<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-27 00:26:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 00:26:13 --> Config Class Initialized
INFO - 2024-02-27 00:26:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:13 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:13 --> URI Class Initialized
DEBUG - 2024-02-27 00:26:13 --> No URI present. Default controller set.
INFO - 2024-02-27 00:26:13 --> Router Class Initialized
INFO - 2024-02-27 00:26:13 --> Output Class Initialized
INFO - 2024-02-27 00:26:13 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:13 --> Input Class Initialized
INFO - 2024-02-27 00:26:13 --> Language Class Initialized
INFO - 2024-02-27 00:26:13 --> Loader Class Initialized
INFO - 2024-02-27 00:26:13 --> Helper loaded: url_helper
INFO - 2024-02-27 00:26:13 --> Helper loaded: file_helper
INFO - 2024-02-27 00:26:13 --> Helper loaded: html_helper
INFO - 2024-02-27 00:26:13 --> Helper loaded: text_helper
INFO - 2024-02-27 00:26:13 --> Helper loaded: form_helper
INFO - 2024-02-27 00:26:13 --> Helper loaded: lang_helper
INFO - 2024-02-27 00:26:13 --> Helper loaded: security_helper
INFO - 2024-02-27 00:26:13 --> Helper loaded: cookie_helper
INFO - 2024-02-27 00:26:13 --> Database Driver Class Initialized
INFO - 2024-02-27 00:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:26:13 --> Parser Class Initialized
INFO - 2024-02-27 00:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 00:26:13 --> Pagination Class Initialized
INFO - 2024-02-27 00:26:13 --> Form Validation Class Initialized
INFO - 2024-02-27 00:26:13 --> Controller Class Initialized
INFO - 2024-02-27 00:26:13 --> Model Class Initialized
DEBUG - 2024-02-27 00:26:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 00:26:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 00:26:14 --> Config Class Initialized
INFO - 2024-02-27 00:26:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:14 --> URI Class Initialized
DEBUG - 2024-02-27 00:26:14 --> No URI present. Default controller set.
INFO - 2024-02-27 00:26:14 --> Router Class Initialized
INFO - 2024-02-27 00:26:14 --> Output Class Initialized
INFO - 2024-02-27 00:26:14 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:14 --> Input Class Initialized
INFO - 2024-02-27 00:26:14 --> Language Class Initialized
INFO - 2024-02-27 00:26:14 --> Loader Class Initialized
INFO - 2024-02-27 00:26:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: html_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: text_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: lang_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: cookie_helper
INFO - 2024-02-27 00:26:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:26:14 --> Parser Class Initialized
INFO - 2024-02-27 00:26:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 00:26:14 --> Pagination Class Initialized
INFO - 2024-02-27 00:26:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:26:14 --> Controller Class Initialized
INFO - 2024-02-27 00:26:14 --> Model Class Initialized
DEBUG - 2024-02-27 00:26:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 00:26:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 00:26:14 --> Config Class Initialized
INFO - 2024-02-27 00:26:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:14 --> URI Class Initialized
DEBUG - 2024-02-27 00:26:14 --> No URI present. Default controller set.
INFO - 2024-02-27 00:26:14 --> Router Class Initialized
INFO - 2024-02-27 00:26:14 --> Output Class Initialized
INFO - 2024-02-27 00:26:14 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:14 --> Input Class Initialized
INFO - 2024-02-27 00:26:14 --> Language Class Initialized
INFO - 2024-02-27 00:26:14 --> Loader Class Initialized
INFO - 2024-02-27 00:26:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: html_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: text_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: lang_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:26:14 --> Helper loaded: cookie_helper
INFO - 2024-02-27 00:26:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:26:14 --> Parser Class Initialized
INFO - 2024-02-27 00:26:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 00:26:14 --> Pagination Class Initialized
INFO - 2024-02-27 00:26:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:26:14 --> Controller Class Initialized
INFO - 2024-02-27 00:26:14 --> Model Class Initialized
DEBUG - 2024-02-27 00:26:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 00:26:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 00:26:15 --> Config Class Initialized
INFO - 2024-02-27 00:26:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:15 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:15 --> URI Class Initialized
DEBUG - 2024-02-27 00:26:15 --> No URI present. Default controller set.
INFO - 2024-02-27 00:26:15 --> Router Class Initialized
INFO - 2024-02-27 00:26:15 --> Output Class Initialized
INFO - 2024-02-27 00:26:15 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:15 --> Input Class Initialized
INFO - 2024-02-27 00:26:15 --> Language Class Initialized
INFO - 2024-02-27 00:26:15 --> Loader Class Initialized
INFO - 2024-02-27 00:26:15 --> Helper loaded: url_helper
INFO - 2024-02-27 00:26:15 --> Helper loaded: file_helper
INFO - 2024-02-27 00:26:15 --> Helper loaded: html_helper
INFO - 2024-02-27 00:26:15 --> Helper loaded: text_helper
INFO - 2024-02-27 00:26:15 --> Helper loaded: form_helper
INFO - 2024-02-27 00:26:15 --> Helper loaded: lang_helper
INFO - 2024-02-27 00:26:15 --> Helper loaded: security_helper
INFO - 2024-02-27 00:26:15 --> Helper loaded: cookie_helper
INFO - 2024-02-27 00:26:15 --> Database Driver Class Initialized
INFO - 2024-02-27 00:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:26:15 --> Parser Class Initialized
INFO - 2024-02-27 00:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 00:26:15 --> Pagination Class Initialized
INFO - 2024-02-27 00:26:15 --> Form Validation Class Initialized
INFO - 2024-02-27 00:26:15 --> Controller Class Initialized
INFO - 2024-02-27 00:26:15 --> Model Class Initialized
DEBUG - 2024-02-27 00:26:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 00:28:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 00:28:00 --> Config Class Initialized
INFO - 2024-02-27 00:28:00 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:00 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:00 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:00 --> URI Class Initialized
INFO - 2024-02-27 00:28:00 --> Router Class Initialized
INFO - 2024-02-27 00:28:00 --> Output Class Initialized
INFO - 2024-02-27 00:28:00 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:00 --> Input Class Initialized
INFO - 2024-02-27 00:28:00 --> Language Class Initialized
ERROR - 2024-02-27 00:28:00 --> 404 Page Not Found: Wp-json/index
ERROR - 2024-02-27 03:08:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 03:08:57 --> Config Class Initialized
INFO - 2024-02-27 03:08:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 03:08:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 03:08:57 --> Utf8 Class Initialized
INFO - 2024-02-27 03:08:57 --> URI Class Initialized
INFO - 2024-02-27 03:08:57 --> Router Class Initialized
INFO - 2024-02-27 03:08:57 --> Output Class Initialized
INFO - 2024-02-27 03:08:57 --> Security Class Initialized
DEBUG - 2024-02-27 03:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 03:08:57 --> Input Class Initialized
INFO - 2024-02-27 03:08:57 --> Language Class Initialized
ERROR - 2024-02-27 03:08:57 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-27 03:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 03:40:57 --> Config Class Initialized
INFO - 2024-02-27 03:40:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 03:40:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 03:40:57 --> Utf8 Class Initialized
INFO - 2024-02-27 03:40:57 --> URI Class Initialized
DEBUG - 2024-02-27 03:40:57 --> No URI present. Default controller set.
INFO - 2024-02-27 03:40:57 --> Router Class Initialized
INFO - 2024-02-27 03:40:57 --> Output Class Initialized
INFO - 2024-02-27 03:40:57 --> Security Class Initialized
DEBUG - 2024-02-27 03:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 03:40:57 --> Input Class Initialized
INFO - 2024-02-27 03:40:57 --> Language Class Initialized
INFO - 2024-02-27 03:40:57 --> Loader Class Initialized
INFO - 2024-02-27 03:40:57 --> Helper loaded: url_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: file_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: html_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: text_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: form_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: lang_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: security_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: cookie_helper
INFO - 2024-02-27 03:40:57 --> Database Driver Class Initialized
INFO - 2024-02-27 03:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 03:40:57 --> Parser Class Initialized
INFO - 2024-02-27 03:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 03:40:57 --> Pagination Class Initialized
INFO - 2024-02-27 03:40:57 --> Form Validation Class Initialized
INFO - 2024-02-27 03:40:57 --> Controller Class Initialized
INFO - 2024-02-27 03:40:57 --> Model Class Initialized
DEBUG - 2024-02-27 03:40:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 03:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 03:40:57 --> Config Class Initialized
INFO - 2024-02-27 03:40:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 03:40:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 03:40:57 --> Utf8 Class Initialized
INFO - 2024-02-27 03:40:57 --> URI Class Initialized
INFO - 2024-02-27 03:40:57 --> Router Class Initialized
INFO - 2024-02-27 03:40:57 --> Output Class Initialized
INFO - 2024-02-27 03:40:57 --> Security Class Initialized
DEBUG - 2024-02-27 03:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 03:40:57 --> Input Class Initialized
INFO - 2024-02-27 03:40:57 --> Language Class Initialized
INFO - 2024-02-27 03:40:57 --> Loader Class Initialized
INFO - 2024-02-27 03:40:57 --> Helper loaded: url_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: file_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: html_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: text_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: form_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: lang_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: security_helper
INFO - 2024-02-27 03:40:57 --> Helper loaded: cookie_helper
INFO - 2024-02-27 03:40:57 --> Database Driver Class Initialized
INFO - 2024-02-27 03:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 03:40:57 --> Parser Class Initialized
INFO - 2024-02-27 03:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 03:40:57 --> Pagination Class Initialized
INFO - 2024-02-27 03:40:57 --> Form Validation Class Initialized
INFO - 2024-02-27 03:40:57 --> Controller Class Initialized
INFO - 2024-02-27 03:40:57 --> Model Class Initialized
DEBUG - 2024-02-27 03:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 03:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 03:40:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 03:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 03:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 03:40:57 --> Model Class Initialized
INFO - 2024-02-27 03:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 03:40:57 --> Final output sent to browser
DEBUG - 2024-02-27 03:40:57 --> Total execution time: 0.0329
ERROR - 2024-02-27 03:41:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 03:41:01 --> Config Class Initialized
INFO - 2024-02-27 03:41:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 03:41:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 03:41:01 --> Utf8 Class Initialized
INFO - 2024-02-27 03:41:01 --> URI Class Initialized
INFO - 2024-02-27 03:41:01 --> Router Class Initialized
INFO - 2024-02-27 03:41:01 --> Output Class Initialized
INFO - 2024-02-27 03:41:01 --> Security Class Initialized
DEBUG - 2024-02-27 03:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 03:41:01 --> Input Class Initialized
INFO - 2024-02-27 03:41:01 --> Language Class Initialized
INFO - 2024-02-27 03:41:01 --> Loader Class Initialized
INFO - 2024-02-27 03:41:01 --> Helper loaded: url_helper
INFO - 2024-02-27 03:41:01 --> Helper loaded: file_helper
INFO - 2024-02-27 03:41:01 --> Helper loaded: html_helper
INFO - 2024-02-27 03:41:01 --> Helper loaded: text_helper
INFO - 2024-02-27 03:41:01 --> Helper loaded: form_helper
INFO - 2024-02-27 03:41:01 --> Helper loaded: lang_helper
INFO - 2024-02-27 03:41:01 --> Helper loaded: security_helper
INFO - 2024-02-27 03:41:01 --> Helper loaded: cookie_helper
INFO - 2024-02-27 03:41:02 --> Database Driver Class Initialized
INFO - 2024-02-27 03:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 03:41:02 --> Parser Class Initialized
INFO - 2024-02-27 03:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 03:41:02 --> Pagination Class Initialized
INFO - 2024-02-27 03:41:02 --> Form Validation Class Initialized
INFO - 2024-02-27 03:41:02 --> Controller Class Initialized
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
DEBUG - 2024-02-27 03:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
INFO - 2024-02-27 03:41:02 --> Final output sent to browser
DEBUG - 2024-02-27 03:41:02 --> Total execution time: 0.0233
ERROR - 2024-02-27 03:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 03:41:02 --> Config Class Initialized
INFO - 2024-02-27 03:41:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 03:41:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 03:41:02 --> Utf8 Class Initialized
INFO - 2024-02-27 03:41:02 --> URI Class Initialized
DEBUG - 2024-02-27 03:41:02 --> No URI present. Default controller set.
INFO - 2024-02-27 03:41:02 --> Router Class Initialized
INFO - 2024-02-27 03:41:02 --> Output Class Initialized
INFO - 2024-02-27 03:41:02 --> Security Class Initialized
DEBUG - 2024-02-27 03:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 03:41:02 --> Input Class Initialized
INFO - 2024-02-27 03:41:02 --> Language Class Initialized
INFO - 2024-02-27 03:41:02 --> Loader Class Initialized
INFO - 2024-02-27 03:41:02 --> Helper loaded: url_helper
INFO - 2024-02-27 03:41:02 --> Helper loaded: file_helper
INFO - 2024-02-27 03:41:02 --> Helper loaded: html_helper
INFO - 2024-02-27 03:41:02 --> Helper loaded: text_helper
INFO - 2024-02-27 03:41:02 --> Helper loaded: form_helper
INFO - 2024-02-27 03:41:02 --> Helper loaded: lang_helper
INFO - 2024-02-27 03:41:02 --> Helper loaded: security_helper
INFO - 2024-02-27 03:41:02 --> Helper loaded: cookie_helper
INFO - 2024-02-27 03:41:02 --> Database Driver Class Initialized
INFO - 2024-02-27 03:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 03:41:02 --> Parser Class Initialized
INFO - 2024-02-27 03:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 03:41:02 --> Pagination Class Initialized
INFO - 2024-02-27 03:41:02 --> Form Validation Class Initialized
INFO - 2024-02-27 03:41:02 --> Controller Class Initialized
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
DEBUG - 2024-02-27 03:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
DEBUG - 2024-02-27 03:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
DEBUG - 2024-02-27 03:41:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 03:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
INFO - 2024-02-27 03:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 03:41:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 03:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 03:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 03:41:02 --> Model Class Initialized
INFO - 2024-02-27 03:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 03:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 03:41:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 03:41:02 --> Final output sent to browser
DEBUG - 2024-02-27 03:41:02 --> Total execution time: 0.4248
ERROR - 2024-02-27 03:41:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 03:41:03 --> Config Class Initialized
INFO - 2024-02-27 03:41:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 03:41:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 03:41:03 --> Utf8 Class Initialized
INFO - 2024-02-27 03:41:03 --> URI Class Initialized
INFO - 2024-02-27 03:41:03 --> Router Class Initialized
INFO - 2024-02-27 03:41:03 --> Output Class Initialized
INFO - 2024-02-27 03:41:03 --> Security Class Initialized
DEBUG - 2024-02-27 03:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 03:41:03 --> Input Class Initialized
INFO - 2024-02-27 03:41:03 --> Language Class Initialized
INFO - 2024-02-27 03:41:03 --> Loader Class Initialized
INFO - 2024-02-27 03:41:03 --> Helper loaded: url_helper
INFO - 2024-02-27 03:41:03 --> Helper loaded: file_helper
INFO - 2024-02-27 03:41:03 --> Helper loaded: html_helper
INFO - 2024-02-27 03:41:03 --> Helper loaded: text_helper
INFO - 2024-02-27 03:41:03 --> Helper loaded: form_helper
INFO - 2024-02-27 03:41:03 --> Helper loaded: lang_helper
INFO - 2024-02-27 03:41:03 --> Helper loaded: security_helper
INFO - 2024-02-27 03:41:03 --> Helper loaded: cookie_helper
INFO - 2024-02-27 03:41:03 --> Database Driver Class Initialized
INFO - 2024-02-27 03:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 03:41:03 --> Parser Class Initialized
INFO - 2024-02-27 03:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 03:41:03 --> Pagination Class Initialized
INFO - 2024-02-27 03:41:03 --> Form Validation Class Initialized
INFO - 2024-02-27 03:41:03 --> Controller Class Initialized
DEBUG - 2024-02-27 03:41:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 03:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 03:41:03 --> Model Class Initialized
INFO - 2024-02-27 03:41:03 --> Final output sent to browser
DEBUG - 2024-02-27 03:41:03 --> Total execution time: 0.0136
ERROR - 2024-02-27 04:37:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:37:50 --> Config Class Initialized
INFO - 2024-02-27 04:37:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:37:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:37:50 --> Utf8 Class Initialized
INFO - 2024-02-27 04:37:50 --> URI Class Initialized
DEBUG - 2024-02-27 04:37:50 --> No URI present. Default controller set.
INFO - 2024-02-27 04:37:50 --> Router Class Initialized
INFO - 2024-02-27 04:37:50 --> Output Class Initialized
INFO - 2024-02-27 04:37:50 --> Security Class Initialized
DEBUG - 2024-02-27 04:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:37:50 --> Input Class Initialized
INFO - 2024-02-27 04:37:50 --> Language Class Initialized
INFO - 2024-02-27 04:37:50 --> Loader Class Initialized
INFO - 2024-02-27 04:37:50 --> Helper loaded: url_helper
INFO - 2024-02-27 04:37:50 --> Helper loaded: file_helper
INFO - 2024-02-27 04:37:50 --> Helper loaded: html_helper
INFO - 2024-02-27 04:37:50 --> Helper loaded: text_helper
INFO - 2024-02-27 04:37:50 --> Helper loaded: form_helper
INFO - 2024-02-27 04:37:50 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:37:50 --> Helper loaded: security_helper
INFO - 2024-02-27 04:37:50 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:37:50 --> Database Driver Class Initialized
INFO - 2024-02-27 04:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:37:50 --> Parser Class Initialized
INFO - 2024-02-27 04:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:37:50 --> Pagination Class Initialized
INFO - 2024-02-27 04:37:50 --> Form Validation Class Initialized
INFO - 2024-02-27 04:37:50 --> Controller Class Initialized
INFO - 2024-02-27 04:37:50 --> Model Class Initialized
DEBUG - 2024-02-27 04:37:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 04:37:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:37:51 --> Config Class Initialized
INFO - 2024-02-27 04:37:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:37:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:37:51 --> Utf8 Class Initialized
INFO - 2024-02-27 04:37:51 --> URI Class Initialized
INFO - 2024-02-27 04:37:51 --> Router Class Initialized
INFO - 2024-02-27 04:37:51 --> Output Class Initialized
INFO - 2024-02-27 04:37:51 --> Security Class Initialized
DEBUG - 2024-02-27 04:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:37:51 --> Input Class Initialized
INFO - 2024-02-27 04:37:51 --> Language Class Initialized
INFO - 2024-02-27 04:37:51 --> Loader Class Initialized
INFO - 2024-02-27 04:37:51 --> Helper loaded: url_helper
INFO - 2024-02-27 04:37:51 --> Helper loaded: file_helper
INFO - 2024-02-27 04:37:51 --> Helper loaded: html_helper
INFO - 2024-02-27 04:37:51 --> Helper loaded: text_helper
INFO - 2024-02-27 04:37:51 --> Helper loaded: form_helper
INFO - 2024-02-27 04:37:51 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:37:51 --> Helper loaded: security_helper
INFO - 2024-02-27 04:37:51 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:37:51 --> Database Driver Class Initialized
INFO - 2024-02-27 04:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:37:51 --> Parser Class Initialized
INFO - 2024-02-27 04:37:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:37:51 --> Pagination Class Initialized
INFO - 2024-02-27 04:37:51 --> Form Validation Class Initialized
INFO - 2024-02-27 04:37:51 --> Controller Class Initialized
INFO - 2024-02-27 04:37:51 --> Model Class Initialized
DEBUG - 2024-02-27 04:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 04:37:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:37:51 --> Model Class Initialized
INFO - 2024-02-27 04:37:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:37:51 --> Final output sent to browser
DEBUG - 2024-02-27 04:37:51 --> Total execution time: 0.0319
ERROR - 2024-02-27 04:38:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:02 --> Config Class Initialized
INFO - 2024-02-27 04:38:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:02 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:02 --> URI Class Initialized
INFO - 2024-02-27 04:38:02 --> Router Class Initialized
INFO - 2024-02-27 04:38:02 --> Output Class Initialized
INFO - 2024-02-27 04:38:02 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:02 --> Input Class Initialized
INFO - 2024-02-27 04:38:02 --> Language Class Initialized
INFO - 2024-02-27 04:38:02 --> Loader Class Initialized
INFO - 2024-02-27 04:38:02 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:02 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:02 --> Parser Class Initialized
INFO - 2024-02-27 04:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:02 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:02 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:02 --> Controller Class Initialized
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
INFO - 2024-02-27 04:38:02 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:02 --> Total execution time: 0.0177
ERROR - 2024-02-27 04:38:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:02 --> Config Class Initialized
INFO - 2024-02-27 04:38:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:02 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:02 --> URI Class Initialized
DEBUG - 2024-02-27 04:38:02 --> No URI present. Default controller set.
INFO - 2024-02-27 04:38:02 --> Router Class Initialized
INFO - 2024-02-27 04:38:02 --> Output Class Initialized
INFO - 2024-02-27 04:38:02 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:02 --> Input Class Initialized
INFO - 2024-02-27 04:38:02 --> Language Class Initialized
INFO - 2024-02-27 04:38:02 --> Loader Class Initialized
INFO - 2024-02-27 04:38:02 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:02 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:02 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:02 --> Parser Class Initialized
INFO - 2024-02-27 04:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:02 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:02 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:02 --> Controller Class Initialized
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
INFO - 2024-02-27 04:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 04:38:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:38:02 --> Model Class Initialized
INFO - 2024-02-27 04:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:38:03 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:03 --> Total execution time: 0.2481
ERROR - 2024-02-27 04:38:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:09 --> Config Class Initialized
INFO - 2024-02-27 04:38:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:09 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:09 --> URI Class Initialized
INFO - 2024-02-27 04:38:09 --> Router Class Initialized
INFO - 2024-02-27 04:38:09 --> Output Class Initialized
INFO - 2024-02-27 04:38:09 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:09 --> Input Class Initialized
INFO - 2024-02-27 04:38:09 --> Language Class Initialized
INFO - 2024-02-27 04:38:09 --> Loader Class Initialized
INFO - 2024-02-27 04:38:09 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:09 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:09 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:09 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:09 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:09 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:09 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:09 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:09 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:09 --> Parser Class Initialized
INFO - 2024-02-27 04:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:09 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:09 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:09 --> Controller Class Initialized
INFO - 2024-02-27 04:38:09 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:09 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:09 --> Model Class Initialized
INFO - 2024-02-27 04:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-27 04:38:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:38:09 --> Model Class Initialized
INFO - 2024-02-27 04:38:09 --> Model Class Initialized
INFO - 2024-02-27 04:38:09 --> Model Class Initialized
INFO - 2024-02-27 04:38:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:38:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:38:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:38:10 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:10 --> Total execution time: 0.1800
ERROR - 2024-02-27 04:38:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:16 --> Config Class Initialized
INFO - 2024-02-27 04:38:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:16 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:16 --> URI Class Initialized
INFO - 2024-02-27 04:38:16 --> Router Class Initialized
INFO - 2024-02-27 04:38:16 --> Output Class Initialized
INFO - 2024-02-27 04:38:16 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:16 --> Input Class Initialized
INFO - 2024-02-27 04:38:16 --> Language Class Initialized
INFO - 2024-02-27 04:38:16 --> Loader Class Initialized
INFO - 2024-02-27 04:38:16 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:16 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:16 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:16 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:16 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:16 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:16 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:16 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:16 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:16 --> Parser Class Initialized
INFO - 2024-02-27 04:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:16 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:16 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:16 --> Controller Class Initialized
INFO - 2024-02-27 04:38:16 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:16 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:16 --> Total execution time: 0.0155
ERROR - 2024-02-27 04:38:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:17 --> Config Class Initialized
INFO - 2024-02-27 04:38:17 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:17 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:17 --> URI Class Initialized
INFO - 2024-02-27 04:38:17 --> Router Class Initialized
INFO - 2024-02-27 04:38:17 --> Output Class Initialized
INFO - 2024-02-27 04:38:17 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:17 --> Input Class Initialized
INFO - 2024-02-27 04:38:17 --> Language Class Initialized
INFO - 2024-02-27 04:38:17 --> Loader Class Initialized
INFO - 2024-02-27 04:38:17 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:17 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:17 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:17 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:17 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:17 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:17 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:17 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:17 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:17 --> Parser Class Initialized
INFO - 2024-02-27 04:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:17 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:17 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:17 --> Controller Class Initialized
INFO - 2024-02-27 04:38:17 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:17 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:17 --> Total execution time: 0.0149
ERROR - 2024-02-27 04:38:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:32 --> Config Class Initialized
INFO - 2024-02-27 04:38:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:32 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:32 --> URI Class Initialized
INFO - 2024-02-27 04:38:32 --> Router Class Initialized
INFO - 2024-02-27 04:38:32 --> Output Class Initialized
INFO - 2024-02-27 04:38:32 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:32 --> Input Class Initialized
INFO - 2024-02-27 04:38:32 --> Language Class Initialized
INFO - 2024-02-27 04:38:32 --> Loader Class Initialized
INFO - 2024-02-27 04:38:32 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:32 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:32 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:32 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:32 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:32 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:32 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:32 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:32 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:32 --> Parser Class Initialized
INFO - 2024-02-27 04:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:32 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:32 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:32 --> Controller Class Initialized
INFO - 2024-02-27 04:38:32 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:32 --> Total execution time: 0.0158
ERROR - 2024-02-27 04:38:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:37 --> Config Class Initialized
INFO - 2024-02-27 04:38:37 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:37 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:37 --> URI Class Initialized
INFO - 2024-02-27 04:38:37 --> Router Class Initialized
INFO - 2024-02-27 04:38:37 --> Output Class Initialized
INFO - 2024-02-27 04:38:37 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:37 --> Input Class Initialized
INFO - 2024-02-27 04:38:37 --> Language Class Initialized
INFO - 2024-02-27 04:38:37 --> Loader Class Initialized
INFO - 2024-02-27 04:38:37 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:37 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:37 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:37 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:37 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:37 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:37 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:37 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:37 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:37 --> Parser Class Initialized
INFO - 2024-02-27 04:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:37 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:37 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:37 --> Controller Class Initialized
INFO - 2024-02-27 04:38:37 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:37 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:37 --> Total execution time: 0.0155
ERROR - 2024-02-27 04:38:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:53 --> Config Class Initialized
INFO - 2024-02-27 04:38:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:53 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:53 --> URI Class Initialized
INFO - 2024-02-27 04:38:53 --> Router Class Initialized
INFO - 2024-02-27 04:38:53 --> Output Class Initialized
INFO - 2024-02-27 04:38:53 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:53 --> Input Class Initialized
INFO - 2024-02-27 04:38:53 --> Language Class Initialized
INFO - 2024-02-27 04:38:53 --> Loader Class Initialized
INFO - 2024-02-27 04:38:53 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:53 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:53 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:53 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:53 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:53 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:53 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:53 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:53 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:53 --> Parser Class Initialized
INFO - 2024-02-27 04:38:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:53 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:53 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:53 --> Controller Class Initialized
INFO - 2024-02-27 04:38:53 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:53 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:53 --> Total execution time: 0.0182
ERROR - 2024-02-27 04:38:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:54 --> Config Class Initialized
INFO - 2024-02-27 04:38:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:54 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:54 --> URI Class Initialized
INFO - 2024-02-27 04:38:54 --> Router Class Initialized
INFO - 2024-02-27 04:38:54 --> Output Class Initialized
INFO - 2024-02-27 04:38:54 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:54 --> Input Class Initialized
INFO - 2024-02-27 04:38:54 --> Language Class Initialized
INFO - 2024-02-27 04:38:54 --> Loader Class Initialized
INFO - 2024-02-27 04:38:54 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:54 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:54 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:54 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:54 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:54 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:54 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:54 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:54 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:54 --> Parser Class Initialized
INFO - 2024-02-27 04:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:54 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:54 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:54 --> Controller Class Initialized
INFO - 2024-02-27 04:38:54 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:54 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:54 --> Total execution time: 0.0171
ERROR - 2024-02-27 04:38:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:38:55 --> Config Class Initialized
INFO - 2024-02-27 04:38:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:38:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:38:55 --> Utf8 Class Initialized
INFO - 2024-02-27 04:38:55 --> URI Class Initialized
INFO - 2024-02-27 04:38:55 --> Router Class Initialized
INFO - 2024-02-27 04:38:55 --> Output Class Initialized
INFO - 2024-02-27 04:38:55 --> Security Class Initialized
DEBUG - 2024-02-27 04:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:38:55 --> Input Class Initialized
INFO - 2024-02-27 04:38:55 --> Language Class Initialized
INFO - 2024-02-27 04:38:55 --> Loader Class Initialized
INFO - 2024-02-27 04:38:55 --> Helper loaded: url_helper
INFO - 2024-02-27 04:38:55 --> Helper loaded: file_helper
INFO - 2024-02-27 04:38:55 --> Helper loaded: html_helper
INFO - 2024-02-27 04:38:55 --> Helper loaded: text_helper
INFO - 2024-02-27 04:38:55 --> Helper loaded: form_helper
INFO - 2024-02-27 04:38:55 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:38:55 --> Helper loaded: security_helper
INFO - 2024-02-27 04:38:55 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:38:55 --> Database Driver Class Initialized
INFO - 2024-02-27 04:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:38:55 --> Parser Class Initialized
INFO - 2024-02-27 04:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:38:55 --> Pagination Class Initialized
INFO - 2024-02-27 04:38:55 --> Form Validation Class Initialized
INFO - 2024-02-27 04:38:55 --> Controller Class Initialized
INFO - 2024-02-27 04:38:55 --> Model Class Initialized
DEBUG - 2024-02-27 04:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:38:55 --> Final output sent to browser
DEBUG - 2024-02-27 04:38:55 --> Total execution time: 0.0158
ERROR - 2024-02-27 04:39:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:02 --> Config Class Initialized
INFO - 2024-02-27 04:39:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:02 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:02 --> URI Class Initialized
INFO - 2024-02-27 04:39:02 --> Router Class Initialized
INFO - 2024-02-27 04:39:02 --> Output Class Initialized
INFO - 2024-02-27 04:39:02 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:02 --> Input Class Initialized
INFO - 2024-02-27 04:39:02 --> Language Class Initialized
INFO - 2024-02-27 04:39:02 --> Loader Class Initialized
INFO - 2024-02-27 04:39:02 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:02 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:02 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:02 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:02 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:02 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:02 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:02 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:02 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:02 --> Parser Class Initialized
INFO - 2024-02-27 04:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:02 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:02 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:02 --> Controller Class Initialized
INFO - 2024-02-27 04:39:02 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:02 --> Total execution time: 0.0157
ERROR - 2024-02-27 04:39:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:10 --> Config Class Initialized
INFO - 2024-02-27 04:39:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:10 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:10 --> URI Class Initialized
INFO - 2024-02-27 04:39:10 --> Router Class Initialized
INFO - 2024-02-27 04:39:10 --> Output Class Initialized
INFO - 2024-02-27 04:39:10 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:10 --> Input Class Initialized
INFO - 2024-02-27 04:39:10 --> Language Class Initialized
INFO - 2024-02-27 04:39:10 --> Loader Class Initialized
INFO - 2024-02-27 04:39:10 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:10 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:10 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:10 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:10 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:10 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:10 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:10 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:10 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:10 --> Parser Class Initialized
INFO - 2024-02-27 04:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:10 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:10 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:10 --> Controller Class Initialized
INFO - 2024-02-27 04:39:10 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:10 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:10 --> Model Class Initialized
INFO - 2024-02-27 04:39:10 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:10 --> Total execution time: 0.1299
ERROR - 2024-02-27 04:39:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:12 --> Config Class Initialized
INFO - 2024-02-27 04:39:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:12 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:12 --> URI Class Initialized
INFO - 2024-02-27 04:39:12 --> Router Class Initialized
INFO - 2024-02-27 04:39:12 --> Output Class Initialized
INFO - 2024-02-27 04:39:12 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:12 --> Input Class Initialized
INFO - 2024-02-27 04:39:12 --> Language Class Initialized
INFO - 2024-02-27 04:39:12 --> Loader Class Initialized
INFO - 2024-02-27 04:39:12 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:12 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:12 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:12 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:12 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:12 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:12 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:12 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:12 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:12 --> Parser Class Initialized
INFO - 2024-02-27 04:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:12 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:12 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:12 --> Controller Class Initialized
INFO - 2024-02-27 04:39:12 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:12 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:12 --> Model Class Initialized
INFO - 2024-02-27 04:39:12 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:12 --> Total execution time: 0.1377
ERROR - 2024-02-27 04:39:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:13 --> Config Class Initialized
INFO - 2024-02-27 04:39:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:13 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:13 --> URI Class Initialized
INFO - 2024-02-27 04:39:13 --> Router Class Initialized
INFO - 2024-02-27 04:39:13 --> Output Class Initialized
INFO - 2024-02-27 04:39:13 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:13 --> Input Class Initialized
INFO - 2024-02-27 04:39:13 --> Language Class Initialized
INFO - 2024-02-27 04:39:13 --> Loader Class Initialized
INFO - 2024-02-27 04:39:13 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:13 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:13 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:13 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:13 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:13 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:13 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:13 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:13 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:13 --> Parser Class Initialized
INFO - 2024-02-27 04:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:13 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:13 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:13 --> Controller Class Initialized
INFO - 2024-02-27 04:39:13 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:13 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:13 --> Model Class Initialized
INFO - 2024-02-27 04:39:13 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:13 --> Total execution time: 0.0171
ERROR - 2024-02-27 04:39:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:17 --> Config Class Initialized
INFO - 2024-02-27 04:39:17 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:17 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:17 --> URI Class Initialized
INFO - 2024-02-27 04:39:17 --> Router Class Initialized
INFO - 2024-02-27 04:39:17 --> Output Class Initialized
INFO - 2024-02-27 04:39:17 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:17 --> Input Class Initialized
INFO - 2024-02-27 04:39:17 --> Language Class Initialized
INFO - 2024-02-27 04:39:17 --> Loader Class Initialized
INFO - 2024-02-27 04:39:17 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:17 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:17 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:17 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:17 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:17 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:17 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:17 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:17 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:17 --> Parser Class Initialized
INFO - 2024-02-27 04:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:17 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:17 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:17 --> Controller Class Initialized
INFO - 2024-02-27 04:39:17 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:17 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:17 --> Model Class Initialized
INFO - 2024-02-27 04:39:17 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:17 --> Total execution time: 0.1350
ERROR - 2024-02-27 04:39:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:30 --> Config Class Initialized
INFO - 2024-02-27 04:39:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:30 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:30 --> URI Class Initialized
INFO - 2024-02-27 04:39:30 --> Router Class Initialized
INFO - 2024-02-27 04:39:30 --> Output Class Initialized
INFO - 2024-02-27 04:39:30 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:30 --> Input Class Initialized
INFO - 2024-02-27 04:39:30 --> Language Class Initialized
INFO - 2024-02-27 04:39:30 --> Loader Class Initialized
INFO - 2024-02-27 04:39:30 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:30 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:30 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:30 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:30 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:30 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:30 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:30 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:30 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:30 --> Parser Class Initialized
INFO - 2024-02-27 04:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:30 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:30 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:30 --> Controller Class Initialized
INFO - 2024-02-27 04:39:30 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:30 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:30 --> Model Class Initialized
INFO - 2024-02-27 04:39:30 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:30 --> Total execution time: 0.1307
ERROR - 2024-02-27 04:39:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:33 --> Config Class Initialized
INFO - 2024-02-27 04:39:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:33 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:33 --> URI Class Initialized
INFO - 2024-02-27 04:39:33 --> Router Class Initialized
INFO - 2024-02-27 04:39:33 --> Output Class Initialized
INFO - 2024-02-27 04:39:33 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:33 --> Input Class Initialized
INFO - 2024-02-27 04:39:33 --> Language Class Initialized
INFO - 2024-02-27 04:39:33 --> Loader Class Initialized
INFO - 2024-02-27 04:39:33 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:33 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:33 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:33 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:33 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:33 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:33 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:33 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:33 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:33 --> Parser Class Initialized
INFO - 2024-02-27 04:39:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:33 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:33 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:33 --> Controller Class Initialized
INFO - 2024-02-27 04:39:33 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:33 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:33 --> Model Class Initialized
INFO - 2024-02-27 04:39:33 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:33 --> Total execution time: 0.0446
ERROR - 2024-02-27 04:39:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:34 --> Config Class Initialized
INFO - 2024-02-27 04:39:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:34 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:34 --> URI Class Initialized
INFO - 2024-02-27 04:39:34 --> Router Class Initialized
INFO - 2024-02-27 04:39:34 --> Output Class Initialized
INFO - 2024-02-27 04:39:34 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:34 --> Input Class Initialized
INFO - 2024-02-27 04:39:34 --> Language Class Initialized
INFO - 2024-02-27 04:39:34 --> Loader Class Initialized
INFO - 2024-02-27 04:39:34 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:34 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:34 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:34 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:34 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:34 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:34 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:34 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:34 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:34 --> Parser Class Initialized
INFO - 2024-02-27 04:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:34 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:34 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:34 --> Controller Class Initialized
INFO - 2024-02-27 04:39:34 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:34 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:34 --> Model Class Initialized
INFO - 2024-02-27 04:39:34 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:34 --> Total execution time: 0.0265
ERROR - 2024-02-27 04:39:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:37 --> Config Class Initialized
INFO - 2024-02-27 04:39:37 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:37 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:37 --> URI Class Initialized
INFO - 2024-02-27 04:39:37 --> Router Class Initialized
INFO - 2024-02-27 04:39:37 --> Output Class Initialized
INFO - 2024-02-27 04:39:37 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:37 --> Input Class Initialized
INFO - 2024-02-27 04:39:37 --> Language Class Initialized
INFO - 2024-02-27 04:39:37 --> Loader Class Initialized
INFO - 2024-02-27 04:39:37 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:37 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:37 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:37 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:37 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:37 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:37 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:37 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:37 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:37 --> Parser Class Initialized
INFO - 2024-02-27 04:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:37 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:37 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:37 --> Controller Class Initialized
INFO - 2024-02-27 04:39:37 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:37 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:37 --> Model Class Initialized
INFO - 2024-02-27 04:39:37 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:37 --> Total execution time: 0.0210
ERROR - 2024-02-27 04:39:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:39 --> Config Class Initialized
INFO - 2024-02-27 04:39:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:39 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:39 --> URI Class Initialized
INFO - 2024-02-27 04:39:39 --> Router Class Initialized
INFO - 2024-02-27 04:39:39 --> Output Class Initialized
INFO - 2024-02-27 04:39:39 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:39 --> Input Class Initialized
INFO - 2024-02-27 04:39:39 --> Language Class Initialized
INFO - 2024-02-27 04:39:39 --> Loader Class Initialized
INFO - 2024-02-27 04:39:39 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:39 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:39 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:39 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:39 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:39 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:39 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:39 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:39 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:39 --> Parser Class Initialized
INFO - 2024-02-27 04:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:39 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:39 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:39 --> Controller Class Initialized
INFO - 2024-02-27 04:39:39 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:39 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:39 --> Model Class Initialized
INFO - 2024-02-27 04:39:39 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:39 --> Total execution time: 0.0274
ERROR - 2024-02-27 04:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:41 --> Config Class Initialized
INFO - 2024-02-27 04:39:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:41 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:41 --> URI Class Initialized
INFO - 2024-02-27 04:39:41 --> Router Class Initialized
INFO - 2024-02-27 04:39:41 --> Output Class Initialized
INFO - 2024-02-27 04:39:41 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:41 --> Input Class Initialized
INFO - 2024-02-27 04:39:41 --> Language Class Initialized
INFO - 2024-02-27 04:39:41 --> Loader Class Initialized
INFO - 2024-02-27 04:39:41 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:41 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:41 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:41 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:41 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:41 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:41 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:41 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:41 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:41 --> Parser Class Initialized
INFO - 2024-02-27 04:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:41 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:41 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:41 --> Controller Class Initialized
INFO - 2024-02-27 04:39:41 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:41 --> Model Class Initialized
INFO - 2024-02-27 04:39:41 --> Model Class Initialized
INFO - 2024-02-27 04:39:41 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:41 --> Total execution time: 0.0197
ERROR - 2024-02-27 04:39:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:43 --> Config Class Initialized
INFO - 2024-02-27 04:39:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:43 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:43 --> URI Class Initialized
INFO - 2024-02-27 04:39:43 --> Router Class Initialized
INFO - 2024-02-27 04:39:43 --> Output Class Initialized
INFO - 2024-02-27 04:39:43 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:43 --> Input Class Initialized
INFO - 2024-02-27 04:39:43 --> Language Class Initialized
INFO - 2024-02-27 04:39:43 --> Loader Class Initialized
INFO - 2024-02-27 04:39:43 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:43 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:43 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:43 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:43 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:43 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:43 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:43 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:43 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:43 --> Parser Class Initialized
INFO - 2024-02-27 04:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:43 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:43 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:43 --> Controller Class Initialized
INFO - 2024-02-27 04:39:43 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:43 --> Model Class Initialized
INFO - 2024-02-27 04:39:43 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:43 --> Total execution time: 0.0202
ERROR - 2024-02-27 04:39:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:39:45 --> Config Class Initialized
INFO - 2024-02-27 04:39:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:39:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:39:45 --> Utf8 Class Initialized
INFO - 2024-02-27 04:39:45 --> URI Class Initialized
INFO - 2024-02-27 04:39:45 --> Router Class Initialized
INFO - 2024-02-27 04:39:45 --> Output Class Initialized
INFO - 2024-02-27 04:39:45 --> Security Class Initialized
DEBUG - 2024-02-27 04:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:39:45 --> Input Class Initialized
INFO - 2024-02-27 04:39:45 --> Language Class Initialized
INFO - 2024-02-27 04:39:45 --> Loader Class Initialized
INFO - 2024-02-27 04:39:45 --> Helper loaded: url_helper
INFO - 2024-02-27 04:39:45 --> Helper loaded: file_helper
INFO - 2024-02-27 04:39:45 --> Helper loaded: html_helper
INFO - 2024-02-27 04:39:45 --> Helper loaded: text_helper
INFO - 2024-02-27 04:39:45 --> Helper loaded: form_helper
INFO - 2024-02-27 04:39:45 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:39:45 --> Helper loaded: security_helper
INFO - 2024-02-27 04:39:45 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:39:45 --> Database Driver Class Initialized
INFO - 2024-02-27 04:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:39:45 --> Parser Class Initialized
INFO - 2024-02-27 04:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:39:45 --> Pagination Class Initialized
INFO - 2024-02-27 04:39:45 --> Form Validation Class Initialized
INFO - 2024-02-27 04:39:45 --> Controller Class Initialized
INFO - 2024-02-27 04:39:45 --> Model Class Initialized
DEBUG - 2024-02-27 04:39:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:39:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:39:45 --> Model Class Initialized
INFO - 2024-02-27 04:39:45 --> Final output sent to browser
DEBUG - 2024-02-27 04:39:45 --> Total execution time: 0.0166
ERROR - 2024-02-27 04:40:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:01 --> Config Class Initialized
INFO - 2024-02-27 04:40:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:01 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:01 --> URI Class Initialized
INFO - 2024-02-27 04:40:01 --> Router Class Initialized
INFO - 2024-02-27 04:40:01 --> Output Class Initialized
INFO - 2024-02-27 04:40:01 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:01 --> Input Class Initialized
INFO - 2024-02-27 04:40:01 --> Language Class Initialized
INFO - 2024-02-27 04:40:01 --> Loader Class Initialized
INFO - 2024-02-27 04:40:01 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:01 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:01 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:01 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:01 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:01 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:01 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:01 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:01 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:01 --> Parser Class Initialized
INFO - 2024-02-27 04:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:01 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:01 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:01 --> Controller Class Initialized
INFO - 2024-02-27 04:40:01 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:01 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:01 --> Model Class Initialized
INFO - 2024-02-27 04:40:02 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:02 --> Total execution time: 0.1363
ERROR - 2024-02-27 04:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:03 --> Config Class Initialized
INFO - 2024-02-27 04:40:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:03 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:03 --> URI Class Initialized
INFO - 2024-02-27 04:40:03 --> Router Class Initialized
INFO - 2024-02-27 04:40:03 --> Output Class Initialized
INFO - 2024-02-27 04:40:03 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:03 --> Input Class Initialized
INFO - 2024-02-27 04:40:03 --> Language Class Initialized
INFO - 2024-02-27 04:40:03 --> Loader Class Initialized
INFO - 2024-02-27 04:40:03 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:03 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:03 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:03 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:03 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:03 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:03 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:03 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:03 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:03 --> Parser Class Initialized
INFO - 2024-02-27 04:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:03 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:03 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:03 --> Controller Class Initialized
INFO - 2024-02-27 04:40:03 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:03 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:03 --> Model Class Initialized
INFO - 2024-02-27 04:40:04 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:04 --> Total execution time: 0.1335
ERROR - 2024-02-27 04:40:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:05 --> Config Class Initialized
INFO - 2024-02-27 04:40:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:05 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:05 --> URI Class Initialized
INFO - 2024-02-27 04:40:05 --> Router Class Initialized
INFO - 2024-02-27 04:40:05 --> Output Class Initialized
INFO - 2024-02-27 04:40:05 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:05 --> Input Class Initialized
INFO - 2024-02-27 04:40:05 --> Language Class Initialized
INFO - 2024-02-27 04:40:05 --> Loader Class Initialized
INFO - 2024-02-27 04:40:05 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:05 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:05 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:05 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:05 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:05 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:05 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:05 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:05 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:05 --> Parser Class Initialized
INFO - 2024-02-27 04:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:05 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:05 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:05 --> Controller Class Initialized
INFO - 2024-02-27 04:40:05 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:05 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:05 --> Model Class Initialized
INFO - 2024-02-27 04:40:05 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:05 --> Total execution time: 0.1486
ERROR - 2024-02-27 04:40:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:06 --> Config Class Initialized
INFO - 2024-02-27 04:40:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:06 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:06 --> URI Class Initialized
INFO - 2024-02-27 04:40:06 --> Router Class Initialized
INFO - 2024-02-27 04:40:06 --> Output Class Initialized
INFO - 2024-02-27 04:40:06 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:06 --> Input Class Initialized
INFO - 2024-02-27 04:40:06 --> Language Class Initialized
INFO - 2024-02-27 04:40:06 --> Loader Class Initialized
INFO - 2024-02-27 04:40:06 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:06 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:06 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:06 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:06 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:06 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:06 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:06 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:06 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:06 --> Parser Class Initialized
INFO - 2024-02-27 04:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:06 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:06 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:06 --> Controller Class Initialized
INFO - 2024-02-27 04:40:06 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:06 --> Model Class Initialized
INFO - 2024-02-27 04:40:06 --> Model Class Initialized
INFO - 2024-02-27 04:40:06 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:06 --> Total execution time: 0.0224
ERROR - 2024-02-27 04:40:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:09 --> Config Class Initialized
INFO - 2024-02-27 04:40:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:09 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:09 --> URI Class Initialized
INFO - 2024-02-27 04:40:09 --> Router Class Initialized
INFO - 2024-02-27 04:40:09 --> Output Class Initialized
INFO - 2024-02-27 04:40:09 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:09 --> Input Class Initialized
INFO - 2024-02-27 04:40:09 --> Language Class Initialized
INFO - 2024-02-27 04:40:09 --> Loader Class Initialized
INFO - 2024-02-27 04:40:09 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:09 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:09 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:09 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:09 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:09 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:09 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:09 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:09 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:09 --> Parser Class Initialized
INFO - 2024-02-27 04:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:09 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:09 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:09 --> Controller Class Initialized
INFO - 2024-02-27 04:40:09 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:09 --> Model Class Initialized
INFO - 2024-02-27 04:40:09 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:09 --> Total execution time: 0.0211
ERROR - 2024-02-27 04:40:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:23 --> Config Class Initialized
INFO - 2024-02-27 04:40:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:23 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:23 --> URI Class Initialized
INFO - 2024-02-27 04:40:23 --> Router Class Initialized
INFO - 2024-02-27 04:40:23 --> Output Class Initialized
INFO - 2024-02-27 04:40:23 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:23 --> Input Class Initialized
INFO - 2024-02-27 04:40:23 --> Language Class Initialized
INFO - 2024-02-27 04:40:23 --> Loader Class Initialized
INFO - 2024-02-27 04:40:23 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:23 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:23 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:23 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:23 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:23 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:23 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:23 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:23 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:23 --> Parser Class Initialized
INFO - 2024-02-27 04:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:23 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:23 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:23 --> Controller Class Initialized
INFO - 2024-02-27 04:40:24 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:24 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:24 --> Model Class Initialized
INFO - 2024-02-27 04:40:24 --> Email Class Initialized
DEBUG - 2024-02-27 04:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 04:40:24 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-27 04:40:24 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-27 04:40:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-27 04:40:24 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:24 --> Total execution time: 0.2623
ERROR - 2024-02-27 04:40:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:27 --> Config Class Initialized
INFO - 2024-02-27 04:40:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:27 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:27 --> URI Class Initialized
INFO - 2024-02-27 04:40:27 --> Router Class Initialized
INFO - 2024-02-27 04:40:27 --> Output Class Initialized
INFO - 2024-02-27 04:40:27 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:27 --> Input Class Initialized
INFO - 2024-02-27 04:40:27 --> Language Class Initialized
INFO - 2024-02-27 04:40:27 --> Loader Class Initialized
INFO - 2024-02-27 04:40:27 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:27 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:27 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:27 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:27 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:27 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:27 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:27 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:27 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:27 --> Parser Class Initialized
INFO - 2024-02-27 04:40:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:27 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:27 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:27 --> Controller Class Initialized
INFO - 2024-02-27 04:40:27 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:27 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:27 --> Model Class Initialized
INFO - 2024-02-27 04:40:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-27 04:40:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:40:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:40:27 --> Model Class Initialized
INFO - 2024-02-27 04:40:27 --> Model Class Initialized
INFO - 2024-02-27 04:40:27 --> Model Class Initialized
INFO - 2024-02-27 04:40:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:40:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:40:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:40:27 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:27 --> Total execution time: 0.1901
ERROR - 2024-02-27 04:40:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:29 --> Config Class Initialized
INFO - 2024-02-27 04:40:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:29 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:29 --> URI Class Initialized
DEBUG - 2024-02-27 04:40:29 --> No URI present. Default controller set.
INFO - 2024-02-27 04:40:29 --> Router Class Initialized
INFO - 2024-02-27 04:40:29 --> Output Class Initialized
INFO - 2024-02-27 04:40:29 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:29 --> Input Class Initialized
INFO - 2024-02-27 04:40:29 --> Language Class Initialized
INFO - 2024-02-27 04:40:29 --> Loader Class Initialized
INFO - 2024-02-27 04:40:29 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:29 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:29 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:29 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:29 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:29 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:29 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:29 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:29 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:29 --> Parser Class Initialized
INFO - 2024-02-27 04:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:29 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:29 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:29 --> Controller Class Initialized
INFO - 2024-02-27 04:40:29 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:29 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:29 --> Model Class Initialized
INFO - 2024-02-27 04:40:29 --> Model Class Initialized
INFO - 2024-02-27 04:40:29 --> Model Class Initialized
INFO - 2024-02-27 04:40:29 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:29 --> Model Class Initialized
INFO - 2024-02-27 04:40:29 --> Model Class Initialized
INFO - 2024-02-27 04:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 04:40:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:40:29 --> Model Class Initialized
INFO - 2024-02-27 04:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:40:29 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:29 --> Total execution time: 0.2424
ERROR - 2024-02-27 04:40:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:42 --> Config Class Initialized
INFO - 2024-02-27 04:40:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:42 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:42 --> URI Class Initialized
INFO - 2024-02-27 04:40:42 --> Router Class Initialized
INFO - 2024-02-27 04:40:42 --> Output Class Initialized
INFO - 2024-02-27 04:40:42 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:42 --> Input Class Initialized
INFO - 2024-02-27 04:40:42 --> Language Class Initialized
INFO - 2024-02-27 04:40:42 --> Loader Class Initialized
INFO - 2024-02-27 04:40:42 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:42 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:42 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:42 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:42 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:42 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:42 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:42 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:42 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:42 --> Parser Class Initialized
INFO - 2024-02-27 04:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:42 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:42 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:42 --> Controller Class Initialized
INFO - 2024-02-27 04:40:42 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:42 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:42 --> Model Class Initialized
INFO - 2024-02-27 04:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-02-27 04:40:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:40:42 --> Model Class Initialized
INFO - 2024-02-27 04:40:42 --> Model Class Initialized
INFO - 2024-02-27 04:40:42 --> Model Class Initialized
INFO - 2024-02-27 04:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:40:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:40:42 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:42 --> Total execution time: 0.1626
ERROR - 2024-02-27 04:40:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:43 --> Config Class Initialized
INFO - 2024-02-27 04:40:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:43 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:43 --> URI Class Initialized
INFO - 2024-02-27 04:40:43 --> Router Class Initialized
INFO - 2024-02-27 04:40:43 --> Output Class Initialized
INFO - 2024-02-27 04:40:43 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:43 --> Input Class Initialized
INFO - 2024-02-27 04:40:43 --> Language Class Initialized
INFO - 2024-02-27 04:40:43 --> Loader Class Initialized
INFO - 2024-02-27 04:40:43 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:43 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:43 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:43 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:43 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:43 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:43 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:43 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:43 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:43 --> Parser Class Initialized
INFO - 2024-02-27 04:40:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:43 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:43 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:43 --> Controller Class Initialized
INFO - 2024-02-27 04:40:43 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:43 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:43 --> Model Class Initialized
INFO - 2024-02-27 04:40:43 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:43 --> Total execution time: 0.0246
ERROR - 2024-02-27 04:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:40:57 --> Config Class Initialized
INFO - 2024-02-27 04:40:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:40:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:40:57 --> Utf8 Class Initialized
INFO - 2024-02-27 04:40:57 --> URI Class Initialized
INFO - 2024-02-27 04:40:57 --> Router Class Initialized
INFO - 2024-02-27 04:40:57 --> Output Class Initialized
INFO - 2024-02-27 04:40:57 --> Security Class Initialized
DEBUG - 2024-02-27 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:40:57 --> Input Class Initialized
INFO - 2024-02-27 04:40:57 --> Language Class Initialized
INFO - 2024-02-27 04:40:57 --> Loader Class Initialized
INFO - 2024-02-27 04:40:57 --> Helper loaded: url_helper
INFO - 2024-02-27 04:40:57 --> Helper loaded: file_helper
INFO - 2024-02-27 04:40:57 --> Helper loaded: html_helper
INFO - 2024-02-27 04:40:57 --> Helper loaded: text_helper
INFO - 2024-02-27 04:40:57 --> Helper loaded: form_helper
INFO - 2024-02-27 04:40:57 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:40:57 --> Helper loaded: security_helper
INFO - 2024-02-27 04:40:57 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:40:57 --> Database Driver Class Initialized
INFO - 2024-02-27 04:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:40:57 --> Parser Class Initialized
INFO - 2024-02-27 04:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:40:57 --> Pagination Class Initialized
INFO - 2024-02-27 04:40:57 --> Form Validation Class Initialized
INFO - 2024-02-27 04:40:57 --> Controller Class Initialized
INFO - 2024-02-27 04:40:57 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:57 --> Model Class Initialized
DEBUG - 2024-02-27 04:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:57 --> Model Class Initialized
INFO - 2024-02-27 04:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-02-27 04:40:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:40:57 --> Model Class Initialized
INFO - 2024-02-27 04:40:57 --> Model Class Initialized
INFO - 2024-02-27 04:40:57 --> Model Class Initialized
INFO - 2024-02-27 04:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:40:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:40:57 --> Final output sent to browser
DEBUG - 2024-02-27 04:40:57 --> Total execution time: 0.1781
ERROR - 2024-02-27 04:41:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:41:10 --> Config Class Initialized
INFO - 2024-02-27 04:41:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:41:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:41:10 --> Utf8 Class Initialized
INFO - 2024-02-27 04:41:10 --> URI Class Initialized
INFO - 2024-02-27 04:41:10 --> Router Class Initialized
INFO - 2024-02-27 04:41:10 --> Output Class Initialized
INFO - 2024-02-27 04:41:10 --> Security Class Initialized
DEBUG - 2024-02-27 04:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:41:10 --> Input Class Initialized
INFO - 2024-02-27 04:41:10 --> Language Class Initialized
INFO - 2024-02-27 04:41:10 --> Loader Class Initialized
INFO - 2024-02-27 04:41:10 --> Helper loaded: url_helper
INFO - 2024-02-27 04:41:10 --> Helper loaded: file_helper
INFO - 2024-02-27 04:41:10 --> Helper loaded: html_helper
INFO - 2024-02-27 04:41:10 --> Helper loaded: text_helper
INFO - 2024-02-27 04:41:10 --> Helper loaded: form_helper
INFO - 2024-02-27 04:41:10 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:41:10 --> Helper loaded: security_helper
INFO - 2024-02-27 04:41:10 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:41:10 --> Database Driver Class Initialized
INFO - 2024-02-27 04:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:41:10 --> Parser Class Initialized
INFO - 2024-02-27 04:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:41:10 --> Pagination Class Initialized
INFO - 2024-02-27 04:41:10 --> Form Validation Class Initialized
INFO - 2024-02-27 04:41:10 --> Controller Class Initialized
INFO - 2024-02-27 04:41:10 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:10 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:10 --> Model Class Initialized
INFO - 2024-02-27 04:41:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-02-27 04:41:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:41:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:41:10 --> Model Class Initialized
INFO - 2024-02-27 04:41:10 --> Model Class Initialized
INFO - 2024-02-27 04:41:10 --> Model Class Initialized
INFO - 2024-02-27 04:41:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:41:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:41:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:41:10 --> Final output sent to browser
DEBUG - 2024-02-27 04:41:10 --> Total execution time: 0.1700
ERROR - 2024-02-27 04:41:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:41:11 --> Config Class Initialized
INFO - 2024-02-27 04:41:11 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:41:11 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:41:11 --> Utf8 Class Initialized
INFO - 2024-02-27 04:41:11 --> URI Class Initialized
INFO - 2024-02-27 04:41:11 --> Router Class Initialized
INFO - 2024-02-27 04:41:11 --> Output Class Initialized
INFO - 2024-02-27 04:41:11 --> Security Class Initialized
DEBUG - 2024-02-27 04:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:41:11 --> Input Class Initialized
INFO - 2024-02-27 04:41:11 --> Language Class Initialized
INFO - 2024-02-27 04:41:11 --> Loader Class Initialized
INFO - 2024-02-27 04:41:11 --> Helper loaded: url_helper
INFO - 2024-02-27 04:41:11 --> Helper loaded: file_helper
INFO - 2024-02-27 04:41:11 --> Helper loaded: html_helper
INFO - 2024-02-27 04:41:11 --> Helper loaded: text_helper
INFO - 2024-02-27 04:41:11 --> Helper loaded: form_helper
INFO - 2024-02-27 04:41:11 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:41:11 --> Helper loaded: security_helper
INFO - 2024-02-27 04:41:11 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:41:11 --> Database Driver Class Initialized
INFO - 2024-02-27 04:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:41:11 --> Parser Class Initialized
INFO - 2024-02-27 04:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:41:11 --> Pagination Class Initialized
INFO - 2024-02-27 04:41:11 --> Form Validation Class Initialized
INFO - 2024-02-27 04:41:11 --> Controller Class Initialized
INFO - 2024-02-27 04:41:11 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:11 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:11 --> Model Class Initialized
INFO - 2024-02-27 04:41:11 --> Final output sent to browser
DEBUG - 2024-02-27 04:41:11 --> Total execution time: 0.0307
ERROR - 2024-02-27 04:41:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:41:14 --> Config Class Initialized
INFO - 2024-02-27 04:41:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:41:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:41:14 --> Utf8 Class Initialized
INFO - 2024-02-27 04:41:14 --> URI Class Initialized
INFO - 2024-02-27 04:41:14 --> Router Class Initialized
INFO - 2024-02-27 04:41:14 --> Output Class Initialized
INFO - 2024-02-27 04:41:14 --> Security Class Initialized
DEBUG - 2024-02-27 04:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:41:14 --> Input Class Initialized
INFO - 2024-02-27 04:41:14 --> Language Class Initialized
INFO - 2024-02-27 04:41:14 --> Loader Class Initialized
INFO - 2024-02-27 04:41:14 --> Helper loaded: url_helper
INFO - 2024-02-27 04:41:14 --> Helper loaded: file_helper
INFO - 2024-02-27 04:41:14 --> Helper loaded: html_helper
INFO - 2024-02-27 04:41:14 --> Helper loaded: text_helper
INFO - 2024-02-27 04:41:14 --> Helper loaded: form_helper
INFO - 2024-02-27 04:41:14 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:41:14 --> Helper loaded: security_helper
INFO - 2024-02-27 04:41:14 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:41:14 --> Database Driver Class Initialized
INFO - 2024-02-27 04:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:41:14 --> Parser Class Initialized
INFO - 2024-02-27 04:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:41:14 --> Pagination Class Initialized
INFO - 2024-02-27 04:41:14 --> Form Validation Class Initialized
INFO - 2024-02-27 04:41:14 --> Controller Class Initialized
INFO - 2024-02-27 04:41:14 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:14 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:14 --> Model Class Initialized
INFO - 2024-02-27 04:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2024-02-27 04:41:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:41:14 --> Model Class Initialized
INFO - 2024-02-27 04:41:14 --> Model Class Initialized
INFO - 2024-02-27 04:41:14 --> Model Class Initialized
INFO - 2024-02-27 04:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:41:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:41:14 --> Final output sent to browser
DEBUG - 2024-02-27 04:41:14 --> Total execution time: 0.1592
ERROR - 2024-02-27 04:41:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:41:22 --> Config Class Initialized
INFO - 2024-02-27 04:41:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:41:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:41:22 --> Utf8 Class Initialized
INFO - 2024-02-27 04:41:22 --> URI Class Initialized
INFO - 2024-02-27 04:41:22 --> Router Class Initialized
INFO - 2024-02-27 04:41:22 --> Output Class Initialized
INFO - 2024-02-27 04:41:22 --> Security Class Initialized
DEBUG - 2024-02-27 04:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:41:22 --> Input Class Initialized
INFO - 2024-02-27 04:41:22 --> Language Class Initialized
INFO - 2024-02-27 04:41:22 --> Loader Class Initialized
INFO - 2024-02-27 04:41:22 --> Helper loaded: url_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: file_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: html_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: text_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: form_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: security_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:41:22 --> Database Driver Class Initialized
INFO - 2024-02-27 04:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:41:22 --> Parser Class Initialized
INFO - 2024-02-27 04:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:41:22 --> Pagination Class Initialized
INFO - 2024-02-27 04:41:22 --> Form Validation Class Initialized
INFO - 2024-02-27 04:41:22 --> Controller Class Initialized
INFO - 2024-02-27 04:41:22 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:22 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:22 --> Model Class Initialized
INFO - 2024-02-27 04:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-02-27 04:41:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:41:22 --> Model Class Initialized
INFO - 2024-02-27 04:41:22 --> Model Class Initialized
INFO - 2024-02-27 04:41:22 --> Model Class Initialized
INFO - 2024-02-27 04:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:41:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:41:22 --> Final output sent to browser
DEBUG - 2024-02-27 04:41:22 --> Total execution time: 0.1553
ERROR - 2024-02-27 04:41:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:41:22 --> Config Class Initialized
INFO - 2024-02-27 04:41:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:41:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:41:22 --> Utf8 Class Initialized
INFO - 2024-02-27 04:41:22 --> URI Class Initialized
INFO - 2024-02-27 04:41:22 --> Router Class Initialized
INFO - 2024-02-27 04:41:22 --> Output Class Initialized
INFO - 2024-02-27 04:41:22 --> Security Class Initialized
DEBUG - 2024-02-27 04:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:41:22 --> Input Class Initialized
INFO - 2024-02-27 04:41:22 --> Language Class Initialized
INFO - 2024-02-27 04:41:22 --> Loader Class Initialized
INFO - 2024-02-27 04:41:22 --> Helper loaded: url_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: file_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: html_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: text_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: form_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: security_helper
INFO - 2024-02-27 04:41:22 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:41:22 --> Database Driver Class Initialized
INFO - 2024-02-27 04:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:41:22 --> Parser Class Initialized
INFO - 2024-02-27 04:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:41:22 --> Pagination Class Initialized
INFO - 2024-02-27 04:41:22 --> Form Validation Class Initialized
INFO - 2024-02-27 04:41:22 --> Controller Class Initialized
INFO - 2024-02-27 04:41:22 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:22 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:22 --> Model Class Initialized
INFO - 2024-02-27 04:41:22 --> Final output sent to browser
DEBUG - 2024-02-27 04:41:22 --> Total execution time: 0.0258
ERROR - 2024-02-27 04:41:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:41:27 --> Config Class Initialized
INFO - 2024-02-27 04:41:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:41:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:41:27 --> Utf8 Class Initialized
INFO - 2024-02-27 04:41:27 --> URI Class Initialized
DEBUG - 2024-02-27 04:41:27 --> No URI present. Default controller set.
INFO - 2024-02-27 04:41:27 --> Router Class Initialized
INFO - 2024-02-27 04:41:27 --> Output Class Initialized
INFO - 2024-02-27 04:41:27 --> Security Class Initialized
DEBUG - 2024-02-27 04:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:41:27 --> Input Class Initialized
INFO - 2024-02-27 04:41:27 --> Language Class Initialized
INFO - 2024-02-27 04:41:27 --> Loader Class Initialized
INFO - 2024-02-27 04:41:27 --> Helper loaded: url_helper
INFO - 2024-02-27 04:41:27 --> Helper loaded: file_helper
INFO - 2024-02-27 04:41:27 --> Helper loaded: html_helper
INFO - 2024-02-27 04:41:27 --> Helper loaded: text_helper
INFO - 2024-02-27 04:41:27 --> Helper loaded: form_helper
INFO - 2024-02-27 04:41:27 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:41:27 --> Helper loaded: security_helper
INFO - 2024-02-27 04:41:27 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:41:27 --> Database Driver Class Initialized
INFO - 2024-02-27 04:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:41:27 --> Parser Class Initialized
INFO - 2024-02-27 04:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:41:27 --> Pagination Class Initialized
INFO - 2024-02-27 04:41:27 --> Form Validation Class Initialized
INFO - 2024-02-27 04:41:27 --> Controller Class Initialized
INFO - 2024-02-27 04:41:27 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:27 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:27 --> Model Class Initialized
INFO - 2024-02-27 04:41:27 --> Model Class Initialized
INFO - 2024-02-27 04:41:27 --> Model Class Initialized
INFO - 2024-02-27 04:41:27 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:27 --> Model Class Initialized
INFO - 2024-02-27 04:41:27 --> Model Class Initialized
INFO - 2024-02-27 04:41:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 04:41:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:41:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:41:27 --> Model Class Initialized
INFO - 2024-02-27 04:41:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:41:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:41:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:41:27 --> Final output sent to browser
DEBUG - 2024-02-27 04:41:27 --> Total execution time: 0.2410
ERROR - 2024-02-27 04:41:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:41:32 --> Config Class Initialized
INFO - 2024-02-27 04:41:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:41:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:41:32 --> Utf8 Class Initialized
INFO - 2024-02-27 04:41:32 --> URI Class Initialized
INFO - 2024-02-27 04:41:32 --> Router Class Initialized
INFO - 2024-02-27 04:41:32 --> Output Class Initialized
INFO - 2024-02-27 04:41:32 --> Security Class Initialized
DEBUG - 2024-02-27 04:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:41:32 --> Input Class Initialized
INFO - 2024-02-27 04:41:32 --> Language Class Initialized
INFO - 2024-02-27 04:41:32 --> Loader Class Initialized
INFO - 2024-02-27 04:41:32 --> Helper loaded: url_helper
INFO - 2024-02-27 04:41:32 --> Helper loaded: file_helper
INFO - 2024-02-27 04:41:32 --> Helper loaded: html_helper
INFO - 2024-02-27 04:41:32 --> Helper loaded: text_helper
INFO - 2024-02-27 04:41:32 --> Helper loaded: form_helper
INFO - 2024-02-27 04:41:32 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:41:32 --> Helper loaded: security_helper
INFO - 2024-02-27 04:41:32 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:41:32 --> Database Driver Class Initialized
INFO - 2024-02-27 04:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:41:32 --> Parser Class Initialized
INFO - 2024-02-27 04:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:41:32 --> Pagination Class Initialized
INFO - 2024-02-27 04:41:32 --> Form Validation Class Initialized
INFO - 2024-02-27 04:41:32 --> Controller Class Initialized
INFO - 2024-02-27 04:41:32 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:32 --> Model Class Initialized
INFO - 2024-02-27 04:41:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-02-27 04:41:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 04:41:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 04:41:32 --> Model Class Initialized
INFO - 2024-02-27 04:41:32 --> Model Class Initialized
INFO - 2024-02-27 04:41:32 --> Model Class Initialized
INFO - 2024-02-27 04:41:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 04:41:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 04:41:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 04:41:32 --> Final output sent to browser
DEBUG - 2024-02-27 04:41:32 --> Total execution time: 0.1474
ERROR - 2024-02-27 04:41:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:41:33 --> Config Class Initialized
INFO - 2024-02-27 04:41:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:41:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:41:33 --> Utf8 Class Initialized
INFO - 2024-02-27 04:41:33 --> URI Class Initialized
INFO - 2024-02-27 04:41:33 --> Router Class Initialized
INFO - 2024-02-27 04:41:33 --> Output Class Initialized
INFO - 2024-02-27 04:41:33 --> Security Class Initialized
DEBUG - 2024-02-27 04:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:41:33 --> Input Class Initialized
INFO - 2024-02-27 04:41:33 --> Language Class Initialized
INFO - 2024-02-27 04:41:33 --> Loader Class Initialized
INFO - 2024-02-27 04:41:33 --> Helper loaded: url_helper
INFO - 2024-02-27 04:41:33 --> Helper loaded: file_helper
INFO - 2024-02-27 04:41:33 --> Helper loaded: html_helper
INFO - 2024-02-27 04:41:33 --> Helper loaded: text_helper
INFO - 2024-02-27 04:41:33 --> Helper loaded: form_helper
INFO - 2024-02-27 04:41:33 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:41:33 --> Helper loaded: security_helper
INFO - 2024-02-27 04:41:33 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:41:33 --> Database Driver Class Initialized
INFO - 2024-02-27 04:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:41:33 --> Parser Class Initialized
INFO - 2024-02-27 04:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:41:33 --> Pagination Class Initialized
INFO - 2024-02-27 04:41:33 --> Form Validation Class Initialized
INFO - 2024-02-27 04:41:33 --> Controller Class Initialized
INFO - 2024-02-27 04:41:33 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:33 --> Model Class Initialized
INFO - 2024-02-27 04:41:33 --> Final output sent to browser
DEBUG - 2024-02-27 04:41:33 --> Total execution time: 0.2146
ERROR - 2024-02-27 04:41:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 04:41:52 --> Config Class Initialized
INFO - 2024-02-27 04:41:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 04:41:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 04:41:52 --> Utf8 Class Initialized
INFO - 2024-02-27 04:41:52 --> URI Class Initialized
INFO - 2024-02-27 04:41:52 --> Router Class Initialized
INFO - 2024-02-27 04:41:52 --> Output Class Initialized
INFO - 2024-02-27 04:41:52 --> Security Class Initialized
DEBUG - 2024-02-27 04:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 04:41:52 --> Input Class Initialized
INFO - 2024-02-27 04:41:52 --> Language Class Initialized
INFO - 2024-02-27 04:41:52 --> Loader Class Initialized
INFO - 2024-02-27 04:41:52 --> Helper loaded: url_helper
INFO - 2024-02-27 04:41:52 --> Helper loaded: file_helper
INFO - 2024-02-27 04:41:52 --> Helper loaded: html_helper
INFO - 2024-02-27 04:41:52 --> Helper loaded: text_helper
INFO - 2024-02-27 04:41:52 --> Helper loaded: form_helper
INFO - 2024-02-27 04:41:52 --> Helper loaded: lang_helper
INFO - 2024-02-27 04:41:52 --> Helper loaded: security_helper
INFO - 2024-02-27 04:41:52 --> Helper loaded: cookie_helper
INFO - 2024-02-27 04:41:52 --> Database Driver Class Initialized
INFO - 2024-02-27 04:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 04:41:52 --> Parser Class Initialized
INFO - 2024-02-27 04:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 04:41:52 --> Pagination Class Initialized
INFO - 2024-02-27 04:41:52 --> Form Validation Class Initialized
INFO - 2024-02-27 04:41:52 --> Controller Class Initialized
INFO - 2024-02-27 04:41:52 --> Model Class Initialized
DEBUG - 2024-02-27 04:41:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 04:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 04:41:52 --> Model Class Initialized
INFO - 2024-02-27 04:41:52 --> Final output sent to browser
DEBUG - 2024-02-27 04:41:52 --> Total execution time: 0.2247
ERROR - 2024-02-27 05:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:15:26 --> Config Class Initialized
INFO - 2024-02-27 05:15:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:15:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:15:26 --> Utf8 Class Initialized
INFO - 2024-02-27 05:15:26 --> URI Class Initialized
DEBUG - 2024-02-27 05:15:26 --> No URI present. Default controller set.
INFO - 2024-02-27 05:15:26 --> Router Class Initialized
INFO - 2024-02-27 05:15:26 --> Output Class Initialized
INFO - 2024-02-27 05:15:26 --> Security Class Initialized
DEBUG - 2024-02-27 05:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:15:26 --> Input Class Initialized
INFO - 2024-02-27 05:15:26 --> Language Class Initialized
INFO - 2024-02-27 05:15:26 --> Loader Class Initialized
INFO - 2024-02-27 05:15:26 --> Helper loaded: url_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: file_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: html_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: text_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: form_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: security_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:15:26 --> Database Driver Class Initialized
INFO - 2024-02-27 05:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:15:26 --> Parser Class Initialized
INFO - 2024-02-27 05:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:15:26 --> Pagination Class Initialized
INFO - 2024-02-27 05:15:26 --> Form Validation Class Initialized
INFO - 2024-02-27 05:15:26 --> Controller Class Initialized
INFO - 2024-02-27 05:15:26 --> Model Class Initialized
DEBUG - 2024-02-27 05:15:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 05:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:15:26 --> Config Class Initialized
INFO - 2024-02-27 05:15:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:15:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:15:26 --> Utf8 Class Initialized
INFO - 2024-02-27 05:15:26 --> URI Class Initialized
INFO - 2024-02-27 05:15:26 --> Router Class Initialized
INFO - 2024-02-27 05:15:26 --> Output Class Initialized
INFO - 2024-02-27 05:15:26 --> Security Class Initialized
DEBUG - 2024-02-27 05:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:15:26 --> Input Class Initialized
INFO - 2024-02-27 05:15:26 --> Language Class Initialized
INFO - 2024-02-27 05:15:26 --> Loader Class Initialized
INFO - 2024-02-27 05:15:26 --> Helper loaded: url_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: file_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: html_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: text_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: form_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: security_helper
INFO - 2024-02-27 05:15:26 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:15:26 --> Database Driver Class Initialized
INFO - 2024-02-27 05:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:15:26 --> Parser Class Initialized
INFO - 2024-02-27 05:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:15:26 --> Pagination Class Initialized
INFO - 2024-02-27 05:15:26 --> Form Validation Class Initialized
INFO - 2024-02-27 05:15:26 --> Controller Class Initialized
INFO - 2024-02-27 05:15:26 --> Model Class Initialized
DEBUG - 2024-02-27 05:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 05:15:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:15:26 --> Model Class Initialized
INFO - 2024-02-27 05:15:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:15:26 --> Final output sent to browser
DEBUG - 2024-02-27 05:15:26 --> Total execution time: 0.0286
ERROR - 2024-02-27 05:15:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:15:39 --> Config Class Initialized
INFO - 2024-02-27 05:15:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:15:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:15:39 --> Utf8 Class Initialized
INFO - 2024-02-27 05:15:39 --> URI Class Initialized
INFO - 2024-02-27 05:15:39 --> Router Class Initialized
INFO - 2024-02-27 05:15:39 --> Output Class Initialized
INFO - 2024-02-27 05:15:39 --> Security Class Initialized
DEBUG - 2024-02-27 05:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:15:39 --> Input Class Initialized
INFO - 2024-02-27 05:15:39 --> Language Class Initialized
INFO - 2024-02-27 05:15:39 --> Loader Class Initialized
INFO - 2024-02-27 05:15:39 --> Helper loaded: url_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: file_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: html_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: text_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: form_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: security_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:15:39 --> Database Driver Class Initialized
INFO - 2024-02-27 05:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:15:39 --> Parser Class Initialized
INFO - 2024-02-27 05:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:15:39 --> Pagination Class Initialized
INFO - 2024-02-27 05:15:39 --> Form Validation Class Initialized
INFO - 2024-02-27 05:15:39 --> Controller Class Initialized
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
DEBUG - 2024-02-27 05:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
INFO - 2024-02-27 05:15:39 --> Final output sent to browser
DEBUG - 2024-02-27 05:15:39 --> Total execution time: 0.0203
ERROR - 2024-02-27 05:15:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:15:39 --> Config Class Initialized
INFO - 2024-02-27 05:15:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:15:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:15:39 --> Utf8 Class Initialized
INFO - 2024-02-27 05:15:39 --> URI Class Initialized
DEBUG - 2024-02-27 05:15:39 --> No URI present. Default controller set.
INFO - 2024-02-27 05:15:39 --> Router Class Initialized
INFO - 2024-02-27 05:15:39 --> Output Class Initialized
INFO - 2024-02-27 05:15:39 --> Security Class Initialized
DEBUG - 2024-02-27 05:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:15:39 --> Input Class Initialized
INFO - 2024-02-27 05:15:39 --> Language Class Initialized
INFO - 2024-02-27 05:15:39 --> Loader Class Initialized
INFO - 2024-02-27 05:15:39 --> Helper loaded: url_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: file_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: html_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: text_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: form_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: security_helper
INFO - 2024-02-27 05:15:39 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:15:39 --> Database Driver Class Initialized
INFO - 2024-02-27 05:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:15:39 --> Parser Class Initialized
INFO - 2024-02-27 05:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:15:39 --> Pagination Class Initialized
INFO - 2024-02-27 05:15:39 --> Form Validation Class Initialized
INFO - 2024-02-27 05:15:39 --> Controller Class Initialized
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
DEBUG - 2024-02-27 05:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
DEBUG - 2024-02-27 05:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
DEBUG - 2024-02-27 05:15:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
INFO - 2024-02-27 05:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 05:15:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:15:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:15:39 --> Model Class Initialized
INFO - 2024-02-27 05:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:15:40 --> Final output sent to browser
DEBUG - 2024-02-27 05:15:40 --> Total execution time: 0.4230
ERROR - 2024-02-27 05:15:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:15:41 --> Config Class Initialized
INFO - 2024-02-27 05:15:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:15:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:15:41 --> Utf8 Class Initialized
INFO - 2024-02-27 05:15:41 --> URI Class Initialized
INFO - 2024-02-27 05:15:41 --> Router Class Initialized
INFO - 2024-02-27 05:15:41 --> Output Class Initialized
INFO - 2024-02-27 05:15:41 --> Security Class Initialized
DEBUG - 2024-02-27 05:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:15:41 --> Input Class Initialized
INFO - 2024-02-27 05:15:41 --> Language Class Initialized
INFO - 2024-02-27 05:15:41 --> Loader Class Initialized
INFO - 2024-02-27 05:15:41 --> Helper loaded: url_helper
INFO - 2024-02-27 05:15:41 --> Helper loaded: file_helper
INFO - 2024-02-27 05:15:41 --> Helper loaded: html_helper
INFO - 2024-02-27 05:15:41 --> Helper loaded: text_helper
INFO - 2024-02-27 05:15:41 --> Helper loaded: form_helper
INFO - 2024-02-27 05:15:41 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:15:41 --> Helper loaded: security_helper
INFO - 2024-02-27 05:15:41 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:15:41 --> Database Driver Class Initialized
INFO - 2024-02-27 05:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:15:41 --> Parser Class Initialized
INFO - 2024-02-27 05:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:15:41 --> Pagination Class Initialized
INFO - 2024-02-27 05:15:41 --> Form Validation Class Initialized
INFO - 2024-02-27 05:15:41 --> Controller Class Initialized
DEBUG - 2024-02-27 05:15:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:41 --> Model Class Initialized
INFO - 2024-02-27 05:15:41 --> Final output sent to browser
DEBUG - 2024-02-27 05:15:41 --> Total execution time: 0.0169
ERROR - 2024-02-27 05:15:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:15:54 --> Config Class Initialized
INFO - 2024-02-27 05:15:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:15:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:15:54 --> Utf8 Class Initialized
INFO - 2024-02-27 05:15:54 --> URI Class Initialized
INFO - 2024-02-27 05:15:54 --> Router Class Initialized
INFO - 2024-02-27 05:15:54 --> Output Class Initialized
INFO - 2024-02-27 05:15:54 --> Security Class Initialized
DEBUG - 2024-02-27 05:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:15:54 --> Input Class Initialized
INFO - 2024-02-27 05:15:54 --> Language Class Initialized
INFO - 2024-02-27 05:15:54 --> Loader Class Initialized
INFO - 2024-02-27 05:15:54 --> Helper loaded: url_helper
INFO - 2024-02-27 05:15:54 --> Helper loaded: file_helper
INFO - 2024-02-27 05:15:54 --> Helper loaded: html_helper
INFO - 2024-02-27 05:15:54 --> Helper loaded: text_helper
INFO - 2024-02-27 05:15:54 --> Helper loaded: form_helper
INFO - 2024-02-27 05:15:54 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:15:54 --> Helper loaded: security_helper
INFO - 2024-02-27 05:15:54 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:15:54 --> Database Driver Class Initialized
INFO - 2024-02-27 05:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:15:54 --> Parser Class Initialized
INFO - 2024-02-27 05:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:15:54 --> Pagination Class Initialized
INFO - 2024-02-27 05:15:54 --> Form Validation Class Initialized
INFO - 2024-02-27 05:15:54 --> Controller Class Initialized
DEBUG - 2024-02-27 05:15:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:54 --> Model Class Initialized
DEBUG - 2024-02-27 05:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:54 --> Model Class Initialized
DEBUG - 2024-02-27 05:15:54 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:54 --> Model Class Initialized
INFO - 2024-02-27 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-27 05:15:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:15:54 --> Model Class Initialized
INFO - 2024-02-27 05:15:54 --> Model Class Initialized
INFO - 2024-02-27 05:15:54 --> Model Class Initialized
INFO - 2024-02-27 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:15:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:15:54 --> Final output sent to browser
DEBUG - 2024-02-27 05:15:54 --> Total execution time: 0.2274
ERROR - 2024-02-27 05:15:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:15:55 --> Config Class Initialized
INFO - 2024-02-27 05:15:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:15:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:15:55 --> Utf8 Class Initialized
INFO - 2024-02-27 05:15:55 --> URI Class Initialized
INFO - 2024-02-27 05:15:55 --> Router Class Initialized
INFO - 2024-02-27 05:15:55 --> Output Class Initialized
INFO - 2024-02-27 05:15:55 --> Security Class Initialized
DEBUG - 2024-02-27 05:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:15:55 --> Input Class Initialized
INFO - 2024-02-27 05:15:55 --> Language Class Initialized
INFO - 2024-02-27 05:15:55 --> Loader Class Initialized
INFO - 2024-02-27 05:15:55 --> Helper loaded: url_helper
INFO - 2024-02-27 05:15:55 --> Helper loaded: file_helper
INFO - 2024-02-27 05:15:55 --> Helper loaded: html_helper
INFO - 2024-02-27 05:15:55 --> Helper loaded: text_helper
INFO - 2024-02-27 05:15:55 --> Helper loaded: form_helper
INFO - 2024-02-27 05:15:55 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:15:55 --> Helper loaded: security_helper
INFO - 2024-02-27 05:15:55 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:15:55 --> Database Driver Class Initialized
INFO - 2024-02-27 05:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:15:55 --> Parser Class Initialized
INFO - 2024-02-27 05:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:15:55 --> Pagination Class Initialized
INFO - 2024-02-27 05:15:55 --> Form Validation Class Initialized
INFO - 2024-02-27 05:15:55 --> Controller Class Initialized
DEBUG - 2024-02-27 05:15:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:55 --> Model Class Initialized
DEBUG - 2024-02-27 05:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:15:55 --> Model Class Initialized
INFO - 2024-02-27 05:15:55 --> Final output sent to browser
DEBUG - 2024-02-27 05:15:55 --> Total execution time: 0.0371
ERROR - 2024-02-27 05:16:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:16:03 --> Config Class Initialized
INFO - 2024-02-27 05:16:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:16:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:16:03 --> Utf8 Class Initialized
INFO - 2024-02-27 05:16:03 --> URI Class Initialized
INFO - 2024-02-27 05:16:03 --> Router Class Initialized
INFO - 2024-02-27 05:16:03 --> Output Class Initialized
INFO - 2024-02-27 05:16:03 --> Security Class Initialized
DEBUG - 2024-02-27 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:16:03 --> Input Class Initialized
INFO - 2024-02-27 05:16:03 --> Language Class Initialized
INFO - 2024-02-27 05:16:03 --> Loader Class Initialized
INFO - 2024-02-27 05:16:03 --> Helper loaded: url_helper
INFO - 2024-02-27 05:16:03 --> Helper loaded: file_helper
INFO - 2024-02-27 05:16:03 --> Helper loaded: html_helper
INFO - 2024-02-27 05:16:03 --> Helper loaded: text_helper
INFO - 2024-02-27 05:16:03 --> Helper loaded: form_helper
INFO - 2024-02-27 05:16:03 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:16:03 --> Helper loaded: security_helper
INFO - 2024-02-27 05:16:03 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:16:03 --> Database Driver Class Initialized
INFO - 2024-02-27 05:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:16:03 --> Parser Class Initialized
INFO - 2024-02-27 05:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:16:03 --> Pagination Class Initialized
INFO - 2024-02-27 05:16:03 --> Form Validation Class Initialized
INFO - 2024-02-27 05:16:03 --> Controller Class Initialized
INFO - 2024-02-27 05:16:03 --> Model Class Initialized
DEBUG - 2024-02-27 05:16:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:16:03 --> Model Class Initialized
DEBUG - 2024-02-27 05:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:16:03 --> Model Class Initialized
INFO - 2024-02-27 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-27 05:16:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:16:03 --> Model Class Initialized
INFO - 2024-02-27 05:16:03 --> Model Class Initialized
INFO - 2024-02-27 05:16:03 --> Model Class Initialized
INFO - 2024-02-27 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:16:03 --> Final output sent to browser
DEBUG - 2024-02-27 05:16:03 --> Total execution time: 0.2351
ERROR - 2024-02-27 05:16:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:16:05 --> Config Class Initialized
INFO - 2024-02-27 05:16:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:16:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:16:05 --> Utf8 Class Initialized
INFO - 2024-02-27 05:16:05 --> URI Class Initialized
INFO - 2024-02-27 05:16:05 --> Router Class Initialized
INFO - 2024-02-27 05:16:05 --> Output Class Initialized
INFO - 2024-02-27 05:16:05 --> Security Class Initialized
DEBUG - 2024-02-27 05:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:16:05 --> Input Class Initialized
INFO - 2024-02-27 05:16:05 --> Language Class Initialized
INFO - 2024-02-27 05:16:05 --> Loader Class Initialized
INFO - 2024-02-27 05:16:05 --> Helper loaded: url_helper
INFO - 2024-02-27 05:16:05 --> Helper loaded: file_helper
INFO - 2024-02-27 05:16:05 --> Helper loaded: html_helper
INFO - 2024-02-27 05:16:05 --> Helper loaded: text_helper
INFO - 2024-02-27 05:16:05 --> Helper loaded: form_helper
INFO - 2024-02-27 05:16:05 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:16:05 --> Helper loaded: security_helper
INFO - 2024-02-27 05:16:05 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:16:05 --> Database Driver Class Initialized
INFO - 2024-02-27 05:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:16:05 --> Parser Class Initialized
INFO - 2024-02-27 05:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:16:05 --> Pagination Class Initialized
INFO - 2024-02-27 05:16:05 --> Form Validation Class Initialized
INFO - 2024-02-27 05:16:05 --> Controller Class Initialized
INFO - 2024-02-27 05:16:05 --> Model Class Initialized
DEBUG - 2024-02-27 05:16:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:16:05 --> Model Class Initialized
DEBUG - 2024-02-27 05:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:16:05 --> Model Class Initialized
INFO - 2024-02-27 05:16:05 --> Final output sent to browser
DEBUG - 2024-02-27 05:16:05 --> Total execution time: 0.0612
ERROR - 2024-02-27 05:35:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:35:37 --> Config Class Initialized
INFO - 2024-02-27 05:35:37 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:35:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:35:37 --> Utf8 Class Initialized
INFO - 2024-02-27 05:35:37 --> URI Class Initialized
INFO - 2024-02-27 05:35:37 --> Router Class Initialized
INFO - 2024-02-27 05:35:37 --> Output Class Initialized
INFO - 2024-02-27 05:35:37 --> Security Class Initialized
DEBUG - 2024-02-27 05:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:35:37 --> Input Class Initialized
INFO - 2024-02-27 05:35:37 --> Language Class Initialized
INFO - 2024-02-27 05:35:37 --> Loader Class Initialized
INFO - 2024-02-27 05:35:37 --> Helper loaded: url_helper
INFO - 2024-02-27 05:35:37 --> Helper loaded: file_helper
INFO - 2024-02-27 05:35:37 --> Helper loaded: html_helper
INFO - 2024-02-27 05:35:37 --> Helper loaded: text_helper
INFO - 2024-02-27 05:35:37 --> Helper loaded: form_helper
INFO - 2024-02-27 05:35:37 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:35:37 --> Helper loaded: security_helper
INFO - 2024-02-27 05:35:37 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:35:37 --> Database Driver Class Initialized
INFO - 2024-02-27 05:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:35:37 --> Parser Class Initialized
INFO - 2024-02-27 05:35:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:35:37 --> Pagination Class Initialized
INFO - 2024-02-27 05:35:37 --> Form Validation Class Initialized
INFO - 2024-02-27 05:35:37 --> Controller Class Initialized
INFO - 2024-02-27 05:35:37 --> Model Class Initialized
DEBUG - 2024-02-27 05:35:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:37 --> Model Class Initialized
DEBUG - 2024-02-27 05:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:37 --> Model Class Initialized
DEBUG - 2024-02-27 05:35:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:37 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-27 05:35:37 --> Final output sent to browser
DEBUG - 2024-02-27 05:35:37 --> Total execution time: 0.1860
ERROR - 2024-02-27 05:35:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:35:40 --> Config Class Initialized
INFO - 2024-02-27 05:35:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:35:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:35:40 --> Utf8 Class Initialized
INFO - 2024-02-27 05:35:40 --> URI Class Initialized
INFO - 2024-02-27 05:35:40 --> Router Class Initialized
INFO - 2024-02-27 05:35:40 --> Output Class Initialized
INFO - 2024-02-27 05:35:40 --> Security Class Initialized
DEBUG - 2024-02-27 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:35:40 --> Input Class Initialized
INFO - 2024-02-27 05:35:40 --> Language Class Initialized
INFO - 2024-02-27 05:35:40 --> Loader Class Initialized
INFO - 2024-02-27 05:35:40 --> Helper loaded: url_helper
INFO - 2024-02-27 05:35:40 --> Helper loaded: file_helper
INFO - 2024-02-27 05:35:40 --> Helper loaded: html_helper
INFO - 2024-02-27 05:35:40 --> Helper loaded: text_helper
INFO - 2024-02-27 05:35:40 --> Helper loaded: form_helper
INFO - 2024-02-27 05:35:40 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:35:40 --> Helper loaded: security_helper
INFO - 2024-02-27 05:35:40 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:35:40 --> Database Driver Class Initialized
INFO - 2024-02-27 05:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:35:40 --> Parser Class Initialized
INFO - 2024-02-27 05:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:35:40 --> Pagination Class Initialized
INFO - 2024-02-27 05:35:40 --> Form Validation Class Initialized
INFO - 2024-02-27 05:35:40 --> Controller Class Initialized
INFO - 2024-02-27 05:35:40 --> Model Class Initialized
DEBUG - 2024-02-27 05:35:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:40 --> Model Class Initialized
DEBUG - 2024-02-27 05:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:40 --> Model Class Initialized
DEBUG - 2024-02-27 05:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 05:35:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-27 05:35:40 --> Final output sent to browser
DEBUG - 2024-02-27 05:35:40 --> Total execution time: 0.1775
ERROR - 2024-02-27 05:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:35:42 --> Config Class Initialized
INFO - 2024-02-27 05:35:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:35:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:35:42 --> Utf8 Class Initialized
INFO - 2024-02-27 05:35:42 --> URI Class Initialized
INFO - 2024-02-27 05:35:42 --> Router Class Initialized
INFO - 2024-02-27 05:35:42 --> Output Class Initialized
INFO - 2024-02-27 05:35:42 --> Security Class Initialized
DEBUG - 2024-02-27 05:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:35:42 --> Input Class Initialized
INFO - 2024-02-27 05:35:42 --> Language Class Initialized
INFO - 2024-02-27 05:35:42 --> Loader Class Initialized
INFO - 2024-02-27 05:35:42 --> Helper loaded: url_helper
INFO - 2024-02-27 05:35:42 --> Helper loaded: file_helper
INFO - 2024-02-27 05:35:42 --> Helper loaded: html_helper
INFO - 2024-02-27 05:35:42 --> Helper loaded: text_helper
INFO - 2024-02-27 05:35:42 --> Helper loaded: form_helper
INFO - 2024-02-27 05:35:42 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:35:42 --> Helper loaded: security_helper
INFO - 2024-02-27 05:35:42 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:35:42 --> Database Driver Class Initialized
INFO - 2024-02-27 05:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:35:42 --> Parser Class Initialized
INFO - 2024-02-27 05:35:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:35:42 --> Pagination Class Initialized
INFO - 2024-02-27 05:35:42 --> Form Validation Class Initialized
INFO - 2024-02-27 05:35:42 --> Controller Class Initialized
INFO - 2024-02-27 05:35:42 --> Model Class Initialized
DEBUG - 2024-02-27 05:35:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:42 --> Model Class Initialized
DEBUG - 2024-02-27 05:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:42 --> Model Class Initialized
DEBUG - 2024-02-27 05:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-27 05:35:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:35:42 --> Model Class Initialized
INFO - 2024-02-27 05:35:42 --> Model Class Initialized
INFO - 2024-02-27 05:35:42 --> Model Class Initialized
INFO - 2024-02-27 05:35:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:35:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:35:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:35:43 --> Final output sent to browser
DEBUG - 2024-02-27 05:35:43 --> Total execution time: 0.2523
ERROR - 2024-02-27 05:39:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:39:15 --> Config Class Initialized
INFO - 2024-02-27 05:39:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:39:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:39:15 --> Utf8 Class Initialized
INFO - 2024-02-27 05:39:15 --> URI Class Initialized
DEBUG - 2024-02-27 05:39:15 --> No URI present. Default controller set.
INFO - 2024-02-27 05:39:15 --> Router Class Initialized
INFO - 2024-02-27 05:39:15 --> Output Class Initialized
INFO - 2024-02-27 05:39:15 --> Security Class Initialized
DEBUG - 2024-02-27 05:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:39:15 --> Input Class Initialized
INFO - 2024-02-27 05:39:15 --> Language Class Initialized
INFO - 2024-02-27 05:39:15 --> Loader Class Initialized
INFO - 2024-02-27 05:39:15 --> Helper loaded: url_helper
INFO - 2024-02-27 05:39:15 --> Helper loaded: file_helper
INFO - 2024-02-27 05:39:15 --> Helper loaded: html_helper
INFO - 2024-02-27 05:39:15 --> Helper loaded: text_helper
INFO - 2024-02-27 05:39:15 --> Helper loaded: form_helper
INFO - 2024-02-27 05:39:15 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:39:15 --> Helper loaded: security_helper
INFO - 2024-02-27 05:39:15 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:39:15 --> Database Driver Class Initialized
INFO - 2024-02-27 05:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:39:15 --> Parser Class Initialized
INFO - 2024-02-27 05:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:39:15 --> Pagination Class Initialized
INFO - 2024-02-27 05:39:15 --> Form Validation Class Initialized
INFO - 2024-02-27 05:39:15 --> Controller Class Initialized
INFO - 2024-02-27 05:39:15 --> Model Class Initialized
DEBUG - 2024-02-27 05:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:39:15 --> Model Class Initialized
DEBUG - 2024-02-27 05:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:39:15 --> Model Class Initialized
INFO - 2024-02-27 05:39:15 --> Model Class Initialized
INFO - 2024-02-27 05:39:15 --> Model Class Initialized
INFO - 2024-02-27 05:39:15 --> Model Class Initialized
DEBUG - 2024-02-27 05:39:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:39:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:39:15 --> Model Class Initialized
INFO - 2024-02-27 05:39:15 --> Model Class Initialized
INFO - 2024-02-27 05:39:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 05:39:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:39:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:39:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:39:15 --> Model Class Initialized
INFO - 2024-02-27 05:39:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:39:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:39:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:39:15 --> Final output sent to browser
DEBUG - 2024-02-27 05:39:15 --> Total execution time: 0.4311
ERROR - 2024-02-27 05:42:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:42:26 --> Config Class Initialized
INFO - 2024-02-27 05:42:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:42:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:42:26 --> Utf8 Class Initialized
INFO - 2024-02-27 05:42:26 --> URI Class Initialized
DEBUG - 2024-02-27 05:42:26 --> No URI present. Default controller set.
INFO - 2024-02-27 05:42:26 --> Router Class Initialized
INFO - 2024-02-27 05:42:26 --> Output Class Initialized
INFO - 2024-02-27 05:42:26 --> Security Class Initialized
DEBUG - 2024-02-27 05:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:42:26 --> Input Class Initialized
INFO - 2024-02-27 05:42:26 --> Language Class Initialized
INFO - 2024-02-27 05:42:26 --> Loader Class Initialized
INFO - 2024-02-27 05:42:26 --> Helper loaded: url_helper
INFO - 2024-02-27 05:42:26 --> Helper loaded: file_helper
INFO - 2024-02-27 05:42:26 --> Helper loaded: html_helper
INFO - 2024-02-27 05:42:26 --> Helper loaded: text_helper
INFO - 2024-02-27 05:42:26 --> Helper loaded: form_helper
INFO - 2024-02-27 05:42:26 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:42:26 --> Helper loaded: security_helper
INFO - 2024-02-27 05:42:26 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:42:26 --> Database Driver Class Initialized
INFO - 2024-02-27 05:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:42:26 --> Parser Class Initialized
INFO - 2024-02-27 05:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:42:26 --> Pagination Class Initialized
INFO - 2024-02-27 05:42:26 --> Form Validation Class Initialized
INFO - 2024-02-27 05:42:26 --> Controller Class Initialized
INFO - 2024-02-27 05:42:26 --> Model Class Initialized
DEBUG - 2024-02-27 05:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:26 --> Model Class Initialized
DEBUG - 2024-02-27 05:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:26 --> Model Class Initialized
INFO - 2024-02-27 05:42:26 --> Model Class Initialized
INFO - 2024-02-27 05:42:26 --> Model Class Initialized
INFO - 2024-02-27 05:42:26 --> Model Class Initialized
DEBUG - 2024-02-27 05:42:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:26 --> Model Class Initialized
INFO - 2024-02-27 05:42:26 --> Model Class Initialized
INFO - 2024-02-27 05:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 05:42:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:42:26 --> Model Class Initialized
INFO - 2024-02-27 05:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:42:26 --> Final output sent to browser
DEBUG - 2024-02-27 05:42:26 --> Total execution time: 0.4286
ERROR - 2024-02-27 05:42:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:42:40 --> Config Class Initialized
INFO - 2024-02-27 05:42:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:42:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:42:40 --> Utf8 Class Initialized
INFO - 2024-02-27 05:42:40 --> URI Class Initialized
INFO - 2024-02-27 05:42:40 --> Router Class Initialized
INFO - 2024-02-27 05:42:40 --> Output Class Initialized
INFO - 2024-02-27 05:42:40 --> Security Class Initialized
DEBUG - 2024-02-27 05:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:42:40 --> Input Class Initialized
INFO - 2024-02-27 05:42:40 --> Language Class Initialized
INFO - 2024-02-27 05:42:40 --> Loader Class Initialized
INFO - 2024-02-27 05:42:40 --> Helper loaded: url_helper
INFO - 2024-02-27 05:42:40 --> Helper loaded: file_helper
INFO - 2024-02-27 05:42:40 --> Helper loaded: html_helper
INFO - 2024-02-27 05:42:40 --> Helper loaded: text_helper
INFO - 2024-02-27 05:42:40 --> Helper loaded: form_helper
INFO - 2024-02-27 05:42:40 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:42:40 --> Helper loaded: security_helper
INFO - 2024-02-27 05:42:40 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:42:40 --> Database Driver Class Initialized
INFO - 2024-02-27 05:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:42:40 --> Parser Class Initialized
INFO - 2024-02-27 05:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:42:40 --> Pagination Class Initialized
INFO - 2024-02-27 05:42:40 --> Form Validation Class Initialized
INFO - 2024-02-27 05:42:40 --> Controller Class Initialized
DEBUG - 2024-02-27 05:42:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:40 --> Model Class Initialized
DEBUG - 2024-02-27 05:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:40 --> Model Class Initialized
DEBUG - 2024-02-27 05:42:40 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:40 --> Model Class Initialized
INFO - 2024-02-27 05:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-27 05:42:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:42:40 --> Model Class Initialized
INFO - 2024-02-27 05:42:40 --> Model Class Initialized
INFO - 2024-02-27 05:42:40 --> Model Class Initialized
INFO - 2024-02-27 05:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:42:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:42:40 --> Final output sent to browser
DEBUG - 2024-02-27 05:42:40 --> Total execution time: 0.2270
ERROR - 2024-02-27 05:42:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:42:42 --> Config Class Initialized
INFO - 2024-02-27 05:42:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:42:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:42:42 --> Utf8 Class Initialized
INFO - 2024-02-27 05:42:42 --> URI Class Initialized
INFO - 2024-02-27 05:42:42 --> Router Class Initialized
INFO - 2024-02-27 05:42:42 --> Output Class Initialized
INFO - 2024-02-27 05:42:42 --> Security Class Initialized
DEBUG - 2024-02-27 05:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:42:42 --> Input Class Initialized
INFO - 2024-02-27 05:42:42 --> Language Class Initialized
INFO - 2024-02-27 05:42:42 --> Loader Class Initialized
INFO - 2024-02-27 05:42:42 --> Helper loaded: url_helper
INFO - 2024-02-27 05:42:42 --> Helper loaded: file_helper
INFO - 2024-02-27 05:42:42 --> Helper loaded: html_helper
INFO - 2024-02-27 05:42:42 --> Helper loaded: text_helper
INFO - 2024-02-27 05:42:42 --> Helper loaded: form_helper
INFO - 2024-02-27 05:42:42 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:42:42 --> Helper loaded: security_helper
INFO - 2024-02-27 05:42:42 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:42:42 --> Database Driver Class Initialized
INFO - 2024-02-27 05:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:42:42 --> Parser Class Initialized
INFO - 2024-02-27 05:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:42:42 --> Pagination Class Initialized
INFO - 2024-02-27 05:42:42 --> Form Validation Class Initialized
INFO - 2024-02-27 05:42:42 --> Controller Class Initialized
DEBUG - 2024-02-27 05:42:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:42 --> Model Class Initialized
DEBUG - 2024-02-27 05:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:42 --> Model Class Initialized
INFO - 2024-02-27 05:42:42 --> Final output sent to browser
DEBUG - 2024-02-27 05:42:42 --> Total execution time: 0.0319
ERROR - 2024-02-27 05:42:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:42:52 --> Config Class Initialized
INFO - 2024-02-27 05:42:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:42:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:42:52 --> Utf8 Class Initialized
INFO - 2024-02-27 05:42:52 --> URI Class Initialized
INFO - 2024-02-27 05:42:52 --> Router Class Initialized
INFO - 2024-02-27 05:42:52 --> Output Class Initialized
INFO - 2024-02-27 05:42:52 --> Security Class Initialized
DEBUG - 2024-02-27 05:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:42:52 --> Input Class Initialized
INFO - 2024-02-27 05:42:52 --> Language Class Initialized
INFO - 2024-02-27 05:42:52 --> Loader Class Initialized
INFO - 2024-02-27 05:42:52 --> Helper loaded: url_helper
INFO - 2024-02-27 05:42:52 --> Helper loaded: file_helper
INFO - 2024-02-27 05:42:52 --> Helper loaded: html_helper
INFO - 2024-02-27 05:42:52 --> Helper loaded: text_helper
INFO - 2024-02-27 05:42:52 --> Helper loaded: form_helper
INFO - 2024-02-27 05:42:52 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:42:52 --> Helper loaded: security_helper
INFO - 2024-02-27 05:42:52 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:42:52 --> Database Driver Class Initialized
INFO - 2024-02-27 05:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:42:52 --> Parser Class Initialized
INFO - 2024-02-27 05:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:42:52 --> Pagination Class Initialized
INFO - 2024-02-27 05:42:52 --> Form Validation Class Initialized
INFO - 2024-02-27 05:42:52 --> Controller Class Initialized
DEBUG - 2024-02-27 05:42:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:52 --> Model Class Initialized
DEBUG - 2024-02-27 05:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:42:52 --> Model Class Initialized
INFO - 2024-02-27 05:42:53 --> Final output sent to browser
DEBUG - 2024-02-27 05:42:53 --> Total execution time: 0.2613
ERROR - 2024-02-27 05:43:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:43:06 --> Config Class Initialized
INFO - 2024-02-27 05:43:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:43:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:43:06 --> Utf8 Class Initialized
INFO - 2024-02-27 05:43:06 --> URI Class Initialized
INFO - 2024-02-27 05:43:06 --> Router Class Initialized
INFO - 2024-02-27 05:43:06 --> Output Class Initialized
INFO - 2024-02-27 05:43:06 --> Security Class Initialized
DEBUG - 2024-02-27 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:43:06 --> Input Class Initialized
INFO - 2024-02-27 05:43:06 --> Language Class Initialized
INFO - 2024-02-27 05:43:06 --> Loader Class Initialized
INFO - 2024-02-27 05:43:06 --> Helper loaded: url_helper
INFO - 2024-02-27 05:43:06 --> Helper loaded: file_helper
INFO - 2024-02-27 05:43:06 --> Helper loaded: html_helper
INFO - 2024-02-27 05:43:06 --> Helper loaded: text_helper
INFO - 2024-02-27 05:43:06 --> Helper loaded: form_helper
INFO - 2024-02-27 05:43:06 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:43:06 --> Helper loaded: security_helper
INFO - 2024-02-27 05:43:06 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:43:06 --> Database Driver Class Initialized
INFO - 2024-02-27 05:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:43:06 --> Parser Class Initialized
INFO - 2024-02-27 05:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:43:06 --> Pagination Class Initialized
INFO - 2024-02-27 05:43:06 --> Form Validation Class Initialized
INFO - 2024-02-27 05:43:06 --> Controller Class Initialized
INFO - 2024-02-27 05:43:06 --> Model Class Initialized
DEBUG - 2024-02-27 05:43:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:06 --> Model Class Initialized
DEBUG - 2024-02-27 05:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:06 --> Model Class Initialized
ERROR - 2024-02-27 05:43:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/invoice/add_invoice_form.php 195
INFO - 2024-02-27 05:43:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/add_invoice_form.php
DEBUG - 2024-02-27 05:43:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:43:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:43:06 --> Model Class Initialized
INFO - 2024-02-27 05:43:06 --> Model Class Initialized
INFO - 2024-02-27 05:43:06 --> Model Class Initialized
INFO - 2024-02-27 05:43:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:43:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:43:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:43:06 --> Final output sent to browser
DEBUG - 2024-02-27 05:43:06 --> Total execution time: 0.2759
ERROR - 2024-02-27 05:43:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:43:25 --> Config Class Initialized
INFO - 2024-02-27 05:43:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:43:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:43:25 --> Utf8 Class Initialized
INFO - 2024-02-27 05:43:25 --> URI Class Initialized
INFO - 2024-02-27 05:43:25 --> Router Class Initialized
INFO - 2024-02-27 05:43:25 --> Output Class Initialized
INFO - 2024-02-27 05:43:25 --> Security Class Initialized
DEBUG - 2024-02-27 05:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:43:25 --> Input Class Initialized
INFO - 2024-02-27 05:43:25 --> Language Class Initialized
ERROR - 2024-02-27 05:43:25 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-27 05:43:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:43:29 --> Config Class Initialized
INFO - 2024-02-27 05:43:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:43:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:43:29 --> Utf8 Class Initialized
INFO - 2024-02-27 05:43:29 --> URI Class Initialized
INFO - 2024-02-27 05:43:29 --> Router Class Initialized
INFO - 2024-02-27 05:43:29 --> Output Class Initialized
INFO - 2024-02-27 05:43:29 --> Security Class Initialized
DEBUG - 2024-02-27 05:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:43:29 --> Input Class Initialized
INFO - 2024-02-27 05:43:29 --> Language Class Initialized
INFO - 2024-02-27 05:43:29 --> Loader Class Initialized
INFO - 2024-02-27 05:43:29 --> Helper loaded: url_helper
INFO - 2024-02-27 05:43:29 --> Helper loaded: file_helper
INFO - 2024-02-27 05:43:29 --> Helper loaded: html_helper
INFO - 2024-02-27 05:43:29 --> Helper loaded: text_helper
INFO - 2024-02-27 05:43:29 --> Helper loaded: form_helper
INFO - 2024-02-27 05:43:29 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:43:29 --> Helper loaded: security_helper
INFO - 2024-02-27 05:43:29 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:43:29 --> Database Driver Class Initialized
INFO - 2024-02-27 05:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:43:29 --> Parser Class Initialized
INFO - 2024-02-27 05:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:43:29 --> Pagination Class Initialized
INFO - 2024-02-27 05:43:29 --> Form Validation Class Initialized
INFO - 2024-02-27 05:43:29 --> Controller Class Initialized
INFO - 2024-02-27 05:43:29 --> Model Class Initialized
INFO - 2024-02-27 05:43:29 --> Model Class Initialized
ERROR - 2024-02-27 05:43:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php 157
INFO - 2024-02-27 05:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/add_purchase_form.php
DEBUG - 2024-02-27 05:43:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:43:29 --> Model Class Initialized
INFO - 2024-02-27 05:43:29 --> Model Class Initialized
INFO - 2024-02-27 05:43:29 --> Model Class Initialized
INFO - 2024-02-27 05:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:43:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:43:29 --> Final output sent to browser
DEBUG - 2024-02-27 05:43:29 --> Total execution time: 0.2652
ERROR - 2024-02-27 05:43:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:43:43 --> Config Class Initialized
INFO - 2024-02-27 05:43:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:43:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:43:43 --> Utf8 Class Initialized
INFO - 2024-02-27 05:43:43 --> URI Class Initialized
DEBUG - 2024-02-27 05:43:43 --> No URI present. Default controller set.
INFO - 2024-02-27 05:43:43 --> Router Class Initialized
INFO - 2024-02-27 05:43:43 --> Output Class Initialized
INFO - 2024-02-27 05:43:43 --> Security Class Initialized
DEBUG - 2024-02-27 05:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:43:43 --> Input Class Initialized
INFO - 2024-02-27 05:43:43 --> Language Class Initialized
INFO - 2024-02-27 05:43:43 --> Loader Class Initialized
INFO - 2024-02-27 05:43:43 --> Helper loaded: url_helper
INFO - 2024-02-27 05:43:43 --> Helper loaded: file_helper
INFO - 2024-02-27 05:43:43 --> Helper loaded: html_helper
INFO - 2024-02-27 05:43:43 --> Helper loaded: text_helper
INFO - 2024-02-27 05:43:43 --> Helper loaded: form_helper
INFO - 2024-02-27 05:43:43 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:43:43 --> Helper loaded: security_helper
INFO - 2024-02-27 05:43:43 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:43:43 --> Database Driver Class Initialized
INFO - 2024-02-27 05:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:43:43 --> Parser Class Initialized
INFO - 2024-02-27 05:43:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:43:43 --> Pagination Class Initialized
INFO - 2024-02-27 05:43:43 --> Form Validation Class Initialized
INFO - 2024-02-27 05:43:43 --> Controller Class Initialized
INFO - 2024-02-27 05:43:43 --> Model Class Initialized
DEBUG - 2024-02-27 05:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:43 --> Model Class Initialized
DEBUG - 2024-02-27 05:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:43 --> Model Class Initialized
INFO - 2024-02-27 05:43:43 --> Model Class Initialized
INFO - 2024-02-27 05:43:43 --> Model Class Initialized
INFO - 2024-02-27 05:43:43 --> Model Class Initialized
DEBUG - 2024-02-27 05:43:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:43 --> Model Class Initialized
INFO - 2024-02-27 05:43:43 --> Model Class Initialized
INFO - 2024-02-27 05:43:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 05:43:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:43:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:43:43 --> Model Class Initialized
INFO - 2024-02-27 05:43:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:43:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:43:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:43:43 --> Final output sent to browser
DEBUG - 2024-02-27 05:43:43 --> Total execution time: 0.4344
ERROR - 2024-02-27 05:43:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:43:55 --> Config Class Initialized
INFO - 2024-02-27 05:43:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:43:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:43:55 --> Utf8 Class Initialized
INFO - 2024-02-27 05:43:55 --> URI Class Initialized
INFO - 2024-02-27 05:43:55 --> Router Class Initialized
INFO - 2024-02-27 05:43:55 --> Output Class Initialized
INFO - 2024-02-27 05:43:55 --> Security Class Initialized
DEBUG - 2024-02-27 05:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:43:55 --> Input Class Initialized
INFO - 2024-02-27 05:43:55 --> Language Class Initialized
INFO - 2024-02-27 05:43:55 --> Loader Class Initialized
INFO - 2024-02-27 05:43:55 --> Helper loaded: url_helper
INFO - 2024-02-27 05:43:55 --> Helper loaded: file_helper
INFO - 2024-02-27 05:43:55 --> Helper loaded: html_helper
INFO - 2024-02-27 05:43:55 --> Helper loaded: text_helper
INFO - 2024-02-27 05:43:55 --> Helper loaded: form_helper
INFO - 2024-02-27 05:43:55 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:43:55 --> Helper loaded: security_helper
INFO - 2024-02-27 05:43:55 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:43:55 --> Database Driver Class Initialized
INFO - 2024-02-27 05:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:43:55 --> Parser Class Initialized
INFO - 2024-02-27 05:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:43:55 --> Pagination Class Initialized
INFO - 2024-02-27 05:43:55 --> Form Validation Class Initialized
INFO - 2024-02-27 05:43:55 --> Controller Class Initialized
DEBUG - 2024-02-27 05:43:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:55 --> Model Class Initialized
DEBUG - 2024-02-27 05:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:55 --> Model Class Initialized
DEBUG - 2024-02-27 05:43:55 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:55 --> Model Class Initialized
INFO - 2024-02-27 05:43:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-27 05:43:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:43:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:43:55 --> Model Class Initialized
INFO - 2024-02-27 05:43:55 --> Model Class Initialized
INFO - 2024-02-27 05:43:55 --> Model Class Initialized
INFO - 2024-02-27 05:43:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:43:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:43:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:43:55 --> Final output sent to browser
DEBUG - 2024-02-27 05:43:55 --> Total execution time: 0.2146
ERROR - 2024-02-27 05:43:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:43:56 --> Config Class Initialized
INFO - 2024-02-27 05:43:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:43:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:43:56 --> Utf8 Class Initialized
INFO - 2024-02-27 05:43:56 --> URI Class Initialized
INFO - 2024-02-27 05:43:56 --> Router Class Initialized
INFO - 2024-02-27 05:43:56 --> Output Class Initialized
INFO - 2024-02-27 05:43:56 --> Security Class Initialized
DEBUG - 2024-02-27 05:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:43:56 --> Input Class Initialized
INFO - 2024-02-27 05:43:56 --> Language Class Initialized
INFO - 2024-02-27 05:43:56 --> Loader Class Initialized
INFO - 2024-02-27 05:43:56 --> Helper loaded: url_helper
INFO - 2024-02-27 05:43:56 --> Helper loaded: file_helper
INFO - 2024-02-27 05:43:56 --> Helper loaded: html_helper
INFO - 2024-02-27 05:43:56 --> Helper loaded: text_helper
INFO - 2024-02-27 05:43:56 --> Helper loaded: form_helper
INFO - 2024-02-27 05:43:56 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:43:56 --> Helper loaded: security_helper
INFO - 2024-02-27 05:43:56 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:43:56 --> Database Driver Class Initialized
INFO - 2024-02-27 05:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:43:56 --> Parser Class Initialized
INFO - 2024-02-27 05:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:43:56 --> Pagination Class Initialized
INFO - 2024-02-27 05:43:56 --> Form Validation Class Initialized
INFO - 2024-02-27 05:43:56 --> Controller Class Initialized
DEBUG - 2024-02-27 05:43:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:56 --> Model Class Initialized
DEBUG - 2024-02-27 05:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:43:56 --> Model Class Initialized
INFO - 2024-02-27 05:43:56 --> Final output sent to browser
DEBUG - 2024-02-27 05:43:56 --> Total execution time: 0.0319
ERROR - 2024-02-27 05:45:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 05:45:43 --> Config Class Initialized
INFO - 2024-02-27 05:45:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 05:45:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 05:45:43 --> Utf8 Class Initialized
INFO - 2024-02-27 05:45:43 --> URI Class Initialized
DEBUG - 2024-02-27 05:45:43 --> No URI present. Default controller set.
INFO - 2024-02-27 05:45:43 --> Router Class Initialized
INFO - 2024-02-27 05:45:43 --> Output Class Initialized
INFO - 2024-02-27 05:45:43 --> Security Class Initialized
DEBUG - 2024-02-27 05:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 05:45:43 --> Input Class Initialized
INFO - 2024-02-27 05:45:43 --> Language Class Initialized
INFO - 2024-02-27 05:45:43 --> Loader Class Initialized
INFO - 2024-02-27 05:45:43 --> Helper loaded: url_helper
INFO - 2024-02-27 05:45:43 --> Helper loaded: file_helper
INFO - 2024-02-27 05:45:43 --> Helper loaded: html_helper
INFO - 2024-02-27 05:45:43 --> Helper loaded: text_helper
INFO - 2024-02-27 05:45:43 --> Helper loaded: form_helper
INFO - 2024-02-27 05:45:43 --> Helper loaded: lang_helper
INFO - 2024-02-27 05:45:43 --> Helper loaded: security_helper
INFO - 2024-02-27 05:45:43 --> Helper loaded: cookie_helper
INFO - 2024-02-27 05:45:43 --> Database Driver Class Initialized
INFO - 2024-02-27 05:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 05:45:43 --> Parser Class Initialized
INFO - 2024-02-27 05:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 05:45:43 --> Pagination Class Initialized
INFO - 2024-02-27 05:45:43 --> Form Validation Class Initialized
INFO - 2024-02-27 05:45:43 --> Controller Class Initialized
INFO - 2024-02-27 05:45:43 --> Model Class Initialized
DEBUG - 2024-02-27 05:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:45:43 --> Model Class Initialized
DEBUG - 2024-02-27 05:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:45:43 --> Model Class Initialized
INFO - 2024-02-27 05:45:43 --> Model Class Initialized
INFO - 2024-02-27 05:45:43 --> Model Class Initialized
INFO - 2024-02-27 05:45:43 --> Model Class Initialized
DEBUG - 2024-02-27 05:45:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 05:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:45:43 --> Model Class Initialized
INFO - 2024-02-27 05:45:43 --> Model Class Initialized
INFO - 2024-02-27 05:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 05:45:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 05:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 05:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 05:45:44 --> Model Class Initialized
INFO - 2024-02-27 05:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 05:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 05:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 05:45:44 --> Final output sent to browser
DEBUG - 2024-02-27 05:45:44 --> Total execution time: 0.4344
ERROR - 2024-02-27 06:01:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 06:01:46 --> Config Class Initialized
INFO - 2024-02-27 06:01:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 06:01:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 06:01:46 --> Utf8 Class Initialized
INFO - 2024-02-27 06:01:46 --> URI Class Initialized
DEBUG - 2024-02-27 06:01:46 --> No URI present. Default controller set.
INFO - 2024-02-27 06:01:46 --> Router Class Initialized
INFO - 2024-02-27 06:01:46 --> Output Class Initialized
INFO - 2024-02-27 06:01:46 --> Security Class Initialized
DEBUG - 2024-02-27 06:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 06:01:46 --> Input Class Initialized
INFO - 2024-02-27 06:01:46 --> Language Class Initialized
INFO - 2024-02-27 06:01:46 --> Loader Class Initialized
INFO - 2024-02-27 06:01:46 --> Helper loaded: url_helper
INFO - 2024-02-27 06:01:46 --> Helper loaded: file_helper
INFO - 2024-02-27 06:01:46 --> Helper loaded: html_helper
INFO - 2024-02-27 06:01:46 --> Helper loaded: text_helper
INFO - 2024-02-27 06:01:46 --> Helper loaded: form_helper
INFO - 2024-02-27 06:01:46 --> Helper loaded: lang_helper
INFO - 2024-02-27 06:01:46 --> Helper loaded: security_helper
INFO - 2024-02-27 06:01:46 --> Helper loaded: cookie_helper
INFO - 2024-02-27 06:01:46 --> Database Driver Class Initialized
INFO - 2024-02-27 06:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 06:01:46 --> Parser Class Initialized
INFO - 2024-02-27 06:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 06:01:46 --> Pagination Class Initialized
INFO - 2024-02-27 06:01:46 --> Form Validation Class Initialized
INFO - 2024-02-27 06:01:46 --> Controller Class Initialized
INFO - 2024-02-27 06:01:46 --> Model Class Initialized
DEBUG - 2024-02-27 06:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 06:01:46 --> Model Class Initialized
DEBUG - 2024-02-27 06:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 06:01:46 --> Model Class Initialized
INFO - 2024-02-27 06:01:46 --> Model Class Initialized
INFO - 2024-02-27 06:01:46 --> Model Class Initialized
INFO - 2024-02-27 06:01:46 --> Model Class Initialized
DEBUG - 2024-02-27 06:01:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 06:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 06:01:46 --> Model Class Initialized
INFO - 2024-02-27 06:01:46 --> Model Class Initialized
INFO - 2024-02-27 06:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 06:01:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 06:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 06:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 06:01:47 --> Model Class Initialized
INFO - 2024-02-27 06:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 06:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 06:01:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 06:01:47 --> Final output sent to browser
DEBUG - 2024-02-27 06:01:47 --> Total execution time: 0.4338
ERROR - 2024-02-27 06:02:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 06:02:36 --> Config Class Initialized
INFO - 2024-02-27 06:02:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 06:02:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 06:02:36 --> Utf8 Class Initialized
INFO - 2024-02-27 06:02:36 --> URI Class Initialized
INFO - 2024-02-27 06:02:36 --> Router Class Initialized
INFO - 2024-02-27 06:02:36 --> Output Class Initialized
INFO - 2024-02-27 06:02:36 --> Security Class Initialized
DEBUG - 2024-02-27 06:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 06:02:36 --> Input Class Initialized
INFO - 2024-02-27 06:02:36 --> Language Class Initialized
INFO - 2024-02-27 06:02:36 --> Loader Class Initialized
INFO - 2024-02-27 06:02:36 --> Helper loaded: url_helper
INFO - 2024-02-27 06:02:36 --> Helper loaded: file_helper
INFO - 2024-02-27 06:02:36 --> Helper loaded: html_helper
INFO - 2024-02-27 06:02:36 --> Helper loaded: text_helper
INFO - 2024-02-27 06:02:36 --> Helper loaded: form_helper
INFO - 2024-02-27 06:02:36 --> Helper loaded: lang_helper
INFO - 2024-02-27 06:02:36 --> Helper loaded: security_helper
INFO - 2024-02-27 06:02:36 --> Helper loaded: cookie_helper
INFO - 2024-02-27 06:02:36 --> Database Driver Class Initialized
INFO - 2024-02-27 06:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 06:02:36 --> Parser Class Initialized
INFO - 2024-02-27 06:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 06:02:36 --> Pagination Class Initialized
INFO - 2024-02-27 06:02:36 --> Form Validation Class Initialized
INFO - 2024-02-27 06:02:36 --> Controller Class Initialized
INFO - 2024-02-27 06:02:36 --> Model Class Initialized
INFO - 2024-02-27 06:02:36 --> Model Class Initialized
INFO - 2024-02-27 06:02:36 --> Model Class Initialized
INFO - 2024-02-27 06:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2024-02-27 06:02:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 06:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 06:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 06:02:36 --> Model Class Initialized
INFO - 2024-02-27 06:02:36 --> Model Class Initialized
INFO - 2024-02-27 06:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 06:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 06:02:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 06:02:36 --> Final output sent to browser
DEBUG - 2024-02-27 06:02:36 --> Total execution time: 0.2316
ERROR - 2024-02-27 06:02:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 06:02:37 --> Config Class Initialized
INFO - 2024-02-27 06:02:37 --> Hooks Class Initialized
DEBUG - 2024-02-27 06:02:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 06:02:37 --> Utf8 Class Initialized
INFO - 2024-02-27 06:02:37 --> URI Class Initialized
INFO - 2024-02-27 06:02:37 --> Router Class Initialized
INFO - 2024-02-27 06:02:37 --> Output Class Initialized
INFO - 2024-02-27 06:02:37 --> Security Class Initialized
DEBUG - 2024-02-27 06:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 06:02:37 --> Input Class Initialized
INFO - 2024-02-27 06:02:37 --> Language Class Initialized
INFO - 2024-02-27 06:02:37 --> Loader Class Initialized
INFO - 2024-02-27 06:02:37 --> Helper loaded: url_helper
INFO - 2024-02-27 06:02:37 --> Helper loaded: file_helper
INFO - 2024-02-27 06:02:37 --> Helper loaded: html_helper
INFO - 2024-02-27 06:02:37 --> Helper loaded: text_helper
INFO - 2024-02-27 06:02:37 --> Helper loaded: form_helper
INFO - 2024-02-27 06:02:37 --> Helper loaded: lang_helper
INFO - 2024-02-27 06:02:37 --> Helper loaded: security_helper
INFO - 2024-02-27 06:02:37 --> Helper loaded: cookie_helper
INFO - 2024-02-27 06:02:37 --> Database Driver Class Initialized
INFO - 2024-02-27 06:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 06:02:37 --> Parser Class Initialized
INFO - 2024-02-27 06:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 06:02:37 --> Pagination Class Initialized
INFO - 2024-02-27 06:02:37 --> Form Validation Class Initialized
INFO - 2024-02-27 06:02:37 --> Controller Class Initialized
INFO - 2024-02-27 06:02:37 --> Model Class Initialized
INFO - 2024-02-27 06:02:37 --> Model Class Initialized
INFO - 2024-02-27 06:02:37 --> Final output sent to browser
DEBUG - 2024-02-27 06:02:37 --> Total execution time: 0.0280
ERROR - 2024-02-27 06:02:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 06:02:44 --> Config Class Initialized
INFO - 2024-02-27 06:02:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 06:02:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 06:02:44 --> Utf8 Class Initialized
INFO - 2024-02-27 06:02:44 --> URI Class Initialized
DEBUG - 2024-02-27 06:02:44 --> No URI present. Default controller set.
INFO - 2024-02-27 06:02:44 --> Router Class Initialized
INFO - 2024-02-27 06:02:44 --> Output Class Initialized
INFO - 2024-02-27 06:02:44 --> Security Class Initialized
DEBUG - 2024-02-27 06:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 06:02:44 --> Input Class Initialized
INFO - 2024-02-27 06:02:44 --> Language Class Initialized
INFO - 2024-02-27 06:02:44 --> Loader Class Initialized
INFO - 2024-02-27 06:02:44 --> Helper loaded: url_helper
INFO - 2024-02-27 06:02:44 --> Helper loaded: file_helper
INFO - 2024-02-27 06:02:44 --> Helper loaded: html_helper
INFO - 2024-02-27 06:02:44 --> Helper loaded: text_helper
INFO - 2024-02-27 06:02:44 --> Helper loaded: form_helper
INFO - 2024-02-27 06:02:44 --> Helper loaded: lang_helper
INFO - 2024-02-27 06:02:44 --> Helper loaded: security_helper
INFO - 2024-02-27 06:02:44 --> Helper loaded: cookie_helper
INFO - 2024-02-27 06:02:44 --> Database Driver Class Initialized
INFO - 2024-02-27 06:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 06:02:44 --> Parser Class Initialized
INFO - 2024-02-27 06:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 06:02:44 --> Pagination Class Initialized
INFO - 2024-02-27 06:02:44 --> Form Validation Class Initialized
INFO - 2024-02-27 06:02:44 --> Controller Class Initialized
INFO - 2024-02-27 06:02:44 --> Model Class Initialized
DEBUG - 2024-02-27 06:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 06:02:44 --> Model Class Initialized
DEBUG - 2024-02-27 06:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 06:02:44 --> Model Class Initialized
INFO - 2024-02-27 06:02:44 --> Model Class Initialized
INFO - 2024-02-27 06:02:44 --> Model Class Initialized
INFO - 2024-02-27 06:02:44 --> Model Class Initialized
DEBUG - 2024-02-27 06:02:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 06:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 06:02:44 --> Model Class Initialized
INFO - 2024-02-27 06:02:44 --> Model Class Initialized
INFO - 2024-02-27 06:02:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 06:02:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 06:02:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 06:02:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 06:02:44 --> Model Class Initialized
INFO - 2024-02-27 06:02:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 06:02:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 06:02:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 06:02:44 --> Final output sent to browser
DEBUG - 2024-02-27 06:02:44 --> Total execution time: 0.4305
ERROR - 2024-02-27 08:47:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:47:38 --> Config Class Initialized
INFO - 2024-02-27 08:47:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:47:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:47:38 --> Utf8 Class Initialized
INFO - 2024-02-27 08:47:38 --> URI Class Initialized
DEBUG - 2024-02-27 08:47:38 --> No URI present. Default controller set.
INFO - 2024-02-27 08:47:38 --> Router Class Initialized
INFO - 2024-02-27 08:47:38 --> Output Class Initialized
INFO - 2024-02-27 08:47:38 --> Security Class Initialized
DEBUG - 2024-02-27 08:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:47:38 --> Input Class Initialized
INFO - 2024-02-27 08:47:38 --> Language Class Initialized
INFO - 2024-02-27 08:47:38 --> Loader Class Initialized
INFO - 2024-02-27 08:47:38 --> Helper loaded: url_helper
INFO - 2024-02-27 08:47:38 --> Helper loaded: file_helper
INFO - 2024-02-27 08:47:38 --> Helper loaded: html_helper
INFO - 2024-02-27 08:47:38 --> Helper loaded: text_helper
INFO - 2024-02-27 08:47:38 --> Helper loaded: form_helper
INFO - 2024-02-27 08:47:38 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:47:38 --> Helper loaded: security_helper
INFO - 2024-02-27 08:47:38 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:47:38 --> Database Driver Class Initialized
INFO - 2024-02-27 08:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:47:38 --> Parser Class Initialized
INFO - 2024-02-27 08:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:47:38 --> Pagination Class Initialized
INFO - 2024-02-27 08:47:38 --> Form Validation Class Initialized
INFO - 2024-02-27 08:47:38 --> Controller Class Initialized
INFO - 2024-02-27 08:47:38 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 08:47:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:47:39 --> Config Class Initialized
INFO - 2024-02-27 08:47:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:47:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:47:39 --> Utf8 Class Initialized
INFO - 2024-02-27 08:47:39 --> URI Class Initialized
INFO - 2024-02-27 08:47:39 --> Router Class Initialized
INFO - 2024-02-27 08:47:39 --> Output Class Initialized
INFO - 2024-02-27 08:47:39 --> Security Class Initialized
DEBUG - 2024-02-27 08:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:47:39 --> Input Class Initialized
INFO - 2024-02-27 08:47:39 --> Language Class Initialized
INFO - 2024-02-27 08:47:39 --> Loader Class Initialized
INFO - 2024-02-27 08:47:39 --> Helper loaded: url_helper
INFO - 2024-02-27 08:47:39 --> Helper loaded: file_helper
INFO - 2024-02-27 08:47:39 --> Helper loaded: html_helper
INFO - 2024-02-27 08:47:39 --> Helper loaded: text_helper
INFO - 2024-02-27 08:47:39 --> Helper loaded: form_helper
INFO - 2024-02-27 08:47:39 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:47:39 --> Helper loaded: security_helper
INFO - 2024-02-27 08:47:39 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:47:39 --> Database Driver Class Initialized
INFO - 2024-02-27 08:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:47:39 --> Parser Class Initialized
INFO - 2024-02-27 08:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:47:39 --> Pagination Class Initialized
INFO - 2024-02-27 08:47:39 --> Form Validation Class Initialized
INFO - 2024-02-27 08:47:39 --> Controller Class Initialized
INFO - 2024-02-27 08:47:39 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 08:47:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:47:39 --> Model Class Initialized
INFO - 2024-02-27 08:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:47:39 --> Final output sent to browser
DEBUG - 2024-02-27 08:47:39 --> Total execution time: 0.0378
ERROR - 2024-02-27 08:47:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:47:48 --> Config Class Initialized
INFO - 2024-02-27 08:47:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:47:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:47:48 --> Utf8 Class Initialized
INFO - 2024-02-27 08:47:48 --> URI Class Initialized
INFO - 2024-02-27 08:47:48 --> Router Class Initialized
INFO - 2024-02-27 08:47:48 --> Output Class Initialized
INFO - 2024-02-27 08:47:48 --> Security Class Initialized
DEBUG - 2024-02-27 08:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:47:48 --> Input Class Initialized
INFO - 2024-02-27 08:47:48 --> Language Class Initialized
INFO - 2024-02-27 08:47:48 --> Loader Class Initialized
INFO - 2024-02-27 08:47:48 --> Helper loaded: url_helper
INFO - 2024-02-27 08:47:48 --> Helper loaded: file_helper
INFO - 2024-02-27 08:47:48 --> Helper loaded: html_helper
INFO - 2024-02-27 08:47:48 --> Helper loaded: text_helper
INFO - 2024-02-27 08:47:48 --> Helper loaded: form_helper
INFO - 2024-02-27 08:47:48 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:47:48 --> Helper loaded: security_helper
INFO - 2024-02-27 08:47:48 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:47:48 --> Database Driver Class Initialized
INFO - 2024-02-27 08:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:47:48 --> Parser Class Initialized
INFO - 2024-02-27 08:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:47:48 --> Pagination Class Initialized
INFO - 2024-02-27 08:47:48 --> Form Validation Class Initialized
INFO - 2024-02-27 08:47:48 --> Controller Class Initialized
INFO - 2024-02-27 08:47:48 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:48 --> Model Class Initialized
INFO - 2024-02-27 08:47:48 --> Final output sent to browser
DEBUG - 2024-02-27 08:47:48 --> Total execution time: 0.0193
ERROR - 2024-02-27 08:47:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:47:49 --> Config Class Initialized
INFO - 2024-02-27 08:47:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:47:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:47:49 --> Utf8 Class Initialized
INFO - 2024-02-27 08:47:49 --> URI Class Initialized
DEBUG - 2024-02-27 08:47:49 --> No URI present. Default controller set.
INFO - 2024-02-27 08:47:49 --> Router Class Initialized
INFO - 2024-02-27 08:47:49 --> Output Class Initialized
INFO - 2024-02-27 08:47:49 --> Security Class Initialized
DEBUG - 2024-02-27 08:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:47:49 --> Input Class Initialized
INFO - 2024-02-27 08:47:49 --> Language Class Initialized
INFO - 2024-02-27 08:47:49 --> Loader Class Initialized
INFO - 2024-02-27 08:47:49 --> Helper loaded: url_helper
INFO - 2024-02-27 08:47:49 --> Helper loaded: file_helper
INFO - 2024-02-27 08:47:49 --> Helper loaded: html_helper
INFO - 2024-02-27 08:47:49 --> Helper loaded: text_helper
INFO - 2024-02-27 08:47:49 --> Helper loaded: form_helper
INFO - 2024-02-27 08:47:49 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:47:49 --> Helper loaded: security_helper
INFO - 2024-02-27 08:47:49 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:47:49 --> Database Driver Class Initialized
INFO - 2024-02-27 08:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:47:49 --> Parser Class Initialized
INFO - 2024-02-27 08:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:47:49 --> Pagination Class Initialized
INFO - 2024-02-27 08:47:49 --> Form Validation Class Initialized
INFO - 2024-02-27 08:47:49 --> Controller Class Initialized
INFO - 2024-02-27 08:47:49 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:49 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:49 --> Model Class Initialized
INFO - 2024-02-27 08:47:49 --> Model Class Initialized
INFO - 2024-02-27 08:47:49 --> Model Class Initialized
INFO - 2024-02-27 08:47:49 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:49 --> Model Class Initialized
INFO - 2024-02-27 08:47:49 --> Model Class Initialized
INFO - 2024-02-27 08:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:47:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:47:49 --> Model Class Initialized
INFO - 2024-02-27 08:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:47:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:47:49 --> Final output sent to browser
DEBUG - 2024-02-27 08:47:49 --> Total execution time: 0.2442
ERROR - 2024-02-27 08:47:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:47:53 --> Config Class Initialized
INFO - 2024-02-27 08:47:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:47:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:47:53 --> Utf8 Class Initialized
INFO - 2024-02-27 08:47:53 --> URI Class Initialized
INFO - 2024-02-27 08:47:53 --> Router Class Initialized
INFO - 2024-02-27 08:47:53 --> Output Class Initialized
INFO - 2024-02-27 08:47:53 --> Security Class Initialized
DEBUG - 2024-02-27 08:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:47:53 --> Input Class Initialized
INFO - 2024-02-27 08:47:53 --> Language Class Initialized
INFO - 2024-02-27 08:47:53 --> Loader Class Initialized
INFO - 2024-02-27 08:47:53 --> Helper loaded: url_helper
INFO - 2024-02-27 08:47:53 --> Helper loaded: file_helper
INFO - 2024-02-27 08:47:53 --> Helper loaded: html_helper
INFO - 2024-02-27 08:47:53 --> Helper loaded: text_helper
INFO - 2024-02-27 08:47:53 --> Helper loaded: form_helper
INFO - 2024-02-27 08:47:53 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:47:53 --> Helper loaded: security_helper
INFO - 2024-02-27 08:47:53 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:47:53 --> Database Driver Class Initialized
INFO - 2024-02-27 08:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:47:53 --> Parser Class Initialized
INFO - 2024-02-27 08:47:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:47:53 --> Pagination Class Initialized
INFO - 2024-02-27 08:47:53 --> Form Validation Class Initialized
INFO - 2024-02-27 08:47:53 --> Controller Class Initialized
DEBUG - 2024-02-27 08:47:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:53 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:53 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:53 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:53 --> Model Class Initialized
INFO - 2024-02-27 08:47:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-27 08:47:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:47:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:47:53 --> Model Class Initialized
INFO - 2024-02-27 08:47:53 --> Model Class Initialized
INFO - 2024-02-27 08:47:53 --> Model Class Initialized
INFO - 2024-02-27 08:47:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:47:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:47:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:47:53 --> Final output sent to browser
DEBUG - 2024-02-27 08:47:53 --> Total execution time: 0.1450
ERROR - 2024-02-27 08:47:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:47:55 --> Config Class Initialized
INFO - 2024-02-27 08:47:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:47:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:47:55 --> Utf8 Class Initialized
INFO - 2024-02-27 08:47:55 --> URI Class Initialized
INFO - 2024-02-27 08:47:55 --> Router Class Initialized
INFO - 2024-02-27 08:47:55 --> Output Class Initialized
INFO - 2024-02-27 08:47:55 --> Security Class Initialized
DEBUG - 2024-02-27 08:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:47:55 --> Input Class Initialized
INFO - 2024-02-27 08:47:55 --> Language Class Initialized
INFO - 2024-02-27 08:47:55 --> Loader Class Initialized
INFO - 2024-02-27 08:47:55 --> Helper loaded: url_helper
INFO - 2024-02-27 08:47:55 --> Helper loaded: file_helper
INFO - 2024-02-27 08:47:55 --> Helper loaded: html_helper
INFO - 2024-02-27 08:47:55 --> Helper loaded: text_helper
INFO - 2024-02-27 08:47:55 --> Helper loaded: form_helper
INFO - 2024-02-27 08:47:55 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:47:55 --> Helper loaded: security_helper
INFO - 2024-02-27 08:47:55 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:47:55 --> Database Driver Class Initialized
INFO - 2024-02-27 08:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:47:55 --> Parser Class Initialized
INFO - 2024-02-27 08:47:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:47:55 --> Pagination Class Initialized
INFO - 2024-02-27 08:47:55 --> Form Validation Class Initialized
INFO - 2024-02-27 08:47:55 --> Controller Class Initialized
DEBUG - 2024-02-27 08:47:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:55 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:55 --> Model Class Initialized
INFO - 2024-02-27 08:47:55 --> Final output sent to browser
DEBUG - 2024-02-27 08:47:55 --> Total execution time: 0.0226
ERROR - 2024-02-27 08:47:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:47:58 --> Config Class Initialized
INFO - 2024-02-27 08:47:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:47:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:47:58 --> Utf8 Class Initialized
INFO - 2024-02-27 08:47:58 --> URI Class Initialized
INFO - 2024-02-27 08:47:58 --> Router Class Initialized
INFO - 2024-02-27 08:47:58 --> Output Class Initialized
INFO - 2024-02-27 08:47:58 --> Security Class Initialized
DEBUG - 2024-02-27 08:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:47:58 --> Input Class Initialized
INFO - 2024-02-27 08:47:58 --> Language Class Initialized
INFO - 2024-02-27 08:47:58 --> Loader Class Initialized
INFO - 2024-02-27 08:47:58 --> Helper loaded: url_helper
INFO - 2024-02-27 08:47:58 --> Helper loaded: file_helper
INFO - 2024-02-27 08:47:58 --> Helper loaded: html_helper
INFO - 2024-02-27 08:47:58 --> Helper loaded: text_helper
INFO - 2024-02-27 08:47:58 --> Helper loaded: form_helper
INFO - 2024-02-27 08:47:58 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:47:58 --> Helper loaded: security_helper
INFO - 2024-02-27 08:47:58 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:47:58 --> Database Driver Class Initialized
INFO - 2024-02-27 08:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:47:58 --> Parser Class Initialized
INFO - 2024-02-27 08:47:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:47:58 --> Pagination Class Initialized
INFO - 2024-02-27 08:47:58 --> Form Validation Class Initialized
INFO - 2024-02-27 08:47:58 --> Controller Class Initialized
DEBUG - 2024-02-27 08:47:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:58 --> Model Class Initialized
DEBUG - 2024-02-27 08:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:47:58 --> Model Class Initialized
INFO - 2024-02-27 08:47:58 --> Final output sent to browser
DEBUG - 2024-02-27 08:47:58 --> Total execution time: 0.0334
ERROR - 2024-02-27 08:48:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:48:25 --> Config Class Initialized
INFO - 2024-02-27 08:48:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:48:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:48:25 --> Utf8 Class Initialized
INFO - 2024-02-27 08:48:25 --> URI Class Initialized
DEBUG - 2024-02-27 08:48:25 --> No URI present. Default controller set.
INFO - 2024-02-27 08:48:25 --> Router Class Initialized
INFO - 2024-02-27 08:48:25 --> Output Class Initialized
INFO - 2024-02-27 08:48:25 --> Security Class Initialized
DEBUG - 2024-02-27 08:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:48:25 --> Input Class Initialized
INFO - 2024-02-27 08:48:25 --> Language Class Initialized
INFO - 2024-02-27 08:48:25 --> Loader Class Initialized
INFO - 2024-02-27 08:48:25 --> Helper loaded: url_helper
INFO - 2024-02-27 08:48:25 --> Helper loaded: file_helper
INFO - 2024-02-27 08:48:25 --> Helper loaded: html_helper
INFO - 2024-02-27 08:48:25 --> Helper loaded: text_helper
INFO - 2024-02-27 08:48:25 --> Helper loaded: form_helper
INFO - 2024-02-27 08:48:25 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:48:25 --> Helper loaded: security_helper
INFO - 2024-02-27 08:48:25 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:48:25 --> Database Driver Class Initialized
INFO - 2024-02-27 08:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:48:25 --> Parser Class Initialized
INFO - 2024-02-27 08:48:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:48:25 --> Pagination Class Initialized
INFO - 2024-02-27 08:48:25 --> Form Validation Class Initialized
INFO - 2024-02-27 08:48:25 --> Controller Class Initialized
INFO - 2024-02-27 08:48:25 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:25 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:25 --> Model Class Initialized
INFO - 2024-02-27 08:48:25 --> Model Class Initialized
INFO - 2024-02-27 08:48:25 --> Model Class Initialized
INFO - 2024-02-27 08:48:25 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:25 --> Model Class Initialized
INFO - 2024-02-27 08:48:25 --> Model Class Initialized
INFO - 2024-02-27 08:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:48:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:48:25 --> Model Class Initialized
INFO - 2024-02-27 08:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:48:25 --> Final output sent to browser
DEBUG - 2024-02-27 08:48:25 --> Total execution time: 0.2475
ERROR - 2024-02-27 08:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:48:27 --> Config Class Initialized
INFO - 2024-02-27 08:48:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:48:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:48:27 --> Utf8 Class Initialized
INFO - 2024-02-27 08:48:27 --> URI Class Initialized
INFO - 2024-02-27 08:48:27 --> Router Class Initialized
INFO - 2024-02-27 08:48:27 --> Output Class Initialized
INFO - 2024-02-27 08:48:27 --> Security Class Initialized
DEBUG - 2024-02-27 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:48:27 --> Input Class Initialized
INFO - 2024-02-27 08:48:27 --> Language Class Initialized
INFO - 2024-02-27 08:48:27 --> Loader Class Initialized
INFO - 2024-02-27 08:48:27 --> Helper loaded: url_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: file_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: html_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: text_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: form_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: security_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:48:27 --> Database Driver Class Initialized
INFO - 2024-02-27 08:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:48:27 --> Parser Class Initialized
INFO - 2024-02-27 08:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:48:27 --> Pagination Class Initialized
INFO - 2024-02-27 08:48:27 --> Form Validation Class Initialized
INFO - 2024-02-27 08:48:27 --> Controller Class Initialized
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 08:48:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
INFO - 2024-02-27 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:48:27 --> Final output sent to browser
DEBUG - 2024-02-27 08:48:27 --> Total execution time: 0.0287
ERROR - 2024-02-27 08:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:48:27 --> Config Class Initialized
INFO - 2024-02-27 08:48:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:48:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:48:27 --> Utf8 Class Initialized
INFO - 2024-02-27 08:48:27 --> URI Class Initialized
INFO - 2024-02-27 08:48:27 --> Router Class Initialized
INFO - 2024-02-27 08:48:27 --> Output Class Initialized
INFO - 2024-02-27 08:48:27 --> Security Class Initialized
DEBUG - 2024-02-27 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:48:27 --> Input Class Initialized
INFO - 2024-02-27 08:48:27 --> Language Class Initialized
INFO - 2024-02-27 08:48:27 --> Loader Class Initialized
INFO - 2024-02-27 08:48:27 --> Helper loaded: url_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: file_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: html_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: text_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: form_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: security_helper
INFO - 2024-02-27 08:48:27 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:48:27 --> Database Driver Class Initialized
INFO - 2024-02-27 08:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:48:27 --> Parser Class Initialized
INFO - 2024-02-27 08:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:48:27 --> Pagination Class Initialized
INFO - 2024-02-27 08:48:27 --> Form Validation Class Initialized
INFO - 2024-02-27 08:48:27 --> Controller Class Initialized
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
INFO - 2024-02-27 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:48:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:48:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:48:27 --> Model Class Initialized
INFO - 2024-02-27 08:48:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:48:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:48:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:48:28 --> Final output sent to browser
DEBUG - 2024-02-27 08:48:28 --> Total execution time: 0.2332
ERROR - 2024-02-27 08:48:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:48:36 --> Config Class Initialized
INFO - 2024-02-27 08:48:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:48:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:48:36 --> Utf8 Class Initialized
INFO - 2024-02-27 08:48:36 --> URI Class Initialized
INFO - 2024-02-27 08:48:36 --> Router Class Initialized
INFO - 2024-02-27 08:48:36 --> Output Class Initialized
INFO - 2024-02-27 08:48:36 --> Security Class Initialized
DEBUG - 2024-02-27 08:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:48:36 --> Input Class Initialized
INFO - 2024-02-27 08:48:36 --> Language Class Initialized
INFO - 2024-02-27 08:48:36 --> Loader Class Initialized
INFO - 2024-02-27 08:48:36 --> Helper loaded: url_helper
INFO - 2024-02-27 08:48:36 --> Helper loaded: file_helper
INFO - 2024-02-27 08:48:36 --> Helper loaded: html_helper
INFO - 2024-02-27 08:48:36 --> Helper loaded: text_helper
INFO - 2024-02-27 08:48:36 --> Helper loaded: form_helper
INFO - 2024-02-27 08:48:36 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:48:36 --> Helper loaded: security_helper
INFO - 2024-02-27 08:48:36 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:48:36 --> Database Driver Class Initialized
INFO - 2024-02-27 08:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:48:36 --> Parser Class Initialized
INFO - 2024-02-27 08:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:48:36 --> Pagination Class Initialized
INFO - 2024-02-27 08:48:36 --> Form Validation Class Initialized
INFO - 2024-02-27 08:48:36 --> Controller Class Initialized
INFO - 2024-02-27 08:48:36 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:36 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:36 --> Model Class Initialized
INFO - 2024-02-27 08:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-27 08:48:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:48:36 --> Model Class Initialized
INFO - 2024-02-27 08:48:36 --> Model Class Initialized
INFO - 2024-02-27 08:48:36 --> Model Class Initialized
INFO - 2024-02-27 08:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:48:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:48:36 --> Final output sent to browser
DEBUG - 2024-02-27 08:48:36 --> Total execution time: 0.1824
ERROR - 2024-02-27 08:48:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:48:43 --> Config Class Initialized
INFO - 2024-02-27 08:48:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:48:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:48:43 --> Utf8 Class Initialized
INFO - 2024-02-27 08:48:43 --> URI Class Initialized
INFO - 2024-02-27 08:48:43 --> Router Class Initialized
INFO - 2024-02-27 08:48:43 --> Output Class Initialized
INFO - 2024-02-27 08:48:43 --> Security Class Initialized
DEBUG - 2024-02-27 08:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:48:43 --> Input Class Initialized
INFO - 2024-02-27 08:48:43 --> Language Class Initialized
INFO - 2024-02-27 08:48:43 --> Loader Class Initialized
INFO - 2024-02-27 08:48:43 --> Helper loaded: url_helper
INFO - 2024-02-27 08:48:43 --> Helper loaded: file_helper
INFO - 2024-02-27 08:48:43 --> Helper loaded: html_helper
INFO - 2024-02-27 08:48:43 --> Helper loaded: text_helper
INFO - 2024-02-27 08:48:43 --> Helper loaded: form_helper
INFO - 2024-02-27 08:48:43 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:48:43 --> Helper loaded: security_helper
INFO - 2024-02-27 08:48:43 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:48:43 --> Database Driver Class Initialized
INFO - 2024-02-27 08:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:48:43 --> Parser Class Initialized
INFO - 2024-02-27 08:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:48:43 --> Pagination Class Initialized
INFO - 2024-02-27 08:48:43 --> Form Validation Class Initialized
INFO - 2024-02-27 08:48:43 --> Controller Class Initialized
INFO - 2024-02-27 08:48:43 --> Model Class Initialized
DEBUG - 2024-02-27 08:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:48:43 --> Final output sent to browser
DEBUG - 2024-02-27 08:48:43 --> Total execution time: 0.0164
ERROR - 2024-02-27 08:49:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:49:18 --> Config Class Initialized
INFO - 2024-02-27 08:49:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:49:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:49:18 --> Utf8 Class Initialized
INFO - 2024-02-27 08:49:18 --> URI Class Initialized
INFO - 2024-02-27 08:49:18 --> Router Class Initialized
INFO - 2024-02-27 08:49:18 --> Output Class Initialized
INFO - 2024-02-27 08:49:18 --> Security Class Initialized
DEBUG - 2024-02-27 08:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:49:18 --> Input Class Initialized
INFO - 2024-02-27 08:49:18 --> Language Class Initialized
INFO - 2024-02-27 08:49:18 --> Loader Class Initialized
INFO - 2024-02-27 08:49:18 --> Helper loaded: url_helper
INFO - 2024-02-27 08:49:18 --> Helper loaded: file_helper
INFO - 2024-02-27 08:49:18 --> Helper loaded: html_helper
INFO - 2024-02-27 08:49:18 --> Helper loaded: text_helper
INFO - 2024-02-27 08:49:18 --> Helper loaded: form_helper
INFO - 2024-02-27 08:49:18 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:49:18 --> Helper loaded: security_helper
INFO - 2024-02-27 08:49:18 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:49:18 --> Database Driver Class Initialized
INFO - 2024-02-27 08:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:49:18 --> Parser Class Initialized
INFO - 2024-02-27 08:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:49:18 --> Pagination Class Initialized
INFO - 2024-02-27 08:49:18 --> Form Validation Class Initialized
INFO - 2024-02-27 08:49:18 --> Controller Class Initialized
INFO - 2024-02-27 08:49:18 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 08:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-27 08:49:18 --> Final output sent to browser
DEBUG - 2024-02-27 08:49:18 --> Total execution time: 0.0184
ERROR - 2024-02-27 08:49:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:49:20 --> Config Class Initialized
INFO - 2024-02-27 08:49:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:49:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:49:20 --> Utf8 Class Initialized
INFO - 2024-02-27 08:49:20 --> URI Class Initialized
INFO - 2024-02-27 08:49:20 --> Router Class Initialized
INFO - 2024-02-27 08:49:20 --> Output Class Initialized
INFO - 2024-02-27 08:49:20 --> Security Class Initialized
DEBUG - 2024-02-27 08:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:49:20 --> Input Class Initialized
INFO - 2024-02-27 08:49:20 --> Language Class Initialized
INFO - 2024-02-27 08:49:20 --> Loader Class Initialized
INFO - 2024-02-27 08:49:20 --> Helper loaded: url_helper
INFO - 2024-02-27 08:49:20 --> Helper loaded: file_helper
INFO - 2024-02-27 08:49:20 --> Helper loaded: html_helper
INFO - 2024-02-27 08:49:20 --> Helper loaded: text_helper
INFO - 2024-02-27 08:49:20 --> Helper loaded: form_helper
INFO - 2024-02-27 08:49:20 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:49:20 --> Helper loaded: security_helper
INFO - 2024-02-27 08:49:20 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:49:20 --> Database Driver Class Initialized
INFO - 2024-02-27 08:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:49:20 --> Parser Class Initialized
INFO - 2024-02-27 08:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:49:20 --> Pagination Class Initialized
INFO - 2024-02-27 08:49:20 --> Form Validation Class Initialized
INFO - 2024-02-27 08:49:20 --> Controller Class Initialized
INFO - 2024-02-27 08:49:20 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 08:49:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-27 08:49:20 --> Final output sent to browser
DEBUG - 2024-02-27 08:49:20 --> Total execution time: 0.0178
ERROR - 2024-02-27 08:49:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:49:21 --> Config Class Initialized
INFO - 2024-02-27 08:49:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:49:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:49:21 --> Utf8 Class Initialized
INFO - 2024-02-27 08:49:21 --> URI Class Initialized
INFO - 2024-02-27 08:49:21 --> Router Class Initialized
INFO - 2024-02-27 08:49:21 --> Output Class Initialized
INFO - 2024-02-27 08:49:21 --> Security Class Initialized
DEBUG - 2024-02-27 08:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:49:21 --> Input Class Initialized
INFO - 2024-02-27 08:49:21 --> Language Class Initialized
INFO - 2024-02-27 08:49:21 --> Loader Class Initialized
INFO - 2024-02-27 08:49:21 --> Helper loaded: url_helper
INFO - 2024-02-27 08:49:21 --> Helper loaded: file_helper
INFO - 2024-02-27 08:49:21 --> Helper loaded: html_helper
INFO - 2024-02-27 08:49:21 --> Helper loaded: text_helper
INFO - 2024-02-27 08:49:21 --> Helper loaded: form_helper
INFO - 2024-02-27 08:49:21 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:49:21 --> Helper loaded: security_helper
INFO - 2024-02-27 08:49:21 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:49:21 --> Database Driver Class Initialized
INFO - 2024-02-27 08:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:49:21 --> Parser Class Initialized
INFO - 2024-02-27 08:49:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:49:21 --> Pagination Class Initialized
INFO - 2024-02-27 08:49:21 --> Form Validation Class Initialized
INFO - 2024-02-27 08:49:21 --> Controller Class Initialized
INFO - 2024-02-27 08:49:21 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 08:49:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-27 08:49:21 --> Final output sent to browser
DEBUG - 2024-02-27 08:49:21 --> Total execution time: 0.0149
ERROR - 2024-02-27 08:49:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:49:25 --> Config Class Initialized
INFO - 2024-02-27 08:49:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:49:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:49:25 --> Utf8 Class Initialized
INFO - 2024-02-27 08:49:25 --> URI Class Initialized
INFO - 2024-02-27 08:49:25 --> Router Class Initialized
INFO - 2024-02-27 08:49:25 --> Output Class Initialized
INFO - 2024-02-27 08:49:25 --> Security Class Initialized
DEBUG - 2024-02-27 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:49:25 --> Input Class Initialized
INFO - 2024-02-27 08:49:25 --> Language Class Initialized
INFO - 2024-02-27 08:49:25 --> Loader Class Initialized
INFO - 2024-02-27 08:49:25 --> Helper loaded: url_helper
INFO - 2024-02-27 08:49:25 --> Helper loaded: file_helper
INFO - 2024-02-27 08:49:25 --> Helper loaded: html_helper
INFO - 2024-02-27 08:49:25 --> Helper loaded: text_helper
INFO - 2024-02-27 08:49:25 --> Helper loaded: form_helper
INFO - 2024-02-27 08:49:25 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:49:25 --> Helper loaded: security_helper
INFO - 2024-02-27 08:49:25 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:49:25 --> Database Driver Class Initialized
INFO - 2024-02-27 08:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:49:25 --> Parser Class Initialized
INFO - 2024-02-27 08:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:49:25 --> Pagination Class Initialized
INFO - 2024-02-27 08:49:25 --> Form Validation Class Initialized
INFO - 2024-02-27 08:49:25 --> Controller Class Initialized
INFO - 2024-02-27 08:49:25 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 08:49:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-27 08:49:25 --> Final output sent to browser
DEBUG - 2024-02-27 08:49:25 --> Total execution time: 0.0148
ERROR - 2024-02-27 08:49:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:49:28 --> Config Class Initialized
INFO - 2024-02-27 08:49:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:49:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:49:28 --> Utf8 Class Initialized
INFO - 2024-02-27 08:49:28 --> URI Class Initialized
INFO - 2024-02-27 08:49:28 --> Router Class Initialized
INFO - 2024-02-27 08:49:28 --> Output Class Initialized
INFO - 2024-02-27 08:49:28 --> Security Class Initialized
DEBUG - 2024-02-27 08:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:49:28 --> Input Class Initialized
INFO - 2024-02-27 08:49:28 --> Language Class Initialized
INFO - 2024-02-27 08:49:28 --> Loader Class Initialized
INFO - 2024-02-27 08:49:28 --> Helper loaded: url_helper
INFO - 2024-02-27 08:49:28 --> Helper loaded: file_helper
INFO - 2024-02-27 08:49:28 --> Helper loaded: html_helper
INFO - 2024-02-27 08:49:28 --> Helper loaded: text_helper
INFO - 2024-02-27 08:49:28 --> Helper loaded: form_helper
INFO - 2024-02-27 08:49:28 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:49:28 --> Helper loaded: security_helper
INFO - 2024-02-27 08:49:28 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:49:28 --> Database Driver Class Initialized
INFO - 2024-02-27 08:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:49:28 --> Parser Class Initialized
INFO - 2024-02-27 08:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:49:28 --> Pagination Class Initialized
INFO - 2024-02-27 08:49:28 --> Form Validation Class Initialized
INFO - 2024-02-27 08:49:28 --> Controller Class Initialized
INFO - 2024-02-27 08:49:28 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:49:28 --> Final output sent to browser
DEBUG - 2024-02-27 08:49:28 --> Total execution time: 0.0154
ERROR - 2024-02-27 08:49:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:49:54 --> Config Class Initialized
INFO - 2024-02-27 08:49:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:49:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:49:54 --> Utf8 Class Initialized
INFO - 2024-02-27 08:49:54 --> URI Class Initialized
INFO - 2024-02-27 08:49:54 --> Router Class Initialized
INFO - 2024-02-27 08:49:54 --> Output Class Initialized
INFO - 2024-02-27 08:49:54 --> Security Class Initialized
DEBUG - 2024-02-27 08:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:49:54 --> Input Class Initialized
INFO - 2024-02-27 08:49:54 --> Language Class Initialized
INFO - 2024-02-27 08:49:54 --> Loader Class Initialized
INFO - 2024-02-27 08:49:54 --> Helper loaded: url_helper
INFO - 2024-02-27 08:49:54 --> Helper loaded: file_helper
INFO - 2024-02-27 08:49:54 --> Helper loaded: html_helper
INFO - 2024-02-27 08:49:54 --> Helper loaded: text_helper
INFO - 2024-02-27 08:49:54 --> Helper loaded: form_helper
INFO - 2024-02-27 08:49:54 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:49:54 --> Helper loaded: security_helper
INFO - 2024-02-27 08:49:54 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:49:54 --> Database Driver Class Initialized
INFO - 2024-02-27 08:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:49:54 --> Parser Class Initialized
INFO - 2024-02-27 08:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:49:54 --> Pagination Class Initialized
INFO - 2024-02-27 08:49:54 --> Form Validation Class Initialized
INFO - 2024-02-27 08:49:54 --> Controller Class Initialized
INFO - 2024-02-27 08:49:54 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:49:54 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:49:54 --> Model Class Initialized
INFO - 2024-02-27 08:49:54 --> Model Class Initialized
INFO - 2024-02-27 08:49:54 --> Model Class Initialized
INFO - 2024-02-27 08:49:54 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:49:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:49:54 --> Model Class Initialized
INFO - 2024-02-27 08:49:54 --> Model Class Initialized
INFO - 2024-02-27 08:49:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:49:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:49:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:49:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:49:54 --> Model Class Initialized
INFO - 2024-02-27 08:49:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:49:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:49:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:49:54 --> Final output sent to browser
DEBUG - 2024-02-27 08:49:54 --> Total execution time: 0.2439
ERROR - 2024-02-27 08:49:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:49:58 --> Config Class Initialized
INFO - 2024-02-27 08:49:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:49:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:49:58 --> Utf8 Class Initialized
INFO - 2024-02-27 08:49:58 --> URI Class Initialized
INFO - 2024-02-27 08:49:58 --> Router Class Initialized
INFO - 2024-02-27 08:49:58 --> Output Class Initialized
INFO - 2024-02-27 08:49:58 --> Security Class Initialized
DEBUG - 2024-02-27 08:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:49:58 --> Input Class Initialized
INFO - 2024-02-27 08:49:58 --> Language Class Initialized
INFO - 2024-02-27 08:49:58 --> Loader Class Initialized
INFO - 2024-02-27 08:49:58 --> Helper loaded: url_helper
INFO - 2024-02-27 08:49:58 --> Helper loaded: file_helper
INFO - 2024-02-27 08:49:58 --> Helper loaded: html_helper
INFO - 2024-02-27 08:49:58 --> Helper loaded: text_helper
INFO - 2024-02-27 08:49:58 --> Helper loaded: form_helper
INFO - 2024-02-27 08:49:58 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:49:58 --> Helper loaded: security_helper
INFO - 2024-02-27 08:49:58 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:49:58 --> Database Driver Class Initialized
INFO - 2024-02-27 08:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:49:58 --> Parser Class Initialized
INFO - 2024-02-27 08:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:49:58 --> Pagination Class Initialized
INFO - 2024-02-27 08:49:58 --> Form Validation Class Initialized
INFO - 2024-02-27 08:49:58 --> Controller Class Initialized
DEBUG - 2024-02-27 08:49:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:49:58 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:49:58 --> Model Class Initialized
DEBUG - 2024-02-27 08:49:58 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:49:58 --> Model Class Initialized
INFO - 2024-02-27 08:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-27 08:49:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:49:58 --> Model Class Initialized
INFO - 2024-02-27 08:49:58 --> Model Class Initialized
INFO - 2024-02-27 08:49:58 --> Model Class Initialized
INFO - 2024-02-27 08:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:49:59 --> Final output sent to browser
DEBUG - 2024-02-27 08:49:59 --> Total execution time: 0.1553
ERROR - 2024-02-27 08:50:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:50:00 --> Config Class Initialized
INFO - 2024-02-27 08:50:00 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:50:00 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:50:00 --> Utf8 Class Initialized
INFO - 2024-02-27 08:50:00 --> URI Class Initialized
INFO - 2024-02-27 08:50:00 --> Router Class Initialized
INFO - 2024-02-27 08:50:00 --> Output Class Initialized
INFO - 2024-02-27 08:50:00 --> Security Class Initialized
DEBUG - 2024-02-27 08:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:50:00 --> Input Class Initialized
INFO - 2024-02-27 08:50:00 --> Language Class Initialized
INFO - 2024-02-27 08:50:00 --> Loader Class Initialized
INFO - 2024-02-27 08:50:00 --> Helper loaded: url_helper
INFO - 2024-02-27 08:50:00 --> Helper loaded: file_helper
INFO - 2024-02-27 08:50:00 --> Helper loaded: html_helper
INFO - 2024-02-27 08:50:00 --> Helper loaded: text_helper
INFO - 2024-02-27 08:50:00 --> Helper loaded: form_helper
INFO - 2024-02-27 08:50:00 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:50:00 --> Helper loaded: security_helper
INFO - 2024-02-27 08:50:00 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:50:00 --> Database Driver Class Initialized
INFO - 2024-02-27 08:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:50:00 --> Parser Class Initialized
INFO - 2024-02-27 08:50:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:50:00 --> Pagination Class Initialized
INFO - 2024-02-27 08:50:00 --> Form Validation Class Initialized
INFO - 2024-02-27 08:50:00 --> Controller Class Initialized
DEBUG - 2024-02-27 08:50:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:00 --> Model Class Initialized
DEBUG - 2024-02-27 08:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:00 --> Model Class Initialized
DEBUG - 2024-02-27 08:50:00 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:00 --> Model Class Initialized
INFO - 2024-02-27 08:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-27 08:50:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:50:00 --> Model Class Initialized
INFO - 2024-02-27 08:50:00 --> Model Class Initialized
INFO - 2024-02-27 08:50:00 --> Model Class Initialized
INFO - 2024-02-27 08:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:50:00 --> Final output sent to browser
DEBUG - 2024-02-27 08:50:00 --> Total execution time: 0.1502
ERROR - 2024-02-27 08:50:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:50:01 --> Config Class Initialized
INFO - 2024-02-27 08:50:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:50:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:50:01 --> Utf8 Class Initialized
INFO - 2024-02-27 08:50:01 --> URI Class Initialized
INFO - 2024-02-27 08:50:01 --> Router Class Initialized
INFO - 2024-02-27 08:50:01 --> Output Class Initialized
INFO - 2024-02-27 08:50:01 --> Security Class Initialized
DEBUG - 2024-02-27 08:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:50:01 --> Input Class Initialized
INFO - 2024-02-27 08:50:01 --> Language Class Initialized
INFO - 2024-02-27 08:50:01 --> Loader Class Initialized
INFO - 2024-02-27 08:50:01 --> Helper loaded: url_helper
INFO - 2024-02-27 08:50:01 --> Helper loaded: file_helper
INFO - 2024-02-27 08:50:01 --> Helper loaded: html_helper
INFO - 2024-02-27 08:50:01 --> Helper loaded: text_helper
INFO - 2024-02-27 08:50:01 --> Helper loaded: form_helper
INFO - 2024-02-27 08:50:01 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:50:01 --> Helper loaded: security_helper
INFO - 2024-02-27 08:50:01 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:50:01 --> Database Driver Class Initialized
INFO - 2024-02-27 08:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:50:01 --> Parser Class Initialized
INFO - 2024-02-27 08:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:50:01 --> Pagination Class Initialized
INFO - 2024-02-27 08:50:01 --> Form Validation Class Initialized
INFO - 2024-02-27 08:50:01 --> Controller Class Initialized
DEBUG - 2024-02-27 08:50:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:01 --> Model Class Initialized
DEBUG - 2024-02-27 08:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:01 --> Model Class Initialized
INFO - 2024-02-27 08:50:01 --> Final output sent to browser
DEBUG - 2024-02-27 08:50:01 --> Total execution time: 0.0213
ERROR - 2024-02-27 08:50:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:50:08 --> Config Class Initialized
INFO - 2024-02-27 08:50:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:50:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:50:08 --> Utf8 Class Initialized
INFO - 2024-02-27 08:50:08 --> URI Class Initialized
INFO - 2024-02-27 08:50:08 --> Router Class Initialized
INFO - 2024-02-27 08:50:08 --> Output Class Initialized
INFO - 2024-02-27 08:50:08 --> Security Class Initialized
DEBUG - 2024-02-27 08:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:50:08 --> Input Class Initialized
INFO - 2024-02-27 08:50:08 --> Language Class Initialized
INFO - 2024-02-27 08:50:08 --> Loader Class Initialized
INFO - 2024-02-27 08:50:08 --> Helper loaded: url_helper
INFO - 2024-02-27 08:50:08 --> Helper loaded: file_helper
INFO - 2024-02-27 08:50:08 --> Helper loaded: html_helper
INFO - 2024-02-27 08:50:08 --> Helper loaded: text_helper
INFO - 2024-02-27 08:50:08 --> Helper loaded: form_helper
INFO - 2024-02-27 08:50:08 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:50:08 --> Helper loaded: security_helper
INFO - 2024-02-27 08:50:08 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:50:08 --> Database Driver Class Initialized
INFO - 2024-02-27 08:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:50:08 --> Parser Class Initialized
INFO - 2024-02-27 08:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:50:08 --> Pagination Class Initialized
INFO - 2024-02-27 08:50:08 --> Form Validation Class Initialized
INFO - 2024-02-27 08:50:08 --> Controller Class Initialized
DEBUG - 2024-02-27 08:50:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:08 --> Model Class Initialized
DEBUG - 2024-02-27 08:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:08 --> Model Class Initialized
INFO - 2024-02-27 08:50:08 --> Final output sent to browser
DEBUG - 2024-02-27 08:50:08 --> Total execution time: 0.0338
ERROR - 2024-02-27 08:50:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:50:58 --> Config Class Initialized
INFO - 2024-02-27 08:50:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:50:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:50:58 --> Utf8 Class Initialized
INFO - 2024-02-27 08:50:58 --> URI Class Initialized
INFO - 2024-02-27 08:50:58 --> Router Class Initialized
INFO - 2024-02-27 08:50:58 --> Output Class Initialized
INFO - 2024-02-27 08:50:58 --> Security Class Initialized
DEBUG - 2024-02-27 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:50:58 --> Input Class Initialized
INFO - 2024-02-27 08:50:58 --> Language Class Initialized
INFO - 2024-02-27 08:50:58 --> Loader Class Initialized
INFO - 2024-02-27 08:50:58 --> Helper loaded: url_helper
INFO - 2024-02-27 08:50:58 --> Helper loaded: file_helper
INFO - 2024-02-27 08:50:58 --> Helper loaded: html_helper
INFO - 2024-02-27 08:50:58 --> Helper loaded: text_helper
INFO - 2024-02-27 08:50:58 --> Helper loaded: form_helper
INFO - 2024-02-27 08:50:58 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:50:58 --> Helper loaded: security_helper
INFO - 2024-02-27 08:50:58 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:50:58 --> Database Driver Class Initialized
INFO - 2024-02-27 08:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:50:58 --> Parser Class Initialized
INFO - 2024-02-27 08:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:50:58 --> Pagination Class Initialized
INFO - 2024-02-27 08:50:58 --> Form Validation Class Initialized
INFO - 2024-02-27 08:50:58 --> Controller Class Initialized
INFO - 2024-02-27 08:50:58 --> Model Class Initialized
DEBUG - 2024-02-27 08:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:58 --> Model Class Initialized
DEBUG - 2024-02-27 08:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:58 --> Model Class Initialized
INFO - 2024-02-27 08:50:58 --> Model Class Initialized
INFO - 2024-02-27 08:50:58 --> Model Class Initialized
INFO - 2024-02-27 08:50:58 --> Model Class Initialized
DEBUG - 2024-02-27 08:50:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:58 --> Model Class Initialized
INFO - 2024-02-27 08:50:58 --> Model Class Initialized
INFO - 2024-02-27 08:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:50:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:50:58 --> Model Class Initialized
INFO - 2024-02-27 08:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:50:58 --> Final output sent to browser
DEBUG - 2024-02-27 08:50:58 --> Total execution time: 0.2378
ERROR - 2024-02-27 08:51:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:51:05 --> Config Class Initialized
INFO - 2024-02-27 08:51:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:51:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:51:05 --> Utf8 Class Initialized
INFO - 2024-02-27 08:51:05 --> URI Class Initialized
INFO - 2024-02-27 08:51:05 --> Router Class Initialized
INFO - 2024-02-27 08:51:05 --> Output Class Initialized
INFO - 2024-02-27 08:51:05 --> Security Class Initialized
DEBUG - 2024-02-27 08:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:51:05 --> Input Class Initialized
INFO - 2024-02-27 08:51:05 --> Language Class Initialized
INFO - 2024-02-27 08:51:05 --> Loader Class Initialized
INFO - 2024-02-27 08:51:05 --> Helper loaded: url_helper
INFO - 2024-02-27 08:51:05 --> Helper loaded: file_helper
INFO - 2024-02-27 08:51:05 --> Helper loaded: html_helper
INFO - 2024-02-27 08:51:05 --> Helper loaded: text_helper
INFO - 2024-02-27 08:51:05 --> Helper loaded: form_helper
INFO - 2024-02-27 08:51:05 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:51:05 --> Helper loaded: security_helper
INFO - 2024-02-27 08:51:05 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:51:05 --> Database Driver Class Initialized
INFO - 2024-02-27 08:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:51:05 --> Parser Class Initialized
INFO - 2024-02-27 08:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:51:05 --> Pagination Class Initialized
INFO - 2024-02-27 08:51:05 --> Form Validation Class Initialized
INFO - 2024-02-27 08:51:05 --> Controller Class Initialized
INFO - 2024-02-27 08:51:05 --> Model Class Initialized
DEBUG - 2024-02-27 08:51:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:51:05 --> Model Class Initialized
DEBUG - 2024-02-27 08:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:51:05 --> Model Class Initialized
INFO - 2024-02-27 08:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-27 08:51:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:51:05 --> Model Class Initialized
INFO - 2024-02-27 08:51:05 --> Model Class Initialized
INFO - 2024-02-27 08:51:05 --> Model Class Initialized
INFO - 2024-02-27 08:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:51:05 --> Final output sent to browser
DEBUG - 2024-02-27 08:51:05 --> Total execution time: 0.1689
ERROR - 2024-02-27 08:51:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:51:14 --> Config Class Initialized
INFO - 2024-02-27 08:51:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:51:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:51:14 --> Utf8 Class Initialized
INFO - 2024-02-27 08:51:14 --> URI Class Initialized
INFO - 2024-02-27 08:51:14 --> Router Class Initialized
INFO - 2024-02-27 08:51:14 --> Output Class Initialized
INFO - 2024-02-27 08:51:14 --> Security Class Initialized
DEBUG - 2024-02-27 08:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:51:14 --> Input Class Initialized
INFO - 2024-02-27 08:51:14 --> Language Class Initialized
INFO - 2024-02-27 08:51:14 --> Loader Class Initialized
INFO - 2024-02-27 08:51:14 --> Helper loaded: url_helper
INFO - 2024-02-27 08:51:14 --> Helper loaded: file_helper
INFO - 2024-02-27 08:51:14 --> Helper loaded: html_helper
INFO - 2024-02-27 08:51:14 --> Helper loaded: text_helper
INFO - 2024-02-27 08:51:14 --> Helper loaded: form_helper
INFO - 2024-02-27 08:51:14 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:51:14 --> Helper loaded: security_helper
INFO - 2024-02-27 08:51:14 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:51:14 --> Database Driver Class Initialized
INFO - 2024-02-27 08:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:51:14 --> Parser Class Initialized
INFO - 2024-02-27 08:51:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:51:14 --> Pagination Class Initialized
INFO - 2024-02-27 08:51:14 --> Form Validation Class Initialized
INFO - 2024-02-27 08:51:14 --> Controller Class Initialized
INFO - 2024-02-27 08:51:14 --> Model Class Initialized
DEBUG - 2024-02-27 08:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:51:14 --> Final output sent to browser
DEBUG - 2024-02-27 08:51:14 --> Total execution time: 0.0164
ERROR - 2024-02-27 08:52:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:52:19 --> Config Class Initialized
INFO - 2024-02-27 08:52:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:52:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:52:19 --> Utf8 Class Initialized
INFO - 2024-02-27 08:52:19 --> URI Class Initialized
INFO - 2024-02-27 08:52:19 --> Router Class Initialized
INFO - 2024-02-27 08:52:19 --> Output Class Initialized
INFO - 2024-02-27 08:52:19 --> Security Class Initialized
DEBUG - 2024-02-27 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:52:19 --> Input Class Initialized
INFO - 2024-02-27 08:52:19 --> Language Class Initialized
INFO - 2024-02-27 08:52:19 --> Loader Class Initialized
INFO - 2024-02-27 08:52:19 --> Helper loaded: url_helper
INFO - 2024-02-27 08:52:19 --> Helper loaded: file_helper
INFO - 2024-02-27 08:52:19 --> Helper loaded: html_helper
INFO - 2024-02-27 08:52:19 --> Helper loaded: text_helper
INFO - 2024-02-27 08:52:19 --> Helper loaded: form_helper
INFO - 2024-02-27 08:52:19 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:52:19 --> Helper loaded: security_helper
INFO - 2024-02-27 08:52:19 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:52:19 --> Database Driver Class Initialized
INFO - 2024-02-27 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:52:19 --> Parser Class Initialized
INFO - 2024-02-27 08:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:52:19 --> Pagination Class Initialized
INFO - 2024-02-27 08:52:19 --> Form Validation Class Initialized
INFO - 2024-02-27 08:52:19 --> Controller Class Initialized
INFO - 2024-02-27 08:52:19 --> Model Class Initialized
DEBUG - 2024-02-27 08:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:52:19 --> Model Class Initialized
DEBUG - 2024-02-27 08:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:52:19 --> Model Class Initialized
INFO - 2024-02-27 08:52:19 --> Model Class Initialized
INFO - 2024-02-27 08:52:19 --> Model Class Initialized
INFO - 2024-02-27 08:52:19 --> Model Class Initialized
DEBUG - 2024-02-27 08:52:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:52:19 --> Model Class Initialized
INFO - 2024-02-27 08:52:19 --> Model Class Initialized
INFO - 2024-02-27 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:52:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:52:19 --> Model Class Initialized
INFO - 2024-02-27 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:52:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:52:19 --> Final output sent to browser
DEBUG - 2024-02-27 08:52:19 --> Total execution time: 0.2355
ERROR - 2024-02-27 08:58:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:02 --> Config Class Initialized
INFO - 2024-02-27 08:58:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:02 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:02 --> URI Class Initialized
DEBUG - 2024-02-27 08:58:02 --> No URI present. Default controller set.
INFO - 2024-02-27 08:58:02 --> Router Class Initialized
INFO - 2024-02-27 08:58:02 --> Output Class Initialized
INFO - 2024-02-27 08:58:02 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:02 --> Input Class Initialized
INFO - 2024-02-27 08:58:02 --> Language Class Initialized
INFO - 2024-02-27 08:58:02 --> Loader Class Initialized
INFO - 2024-02-27 08:58:02 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:02 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:02 --> Parser Class Initialized
INFO - 2024-02-27 08:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:02 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:02 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:02 --> Controller Class Initialized
INFO - 2024-02-27 08:58:02 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 08:58:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:02 --> Config Class Initialized
INFO - 2024-02-27 08:58:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:02 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:02 --> URI Class Initialized
INFO - 2024-02-27 08:58:02 --> Router Class Initialized
INFO - 2024-02-27 08:58:02 --> Output Class Initialized
INFO - 2024-02-27 08:58:02 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:02 --> Input Class Initialized
INFO - 2024-02-27 08:58:02 --> Language Class Initialized
INFO - 2024-02-27 08:58:02 --> Loader Class Initialized
INFO - 2024-02-27 08:58:02 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:02 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:02 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:02 --> Parser Class Initialized
INFO - 2024-02-27 08:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:02 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:02 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:02 --> Controller Class Initialized
INFO - 2024-02-27 08:58:02 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 08:58:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:58:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:58:02 --> Model Class Initialized
INFO - 2024-02-27 08:58:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:58:02 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:02 --> Total execution time: 0.0304
ERROR - 2024-02-27 08:58:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:06 --> Config Class Initialized
INFO - 2024-02-27 08:58:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:06 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:06 --> URI Class Initialized
INFO - 2024-02-27 08:58:06 --> Router Class Initialized
INFO - 2024-02-27 08:58:06 --> Output Class Initialized
INFO - 2024-02-27 08:58:06 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:06 --> Input Class Initialized
INFO - 2024-02-27 08:58:06 --> Language Class Initialized
INFO - 2024-02-27 08:58:06 --> Loader Class Initialized
INFO - 2024-02-27 08:58:06 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:06 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:06 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:06 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:06 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:06 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:06 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:06 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:06 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:06 --> Parser Class Initialized
INFO - 2024-02-27 08:58:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:06 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:06 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:06 --> Controller Class Initialized
INFO - 2024-02-27 08:58:06 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:06 --> Model Class Initialized
INFO - 2024-02-27 08:58:06 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:06 --> Total execution time: 0.0158
ERROR - 2024-02-27 08:58:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:07 --> Config Class Initialized
INFO - 2024-02-27 08:58:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:07 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:07 --> URI Class Initialized
DEBUG - 2024-02-27 08:58:07 --> No URI present. Default controller set.
INFO - 2024-02-27 08:58:07 --> Router Class Initialized
INFO - 2024-02-27 08:58:07 --> Output Class Initialized
INFO - 2024-02-27 08:58:07 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:07 --> Input Class Initialized
INFO - 2024-02-27 08:58:07 --> Language Class Initialized
INFO - 2024-02-27 08:58:07 --> Loader Class Initialized
INFO - 2024-02-27 08:58:07 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:07 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:07 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:07 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:07 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:07 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:07 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:07 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:07 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:07 --> Parser Class Initialized
INFO - 2024-02-27 08:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:07 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:07 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:07 --> Controller Class Initialized
INFO - 2024-02-27 08:58:07 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:07 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:07 --> Model Class Initialized
INFO - 2024-02-27 08:58:07 --> Model Class Initialized
INFO - 2024-02-27 08:58:07 --> Model Class Initialized
INFO - 2024-02-27 08:58:07 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:07 --> Model Class Initialized
INFO - 2024-02-27 08:58:07 --> Model Class Initialized
INFO - 2024-02-27 08:58:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:58:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:58:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:58:07 --> Model Class Initialized
INFO - 2024-02-27 08:58:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:58:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:58:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:58:07 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:07 --> Total execution time: 0.4070
ERROR - 2024-02-27 08:58:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:08 --> Config Class Initialized
INFO - 2024-02-27 08:58:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:08 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:08 --> URI Class Initialized
INFO - 2024-02-27 08:58:08 --> Router Class Initialized
INFO - 2024-02-27 08:58:08 --> Output Class Initialized
INFO - 2024-02-27 08:58:08 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:08 --> Input Class Initialized
INFO - 2024-02-27 08:58:08 --> Language Class Initialized
INFO - 2024-02-27 08:58:08 --> Loader Class Initialized
INFO - 2024-02-27 08:58:08 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:08 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:08 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:08 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:08 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:08 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:08 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:08 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:08 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:08 --> Parser Class Initialized
INFO - 2024-02-27 08:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:08 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:08 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:08 --> Controller Class Initialized
DEBUG - 2024-02-27 08:58:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:08 --> Model Class Initialized
INFO - 2024-02-27 08:58:08 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:08 --> Total execution time: 0.0153
ERROR - 2024-02-27 08:58:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:31 --> Config Class Initialized
INFO - 2024-02-27 08:58:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:31 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:31 --> URI Class Initialized
DEBUG - 2024-02-27 08:58:31 --> No URI present. Default controller set.
INFO - 2024-02-27 08:58:31 --> Router Class Initialized
INFO - 2024-02-27 08:58:31 --> Output Class Initialized
INFO - 2024-02-27 08:58:31 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:31 --> Input Class Initialized
INFO - 2024-02-27 08:58:31 --> Language Class Initialized
INFO - 2024-02-27 08:58:31 --> Loader Class Initialized
INFO - 2024-02-27 08:58:31 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:31 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:31 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:31 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:31 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:31 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:31 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:31 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:31 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:31 --> Parser Class Initialized
INFO - 2024-02-27 08:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:31 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:31 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:31 --> Controller Class Initialized
INFO - 2024-02-27 08:58:31 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 08:58:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:33 --> Config Class Initialized
INFO - 2024-02-27 08:58:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:33 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:33 --> URI Class Initialized
INFO - 2024-02-27 08:58:33 --> Router Class Initialized
INFO - 2024-02-27 08:58:33 --> Output Class Initialized
INFO - 2024-02-27 08:58:33 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:33 --> Input Class Initialized
INFO - 2024-02-27 08:58:33 --> Language Class Initialized
INFO - 2024-02-27 08:58:33 --> Loader Class Initialized
INFO - 2024-02-27 08:58:33 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:33 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:33 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:33 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:33 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:33 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:33 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:33 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:33 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:33 --> Parser Class Initialized
INFO - 2024-02-27 08:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:33 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:33 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:33 --> Controller Class Initialized
INFO - 2024-02-27 08:58:33 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 08:58:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:58:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:58:33 --> Model Class Initialized
INFO - 2024-02-27 08:58:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:58:33 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:33 --> Total execution time: 0.0293
ERROR - 2024-02-27 08:58:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:34 --> Config Class Initialized
INFO - 2024-02-27 08:58:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:34 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:34 --> URI Class Initialized
INFO - 2024-02-27 08:58:34 --> Router Class Initialized
INFO - 2024-02-27 08:58:34 --> Output Class Initialized
INFO - 2024-02-27 08:58:34 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:34 --> Input Class Initialized
INFO - 2024-02-27 08:58:34 --> Language Class Initialized
INFO - 2024-02-27 08:58:34 --> Loader Class Initialized
INFO - 2024-02-27 08:58:34 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:34 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:34 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:34 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:34 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:34 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:34 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:34 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:34 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:34 --> Parser Class Initialized
INFO - 2024-02-27 08:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:34 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:34 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:34 --> Controller Class Initialized
INFO - 2024-02-27 08:58:34 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:34 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:34 --> Model Class Initialized
INFO - 2024-02-27 08:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-27 08:58:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:58:34 --> Model Class Initialized
INFO - 2024-02-27 08:58:34 --> Model Class Initialized
INFO - 2024-02-27 08:58:34 --> Model Class Initialized
INFO - 2024-02-27 08:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:58:34 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:34 --> Total execution time: 0.2295
ERROR - 2024-02-27 08:58:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:35 --> Config Class Initialized
INFO - 2024-02-27 08:58:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:35 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:35 --> URI Class Initialized
INFO - 2024-02-27 08:58:35 --> Router Class Initialized
INFO - 2024-02-27 08:58:35 --> Output Class Initialized
INFO - 2024-02-27 08:58:35 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:35 --> Input Class Initialized
INFO - 2024-02-27 08:58:35 --> Language Class Initialized
INFO - 2024-02-27 08:58:35 --> Loader Class Initialized
INFO - 2024-02-27 08:58:35 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:35 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:35 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:35 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:35 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:35 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:35 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:35 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:35 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:35 --> Parser Class Initialized
INFO - 2024-02-27 08:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:35 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:35 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:35 --> Controller Class Initialized
INFO - 2024-02-27 08:58:35 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:35 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:35 --> Model Class Initialized
INFO - 2024-02-27 08:58:35 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:35 --> Total execution time: 0.0671
ERROR - 2024-02-27 08:58:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:40 --> Config Class Initialized
INFO - 2024-02-27 08:58:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:40 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:40 --> URI Class Initialized
INFO - 2024-02-27 08:58:40 --> Router Class Initialized
INFO - 2024-02-27 08:58:40 --> Output Class Initialized
INFO - 2024-02-27 08:58:40 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:40 --> Input Class Initialized
INFO - 2024-02-27 08:58:40 --> Language Class Initialized
INFO - 2024-02-27 08:58:40 --> Loader Class Initialized
INFO - 2024-02-27 08:58:40 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:40 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:40 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:40 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:40 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:40 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:40 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:40 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:40 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:40 --> Parser Class Initialized
INFO - 2024-02-27 08:58:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:40 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:40 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:40 --> Controller Class Initialized
INFO - 2024-02-27 08:58:40 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:40 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:40 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-27 08:58:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:58:40 --> Model Class Initialized
INFO - 2024-02-27 08:58:40 --> Model Class Initialized
INFO - 2024-02-27 08:58:40 --> Model Class Initialized
INFO - 2024-02-27 08:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:58:40 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:40 --> Total execution time: 0.2263
ERROR - 2024-02-27 08:58:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:48 --> Config Class Initialized
INFO - 2024-02-27 08:58:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:48 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:48 --> URI Class Initialized
INFO - 2024-02-27 08:58:48 --> Router Class Initialized
INFO - 2024-02-27 08:58:48 --> Output Class Initialized
INFO - 2024-02-27 08:58:48 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:48 --> Input Class Initialized
INFO - 2024-02-27 08:58:48 --> Language Class Initialized
INFO - 2024-02-27 08:58:48 --> Loader Class Initialized
INFO - 2024-02-27 08:58:48 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:48 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:48 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:48 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:48 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:48 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:48 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:48 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:48 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:48 --> Parser Class Initialized
INFO - 2024-02-27 08:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:48 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:48 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:48 --> Controller Class Initialized
INFO - 2024-02-27 08:58:48 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:48 --> Model Class Initialized
INFO - 2024-02-27 08:58:48 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:48 --> Total execution time: 0.0164
ERROR - 2024-02-27 08:58:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:49 --> Config Class Initialized
INFO - 2024-02-27 08:58:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:49 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:49 --> URI Class Initialized
DEBUG - 2024-02-27 08:58:49 --> No URI present. Default controller set.
INFO - 2024-02-27 08:58:49 --> Router Class Initialized
INFO - 2024-02-27 08:58:49 --> Output Class Initialized
INFO - 2024-02-27 08:58:49 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:49 --> Input Class Initialized
INFO - 2024-02-27 08:58:49 --> Language Class Initialized
INFO - 2024-02-27 08:58:49 --> Loader Class Initialized
INFO - 2024-02-27 08:58:49 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:49 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:49 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:49 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:49 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:49 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:49 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:49 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:49 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:49 --> Parser Class Initialized
INFO - 2024-02-27 08:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:49 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:49 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:49 --> Controller Class Initialized
INFO - 2024-02-27 08:58:49 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:49 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:49 --> Model Class Initialized
INFO - 2024-02-27 08:58:49 --> Model Class Initialized
INFO - 2024-02-27 08:58:49 --> Model Class Initialized
INFO - 2024-02-27 08:58:49 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:49 --> Model Class Initialized
INFO - 2024-02-27 08:58:49 --> Model Class Initialized
INFO - 2024-02-27 08:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:58:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:58:49 --> Model Class Initialized
INFO - 2024-02-27 08:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:58:49 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:49 --> Total execution time: 0.2299
ERROR - 2024-02-27 08:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:58:59 --> Config Class Initialized
INFO - 2024-02-27 08:58:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:58:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:58:59 --> Utf8 Class Initialized
INFO - 2024-02-27 08:58:59 --> URI Class Initialized
INFO - 2024-02-27 08:58:59 --> Router Class Initialized
INFO - 2024-02-27 08:58:59 --> Output Class Initialized
INFO - 2024-02-27 08:58:59 --> Security Class Initialized
DEBUG - 2024-02-27 08:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:58:59 --> Input Class Initialized
INFO - 2024-02-27 08:58:59 --> Language Class Initialized
INFO - 2024-02-27 08:58:59 --> Loader Class Initialized
INFO - 2024-02-27 08:58:59 --> Helper loaded: url_helper
INFO - 2024-02-27 08:58:59 --> Helper loaded: file_helper
INFO - 2024-02-27 08:58:59 --> Helper loaded: html_helper
INFO - 2024-02-27 08:58:59 --> Helper loaded: text_helper
INFO - 2024-02-27 08:58:59 --> Helper loaded: form_helper
INFO - 2024-02-27 08:58:59 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:58:59 --> Helper loaded: security_helper
INFO - 2024-02-27 08:58:59 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:58:59 --> Database Driver Class Initialized
INFO - 2024-02-27 08:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:58:59 --> Parser Class Initialized
INFO - 2024-02-27 08:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:58:59 --> Pagination Class Initialized
INFO - 2024-02-27 08:58:59 --> Form Validation Class Initialized
INFO - 2024-02-27 08:58:59 --> Controller Class Initialized
INFO - 2024-02-27 08:58:59 --> Model Class Initialized
DEBUG - 2024-02-27 08:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 08:58:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:58:59 --> Model Class Initialized
INFO - 2024-02-27 08:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:58:59 --> Final output sent to browser
DEBUG - 2024-02-27 08:58:59 --> Total execution time: 0.0373
ERROR - 2024-02-27 08:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:59:00 --> Config Class Initialized
INFO - 2024-02-27 08:59:00 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:59:00 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:59:00 --> Utf8 Class Initialized
INFO - 2024-02-27 08:59:00 --> URI Class Initialized
INFO - 2024-02-27 08:59:00 --> Router Class Initialized
INFO - 2024-02-27 08:59:00 --> Output Class Initialized
INFO - 2024-02-27 08:59:00 --> Security Class Initialized
DEBUG - 2024-02-27 08:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:59:00 --> Input Class Initialized
INFO - 2024-02-27 08:59:00 --> Language Class Initialized
INFO - 2024-02-27 08:59:00 --> Loader Class Initialized
INFO - 2024-02-27 08:59:00 --> Helper loaded: url_helper
INFO - 2024-02-27 08:59:00 --> Helper loaded: file_helper
INFO - 2024-02-27 08:59:00 --> Helper loaded: html_helper
INFO - 2024-02-27 08:59:00 --> Helper loaded: text_helper
INFO - 2024-02-27 08:59:00 --> Helper loaded: form_helper
INFO - 2024-02-27 08:59:00 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:59:00 --> Helper loaded: security_helper
INFO - 2024-02-27 08:59:00 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:59:00 --> Database Driver Class Initialized
INFO - 2024-02-27 08:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:59:00 --> Parser Class Initialized
INFO - 2024-02-27 08:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:59:00 --> Pagination Class Initialized
INFO - 2024-02-27 08:59:00 --> Form Validation Class Initialized
INFO - 2024-02-27 08:59:00 --> Controller Class Initialized
INFO - 2024-02-27 08:59:00 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:00 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:00 --> Model Class Initialized
INFO - 2024-02-27 08:59:00 --> Model Class Initialized
INFO - 2024-02-27 08:59:00 --> Model Class Initialized
INFO - 2024-02-27 08:59:00 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:00 --> Model Class Initialized
INFO - 2024-02-27 08:59:00 --> Model Class Initialized
INFO - 2024-02-27 08:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:59:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:59:00 --> Model Class Initialized
INFO - 2024-02-27 08:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:59:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:59:00 --> Final output sent to browser
DEBUG - 2024-02-27 08:59:00 --> Total execution time: 0.2245
ERROR - 2024-02-27 08:59:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:59:03 --> Config Class Initialized
INFO - 2024-02-27 08:59:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:59:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:59:03 --> Utf8 Class Initialized
INFO - 2024-02-27 08:59:03 --> URI Class Initialized
INFO - 2024-02-27 08:59:03 --> Router Class Initialized
INFO - 2024-02-27 08:59:03 --> Output Class Initialized
INFO - 2024-02-27 08:59:03 --> Security Class Initialized
DEBUG - 2024-02-27 08:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:59:03 --> Input Class Initialized
INFO - 2024-02-27 08:59:03 --> Language Class Initialized
INFO - 2024-02-27 08:59:03 --> Loader Class Initialized
INFO - 2024-02-27 08:59:03 --> Helper loaded: url_helper
INFO - 2024-02-27 08:59:03 --> Helper loaded: file_helper
INFO - 2024-02-27 08:59:03 --> Helper loaded: html_helper
INFO - 2024-02-27 08:59:03 --> Helper loaded: text_helper
INFO - 2024-02-27 08:59:03 --> Helper loaded: form_helper
INFO - 2024-02-27 08:59:03 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:59:03 --> Helper loaded: security_helper
INFO - 2024-02-27 08:59:03 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:59:03 --> Database Driver Class Initialized
INFO - 2024-02-27 08:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:59:03 --> Parser Class Initialized
INFO - 2024-02-27 08:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:59:03 --> Pagination Class Initialized
INFO - 2024-02-27 08:59:03 --> Form Validation Class Initialized
INFO - 2024-02-27 08:59:03 --> Controller Class Initialized
INFO - 2024-02-27 08:59:03 --> Model Class Initialized
INFO - 2024-02-27 08:59:03 --> Model Class Initialized
INFO - 2024-02-27 08:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-02-27 08:59:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:59:04 --> Model Class Initialized
INFO - 2024-02-27 08:59:04 --> Model Class Initialized
INFO - 2024-02-27 08:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:59:04 --> Final output sent to browser
DEBUG - 2024-02-27 08:59:04 --> Total execution time: 0.1572
ERROR - 2024-02-27 08:59:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:59:05 --> Config Class Initialized
INFO - 2024-02-27 08:59:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:59:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:59:05 --> Utf8 Class Initialized
INFO - 2024-02-27 08:59:05 --> URI Class Initialized
INFO - 2024-02-27 08:59:05 --> Router Class Initialized
INFO - 2024-02-27 08:59:05 --> Output Class Initialized
INFO - 2024-02-27 08:59:05 --> Security Class Initialized
DEBUG - 2024-02-27 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:59:05 --> Input Class Initialized
INFO - 2024-02-27 08:59:05 --> Language Class Initialized
INFO - 2024-02-27 08:59:05 --> Loader Class Initialized
INFO - 2024-02-27 08:59:05 --> Helper loaded: url_helper
INFO - 2024-02-27 08:59:05 --> Helper loaded: file_helper
INFO - 2024-02-27 08:59:05 --> Helper loaded: html_helper
INFO - 2024-02-27 08:59:05 --> Helper loaded: text_helper
INFO - 2024-02-27 08:59:05 --> Helper loaded: form_helper
INFO - 2024-02-27 08:59:05 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:59:05 --> Helper loaded: security_helper
INFO - 2024-02-27 08:59:05 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:59:05 --> Database Driver Class Initialized
INFO - 2024-02-27 08:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:59:05 --> Parser Class Initialized
INFO - 2024-02-27 08:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:59:05 --> Pagination Class Initialized
INFO - 2024-02-27 08:59:05 --> Form Validation Class Initialized
INFO - 2024-02-27 08:59:05 --> Controller Class Initialized
INFO - 2024-02-27 08:59:05 --> Model Class Initialized
INFO - 2024-02-27 08:59:05 --> Model Class Initialized
INFO - 2024-02-27 08:59:05 --> Final output sent to browser
DEBUG - 2024-02-27 08:59:05 --> Total execution time: 0.0793
ERROR - 2024-02-27 08:59:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:59:23 --> Config Class Initialized
INFO - 2024-02-27 08:59:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:59:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:59:23 --> Utf8 Class Initialized
INFO - 2024-02-27 08:59:23 --> URI Class Initialized
INFO - 2024-02-27 08:59:23 --> Router Class Initialized
INFO - 2024-02-27 08:59:23 --> Output Class Initialized
INFO - 2024-02-27 08:59:23 --> Security Class Initialized
DEBUG - 2024-02-27 08:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:59:23 --> Input Class Initialized
INFO - 2024-02-27 08:59:23 --> Language Class Initialized
INFO - 2024-02-27 08:59:23 --> Loader Class Initialized
INFO - 2024-02-27 08:59:23 --> Helper loaded: url_helper
INFO - 2024-02-27 08:59:23 --> Helper loaded: file_helper
INFO - 2024-02-27 08:59:23 --> Helper loaded: html_helper
INFO - 2024-02-27 08:59:23 --> Helper loaded: text_helper
INFO - 2024-02-27 08:59:23 --> Helper loaded: form_helper
INFO - 2024-02-27 08:59:23 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:59:23 --> Helper loaded: security_helper
INFO - 2024-02-27 08:59:23 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:59:23 --> Database Driver Class Initialized
INFO - 2024-02-27 08:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:59:23 --> Parser Class Initialized
INFO - 2024-02-27 08:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:59:23 --> Pagination Class Initialized
INFO - 2024-02-27 08:59:23 --> Form Validation Class Initialized
INFO - 2024-02-27 08:59:23 --> Controller Class Initialized
INFO - 2024-02-27 08:59:23 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:23 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:23 --> Model Class Initialized
INFO - 2024-02-27 08:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-27 08:59:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:59:23 --> Model Class Initialized
INFO - 2024-02-27 08:59:23 --> Model Class Initialized
INFO - 2024-02-27 08:59:23 --> Model Class Initialized
INFO - 2024-02-27 08:59:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:59:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:59:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:59:24 --> Final output sent to browser
DEBUG - 2024-02-27 08:59:24 --> Total execution time: 0.2402
ERROR - 2024-02-27 08:59:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:59:26 --> Config Class Initialized
INFO - 2024-02-27 08:59:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:59:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:59:26 --> Utf8 Class Initialized
INFO - 2024-02-27 08:59:26 --> URI Class Initialized
INFO - 2024-02-27 08:59:26 --> Router Class Initialized
INFO - 2024-02-27 08:59:26 --> Output Class Initialized
INFO - 2024-02-27 08:59:26 --> Security Class Initialized
DEBUG - 2024-02-27 08:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:59:26 --> Input Class Initialized
INFO - 2024-02-27 08:59:26 --> Language Class Initialized
INFO - 2024-02-27 08:59:26 --> Loader Class Initialized
INFO - 2024-02-27 08:59:26 --> Helper loaded: url_helper
INFO - 2024-02-27 08:59:26 --> Helper loaded: file_helper
INFO - 2024-02-27 08:59:26 --> Helper loaded: html_helper
INFO - 2024-02-27 08:59:26 --> Helper loaded: text_helper
INFO - 2024-02-27 08:59:26 --> Helper loaded: form_helper
INFO - 2024-02-27 08:59:26 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:59:26 --> Helper loaded: security_helper
INFO - 2024-02-27 08:59:26 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:59:26 --> Database Driver Class Initialized
INFO - 2024-02-27 08:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:59:26 --> Parser Class Initialized
INFO - 2024-02-27 08:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:59:26 --> Pagination Class Initialized
INFO - 2024-02-27 08:59:26 --> Form Validation Class Initialized
INFO - 2024-02-27 08:59:26 --> Controller Class Initialized
INFO - 2024-02-27 08:59:26 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:26 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:26 --> Model Class Initialized
INFO - 2024-02-27 08:59:26 --> Final output sent to browser
DEBUG - 2024-02-27 08:59:26 --> Total execution time: 0.0666
ERROR - 2024-02-27 08:59:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:59:29 --> Config Class Initialized
INFO - 2024-02-27 08:59:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:59:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:59:29 --> Utf8 Class Initialized
INFO - 2024-02-27 08:59:29 --> URI Class Initialized
INFO - 2024-02-27 08:59:29 --> Router Class Initialized
INFO - 2024-02-27 08:59:29 --> Output Class Initialized
INFO - 2024-02-27 08:59:29 --> Security Class Initialized
DEBUG - 2024-02-27 08:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:59:29 --> Input Class Initialized
INFO - 2024-02-27 08:59:29 --> Language Class Initialized
INFO - 2024-02-27 08:59:29 --> Loader Class Initialized
INFO - 2024-02-27 08:59:29 --> Helper loaded: url_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: file_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: html_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: text_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: form_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: security_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:59:29 --> Database Driver Class Initialized
INFO - 2024-02-27 08:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:59:29 --> Parser Class Initialized
INFO - 2024-02-27 08:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:59:29 --> Pagination Class Initialized
INFO - 2024-02-27 08:59:29 --> Form Validation Class Initialized
INFO - 2024-02-27 08:59:29 --> Controller Class Initialized
INFO - 2024-02-27 08:59:29 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:29 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:29 --> Model Class Initialized
INFO - 2024-02-27 08:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2024-02-27 08:59:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:59:29 --> Model Class Initialized
INFO - 2024-02-27 08:59:29 --> Model Class Initialized
INFO - 2024-02-27 08:59:29 --> Model Class Initialized
INFO - 2024-02-27 08:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:59:29 --> Final output sent to browser
DEBUG - 2024-02-27 08:59:29 --> Total execution time: 0.2260
ERROR - 2024-02-27 08:59:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:59:29 --> Config Class Initialized
INFO - 2024-02-27 08:59:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:59:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:59:29 --> Utf8 Class Initialized
INFO - 2024-02-27 08:59:29 --> URI Class Initialized
INFO - 2024-02-27 08:59:29 --> Router Class Initialized
INFO - 2024-02-27 08:59:29 --> Output Class Initialized
INFO - 2024-02-27 08:59:29 --> Security Class Initialized
DEBUG - 2024-02-27 08:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:59:29 --> Input Class Initialized
INFO - 2024-02-27 08:59:29 --> Language Class Initialized
INFO - 2024-02-27 08:59:29 --> Loader Class Initialized
INFO - 2024-02-27 08:59:29 --> Helper loaded: url_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: file_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: html_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: text_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: form_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: security_helper
INFO - 2024-02-27 08:59:29 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:59:29 --> Database Driver Class Initialized
INFO - 2024-02-27 08:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:59:29 --> Parser Class Initialized
INFO - 2024-02-27 08:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:59:29 --> Pagination Class Initialized
INFO - 2024-02-27 08:59:29 --> Form Validation Class Initialized
INFO - 2024-02-27 08:59:29 --> Controller Class Initialized
INFO - 2024-02-27 08:59:29 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:29 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:29 --> Model Class Initialized
INFO - 2024-02-27 08:59:29 --> Final output sent to browser
DEBUG - 2024-02-27 08:59:29 --> Total execution time: 0.0568
ERROR - 2024-02-27 08:59:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 08:59:38 --> Config Class Initialized
INFO - 2024-02-27 08:59:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 08:59:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 08:59:38 --> Utf8 Class Initialized
INFO - 2024-02-27 08:59:38 --> URI Class Initialized
INFO - 2024-02-27 08:59:38 --> Router Class Initialized
INFO - 2024-02-27 08:59:38 --> Output Class Initialized
INFO - 2024-02-27 08:59:38 --> Security Class Initialized
DEBUG - 2024-02-27 08:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 08:59:38 --> Input Class Initialized
INFO - 2024-02-27 08:59:38 --> Language Class Initialized
INFO - 2024-02-27 08:59:38 --> Loader Class Initialized
INFO - 2024-02-27 08:59:38 --> Helper loaded: url_helper
INFO - 2024-02-27 08:59:38 --> Helper loaded: file_helper
INFO - 2024-02-27 08:59:38 --> Helper loaded: html_helper
INFO - 2024-02-27 08:59:38 --> Helper loaded: text_helper
INFO - 2024-02-27 08:59:38 --> Helper loaded: form_helper
INFO - 2024-02-27 08:59:38 --> Helper loaded: lang_helper
INFO - 2024-02-27 08:59:38 --> Helper loaded: security_helper
INFO - 2024-02-27 08:59:38 --> Helper loaded: cookie_helper
INFO - 2024-02-27 08:59:38 --> Database Driver Class Initialized
INFO - 2024-02-27 08:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 08:59:38 --> Parser Class Initialized
INFO - 2024-02-27 08:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 08:59:38 --> Pagination Class Initialized
INFO - 2024-02-27 08:59:38 --> Form Validation Class Initialized
INFO - 2024-02-27 08:59:38 --> Controller Class Initialized
INFO - 2024-02-27 08:59:38 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:38 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:38 --> Model Class Initialized
INFO - 2024-02-27 08:59:38 --> Model Class Initialized
INFO - 2024-02-27 08:59:38 --> Model Class Initialized
INFO - 2024-02-27 08:59:38 --> Model Class Initialized
DEBUG - 2024-02-27 08:59:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 08:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:38 --> Model Class Initialized
INFO - 2024-02-27 08:59:38 --> Model Class Initialized
INFO - 2024-02-27 08:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 08:59:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 08:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 08:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 08:59:39 --> Model Class Initialized
INFO - 2024-02-27 08:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 08:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 08:59:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 08:59:39 --> Final output sent to browser
DEBUG - 2024-02-27 08:59:39 --> Total execution time: 0.2252
ERROR - 2024-02-27 09:00:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:00:50 --> Config Class Initialized
INFO - 2024-02-27 09:00:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:00:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:00:50 --> Utf8 Class Initialized
INFO - 2024-02-27 09:00:50 --> URI Class Initialized
INFO - 2024-02-27 09:00:50 --> Router Class Initialized
INFO - 2024-02-27 09:00:50 --> Output Class Initialized
INFO - 2024-02-27 09:00:50 --> Security Class Initialized
DEBUG - 2024-02-27 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:00:50 --> Input Class Initialized
INFO - 2024-02-27 09:00:50 --> Language Class Initialized
INFO - 2024-02-27 09:00:50 --> Loader Class Initialized
INFO - 2024-02-27 09:00:50 --> Helper loaded: url_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: file_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: html_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: text_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: form_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: security_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:00:50 --> Database Driver Class Initialized
INFO - 2024-02-27 09:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:00:50 --> Parser Class Initialized
INFO - 2024-02-27 09:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:00:50 --> Pagination Class Initialized
INFO - 2024-02-27 09:00:50 --> Form Validation Class Initialized
INFO - 2024-02-27 09:00:50 --> Controller Class Initialized
INFO - 2024-02-27 09:00:50 --> Model Class Initialized
DEBUG - 2024-02-27 09:00:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:00:50 --> Model Class Initialized
DEBUG - 2024-02-27 09:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:00:50 --> Model Class Initialized
INFO - 2024-02-27 09:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-27 09:00:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:00:50 --> Model Class Initialized
INFO - 2024-02-27 09:00:50 --> Model Class Initialized
INFO - 2024-02-27 09:00:50 --> Model Class Initialized
INFO - 2024-02-27 09:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 09:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 09:00:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:00:50 --> Final output sent to browser
DEBUG - 2024-02-27 09:00:50 --> Total execution time: 0.2341
ERROR - 2024-02-27 09:00:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:00:50 --> Config Class Initialized
INFO - 2024-02-27 09:00:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:00:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:00:50 --> Utf8 Class Initialized
INFO - 2024-02-27 09:00:50 --> URI Class Initialized
INFO - 2024-02-27 09:00:50 --> Router Class Initialized
INFO - 2024-02-27 09:00:50 --> Output Class Initialized
INFO - 2024-02-27 09:00:50 --> Security Class Initialized
DEBUG - 2024-02-27 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:00:50 --> Input Class Initialized
INFO - 2024-02-27 09:00:50 --> Language Class Initialized
INFO - 2024-02-27 09:00:50 --> Loader Class Initialized
INFO - 2024-02-27 09:00:50 --> Helper loaded: url_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: file_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: html_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: text_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: form_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: security_helper
INFO - 2024-02-27 09:00:50 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:00:50 --> Database Driver Class Initialized
INFO - 2024-02-27 09:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:00:50 --> Parser Class Initialized
INFO - 2024-02-27 09:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:00:50 --> Pagination Class Initialized
INFO - 2024-02-27 09:00:50 --> Form Validation Class Initialized
INFO - 2024-02-27 09:00:50 --> Controller Class Initialized
INFO - 2024-02-27 09:00:50 --> Model Class Initialized
DEBUG - 2024-02-27 09:00:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:00:50 --> Model Class Initialized
DEBUG - 2024-02-27 09:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:00:50 --> Model Class Initialized
INFO - 2024-02-27 09:00:50 --> Final output sent to browser
DEBUG - 2024-02-27 09:00:50 --> Total execution time: 0.0618
ERROR - 2024-02-27 09:01:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:01:52 --> Config Class Initialized
INFO - 2024-02-27 09:01:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:01:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:01:52 --> Utf8 Class Initialized
INFO - 2024-02-27 09:01:52 --> URI Class Initialized
DEBUG - 2024-02-27 09:01:52 --> No URI present. Default controller set.
INFO - 2024-02-27 09:01:52 --> Router Class Initialized
INFO - 2024-02-27 09:01:52 --> Output Class Initialized
INFO - 2024-02-27 09:01:52 --> Security Class Initialized
DEBUG - 2024-02-27 09:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:01:52 --> Input Class Initialized
INFO - 2024-02-27 09:01:52 --> Language Class Initialized
INFO - 2024-02-27 09:01:52 --> Loader Class Initialized
INFO - 2024-02-27 09:01:52 --> Helper loaded: url_helper
INFO - 2024-02-27 09:01:52 --> Helper loaded: file_helper
INFO - 2024-02-27 09:01:52 --> Helper loaded: html_helper
INFO - 2024-02-27 09:01:52 --> Helper loaded: text_helper
INFO - 2024-02-27 09:01:52 --> Helper loaded: form_helper
INFO - 2024-02-27 09:01:52 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:01:52 --> Helper loaded: security_helper
INFO - 2024-02-27 09:01:52 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:01:52 --> Database Driver Class Initialized
INFO - 2024-02-27 09:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:01:52 --> Parser Class Initialized
INFO - 2024-02-27 09:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:01:52 --> Pagination Class Initialized
INFO - 2024-02-27 09:01:52 --> Form Validation Class Initialized
INFO - 2024-02-27 09:01:52 --> Controller Class Initialized
INFO - 2024-02-27 09:01:52 --> Model Class Initialized
DEBUG - 2024-02-27 09:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:01:52 --> Model Class Initialized
DEBUG - 2024-02-27 09:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:01:52 --> Model Class Initialized
INFO - 2024-02-27 09:01:52 --> Model Class Initialized
INFO - 2024-02-27 09:01:52 --> Model Class Initialized
INFO - 2024-02-27 09:01:52 --> Model Class Initialized
DEBUG - 2024-02-27 09:01:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:01:52 --> Model Class Initialized
INFO - 2024-02-27 09:01:52 --> Model Class Initialized
INFO - 2024-02-27 09:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 09:01:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:01:52 --> Model Class Initialized
INFO - 2024-02-27 09:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 09:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 09:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:01:52 --> Final output sent to browser
DEBUG - 2024-02-27 09:01:52 --> Total execution time: 0.4177
ERROR - 2024-02-27 09:02:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:02:08 --> Config Class Initialized
INFO - 2024-02-27 09:02:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:02:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:02:08 --> Utf8 Class Initialized
INFO - 2024-02-27 09:02:08 --> URI Class Initialized
INFO - 2024-02-27 09:02:08 --> Router Class Initialized
INFO - 2024-02-27 09:02:08 --> Output Class Initialized
INFO - 2024-02-27 09:02:08 --> Security Class Initialized
DEBUG - 2024-02-27 09:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:02:08 --> Input Class Initialized
INFO - 2024-02-27 09:02:08 --> Language Class Initialized
INFO - 2024-02-27 09:02:08 --> Loader Class Initialized
INFO - 2024-02-27 09:02:08 --> Helper loaded: url_helper
INFO - 2024-02-27 09:02:08 --> Helper loaded: file_helper
INFO - 2024-02-27 09:02:08 --> Helper loaded: html_helper
INFO - 2024-02-27 09:02:08 --> Helper loaded: text_helper
INFO - 2024-02-27 09:02:08 --> Helper loaded: form_helper
INFO - 2024-02-27 09:02:08 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:02:08 --> Helper loaded: security_helper
INFO - 2024-02-27 09:02:08 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:02:08 --> Database Driver Class Initialized
INFO - 2024-02-27 09:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:02:08 --> Parser Class Initialized
INFO - 2024-02-27 09:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:02:08 --> Pagination Class Initialized
INFO - 2024-02-27 09:02:08 --> Form Validation Class Initialized
INFO - 2024-02-27 09:02:08 --> Controller Class Initialized
INFO - 2024-02-27 09:02:08 --> Model Class Initialized
DEBUG - 2024-02-27 09:02:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:08 --> Final output sent to browser
DEBUG - 2024-02-27 09:02:08 --> Total execution time: 0.0150
ERROR - 2024-02-27 09:02:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:02:09 --> Config Class Initialized
INFO - 2024-02-27 09:02:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:02:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:02:09 --> Utf8 Class Initialized
INFO - 2024-02-27 09:02:09 --> URI Class Initialized
INFO - 2024-02-27 09:02:09 --> Router Class Initialized
INFO - 2024-02-27 09:02:09 --> Output Class Initialized
INFO - 2024-02-27 09:02:09 --> Security Class Initialized
DEBUG - 2024-02-27 09:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:02:09 --> Input Class Initialized
INFO - 2024-02-27 09:02:09 --> Language Class Initialized
INFO - 2024-02-27 09:02:09 --> Loader Class Initialized
INFO - 2024-02-27 09:02:09 --> Helper loaded: url_helper
INFO - 2024-02-27 09:02:09 --> Helper loaded: file_helper
INFO - 2024-02-27 09:02:09 --> Helper loaded: html_helper
INFO - 2024-02-27 09:02:09 --> Helper loaded: text_helper
INFO - 2024-02-27 09:02:09 --> Helper loaded: form_helper
INFO - 2024-02-27 09:02:09 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:02:09 --> Helper loaded: security_helper
INFO - 2024-02-27 09:02:09 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:02:09 --> Database Driver Class Initialized
INFO - 2024-02-27 09:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:02:09 --> Parser Class Initialized
INFO - 2024-02-27 09:02:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:02:09 --> Pagination Class Initialized
INFO - 2024-02-27 09:02:09 --> Form Validation Class Initialized
INFO - 2024-02-27 09:02:09 --> Controller Class Initialized
INFO - 2024-02-27 09:02:09 --> Model Class Initialized
DEBUG - 2024-02-27 09:02:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 09:02:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:02:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:02:09 --> Model Class Initialized
INFO - 2024-02-27 09:02:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:02:09 --> Final output sent to browser
DEBUG - 2024-02-27 09:02:09 --> Total execution time: 0.0303
ERROR - 2024-02-27 09:02:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:02:17 --> Config Class Initialized
INFO - 2024-02-27 09:02:17 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:02:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:02:17 --> Utf8 Class Initialized
INFO - 2024-02-27 09:02:17 --> URI Class Initialized
INFO - 2024-02-27 09:02:17 --> Router Class Initialized
INFO - 2024-02-27 09:02:17 --> Output Class Initialized
INFO - 2024-02-27 09:02:17 --> Security Class Initialized
DEBUG - 2024-02-27 09:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:02:17 --> Input Class Initialized
INFO - 2024-02-27 09:02:17 --> Language Class Initialized
INFO - 2024-02-27 09:02:17 --> Loader Class Initialized
INFO - 2024-02-27 09:02:17 --> Helper loaded: url_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: file_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: html_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: text_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: form_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: security_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:02:17 --> Database Driver Class Initialized
INFO - 2024-02-27 09:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:02:17 --> Parser Class Initialized
INFO - 2024-02-27 09:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:02:17 --> Pagination Class Initialized
INFO - 2024-02-27 09:02:17 --> Form Validation Class Initialized
INFO - 2024-02-27 09:02:17 --> Controller Class Initialized
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
DEBUG - 2024-02-27 09:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
INFO - 2024-02-27 09:02:17 --> Final output sent to browser
DEBUG - 2024-02-27 09:02:17 --> Total execution time: 0.0214
ERROR - 2024-02-27 09:02:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:02:17 --> Config Class Initialized
INFO - 2024-02-27 09:02:17 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:02:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:02:17 --> Utf8 Class Initialized
INFO - 2024-02-27 09:02:17 --> URI Class Initialized
DEBUG - 2024-02-27 09:02:17 --> No URI present. Default controller set.
INFO - 2024-02-27 09:02:17 --> Router Class Initialized
INFO - 2024-02-27 09:02:17 --> Output Class Initialized
INFO - 2024-02-27 09:02:17 --> Security Class Initialized
DEBUG - 2024-02-27 09:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:02:17 --> Input Class Initialized
INFO - 2024-02-27 09:02:17 --> Language Class Initialized
INFO - 2024-02-27 09:02:17 --> Loader Class Initialized
INFO - 2024-02-27 09:02:17 --> Helper loaded: url_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: file_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: html_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: text_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: form_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: security_helper
INFO - 2024-02-27 09:02:17 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:02:17 --> Database Driver Class Initialized
INFO - 2024-02-27 09:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:02:17 --> Parser Class Initialized
INFO - 2024-02-27 09:02:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:02:17 --> Pagination Class Initialized
INFO - 2024-02-27 09:02:17 --> Form Validation Class Initialized
INFO - 2024-02-27 09:02:17 --> Controller Class Initialized
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
DEBUG - 2024-02-27 09:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
DEBUG - 2024-02-27 09:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
DEBUG - 2024-02-27 09:02:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
INFO - 2024-02-27 09:02:17 --> Model Class Initialized
INFO - 2024-02-27 09:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 09:02:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:02:18 --> Model Class Initialized
INFO - 2024-02-27 09:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 09:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 09:02:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:02:18 --> Final output sent to browser
DEBUG - 2024-02-27 09:02:18 --> Total execution time: 0.2446
ERROR - 2024-02-27 09:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:02:31 --> Config Class Initialized
INFO - 2024-02-27 09:02:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:02:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:02:31 --> Utf8 Class Initialized
INFO - 2024-02-27 09:02:31 --> URI Class Initialized
INFO - 2024-02-27 09:02:31 --> Router Class Initialized
INFO - 2024-02-27 09:02:31 --> Output Class Initialized
INFO - 2024-02-27 09:02:31 --> Security Class Initialized
DEBUG - 2024-02-27 09:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:02:31 --> Input Class Initialized
INFO - 2024-02-27 09:02:31 --> Language Class Initialized
INFO - 2024-02-27 09:02:31 --> Loader Class Initialized
INFO - 2024-02-27 09:02:31 --> Helper loaded: url_helper
INFO - 2024-02-27 09:02:31 --> Helper loaded: file_helper
INFO - 2024-02-27 09:02:31 --> Helper loaded: html_helper
INFO - 2024-02-27 09:02:31 --> Helper loaded: text_helper
INFO - 2024-02-27 09:02:31 --> Helper loaded: form_helper
INFO - 2024-02-27 09:02:31 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:02:31 --> Helper loaded: security_helper
INFO - 2024-02-27 09:02:31 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:02:31 --> Database Driver Class Initialized
INFO - 2024-02-27 09:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:02:31 --> Parser Class Initialized
INFO - 2024-02-27 09:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:02:31 --> Pagination Class Initialized
INFO - 2024-02-27 09:02:31 --> Form Validation Class Initialized
INFO - 2024-02-27 09:02:31 --> Controller Class Initialized
INFO - 2024-02-27 09:02:31 --> Model Class Initialized
DEBUG - 2024-02-27 09:02:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:31 --> Model Class Initialized
INFO - 2024-02-27 09:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-02-27 09:02:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:02:31 --> Model Class Initialized
INFO - 2024-02-27 09:02:31 --> Model Class Initialized
INFO - 2024-02-27 09:02:31 --> Model Class Initialized
INFO - 2024-02-27 09:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 09:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 09:02:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:02:31 --> Final output sent to browser
DEBUG - 2024-02-27 09:02:31 --> Total execution time: 0.1570
ERROR - 2024-02-27 09:02:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:02:32 --> Config Class Initialized
INFO - 2024-02-27 09:02:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:02:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:02:32 --> Utf8 Class Initialized
INFO - 2024-02-27 09:02:32 --> URI Class Initialized
INFO - 2024-02-27 09:02:32 --> Router Class Initialized
INFO - 2024-02-27 09:02:32 --> Output Class Initialized
INFO - 2024-02-27 09:02:32 --> Security Class Initialized
DEBUG - 2024-02-27 09:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:02:32 --> Input Class Initialized
INFO - 2024-02-27 09:02:32 --> Language Class Initialized
INFO - 2024-02-27 09:02:32 --> Loader Class Initialized
INFO - 2024-02-27 09:02:32 --> Helper loaded: url_helper
INFO - 2024-02-27 09:02:32 --> Helper loaded: file_helper
INFO - 2024-02-27 09:02:32 --> Helper loaded: html_helper
INFO - 2024-02-27 09:02:32 --> Helper loaded: text_helper
INFO - 2024-02-27 09:02:32 --> Helper loaded: form_helper
INFO - 2024-02-27 09:02:32 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:02:32 --> Helper loaded: security_helper
INFO - 2024-02-27 09:02:32 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:02:32 --> Database Driver Class Initialized
INFO - 2024-02-27 09:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:02:32 --> Parser Class Initialized
INFO - 2024-02-27 09:02:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:02:32 --> Pagination Class Initialized
INFO - 2024-02-27 09:02:32 --> Form Validation Class Initialized
INFO - 2024-02-27 09:02:32 --> Controller Class Initialized
INFO - 2024-02-27 09:02:32 --> Model Class Initialized
DEBUG - 2024-02-27 09:02:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:32 --> Model Class Initialized
INFO - 2024-02-27 09:02:32 --> Final output sent to browser
DEBUG - 2024-02-27 09:02:32 --> Total execution time: 0.0283
ERROR - 2024-02-27 09:02:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:02:37 --> Config Class Initialized
INFO - 2024-02-27 09:02:37 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:02:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:02:37 --> Utf8 Class Initialized
INFO - 2024-02-27 09:02:37 --> URI Class Initialized
INFO - 2024-02-27 09:02:37 --> Router Class Initialized
INFO - 2024-02-27 09:02:37 --> Output Class Initialized
INFO - 2024-02-27 09:02:37 --> Security Class Initialized
DEBUG - 2024-02-27 09:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:02:37 --> Input Class Initialized
INFO - 2024-02-27 09:02:37 --> Language Class Initialized
INFO - 2024-02-27 09:02:37 --> Loader Class Initialized
INFO - 2024-02-27 09:02:37 --> Helper loaded: url_helper
INFO - 2024-02-27 09:02:37 --> Helper loaded: file_helper
INFO - 2024-02-27 09:02:37 --> Helper loaded: html_helper
INFO - 2024-02-27 09:02:37 --> Helper loaded: text_helper
INFO - 2024-02-27 09:02:37 --> Helper loaded: form_helper
INFO - 2024-02-27 09:02:37 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:02:37 --> Helper loaded: security_helper
INFO - 2024-02-27 09:02:37 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:02:37 --> Database Driver Class Initialized
INFO - 2024-02-27 09:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:02:37 --> Parser Class Initialized
INFO - 2024-02-27 09:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:02:37 --> Pagination Class Initialized
INFO - 2024-02-27 09:02:37 --> Form Validation Class Initialized
INFO - 2024-02-27 09:02:37 --> Controller Class Initialized
INFO - 2024-02-27 09:02:37 --> Model Class Initialized
DEBUG - 2024-02-27 09:02:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:02:37 --> Model Class Initialized
INFO - 2024-02-27 09:02:37 --> Final output sent to browser
DEBUG - 2024-02-27 09:02:37 --> Total execution time: 0.0507
ERROR - 2024-02-27 09:03:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:03:12 --> Config Class Initialized
INFO - 2024-02-27 09:03:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:03:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:03:12 --> Utf8 Class Initialized
INFO - 2024-02-27 09:03:12 --> URI Class Initialized
DEBUG - 2024-02-27 09:03:12 --> No URI present. Default controller set.
INFO - 2024-02-27 09:03:12 --> Router Class Initialized
INFO - 2024-02-27 09:03:12 --> Output Class Initialized
INFO - 2024-02-27 09:03:12 --> Security Class Initialized
DEBUG - 2024-02-27 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:03:12 --> Input Class Initialized
INFO - 2024-02-27 09:03:12 --> Language Class Initialized
INFO - 2024-02-27 09:03:12 --> Loader Class Initialized
INFO - 2024-02-27 09:03:12 --> Helper loaded: url_helper
INFO - 2024-02-27 09:03:12 --> Helper loaded: file_helper
INFO - 2024-02-27 09:03:12 --> Helper loaded: html_helper
INFO - 2024-02-27 09:03:12 --> Helper loaded: text_helper
INFO - 2024-02-27 09:03:12 --> Helper loaded: form_helper
INFO - 2024-02-27 09:03:12 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:03:12 --> Helper loaded: security_helper
INFO - 2024-02-27 09:03:12 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:03:12 --> Database Driver Class Initialized
INFO - 2024-02-27 09:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:03:12 --> Parser Class Initialized
INFO - 2024-02-27 09:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:03:12 --> Pagination Class Initialized
INFO - 2024-02-27 09:03:12 --> Form Validation Class Initialized
INFO - 2024-02-27 09:03:12 --> Controller Class Initialized
INFO - 2024-02-27 09:03:12 --> Model Class Initialized
DEBUG - 2024-02-27 09:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:03:12 --> Model Class Initialized
DEBUG - 2024-02-27 09:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:03:12 --> Model Class Initialized
INFO - 2024-02-27 09:03:12 --> Model Class Initialized
INFO - 2024-02-27 09:03:12 --> Model Class Initialized
INFO - 2024-02-27 09:03:12 --> Model Class Initialized
DEBUG - 2024-02-27 09:03:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:03:12 --> Model Class Initialized
INFO - 2024-02-27 09:03:12 --> Model Class Initialized
INFO - 2024-02-27 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 09:03:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:03:12 --> Model Class Initialized
INFO - 2024-02-27 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 09:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:03:12 --> Final output sent to browser
DEBUG - 2024-02-27 09:03:12 --> Total execution time: 0.2450
ERROR - 2024-02-27 09:04:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:04:07 --> Config Class Initialized
INFO - 2024-02-27 09:04:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:04:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:04:07 --> Utf8 Class Initialized
INFO - 2024-02-27 09:04:07 --> URI Class Initialized
INFO - 2024-02-27 09:04:07 --> Router Class Initialized
INFO - 2024-02-27 09:04:07 --> Output Class Initialized
INFO - 2024-02-27 09:04:07 --> Security Class Initialized
DEBUG - 2024-02-27 09:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:04:07 --> Input Class Initialized
INFO - 2024-02-27 09:04:07 --> Language Class Initialized
INFO - 2024-02-27 09:04:07 --> Loader Class Initialized
INFO - 2024-02-27 09:04:07 --> Helper loaded: url_helper
INFO - 2024-02-27 09:04:07 --> Helper loaded: file_helper
INFO - 2024-02-27 09:04:07 --> Helper loaded: html_helper
INFO - 2024-02-27 09:04:07 --> Helper loaded: text_helper
INFO - 2024-02-27 09:04:07 --> Helper loaded: form_helper
INFO - 2024-02-27 09:04:07 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:04:07 --> Helper loaded: security_helper
INFO - 2024-02-27 09:04:07 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:04:07 --> Database Driver Class Initialized
INFO - 2024-02-27 09:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:04:07 --> Parser Class Initialized
INFO - 2024-02-27 09:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:04:07 --> Pagination Class Initialized
INFO - 2024-02-27 09:04:07 --> Form Validation Class Initialized
INFO - 2024-02-27 09:04:07 --> Controller Class Initialized
INFO - 2024-02-27 09:04:07 --> Model Class Initialized
DEBUG - 2024-02-27 09:04:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:07 --> Model Class Initialized
DEBUG - 2024-02-27 09:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:07 --> Model Class Initialized
INFO - 2024-02-27 09:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-27 09:04:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:04:07 --> Model Class Initialized
INFO - 2024-02-27 09:04:07 --> Model Class Initialized
INFO - 2024-02-27 09:04:07 --> Model Class Initialized
INFO - 2024-02-27 09:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 09:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 09:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:04:08 --> Final output sent to browser
DEBUG - 2024-02-27 09:04:08 --> Total execution time: 0.1613
ERROR - 2024-02-27 09:04:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:04:08 --> Config Class Initialized
INFO - 2024-02-27 09:04:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:04:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:04:08 --> Utf8 Class Initialized
INFO - 2024-02-27 09:04:08 --> URI Class Initialized
INFO - 2024-02-27 09:04:08 --> Router Class Initialized
INFO - 2024-02-27 09:04:08 --> Output Class Initialized
INFO - 2024-02-27 09:04:08 --> Security Class Initialized
DEBUG - 2024-02-27 09:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:04:08 --> Input Class Initialized
INFO - 2024-02-27 09:04:08 --> Language Class Initialized
INFO - 2024-02-27 09:04:08 --> Loader Class Initialized
INFO - 2024-02-27 09:04:08 --> Helper loaded: url_helper
INFO - 2024-02-27 09:04:08 --> Helper loaded: file_helper
INFO - 2024-02-27 09:04:08 --> Helper loaded: html_helper
INFO - 2024-02-27 09:04:08 --> Helper loaded: text_helper
INFO - 2024-02-27 09:04:08 --> Helper loaded: form_helper
INFO - 2024-02-27 09:04:08 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:04:08 --> Helper loaded: security_helper
INFO - 2024-02-27 09:04:08 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:04:08 --> Database Driver Class Initialized
INFO - 2024-02-27 09:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:04:08 --> Parser Class Initialized
INFO - 2024-02-27 09:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:04:08 --> Pagination Class Initialized
INFO - 2024-02-27 09:04:08 --> Form Validation Class Initialized
INFO - 2024-02-27 09:04:08 --> Controller Class Initialized
INFO - 2024-02-27 09:04:08 --> Model Class Initialized
DEBUG - 2024-02-27 09:04:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:08 --> Model Class Initialized
DEBUG - 2024-02-27 09:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:08 --> Model Class Initialized
INFO - 2024-02-27 09:04:08 --> Final output sent to browser
DEBUG - 2024-02-27 09:04:08 --> Total execution time: 0.0409
ERROR - 2024-02-27 09:04:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:04:24 --> Config Class Initialized
INFO - 2024-02-27 09:04:24 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:04:24 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:04:24 --> Utf8 Class Initialized
INFO - 2024-02-27 09:04:24 --> URI Class Initialized
DEBUG - 2024-02-27 09:04:24 --> No URI present. Default controller set.
INFO - 2024-02-27 09:04:24 --> Router Class Initialized
INFO - 2024-02-27 09:04:24 --> Output Class Initialized
INFO - 2024-02-27 09:04:24 --> Security Class Initialized
DEBUG - 2024-02-27 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:04:24 --> Input Class Initialized
INFO - 2024-02-27 09:04:24 --> Language Class Initialized
INFO - 2024-02-27 09:04:24 --> Loader Class Initialized
INFO - 2024-02-27 09:04:24 --> Helper loaded: url_helper
INFO - 2024-02-27 09:04:24 --> Helper loaded: file_helper
INFO - 2024-02-27 09:04:24 --> Helper loaded: html_helper
INFO - 2024-02-27 09:04:24 --> Helper loaded: text_helper
INFO - 2024-02-27 09:04:24 --> Helper loaded: form_helper
INFO - 2024-02-27 09:04:24 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:04:24 --> Helper loaded: security_helper
INFO - 2024-02-27 09:04:24 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:04:24 --> Database Driver Class Initialized
INFO - 2024-02-27 09:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:04:24 --> Parser Class Initialized
INFO - 2024-02-27 09:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:04:24 --> Pagination Class Initialized
INFO - 2024-02-27 09:04:24 --> Form Validation Class Initialized
INFO - 2024-02-27 09:04:24 --> Controller Class Initialized
INFO - 2024-02-27 09:04:24 --> Model Class Initialized
DEBUG - 2024-02-27 09:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:24 --> Model Class Initialized
DEBUG - 2024-02-27 09:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:24 --> Model Class Initialized
INFO - 2024-02-27 09:04:24 --> Model Class Initialized
INFO - 2024-02-27 09:04:24 --> Model Class Initialized
INFO - 2024-02-27 09:04:24 --> Model Class Initialized
DEBUG - 2024-02-27 09:04:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:24 --> Model Class Initialized
INFO - 2024-02-27 09:04:24 --> Model Class Initialized
INFO - 2024-02-27 09:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 09:04:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:04:24 --> Model Class Initialized
INFO - 2024-02-27 09:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 09:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 09:04:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:04:24 --> Final output sent to browser
DEBUG - 2024-02-27 09:04:24 --> Total execution time: 0.2431
ERROR - 2024-02-27 09:04:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:04:52 --> Config Class Initialized
INFO - 2024-02-27 09:04:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:04:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:04:52 --> Utf8 Class Initialized
INFO - 2024-02-27 09:04:52 --> URI Class Initialized
INFO - 2024-02-27 09:04:52 --> Router Class Initialized
INFO - 2024-02-27 09:04:52 --> Output Class Initialized
INFO - 2024-02-27 09:04:52 --> Security Class Initialized
DEBUG - 2024-02-27 09:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:04:52 --> Input Class Initialized
INFO - 2024-02-27 09:04:52 --> Language Class Initialized
INFO - 2024-02-27 09:04:52 --> Loader Class Initialized
INFO - 2024-02-27 09:04:52 --> Helper loaded: url_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: file_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: html_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: text_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: form_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: security_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:04:52 --> Database Driver Class Initialized
INFO - 2024-02-27 09:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:04:52 --> Parser Class Initialized
INFO - 2024-02-27 09:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:04:52 --> Pagination Class Initialized
INFO - 2024-02-27 09:04:52 --> Form Validation Class Initialized
INFO - 2024-02-27 09:04:52 --> Controller Class Initialized
INFO - 2024-02-27 09:04:52 --> Model Class Initialized
DEBUG - 2024-02-27 09:04:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:52 --> Model Class Initialized
INFO - 2024-02-27 09:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-02-27 09:04:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:04:52 --> Model Class Initialized
INFO - 2024-02-27 09:04:52 --> Model Class Initialized
INFO - 2024-02-27 09:04:52 --> Model Class Initialized
INFO - 2024-02-27 09:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 09:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 09:04:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:04:52 --> Final output sent to browser
DEBUG - 2024-02-27 09:04:52 --> Total execution time: 0.1560
ERROR - 2024-02-27 09:04:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:04:52 --> Config Class Initialized
INFO - 2024-02-27 09:04:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:04:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:04:52 --> Utf8 Class Initialized
INFO - 2024-02-27 09:04:52 --> URI Class Initialized
INFO - 2024-02-27 09:04:52 --> Router Class Initialized
INFO - 2024-02-27 09:04:52 --> Output Class Initialized
INFO - 2024-02-27 09:04:52 --> Security Class Initialized
DEBUG - 2024-02-27 09:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:04:52 --> Input Class Initialized
INFO - 2024-02-27 09:04:52 --> Language Class Initialized
INFO - 2024-02-27 09:04:52 --> Loader Class Initialized
INFO - 2024-02-27 09:04:52 --> Helper loaded: url_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: file_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: html_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: text_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: form_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: security_helper
INFO - 2024-02-27 09:04:52 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:04:52 --> Database Driver Class Initialized
INFO - 2024-02-27 09:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:04:52 --> Parser Class Initialized
INFO - 2024-02-27 09:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:04:52 --> Pagination Class Initialized
INFO - 2024-02-27 09:04:52 --> Form Validation Class Initialized
INFO - 2024-02-27 09:04:52 --> Controller Class Initialized
INFO - 2024-02-27 09:04:52 --> Model Class Initialized
DEBUG - 2024-02-27 09:04:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:04:52 --> Model Class Initialized
INFO - 2024-02-27 09:04:52 --> Final output sent to browser
DEBUG - 2024-02-27 09:04:52 --> Total execution time: 0.0286
ERROR - 2024-02-27 09:05:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 09:05:41 --> Config Class Initialized
INFO - 2024-02-27 09:05:41 --> Hooks Class Initialized
DEBUG - 2024-02-27 09:05:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 09:05:41 --> Utf8 Class Initialized
INFO - 2024-02-27 09:05:41 --> URI Class Initialized
DEBUG - 2024-02-27 09:05:41 --> No URI present. Default controller set.
INFO - 2024-02-27 09:05:41 --> Router Class Initialized
INFO - 2024-02-27 09:05:41 --> Output Class Initialized
INFO - 2024-02-27 09:05:41 --> Security Class Initialized
DEBUG - 2024-02-27 09:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 09:05:41 --> Input Class Initialized
INFO - 2024-02-27 09:05:41 --> Language Class Initialized
INFO - 2024-02-27 09:05:41 --> Loader Class Initialized
INFO - 2024-02-27 09:05:41 --> Helper loaded: url_helper
INFO - 2024-02-27 09:05:41 --> Helper loaded: file_helper
INFO - 2024-02-27 09:05:41 --> Helper loaded: html_helper
INFO - 2024-02-27 09:05:41 --> Helper loaded: text_helper
INFO - 2024-02-27 09:05:41 --> Helper loaded: form_helper
INFO - 2024-02-27 09:05:41 --> Helper loaded: lang_helper
INFO - 2024-02-27 09:05:41 --> Helper loaded: security_helper
INFO - 2024-02-27 09:05:41 --> Helper loaded: cookie_helper
INFO - 2024-02-27 09:05:41 --> Database Driver Class Initialized
INFO - 2024-02-27 09:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 09:05:41 --> Parser Class Initialized
INFO - 2024-02-27 09:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 09:05:41 --> Pagination Class Initialized
INFO - 2024-02-27 09:05:41 --> Form Validation Class Initialized
INFO - 2024-02-27 09:05:41 --> Controller Class Initialized
INFO - 2024-02-27 09:05:41 --> Model Class Initialized
DEBUG - 2024-02-27 09:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:05:41 --> Model Class Initialized
DEBUG - 2024-02-27 09:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:05:41 --> Model Class Initialized
INFO - 2024-02-27 09:05:41 --> Model Class Initialized
INFO - 2024-02-27 09:05:41 --> Model Class Initialized
INFO - 2024-02-27 09:05:41 --> Model Class Initialized
DEBUG - 2024-02-27 09:05:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 09:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:05:41 --> Model Class Initialized
INFO - 2024-02-27 09:05:41 --> Model Class Initialized
INFO - 2024-02-27 09:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 09:05:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 09:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 09:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 09:05:41 --> Model Class Initialized
INFO - 2024-02-27 09:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 09:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 09:05:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 09:05:41 --> Final output sent to browser
DEBUG - 2024-02-27 09:05:41 --> Total execution time: 0.2410
ERROR - 2024-02-27 11:03:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 11:03:20 --> Config Class Initialized
INFO - 2024-02-27 11:03:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 11:03:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 11:03:20 --> Utf8 Class Initialized
INFO - 2024-02-27 11:03:20 --> URI Class Initialized
DEBUG - 2024-02-27 11:03:20 --> No URI present. Default controller set.
INFO - 2024-02-27 11:03:20 --> Router Class Initialized
INFO - 2024-02-27 11:03:20 --> Output Class Initialized
INFO - 2024-02-27 11:03:20 --> Security Class Initialized
DEBUG - 2024-02-27 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 11:03:20 --> Input Class Initialized
INFO - 2024-02-27 11:03:20 --> Language Class Initialized
INFO - 2024-02-27 11:03:20 --> Loader Class Initialized
INFO - 2024-02-27 11:03:20 --> Helper loaded: url_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: file_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: html_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: text_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: form_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: lang_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: security_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: cookie_helper
INFO - 2024-02-27 11:03:20 --> Database Driver Class Initialized
INFO - 2024-02-27 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 11:03:20 --> Parser Class Initialized
INFO - 2024-02-27 11:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 11:03:20 --> Pagination Class Initialized
INFO - 2024-02-27 11:03:20 --> Form Validation Class Initialized
INFO - 2024-02-27 11:03:20 --> Controller Class Initialized
INFO - 2024-02-27 11:03:20 --> Model Class Initialized
DEBUG - 2024-02-27 11:03:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 11:03:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 11:03:20 --> Config Class Initialized
INFO - 2024-02-27 11:03:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 11:03:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 11:03:20 --> Utf8 Class Initialized
INFO - 2024-02-27 11:03:20 --> URI Class Initialized
INFO - 2024-02-27 11:03:20 --> Router Class Initialized
INFO - 2024-02-27 11:03:20 --> Output Class Initialized
INFO - 2024-02-27 11:03:20 --> Security Class Initialized
DEBUG - 2024-02-27 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 11:03:20 --> Input Class Initialized
INFO - 2024-02-27 11:03:20 --> Language Class Initialized
INFO - 2024-02-27 11:03:20 --> Loader Class Initialized
INFO - 2024-02-27 11:03:20 --> Helper loaded: url_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: file_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: html_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: text_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: form_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: lang_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: security_helper
INFO - 2024-02-27 11:03:20 --> Helper loaded: cookie_helper
INFO - 2024-02-27 11:03:20 --> Database Driver Class Initialized
INFO - 2024-02-27 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 11:03:20 --> Parser Class Initialized
INFO - 2024-02-27 11:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 11:03:20 --> Pagination Class Initialized
INFO - 2024-02-27 11:03:20 --> Form Validation Class Initialized
INFO - 2024-02-27 11:03:20 --> Controller Class Initialized
INFO - 2024-02-27 11:03:20 --> Model Class Initialized
DEBUG - 2024-02-27 11:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 11:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 11:03:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 11:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 11:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 11:03:20 --> Model Class Initialized
INFO - 2024-02-27 11:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 11:03:20 --> Final output sent to browser
DEBUG - 2024-02-27 11:03:20 --> Total execution time: 0.0313
ERROR - 2024-02-27 12:03:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 12:03:11 --> Config Class Initialized
INFO - 2024-02-27 12:03:11 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:03:11 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:03:11 --> Utf8 Class Initialized
INFO - 2024-02-27 12:03:11 --> URI Class Initialized
DEBUG - 2024-02-27 12:03:11 --> No URI present. Default controller set.
INFO - 2024-02-27 12:03:11 --> Router Class Initialized
INFO - 2024-02-27 12:03:11 --> Output Class Initialized
INFO - 2024-02-27 12:03:11 --> Security Class Initialized
DEBUG - 2024-02-27 12:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:03:11 --> Input Class Initialized
INFO - 2024-02-27 12:03:11 --> Language Class Initialized
INFO - 2024-02-27 12:03:11 --> Loader Class Initialized
INFO - 2024-02-27 12:03:11 --> Helper loaded: url_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: file_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: html_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: text_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: form_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: lang_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: security_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: cookie_helper
INFO - 2024-02-27 12:03:11 --> Database Driver Class Initialized
INFO - 2024-02-27 12:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:03:11 --> Parser Class Initialized
INFO - 2024-02-27 12:03:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 12:03:11 --> Pagination Class Initialized
INFO - 2024-02-27 12:03:11 --> Form Validation Class Initialized
INFO - 2024-02-27 12:03:11 --> Controller Class Initialized
INFO - 2024-02-27 12:03:11 --> Model Class Initialized
DEBUG - 2024-02-27 12:03:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 12:03:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 12:03:11 --> Config Class Initialized
INFO - 2024-02-27 12:03:11 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:03:11 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:03:11 --> Utf8 Class Initialized
INFO - 2024-02-27 12:03:11 --> URI Class Initialized
INFO - 2024-02-27 12:03:11 --> Router Class Initialized
INFO - 2024-02-27 12:03:11 --> Output Class Initialized
INFO - 2024-02-27 12:03:11 --> Security Class Initialized
DEBUG - 2024-02-27 12:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:03:11 --> Input Class Initialized
INFO - 2024-02-27 12:03:11 --> Language Class Initialized
INFO - 2024-02-27 12:03:11 --> Loader Class Initialized
INFO - 2024-02-27 12:03:11 --> Helper loaded: url_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: file_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: html_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: text_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: form_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: lang_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: security_helper
INFO - 2024-02-27 12:03:11 --> Helper loaded: cookie_helper
INFO - 2024-02-27 12:03:11 --> Database Driver Class Initialized
INFO - 2024-02-27 12:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:03:12 --> Parser Class Initialized
INFO - 2024-02-27 12:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 12:03:12 --> Pagination Class Initialized
INFO - 2024-02-27 12:03:12 --> Form Validation Class Initialized
INFO - 2024-02-27 12:03:12 --> Controller Class Initialized
INFO - 2024-02-27 12:03:12 --> Model Class Initialized
DEBUG - 2024-02-27 12:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 12:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 12:03:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 12:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 12:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 12:03:12 --> Model Class Initialized
INFO - 2024-02-27 12:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 12:03:12 --> Final output sent to browser
DEBUG - 2024-02-27 12:03:12 --> Total execution time: 0.0349
ERROR - 2024-02-27 14:02:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:02:53 --> Config Class Initialized
INFO - 2024-02-27 14:02:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:02:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:02:53 --> Utf8 Class Initialized
INFO - 2024-02-27 14:02:53 --> URI Class Initialized
DEBUG - 2024-02-27 14:02:53 --> No URI present. Default controller set.
INFO - 2024-02-27 14:02:53 --> Router Class Initialized
INFO - 2024-02-27 14:02:53 --> Output Class Initialized
INFO - 2024-02-27 14:02:53 --> Security Class Initialized
DEBUG - 2024-02-27 14:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:02:53 --> Input Class Initialized
INFO - 2024-02-27 14:02:53 --> Language Class Initialized
INFO - 2024-02-27 14:02:53 --> Loader Class Initialized
INFO - 2024-02-27 14:02:53 --> Helper loaded: url_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: file_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: html_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: text_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: form_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: security_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:02:53 --> Database Driver Class Initialized
INFO - 2024-02-27 14:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:02:53 --> Parser Class Initialized
INFO - 2024-02-27 14:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:02:53 --> Pagination Class Initialized
INFO - 2024-02-27 14:02:53 --> Form Validation Class Initialized
INFO - 2024-02-27 14:02:53 --> Controller Class Initialized
INFO - 2024-02-27 14:02:53 --> Model Class Initialized
DEBUG - 2024-02-27 14:02:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 14:02:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:02:53 --> Config Class Initialized
INFO - 2024-02-27 14:02:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:02:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:02:53 --> Utf8 Class Initialized
INFO - 2024-02-27 14:02:53 --> URI Class Initialized
INFO - 2024-02-27 14:02:53 --> Router Class Initialized
INFO - 2024-02-27 14:02:53 --> Output Class Initialized
INFO - 2024-02-27 14:02:53 --> Security Class Initialized
DEBUG - 2024-02-27 14:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:02:53 --> Input Class Initialized
INFO - 2024-02-27 14:02:53 --> Language Class Initialized
INFO - 2024-02-27 14:02:53 --> Loader Class Initialized
INFO - 2024-02-27 14:02:53 --> Helper loaded: url_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: file_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: html_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: text_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: form_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: security_helper
INFO - 2024-02-27 14:02:53 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:02:53 --> Database Driver Class Initialized
INFO - 2024-02-27 14:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:02:53 --> Parser Class Initialized
INFO - 2024-02-27 14:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:02:53 --> Pagination Class Initialized
INFO - 2024-02-27 14:02:53 --> Form Validation Class Initialized
INFO - 2024-02-27 14:02:53 --> Controller Class Initialized
INFO - 2024-02-27 14:02:53 --> Model Class Initialized
DEBUG - 2024-02-27 14:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 14:02:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:02:53 --> Model Class Initialized
INFO - 2024-02-27 14:02:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:02:53 --> Final output sent to browser
DEBUG - 2024-02-27 14:02:53 --> Total execution time: 0.0336
ERROR - 2024-02-27 14:03:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:02 --> Config Class Initialized
INFO - 2024-02-27 14:03:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:02 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:02 --> URI Class Initialized
INFO - 2024-02-27 14:03:02 --> Router Class Initialized
INFO - 2024-02-27 14:03:02 --> Output Class Initialized
INFO - 2024-02-27 14:03:02 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:02 --> Input Class Initialized
INFO - 2024-02-27 14:03:02 --> Language Class Initialized
INFO - 2024-02-27 14:03:02 --> Loader Class Initialized
INFO - 2024-02-27 14:03:02 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:02 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:02 --> Parser Class Initialized
INFO - 2024-02-27 14:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:02 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:02 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:02 --> Controller Class Initialized
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
INFO - 2024-02-27 14:03:02 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:02 --> Total execution time: 0.0250
ERROR - 2024-02-27 14:03:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:02 --> Config Class Initialized
INFO - 2024-02-27 14:03:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:02 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:02 --> URI Class Initialized
DEBUG - 2024-02-27 14:03:02 --> No URI present. Default controller set.
INFO - 2024-02-27 14:03:02 --> Router Class Initialized
INFO - 2024-02-27 14:03:02 --> Output Class Initialized
INFO - 2024-02-27 14:03:02 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:02 --> Input Class Initialized
INFO - 2024-02-27 14:03:02 --> Language Class Initialized
INFO - 2024-02-27 14:03:02 --> Loader Class Initialized
INFO - 2024-02-27 14:03:02 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:02 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:02 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:02 --> Parser Class Initialized
INFO - 2024-02-27 14:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:02 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:02 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:02 --> Controller Class Initialized
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
INFO - 2024-02-27 14:03:02 --> Model Class Initialized
INFO - 2024-02-27 14:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:03:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:03:03 --> Model Class Initialized
INFO - 2024-02-27 14:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:03:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:03:03 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:03 --> Total execution time: 0.2529
ERROR - 2024-02-27 14:03:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:09 --> Config Class Initialized
INFO - 2024-02-27 14:03:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:09 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:09 --> URI Class Initialized
INFO - 2024-02-27 14:03:09 --> Router Class Initialized
INFO - 2024-02-27 14:03:09 --> Output Class Initialized
INFO - 2024-02-27 14:03:09 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:09 --> Input Class Initialized
INFO - 2024-02-27 14:03:09 --> Language Class Initialized
INFO - 2024-02-27 14:03:09 --> Loader Class Initialized
INFO - 2024-02-27 14:03:09 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:09 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:09 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:09 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:09 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:09 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:09 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:09 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:09 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:09 --> Parser Class Initialized
INFO - 2024-02-27 14:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:09 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:09 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:09 --> Controller Class Initialized
INFO - 2024-02-27 14:03:09 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:09 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:09 --> Model Class Initialized
INFO - 2024-02-27 14:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-27 14:03:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:03:09 --> Model Class Initialized
INFO - 2024-02-27 14:03:09 --> Model Class Initialized
INFO - 2024-02-27 14:03:09 --> Model Class Initialized
INFO - 2024-02-27 14:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:03:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:03:09 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:09 --> Total execution time: 0.1923
ERROR - 2024-02-27 14:03:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:15 --> Config Class Initialized
INFO - 2024-02-27 14:03:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:15 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:15 --> URI Class Initialized
INFO - 2024-02-27 14:03:15 --> Router Class Initialized
INFO - 2024-02-27 14:03:15 --> Output Class Initialized
INFO - 2024-02-27 14:03:15 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:15 --> Input Class Initialized
INFO - 2024-02-27 14:03:15 --> Language Class Initialized
INFO - 2024-02-27 14:03:15 --> Loader Class Initialized
INFO - 2024-02-27 14:03:15 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:15 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:15 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:15 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:15 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:15 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:15 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:15 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:15 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:15 --> Parser Class Initialized
INFO - 2024-02-27 14:03:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:15 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:15 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:15 --> Controller Class Initialized
INFO - 2024-02-27 14:03:15 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:15 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:15 --> Total execution time: 0.0212
ERROR - 2024-02-27 14:03:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:16 --> Config Class Initialized
INFO - 2024-02-27 14:03:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:16 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:16 --> URI Class Initialized
INFO - 2024-02-27 14:03:16 --> Router Class Initialized
INFO - 2024-02-27 14:03:16 --> Output Class Initialized
INFO - 2024-02-27 14:03:16 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:16 --> Input Class Initialized
INFO - 2024-02-27 14:03:16 --> Language Class Initialized
INFO - 2024-02-27 14:03:16 --> Loader Class Initialized
INFO - 2024-02-27 14:03:16 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:16 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:16 --> Parser Class Initialized
INFO - 2024-02-27 14:03:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:16 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:16 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:16 --> Controller Class Initialized
INFO - 2024-02-27 14:03:16 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:16 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:16 --> Total execution time: 0.0154
ERROR - 2024-02-27 14:03:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:16 --> Config Class Initialized
INFO - 2024-02-27 14:03:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:16 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:16 --> URI Class Initialized
INFO - 2024-02-27 14:03:16 --> Router Class Initialized
INFO - 2024-02-27 14:03:16 --> Output Class Initialized
INFO - 2024-02-27 14:03:16 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:16 --> Input Class Initialized
INFO - 2024-02-27 14:03:16 --> Language Class Initialized
INFO - 2024-02-27 14:03:16 --> Loader Class Initialized
INFO - 2024-02-27 14:03:16 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:16 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:16 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:16 --> Parser Class Initialized
INFO - 2024-02-27 14:03:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:16 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:16 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:16 --> Controller Class Initialized
INFO - 2024-02-27 14:03:16 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:16 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:16 --> Total execution time: 0.0153
ERROR - 2024-02-27 14:03:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:25 --> Config Class Initialized
INFO - 2024-02-27 14:03:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:25 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:25 --> URI Class Initialized
INFO - 2024-02-27 14:03:25 --> Router Class Initialized
INFO - 2024-02-27 14:03:25 --> Output Class Initialized
INFO - 2024-02-27 14:03:25 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:25 --> Input Class Initialized
INFO - 2024-02-27 14:03:25 --> Language Class Initialized
INFO - 2024-02-27 14:03:25 --> Loader Class Initialized
INFO - 2024-02-27 14:03:25 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:25 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:25 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:25 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:25 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:25 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:25 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:25 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:25 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:25 --> Parser Class Initialized
INFO - 2024-02-27 14:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:25 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:25 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:25 --> Controller Class Initialized
INFO - 2024-02-27 14:03:25 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:25 --> Total execution time: 0.0139
ERROR - 2024-02-27 14:03:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:36 --> Config Class Initialized
INFO - 2024-02-27 14:03:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:36 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:36 --> URI Class Initialized
DEBUG - 2024-02-27 14:03:36 --> No URI present. Default controller set.
INFO - 2024-02-27 14:03:36 --> Router Class Initialized
INFO - 2024-02-27 14:03:36 --> Output Class Initialized
INFO - 2024-02-27 14:03:36 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:36 --> Input Class Initialized
INFO - 2024-02-27 14:03:36 --> Language Class Initialized
INFO - 2024-02-27 14:03:36 --> Loader Class Initialized
INFO - 2024-02-27 14:03:36 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:36 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:36 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:36 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:36 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:36 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:36 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:36 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:36 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:36 --> Parser Class Initialized
INFO - 2024-02-27 14:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:36 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:36 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:36 --> Controller Class Initialized
INFO - 2024-02-27 14:03:36 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:36 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:36 --> Model Class Initialized
INFO - 2024-02-27 14:03:36 --> Model Class Initialized
INFO - 2024-02-27 14:03:36 --> Model Class Initialized
INFO - 2024-02-27 14:03:36 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:36 --> Model Class Initialized
INFO - 2024-02-27 14:03:36 --> Model Class Initialized
INFO - 2024-02-27 14:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:03:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:03:36 --> Model Class Initialized
INFO - 2024-02-27 14:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:03:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:03:36 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:36 --> Total execution time: 0.2374
ERROR - 2024-02-27 14:03:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:42 --> Config Class Initialized
INFO - 2024-02-27 14:03:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:42 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:42 --> URI Class Initialized
INFO - 2024-02-27 14:03:42 --> Router Class Initialized
INFO - 2024-02-27 14:03:42 --> Output Class Initialized
INFO - 2024-02-27 14:03:42 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:42 --> Input Class Initialized
INFO - 2024-02-27 14:03:42 --> Language Class Initialized
INFO - 2024-02-27 14:03:42 --> Loader Class Initialized
INFO - 2024-02-27 14:03:42 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:42 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:42 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:42 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:42 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:42 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:42 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:42 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:42 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:42 --> Parser Class Initialized
INFO - 2024-02-27 14:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:42 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:42 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:42 --> Controller Class Initialized
INFO - 2024-02-27 14:03:42 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:42 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:42 --> Model Class Initialized
INFO - 2024-02-27 14:03:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-27 14:03:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:03:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:03:42 --> Model Class Initialized
INFO - 2024-02-27 14:03:42 --> Model Class Initialized
INFO - 2024-02-27 14:03:42 --> Model Class Initialized
INFO - 2024-02-27 14:03:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:03:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:03:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:43 --> Total execution time: 0.1628
ERROR - 2024-02-27 14:03:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:43 --> Config Class Initialized
INFO - 2024-02-27 14:03:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:43 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:43 --> URI Class Initialized
INFO - 2024-02-27 14:03:43 --> Router Class Initialized
INFO - 2024-02-27 14:03:43 --> Output Class Initialized
INFO - 2024-02-27 14:03:43 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:43 --> Input Class Initialized
INFO - 2024-02-27 14:03:43 --> Language Class Initialized
INFO - 2024-02-27 14:03:43 --> Loader Class Initialized
INFO - 2024-02-27 14:03:43 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:43 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:43 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:43 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:43 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:43 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:43 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:43 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:43 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:43 --> Parser Class Initialized
INFO - 2024-02-27 14:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:43 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:43 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:43 --> Controller Class Initialized
INFO - 2024-02-27 14:03:43 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:43 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:43 --> Model Class Initialized
INFO - 2024-02-27 14:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:43 --> Total execution time: 0.0416
ERROR - 2024-02-27 14:03:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:03:50 --> Config Class Initialized
INFO - 2024-02-27 14:03:50 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:03:50 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:03:50 --> Utf8 Class Initialized
INFO - 2024-02-27 14:03:50 --> URI Class Initialized
INFO - 2024-02-27 14:03:50 --> Router Class Initialized
INFO - 2024-02-27 14:03:50 --> Output Class Initialized
INFO - 2024-02-27 14:03:50 --> Security Class Initialized
DEBUG - 2024-02-27 14:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:03:50 --> Input Class Initialized
INFO - 2024-02-27 14:03:50 --> Language Class Initialized
INFO - 2024-02-27 14:03:50 --> Loader Class Initialized
INFO - 2024-02-27 14:03:50 --> Helper loaded: url_helper
INFO - 2024-02-27 14:03:50 --> Helper loaded: file_helper
INFO - 2024-02-27 14:03:50 --> Helper loaded: html_helper
INFO - 2024-02-27 14:03:50 --> Helper loaded: text_helper
INFO - 2024-02-27 14:03:50 --> Helper loaded: form_helper
INFO - 2024-02-27 14:03:50 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:03:50 --> Helper loaded: security_helper
INFO - 2024-02-27 14:03:50 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:03:50 --> Database Driver Class Initialized
INFO - 2024-02-27 14:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:03:50 --> Parser Class Initialized
INFO - 2024-02-27 14:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:03:50 --> Pagination Class Initialized
INFO - 2024-02-27 14:03:50 --> Form Validation Class Initialized
INFO - 2024-02-27 14:03:50 --> Controller Class Initialized
INFO - 2024-02-27 14:03:50 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:50 --> Model Class Initialized
DEBUG - 2024-02-27 14:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:03:50 --> Model Class Initialized
INFO - 2024-02-27 14:03:50 --> Final output sent to browser
DEBUG - 2024-02-27 14:03:50 --> Total execution time: 0.2336
ERROR - 2024-02-27 14:04:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:16 --> Config Class Initialized
INFO - 2024-02-27 14:04:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:16 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:16 --> URI Class Initialized
DEBUG - 2024-02-27 14:04:16 --> No URI present. Default controller set.
INFO - 2024-02-27 14:04:16 --> Router Class Initialized
INFO - 2024-02-27 14:04:16 --> Output Class Initialized
INFO - 2024-02-27 14:04:16 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:16 --> Input Class Initialized
INFO - 2024-02-27 14:04:16 --> Language Class Initialized
INFO - 2024-02-27 14:04:16 --> Loader Class Initialized
INFO - 2024-02-27 14:04:16 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:16 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:16 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:16 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:16 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:16 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:16 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:16 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:16 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:16 --> Parser Class Initialized
INFO - 2024-02-27 14:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:16 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:16 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:16 --> Controller Class Initialized
INFO - 2024-02-27 14:04:16 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:16 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:16 --> Model Class Initialized
INFO - 2024-02-27 14:04:16 --> Model Class Initialized
INFO - 2024-02-27 14:04:16 --> Model Class Initialized
INFO - 2024-02-27 14:04:16 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:16 --> Model Class Initialized
INFO - 2024-02-27 14:04:16 --> Model Class Initialized
INFO - 2024-02-27 14:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:04:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:04:16 --> Model Class Initialized
INFO - 2024-02-27 14:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:04:16 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:16 --> Total execution time: 0.2427
ERROR - 2024-02-27 14:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:21 --> Config Class Initialized
INFO - 2024-02-27 14:04:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:21 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:21 --> URI Class Initialized
INFO - 2024-02-27 14:04:21 --> Router Class Initialized
INFO - 2024-02-27 14:04:21 --> Output Class Initialized
INFO - 2024-02-27 14:04:21 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:21 --> Input Class Initialized
INFO - 2024-02-27 14:04:21 --> Language Class Initialized
INFO - 2024-02-27 14:04:21 --> Loader Class Initialized
INFO - 2024-02-27 14:04:21 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:21 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:21 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:21 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:21 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:21 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:21 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:21 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:21 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:21 --> Parser Class Initialized
INFO - 2024-02-27 14:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:21 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:21 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:21 --> Controller Class Initialized
INFO - 2024-02-27 14:04:21 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:21 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:21 --> Model Class Initialized
INFO - 2024-02-27 14:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-27 14:04:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:04:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:04:21 --> Model Class Initialized
INFO - 2024-02-27 14:04:21 --> Model Class Initialized
INFO - 2024-02-27 14:04:21 --> Model Class Initialized
INFO - 2024-02-27 14:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:04:22 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:22 --> Total execution time: 0.1885
ERROR - 2024-02-27 14:04:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:26 --> Config Class Initialized
INFO - 2024-02-27 14:04:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:26 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:26 --> URI Class Initialized
INFO - 2024-02-27 14:04:26 --> Router Class Initialized
INFO - 2024-02-27 14:04:26 --> Output Class Initialized
INFO - 2024-02-27 14:04:26 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:26 --> Input Class Initialized
INFO - 2024-02-27 14:04:26 --> Language Class Initialized
INFO - 2024-02-27 14:04:26 --> Loader Class Initialized
INFO - 2024-02-27 14:04:26 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:26 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:26 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:26 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:26 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:26 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:26 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:26 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:26 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:26 --> Parser Class Initialized
INFO - 2024-02-27 14:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:26 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:26 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:26 --> Controller Class Initialized
INFO - 2024-02-27 14:04:26 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:26 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:26 --> Total execution time: 0.0155
ERROR - 2024-02-27 14:04:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:27 --> Config Class Initialized
INFO - 2024-02-27 14:04:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:27 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:27 --> URI Class Initialized
INFO - 2024-02-27 14:04:27 --> Router Class Initialized
INFO - 2024-02-27 14:04:27 --> Output Class Initialized
INFO - 2024-02-27 14:04:27 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:27 --> Input Class Initialized
INFO - 2024-02-27 14:04:27 --> Language Class Initialized
INFO - 2024-02-27 14:04:27 --> Loader Class Initialized
INFO - 2024-02-27 14:04:27 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:27 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:27 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:27 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:27 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:27 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:27 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:27 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:27 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:27 --> Parser Class Initialized
INFO - 2024-02-27 14:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:27 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:27 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:27 --> Controller Class Initialized
INFO - 2024-02-27 14:04:27 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:27 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:27 --> Total execution time: 0.0189
ERROR - 2024-02-27 14:04:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:29 --> Config Class Initialized
INFO - 2024-02-27 14:04:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:29 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:29 --> URI Class Initialized
INFO - 2024-02-27 14:04:29 --> Router Class Initialized
INFO - 2024-02-27 14:04:29 --> Output Class Initialized
INFO - 2024-02-27 14:04:29 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:29 --> Input Class Initialized
INFO - 2024-02-27 14:04:29 --> Language Class Initialized
INFO - 2024-02-27 14:04:29 --> Loader Class Initialized
INFO - 2024-02-27 14:04:29 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:29 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:29 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:29 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:29 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:29 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:29 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:29 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:29 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:29 --> Parser Class Initialized
INFO - 2024-02-27 14:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:29 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:29 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:29 --> Controller Class Initialized
INFO - 2024-02-27 14:04:29 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:29 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:29 --> Total execution time: 0.0157
ERROR - 2024-02-27 14:04:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:30 --> Config Class Initialized
INFO - 2024-02-27 14:04:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:30 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:30 --> URI Class Initialized
INFO - 2024-02-27 14:04:30 --> Router Class Initialized
INFO - 2024-02-27 14:04:30 --> Output Class Initialized
INFO - 2024-02-27 14:04:30 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:30 --> Input Class Initialized
INFO - 2024-02-27 14:04:30 --> Language Class Initialized
INFO - 2024-02-27 14:04:30 --> Loader Class Initialized
INFO - 2024-02-27 14:04:30 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:30 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:30 --> Parser Class Initialized
INFO - 2024-02-27 14:04:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:30 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:30 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:30 --> Controller Class Initialized
INFO - 2024-02-27 14:04:30 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:30 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:30 --> Total execution time: 0.0158
ERROR - 2024-02-27 14:04:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:30 --> Config Class Initialized
INFO - 2024-02-27 14:04:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:30 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:30 --> URI Class Initialized
INFO - 2024-02-27 14:04:30 --> Router Class Initialized
INFO - 2024-02-27 14:04:30 --> Output Class Initialized
INFO - 2024-02-27 14:04:30 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:30 --> Input Class Initialized
INFO - 2024-02-27 14:04:30 --> Language Class Initialized
INFO - 2024-02-27 14:04:30 --> Loader Class Initialized
INFO - 2024-02-27 14:04:30 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:30 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:30 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:30 --> Parser Class Initialized
INFO - 2024-02-27 14:04:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:30 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:30 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:30 --> Controller Class Initialized
INFO - 2024-02-27 14:04:30 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 14:04:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-27 14:04:30 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:30 --> Total execution time: 0.0157
ERROR - 2024-02-27 14:04:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:33 --> Config Class Initialized
INFO - 2024-02-27 14:04:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:33 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:33 --> URI Class Initialized
INFO - 2024-02-27 14:04:33 --> Router Class Initialized
INFO - 2024-02-27 14:04:33 --> Output Class Initialized
INFO - 2024-02-27 14:04:33 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:33 --> Input Class Initialized
INFO - 2024-02-27 14:04:33 --> Language Class Initialized
INFO - 2024-02-27 14:04:33 --> Loader Class Initialized
INFO - 2024-02-27 14:04:33 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:33 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:33 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:33 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:33 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:33 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:33 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:33 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:33 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:33 --> Parser Class Initialized
INFO - 2024-02-27 14:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:33 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:33 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:33 --> Controller Class Initialized
INFO - 2024-02-27 14:04:33 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:33 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:33 --> Total execution time: 0.0162
ERROR - 2024-02-27 14:04:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:34 --> Config Class Initialized
INFO - 2024-02-27 14:04:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:34 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:34 --> URI Class Initialized
INFO - 2024-02-27 14:04:34 --> Router Class Initialized
INFO - 2024-02-27 14:04:34 --> Output Class Initialized
INFO - 2024-02-27 14:04:34 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:34 --> Input Class Initialized
INFO - 2024-02-27 14:04:34 --> Language Class Initialized
INFO - 2024-02-27 14:04:34 --> Loader Class Initialized
INFO - 2024-02-27 14:04:34 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:34 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:34 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:34 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:34 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:34 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:34 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:34 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:34 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:34 --> Parser Class Initialized
INFO - 2024-02-27 14:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:34 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:34 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:34 --> Controller Class Initialized
INFO - 2024-02-27 14:04:34 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:34 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:34 --> Total execution time: 0.0150
ERROR - 2024-02-27 14:04:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:35 --> Config Class Initialized
INFO - 2024-02-27 14:04:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:35 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:35 --> URI Class Initialized
INFO - 2024-02-27 14:04:35 --> Router Class Initialized
INFO - 2024-02-27 14:04:35 --> Output Class Initialized
INFO - 2024-02-27 14:04:35 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:35 --> Input Class Initialized
INFO - 2024-02-27 14:04:35 --> Language Class Initialized
INFO - 2024-02-27 14:04:35 --> Loader Class Initialized
INFO - 2024-02-27 14:04:35 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:35 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:35 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:35 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:35 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:35 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:35 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:35 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:35 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:35 --> Parser Class Initialized
INFO - 2024-02-27 14:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:35 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:35 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:35 --> Controller Class Initialized
INFO - 2024-02-27 14:04:35 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:35 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:35 --> Total execution time: 0.0155
ERROR - 2024-02-27 14:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:44 --> Config Class Initialized
INFO - 2024-02-27 14:04:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:44 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:44 --> URI Class Initialized
DEBUG - 2024-02-27 14:04:44 --> No URI present. Default controller set.
INFO - 2024-02-27 14:04:44 --> Router Class Initialized
INFO - 2024-02-27 14:04:44 --> Output Class Initialized
INFO - 2024-02-27 14:04:44 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:44 --> Input Class Initialized
INFO - 2024-02-27 14:04:44 --> Language Class Initialized
INFO - 2024-02-27 14:04:44 --> Loader Class Initialized
INFO - 2024-02-27 14:04:44 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:44 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:44 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:44 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:44 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:44 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:44 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:44 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:44 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:44 --> Parser Class Initialized
INFO - 2024-02-27 14:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:44 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:44 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:44 --> Controller Class Initialized
INFO - 2024-02-27 14:04:44 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:44 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:44 --> Model Class Initialized
INFO - 2024-02-27 14:04:44 --> Model Class Initialized
INFO - 2024-02-27 14:04:44 --> Model Class Initialized
INFO - 2024-02-27 14:04:44 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:44 --> Model Class Initialized
INFO - 2024-02-27 14:04:44 --> Model Class Initialized
INFO - 2024-02-27 14:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:04:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:04:44 --> Model Class Initialized
INFO - 2024-02-27 14:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:04:44 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:44 --> Total execution time: 0.2399
ERROR - 2024-02-27 14:04:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:48 --> Config Class Initialized
INFO - 2024-02-27 14:04:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:48 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:48 --> URI Class Initialized
INFO - 2024-02-27 14:04:48 --> Router Class Initialized
INFO - 2024-02-27 14:04:48 --> Output Class Initialized
INFO - 2024-02-27 14:04:48 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:48 --> Input Class Initialized
INFO - 2024-02-27 14:04:48 --> Language Class Initialized
INFO - 2024-02-27 14:04:48 --> Loader Class Initialized
INFO - 2024-02-27 14:04:48 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:48 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:48 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:48 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:48 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:48 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:48 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:48 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:48 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:48 --> Parser Class Initialized
INFO - 2024-02-27 14:04:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:48 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:48 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:48 --> Controller Class Initialized
INFO - 2024-02-27 14:04:48 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 14:04:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:04:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:04:48 --> Model Class Initialized
INFO - 2024-02-27 14:04:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:04:48 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:48 --> Total execution time: 0.0300
ERROR - 2024-02-27 14:04:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:04:49 --> Config Class Initialized
INFO - 2024-02-27 14:04:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:04:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:04:49 --> Utf8 Class Initialized
INFO - 2024-02-27 14:04:49 --> URI Class Initialized
INFO - 2024-02-27 14:04:49 --> Router Class Initialized
INFO - 2024-02-27 14:04:49 --> Output Class Initialized
INFO - 2024-02-27 14:04:49 --> Security Class Initialized
DEBUG - 2024-02-27 14:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:04:49 --> Input Class Initialized
INFO - 2024-02-27 14:04:49 --> Language Class Initialized
INFO - 2024-02-27 14:04:49 --> Loader Class Initialized
INFO - 2024-02-27 14:04:49 --> Helper loaded: url_helper
INFO - 2024-02-27 14:04:49 --> Helper loaded: file_helper
INFO - 2024-02-27 14:04:49 --> Helper loaded: html_helper
INFO - 2024-02-27 14:04:49 --> Helper loaded: text_helper
INFO - 2024-02-27 14:04:49 --> Helper loaded: form_helper
INFO - 2024-02-27 14:04:49 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:04:49 --> Helper loaded: security_helper
INFO - 2024-02-27 14:04:49 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:04:49 --> Database Driver Class Initialized
INFO - 2024-02-27 14:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:04:49 --> Parser Class Initialized
INFO - 2024-02-27 14:04:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:04:49 --> Pagination Class Initialized
INFO - 2024-02-27 14:04:49 --> Form Validation Class Initialized
INFO - 2024-02-27 14:04:49 --> Controller Class Initialized
INFO - 2024-02-27 14:04:49 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:49 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:49 --> Model Class Initialized
INFO - 2024-02-27 14:04:49 --> Model Class Initialized
INFO - 2024-02-27 14:04:49 --> Model Class Initialized
INFO - 2024-02-27 14:04:49 --> Model Class Initialized
DEBUG - 2024-02-27 14:04:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:49 --> Model Class Initialized
INFO - 2024-02-27 14:04:49 --> Model Class Initialized
INFO - 2024-02-27 14:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:04:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:04:49 --> Model Class Initialized
INFO - 2024-02-27 14:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:04:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:04:49 --> Final output sent to browser
DEBUG - 2024-02-27 14:04:49 --> Total execution time: 0.2698
ERROR - 2024-02-27 14:09:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:09:15 --> Config Class Initialized
INFO - 2024-02-27 14:09:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:09:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:09:15 --> Utf8 Class Initialized
INFO - 2024-02-27 14:09:15 --> URI Class Initialized
DEBUG - 2024-02-27 14:09:15 --> No URI present. Default controller set.
INFO - 2024-02-27 14:09:15 --> Router Class Initialized
INFO - 2024-02-27 14:09:15 --> Output Class Initialized
INFO - 2024-02-27 14:09:15 --> Security Class Initialized
DEBUG - 2024-02-27 14:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:09:15 --> Input Class Initialized
INFO - 2024-02-27 14:09:15 --> Language Class Initialized
INFO - 2024-02-27 14:09:15 --> Loader Class Initialized
INFO - 2024-02-27 14:09:15 --> Helper loaded: url_helper
INFO - 2024-02-27 14:09:15 --> Helper loaded: file_helper
INFO - 2024-02-27 14:09:15 --> Helper loaded: html_helper
INFO - 2024-02-27 14:09:15 --> Helper loaded: text_helper
INFO - 2024-02-27 14:09:15 --> Helper loaded: form_helper
INFO - 2024-02-27 14:09:15 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:09:15 --> Helper loaded: security_helper
INFO - 2024-02-27 14:09:15 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:09:15 --> Database Driver Class Initialized
INFO - 2024-02-27 14:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:09:15 --> Parser Class Initialized
INFO - 2024-02-27 14:09:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:09:15 --> Pagination Class Initialized
INFO - 2024-02-27 14:09:15 --> Form Validation Class Initialized
INFO - 2024-02-27 14:09:15 --> Controller Class Initialized
INFO - 2024-02-27 14:09:15 --> Model Class Initialized
DEBUG - 2024-02-27 14:09:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 14:09:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:09:16 --> Config Class Initialized
INFO - 2024-02-27 14:09:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:09:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:09:16 --> Utf8 Class Initialized
INFO - 2024-02-27 14:09:16 --> URI Class Initialized
INFO - 2024-02-27 14:09:16 --> Router Class Initialized
INFO - 2024-02-27 14:09:16 --> Output Class Initialized
INFO - 2024-02-27 14:09:16 --> Security Class Initialized
DEBUG - 2024-02-27 14:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:09:16 --> Input Class Initialized
INFO - 2024-02-27 14:09:16 --> Language Class Initialized
INFO - 2024-02-27 14:09:16 --> Loader Class Initialized
INFO - 2024-02-27 14:09:16 --> Helper loaded: url_helper
INFO - 2024-02-27 14:09:16 --> Helper loaded: file_helper
INFO - 2024-02-27 14:09:16 --> Helper loaded: html_helper
INFO - 2024-02-27 14:09:16 --> Helper loaded: text_helper
INFO - 2024-02-27 14:09:16 --> Helper loaded: form_helper
INFO - 2024-02-27 14:09:16 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:09:16 --> Helper loaded: security_helper
INFO - 2024-02-27 14:09:16 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:09:16 --> Database Driver Class Initialized
INFO - 2024-02-27 14:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:09:16 --> Parser Class Initialized
INFO - 2024-02-27 14:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:09:16 --> Pagination Class Initialized
INFO - 2024-02-27 14:09:16 --> Form Validation Class Initialized
INFO - 2024-02-27 14:09:16 --> Controller Class Initialized
INFO - 2024-02-27 14:09:16 --> Model Class Initialized
DEBUG - 2024-02-27 14:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-27 14:09:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:09:16 --> Model Class Initialized
INFO - 2024-02-27 14:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:09:16 --> Final output sent to browser
DEBUG - 2024-02-27 14:09:16 --> Total execution time: 0.0351
ERROR - 2024-02-27 14:09:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:09:35 --> Config Class Initialized
INFO - 2024-02-27 14:09:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:09:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:09:35 --> Utf8 Class Initialized
INFO - 2024-02-27 14:09:35 --> URI Class Initialized
INFO - 2024-02-27 14:09:35 --> Router Class Initialized
INFO - 2024-02-27 14:09:35 --> Output Class Initialized
INFO - 2024-02-27 14:09:35 --> Security Class Initialized
DEBUG - 2024-02-27 14:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:09:35 --> Input Class Initialized
INFO - 2024-02-27 14:09:35 --> Language Class Initialized
INFO - 2024-02-27 14:09:35 --> Loader Class Initialized
INFO - 2024-02-27 14:09:35 --> Helper loaded: url_helper
INFO - 2024-02-27 14:09:35 --> Helper loaded: file_helper
INFO - 2024-02-27 14:09:35 --> Helper loaded: html_helper
INFO - 2024-02-27 14:09:35 --> Helper loaded: text_helper
INFO - 2024-02-27 14:09:35 --> Helper loaded: form_helper
INFO - 2024-02-27 14:09:35 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:09:35 --> Helper loaded: security_helper
INFO - 2024-02-27 14:09:35 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:09:35 --> Database Driver Class Initialized
INFO - 2024-02-27 14:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:09:35 --> Parser Class Initialized
INFO - 2024-02-27 14:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:09:35 --> Pagination Class Initialized
INFO - 2024-02-27 14:09:35 --> Form Validation Class Initialized
INFO - 2024-02-27 14:09:35 --> Controller Class Initialized
INFO - 2024-02-27 14:09:35 --> Model Class Initialized
DEBUG - 2024-02-27 14:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:09:35 --> Model Class Initialized
INFO - 2024-02-27 14:09:35 --> Final output sent to browser
DEBUG - 2024-02-27 14:09:35 --> Total execution time: 0.0198
ERROR - 2024-02-27 14:09:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:09:36 --> Config Class Initialized
INFO - 2024-02-27 14:09:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:09:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:09:36 --> Utf8 Class Initialized
INFO - 2024-02-27 14:09:36 --> URI Class Initialized
DEBUG - 2024-02-27 14:09:36 --> No URI present. Default controller set.
INFO - 2024-02-27 14:09:36 --> Router Class Initialized
INFO - 2024-02-27 14:09:36 --> Output Class Initialized
INFO - 2024-02-27 14:09:36 --> Security Class Initialized
DEBUG - 2024-02-27 14:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:09:36 --> Input Class Initialized
INFO - 2024-02-27 14:09:36 --> Language Class Initialized
INFO - 2024-02-27 14:09:36 --> Loader Class Initialized
INFO - 2024-02-27 14:09:36 --> Helper loaded: url_helper
INFO - 2024-02-27 14:09:36 --> Helper loaded: file_helper
INFO - 2024-02-27 14:09:36 --> Helper loaded: html_helper
INFO - 2024-02-27 14:09:36 --> Helper loaded: text_helper
INFO - 2024-02-27 14:09:36 --> Helper loaded: form_helper
INFO - 2024-02-27 14:09:36 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:09:36 --> Helper loaded: security_helper
INFO - 2024-02-27 14:09:36 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:09:36 --> Database Driver Class Initialized
INFO - 2024-02-27 14:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:09:36 --> Parser Class Initialized
INFO - 2024-02-27 14:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:09:36 --> Pagination Class Initialized
INFO - 2024-02-27 14:09:36 --> Form Validation Class Initialized
INFO - 2024-02-27 14:09:36 --> Controller Class Initialized
INFO - 2024-02-27 14:09:36 --> Model Class Initialized
DEBUG - 2024-02-27 14:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:09:36 --> Model Class Initialized
DEBUG - 2024-02-27 14:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:09:36 --> Model Class Initialized
INFO - 2024-02-27 14:09:36 --> Model Class Initialized
INFO - 2024-02-27 14:09:36 --> Model Class Initialized
INFO - 2024-02-27 14:09:36 --> Model Class Initialized
DEBUG - 2024-02-27 14:09:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:09:36 --> Model Class Initialized
INFO - 2024-02-27 14:09:36 --> Model Class Initialized
INFO - 2024-02-27 14:09:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:09:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:09:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:09:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:09:36 --> Model Class Initialized
INFO - 2024-02-27 14:09:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:09:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:09:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:09:36 --> Final output sent to browser
DEBUG - 2024-02-27 14:09:36 --> Total execution time: 0.2471
ERROR - 2024-02-27 14:12:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:12:33 --> Config Class Initialized
INFO - 2024-02-27 14:12:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:12:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:12:33 --> Utf8 Class Initialized
INFO - 2024-02-27 14:12:33 --> URI Class Initialized
INFO - 2024-02-27 14:12:33 --> Router Class Initialized
INFO - 2024-02-27 14:12:33 --> Output Class Initialized
INFO - 2024-02-27 14:12:33 --> Security Class Initialized
DEBUG - 2024-02-27 14:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:12:33 --> Input Class Initialized
INFO - 2024-02-27 14:12:33 --> Language Class Initialized
INFO - 2024-02-27 14:12:33 --> Loader Class Initialized
INFO - 2024-02-27 14:12:33 --> Helper loaded: url_helper
INFO - 2024-02-27 14:12:33 --> Helper loaded: file_helper
INFO - 2024-02-27 14:12:33 --> Helper loaded: html_helper
INFO - 2024-02-27 14:12:33 --> Helper loaded: text_helper
INFO - 2024-02-27 14:12:33 --> Helper loaded: form_helper
INFO - 2024-02-27 14:12:33 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:12:33 --> Helper loaded: security_helper
INFO - 2024-02-27 14:12:33 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:12:33 --> Database Driver Class Initialized
INFO - 2024-02-27 14:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:12:33 --> Parser Class Initialized
INFO - 2024-02-27 14:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:12:33 --> Pagination Class Initialized
INFO - 2024-02-27 14:12:33 --> Form Validation Class Initialized
INFO - 2024-02-27 14:12:33 --> Controller Class Initialized
INFO - 2024-02-27 14:12:33 --> Model Class Initialized
DEBUG - 2024-02-27 14:12:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:12:33 --> Model Class Initialized
DEBUG - 2024-02-27 14:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:12:33 --> Model Class Initialized
INFO - 2024-02-27 14:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-27 14:12:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:12:33 --> Model Class Initialized
INFO - 2024-02-27 14:12:33 --> Model Class Initialized
INFO - 2024-02-27 14:12:33 --> Model Class Initialized
INFO - 2024-02-27 14:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:12:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:12:33 --> Final output sent to browser
DEBUG - 2024-02-27 14:12:33 --> Total execution time: 0.1704
ERROR - 2024-02-27 14:12:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:12:34 --> Config Class Initialized
INFO - 2024-02-27 14:12:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:12:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:12:34 --> Utf8 Class Initialized
INFO - 2024-02-27 14:12:34 --> URI Class Initialized
INFO - 2024-02-27 14:12:34 --> Router Class Initialized
INFO - 2024-02-27 14:12:34 --> Output Class Initialized
INFO - 2024-02-27 14:12:34 --> Security Class Initialized
DEBUG - 2024-02-27 14:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:12:34 --> Input Class Initialized
INFO - 2024-02-27 14:12:34 --> Language Class Initialized
INFO - 2024-02-27 14:12:34 --> Loader Class Initialized
INFO - 2024-02-27 14:12:34 --> Helper loaded: url_helper
INFO - 2024-02-27 14:12:34 --> Helper loaded: file_helper
INFO - 2024-02-27 14:12:34 --> Helper loaded: html_helper
INFO - 2024-02-27 14:12:34 --> Helper loaded: text_helper
INFO - 2024-02-27 14:12:34 --> Helper loaded: form_helper
INFO - 2024-02-27 14:12:34 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:12:34 --> Helper loaded: security_helper
INFO - 2024-02-27 14:12:34 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:12:34 --> Database Driver Class Initialized
INFO - 2024-02-27 14:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:12:34 --> Parser Class Initialized
INFO - 2024-02-27 14:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:12:34 --> Pagination Class Initialized
INFO - 2024-02-27 14:12:34 --> Form Validation Class Initialized
INFO - 2024-02-27 14:12:34 --> Controller Class Initialized
INFO - 2024-02-27 14:12:34 --> Model Class Initialized
DEBUG - 2024-02-27 14:12:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:12:34 --> Model Class Initialized
DEBUG - 2024-02-27 14:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:12:34 --> Model Class Initialized
INFO - 2024-02-27 14:12:34 --> Final output sent to browser
DEBUG - 2024-02-27 14:12:34 --> Total execution time: 0.0415
ERROR - 2024-02-27 14:12:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:12:45 --> Config Class Initialized
INFO - 2024-02-27 14:12:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:12:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:12:45 --> Utf8 Class Initialized
INFO - 2024-02-27 14:12:45 --> URI Class Initialized
DEBUG - 2024-02-27 14:12:45 --> No URI present. Default controller set.
INFO - 2024-02-27 14:12:45 --> Router Class Initialized
INFO - 2024-02-27 14:12:45 --> Output Class Initialized
INFO - 2024-02-27 14:12:45 --> Security Class Initialized
DEBUG - 2024-02-27 14:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:12:45 --> Input Class Initialized
INFO - 2024-02-27 14:12:45 --> Language Class Initialized
INFO - 2024-02-27 14:12:45 --> Loader Class Initialized
INFO - 2024-02-27 14:12:45 --> Helper loaded: url_helper
INFO - 2024-02-27 14:12:45 --> Helper loaded: file_helper
INFO - 2024-02-27 14:12:45 --> Helper loaded: html_helper
INFO - 2024-02-27 14:12:45 --> Helper loaded: text_helper
INFO - 2024-02-27 14:12:45 --> Helper loaded: form_helper
INFO - 2024-02-27 14:12:45 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:12:45 --> Helper loaded: security_helper
INFO - 2024-02-27 14:12:45 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:12:45 --> Database Driver Class Initialized
INFO - 2024-02-27 14:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:12:45 --> Parser Class Initialized
INFO - 2024-02-27 14:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:12:45 --> Pagination Class Initialized
INFO - 2024-02-27 14:12:45 --> Form Validation Class Initialized
INFO - 2024-02-27 14:12:45 --> Controller Class Initialized
INFO - 2024-02-27 14:12:45 --> Model Class Initialized
DEBUG - 2024-02-27 14:12:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 14:14:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:14:12 --> Config Class Initialized
INFO - 2024-02-27 14:14:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:14:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:14:12 --> Utf8 Class Initialized
INFO - 2024-02-27 14:14:12 --> URI Class Initialized
INFO - 2024-02-27 14:14:12 --> Router Class Initialized
INFO - 2024-02-27 14:14:12 --> Output Class Initialized
INFO - 2024-02-27 14:14:12 --> Security Class Initialized
DEBUG - 2024-02-27 14:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:14:12 --> Input Class Initialized
INFO - 2024-02-27 14:14:12 --> Language Class Initialized
INFO - 2024-02-27 14:14:12 --> Loader Class Initialized
INFO - 2024-02-27 14:14:12 --> Helper loaded: url_helper
INFO - 2024-02-27 14:14:12 --> Helper loaded: file_helper
INFO - 2024-02-27 14:14:12 --> Helper loaded: html_helper
INFO - 2024-02-27 14:14:12 --> Helper loaded: text_helper
INFO - 2024-02-27 14:14:12 --> Helper loaded: form_helper
INFO - 2024-02-27 14:14:12 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:14:12 --> Helper loaded: security_helper
INFO - 2024-02-27 14:14:12 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:14:12 --> Database Driver Class Initialized
INFO - 2024-02-27 14:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:14:12 --> Parser Class Initialized
INFO - 2024-02-27 14:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:14:12 --> Pagination Class Initialized
INFO - 2024-02-27 14:14:12 --> Form Validation Class Initialized
INFO - 2024-02-27 14:14:12 --> Controller Class Initialized
INFO - 2024-02-27 14:14:12 --> Model Class Initialized
DEBUG - 2024-02-27 14:14:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:14:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:14:12 --> Model Class Initialized
INFO - 2024-02-27 14:14:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-02-27 14:14:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:14:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:14:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:14:12 --> Model Class Initialized
INFO - 2024-02-27 14:14:12 --> Model Class Initialized
INFO - 2024-02-27 14:14:12 --> Model Class Initialized
INFO - 2024-02-27 14:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:14:13 --> Final output sent to browser
DEBUG - 2024-02-27 14:14:13 --> Total execution time: 0.1538
ERROR - 2024-02-27 14:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:14:13 --> Config Class Initialized
INFO - 2024-02-27 14:14:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:14:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:14:13 --> Utf8 Class Initialized
INFO - 2024-02-27 14:14:13 --> URI Class Initialized
INFO - 2024-02-27 14:14:13 --> Router Class Initialized
INFO - 2024-02-27 14:14:13 --> Output Class Initialized
INFO - 2024-02-27 14:14:13 --> Security Class Initialized
DEBUG - 2024-02-27 14:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:14:13 --> Input Class Initialized
INFO - 2024-02-27 14:14:13 --> Language Class Initialized
INFO - 2024-02-27 14:14:13 --> Loader Class Initialized
INFO - 2024-02-27 14:14:13 --> Helper loaded: url_helper
INFO - 2024-02-27 14:14:13 --> Helper loaded: file_helper
INFO - 2024-02-27 14:14:13 --> Helper loaded: html_helper
INFO - 2024-02-27 14:14:13 --> Helper loaded: text_helper
INFO - 2024-02-27 14:14:13 --> Helper loaded: form_helper
INFO - 2024-02-27 14:14:13 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:14:13 --> Helper loaded: security_helper
INFO - 2024-02-27 14:14:13 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:14:13 --> Database Driver Class Initialized
INFO - 2024-02-27 14:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:14:13 --> Parser Class Initialized
INFO - 2024-02-27 14:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:14:13 --> Pagination Class Initialized
INFO - 2024-02-27 14:14:13 --> Form Validation Class Initialized
INFO - 2024-02-27 14:14:13 --> Controller Class Initialized
INFO - 2024-02-27 14:14:13 --> Model Class Initialized
DEBUG - 2024-02-27 14:14:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:14:13 --> Model Class Initialized
INFO - 2024-02-27 14:14:13 --> Final output sent to browser
DEBUG - 2024-02-27 14:14:13 --> Total execution time: 0.2266
ERROR - 2024-02-27 14:14:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:14:17 --> Config Class Initialized
INFO - 2024-02-27 14:14:17 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:14:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:14:17 --> Utf8 Class Initialized
INFO - 2024-02-27 14:14:17 --> URI Class Initialized
INFO - 2024-02-27 14:14:17 --> Router Class Initialized
INFO - 2024-02-27 14:14:17 --> Output Class Initialized
INFO - 2024-02-27 14:14:17 --> Security Class Initialized
DEBUG - 2024-02-27 14:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:14:17 --> Input Class Initialized
INFO - 2024-02-27 14:14:17 --> Language Class Initialized
INFO - 2024-02-27 14:14:17 --> Loader Class Initialized
INFO - 2024-02-27 14:14:17 --> Helper loaded: url_helper
INFO - 2024-02-27 14:14:17 --> Helper loaded: file_helper
INFO - 2024-02-27 14:14:17 --> Helper loaded: html_helper
INFO - 2024-02-27 14:14:17 --> Helper loaded: text_helper
INFO - 2024-02-27 14:14:17 --> Helper loaded: form_helper
INFO - 2024-02-27 14:14:17 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:14:17 --> Helper loaded: security_helper
INFO - 2024-02-27 14:14:17 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:14:17 --> Database Driver Class Initialized
INFO - 2024-02-27 14:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:14:17 --> Parser Class Initialized
INFO - 2024-02-27 14:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:14:17 --> Pagination Class Initialized
INFO - 2024-02-27 14:14:17 --> Form Validation Class Initialized
INFO - 2024-02-27 14:14:17 --> Controller Class Initialized
INFO - 2024-02-27 14:14:17 --> Model Class Initialized
DEBUG - 2024-02-27 14:14:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:14:17 --> Model Class Initialized
INFO - 2024-02-27 14:14:18 --> Final output sent to browser
DEBUG - 2024-02-27 14:14:18 --> Total execution time: 0.2214
ERROR - 2024-02-27 14:24:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:24:53 --> Config Class Initialized
INFO - 2024-02-27 14:24:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:24:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:24:53 --> Utf8 Class Initialized
INFO - 2024-02-27 14:24:53 --> URI Class Initialized
DEBUG - 2024-02-27 14:24:53 --> No URI present. Default controller set.
INFO - 2024-02-27 14:24:53 --> Router Class Initialized
INFO - 2024-02-27 14:24:53 --> Output Class Initialized
INFO - 2024-02-27 14:24:53 --> Security Class Initialized
DEBUG - 2024-02-27 14:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:24:53 --> Input Class Initialized
INFO - 2024-02-27 14:24:53 --> Language Class Initialized
INFO - 2024-02-27 14:24:53 --> Loader Class Initialized
INFO - 2024-02-27 14:24:53 --> Helper loaded: url_helper
INFO - 2024-02-27 14:24:53 --> Helper loaded: file_helper
INFO - 2024-02-27 14:24:53 --> Helper loaded: html_helper
INFO - 2024-02-27 14:24:53 --> Helper loaded: text_helper
INFO - 2024-02-27 14:24:53 --> Helper loaded: form_helper
INFO - 2024-02-27 14:24:53 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:24:53 --> Helper loaded: security_helper
INFO - 2024-02-27 14:24:53 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:24:53 --> Database Driver Class Initialized
INFO - 2024-02-27 14:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:24:53 --> Parser Class Initialized
INFO - 2024-02-27 14:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:24:53 --> Pagination Class Initialized
INFO - 2024-02-27 14:24:53 --> Form Validation Class Initialized
INFO - 2024-02-27 14:24:53 --> Controller Class Initialized
INFO - 2024-02-27 14:24:53 --> Model Class Initialized
DEBUG - 2024-02-27 14:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:24:53 --> Model Class Initialized
DEBUG - 2024-02-27 14:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:24:53 --> Model Class Initialized
INFO - 2024-02-27 14:24:53 --> Model Class Initialized
INFO - 2024-02-27 14:24:53 --> Model Class Initialized
INFO - 2024-02-27 14:24:53 --> Model Class Initialized
DEBUG - 2024-02-27 14:24:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:24:53 --> Model Class Initialized
INFO - 2024-02-27 14:24:53 --> Model Class Initialized
INFO - 2024-02-27 14:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:24:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:24:53 --> Model Class Initialized
INFO - 2024-02-27 14:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:24:54 --> Final output sent to browser
DEBUG - 2024-02-27 14:24:54 --> Total execution time: 0.2604
ERROR - 2024-02-27 14:27:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:27:26 --> Config Class Initialized
INFO - 2024-02-27 14:27:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:27:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:27:26 --> Utf8 Class Initialized
INFO - 2024-02-27 14:27:26 --> URI Class Initialized
INFO - 2024-02-27 14:27:26 --> Router Class Initialized
INFO - 2024-02-27 14:27:26 --> Output Class Initialized
INFO - 2024-02-27 14:27:26 --> Security Class Initialized
DEBUG - 2024-02-27 14:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:27:26 --> Input Class Initialized
INFO - 2024-02-27 14:27:26 --> Language Class Initialized
INFO - 2024-02-27 14:27:26 --> Loader Class Initialized
INFO - 2024-02-27 14:27:26 --> Helper loaded: url_helper
INFO - 2024-02-27 14:27:26 --> Helper loaded: file_helper
INFO - 2024-02-27 14:27:26 --> Helper loaded: html_helper
INFO - 2024-02-27 14:27:26 --> Helper loaded: text_helper
INFO - 2024-02-27 14:27:26 --> Helper loaded: form_helper
INFO - 2024-02-27 14:27:26 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:27:26 --> Helper loaded: security_helper
INFO - 2024-02-27 14:27:26 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:27:26 --> Database Driver Class Initialized
INFO - 2024-02-27 14:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:27:26 --> Parser Class Initialized
INFO - 2024-02-27 14:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:27:26 --> Pagination Class Initialized
INFO - 2024-02-27 14:27:26 --> Form Validation Class Initialized
INFO - 2024-02-27 14:27:26 --> Controller Class Initialized
INFO - 2024-02-27 14:27:26 --> Model Class Initialized
DEBUG - 2024-02-27 14:27:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:26 --> Model Class Initialized
DEBUG - 2024-02-27 14:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:26 --> Model Class Initialized
INFO - 2024-02-27 14:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-27 14:27:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:27:26 --> Model Class Initialized
INFO - 2024-02-27 14:27:26 --> Model Class Initialized
INFO - 2024-02-27 14:27:26 --> Model Class Initialized
INFO - 2024-02-27 14:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:27:26 --> Final output sent to browser
DEBUG - 2024-02-27 14:27:26 --> Total execution time: 0.1781
ERROR - 2024-02-27 14:27:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:27:33 --> Config Class Initialized
INFO - 2024-02-27 14:27:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:27:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:27:33 --> Utf8 Class Initialized
INFO - 2024-02-27 14:27:33 --> URI Class Initialized
INFO - 2024-02-27 14:27:33 --> Router Class Initialized
INFO - 2024-02-27 14:27:33 --> Output Class Initialized
INFO - 2024-02-27 14:27:33 --> Security Class Initialized
DEBUG - 2024-02-27 14:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:27:33 --> Input Class Initialized
INFO - 2024-02-27 14:27:33 --> Language Class Initialized
INFO - 2024-02-27 14:27:33 --> Loader Class Initialized
INFO - 2024-02-27 14:27:33 --> Helper loaded: url_helper
INFO - 2024-02-27 14:27:33 --> Helper loaded: file_helper
INFO - 2024-02-27 14:27:33 --> Helper loaded: html_helper
INFO - 2024-02-27 14:27:33 --> Helper loaded: text_helper
INFO - 2024-02-27 14:27:33 --> Helper loaded: form_helper
INFO - 2024-02-27 14:27:33 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:27:33 --> Helper loaded: security_helper
INFO - 2024-02-27 14:27:33 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:27:33 --> Database Driver Class Initialized
INFO - 2024-02-27 14:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:27:33 --> Parser Class Initialized
INFO - 2024-02-27 14:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:27:33 --> Pagination Class Initialized
INFO - 2024-02-27 14:27:33 --> Form Validation Class Initialized
INFO - 2024-02-27 14:27:33 --> Controller Class Initialized
INFO - 2024-02-27 14:27:33 --> Model Class Initialized
DEBUG - 2024-02-27 14:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:33 --> Final output sent to browser
DEBUG - 2024-02-27 14:27:33 --> Total execution time: 0.0162
ERROR - 2024-02-27 14:27:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:27:40 --> Config Class Initialized
INFO - 2024-02-27 14:27:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:27:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:27:40 --> Utf8 Class Initialized
INFO - 2024-02-27 14:27:40 --> URI Class Initialized
DEBUG - 2024-02-27 14:27:40 --> No URI present. Default controller set.
INFO - 2024-02-27 14:27:40 --> Router Class Initialized
INFO - 2024-02-27 14:27:40 --> Output Class Initialized
INFO - 2024-02-27 14:27:40 --> Security Class Initialized
DEBUG - 2024-02-27 14:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:27:40 --> Input Class Initialized
INFO - 2024-02-27 14:27:40 --> Language Class Initialized
INFO - 2024-02-27 14:27:40 --> Loader Class Initialized
INFO - 2024-02-27 14:27:40 --> Helper loaded: url_helper
INFO - 2024-02-27 14:27:40 --> Helper loaded: file_helper
INFO - 2024-02-27 14:27:40 --> Helper loaded: html_helper
INFO - 2024-02-27 14:27:40 --> Helper loaded: text_helper
INFO - 2024-02-27 14:27:40 --> Helper loaded: form_helper
INFO - 2024-02-27 14:27:40 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:27:40 --> Helper loaded: security_helper
INFO - 2024-02-27 14:27:40 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:27:40 --> Database Driver Class Initialized
INFO - 2024-02-27 14:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:27:40 --> Parser Class Initialized
INFO - 2024-02-27 14:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:27:40 --> Pagination Class Initialized
INFO - 2024-02-27 14:27:40 --> Form Validation Class Initialized
INFO - 2024-02-27 14:27:40 --> Controller Class Initialized
INFO - 2024-02-27 14:27:40 --> Model Class Initialized
DEBUG - 2024-02-27 14:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:40 --> Model Class Initialized
DEBUG - 2024-02-27 14:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:40 --> Model Class Initialized
INFO - 2024-02-27 14:27:40 --> Model Class Initialized
INFO - 2024-02-27 14:27:40 --> Model Class Initialized
INFO - 2024-02-27 14:27:40 --> Model Class Initialized
DEBUG - 2024-02-27 14:27:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:40 --> Model Class Initialized
INFO - 2024-02-27 14:27:40 --> Model Class Initialized
INFO - 2024-02-27 14:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:27:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:27:40 --> Model Class Initialized
INFO - 2024-02-27 14:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:27:40 --> Final output sent to browser
DEBUG - 2024-02-27 14:27:40 --> Total execution time: 0.2593
ERROR - 2024-02-27 14:27:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:27:47 --> Config Class Initialized
INFO - 2024-02-27 14:27:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:27:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:27:47 --> Utf8 Class Initialized
INFO - 2024-02-27 14:27:47 --> URI Class Initialized
INFO - 2024-02-27 14:27:47 --> Router Class Initialized
INFO - 2024-02-27 14:27:47 --> Output Class Initialized
INFO - 2024-02-27 14:27:47 --> Security Class Initialized
DEBUG - 2024-02-27 14:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:27:47 --> Input Class Initialized
INFO - 2024-02-27 14:27:47 --> Language Class Initialized
INFO - 2024-02-27 14:27:47 --> Loader Class Initialized
INFO - 2024-02-27 14:27:47 --> Helper loaded: url_helper
INFO - 2024-02-27 14:27:47 --> Helper loaded: file_helper
INFO - 2024-02-27 14:27:47 --> Helper loaded: html_helper
INFO - 2024-02-27 14:27:47 --> Helper loaded: text_helper
INFO - 2024-02-27 14:27:47 --> Helper loaded: form_helper
INFO - 2024-02-27 14:27:47 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:27:47 --> Helper loaded: security_helper
INFO - 2024-02-27 14:27:47 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:27:47 --> Database Driver Class Initialized
INFO - 2024-02-27 14:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:27:47 --> Parser Class Initialized
INFO - 2024-02-27 14:27:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:27:47 --> Pagination Class Initialized
INFO - 2024-02-27 14:27:47 --> Form Validation Class Initialized
INFO - 2024-02-27 14:27:47 --> Controller Class Initialized
INFO - 2024-02-27 14:27:47 --> Model Class Initialized
DEBUG - 2024-02-27 14:27:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:47 --> Model Class Initialized
DEBUG - 2024-02-27 14:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:47 --> Model Class Initialized
INFO - 2024-02-27 14:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-27 14:27:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:27:47 --> Model Class Initialized
INFO - 2024-02-27 14:27:47 --> Model Class Initialized
INFO - 2024-02-27 14:27:47 --> Model Class Initialized
INFO - 2024-02-27 14:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:27:47 --> Final output sent to browser
DEBUG - 2024-02-27 14:27:47 --> Total execution time: 0.1820
ERROR - 2024-02-27 14:27:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:27:53 --> Config Class Initialized
INFO - 2024-02-27 14:27:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:27:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:27:53 --> Utf8 Class Initialized
INFO - 2024-02-27 14:27:53 --> URI Class Initialized
INFO - 2024-02-27 14:27:53 --> Router Class Initialized
INFO - 2024-02-27 14:27:53 --> Output Class Initialized
INFO - 2024-02-27 14:27:53 --> Security Class Initialized
DEBUG - 2024-02-27 14:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:27:53 --> Input Class Initialized
INFO - 2024-02-27 14:27:53 --> Language Class Initialized
INFO - 2024-02-27 14:27:53 --> Loader Class Initialized
INFO - 2024-02-27 14:27:53 --> Helper loaded: url_helper
INFO - 2024-02-27 14:27:53 --> Helper loaded: file_helper
INFO - 2024-02-27 14:27:53 --> Helper loaded: html_helper
INFO - 2024-02-27 14:27:53 --> Helper loaded: text_helper
INFO - 2024-02-27 14:27:53 --> Helper loaded: form_helper
INFO - 2024-02-27 14:27:53 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:27:53 --> Helper loaded: security_helper
INFO - 2024-02-27 14:27:53 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:27:53 --> Database Driver Class Initialized
INFO - 2024-02-27 14:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:27:53 --> Parser Class Initialized
INFO - 2024-02-27 14:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:27:53 --> Pagination Class Initialized
INFO - 2024-02-27 14:27:53 --> Form Validation Class Initialized
INFO - 2024-02-27 14:27:53 --> Controller Class Initialized
INFO - 2024-02-27 14:27:53 --> Model Class Initialized
DEBUG - 2024-02-27 14:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:27:53 --> Final output sent to browser
DEBUG - 2024-02-27 14:27:53 --> Total execution time: 0.0144
ERROR - 2024-02-27 14:28:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:28:01 --> Config Class Initialized
INFO - 2024-02-27 14:28:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:28:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:28:01 --> Utf8 Class Initialized
INFO - 2024-02-27 14:28:01 --> URI Class Initialized
INFO - 2024-02-27 14:28:01 --> Router Class Initialized
INFO - 2024-02-27 14:28:01 --> Output Class Initialized
INFO - 2024-02-27 14:28:01 --> Security Class Initialized
DEBUG - 2024-02-27 14:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:28:01 --> Input Class Initialized
INFO - 2024-02-27 14:28:01 --> Language Class Initialized
INFO - 2024-02-27 14:28:01 --> Loader Class Initialized
INFO - 2024-02-27 14:28:01 --> Helper loaded: url_helper
INFO - 2024-02-27 14:28:01 --> Helper loaded: file_helper
INFO - 2024-02-27 14:28:01 --> Helper loaded: html_helper
INFO - 2024-02-27 14:28:01 --> Helper loaded: text_helper
INFO - 2024-02-27 14:28:01 --> Helper loaded: form_helper
INFO - 2024-02-27 14:28:01 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:28:01 --> Helper loaded: security_helper
INFO - 2024-02-27 14:28:01 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:28:01 --> Database Driver Class Initialized
INFO - 2024-02-27 14:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:28:01 --> Parser Class Initialized
INFO - 2024-02-27 14:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:28:01 --> Pagination Class Initialized
INFO - 2024-02-27 14:28:01 --> Form Validation Class Initialized
INFO - 2024-02-27 14:28:01 --> Controller Class Initialized
INFO - 2024-02-27 14:28:01 --> Final output sent to browser
DEBUG - 2024-02-27 14:28:01 --> Total execution time: 0.0168
ERROR - 2024-02-27 14:28:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:28:07 --> Config Class Initialized
INFO - 2024-02-27 14:28:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:28:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:28:07 --> Utf8 Class Initialized
INFO - 2024-02-27 14:28:07 --> URI Class Initialized
INFO - 2024-02-27 14:28:07 --> Router Class Initialized
INFO - 2024-02-27 14:28:07 --> Output Class Initialized
INFO - 2024-02-27 14:28:07 --> Security Class Initialized
DEBUG - 2024-02-27 14:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:28:07 --> Input Class Initialized
INFO - 2024-02-27 14:28:07 --> Language Class Initialized
INFO - 2024-02-27 14:28:07 --> Loader Class Initialized
INFO - 2024-02-27 14:28:07 --> Helper loaded: url_helper
INFO - 2024-02-27 14:28:07 --> Helper loaded: file_helper
INFO - 2024-02-27 14:28:07 --> Helper loaded: html_helper
INFO - 2024-02-27 14:28:07 --> Helper loaded: text_helper
INFO - 2024-02-27 14:28:07 --> Helper loaded: form_helper
INFO - 2024-02-27 14:28:07 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:28:07 --> Helper loaded: security_helper
INFO - 2024-02-27 14:28:07 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:28:07 --> Database Driver Class Initialized
INFO - 2024-02-27 14:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:28:08 --> Parser Class Initialized
INFO - 2024-02-27 14:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:28:08 --> Pagination Class Initialized
INFO - 2024-02-27 14:28:08 --> Form Validation Class Initialized
INFO - 2024-02-27 14:28:08 --> Controller Class Initialized
INFO - 2024-02-27 14:28:08 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:08 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:08 --> Model Class Initialized
INFO - 2024-02-27 14:28:08 --> Final output sent to browser
DEBUG - 2024-02-27 14:28:08 --> Total execution time: 0.1348
ERROR - 2024-02-27 14:28:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:28:10 --> Config Class Initialized
INFO - 2024-02-27 14:28:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:28:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:28:10 --> Utf8 Class Initialized
INFO - 2024-02-27 14:28:10 --> URI Class Initialized
INFO - 2024-02-27 14:28:10 --> Router Class Initialized
INFO - 2024-02-27 14:28:10 --> Output Class Initialized
INFO - 2024-02-27 14:28:10 --> Security Class Initialized
DEBUG - 2024-02-27 14:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:28:10 --> Input Class Initialized
INFO - 2024-02-27 14:28:10 --> Language Class Initialized
INFO - 2024-02-27 14:28:10 --> Loader Class Initialized
INFO - 2024-02-27 14:28:10 --> Helper loaded: url_helper
INFO - 2024-02-27 14:28:10 --> Helper loaded: file_helper
INFO - 2024-02-27 14:28:10 --> Helper loaded: html_helper
INFO - 2024-02-27 14:28:10 --> Helper loaded: text_helper
INFO - 2024-02-27 14:28:10 --> Helper loaded: form_helper
INFO - 2024-02-27 14:28:10 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:28:10 --> Helper loaded: security_helper
INFO - 2024-02-27 14:28:10 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:28:10 --> Database Driver Class Initialized
INFO - 2024-02-27 14:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:28:10 --> Parser Class Initialized
INFO - 2024-02-27 14:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:28:10 --> Pagination Class Initialized
INFO - 2024-02-27 14:28:10 --> Form Validation Class Initialized
INFO - 2024-02-27 14:28:10 --> Controller Class Initialized
INFO - 2024-02-27 14:28:10 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:10 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:10 --> Model Class Initialized
INFO - 2024-02-27 14:28:10 --> Final output sent to browser
DEBUG - 2024-02-27 14:28:10 --> Total execution time: 0.1285
ERROR - 2024-02-27 14:28:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:28:11 --> Config Class Initialized
INFO - 2024-02-27 14:28:11 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:28:11 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:28:11 --> Utf8 Class Initialized
INFO - 2024-02-27 14:28:11 --> URI Class Initialized
INFO - 2024-02-27 14:28:11 --> Router Class Initialized
INFO - 2024-02-27 14:28:11 --> Output Class Initialized
INFO - 2024-02-27 14:28:11 --> Security Class Initialized
DEBUG - 2024-02-27 14:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:28:11 --> Input Class Initialized
INFO - 2024-02-27 14:28:11 --> Language Class Initialized
INFO - 2024-02-27 14:28:11 --> Loader Class Initialized
INFO - 2024-02-27 14:28:11 --> Helper loaded: url_helper
INFO - 2024-02-27 14:28:11 --> Helper loaded: file_helper
INFO - 2024-02-27 14:28:11 --> Helper loaded: html_helper
INFO - 2024-02-27 14:28:11 --> Helper loaded: text_helper
INFO - 2024-02-27 14:28:11 --> Helper loaded: form_helper
INFO - 2024-02-27 14:28:11 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:28:11 --> Helper loaded: security_helper
INFO - 2024-02-27 14:28:11 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:28:11 --> Database Driver Class Initialized
INFO - 2024-02-27 14:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:28:11 --> Parser Class Initialized
INFO - 2024-02-27 14:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:28:11 --> Pagination Class Initialized
INFO - 2024-02-27 14:28:11 --> Form Validation Class Initialized
INFO - 2024-02-27 14:28:11 --> Controller Class Initialized
INFO - 2024-02-27 14:28:11 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:11 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:11 --> Model Class Initialized
INFO - 2024-02-27 14:28:12 --> Final output sent to browser
DEBUG - 2024-02-27 14:28:12 --> Total execution time: 0.1439
ERROR - 2024-02-27 14:28:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:28:16 --> Config Class Initialized
INFO - 2024-02-27 14:28:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:28:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:28:16 --> Utf8 Class Initialized
INFO - 2024-02-27 14:28:16 --> URI Class Initialized
INFO - 2024-02-27 14:28:16 --> Router Class Initialized
INFO - 2024-02-27 14:28:16 --> Output Class Initialized
INFO - 2024-02-27 14:28:16 --> Security Class Initialized
DEBUG - 2024-02-27 14:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:28:16 --> Input Class Initialized
INFO - 2024-02-27 14:28:16 --> Language Class Initialized
INFO - 2024-02-27 14:28:16 --> Loader Class Initialized
INFO - 2024-02-27 14:28:16 --> Helper loaded: url_helper
INFO - 2024-02-27 14:28:16 --> Helper loaded: file_helper
INFO - 2024-02-27 14:28:16 --> Helper loaded: html_helper
INFO - 2024-02-27 14:28:16 --> Helper loaded: text_helper
INFO - 2024-02-27 14:28:16 --> Helper loaded: form_helper
INFO - 2024-02-27 14:28:16 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:28:16 --> Helper loaded: security_helper
INFO - 2024-02-27 14:28:16 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:28:16 --> Database Driver Class Initialized
INFO - 2024-02-27 14:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:28:16 --> Parser Class Initialized
INFO - 2024-02-27 14:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:28:16 --> Pagination Class Initialized
INFO - 2024-02-27 14:28:16 --> Form Validation Class Initialized
INFO - 2024-02-27 14:28:16 --> Controller Class Initialized
INFO - 2024-02-27 14:28:16 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:16 --> Model Class Initialized
INFO - 2024-02-27 14:28:16 --> Model Class Initialized
INFO - 2024-02-27 14:28:16 --> Final output sent to browser
DEBUG - 2024-02-27 14:28:16 --> Total execution time: 0.0217
ERROR - 2024-02-27 14:28:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:28:20 --> Config Class Initialized
INFO - 2024-02-27 14:28:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:28:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:28:20 --> Utf8 Class Initialized
INFO - 2024-02-27 14:28:20 --> URI Class Initialized
INFO - 2024-02-27 14:28:20 --> Router Class Initialized
INFO - 2024-02-27 14:28:20 --> Output Class Initialized
INFO - 2024-02-27 14:28:20 --> Security Class Initialized
DEBUG - 2024-02-27 14:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:28:20 --> Input Class Initialized
INFO - 2024-02-27 14:28:20 --> Language Class Initialized
INFO - 2024-02-27 14:28:20 --> Loader Class Initialized
INFO - 2024-02-27 14:28:20 --> Helper loaded: url_helper
INFO - 2024-02-27 14:28:20 --> Helper loaded: file_helper
INFO - 2024-02-27 14:28:20 --> Helper loaded: html_helper
INFO - 2024-02-27 14:28:20 --> Helper loaded: text_helper
INFO - 2024-02-27 14:28:20 --> Helper loaded: form_helper
INFO - 2024-02-27 14:28:20 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:28:20 --> Helper loaded: security_helper
INFO - 2024-02-27 14:28:20 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:28:20 --> Database Driver Class Initialized
INFO - 2024-02-27 14:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:28:20 --> Parser Class Initialized
INFO - 2024-02-27 14:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:28:20 --> Pagination Class Initialized
INFO - 2024-02-27 14:28:20 --> Form Validation Class Initialized
INFO - 2024-02-27 14:28:20 --> Controller Class Initialized
INFO - 2024-02-27 14:28:20 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:20 --> Model Class Initialized
INFO - 2024-02-27 14:28:20 --> Final output sent to browser
DEBUG - 2024-02-27 14:28:20 --> Total execution time: 0.0166
ERROR - 2024-02-27 14:28:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:28:48 --> Config Class Initialized
INFO - 2024-02-27 14:28:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:28:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:28:48 --> Utf8 Class Initialized
INFO - 2024-02-27 14:28:48 --> URI Class Initialized
INFO - 2024-02-27 14:28:48 --> Router Class Initialized
INFO - 2024-02-27 14:28:48 --> Output Class Initialized
INFO - 2024-02-27 14:28:48 --> Security Class Initialized
DEBUG - 2024-02-27 14:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:28:48 --> Input Class Initialized
INFO - 2024-02-27 14:28:48 --> Language Class Initialized
INFO - 2024-02-27 14:28:48 --> Loader Class Initialized
INFO - 2024-02-27 14:28:48 --> Helper loaded: url_helper
INFO - 2024-02-27 14:28:48 --> Helper loaded: file_helper
INFO - 2024-02-27 14:28:48 --> Helper loaded: html_helper
INFO - 2024-02-27 14:28:48 --> Helper loaded: text_helper
INFO - 2024-02-27 14:28:48 --> Helper loaded: form_helper
INFO - 2024-02-27 14:28:48 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:28:48 --> Helper loaded: security_helper
INFO - 2024-02-27 14:28:48 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:28:48 --> Database Driver Class Initialized
INFO - 2024-02-27 14:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:28:48 --> Parser Class Initialized
INFO - 2024-02-27 14:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:28:48 --> Pagination Class Initialized
INFO - 2024-02-27 14:28:48 --> Form Validation Class Initialized
INFO - 2024-02-27 14:28:48 --> Controller Class Initialized
INFO - 2024-02-27 14:28:48 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:48 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:48 --> Model Class Initialized
INFO - 2024-02-27 14:28:48 --> Email Class Initialized
DEBUG - 2024-02-27 14:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-27 14:28:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-27 14:28:48 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-27 14:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-27 14:28:48 --> Final output sent to browser
DEBUG - 2024-02-27 14:28:48 --> Total execution time: 0.2435
ERROR - 2024-02-27 14:28:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:28:55 --> Config Class Initialized
INFO - 2024-02-27 14:28:55 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:28:55 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:28:55 --> Utf8 Class Initialized
INFO - 2024-02-27 14:28:55 --> URI Class Initialized
DEBUG - 2024-02-27 14:28:55 --> No URI present. Default controller set.
INFO - 2024-02-27 14:28:55 --> Router Class Initialized
INFO - 2024-02-27 14:28:55 --> Output Class Initialized
INFO - 2024-02-27 14:28:55 --> Security Class Initialized
DEBUG - 2024-02-27 14:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:28:55 --> Input Class Initialized
INFO - 2024-02-27 14:28:55 --> Language Class Initialized
INFO - 2024-02-27 14:28:55 --> Loader Class Initialized
INFO - 2024-02-27 14:28:55 --> Helper loaded: url_helper
INFO - 2024-02-27 14:28:55 --> Helper loaded: file_helper
INFO - 2024-02-27 14:28:55 --> Helper loaded: html_helper
INFO - 2024-02-27 14:28:55 --> Helper loaded: text_helper
INFO - 2024-02-27 14:28:55 --> Helper loaded: form_helper
INFO - 2024-02-27 14:28:55 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:28:55 --> Helper loaded: security_helper
INFO - 2024-02-27 14:28:55 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:28:55 --> Database Driver Class Initialized
INFO - 2024-02-27 14:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:28:55 --> Parser Class Initialized
INFO - 2024-02-27 14:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:28:55 --> Pagination Class Initialized
INFO - 2024-02-27 14:28:55 --> Form Validation Class Initialized
INFO - 2024-02-27 14:28:55 --> Controller Class Initialized
INFO - 2024-02-27 14:28:55 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:55 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:55 --> Model Class Initialized
INFO - 2024-02-27 14:28:55 --> Model Class Initialized
INFO - 2024-02-27 14:28:55 --> Model Class Initialized
INFO - 2024-02-27 14:28:55 --> Model Class Initialized
DEBUG - 2024-02-27 14:28:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:55 --> Model Class Initialized
INFO - 2024-02-27 14:28:55 --> Model Class Initialized
INFO - 2024-02-27 14:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:28:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:28:56 --> Model Class Initialized
INFO - 2024-02-27 14:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:28:56 --> Final output sent to browser
DEBUG - 2024-02-27 14:28:56 --> Total execution time: 0.2420
ERROR - 2024-02-27 14:29:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:29:07 --> Config Class Initialized
INFO - 2024-02-27 14:29:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:29:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:29:07 --> Utf8 Class Initialized
INFO - 2024-02-27 14:29:07 --> URI Class Initialized
INFO - 2024-02-27 14:29:07 --> Router Class Initialized
INFO - 2024-02-27 14:29:07 --> Output Class Initialized
INFO - 2024-02-27 14:29:07 --> Security Class Initialized
DEBUG - 2024-02-27 14:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:29:07 --> Input Class Initialized
INFO - 2024-02-27 14:29:07 --> Language Class Initialized
INFO - 2024-02-27 14:29:07 --> Loader Class Initialized
INFO - 2024-02-27 14:29:07 --> Helper loaded: url_helper
INFO - 2024-02-27 14:29:07 --> Helper loaded: file_helper
INFO - 2024-02-27 14:29:07 --> Helper loaded: html_helper
INFO - 2024-02-27 14:29:07 --> Helper loaded: text_helper
INFO - 2024-02-27 14:29:07 --> Helper loaded: form_helper
INFO - 2024-02-27 14:29:07 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:29:07 --> Helper loaded: security_helper
INFO - 2024-02-27 14:29:07 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:29:07 --> Database Driver Class Initialized
INFO - 2024-02-27 14:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:29:07 --> Parser Class Initialized
INFO - 2024-02-27 14:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:29:07 --> Pagination Class Initialized
INFO - 2024-02-27 14:29:07 --> Form Validation Class Initialized
INFO - 2024-02-27 14:29:07 --> Controller Class Initialized
INFO - 2024-02-27 14:29:07 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:07 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:07 --> Model Class Initialized
INFO - 2024-02-27 14:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-27 14:29:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:29:07 --> Model Class Initialized
INFO - 2024-02-27 14:29:07 --> Model Class Initialized
INFO - 2024-02-27 14:29:07 --> Model Class Initialized
INFO - 2024-02-27 14:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:29:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:29:07 --> Final output sent to browser
DEBUG - 2024-02-27 14:29:07 --> Total execution time: 0.1586
ERROR - 2024-02-27 14:29:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:29:08 --> Config Class Initialized
INFO - 2024-02-27 14:29:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:29:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:29:08 --> Utf8 Class Initialized
INFO - 2024-02-27 14:29:08 --> URI Class Initialized
INFO - 2024-02-27 14:29:08 --> Router Class Initialized
INFO - 2024-02-27 14:29:08 --> Output Class Initialized
INFO - 2024-02-27 14:29:08 --> Security Class Initialized
DEBUG - 2024-02-27 14:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:29:08 --> Input Class Initialized
INFO - 2024-02-27 14:29:08 --> Language Class Initialized
INFO - 2024-02-27 14:29:08 --> Loader Class Initialized
INFO - 2024-02-27 14:29:08 --> Helper loaded: url_helper
INFO - 2024-02-27 14:29:08 --> Helper loaded: file_helper
INFO - 2024-02-27 14:29:08 --> Helper loaded: html_helper
INFO - 2024-02-27 14:29:08 --> Helper loaded: text_helper
INFO - 2024-02-27 14:29:08 --> Helper loaded: form_helper
INFO - 2024-02-27 14:29:08 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:29:08 --> Helper loaded: security_helper
INFO - 2024-02-27 14:29:08 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:29:08 --> Database Driver Class Initialized
INFO - 2024-02-27 14:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:29:08 --> Parser Class Initialized
INFO - 2024-02-27 14:29:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:29:08 --> Pagination Class Initialized
INFO - 2024-02-27 14:29:08 --> Form Validation Class Initialized
INFO - 2024-02-27 14:29:08 --> Controller Class Initialized
INFO - 2024-02-27 14:29:08 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:08 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:08 --> Model Class Initialized
INFO - 2024-02-27 14:29:08 --> Final output sent to browser
DEBUG - 2024-02-27 14:29:08 --> Total execution time: 0.0442
ERROR - 2024-02-27 14:29:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:29:14 --> Config Class Initialized
INFO - 2024-02-27 14:29:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:29:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:29:14 --> Utf8 Class Initialized
INFO - 2024-02-27 14:29:14 --> URI Class Initialized
INFO - 2024-02-27 14:29:14 --> Router Class Initialized
INFO - 2024-02-27 14:29:14 --> Output Class Initialized
INFO - 2024-02-27 14:29:14 --> Security Class Initialized
DEBUG - 2024-02-27 14:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:29:14 --> Input Class Initialized
INFO - 2024-02-27 14:29:14 --> Language Class Initialized
INFO - 2024-02-27 14:29:14 --> Loader Class Initialized
INFO - 2024-02-27 14:29:14 --> Helper loaded: url_helper
INFO - 2024-02-27 14:29:14 --> Helper loaded: file_helper
INFO - 2024-02-27 14:29:14 --> Helper loaded: html_helper
INFO - 2024-02-27 14:29:14 --> Helper loaded: text_helper
INFO - 2024-02-27 14:29:14 --> Helper loaded: form_helper
INFO - 2024-02-27 14:29:14 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:29:14 --> Helper loaded: security_helper
INFO - 2024-02-27 14:29:14 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:29:14 --> Database Driver Class Initialized
INFO - 2024-02-27 14:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:29:14 --> Parser Class Initialized
INFO - 2024-02-27 14:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:29:14 --> Pagination Class Initialized
INFO - 2024-02-27 14:29:14 --> Form Validation Class Initialized
INFO - 2024-02-27 14:29:14 --> Controller Class Initialized
INFO - 2024-02-27 14:29:14 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:14 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:14 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-27 14:29:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:29:14 --> Model Class Initialized
INFO - 2024-02-27 14:29:14 --> Model Class Initialized
INFO - 2024-02-27 14:29:14 --> Model Class Initialized
INFO - 2024-02-27 14:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:29:14 --> Final output sent to browser
DEBUG - 2024-02-27 14:29:14 --> Total execution time: 0.1715
ERROR - 2024-02-27 14:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:29:30 --> Config Class Initialized
INFO - 2024-02-27 14:29:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:29:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:29:30 --> Utf8 Class Initialized
INFO - 2024-02-27 14:29:30 --> URI Class Initialized
INFO - 2024-02-27 14:29:30 --> Router Class Initialized
INFO - 2024-02-27 14:29:30 --> Output Class Initialized
INFO - 2024-02-27 14:29:30 --> Security Class Initialized
DEBUG - 2024-02-27 14:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:29:30 --> Input Class Initialized
INFO - 2024-02-27 14:29:30 --> Language Class Initialized
INFO - 2024-02-27 14:29:30 --> Loader Class Initialized
INFO - 2024-02-27 14:29:30 --> Helper loaded: url_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: file_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: html_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: text_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: form_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: security_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:29:30 --> Database Driver Class Initialized
INFO - 2024-02-27 14:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:29:30 --> Parser Class Initialized
INFO - 2024-02-27 14:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:29:30 --> Pagination Class Initialized
INFO - 2024-02-27 14:29:30 --> Form Validation Class Initialized
INFO - 2024-02-27 14:29:30 --> Controller Class Initialized
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-27 14:29:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:29:30 --> Final output sent to browser
DEBUG - 2024-02-27 14:29:30 --> Total execution time: 0.1911
ERROR - 2024-02-27 14:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 14:29:30 --> Config Class Initialized
INFO - 2024-02-27 14:29:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 14:29:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 14:29:30 --> Utf8 Class Initialized
INFO - 2024-02-27 14:29:30 --> URI Class Initialized
DEBUG - 2024-02-27 14:29:30 --> No URI present. Default controller set.
INFO - 2024-02-27 14:29:30 --> Router Class Initialized
INFO - 2024-02-27 14:29:30 --> Output Class Initialized
INFO - 2024-02-27 14:29:30 --> Security Class Initialized
DEBUG - 2024-02-27 14:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 14:29:30 --> Input Class Initialized
INFO - 2024-02-27 14:29:30 --> Language Class Initialized
INFO - 2024-02-27 14:29:30 --> Loader Class Initialized
INFO - 2024-02-27 14:29:30 --> Helper loaded: url_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: file_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: html_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: text_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: form_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: lang_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: security_helper
INFO - 2024-02-27 14:29:30 --> Helper loaded: cookie_helper
INFO - 2024-02-27 14:29:30 --> Database Driver Class Initialized
INFO - 2024-02-27 14:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 14:29:30 --> Parser Class Initialized
INFO - 2024-02-27 14:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 14:29:30 --> Pagination Class Initialized
INFO - 2024-02-27 14:29:30 --> Form Validation Class Initialized
INFO - 2024-02-27 14:29:30 --> Controller Class Initialized
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
DEBUG - 2024-02-27 14:29:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 14:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-27 14:29:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-27 14:29:30 --> Model Class Initialized
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-27 14:29:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-27 14:29:30 --> Final output sent to browser
DEBUG - 2024-02-27 14:29:30 --> Total execution time: 0.2473
ERROR - 2024-02-27 16:22:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 16:22:19 --> Config Class Initialized
INFO - 2024-02-27 16:22:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 16:22:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 16:22:19 --> Utf8 Class Initialized
INFO - 2024-02-27 16:22:19 --> URI Class Initialized
DEBUG - 2024-02-27 16:22:19 --> No URI present. Default controller set.
INFO - 2024-02-27 16:22:19 --> Router Class Initialized
INFO - 2024-02-27 16:22:19 --> Output Class Initialized
INFO - 2024-02-27 16:22:19 --> Security Class Initialized
DEBUG - 2024-02-27 16:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 16:22:19 --> Input Class Initialized
INFO - 2024-02-27 16:22:19 --> Language Class Initialized
INFO - 2024-02-27 16:22:19 --> Loader Class Initialized
INFO - 2024-02-27 16:22:19 --> Helper loaded: url_helper
INFO - 2024-02-27 16:22:19 --> Helper loaded: file_helper
INFO - 2024-02-27 16:22:19 --> Helper loaded: html_helper
INFO - 2024-02-27 16:22:19 --> Helper loaded: text_helper
INFO - 2024-02-27 16:22:19 --> Helper loaded: form_helper
INFO - 2024-02-27 16:22:19 --> Helper loaded: lang_helper
INFO - 2024-02-27 16:22:19 --> Helper loaded: security_helper
INFO - 2024-02-27 16:22:19 --> Helper loaded: cookie_helper
INFO - 2024-02-27 16:22:19 --> Database Driver Class Initialized
INFO - 2024-02-27 16:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 16:22:19 --> Parser Class Initialized
INFO - 2024-02-27 16:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 16:22:19 --> Pagination Class Initialized
INFO - 2024-02-27 16:22:19 --> Form Validation Class Initialized
INFO - 2024-02-27 16:22:19 --> Controller Class Initialized
INFO - 2024-02-27 16:22:19 --> Model Class Initialized
DEBUG - 2024-02-27 16:22:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 16:55:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 16:55:11 --> Config Class Initialized
INFO - 2024-02-27 16:55:11 --> Hooks Class Initialized
DEBUG - 2024-02-27 16:55:11 --> UTF-8 Support Enabled
INFO - 2024-02-27 16:55:11 --> Utf8 Class Initialized
INFO - 2024-02-27 16:55:11 --> URI Class Initialized
DEBUG - 2024-02-27 16:55:11 --> No URI present. Default controller set.
INFO - 2024-02-27 16:55:11 --> Router Class Initialized
INFO - 2024-02-27 16:55:11 --> Output Class Initialized
INFO - 2024-02-27 16:55:11 --> Security Class Initialized
DEBUG - 2024-02-27 16:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 16:55:11 --> Input Class Initialized
INFO - 2024-02-27 16:55:11 --> Language Class Initialized
INFO - 2024-02-27 16:55:11 --> Loader Class Initialized
INFO - 2024-02-27 16:55:11 --> Helper loaded: url_helper
INFO - 2024-02-27 16:55:11 --> Helper loaded: file_helper
INFO - 2024-02-27 16:55:11 --> Helper loaded: html_helper
INFO - 2024-02-27 16:55:11 --> Helper loaded: text_helper
INFO - 2024-02-27 16:55:11 --> Helper loaded: form_helper
INFO - 2024-02-27 16:55:11 --> Helper loaded: lang_helper
INFO - 2024-02-27 16:55:11 --> Helper loaded: security_helper
INFO - 2024-02-27 16:55:11 --> Helper loaded: cookie_helper
INFO - 2024-02-27 16:55:11 --> Database Driver Class Initialized
INFO - 2024-02-27 16:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 16:55:11 --> Parser Class Initialized
INFO - 2024-02-27 16:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 16:55:11 --> Pagination Class Initialized
INFO - 2024-02-27 16:55:11 --> Form Validation Class Initialized
INFO - 2024-02-27 16:55:11 --> Controller Class Initialized
INFO - 2024-02-27 16:55:11 --> Model Class Initialized
DEBUG - 2024-02-27 16:55:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 19:23:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 19:23:21 --> Config Class Initialized
INFO - 2024-02-27 19:23:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 19:23:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 19:23:21 --> Utf8 Class Initialized
INFO - 2024-02-27 19:23:21 --> URI Class Initialized
DEBUG - 2024-02-27 19:23:21 --> No URI present. Default controller set.
INFO - 2024-02-27 19:23:21 --> Router Class Initialized
INFO - 2024-02-27 19:23:21 --> Output Class Initialized
INFO - 2024-02-27 19:23:21 --> Security Class Initialized
DEBUG - 2024-02-27 19:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 19:23:21 --> Input Class Initialized
INFO - 2024-02-27 19:23:21 --> Language Class Initialized
INFO - 2024-02-27 19:23:21 --> Loader Class Initialized
INFO - 2024-02-27 19:23:21 --> Helper loaded: url_helper
INFO - 2024-02-27 19:23:21 --> Helper loaded: file_helper
INFO - 2024-02-27 19:23:21 --> Helper loaded: html_helper
INFO - 2024-02-27 19:23:21 --> Helper loaded: text_helper
INFO - 2024-02-27 19:23:21 --> Helper loaded: form_helper
INFO - 2024-02-27 19:23:21 --> Helper loaded: lang_helper
INFO - 2024-02-27 19:23:21 --> Helper loaded: security_helper
INFO - 2024-02-27 19:23:21 --> Helper loaded: cookie_helper
INFO - 2024-02-27 19:23:21 --> Database Driver Class Initialized
INFO - 2024-02-27 19:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 19:23:21 --> Parser Class Initialized
INFO - 2024-02-27 19:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-27 19:23:21 --> Pagination Class Initialized
INFO - 2024-02-27 19:23:21 --> Form Validation Class Initialized
INFO - 2024-02-27 19:23:21 --> Controller Class Initialized
INFO - 2024-02-27 19:23:21 --> Model Class Initialized
DEBUG - 2024-02-27 19:23:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-27 20:09:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-27 20:09:40 --> Config Class Initialized
INFO - 2024-02-27 20:09:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 20:09:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 20:09:40 --> Utf8 Class Initialized
INFO - 2024-02-27 20:09:40 --> URI Class Initialized
INFO - 2024-02-27 20:09:40 --> Router Class Initialized
INFO - 2024-02-27 20:09:40 --> Output Class Initialized
INFO - 2024-02-27 20:09:40 --> Security Class Initialized
DEBUG - 2024-02-27 20:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 20:09:40 --> Input Class Initialized
INFO - 2024-02-27 20:09:40 --> Language Class Initialized
ERROR - 2024-02-27 20:09:40 --> 404 Page Not Found: Wp-loginphp/index
