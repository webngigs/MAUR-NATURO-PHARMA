<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-14 02:22:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:22:35 --> Config Class Initialized
INFO - 2023-05-14 02:22:35 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:22:35 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:22:35 --> Utf8 Class Initialized
INFO - 2023-05-14 02:22:35 --> URI Class Initialized
DEBUG - 2023-05-14 02:22:35 --> No URI present. Default controller set.
INFO - 2023-05-14 02:22:35 --> Router Class Initialized
INFO - 2023-05-14 02:22:35 --> Output Class Initialized
INFO - 2023-05-14 02:22:35 --> Security Class Initialized
DEBUG - 2023-05-14 02:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:22:35 --> Input Class Initialized
INFO - 2023-05-14 02:22:35 --> Language Class Initialized
INFO - 2023-05-14 02:22:35 --> Loader Class Initialized
INFO - 2023-05-14 02:22:35 --> Helper loaded: url_helper
INFO - 2023-05-14 02:22:35 --> Helper loaded: file_helper
INFO - 2023-05-14 02:22:35 --> Helper loaded: html_helper
INFO - 2023-05-14 02:22:35 --> Helper loaded: text_helper
INFO - 2023-05-14 02:22:35 --> Helper loaded: form_helper
INFO - 2023-05-14 02:22:35 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:22:35 --> Helper loaded: security_helper
INFO - 2023-05-14 02:22:35 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:22:35 --> Database Driver Class Initialized
INFO - 2023-05-14 02:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:22:35 --> Parser Class Initialized
INFO - 2023-05-14 02:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:22:35 --> Pagination Class Initialized
INFO - 2023-05-14 02:22:35 --> Form Validation Class Initialized
INFO - 2023-05-14 02:22:35 --> Controller Class Initialized
INFO - 2023-05-14 02:22:35 --> Model Class Initialized
DEBUG - 2023-05-14 02:22:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-14 02:22:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:22:36 --> Config Class Initialized
INFO - 2023-05-14 02:22:36 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:22:36 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:22:36 --> Utf8 Class Initialized
INFO - 2023-05-14 02:22:36 --> URI Class Initialized
INFO - 2023-05-14 02:22:36 --> Router Class Initialized
INFO - 2023-05-14 02:22:36 --> Output Class Initialized
INFO - 2023-05-14 02:22:36 --> Security Class Initialized
DEBUG - 2023-05-14 02:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:22:36 --> Input Class Initialized
INFO - 2023-05-14 02:22:36 --> Language Class Initialized
INFO - 2023-05-14 02:22:36 --> Loader Class Initialized
INFO - 2023-05-14 02:22:36 --> Helper loaded: url_helper
INFO - 2023-05-14 02:22:36 --> Helper loaded: file_helper
INFO - 2023-05-14 02:22:36 --> Helper loaded: html_helper
INFO - 2023-05-14 02:22:36 --> Helper loaded: text_helper
INFO - 2023-05-14 02:22:36 --> Helper loaded: form_helper
INFO - 2023-05-14 02:22:36 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:22:36 --> Helper loaded: security_helper
INFO - 2023-05-14 02:22:36 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:22:36 --> Database Driver Class Initialized
INFO - 2023-05-14 02:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:22:36 --> Parser Class Initialized
INFO - 2023-05-14 02:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:22:36 --> Pagination Class Initialized
INFO - 2023-05-14 02:22:36 --> Form Validation Class Initialized
INFO - 2023-05-14 02:22:36 --> Controller Class Initialized
INFO - 2023-05-14 02:22:36 --> Model Class Initialized
DEBUG - 2023-05-14 02:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:22:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-14 02:22:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:22:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:22:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:22:36 --> Model Class Initialized
INFO - 2023-05-14 02:22:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:22:36 --> Final output sent to browser
DEBUG - 2023-05-14 02:22:36 --> Total execution time: 0.0360
ERROR - 2023-05-14 02:23:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:23:20 --> Config Class Initialized
INFO - 2023-05-14 02:23:20 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:23:20 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:23:20 --> Utf8 Class Initialized
INFO - 2023-05-14 02:23:20 --> URI Class Initialized
INFO - 2023-05-14 02:23:20 --> Router Class Initialized
INFO - 2023-05-14 02:23:20 --> Output Class Initialized
INFO - 2023-05-14 02:23:20 --> Security Class Initialized
DEBUG - 2023-05-14 02:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:23:20 --> Input Class Initialized
INFO - 2023-05-14 02:23:20 --> Language Class Initialized
INFO - 2023-05-14 02:23:20 --> Loader Class Initialized
INFO - 2023-05-14 02:23:20 --> Helper loaded: url_helper
INFO - 2023-05-14 02:23:20 --> Helper loaded: file_helper
INFO - 2023-05-14 02:23:20 --> Helper loaded: html_helper
INFO - 2023-05-14 02:23:20 --> Helper loaded: text_helper
INFO - 2023-05-14 02:23:20 --> Helper loaded: form_helper
INFO - 2023-05-14 02:23:20 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:23:20 --> Helper loaded: security_helper
INFO - 2023-05-14 02:23:20 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:23:20 --> Database Driver Class Initialized
INFO - 2023-05-14 02:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:23:20 --> Parser Class Initialized
INFO - 2023-05-14 02:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:23:20 --> Pagination Class Initialized
INFO - 2023-05-14 02:23:20 --> Form Validation Class Initialized
INFO - 2023-05-14 02:23:20 --> Controller Class Initialized
INFO - 2023-05-14 02:23:20 --> Model Class Initialized
DEBUG - 2023-05-14 02:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:23:20 --> Model Class Initialized
INFO - 2023-05-14 02:23:20 --> Final output sent to browser
DEBUG - 2023-05-14 02:23:20 --> Total execution time: 0.0214
ERROR - 2023-05-14 02:23:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:23:21 --> Config Class Initialized
INFO - 2023-05-14 02:23:21 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:23:21 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:23:21 --> Utf8 Class Initialized
INFO - 2023-05-14 02:23:21 --> URI Class Initialized
INFO - 2023-05-14 02:23:21 --> Router Class Initialized
INFO - 2023-05-14 02:23:21 --> Output Class Initialized
INFO - 2023-05-14 02:23:21 --> Security Class Initialized
DEBUG - 2023-05-14 02:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:23:21 --> Input Class Initialized
INFO - 2023-05-14 02:23:21 --> Language Class Initialized
INFO - 2023-05-14 02:23:21 --> Loader Class Initialized
INFO - 2023-05-14 02:23:21 --> Helper loaded: url_helper
INFO - 2023-05-14 02:23:21 --> Helper loaded: file_helper
INFO - 2023-05-14 02:23:21 --> Helper loaded: html_helper
INFO - 2023-05-14 02:23:21 --> Helper loaded: text_helper
INFO - 2023-05-14 02:23:21 --> Helper loaded: form_helper
INFO - 2023-05-14 02:23:21 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:23:21 --> Helper loaded: security_helper
INFO - 2023-05-14 02:23:21 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:23:21 --> Database Driver Class Initialized
INFO - 2023-05-14 02:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:23:21 --> Parser Class Initialized
INFO - 2023-05-14 02:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:23:21 --> Pagination Class Initialized
INFO - 2023-05-14 02:23:21 --> Form Validation Class Initialized
INFO - 2023-05-14 02:23:21 --> Controller Class Initialized
INFO - 2023-05-14 02:23:21 --> Model Class Initialized
DEBUG - 2023-05-14 02:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-14 02:23:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:23:21 --> Model Class Initialized
INFO - 2023-05-14 02:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:23:21 --> Final output sent to browser
DEBUG - 2023-05-14 02:23:21 --> Total execution time: 0.0324
ERROR - 2023-05-14 02:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:23:43 --> Config Class Initialized
INFO - 2023-05-14 02:23:43 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:23:43 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:23:43 --> Utf8 Class Initialized
INFO - 2023-05-14 02:23:43 --> URI Class Initialized
INFO - 2023-05-14 02:23:43 --> Router Class Initialized
INFO - 2023-05-14 02:23:43 --> Output Class Initialized
INFO - 2023-05-14 02:23:43 --> Security Class Initialized
DEBUG - 2023-05-14 02:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:23:43 --> Input Class Initialized
INFO - 2023-05-14 02:23:43 --> Language Class Initialized
INFO - 2023-05-14 02:23:43 --> Loader Class Initialized
INFO - 2023-05-14 02:23:43 --> Helper loaded: url_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: file_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: html_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: text_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: form_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: security_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:23:43 --> Database Driver Class Initialized
INFO - 2023-05-14 02:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:23:43 --> Parser Class Initialized
INFO - 2023-05-14 02:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:23:43 --> Pagination Class Initialized
INFO - 2023-05-14 02:23:43 --> Form Validation Class Initialized
INFO - 2023-05-14 02:23:43 --> Controller Class Initialized
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
DEBUG - 2023-05-14 02:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
INFO - 2023-05-14 02:23:43 --> Final output sent to browser
DEBUG - 2023-05-14 02:23:43 --> Total execution time: 0.0200
ERROR - 2023-05-14 02:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:23:43 --> Config Class Initialized
INFO - 2023-05-14 02:23:43 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:23:43 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:23:43 --> Utf8 Class Initialized
INFO - 2023-05-14 02:23:43 --> URI Class Initialized
DEBUG - 2023-05-14 02:23:43 --> No URI present. Default controller set.
INFO - 2023-05-14 02:23:43 --> Router Class Initialized
INFO - 2023-05-14 02:23:43 --> Output Class Initialized
INFO - 2023-05-14 02:23:43 --> Security Class Initialized
DEBUG - 2023-05-14 02:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:23:43 --> Input Class Initialized
INFO - 2023-05-14 02:23:43 --> Language Class Initialized
INFO - 2023-05-14 02:23:43 --> Loader Class Initialized
INFO - 2023-05-14 02:23:43 --> Helper loaded: url_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: file_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: html_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: text_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: form_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: security_helper
INFO - 2023-05-14 02:23:43 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:23:43 --> Database Driver Class Initialized
INFO - 2023-05-14 02:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:23:43 --> Parser Class Initialized
INFO - 2023-05-14 02:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:23:43 --> Pagination Class Initialized
INFO - 2023-05-14 02:23:43 --> Form Validation Class Initialized
INFO - 2023-05-14 02:23:43 --> Controller Class Initialized
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
DEBUG - 2023-05-14 02:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
DEBUG - 2023-05-14 02:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
DEBUG - 2023-05-14 02:23:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-14 02:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
INFO - 2023-05-14 02:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-14 02:23:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:23:43 --> Model Class Initialized
INFO - 2023-05-14 02:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-14 02:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-14 02:23:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:23:43 --> Final output sent to browser
DEBUG - 2023-05-14 02:23:43 --> Total execution time: 0.0897
ERROR - 2023-05-14 02:24:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:24:36 --> Config Class Initialized
INFO - 2023-05-14 02:24:36 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:24:36 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:24:36 --> Utf8 Class Initialized
INFO - 2023-05-14 02:24:36 --> URI Class Initialized
INFO - 2023-05-14 02:24:36 --> Router Class Initialized
INFO - 2023-05-14 02:24:36 --> Output Class Initialized
INFO - 2023-05-14 02:24:36 --> Security Class Initialized
DEBUG - 2023-05-14 02:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:24:36 --> Input Class Initialized
INFO - 2023-05-14 02:24:36 --> Language Class Initialized
INFO - 2023-05-14 02:24:36 --> Loader Class Initialized
INFO - 2023-05-14 02:24:36 --> Helper loaded: url_helper
INFO - 2023-05-14 02:24:36 --> Helper loaded: file_helper
INFO - 2023-05-14 02:24:36 --> Helper loaded: html_helper
INFO - 2023-05-14 02:24:36 --> Helper loaded: text_helper
INFO - 2023-05-14 02:24:36 --> Helper loaded: form_helper
INFO - 2023-05-14 02:24:36 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:24:36 --> Helper loaded: security_helper
INFO - 2023-05-14 02:24:36 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:24:36 --> Database Driver Class Initialized
INFO - 2023-05-14 02:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:24:36 --> Parser Class Initialized
INFO - 2023-05-14 02:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:24:36 --> Pagination Class Initialized
INFO - 2023-05-14 02:24:36 --> Form Validation Class Initialized
INFO - 2023-05-14 02:24:36 --> Controller Class Initialized
INFO - 2023-05-14 02:24:36 --> Model Class Initialized
INFO - 2023-05-14 02:24:36 --> Model Class Initialized
INFO - 2023-05-14 02:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-05-14 02:24:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:24:36 --> Model Class Initialized
INFO - 2023-05-14 02:24:36 --> Model Class Initialized
INFO - 2023-05-14 02:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-14 02:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-14 02:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:24:36 --> Final output sent to browser
DEBUG - 2023-05-14 02:24:36 --> Total execution time: 0.0738
ERROR - 2023-05-14 02:24:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:24:37 --> Config Class Initialized
INFO - 2023-05-14 02:24:37 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:24:37 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:24:37 --> Utf8 Class Initialized
INFO - 2023-05-14 02:24:37 --> URI Class Initialized
INFO - 2023-05-14 02:24:37 --> Router Class Initialized
INFO - 2023-05-14 02:24:37 --> Output Class Initialized
INFO - 2023-05-14 02:24:37 --> Security Class Initialized
DEBUG - 2023-05-14 02:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:24:37 --> Input Class Initialized
INFO - 2023-05-14 02:24:37 --> Language Class Initialized
INFO - 2023-05-14 02:24:37 --> Loader Class Initialized
INFO - 2023-05-14 02:24:37 --> Helper loaded: url_helper
INFO - 2023-05-14 02:24:37 --> Helper loaded: file_helper
INFO - 2023-05-14 02:24:37 --> Helper loaded: html_helper
INFO - 2023-05-14 02:24:37 --> Helper loaded: text_helper
INFO - 2023-05-14 02:24:37 --> Helper loaded: form_helper
INFO - 2023-05-14 02:24:37 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:24:37 --> Helper loaded: security_helper
INFO - 2023-05-14 02:24:37 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:24:37 --> Database Driver Class Initialized
INFO - 2023-05-14 02:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:24:37 --> Parser Class Initialized
INFO - 2023-05-14 02:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:24:37 --> Pagination Class Initialized
INFO - 2023-05-14 02:24:37 --> Form Validation Class Initialized
INFO - 2023-05-14 02:24:37 --> Controller Class Initialized
INFO - 2023-05-14 02:24:37 --> Model Class Initialized
INFO - 2023-05-14 02:24:37 --> Model Class Initialized
INFO - 2023-05-14 02:24:37 --> Final output sent to browser
DEBUG - 2023-05-14 02:24:37 --> Total execution time: 0.0267
ERROR - 2023-05-14 02:24:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:24:38 --> Config Class Initialized
INFO - 2023-05-14 02:24:38 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:24:38 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:24:38 --> Utf8 Class Initialized
INFO - 2023-05-14 02:24:38 --> URI Class Initialized
DEBUG - 2023-05-14 02:24:38 --> No URI present. Default controller set.
INFO - 2023-05-14 02:24:38 --> Router Class Initialized
INFO - 2023-05-14 02:24:38 --> Output Class Initialized
INFO - 2023-05-14 02:24:38 --> Security Class Initialized
DEBUG - 2023-05-14 02:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:24:38 --> Input Class Initialized
INFO - 2023-05-14 02:24:38 --> Language Class Initialized
INFO - 2023-05-14 02:24:38 --> Loader Class Initialized
INFO - 2023-05-14 02:24:38 --> Helper loaded: url_helper
INFO - 2023-05-14 02:24:38 --> Helper loaded: file_helper
INFO - 2023-05-14 02:24:38 --> Helper loaded: html_helper
INFO - 2023-05-14 02:24:38 --> Helper loaded: text_helper
INFO - 2023-05-14 02:24:38 --> Helper loaded: form_helper
INFO - 2023-05-14 02:24:38 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:24:38 --> Helper loaded: security_helper
INFO - 2023-05-14 02:24:38 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:24:38 --> Database Driver Class Initialized
INFO - 2023-05-14 02:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:24:38 --> Parser Class Initialized
INFO - 2023-05-14 02:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:24:38 --> Pagination Class Initialized
INFO - 2023-05-14 02:24:38 --> Form Validation Class Initialized
INFO - 2023-05-14 02:24:38 --> Controller Class Initialized
INFO - 2023-05-14 02:24:38 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:38 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:38 --> Model Class Initialized
INFO - 2023-05-14 02:24:38 --> Model Class Initialized
INFO - 2023-05-14 02:24:38 --> Model Class Initialized
INFO - 2023-05-14 02:24:38 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-14 02:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:38 --> Model Class Initialized
INFO - 2023-05-14 02:24:38 --> Model Class Initialized
INFO - 2023-05-14 02:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-14 02:24:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:24:38 --> Model Class Initialized
INFO - 2023-05-14 02:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-14 02:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-14 02:24:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:24:38 --> Final output sent to browser
DEBUG - 2023-05-14 02:24:38 --> Total execution time: 0.0787
ERROR - 2023-05-14 02:24:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:24:40 --> Config Class Initialized
INFO - 2023-05-14 02:24:40 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:24:40 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:24:40 --> Utf8 Class Initialized
INFO - 2023-05-14 02:24:40 --> URI Class Initialized
DEBUG - 2023-05-14 02:24:40 --> No URI present. Default controller set.
INFO - 2023-05-14 02:24:40 --> Router Class Initialized
INFO - 2023-05-14 02:24:40 --> Output Class Initialized
INFO - 2023-05-14 02:24:40 --> Security Class Initialized
DEBUG - 2023-05-14 02:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:24:40 --> Input Class Initialized
INFO - 2023-05-14 02:24:40 --> Language Class Initialized
INFO - 2023-05-14 02:24:40 --> Loader Class Initialized
INFO - 2023-05-14 02:24:40 --> Helper loaded: url_helper
INFO - 2023-05-14 02:24:40 --> Helper loaded: file_helper
INFO - 2023-05-14 02:24:40 --> Helper loaded: html_helper
INFO - 2023-05-14 02:24:40 --> Helper loaded: text_helper
INFO - 2023-05-14 02:24:40 --> Helper loaded: form_helper
INFO - 2023-05-14 02:24:40 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:24:40 --> Helper loaded: security_helper
INFO - 2023-05-14 02:24:40 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:24:40 --> Database Driver Class Initialized
INFO - 2023-05-14 02:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:24:40 --> Parser Class Initialized
INFO - 2023-05-14 02:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:24:40 --> Pagination Class Initialized
INFO - 2023-05-14 02:24:40 --> Form Validation Class Initialized
INFO - 2023-05-14 02:24:40 --> Controller Class Initialized
INFO - 2023-05-14 02:24:40 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:40 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:40 --> Model Class Initialized
INFO - 2023-05-14 02:24:40 --> Model Class Initialized
INFO - 2023-05-14 02:24:40 --> Model Class Initialized
INFO - 2023-05-14 02:24:40 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-14 02:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:40 --> Model Class Initialized
INFO - 2023-05-14 02:24:40 --> Model Class Initialized
INFO - 2023-05-14 02:24:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-14 02:24:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:24:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:24:40 --> Model Class Initialized
INFO - 2023-05-14 02:24:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-14 02:24:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-14 02:24:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:24:40 --> Final output sent to browser
DEBUG - 2023-05-14 02:24:40 --> Total execution time: 0.0761
ERROR - 2023-05-14 02:24:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:24:42 --> Config Class Initialized
INFO - 2023-05-14 02:24:42 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:24:42 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:24:42 --> Utf8 Class Initialized
INFO - 2023-05-14 02:24:42 --> URI Class Initialized
DEBUG - 2023-05-14 02:24:42 --> No URI present. Default controller set.
INFO - 2023-05-14 02:24:42 --> Router Class Initialized
INFO - 2023-05-14 02:24:42 --> Output Class Initialized
INFO - 2023-05-14 02:24:42 --> Security Class Initialized
DEBUG - 2023-05-14 02:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:24:42 --> Input Class Initialized
INFO - 2023-05-14 02:24:42 --> Language Class Initialized
INFO - 2023-05-14 02:24:42 --> Loader Class Initialized
INFO - 2023-05-14 02:24:42 --> Helper loaded: url_helper
INFO - 2023-05-14 02:24:42 --> Helper loaded: file_helper
INFO - 2023-05-14 02:24:42 --> Helper loaded: html_helper
INFO - 2023-05-14 02:24:42 --> Helper loaded: text_helper
INFO - 2023-05-14 02:24:42 --> Helper loaded: form_helper
INFO - 2023-05-14 02:24:42 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:24:42 --> Helper loaded: security_helper
INFO - 2023-05-14 02:24:42 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:24:42 --> Database Driver Class Initialized
INFO - 2023-05-14 02:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:24:42 --> Parser Class Initialized
INFO - 2023-05-14 02:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:24:42 --> Pagination Class Initialized
INFO - 2023-05-14 02:24:42 --> Form Validation Class Initialized
INFO - 2023-05-14 02:24:42 --> Controller Class Initialized
INFO - 2023-05-14 02:24:42 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:42 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:42 --> Model Class Initialized
INFO - 2023-05-14 02:24:42 --> Model Class Initialized
INFO - 2023-05-14 02:24:42 --> Model Class Initialized
INFO - 2023-05-14 02:24:42 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-14 02:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:42 --> Model Class Initialized
INFO - 2023-05-14 02:24:42 --> Model Class Initialized
INFO - 2023-05-14 02:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-14 02:24:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:24:42 --> Model Class Initialized
INFO - 2023-05-14 02:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-14 02:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-14 02:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:24:42 --> Final output sent to browser
DEBUG - 2023-05-14 02:24:42 --> Total execution time: 0.0713
ERROR - 2023-05-14 02:24:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:24:44 --> Config Class Initialized
INFO - 2023-05-14 02:24:44 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:24:44 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:24:44 --> Utf8 Class Initialized
INFO - 2023-05-14 02:24:44 --> URI Class Initialized
DEBUG - 2023-05-14 02:24:44 --> No URI present. Default controller set.
INFO - 2023-05-14 02:24:44 --> Router Class Initialized
INFO - 2023-05-14 02:24:44 --> Output Class Initialized
INFO - 2023-05-14 02:24:44 --> Security Class Initialized
DEBUG - 2023-05-14 02:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:24:44 --> Input Class Initialized
INFO - 2023-05-14 02:24:44 --> Language Class Initialized
INFO - 2023-05-14 02:24:44 --> Loader Class Initialized
INFO - 2023-05-14 02:24:44 --> Helper loaded: url_helper
INFO - 2023-05-14 02:24:44 --> Helper loaded: file_helper
INFO - 2023-05-14 02:24:44 --> Helper loaded: html_helper
INFO - 2023-05-14 02:24:44 --> Helper loaded: text_helper
INFO - 2023-05-14 02:24:44 --> Helper loaded: form_helper
INFO - 2023-05-14 02:24:44 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:24:44 --> Helper loaded: security_helper
INFO - 2023-05-14 02:24:44 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:24:44 --> Database Driver Class Initialized
INFO - 2023-05-14 02:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:24:44 --> Parser Class Initialized
INFO - 2023-05-14 02:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:24:44 --> Pagination Class Initialized
INFO - 2023-05-14 02:24:44 --> Form Validation Class Initialized
INFO - 2023-05-14 02:24:44 --> Controller Class Initialized
INFO - 2023-05-14 02:24:44 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:44 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:44 --> Model Class Initialized
INFO - 2023-05-14 02:24:44 --> Model Class Initialized
INFO - 2023-05-14 02:24:44 --> Model Class Initialized
INFO - 2023-05-14 02:24:44 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-14 02:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:44 --> Model Class Initialized
INFO - 2023-05-14 02:24:44 --> Model Class Initialized
INFO - 2023-05-14 02:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-14 02:24:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:24:44 --> Model Class Initialized
INFO - 2023-05-14 02:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-14 02:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-14 02:24:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:24:44 --> Final output sent to browser
DEBUG - 2023-05-14 02:24:44 --> Total execution time: 0.0696
ERROR - 2023-05-14 02:24:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:24:46 --> Config Class Initialized
INFO - 2023-05-14 02:24:46 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:24:46 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:24:46 --> Utf8 Class Initialized
INFO - 2023-05-14 02:24:46 --> URI Class Initialized
DEBUG - 2023-05-14 02:24:46 --> No URI present. Default controller set.
INFO - 2023-05-14 02:24:46 --> Router Class Initialized
INFO - 2023-05-14 02:24:46 --> Output Class Initialized
INFO - 2023-05-14 02:24:46 --> Security Class Initialized
DEBUG - 2023-05-14 02:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:24:46 --> Input Class Initialized
INFO - 2023-05-14 02:24:46 --> Language Class Initialized
INFO - 2023-05-14 02:24:46 --> Loader Class Initialized
INFO - 2023-05-14 02:24:46 --> Helper loaded: url_helper
INFO - 2023-05-14 02:24:46 --> Helper loaded: file_helper
INFO - 2023-05-14 02:24:46 --> Helper loaded: html_helper
INFO - 2023-05-14 02:24:46 --> Helper loaded: text_helper
INFO - 2023-05-14 02:24:46 --> Helper loaded: form_helper
INFO - 2023-05-14 02:24:46 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:24:46 --> Helper loaded: security_helper
INFO - 2023-05-14 02:24:46 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:24:46 --> Database Driver Class Initialized
INFO - 2023-05-14 02:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:24:46 --> Parser Class Initialized
INFO - 2023-05-14 02:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:24:46 --> Pagination Class Initialized
INFO - 2023-05-14 02:24:46 --> Form Validation Class Initialized
INFO - 2023-05-14 02:24:46 --> Controller Class Initialized
INFO - 2023-05-14 02:24:46 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:46 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:46 --> Model Class Initialized
INFO - 2023-05-14 02:24:46 --> Model Class Initialized
INFO - 2023-05-14 02:24:46 --> Model Class Initialized
INFO - 2023-05-14 02:24:46 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-14 02:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:46 --> Model Class Initialized
INFO - 2023-05-14 02:24:46 --> Model Class Initialized
INFO - 2023-05-14 02:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-14 02:24:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:24:46 --> Model Class Initialized
INFO - 2023-05-14 02:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-14 02:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-14 02:24:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:24:46 --> Final output sent to browser
DEBUG - 2023-05-14 02:24:46 --> Total execution time: 0.0882
ERROR - 2023-05-14 02:24:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:24:53 --> Config Class Initialized
INFO - 2023-05-14 02:24:53 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:24:53 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:24:53 --> Utf8 Class Initialized
INFO - 2023-05-14 02:24:53 --> URI Class Initialized
DEBUG - 2023-05-14 02:24:53 --> No URI present. Default controller set.
INFO - 2023-05-14 02:24:53 --> Router Class Initialized
INFO - 2023-05-14 02:24:53 --> Output Class Initialized
INFO - 2023-05-14 02:24:53 --> Security Class Initialized
DEBUG - 2023-05-14 02:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:24:53 --> Input Class Initialized
INFO - 2023-05-14 02:24:53 --> Language Class Initialized
INFO - 2023-05-14 02:24:53 --> Loader Class Initialized
INFO - 2023-05-14 02:24:53 --> Helper loaded: url_helper
INFO - 2023-05-14 02:24:53 --> Helper loaded: file_helper
INFO - 2023-05-14 02:24:53 --> Helper loaded: html_helper
INFO - 2023-05-14 02:24:53 --> Helper loaded: text_helper
INFO - 2023-05-14 02:24:53 --> Helper loaded: form_helper
INFO - 2023-05-14 02:24:53 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:24:53 --> Helper loaded: security_helper
INFO - 2023-05-14 02:24:53 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:24:53 --> Database Driver Class Initialized
INFO - 2023-05-14 02:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:24:53 --> Parser Class Initialized
INFO - 2023-05-14 02:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:24:53 --> Pagination Class Initialized
INFO - 2023-05-14 02:24:53 --> Form Validation Class Initialized
INFO - 2023-05-14 02:24:53 --> Controller Class Initialized
INFO - 2023-05-14 02:24:53 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:53 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:53 --> Model Class Initialized
INFO - 2023-05-14 02:24:53 --> Model Class Initialized
INFO - 2023-05-14 02:24:53 --> Model Class Initialized
INFO - 2023-05-14 02:24:53 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-14 02:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:53 --> Model Class Initialized
INFO - 2023-05-14 02:24:53 --> Model Class Initialized
INFO - 2023-05-14 02:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-14 02:24:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:24:53 --> Model Class Initialized
INFO - 2023-05-14 02:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-14 02:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-14 02:24:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:24:53 --> Final output sent to browser
DEBUG - 2023-05-14 02:24:53 --> Total execution time: 0.0683
ERROR - 2023-05-14 02:24:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-14 02:24:54 --> Config Class Initialized
INFO - 2023-05-14 02:24:54 --> Hooks Class Initialized
DEBUG - 2023-05-14 02:24:54 --> UTF-8 Support Enabled
INFO - 2023-05-14 02:24:54 --> Utf8 Class Initialized
INFO - 2023-05-14 02:24:54 --> URI Class Initialized
DEBUG - 2023-05-14 02:24:54 --> No URI present. Default controller set.
INFO - 2023-05-14 02:24:54 --> Router Class Initialized
INFO - 2023-05-14 02:24:54 --> Output Class Initialized
INFO - 2023-05-14 02:24:54 --> Security Class Initialized
DEBUG - 2023-05-14 02:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-14 02:24:54 --> Input Class Initialized
INFO - 2023-05-14 02:24:54 --> Language Class Initialized
INFO - 2023-05-14 02:24:54 --> Loader Class Initialized
INFO - 2023-05-14 02:24:54 --> Helper loaded: url_helper
INFO - 2023-05-14 02:24:54 --> Helper loaded: file_helper
INFO - 2023-05-14 02:24:54 --> Helper loaded: html_helper
INFO - 2023-05-14 02:24:54 --> Helper loaded: text_helper
INFO - 2023-05-14 02:24:54 --> Helper loaded: form_helper
INFO - 2023-05-14 02:24:54 --> Helper loaded: lang_helper
INFO - 2023-05-14 02:24:54 --> Helper loaded: security_helper
INFO - 2023-05-14 02:24:54 --> Helper loaded: cookie_helper
INFO - 2023-05-14 02:24:54 --> Database Driver Class Initialized
INFO - 2023-05-14 02:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-14 02:24:54 --> Parser Class Initialized
INFO - 2023-05-14 02:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-14 02:24:54 --> Pagination Class Initialized
INFO - 2023-05-14 02:24:54 --> Form Validation Class Initialized
INFO - 2023-05-14 02:24:54 --> Controller Class Initialized
INFO - 2023-05-14 02:24:54 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:54 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:54 --> Model Class Initialized
INFO - 2023-05-14 02:24:54 --> Model Class Initialized
INFO - 2023-05-14 02:24:54 --> Model Class Initialized
INFO - 2023-05-14 02:24:54 --> Model Class Initialized
DEBUG - 2023-05-14 02:24:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-14 02:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:54 --> Model Class Initialized
INFO - 2023-05-14 02:24:54 --> Model Class Initialized
INFO - 2023-05-14 02:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-14 02:24:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-14 02:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-14 02:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-14 02:24:54 --> Model Class Initialized
INFO - 2023-05-14 02:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-14 02:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-14 02:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-14 02:24:54 --> Final output sent to browser
DEBUG - 2023-05-14 02:24:54 --> Total execution time: 0.0694
