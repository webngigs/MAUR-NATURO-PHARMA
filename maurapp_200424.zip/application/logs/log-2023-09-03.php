<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-03 02:00:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 02:00:19 --> Config Class Initialized
INFO - 2023-09-03 02:00:19 --> Hooks Class Initialized
DEBUG - 2023-09-03 02:00:19 --> UTF-8 Support Enabled
INFO - 2023-09-03 02:00:19 --> Utf8 Class Initialized
INFO - 2023-09-03 02:00:19 --> URI Class Initialized
DEBUG - 2023-09-03 02:00:19 --> No URI present. Default controller set.
INFO - 2023-09-03 02:00:19 --> Router Class Initialized
INFO - 2023-09-03 02:00:19 --> Output Class Initialized
INFO - 2023-09-03 02:00:19 --> Security Class Initialized
DEBUG - 2023-09-03 02:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 02:00:19 --> Input Class Initialized
INFO - 2023-09-03 02:00:19 --> Language Class Initialized
INFO - 2023-09-03 02:00:19 --> Loader Class Initialized
INFO - 2023-09-03 02:00:19 --> Helper loaded: url_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: file_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: html_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: text_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: form_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: lang_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: security_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: cookie_helper
INFO - 2023-09-03 02:00:19 --> Database Driver Class Initialized
INFO - 2023-09-03 02:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 02:00:19 --> Parser Class Initialized
INFO - 2023-09-03 02:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 02:00:19 --> Pagination Class Initialized
INFO - 2023-09-03 02:00:19 --> Form Validation Class Initialized
INFO - 2023-09-03 02:00:19 --> Controller Class Initialized
INFO - 2023-09-03 02:00:19 --> Model Class Initialized
DEBUG - 2023-09-03 02:00:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 02:00:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 02:00:19 --> Config Class Initialized
INFO - 2023-09-03 02:00:19 --> Hooks Class Initialized
DEBUG - 2023-09-03 02:00:19 --> UTF-8 Support Enabled
INFO - 2023-09-03 02:00:19 --> Utf8 Class Initialized
INFO - 2023-09-03 02:00:19 --> URI Class Initialized
INFO - 2023-09-03 02:00:19 --> Router Class Initialized
INFO - 2023-09-03 02:00:19 --> Output Class Initialized
INFO - 2023-09-03 02:00:19 --> Security Class Initialized
DEBUG - 2023-09-03 02:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 02:00:19 --> Input Class Initialized
INFO - 2023-09-03 02:00:19 --> Language Class Initialized
INFO - 2023-09-03 02:00:19 --> Loader Class Initialized
INFO - 2023-09-03 02:00:19 --> Helper loaded: url_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: file_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: html_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: text_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: form_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: lang_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: security_helper
INFO - 2023-09-03 02:00:19 --> Helper loaded: cookie_helper
INFO - 2023-09-03 02:00:19 --> Database Driver Class Initialized
INFO - 2023-09-03 02:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 02:00:19 --> Parser Class Initialized
INFO - 2023-09-03 02:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 02:00:19 --> Pagination Class Initialized
INFO - 2023-09-03 02:00:19 --> Form Validation Class Initialized
INFO - 2023-09-03 02:00:19 --> Controller Class Initialized
INFO - 2023-09-03 02:00:19 --> Model Class Initialized
DEBUG - 2023-09-03 02:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 02:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 02:00:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 02:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 02:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 02:00:19 --> Model Class Initialized
INFO - 2023-09-03 02:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 02:00:19 --> Final output sent to browser
DEBUG - 2023-09-03 02:00:19 --> Total execution time: 0.0343
ERROR - 2023-09-03 02:18:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 02:18:09 --> Config Class Initialized
INFO - 2023-09-03 02:18:09 --> Hooks Class Initialized
DEBUG - 2023-09-03 02:18:09 --> UTF-8 Support Enabled
INFO - 2023-09-03 02:18:09 --> Utf8 Class Initialized
INFO - 2023-09-03 02:18:09 --> URI Class Initialized
DEBUG - 2023-09-03 02:18:09 --> No URI present. Default controller set.
INFO - 2023-09-03 02:18:09 --> Router Class Initialized
INFO - 2023-09-03 02:18:09 --> Output Class Initialized
INFO - 2023-09-03 02:18:09 --> Security Class Initialized
DEBUG - 2023-09-03 02:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 02:18:09 --> Input Class Initialized
INFO - 2023-09-03 02:18:09 --> Language Class Initialized
INFO - 2023-09-03 02:18:09 --> Loader Class Initialized
INFO - 2023-09-03 02:18:09 --> Helper loaded: url_helper
INFO - 2023-09-03 02:18:09 --> Helper loaded: file_helper
INFO - 2023-09-03 02:18:09 --> Helper loaded: html_helper
INFO - 2023-09-03 02:18:09 --> Helper loaded: text_helper
INFO - 2023-09-03 02:18:09 --> Helper loaded: form_helper
INFO - 2023-09-03 02:18:09 --> Helper loaded: lang_helper
INFO - 2023-09-03 02:18:09 --> Helper loaded: security_helper
INFO - 2023-09-03 02:18:09 --> Helper loaded: cookie_helper
INFO - 2023-09-03 02:18:09 --> Database Driver Class Initialized
INFO - 2023-09-03 02:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 02:18:09 --> Parser Class Initialized
INFO - 2023-09-03 02:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 02:18:09 --> Pagination Class Initialized
INFO - 2023-09-03 02:18:09 --> Form Validation Class Initialized
INFO - 2023-09-03 02:18:09 --> Controller Class Initialized
INFO - 2023-09-03 02:18:09 --> Model Class Initialized
DEBUG - 2023-09-03 02:18:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 02:45:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 02:45:18 --> Config Class Initialized
INFO - 2023-09-03 02:45:18 --> Hooks Class Initialized
DEBUG - 2023-09-03 02:45:18 --> UTF-8 Support Enabled
INFO - 2023-09-03 02:45:18 --> Utf8 Class Initialized
INFO - 2023-09-03 02:45:18 --> URI Class Initialized
DEBUG - 2023-09-03 02:45:18 --> No URI present. Default controller set.
INFO - 2023-09-03 02:45:18 --> Router Class Initialized
INFO - 2023-09-03 02:45:18 --> Output Class Initialized
INFO - 2023-09-03 02:45:18 --> Security Class Initialized
DEBUG - 2023-09-03 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 02:45:18 --> Input Class Initialized
INFO - 2023-09-03 02:45:18 --> Language Class Initialized
INFO - 2023-09-03 02:45:18 --> Loader Class Initialized
INFO - 2023-09-03 02:45:18 --> Helper loaded: url_helper
INFO - 2023-09-03 02:45:18 --> Helper loaded: file_helper
INFO - 2023-09-03 02:45:18 --> Helper loaded: html_helper
INFO - 2023-09-03 02:45:18 --> Helper loaded: text_helper
INFO - 2023-09-03 02:45:18 --> Helper loaded: form_helper
INFO - 2023-09-03 02:45:18 --> Helper loaded: lang_helper
INFO - 2023-09-03 02:45:18 --> Helper loaded: security_helper
INFO - 2023-09-03 02:45:18 --> Helper loaded: cookie_helper
INFO - 2023-09-03 02:45:18 --> Database Driver Class Initialized
INFO - 2023-09-03 02:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 02:45:18 --> Parser Class Initialized
INFO - 2023-09-03 02:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 02:45:18 --> Pagination Class Initialized
INFO - 2023-09-03 02:45:18 --> Form Validation Class Initialized
INFO - 2023-09-03 02:45:18 --> Controller Class Initialized
INFO - 2023-09-03 02:45:18 --> Model Class Initialized
DEBUG - 2023-09-03 02:45:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 02:45:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 02:45:19 --> Config Class Initialized
INFO - 2023-09-03 02:45:19 --> Hooks Class Initialized
DEBUG - 2023-09-03 02:45:19 --> UTF-8 Support Enabled
INFO - 2023-09-03 02:45:19 --> Utf8 Class Initialized
INFO - 2023-09-03 02:45:19 --> URI Class Initialized
INFO - 2023-09-03 02:45:19 --> Router Class Initialized
INFO - 2023-09-03 02:45:19 --> Output Class Initialized
INFO - 2023-09-03 02:45:19 --> Security Class Initialized
DEBUG - 2023-09-03 02:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 02:45:19 --> Input Class Initialized
INFO - 2023-09-03 02:45:19 --> Language Class Initialized
INFO - 2023-09-03 02:45:19 --> Loader Class Initialized
INFO - 2023-09-03 02:45:19 --> Helper loaded: url_helper
INFO - 2023-09-03 02:45:19 --> Helper loaded: file_helper
INFO - 2023-09-03 02:45:19 --> Helper loaded: html_helper
INFO - 2023-09-03 02:45:19 --> Helper loaded: text_helper
INFO - 2023-09-03 02:45:19 --> Helper loaded: form_helper
INFO - 2023-09-03 02:45:19 --> Helper loaded: lang_helper
INFO - 2023-09-03 02:45:19 --> Helper loaded: security_helper
INFO - 2023-09-03 02:45:19 --> Helper loaded: cookie_helper
INFO - 2023-09-03 02:45:19 --> Database Driver Class Initialized
INFO - 2023-09-03 02:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 02:45:19 --> Parser Class Initialized
INFO - 2023-09-03 02:45:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 02:45:19 --> Pagination Class Initialized
INFO - 2023-09-03 02:45:19 --> Form Validation Class Initialized
INFO - 2023-09-03 02:45:19 --> Controller Class Initialized
INFO - 2023-09-03 02:45:19 --> Model Class Initialized
DEBUG - 2023-09-03 02:45:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 02:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 02:45:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 02:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 02:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 02:45:19 --> Model Class Initialized
INFO - 2023-09-03 02:45:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 02:45:19 --> Final output sent to browser
DEBUG - 2023-09-03 02:45:19 --> Total execution time: 0.0344
ERROR - 2023-09-03 04:29:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 04:29:51 --> Config Class Initialized
INFO - 2023-09-03 04:29:51 --> Hooks Class Initialized
DEBUG - 2023-09-03 04:29:51 --> UTF-8 Support Enabled
INFO - 2023-09-03 04:29:51 --> Utf8 Class Initialized
INFO - 2023-09-03 04:29:51 --> URI Class Initialized
DEBUG - 2023-09-03 04:29:51 --> No URI present. Default controller set.
INFO - 2023-09-03 04:29:51 --> Router Class Initialized
INFO - 2023-09-03 04:29:51 --> Output Class Initialized
INFO - 2023-09-03 04:29:51 --> Security Class Initialized
DEBUG - 2023-09-03 04:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 04:29:51 --> Input Class Initialized
INFO - 2023-09-03 04:29:51 --> Language Class Initialized
INFO - 2023-09-03 04:29:51 --> Loader Class Initialized
INFO - 2023-09-03 04:29:51 --> Helper loaded: url_helper
INFO - 2023-09-03 04:29:51 --> Helper loaded: file_helper
INFO - 2023-09-03 04:29:51 --> Helper loaded: html_helper
INFO - 2023-09-03 04:29:51 --> Helper loaded: text_helper
INFO - 2023-09-03 04:29:51 --> Helper loaded: form_helper
INFO - 2023-09-03 04:29:51 --> Helper loaded: lang_helper
INFO - 2023-09-03 04:29:51 --> Helper loaded: security_helper
INFO - 2023-09-03 04:29:51 --> Helper loaded: cookie_helper
INFO - 2023-09-03 04:29:51 --> Database Driver Class Initialized
INFO - 2023-09-03 04:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 04:29:51 --> Parser Class Initialized
INFO - 2023-09-03 04:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 04:29:51 --> Pagination Class Initialized
INFO - 2023-09-03 04:29:51 --> Form Validation Class Initialized
INFO - 2023-09-03 04:29:51 --> Controller Class Initialized
INFO - 2023-09-03 04:29:51 --> Model Class Initialized
DEBUG - 2023-09-03 04:29:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 05:55:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 05:55:15 --> Config Class Initialized
INFO - 2023-09-03 05:55:15 --> Hooks Class Initialized
DEBUG - 2023-09-03 05:55:15 --> UTF-8 Support Enabled
INFO - 2023-09-03 05:55:15 --> Utf8 Class Initialized
INFO - 2023-09-03 05:55:15 --> URI Class Initialized
DEBUG - 2023-09-03 05:55:15 --> No URI present. Default controller set.
INFO - 2023-09-03 05:55:15 --> Router Class Initialized
INFO - 2023-09-03 05:55:16 --> Output Class Initialized
INFO - 2023-09-03 05:55:16 --> Security Class Initialized
DEBUG - 2023-09-03 05:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 05:55:16 --> Input Class Initialized
INFO - 2023-09-03 05:55:16 --> Language Class Initialized
INFO - 2023-09-03 05:55:16 --> Loader Class Initialized
INFO - 2023-09-03 05:55:16 --> Helper loaded: url_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: file_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: html_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: text_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: form_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: lang_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: security_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: cookie_helper
INFO - 2023-09-03 05:55:16 --> Database Driver Class Initialized
INFO - 2023-09-03 05:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 05:55:16 --> Parser Class Initialized
INFO - 2023-09-03 05:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 05:55:16 --> Pagination Class Initialized
INFO - 2023-09-03 05:55:16 --> Form Validation Class Initialized
INFO - 2023-09-03 05:55:16 --> Controller Class Initialized
INFO - 2023-09-03 05:55:16 --> Model Class Initialized
DEBUG - 2023-09-03 05:55:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 05:55:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 05:55:16 --> Config Class Initialized
INFO - 2023-09-03 05:55:16 --> Hooks Class Initialized
DEBUG - 2023-09-03 05:55:16 --> UTF-8 Support Enabled
INFO - 2023-09-03 05:55:16 --> Utf8 Class Initialized
INFO - 2023-09-03 05:55:16 --> URI Class Initialized
INFO - 2023-09-03 05:55:16 --> Router Class Initialized
INFO - 2023-09-03 05:55:16 --> Output Class Initialized
INFO - 2023-09-03 05:55:16 --> Security Class Initialized
DEBUG - 2023-09-03 05:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 05:55:16 --> Input Class Initialized
INFO - 2023-09-03 05:55:16 --> Language Class Initialized
INFO - 2023-09-03 05:55:16 --> Loader Class Initialized
INFO - 2023-09-03 05:55:16 --> Helper loaded: url_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: file_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: html_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: text_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: form_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: lang_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: security_helper
INFO - 2023-09-03 05:55:16 --> Helper loaded: cookie_helper
INFO - 2023-09-03 05:55:16 --> Database Driver Class Initialized
INFO - 2023-09-03 05:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 05:55:16 --> Parser Class Initialized
INFO - 2023-09-03 05:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 05:55:16 --> Pagination Class Initialized
INFO - 2023-09-03 05:55:16 --> Form Validation Class Initialized
INFO - 2023-09-03 05:55:16 --> Controller Class Initialized
INFO - 2023-09-03 05:55:16 --> Model Class Initialized
DEBUG - 2023-09-03 05:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 05:55:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 05:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 05:55:16 --> Model Class Initialized
INFO - 2023-09-03 05:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 05:55:16 --> Final output sent to browser
DEBUG - 2023-09-03 05:55:16 --> Total execution time: 0.0329
ERROR - 2023-09-03 05:57:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 05:57:38 --> Config Class Initialized
INFO - 2023-09-03 05:57:38 --> Hooks Class Initialized
DEBUG - 2023-09-03 05:57:38 --> UTF-8 Support Enabled
INFO - 2023-09-03 05:57:38 --> Utf8 Class Initialized
INFO - 2023-09-03 05:57:38 --> URI Class Initialized
INFO - 2023-09-03 05:57:38 --> Router Class Initialized
INFO - 2023-09-03 05:57:38 --> Output Class Initialized
INFO - 2023-09-03 05:57:38 --> Security Class Initialized
DEBUG - 2023-09-03 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 05:57:38 --> Input Class Initialized
INFO - 2023-09-03 05:57:38 --> Language Class Initialized
INFO - 2023-09-03 05:57:38 --> Loader Class Initialized
INFO - 2023-09-03 05:57:38 --> Helper loaded: url_helper
INFO - 2023-09-03 05:57:38 --> Helper loaded: file_helper
INFO - 2023-09-03 05:57:38 --> Helper loaded: html_helper
INFO - 2023-09-03 05:57:38 --> Helper loaded: text_helper
INFO - 2023-09-03 05:57:38 --> Helper loaded: form_helper
INFO - 2023-09-03 05:57:38 --> Helper loaded: lang_helper
INFO - 2023-09-03 05:57:38 --> Helper loaded: security_helper
INFO - 2023-09-03 05:57:38 --> Helper loaded: cookie_helper
INFO - 2023-09-03 05:57:38 --> Database Driver Class Initialized
INFO - 2023-09-03 05:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 05:57:38 --> Parser Class Initialized
INFO - 2023-09-03 05:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 05:57:38 --> Pagination Class Initialized
INFO - 2023-09-03 05:57:38 --> Form Validation Class Initialized
INFO - 2023-09-03 05:57:38 --> Controller Class Initialized
INFO - 2023-09-03 05:57:38 --> Model Class Initialized
DEBUG - 2023-09-03 05:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:57:38 --> Model Class Initialized
INFO - 2023-09-03 05:57:38 --> Final output sent to browser
DEBUG - 2023-09-03 05:57:38 --> Total execution time: 0.0219
ERROR - 2023-09-03 05:57:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 05:57:39 --> Config Class Initialized
INFO - 2023-09-03 05:57:39 --> Hooks Class Initialized
DEBUG - 2023-09-03 05:57:39 --> UTF-8 Support Enabled
INFO - 2023-09-03 05:57:39 --> Utf8 Class Initialized
INFO - 2023-09-03 05:57:39 --> URI Class Initialized
INFO - 2023-09-03 05:57:39 --> Router Class Initialized
INFO - 2023-09-03 05:57:39 --> Output Class Initialized
INFO - 2023-09-03 05:57:39 --> Security Class Initialized
DEBUG - 2023-09-03 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 05:57:39 --> Input Class Initialized
INFO - 2023-09-03 05:57:39 --> Language Class Initialized
INFO - 2023-09-03 05:57:39 --> Loader Class Initialized
INFO - 2023-09-03 05:57:39 --> Helper loaded: url_helper
INFO - 2023-09-03 05:57:39 --> Helper loaded: file_helper
INFO - 2023-09-03 05:57:39 --> Helper loaded: html_helper
INFO - 2023-09-03 05:57:39 --> Helper loaded: text_helper
INFO - 2023-09-03 05:57:39 --> Helper loaded: form_helper
INFO - 2023-09-03 05:57:39 --> Helper loaded: lang_helper
INFO - 2023-09-03 05:57:39 --> Helper loaded: security_helper
INFO - 2023-09-03 05:57:39 --> Helper loaded: cookie_helper
INFO - 2023-09-03 05:57:39 --> Database Driver Class Initialized
INFO - 2023-09-03 05:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 05:57:39 --> Parser Class Initialized
INFO - 2023-09-03 05:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 05:57:39 --> Pagination Class Initialized
INFO - 2023-09-03 05:57:39 --> Form Validation Class Initialized
INFO - 2023-09-03 05:57:39 --> Controller Class Initialized
INFO - 2023-09-03 05:57:39 --> Model Class Initialized
DEBUG - 2023-09-03 05:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 05:57:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 05:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 05:57:39 --> Model Class Initialized
INFO - 2023-09-03 05:57:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 05:57:39 --> Final output sent to browser
DEBUG - 2023-09-03 05:57:39 --> Total execution time: 0.0279
ERROR - 2023-09-03 05:58:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 05:58:12 --> Config Class Initialized
INFO - 2023-09-03 05:58:12 --> Hooks Class Initialized
DEBUG - 2023-09-03 05:58:12 --> UTF-8 Support Enabled
INFO - 2023-09-03 05:58:12 --> Utf8 Class Initialized
INFO - 2023-09-03 05:58:12 --> URI Class Initialized
INFO - 2023-09-03 05:58:12 --> Router Class Initialized
INFO - 2023-09-03 05:58:12 --> Output Class Initialized
INFO - 2023-09-03 05:58:12 --> Security Class Initialized
DEBUG - 2023-09-03 05:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 05:58:12 --> Input Class Initialized
INFO - 2023-09-03 05:58:12 --> Language Class Initialized
INFO - 2023-09-03 05:58:12 --> Loader Class Initialized
INFO - 2023-09-03 05:58:12 --> Helper loaded: url_helper
INFO - 2023-09-03 05:58:12 --> Helper loaded: file_helper
INFO - 2023-09-03 05:58:12 --> Helper loaded: html_helper
INFO - 2023-09-03 05:58:12 --> Helper loaded: text_helper
INFO - 2023-09-03 05:58:12 --> Helper loaded: form_helper
INFO - 2023-09-03 05:58:12 --> Helper loaded: lang_helper
INFO - 2023-09-03 05:58:12 --> Helper loaded: security_helper
INFO - 2023-09-03 05:58:12 --> Helper loaded: cookie_helper
INFO - 2023-09-03 05:58:12 --> Database Driver Class Initialized
INFO - 2023-09-03 05:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 05:58:12 --> Parser Class Initialized
INFO - 2023-09-03 05:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 05:58:12 --> Pagination Class Initialized
INFO - 2023-09-03 05:58:12 --> Form Validation Class Initialized
INFO - 2023-09-03 05:58:12 --> Controller Class Initialized
INFO - 2023-09-03 05:58:12 --> Model Class Initialized
DEBUG - 2023-09-03 05:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:58:12 --> Model Class Initialized
INFO - 2023-09-03 05:58:12 --> Final output sent to browser
DEBUG - 2023-09-03 05:58:12 --> Total execution time: 0.0199
ERROR - 2023-09-03 05:58:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 05:58:13 --> Config Class Initialized
INFO - 2023-09-03 05:58:13 --> Hooks Class Initialized
DEBUG - 2023-09-03 05:58:13 --> UTF-8 Support Enabled
INFO - 2023-09-03 05:58:13 --> Utf8 Class Initialized
INFO - 2023-09-03 05:58:13 --> URI Class Initialized
INFO - 2023-09-03 05:58:13 --> Router Class Initialized
INFO - 2023-09-03 05:58:13 --> Output Class Initialized
INFO - 2023-09-03 05:58:13 --> Security Class Initialized
DEBUG - 2023-09-03 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 05:58:13 --> Input Class Initialized
INFO - 2023-09-03 05:58:13 --> Language Class Initialized
INFO - 2023-09-03 05:58:13 --> Loader Class Initialized
INFO - 2023-09-03 05:58:13 --> Helper loaded: url_helper
INFO - 2023-09-03 05:58:13 --> Helper loaded: file_helper
INFO - 2023-09-03 05:58:13 --> Helper loaded: html_helper
INFO - 2023-09-03 05:58:13 --> Helper loaded: text_helper
INFO - 2023-09-03 05:58:13 --> Helper loaded: form_helper
INFO - 2023-09-03 05:58:13 --> Helper loaded: lang_helper
INFO - 2023-09-03 05:58:13 --> Helper loaded: security_helper
INFO - 2023-09-03 05:58:13 --> Helper loaded: cookie_helper
INFO - 2023-09-03 05:58:13 --> Database Driver Class Initialized
INFO - 2023-09-03 05:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 05:58:13 --> Parser Class Initialized
INFO - 2023-09-03 05:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 05:58:13 --> Pagination Class Initialized
INFO - 2023-09-03 05:58:13 --> Form Validation Class Initialized
INFO - 2023-09-03 05:58:13 --> Controller Class Initialized
INFO - 2023-09-03 05:58:13 --> Model Class Initialized
DEBUG - 2023-09-03 05:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 05:58:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 05:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 05:58:13 --> Model Class Initialized
INFO - 2023-09-03 05:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 05:58:13 --> Final output sent to browser
DEBUG - 2023-09-03 05:58:13 --> Total execution time: 0.0282
ERROR - 2023-09-03 05:58:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 05:58:35 --> Config Class Initialized
INFO - 2023-09-03 05:58:35 --> Hooks Class Initialized
DEBUG - 2023-09-03 05:58:35 --> UTF-8 Support Enabled
INFO - 2023-09-03 05:58:35 --> Utf8 Class Initialized
INFO - 2023-09-03 05:58:35 --> URI Class Initialized
INFO - 2023-09-03 05:58:35 --> Router Class Initialized
INFO - 2023-09-03 05:58:35 --> Output Class Initialized
INFO - 2023-09-03 05:58:35 --> Security Class Initialized
DEBUG - 2023-09-03 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 05:58:35 --> Input Class Initialized
INFO - 2023-09-03 05:58:35 --> Language Class Initialized
INFO - 2023-09-03 05:58:35 --> Loader Class Initialized
INFO - 2023-09-03 05:58:35 --> Helper loaded: url_helper
INFO - 2023-09-03 05:58:35 --> Helper loaded: file_helper
INFO - 2023-09-03 05:58:35 --> Helper loaded: html_helper
INFO - 2023-09-03 05:58:35 --> Helper loaded: text_helper
INFO - 2023-09-03 05:58:35 --> Helper loaded: form_helper
INFO - 2023-09-03 05:58:35 --> Helper loaded: lang_helper
INFO - 2023-09-03 05:58:35 --> Helper loaded: security_helper
INFO - 2023-09-03 05:58:35 --> Helper loaded: cookie_helper
INFO - 2023-09-03 05:58:35 --> Database Driver Class Initialized
INFO - 2023-09-03 05:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 05:58:35 --> Parser Class Initialized
INFO - 2023-09-03 05:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 05:58:35 --> Pagination Class Initialized
INFO - 2023-09-03 05:58:35 --> Form Validation Class Initialized
INFO - 2023-09-03 05:58:35 --> Controller Class Initialized
INFO - 2023-09-03 05:58:35 --> Model Class Initialized
DEBUG - 2023-09-03 05:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:58:35 --> Model Class Initialized
INFO - 2023-09-03 05:58:35 --> Final output sent to browser
DEBUG - 2023-09-03 05:58:35 --> Total execution time: 0.0206
ERROR - 2023-09-03 05:58:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 05:58:36 --> Config Class Initialized
INFO - 2023-09-03 05:58:36 --> Hooks Class Initialized
DEBUG - 2023-09-03 05:58:36 --> UTF-8 Support Enabled
INFO - 2023-09-03 05:58:36 --> Utf8 Class Initialized
INFO - 2023-09-03 05:58:36 --> URI Class Initialized
INFO - 2023-09-03 05:58:36 --> Router Class Initialized
INFO - 2023-09-03 05:58:36 --> Output Class Initialized
INFO - 2023-09-03 05:58:36 --> Security Class Initialized
DEBUG - 2023-09-03 05:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 05:58:36 --> Input Class Initialized
INFO - 2023-09-03 05:58:36 --> Language Class Initialized
INFO - 2023-09-03 05:58:36 --> Loader Class Initialized
INFO - 2023-09-03 05:58:36 --> Helper loaded: url_helper
INFO - 2023-09-03 05:58:36 --> Helper loaded: file_helper
INFO - 2023-09-03 05:58:36 --> Helper loaded: html_helper
INFO - 2023-09-03 05:58:36 --> Helper loaded: text_helper
INFO - 2023-09-03 05:58:36 --> Helper loaded: form_helper
INFO - 2023-09-03 05:58:36 --> Helper loaded: lang_helper
INFO - 2023-09-03 05:58:36 --> Helper loaded: security_helper
INFO - 2023-09-03 05:58:36 --> Helper loaded: cookie_helper
INFO - 2023-09-03 05:58:36 --> Database Driver Class Initialized
INFO - 2023-09-03 05:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 05:58:36 --> Parser Class Initialized
INFO - 2023-09-03 05:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 05:58:36 --> Pagination Class Initialized
INFO - 2023-09-03 05:58:36 --> Form Validation Class Initialized
INFO - 2023-09-03 05:58:36 --> Controller Class Initialized
INFO - 2023-09-03 05:58:36 --> Model Class Initialized
DEBUG - 2023-09-03 05:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:58:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 05:58:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 05:58:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 05:58:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 05:58:36 --> Model Class Initialized
INFO - 2023-09-03 05:58:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 05:58:36 --> Final output sent to browser
DEBUG - 2023-09-03 05:58:36 --> Total execution time: 0.0343
ERROR - 2023-09-03 06:02:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:02:24 --> Config Class Initialized
INFO - 2023-09-03 06:02:24 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:02:24 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:02:24 --> Utf8 Class Initialized
INFO - 2023-09-03 06:02:24 --> URI Class Initialized
INFO - 2023-09-03 06:02:24 --> Router Class Initialized
INFO - 2023-09-03 06:02:24 --> Output Class Initialized
INFO - 2023-09-03 06:02:24 --> Security Class Initialized
DEBUG - 2023-09-03 06:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:02:24 --> Input Class Initialized
INFO - 2023-09-03 06:02:24 --> Language Class Initialized
INFO - 2023-09-03 06:02:24 --> Loader Class Initialized
INFO - 2023-09-03 06:02:24 --> Helper loaded: url_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: file_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: html_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: text_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: form_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: security_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:02:24 --> Database Driver Class Initialized
INFO - 2023-09-03 06:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:02:24 --> Parser Class Initialized
INFO - 2023-09-03 06:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:02:24 --> Pagination Class Initialized
INFO - 2023-09-03 06:02:24 --> Form Validation Class Initialized
INFO - 2023-09-03 06:02:24 --> Controller Class Initialized
INFO - 2023-09-03 06:02:24 --> Model Class Initialized
DEBUG - 2023-09-03 06:02:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 06:02:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:02:24 --> Model Class Initialized
INFO - 2023-09-03 06:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:02:24 --> Final output sent to browser
DEBUG - 2023-09-03 06:02:24 --> Total execution time: 0.0341
ERROR - 2023-09-03 06:02:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:02:24 --> Config Class Initialized
INFO - 2023-09-03 06:02:24 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:02:24 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:02:24 --> Utf8 Class Initialized
INFO - 2023-09-03 06:02:24 --> URI Class Initialized
INFO - 2023-09-03 06:02:24 --> Router Class Initialized
INFO - 2023-09-03 06:02:24 --> Output Class Initialized
INFO - 2023-09-03 06:02:24 --> Security Class Initialized
DEBUG - 2023-09-03 06:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:02:24 --> Input Class Initialized
INFO - 2023-09-03 06:02:24 --> Language Class Initialized
INFO - 2023-09-03 06:02:24 --> Loader Class Initialized
INFO - 2023-09-03 06:02:24 --> Helper loaded: url_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: file_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: html_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: text_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: form_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: security_helper
INFO - 2023-09-03 06:02:24 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:02:24 --> Database Driver Class Initialized
INFO - 2023-09-03 06:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:02:24 --> Parser Class Initialized
INFO - 2023-09-03 06:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:02:24 --> Pagination Class Initialized
INFO - 2023-09-03 06:02:24 --> Form Validation Class Initialized
INFO - 2023-09-03 06:02:24 --> Controller Class Initialized
INFO - 2023-09-03 06:02:24 --> Model Class Initialized
DEBUG - 2023-09-03 06:02:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 06:02:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:02:24 --> Model Class Initialized
INFO - 2023-09-03 06:02:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:02:24 --> Final output sent to browser
DEBUG - 2023-09-03 06:02:24 --> Total execution time: 0.0309
ERROR - 2023-09-03 06:02:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:02:25 --> Config Class Initialized
INFO - 2023-09-03 06:02:25 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:02:25 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:02:25 --> Utf8 Class Initialized
INFO - 2023-09-03 06:02:25 --> URI Class Initialized
INFO - 2023-09-03 06:02:25 --> Router Class Initialized
INFO - 2023-09-03 06:02:25 --> Output Class Initialized
INFO - 2023-09-03 06:02:25 --> Security Class Initialized
DEBUG - 2023-09-03 06:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:02:25 --> Input Class Initialized
INFO - 2023-09-03 06:02:25 --> Language Class Initialized
INFO - 2023-09-03 06:02:25 --> Loader Class Initialized
INFO - 2023-09-03 06:02:25 --> Helper loaded: url_helper
INFO - 2023-09-03 06:02:25 --> Helper loaded: file_helper
INFO - 2023-09-03 06:02:25 --> Helper loaded: html_helper
INFO - 2023-09-03 06:02:25 --> Helper loaded: text_helper
INFO - 2023-09-03 06:02:25 --> Helper loaded: form_helper
INFO - 2023-09-03 06:02:25 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:02:25 --> Helper loaded: security_helper
INFO - 2023-09-03 06:02:25 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:02:25 --> Database Driver Class Initialized
INFO - 2023-09-03 06:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:02:25 --> Parser Class Initialized
INFO - 2023-09-03 06:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:02:25 --> Pagination Class Initialized
INFO - 2023-09-03 06:02:25 --> Form Validation Class Initialized
INFO - 2023-09-03 06:02:25 --> Controller Class Initialized
INFO - 2023-09-03 06:02:25 --> Model Class Initialized
DEBUG - 2023-09-03 06:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 06:02:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:02:25 --> Model Class Initialized
INFO - 2023-09-03 06:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:02:25 --> Final output sent to browser
DEBUG - 2023-09-03 06:02:25 --> Total execution time: 0.0346
ERROR - 2023-09-03 06:47:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:06 --> Config Class Initialized
INFO - 2023-09-03 06:47:06 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:06 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:06 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:06 --> URI Class Initialized
DEBUG - 2023-09-03 06:47:06 --> No URI present. Default controller set.
INFO - 2023-09-03 06:47:06 --> Router Class Initialized
INFO - 2023-09-03 06:47:06 --> Output Class Initialized
INFO - 2023-09-03 06:47:06 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:06 --> Input Class Initialized
INFO - 2023-09-03 06:47:06 --> Language Class Initialized
INFO - 2023-09-03 06:47:06 --> Loader Class Initialized
INFO - 2023-09-03 06:47:06 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:06 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:06 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:06 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:06 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:06 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:06 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:06 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:06 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:06 --> Parser Class Initialized
INFO - 2023-09-03 06:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:06 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:06 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:06 --> Controller Class Initialized
INFO - 2023-09-03 06:47:06 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 06:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:07 --> Config Class Initialized
INFO - 2023-09-03 06:47:07 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:07 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:07 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:07 --> URI Class Initialized
INFO - 2023-09-03 06:47:07 --> Router Class Initialized
INFO - 2023-09-03 06:47:07 --> Output Class Initialized
INFO - 2023-09-03 06:47:07 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:07 --> Input Class Initialized
INFO - 2023-09-03 06:47:07 --> Language Class Initialized
INFO - 2023-09-03 06:47:07 --> Loader Class Initialized
INFO - 2023-09-03 06:47:07 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:07 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:07 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:07 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:07 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:07 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:07 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:07 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:07 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:07 --> Parser Class Initialized
INFO - 2023-09-03 06:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:07 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:07 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:07 --> Controller Class Initialized
INFO - 2023-09-03 06:47:07 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 06:47:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:47:07 --> Model Class Initialized
INFO - 2023-09-03 06:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:47:07 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:07 --> Total execution time: 0.0310
ERROR - 2023-09-03 06:47:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:10 --> Config Class Initialized
INFO - 2023-09-03 06:47:10 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:10 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:10 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:10 --> URI Class Initialized
INFO - 2023-09-03 06:47:10 --> Router Class Initialized
INFO - 2023-09-03 06:47:10 --> Output Class Initialized
INFO - 2023-09-03 06:47:10 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:10 --> Input Class Initialized
INFO - 2023-09-03 06:47:10 --> Language Class Initialized
INFO - 2023-09-03 06:47:10 --> Loader Class Initialized
INFO - 2023-09-03 06:47:10 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:10 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:10 --> Parser Class Initialized
INFO - 2023-09-03 06:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:10 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:10 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:10 --> Controller Class Initialized
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
INFO - 2023-09-03 06:47:10 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:10 --> Total execution time: 0.0174
ERROR - 2023-09-03 06:47:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:10 --> Config Class Initialized
INFO - 2023-09-03 06:47:10 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:10 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:10 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:10 --> URI Class Initialized
DEBUG - 2023-09-03 06:47:10 --> No URI present. Default controller set.
INFO - 2023-09-03 06:47:10 --> Router Class Initialized
INFO - 2023-09-03 06:47:10 --> Output Class Initialized
INFO - 2023-09-03 06:47:10 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:10 --> Input Class Initialized
INFO - 2023-09-03 06:47:10 --> Language Class Initialized
INFO - 2023-09-03 06:47:10 --> Loader Class Initialized
INFO - 2023-09-03 06:47:10 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:10 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:10 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:10 --> Parser Class Initialized
INFO - 2023-09-03 06:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:10 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:10 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:10 --> Controller Class Initialized
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
INFO - 2023-09-03 06:47:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 06:47:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:47:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:47:10 --> Model Class Initialized
INFO - 2023-09-03 06:47:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:47:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:47:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:47:10 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:10 --> Total execution time: 0.2230
ERROR - 2023-09-03 06:47:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:11 --> Config Class Initialized
INFO - 2023-09-03 06:47:11 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:11 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:11 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:11 --> URI Class Initialized
INFO - 2023-09-03 06:47:11 --> Router Class Initialized
INFO - 2023-09-03 06:47:11 --> Output Class Initialized
INFO - 2023-09-03 06:47:11 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:11 --> Input Class Initialized
INFO - 2023-09-03 06:47:11 --> Language Class Initialized
INFO - 2023-09-03 06:47:11 --> Loader Class Initialized
INFO - 2023-09-03 06:47:11 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:11 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:11 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:11 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:11 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:11 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:11 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:11 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:11 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:11 --> Parser Class Initialized
INFO - 2023-09-03 06:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:11 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:11 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:11 --> Controller Class Initialized
DEBUG - 2023-09-03 06:47:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:11 --> Model Class Initialized
INFO - 2023-09-03 06:47:11 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:11 --> Total execution time: 0.0155
ERROR - 2023-09-03 06:47:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:17 --> Config Class Initialized
INFO - 2023-09-03 06:47:17 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:17 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:17 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:17 --> URI Class Initialized
INFO - 2023-09-03 06:47:17 --> Router Class Initialized
INFO - 2023-09-03 06:47:17 --> Output Class Initialized
INFO - 2023-09-03 06:47:17 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:17 --> Input Class Initialized
INFO - 2023-09-03 06:47:17 --> Language Class Initialized
INFO - 2023-09-03 06:47:17 --> Loader Class Initialized
INFO - 2023-09-03 06:47:17 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:17 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:17 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:17 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:17 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:17 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:17 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:17 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:17 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:17 --> Parser Class Initialized
INFO - 2023-09-03 06:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:17 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:17 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:17 --> Controller Class Initialized
INFO - 2023-09-03 06:47:17 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:17 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:17 --> Model Class Initialized
INFO - 2023-09-03 06:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-03 06:47:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:47:17 --> Model Class Initialized
INFO - 2023-09-03 06:47:17 --> Model Class Initialized
INFO - 2023-09-03 06:47:17 --> Model Class Initialized
INFO - 2023-09-03 06:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:47:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:47:17 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:17 --> Total execution time: 0.1776
ERROR - 2023-09-03 06:47:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:18 --> Config Class Initialized
INFO - 2023-09-03 06:47:18 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:18 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:18 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:18 --> URI Class Initialized
INFO - 2023-09-03 06:47:18 --> Router Class Initialized
INFO - 2023-09-03 06:47:18 --> Output Class Initialized
INFO - 2023-09-03 06:47:18 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:18 --> Input Class Initialized
INFO - 2023-09-03 06:47:18 --> Language Class Initialized
INFO - 2023-09-03 06:47:18 --> Loader Class Initialized
INFO - 2023-09-03 06:47:18 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:18 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:18 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:18 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:18 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:18 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:18 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:18 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:18 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:18 --> Parser Class Initialized
INFO - 2023-09-03 06:47:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:18 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:18 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:18 --> Controller Class Initialized
INFO - 2023-09-03 06:47:18 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:18 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:18 --> Model Class Initialized
INFO - 2023-09-03 06:47:18 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:18 --> Total execution time: 0.0582
ERROR - 2023-09-03 06:47:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:21 --> Config Class Initialized
INFO - 2023-09-03 06:47:21 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:21 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:21 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:21 --> URI Class Initialized
INFO - 2023-09-03 06:47:21 --> Router Class Initialized
INFO - 2023-09-03 06:47:21 --> Output Class Initialized
INFO - 2023-09-03 06:47:21 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:21 --> Input Class Initialized
INFO - 2023-09-03 06:47:21 --> Language Class Initialized
INFO - 2023-09-03 06:47:21 --> Loader Class Initialized
INFO - 2023-09-03 06:47:21 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:21 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:21 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:21 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:21 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:21 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:21 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:21 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:21 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:21 --> Parser Class Initialized
INFO - 2023-09-03 06:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:21 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:21 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:21 --> Controller Class Initialized
INFO - 2023-09-03 06:47:21 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:21 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:21 --> Model Class Initialized
INFO - 2023-09-03 06:47:21 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:21 --> Total execution time: 0.0594
ERROR - 2023-09-03 06:47:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:22 --> Config Class Initialized
INFO - 2023-09-03 06:47:22 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:22 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:22 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:22 --> URI Class Initialized
INFO - 2023-09-03 06:47:22 --> Router Class Initialized
INFO - 2023-09-03 06:47:22 --> Output Class Initialized
INFO - 2023-09-03 06:47:22 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:22 --> Input Class Initialized
INFO - 2023-09-03 06:47:22 --> Language Class Initialized
INFO - 2023-09-03 06:47:22 --> Loader Class Initialized
INFO - 2023-09-03 06:47:22 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:22 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:22 --> Parser Class Initialized
INFO - 2023-09-03 06:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:22 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:22 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:22 --> Controller Class Initialized
INFO - 2023-09-03 06:47:22 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:22 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:22 --> Model Class Initialized
INFO - 2023-09-03 06:47:22 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:22 --> Total execution time: 0.0645
ERROR - 2023-09-03 06:47:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:22 --> Config Class Initialized
INFO - 2023-09-03 06:47:22 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:22 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:22 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:22 --> URI Class Initialized
INFO - 2023-09-03 06:47:22 --> Router Class Initialized
INFO - 2023-09-03 06:47:22 --> Output Class Initialized
INFO - 2023-09-03 06:47:22 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:22 --> Input Class Initialized
INFO - 2023-09-03 06:47:22 --> Language Class Initialized
INFO - 2023-09-03 06:47:22 --> Loader Class Initialized
INFO - 2023-09-03 06:47:22 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:22 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:22 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:22 --> Parser Class Initialized
INFO - 2023-09-03 06:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:22 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:22 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:22 --> Controller Class Initialized
INFO - 2023-09-03 06:47:22 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:22 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:22 --> Model Class Initialized
INFO - 2023-09-03 06:47:22 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:22 --> Total execution time: 0.0404
ERROR - 2023-09-03 06:47:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:23 --> Config Class Initialized
INFO - 2023-09-03 06:47:23 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:23 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:23 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:23 --> URI Class Initialized
INFO - 2023-09-03 06:47:23 --> Router Class Initialized
INFO - 2023-09-03 06:47:23 --> Output Class Initialized
INFO - 2023-09-03 06:47:23 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:23 --> Input Class Initialized
INFO - 2023-09-03 06:47:23 --> Language Class Initialized
INFO - 2023-09-03 06:47:23 --> Loader Class Initialized
INFO - 2023-09-03 06:47:23 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:23 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:23 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:23 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:23 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:23 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:23 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:23 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:23 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:23 --> Parser Class Initialized
INFO - 2023-09-03 06:47:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:23 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:23 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:23 --> Controller Class Initialized
INFO - 2023-09-03 06:47:23 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:23 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:23 --> Model Class Initialized
INFO - 2023-09-03 06:47:23 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:23 --> Total execution time: 0.0253
ERROR - 2023-09-03 06:47:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:24 --> Config Class Initialized
INFO - 2023-09-03 06:47:24 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:24 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:24 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:24 --> URI Class Initialized
INFO - 2023-09-03 06:47:24 --> Router Class Initialized
INFO - 2023-09-03 06:47:24 --> Output Class Initialized
INFO - 2023-09-03 06:47:24 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:24 --> Input Class Initialized
INFO - 2023-09-03 06:47:24 --> Language Class Initialized
INFO - 2023-09-03 06:47:24 --> Loader Class Initialized
INFO - 2023-09-03 06:47:24 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:24 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:24 --> Parser Class Initialized
INFO - 2023-09-03 06:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:24 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:24 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:24 --> Controller Class Initialized
INFO - 2023-09-03 06:47:24 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:24 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:24 --> Model Class Initialized
INFO - 2023-09-03 06:47:24 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:24 --> Total execution time: 0.0231
ERROR - 2023-09-03 06:47:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:24 --> Config Class Initialized
INFO - 2023-09-03 06:47:24 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:24 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:24 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:24 --> URI Class Initialized
INFO - 2023-09-03 06:47:24 --> Router Class Initialized
INFO - 2023-09-03 06:47:24 --> Output Class Initialized
INFO - 2023-09-03 06:47:24 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:24 --> Input Class Initialized
INFO - 2023-09-03 06:47:24 --> Language Class Initialized
INFO - 2023-09-03 06:47:24 --> Loader Class Initialized
INFO - 2023-09-03 06:47:24 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:24 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:24 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:24 --> Parser Class Initialized
INFO - 2023-09-03 06:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:24 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:24 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:24 --> Controller Class Initialized
INFO - 2023-09-03 06:47:24 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:24 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:24 --> Model Class Initialized
INFO - 2023-09-03 06:47:24 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:24 --> Total execution time: 0.0228
ERROR - 2023-09-03 06:47:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:28 --> Config Class Initialized
INFO - 2023-09-03 06:47:28 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:28 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:28 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:28 --> URI Class Initialized
INFO - 2023-09-03 06:47:28 --> Router Class Initialized
INFO - 2023-09-03 06:47:28 --> Output Class Initialized
INFO - 2023-09-03 06:47:28 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:28 --> Input Class Initialized
INFO - 2023-09-03 06:47:28 --> Language Class Initialized
INFO - 2023-09-03 06:47:28 --> Loader Class Initialized
INFO - 2023-09-03 06:47:28 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:28 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:28 --> Parser Class Initialized
INFO - 2023-09-03 06:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:28 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:28 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:28 --> Controller Class Initialized
INFO - 2023-09-03 06:47:28 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:28 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:28 --> Model Class Initialized
INFO - 2023-09-03 06:47:28 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:28 --> Total execution time: 0.0233
ERROR - 2023-09-03 06:47:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:28 --> Config Class Initialized
INFO - 2023-09-03 06:47:28 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:28 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:28 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:28 --> URI Class Initialized
INFO - 2023-09-03 06:47:28 --> Router Class Initialized
INFO - 2023-09-03 06:47:28 --> Output Class Initialized
INFO - 2023-09-03 06:47:28 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:28 --> Input Class Initialized
INFO - 2023-09-03 06:47:28 --> Language Class Initialized
INFO - 2023-09-03 06:47:28 --> Loader Class Initialized
INFO - 2023-09-03 06:47:28 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:28 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:28 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:28 --> Parser Class Initialized
INFO - 2023-09-03 06:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:28 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:28 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:28 --> Controller Class Initialized
INFO - 2023-09-03 06:47:28 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:28 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:28 --> Model Class Initialized
INFO - 2023-09-03 06:47:28 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:28 --> Total execution time: 0.0345
ERROR - 2023-09-03 06:47:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:29 --> Config Class Initialized
INFO - 2023-09-03 06:47:29 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:29 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:29 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:29 --> URI Class Initialized
INFO - 2023-09-03 06:47:29 --> Router Class Initialized
INFO - 2023-09-03 06:47:29 --> Output Class Initialized
INFO - 2023-09-03 06:47:29 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:29 --> Input Class Initialized
INFO - 2023-09-03 06:47:29 --> Language Class Initialized
INFO - 2023-09-03 06:47:29 --> Loader Class Initialized
INFO - 2023-09-03 06:47:29 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:29 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:29 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:29 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:29 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:29 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:29 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:29 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:29 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:29 --> Parser Class Initialized
INFO - 2023-09-03 06:47:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:29 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:29 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:29 --> Controller Class Initialized
INFO - 2023-09-03 06:47:29 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:29 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:29 --> Model Class Initialized
INFO - 2023-09-03 06:47:29 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:29 --> Total execution time: 0.0235
ERROR - 2023-09-03 06:47:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:30 --> Config Class Initialized
INFO - 2023-09-03 06:47:30 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:30 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:30 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:30 --> URI Class Initialized
INFO - 2023-09-03 06:47:30 --> Router Class Initialized
INFO - 2023-09-03 06:47:30 --> Output Class Initialized
INFO - 2023-09-03 06:47:30 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:30 --> Input Class Initialized
INFO - 2023-09-03 06:47:30 --> Language Class Initialized
INFO - 2023-09-03 06:47:30 --> Loader Class Initialized
INFO - 2023-09-03 06:47:30 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:30 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:30 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:30 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:30 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:30 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:30 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:30 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:30 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:30 --> Parser Class Initialized
INFO - 2023-09-03 06:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:30 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:30 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:30 --> Controller Class Initialized
INFO - 2023-09-03 06:47:30 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:30 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:30 --> Model Class Initialized
INFO - 2023-09-03 06:47:30 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:30 --> Total execution time: 0.0234
ERROR - 2023-09-03 06:47:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:31 --> Config Class Initialized
INFO - 2023-09-03 06:47:31 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:31 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:31 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:31 --> URI Class Initialized
INFO - 2023-09-03 06:47:31 --> Router Class Initialized
INFO - 2023-09-03 06:47:31 --> Output Class Initialized
INFO - 2023-09-03 06:47:31 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:31 --> Input Class Initialized
INFO - 2023-09-03 06:47:31 --> Language Class Initialized
INFO - 2023-09-03 06:47:31 --> Loader Class Initialized
INFO - 2023-09-03 06:47:31 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:31 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:31 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:31 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:31 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:31 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:31 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:31 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:31 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:31 --> Parser Class Initialized
INFO - 2023-09-03 06:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:31 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:31 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:31 --> Controller Class Initialized
INFO - 2023-09-03 06:47:31 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:31 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:31 --> Model Class Initialized
INFO - 2023-09-03 06:47:31 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:31 --> Total execution time: 0.0226
ERROR - 2023-09-03 06:47:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:32 --> Config Class Initialized
INFO - 2023-09-03 06:47:32 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:32 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:32 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:32 --> URI Class Initialized
INFO - 2023-09-03 06:47:32 --> Router Class Initialized
INFO - 2023-09-03 06:47:32 --> Output Class Initialized
INFO - 2023-09-03 06:47:32 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:32 --> Input Class Initialized
INFO - 2023-09-03 06:47:32 --> Language Class Initialized
INFO - 2023-09-03 06:47:32 --> Loader Class Initialized
INFO - 2023-09-03 06:47:32 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:32 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:32 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:32 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:32 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:32 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:32 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:32 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:32 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:32 --> Parser Class Initialized
INFO - 2023-09-03 06:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:32 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:32 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:32 --> Controller Class Initialized
INFO - 2023-09-03 06:47:32 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:32 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:32 --> Model Class Initialized
INFO - 2023-09-03 06:47:32 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:32 --> Total execution time: 0.0333
ERROR - 2023-09-03 06:47:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:39 --> Config Class Initialized
INFO - 2023-09-03 06:47:39 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:39 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:39 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:39 --> URI Class Initialized
INFO - 2023-09-03 06:47:39 --> Router Class Initialized
INFO - 2023-09-03 06:47:39 --> Output Class Initialized
INFO - 2023-09-03 06:47:39 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:39 --> Input Class Initialized
INFO - 2023-09-03 06:47:39 --> Language Class Initialized
INFO - 2023-09-03 06:47:39 --> Loader Class Initialized
INFO - 2023-09-03 06:47:39 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:39 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:39 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:39 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:39 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:39 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:39 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:39 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:39 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:39 --> Parser Class Initialized
INFO - 2023-09-03 06:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:39 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:39 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:39 --> Controller Class Initialized
DEBUG - 2023-09-03 06:47:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:39 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:39 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:39 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:39 --> Model Class Initialized
INFO - 2023-09-03 06:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-03 06:47:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:47:39 --> Model Class Initialized
INFO - 2023-09-03 06:47:39 --> Model Class Initialized
INFO - 2023-09-03 06:47:39 --> Model Class Initialized
INFO - 2023-09-03 06:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:47:39 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:39 --> Total execution time: 0.1629
ERROR - 2023-09-03 06:47:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:40 --> Config Class Initialized
INFO - 2023-09-03 06:47:40 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:40 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:40 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:40 --> URI Class Initialized
INFO - 2023-09-03 06:47:40 --> Router Class Initialized
INFO - 2023-09-03 06:47:40 --> Output Class Initialized
INFO - 2023-09-03 06:47:40 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:40 --> Input Class Initialized
INFO - 2023-09-03 06:47:40 --> Language Class Initialized
INFO - 2023-09-03 06:47:40 --> Loader Class Initialized
INFO - 2023-09-03 06:47:40 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:40 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:40 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:40 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:40 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:40 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:40 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:40 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:40 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:40 --> Parser Class Initialized
INFO - 2023-09-03 06:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:40 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:40 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:40 --> Controller Class Initialized
DEBUG - 2023-09-03 06:47:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:40 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:40 --> Model Class Initialized
INFO - 2023-09-03 06:47:40 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:40 --> Total execution time: 0.0356
ERROR - 2023-09-03 06:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:47:44 --> Config Class Initialized
INFO - 2023-09-03 06:47:44 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:47:44 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:47:44 --> Utf8 Class Initialized
INFO - 2023-09-03 06:47:44 --> URI Class Initialized
INFO - 2023-09-03 06:47:44 --> Router Class Initialized
INFO - 2023-09-03 06:47:44 --> Output Class Initialized
INFO - 2023-09-03 06:47:44 --> Security Class Initialized
DEBUG - 2023-09-03 06:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:47:44 --> Input Class Initialized
INFO - 2023-09-03 06:47:44 --> Language Class Initialized
INFO - 2023-09-03 06:47:44 --> Loader Class Initialized
INFO - 2023-09-03 06:47:44 --> Helper loaded: url_helper
INFO - 2023-09-03 06:47:44 --> Helper loaded: file_helper
INFO - 2023-09-03 06:47:44 --> Helper loaded: html_helper
INFO - 2023-09-03 06:47:44 --> Helper loaded: text_helper
INFO - 2023-09-03 06:47:44 --> Helper loaded: form_helper
INFO - 2023-09-03 06:47:44 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:47:44 --> Helper loaded: security_helper
INFO - 2023-09-03 06:47:44 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:47:44 --> Database Driver Class Initialized
INFO - 2023-09-03 06:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:47:44 --> Parser Class Initialized
INFO - 2023-09-03 06:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:47:44 --> Pagination Class Initialized
INFO - 2023-09-03 06:47:44 --> Form Validation Class Initialized
INFO - 2023-09-03 06:47:44 --> Controller Class Initialized
DEBUG - 2023-09-03 06:47:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:44 --> Model Class Initialized
DEBUG - 2023-09-03 06:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:47:44 --> Model Class Initialized
INFO - 2023-09-03 06:47:44 --> Final output sent to browser
DEBUG - 2023-09-03 06:47:44 --> Total execution time: 0.1494
ERROR - 2023-09-03 06:48:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:48:03 --> Config Class Initialized
INFO - 2023-09-03 06:48:03 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:48:03 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:48:03 --> Utf8 Class Initialized
INFO - 2023-09-03 06:48:03 --> URI Class Initialized
INFO - 2023-09-03 06:48:03 --> Router Class Initialized
INFO - 2023-09-03 06:48:03 --> Output Class Initialized
INFO - 2023-09-03 06:48:03 --> Security Class Initialized
DEBUG - 2023-09-03 06:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:48:03 --> Input Class Initialized
INFO - 2023-09-03 06:48:03 --> Language Class Initialized
INFO - 2023-09-03 06:48:03 --> Loader Class Initialized
INFO - 2023-09-03 06:48:03 --> Helper loaded: url_helper
INFO - 2023-09-03 06:48:03 --> Helper loaded: file_helper
INFO - 2023-09-03 06:48:03 --> Helper loaded: html_helper
INFO - 2023-09-03 06:48:03 --> Helper loaded: text_helper
INFO - 2023-09-03 06:48:03 --> Helper loaded: form_helper
INFO - 2023-09-03 06:48:03 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:48:03 --> Helper loaded: security_helper
INFO - 2023-09-03 06:48:03 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:48:03 --> Database Driver Class Initialized
INFO - 2023-09-03 06:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:48:03 --> Parser Class Initialized
INFO - 2023-09-03 06:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:48:03 --> Pagination Class Initialized
INFO - 2023-09-03 06:48:03 --> Form Validation Class Initialized
INFO - 2023-09-03 06:48:03 --> Controller Class Initialized
DEBUG - 2023-09-03 06:48:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:03 --> Model Class Initialized
DEBUG - 2023-09-03 06:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:03 --> Model Class Initialized
INFO - 2023-09-03 06:48:03 --> Final output sent to browser
DEBUG - 2023-09-03 06:48:03 --> Total execution time: 0.0783
ERROR - 2023-09-03 06:48:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:48:04 --> Config Class Initialized
INFO - 2023-09-03 06:48:04 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:48:04 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:48:04 --> Utf8 Class Initialized
INFO - 2023-09-03 06:48:04 --> URI Class Initialized
INFO - 2023-09-03 06:48:04 --> Router Class Initialized
INFO - 2023-09-03 06:48:04 --> Output Class Initialized
INFO - 2023-09-03 06:48:04 --> Security Class Initialized
DEBUG - 2023-09-03 06:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:48:04 --> Input Class Initialized
INFO - 2023-09-03 06:48:04 --> Language Class Initialized
INFO - 2023-09-03 06:48:04 --> Loader Class Initialized
INFO - 2023-09-03 06:48:04 --> Helper loaded: url_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: file_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: html_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: text_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: form_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: security_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:48:04 --> Database Driver Class Initialized
INFO - 2023-09-03 06:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:48:04 --> Parser Class Initialized
INFO - 2023-09-03 06:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:48:04 --> Pagination Class Initialized
INFO - 2023-09-03 06:48:04 --> Form Validation Class Initialized
INFO - 2023-09-03 06:48:04 --> Controller Class Initialized
DEBUG - 2023-09-03 06:48:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:04 --> Model Class Initialized
DEBUG - 2023-09-03 06:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:04 --> Model Class Initialized
INFO - 2023-09-03 06:48:04 --> Final output sent to browser
DEBUG - 2023-09-03 06:48:04 --> Total execution time: 0.0546
ERROR - 2023-09-03 06:48:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:48:04 --> Config Class Initialized
INFO - 2023-09-03 06:48:04 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:48:04 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:48:04 --> Utf8 Class Initialized
INFO - 2023-09-03 06:48:04 --> URI Class Initialized
INFO - 2023-09-03 06:48:04 --> Router Class Initialized
INFO - 2023-09-03 06:48:04 --> Output Class Initialized
INFO - 2023-09-03 06:48:04 --> Security Class Initialized
DEBUG - 2023-09-03 06:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:48:04 --> Input Class Initialized
INFO - 2023-09-03 06:48:04 --> Language Class Initialized
INFO - 2023-09-03 06:48:04 --> Loader Class Initialized
INFO - 2023-09-03 06:48:04 --> Helper loaded: url_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: file_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: html_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: text_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: form_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: security_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:48:04 --> Database Driver Class Initialized
INFO - 2023-09-03 06:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:48:04 --> Parser Class Initialized
INFO - 2023-09-03 06:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:48:04 --> Pagination Class Initialized
INFO - 2023-09-03 06:48:04 --> Form Validation Class Initialized
INFO - 2023-09-03 06:48:04 --> Controller Class Initialized
DEBUG - 2023-09-03 06:48:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:04 --> Model Class Initialized
DEBUG - 2023-09-03 06:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:04 --> Model Class Initialized
INFO - 2023-09-03 06:48:04 --> Final output sent to browser
DEBUG - 2023-09-03 06:48:04 --> Total execution time: 0.0243
ERROR - 2023-09-03 06:48:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:48:04 --> Config Class Initialized
INFO - 2023-09-03 06:48:04 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:48:04 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:48:04 --> Utf8 Class Initialized
INFO - 2023-09-03 06:48:04 --> URI Class Initialized
INFO - 2023-09-03 06:48:04 --> Router Class Initialized
INFO - 2023-09-03 06:48:04 --> Output Class Initialized
INFO - 2023-09-03 06:48:04 --> Security Class Initialized
DEBUG - 2023-09-03 06:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:48:04 --> Input Class Initialized
INFO - 2023-09-03 06:48:04 --> Language Class Initialized
INFO - 2023-09-03 06:48:04 --> Loader Class Initialized
INFO - 2023-09-03 06:48:04 --> Helper loaded: url_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: file_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: html_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: text_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: form_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: security_helper
INFO - 2023-09-03 06:48:04 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:48:04 --> Database Driver Class Initialized
INFO - 2023-09-03 06:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:48:04 --> Parser Class Initialized
INFO - 2023-09-03 06:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:48:04 --> Pagination Class Initialized
INFO - 2023-09-03 06:48:04 --> Form Validation Class Initialized
INFO - 2023-09-03 06:48:04 --> Controller Class Initialized
DEBUG - 2023-09-03 06:48:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:04 --> Model Class Initialized
DEBUG - 2023-09-03 06:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:04 --> Model Class Initialized
INFO - 2023-09-03 06:48:04 --> Final output sent to browser
DEBUG - 2023-09-03 06:48:04 --> Total execution time: 0.0213
ERROR - 2023-09-03 06:48:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:48:21 --> Config Class Initialized
INFO - 2023-09-03 06:48:21 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:48:21 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:48:21 --> Utf8 Class Initialized
INFO - 2023-09-03 06:48:21 --> URI Class Initialized
INFO - 2023-09-03 06:48:21 --> Router Class Initialized
INFO - 2023-09-03 06:48:21 --> Output Class Initialized
INFO - 2023-09-03 06:48:21 --> Security Class Initialized
DEBUG - 2023-09-03 06:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:48:21 --> Input Class Initialized
INFO - 2023-09-03 06:48:21 --> Language Class Initialized
INFO - 2023-09-03 06:48:21 --> Loader Class Initialized
INFO - 2023-09-03 06:48:21 --> Helper loaded: url_helper
INFO - 2023-09-03 06:48:21 --> Helper loaded: file_helper
INFO - 2023-09-03 06:48:21 --> Helper loaded: html_helper
INFO - 2023-09-03 06:48:21 --> Helper loaded: text_helper
INFO - 2023-09-03 06:48:21 --> Helper loaded: form_helper
INFO - 2023-09-03 06:48:21 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:48:21 --> Helper loaded: security_helper
INFO - 2023-09-03 06:48:21 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:48:21 --> Database Driver Class Initialized
INFO - 2023-09-03 06:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:48:21 --> Parser Class Initialized
INFO - 2023-09-03 06:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:48:21 --> Pagination Class Initialized
INFO - 2023-09-03 06:48:21 --> Form Validation Class Initialized
INFO - 2023-09-03 06:48:21 --> Controller Class Initialized
DEBUG - 2023-09-03 06:48:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:21 --> Model Class Initialized
DEBUG - 2023-09-03 06:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:21 --> Model Class Initialized
INFO - 2023-09-03 06:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-09-03 06:48:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:48:21 --> Model Class Initialized
INFO - 2023-09-03 06:48:21 --> Model Class Initialized
INFO - 2023-09-03 06:48:21 --> Model Class Initialized
INFO - 2023-09-03 06:48:21 --> Model Class Initialized
INFO - 2023-09-03 06:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:48:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:48:21 --> Final output sent to browser
DEBUG - 2023-09-03 06:48:21 --> Total execution time: 0.1349
ERROR - 2023-09-03 06:48:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:48:49 --> Config Class Initialized
INFO - 2023-09-03 06:48:49 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:48:49 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:48:49 --> Utf8 Class Initialized
INFO - 2023-09-03 06:48:49 --> URI Class Initialized
DEBUG - 2023-09-03 06:48:49 --> No URI present. Default controller set.
INFO - 2023-09-03 06:48:49 --> Router Class Initialized
INFO - 2023-09-03 06:48:49 --> Output Class Initialized
INFO - 2023-09-03 06:48:49 --> Security Class Initialized
DEBUG - 2023-09-03 06:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:48:49 --> Input Class Initialized
INFO - 2023-09-03 06:48:49 --> Language Class Initialized
INFO - 2023-09-03 06:48:49 --> Loader Class Initialized
INFO - 2023-09-03 06:48:49 --> Helper loaded: url_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: file_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: html_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: text_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: form_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: security_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:48:49 --> Database Driver Class Initialized
INFO - 2023-09-03 06:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:48:49 --> Parser Class Initialized
INFO - 2023-09-03 06:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:48:49 --> Pagination Class Initialized
INFO - 2023-09-03 06:48:49 --> Form Validation Class Initialized
INFO - 2023-09-03 06:48:49 --> Controller Class Initialized
INFO - 2023-09-03 06:48:49 --> Model Class Initialized
DEBUG - 2023-09-03 06:48:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 06:48:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:48:49 --> Config Class Initialized
INFO - 2023-09-03 06:48:49 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:48:49 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:48:49 --> Utf8 Class Initialized
INFO - 2023-09-03 06:48:49 --> URI Class Initialized
INFO - 2023-09-03 06:48:49 --> Router Class Initialized
INFO - 2023-09-03 06:48:49 --> Output Class Initialized
INFO - 2023-09-03 06:48:49 --> Security Class Initialized
DEBUG - 2023-09-03 06:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:48:49 --> Input Class Initialized
INFO - 2023-09-03 06:48:49 --> Language Class Initialized
INFO - 2023-09-03 06:48:49 --> Loader Class Initialized
INFO - 2023-09-03 06:48:49 --> Helper loaded: url_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: file_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: html_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: text_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: form_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: security_helper
INFO - 2023-09-03 06:48:49 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:48:49 --> Database Driver Class Initialized
INFO - 2023-09-03 06:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:48:49 --> Parser Class Initialized
INFO - 2023-09-03 06:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:48:49 --> Pagination Class Initialized
INFO - 2023-09-03 06:48:49 --> Form Validation Class Initialized
INFO - 2023-09-03 06:48:49 --> Controller Class Initialized
INFO - 2023-09-03 06:48:49 --> Model Class Initialized
DEBUG - 2023-09-03 06:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 06:48:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:48:49 --> Model Class Initialized
INFO - 2023-09-03 06:48:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:48:49 --> Final output sent to browser
DEBUG - 2023-09-03 06:48:49 --> Total execution time: 0.0351
ERROR - 2023-09-03 06:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:49:40 --> Config Class Initialized
INFO - 2023-09-03 06:49:40 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:49:40 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:49:40 --> Utf8 Class Initialized
INFO - 2023-09-03 06:49:40 --> URI Class Initialized
INFO - 2023-09-03 06:49:40 --> Router Class Initialized
INFO - 2023-09-03 06:49:40 --> Output Class Initialized
INFO - 2023-09-03 06:49:40 --> Security Class Initialized
DEBUG - 2023-09-03 06:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:49:40 --> Input Class Initialized
INFO - 2023-09-03 06:49:40 --> Language Class Initialized
INFO - 2023-09-03 06:49:40 --> Loader Class Initialized
INFO - 2023-09-03 06:49:40 --> Helper loaded: url_helper
INFO - 2023-09-03 06:49:40 --> Helper loaded: file_helper
INFO - 2023-09-03 06:49:40 --> Helper loaded: html_helper
INFO - 2023-09-03 06:49:40 --> Helper loaded: text_helper
INFO - 2023-09-03 06:49:40 --> Helper loaded: form_helper
INFO - 2023-09-03 06:49:40 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:49:40 --> Helper loaded: security_helper
INFO - 2023-09-03 06:49:40 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:49:40 --> Database Driver Class Initialized
INFO - 2023-09-03 06:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:49:40 --> Parser Class Initialized
INFO - 2023-09-03 06:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:49:40 --> Pagination Class Initialized
INFO - 2023-09-03 06:49:40 --> Form Validation Class Initialized
INFO - 2023-09-03 06:49:40 --> Controller Class Initialized
INFO - 2023-09-03 06:49:40 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:40 --> Model Class Initialized
INFO - 2023-09-03 06:49:41 --> Final output sent to browser
DEBUG - 2023-09-03 06:49:41 --> Total execution time: 0.0200
ERROR - 2023-09-03 06:49:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:49:41 --> Config Class Initialized
INFO - 2023-09-03 06:49:41 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:49:41 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:49:41 --> Utf8 Class Initialized
INFO - 2023-09-03 06:49:41 --> URI Class Initialized
DEBUG - 2023-09-03 06:49:41 --> No URI present. Default controller set.
INFO - 2023-09-03 06:49:41 --> Router Class Initialized
INFO - 2023-09-03 06:49:41 --> Output Class Initialized
INFO - 2023-09-03 06:49:41 --> Security Class Initialized
DEBUG - 2023-09-03 06:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:49:41 --> Input Class Initialized
INFO - 2023-09-03 06:49:41 --> Language Class Initialized
INFO - 2023-09-03 06:49:41 --> Loader Class Initialized
INFO - 2023-09-03 06:49:41 --> Helper loaded: url_helper
INFO - 2023-09-03 06:49:41 --> Helper loaded: file_helper
INFO - 2023-09-03 06:49:41 --> Helper loaded: html_helper
INFO - 2023-09-03 06:49:41 --> Helper loaded: text_helper
INFO - 2023-09-03 06:49:41 --> Helper loaded: form_helper
INFO - 2023-09-03 06:49:41 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:49:41 --> Helper loaded: security_helper
INFO - 2023-09-03 06:49:41 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:49:41 --> Database Driver Class Initialized
INFO - 2023-09-03 06:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:49:41 --> Parser Class Initialized
INFO - 2023-09-03 06:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:49:41 --> Pagination Class Initialized
INFO - 2023-09-03 06:49:41 --> Form Validation Class Initialized
INFO - 2023-09-03 06:49:41 --> Controller Class Initialized
INFO - 2023-09-03 06:49:41 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:41 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:41 --> Model Class Initialized
INFO - 2023-09-03 06:49:41 --> Model Class Initialized
INFO - 2023-09-03 06:49:41 --> Model Class Initialized
INFO - 2023-09-03 06:49:41 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:41 --> Model Class Initialized
INFO - 2023-09-03 06:49:41 --> Model Class Initialized
INFO - 2023-09-03 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 06:49:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:49:41 --> Model Class Initialized
INFO - 2023-09-03 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:49:41 --> Final output sent to browser
DEBUG - 2023-09-03 06:49:41 --> Total execution time: 0.0825
ERROR - 2023-09-03 06:49:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:49:47 --> Config Class Initialized
INFO - 2023-09-03 06:49:47 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:49:47 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:49:47 --> Utf8 Class Initialized
INFO - 2023-09-03 06:49:47 --> URI Class Initialized
INFO - 2023-09-03 06:49:47 --> Router Class Initialized
INFO - 2023-09-03 06:49:47 --> Output Class Initialized
INFO - 2023-09-03 06:49:47 --> Security Class Initialized
DEBUG - 2023-09-03 06:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:49:47 --> Input Class Initialized
INFO - 2023-09-03 06:49:47 --> Language Class Initialized
INFO - 2023-09-03 06:49:47 --> Loader Class Initialized
INFO - 2023-09-03 06:49:47 --> Helper loaded: url_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: file_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: html_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: text_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: form_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: security_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:49:47 --> Database Driver Class Initialized
INFO - 2023-09-03 06:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:49:47 --> Parser Class Initialized
INFO - 2023-09-03 06:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:49:47 --> Pagination Class Initialized
INFO - 2023-09-03 06:49:47 --> Form Validation Class Initialized
INFO - 2023-09-03 06:49:47 --> Controller Class Initialized
INFO - 2023-09-03 06:49:47 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:47 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:47 --> Model Class Initialized
INFO - 2023-09-03 06:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-03 06:49:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:49:47 --> Model Class Initialized
INFO - 2023-09-03 06:49:47 --> Model Class Initialized
INFO - 2023-09-03 06:49:47 --> Model Class Initialized
INFO - 2023-09-03 06:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:49:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:49:47 --> Final output sent to browser
DEBUG - 2023-09-03 06:49:47 --> Total execution time: 0.0724
ERROR - 2023-09-03 06:49:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:49:47 --> Config Class Initialized
INFO - 2023-09-03 06:49:47 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:49:47 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:49:47 --> Utf8 Class Initialized
INFO - 2023-09-03 06:49:47 --> URI Class Initialized
INFO - 2023-09-03 06:49:47 --> Router Class Initialized
INFO - 2023-09-03 06:49:47 --> Output Class Initialized
INFO - 2023-09-03 06:49:47 --> Security Class Initialized
DEBUG - 2023-09-03 06:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:49:47 --> Input Class Initialized
INFO - 2023-09-03 06:49:47 --> Language Class Initialized
INFO - 2023-09-03 06:49:47 --> Loader Class Initialized
INFO - 2023-09-03 06:49:47 --> Helper loaded: url_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: file_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: html_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: text_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: form_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: security_helper
INFO - 2023-09-03 06:49:47 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:49:47 --> Database Driver Class Initialized
INFO - 2023-09-03 06:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:49:47 --> Parser Class Initialized
INFO - 2023-09-03 06:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:49:47 --> Pagination Class Initialized
INFO - 2023-09-03 06:49:47 --> Form Validation Class Initialized
INFO - 2023-09-03 06:49:47 --> Controller Class Initialized
INFO - 2023-09-03 06:49:47 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:47 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:47 --> Model Class Initialized
INFO - 2023-09-03 06:49:47 --> Final output sent to browser
DEBUG - 2023-09-03 06:49:47 --> Total execution time: 0.0198
ERROR - 2023-09-03 06:49:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:49:58 --> Config Class Initialized
INFO - 2023-09-03 06:49:58 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:49:58 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:49:58 --> Utf8 Class Initialized
INFO - 2023-09-03 06:49:58 --> URI Class Initialized
INFO - 2023-09-03 06:49:58 --> Router Class Initialized
INFO - 2023-09-03 06:49:58 --> Output Class Initialized
INFO - 2023-09-03 06:49:58 --> Security Class Initialized
DEBUG - 2023-09-03 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:49:58 --> Input Class Initialized
INFO - 2023-09-03 06:49:58 --> Language Class Initialized
INFO - 2023-09-03 06:49:58 --> Loader Class Initialized
INFO - 2023-09-03 06:49:58 --> Helper loaded: url_helper
INFO - 2023-09-03 06:49:58 --> Helper loaded: file_helper
INFO - 2023-09-03 06:49:58 --> Helper loaded: html_helper
INFO - 2023-09-03 06:49:58 --> Helper loaded: text_helper
INFO - 2023-09-03 06:49:58 --> Helper loaded: form_helper
INFO - 2023-09-03 06:49:58 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:49:58 --> Helper loaded: security_helper
INFO - 2023-09-03 06:49:58 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:49:58 --> Database Driver Class Initialized
INFO - 2023-09-03 06:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:49:58 --> Parser Class Initialized
INFO - 2023-09-03 06:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:49:58 --> Pagination Class Initialized
INFO - 2023-09-03 06:49:58 --> Form Validation Class Initialized
INFO - 2023-09-03 06:49:58 --> Controller Class Initialized
DEBUG - 2023-09-03 06:49:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:58 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:58 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:58 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:58 --> Model Class Initialized
INFO - 2023-09-03 06:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-03 06:49:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:49:58 --> Model Class Initialized
INFO - 2023-09-03 06:49:58 --> Model Class Initialized
INFO - 2023-09-03 06:49:58 --> Model Class Initialized
INFO - 2023-09-03 06:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:49:59 --> Final output sent to browser
DEBUG - 2023-09-03 06:49:59 --> Total execution time: 0.1391
ERROR - 2023-09-03 06:49:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:49:59 --> Config Class Initialized
INFO - 2023-09-03 06:49:59 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:49:59 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:49:59 --> Utf8 Class Initialized
INFO - 2023-09-03 06:49:59 --> URI Class Initialized
INFO - 2023-09-03 06:49:59 --> Router Class Initialized
INFO - 2023-09-03 06:49:59 --> Output Class Initialized
INFO - 2023-09-03 06:49:59 --> Security Class Initialized
DEBUG - 2023-09-03 06:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:49:59 --> Input Class Initialized
INFO - 2023-09-03 06:49:59 --> Language Class Initialized
INFO - 2023-09-03 06:49:59 --> Loader Class Initialized
INFO - 2023-09-03 06:49:59 --> Helper loaded: url_helper
INFO - 2023-09-03 06:49:59 --> Helper loaded: file_helper
INFO - 2023-09-03 06:49:59 --> Helper loaded: html_helper
INFO - 2023-09-03 06:49:59 --> Helper loaded: text_helper
INFO - 2023-09-03 06:49:59 --> Helper loaded: form_helper
INFO - 2023-09-03 06:49:59 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:49:59 --> Helper loaded: security_helper
INFO - 2023-09-03 06:49:59 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:49:59 --> Database Driver Class Initialized
INFO - 2023-09-03 06:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:49:59 --> Parser Class Initialized
INFO - 2023-09-03 06:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:49:59 --> Pagination Class Initialized
INFO - 2023-09-03 06:49:59 --> Form Validation Class Initialized
INFO - 2023-09-03 06:49:59 --> Controller Class Initialized
DEBUG - 2023-09-03 06:49:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:59 --> Model Class Initialized
DEBUG - 2023-09-03 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:49:59 --> Model Class Initialized
INFO - 2023-09-03 06:49:59 --> Final output sent to browser
DEBUG - 2023-09-03 06:49:59 --> Total execution time: 0.0376
ERROR - 2023-09-03 06:50:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:50:02 --> Config Class Initialized
INFO - 2023-09-03 06:50:02 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:50:02 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:50:02 --> Utf8 Class Initialized
INFO - 2023-09-03 06:50:02 --> URI Class Initialized
INFO - 2023-09-03 06:50:02 --> Router Class Initialized
INFO - 2023-09-03 06:50:02 --> Output Class Initialized
INFO - 2023-09-03 06:50:02 --> Security Class Initialized
DEBUG - 2023-09-03 06:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:50:02 --> Input Class Initialized
INFO - 2023-09-03 06:50:02 --> Language Class Initialized
INFO - 2023-09-03 06:50:02 --> Loader Class Initialized
INFO - 2023-09-03 06:50:02 --> Helper loaded: url_helper
INFO - 2023-09-03 06:50:02 --> Helper loaded: file_helper
INFO - 2023-09-03 06:50:02 --> Helper loaded: html_helper
INFO - 2023-09-03 06:50:02 --> Helper loaded: text_helper
INFO - 2023-09-03 06:50:02 --> Helper loaded: form_helper
INFO - 2023-09-03 06:50:02 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:50:02 --> Helper loaded: security_helper
INFO - 2023-09-03 06:50:02 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:50:02 --> Database Driver Class Initialized
INFO - 2023-09-03 06:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:50:02 --> Parser Class Initialized
INFO - 2023-09-03 06:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:50:02 --> Pagination Class Initialized
INFO - 2023-09-03 06:50:02 --> Form Validation Class Initialized
INFO - 2023-09-03 06:50:02 --> Controller Class Initialized
DEBUG - 2023-09-03 06:50:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:02 --> Model Class Initialized
DEBUG - 2023-09-03 06:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:02 --> Model Class Initialized
INFO - 2023-09-03 06:50:02 --> Final output sent to browser
DEBUG - 2023-09-03 06:50:02 --> Total execution time: 0.1521
ERROR - 2023-09-03 06:50:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:50:25 --> Config Class Initialized
INFO - 2023-09-03 06:50:25 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:50:25 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:50:25 --> Utf8 Class Initialized
INFO - 2023-09-03 06:50:25 --> URI Class Initialized
INFO - 2023-09-03 06:50:25 --> Router Class Initialized
INFO - 2023-09-03 06:50:25 --> Output Class Initialized
INFO - 2023-09-03 06:50:25 --> Security Class Initialized
DEBUG - 2023-09-03 06:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:50:25 --> Input Class Initialized
INFO - 2023-09-03 06:50:25 --> Language Class Initialized
INFO - 2023-09-03 06:50:25 --> Loader Class Initialized
INFO - 2023-09-03 06:50:25 --> Helper loaded: url_helper
INFO - 2023-09-03 06:50:25 --> Helper loaded: file_helper
INFO - 2023-09-03 06:50:25 --> Helper loaded: html_helper
INFO - 2023-09-03 06:50:25 --> Helper loaded: text_helper
INFO - 2023-09-03 06:50:25 --> Helper loaded: form_helper
INFO - 2023-09-03 06:50:25 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:50:25 --> Helper loaded: security_helper
INFO - 2023-09-03 06:50:25 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:50:25 --> Database Driver Class Initialized
INFO - 2023-09-03 06:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:50:25 --> Parser Class Initialized
INFO - 2023-09-03 06:50:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:50:25 --> Pagination Class Initialized
INFO - 2023-09-03 06:50:25 --> Form Validation Class Initialized
INFO - 2023-09-03 06:50:25 --> Controller Class Initialized
DEBUG - 2023-09-03 06:50:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:50:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:25 --> Model Class Initialized
DEBUG - 2023-09-03 06:50:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:25 --> Model Class Initialized
INFO - 2023-09-03 06:50:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-09-03 06:50:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:50:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:50:25 --> Model Class Initialized
INFO - 2023-09-03 06:50:25 --> Model Class Initialized
INFO - 2023-09-03 06:50:25 --> Model Class Initialized
INFO - 2023-09-03 06:50:25 --> Model Class Initialized
INFO - 2023-09-03 06:50:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:50:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:50:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:50:25 --> Final output sent to browser
DEBUG - 2023-09-03 06:50:25 --> Total execution time: 0.1588
ERROR - 2023-09-03 06:50:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:50:37 --> Config Class Initialized
INFO - 2023-09-03 06:50:37 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:50:37 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:50:37 --> Utf8 Class Initialized
INFO - 2023-09-03 06:50:37 --> URI Class Initialized
DEBUG - 2023-09-03 06:50:37 --> No URI present. Default controller set.
INFO - 2023-09-03 06:50:37 --> Router Class Initialized
INFO - 2023-09-03 06:50:37 --> Output Class Initialized
INFO - 2023-09-03 06:50:37 --> Security Class Initialized
DEBUG - 2023-09-03 06:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:50:37 --> Input Class Initialized
INFO - 2023-09-03 06:50:37 --> Language Class Initialized
INFO - 2023-09-03 06:50:37 --> Loader Class Initialized
INFO - 2023-09-03 06:50:37 --> Helper loaded: url_helper
INFO - 2023-09-03 06:50:37 --> Helper loaded: file_helper
INFO - 2023-09-03 06:50:37 --> Helper loaded: html_helper
INFO - 2023-09-03 06:50:37 --> Helper loaded: text_helper
INFO - 2023-09-03 06:50:37 --> Helper loaded: form_helper
INFO - 2023-09-03 06:50:37 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:50:37 --> Helper loaded: security_helper
INFO - 2023-09-03 06:50:37 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:50:37 --> Database Driver Class Initialized
INFO - 2023-09-03 06:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:50:37 --> Parser Class Initialized
INFO - 2023-09-03 06:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:50:37 --> Pagination Class Initialized
INFO - 2023-09-03 06:50:37 --> Form Validation Class Initialized
INFO - 2023-09-03 06:50:37 --> Controller Class Initialized
INFO - 2023-09-03 06:50:37 --> Model Class Initialized
DEBUG - 2023-09-03 06:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:37 --> Model Class Initialized
DEBUG - 2023-09-03 06:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:37 --> Model Class Initialized
INFO - 2023-09-03 06:50:37 --> Model Class Initialized
INFO - 2023-09-03 06:50:37 --> Model Class Initialized
INFO - 2023-09-03 06:50:37 --> Model Class Initialized
DEBUG - 2023-09-03 06:50:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:37 --> Model Class Initialized
INFO - 2023-09-03 06:50:37 --> Model Class Initialized
INFO - 2023-09-03 06:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 06:50:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:50:37 --> Model Class Initialized
INFO - 2023-09-03 06:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:50:37 --> Final output sent to browser
DEBUG - 2023-09-03 06:50:37 --> Total execution time: 0.0896
ERROR - 2023-09-03 06:50:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:50:44 --> Config Class Initialized
INFO - 2023-09-03 06:50:44 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:50:44 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:50:44 --> Utf8 Class Initialized
INFO - 2023-09-03 06:50:44 --> URI Class Initialized
INFO - 2023-09-03 06:50:44 --> Router Class Initialized
INFO - 2023-09-03 06:50:44 --> Output Class Initialized
INFO - 2023-09-03 06:50:44 --> Security Class Initialized
DEBUG - 2023-09-03 06:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:50:44 --> Input Class Initialized
INFO - 2023-09-03 06:50:44 --> Language Class Initialized
INFO - 2023-09-03 06:50:44 --> Loader Class Initialized
INFO - 2023-09-03 06:50:44 --> Helper loaded: url_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: file_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: html_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: text_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: form_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: security_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:50:44 --> Database Driver Class Initialized
INFO - 2023-09-03 06:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:50:44 --> Parser Class Initialized
INFO - 2023-09-03 06:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:50:44 --> Pagination Class Initialized
INFO - 2023-09-03 06:50:44 --> Form Validation Class Initialized
INFO - 2023-09-03 06:50:44 --> Controller Class Initialized
INFO - 2023-09-03 06:50:44 --> Model Class Initialized
DEBUG - 2023-09-03 06:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:44 --> Final output sent to browser
DEBUG - 2023-09-03 06:50:44 --> Total execution time: 0.0162
ERROR - 2023-09-03 06:50:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:50:44 --> Config Class Initialized
INFO - 2023-09-03 06:50:44 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:50:44 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:50:44 --> Utf8 Class Initialized
INFO - 2023-09-03 06:50:44 --> URI Class Initialized
INFO - 2023-09-03 06:50:44 --> Router Class Initialized
INFO - 2023-09-03 06:50:44 --> Output Class Initialized
INFO - 2023-09-03 06:50:44 --> Security Class Initialized
DEBUG - 2023-09-03 06:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:50:44 --> Input Class Initialized
INFO - 2023-09-03 06:50:44 --> Language Class Initialized
INFO - 2023-09-03 06:50:44 --> Loader Class Initialized
INFO - 2023-09-03 06:50:44 --> Helper loaded: url_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: file_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: html_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: text_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: form_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: security_helper
INFO - 2023-09-03 06:50:44 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:50:44 --> Database Driver Class Initialized
INFO - 2023-09-03 06:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:50:44 --> Parser Class Initialized
INFO - 2023-09-03 06:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:50:44 --> Pagination Class Initialized
INFO - 2023-09-03 06:50:44 --> Form Validation Class Initialized
INFO - 2023-09-03 06:50:44 --> Controller Class Initialized
INFO - 2023-09-03 06:50:44 --> Model Class Initialized
DEBUG - 2023-09-03 06:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 06:50:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:50:44 --> Model Class Initialized
INFO - 2023-09-03 06:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:50:44 --> Final output sent to browser
DEBUG - 2023-09-03 06:50:44 --> Total execution time: 0.0273
ERROR - 2023-09-03 06:51:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:51:09 --> Config Class Initialized
INFO - 2023-09-03 06:51:09 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:51:09 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:51:09 --> Utf8 Class Initialized
INFO - 2023-09-03 06:51:09 --> URI Class Initialized
INFO - 2023-09-03 06:51:09 --> Router Class Initialized
INFO - 2023-09-03 06:51:09 --> Output Class Initialized
INFO - 2023-09-03 06:51:09 --> Security Class Initialized
DEBUG - 2023-09-03 06:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:51:09 --> Input Class Initialized
INFO - 2023-09-03 06:51:09 --> Language Class Initialized
INFO - 2023-09-03 06:51:09 --> Loader Class Initialized
INFO - 2023-09-03 06:51:09 --> Helper loaded: url_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: file_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: html_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: text_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: form_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: security_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:51:09 --> Database Driver Class Initialized
INFO - 2023-09-03 06:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:51:09 --> Parser Class Initialized
INFO - 2023-09-03 06:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:51:09 --> Pagination Class Initialized
INFO - 2023-09-03 06:51:09 --> Form Validation Class Initialized
INFO - 2023-09-03 06:51:09 --> Controller Class Initialized
INFO - 2023-09-03 06:51:09 --> Model Class Initialized
DEBUG - 2023-09-03 06:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:09 --> Model Class Initialized
INFO - 2023-09-03 06:51:09 --> Final output sent to browser
DEBUG - 2023-09-03 06:51:09 --> Total execution time: 0.0239
ERROR - 2023-09-03 06:51:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:51:09 --> Config Class Initialized
INFO - 2023-09-03 06:51:09 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:51:09 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:51:09 --> Utf8 Class Initialized
INFO - 2023-09-03 06:51:09 --> URI Class Initialized
INFO - 2023-09-03 06:51:09 --> Router Class Initialized
INFO - 2023-09-03 06:51:09 --> Output Class Initialized
INFO - 2023-09-03 06:51:09 --> Security Class Initialized
DEBUG - 2023-09-03 06:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:51:09 --> Input Class Initialized
INFO - 2023-09-03 06:51:09 --> Language Class Initialized
INFO - 2023-09-03 06:51:09 --> Loader Class Initialized
INFO - 2023-09-03 06:51:09 --> Helper loaded: url_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: file_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: html_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: text_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: form_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: security_helper
INFO - 2023-09-03 06:51:09 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:51:09 --> Database Driver Class Initialized
INFO - 2023-09-03 06:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:51:09 --> Parser Class Initialized
INFO - 2023-09-03 06:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:51:09 --> Pagination Class Initialized
INFO - 2023-09-03 06:51:09 --> Form Validation Class Initialized
INFO - 2023-09-03 06:51:09 --> Controller Class Initialized
INFO - 2023-09-03 06:51:09 --> Model Class Initialized
DEBUG - 2023-09-03 06:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 06:51:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:51:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:51:09 --> Model Class Initialized
INFO - 2023-09-03 06:51:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:51:09 --> Final output sent to browser
DEBUG - 2023-09-03 06:51:09 --> Total execution time: 0.0290
ERROR - 2023-09-03 06:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:51:28 --> Config Class Initialized
INFO - 2023-09-03 06:51:28 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:51:28 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:51:28 --> Utf8 Class Initialized
INFO - 2023-09-03 06:51:28 --> URI Class Initialized
INFO - 2023-09-03 06:51:28 --> Router Class Initialized
INFO - 2023-09-03 06:51:28 --> Output Class Initialized
INFO - 2023-09-03 06:51:28 --> Security Class Initialized
DEBUG - 2023-09-03 06:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:51:28 --> Input Class Initialized
INFO - 2023-09-03 06:51:28 --> Language Class Initialized
INFO - 2023-09-03 06:51:28 --> Loader Class Initialized
INFO - 2023-09-03 06:51:28 --> Helper loaded: url_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: file_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: html_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: text_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: form_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: security_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:51:28 --> Database Driver Class Initialized
INFO - 2023-09-03 06:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:51:28 --> Parser Class Initialized
INFO - 2023-09-03 06:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:51:28 --> Pagination Class Initialized
INFO - 2023-09-03 06:51:28 --> Form Validation Class Initialized
INFO - 2023-09-03 06:51:28 --> Controller Class Initialized
DEBUG - 2023-09-03 06:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:28 --> Model Class Initialized
DEBUG - 2023-09-03 06:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:28 --> Model Class Initialized
DEBUG - 2023-09-03 06:51:28 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:28 --> Model Class Initialized
INFO - 2023-09-03 06:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-03 06:51:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:51:28 --> Model Class Initialized
INFO - 2023-09-03 06:51:28 --> Model Class Initialized
INFO - 2023-09-03 06:51:28 --> Model Class Initialized
INFO - 2023-09-03 06:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:51:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:51:28 --> Final output sent to browser
DEBUG - 2023-09-03 06:51:28 --> Total execution time: 0.1455
ERROR - 2023-09-03 06:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:51:28 --> Config Class Initialized
INFO - 2023-09-03 06:51:28 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:51:28 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:51:28 --> Utf8 Class Initialized
INFO - 2023-09-03 06:51:28 --> URI Class Initialized
INFO - 2023-09-03 06:51:28 --> Router Class Initialized
INFO - 2023-09-03 06:51:28 --> Output Class Initialized
INFO - 2023-09-03 06:51:28 --> Security Class Initialized
DEBUG - 2023-09-03 06:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:51:28 --> Input Class Initialized
INFO - 2023-09-03 06:51:28 --> Language Class Initialized
INFO - 2023-09-03 06:51:28 --> Loader Class Initialized
INFO - 2023-09-03 06:51:28 --> Helper loaded: url_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: file_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: html_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: text_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: form_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: security_helper
INFO - 2023-09-03 06:51:28 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:51:28 --> Database Driver Class Initialized
INFO - 2023-09-03 06:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:51:28 --> Parser Class Initialized
INFO - 2023-09-03 06:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:51:28 --> Pagination Class Initialized
INFO - 2023-09-03 06:51:28 --> Form Validation Class Initialized
INFO - 2023-09-03 06:51:28 --> Controller Class Initialized
DEBUG - 2023-09-03 06:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:28 --> Model Class Initialized
DEBUG - 2023-09-03 06:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:28 --> Model Class Initialized
INFO - 2023-09-03 06:51:28 --> Final output sent to browser
DEBUG - 2023-09-03 06:51:28 --> Total execution time: 0.0304
ERROR - 2023-09-03 06:51:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:51:43 --> Config Class Initialized
INFO - 2023-09-03 06:51:43 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:51:43 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:51:43 --> Utf8 Class Initialized
INFO - 2023-09-03 06:51:43 --> URI Class Initialized
INFO - 2023-09-03 06:51:43 --> Router Class Initialized
INFO - 2023-09-03 06:51:43 --> Output Class Initialized
INFO - 2023-09-03 06:51:43 --> Security Class Initialized
DEBUG - 2023-09-03 06:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:51:43 --> Input Class Initialized
INFO - 2023-09-03 06:51:43 --> Language Class Initialized
INFO - 2023-09-03 06:51:43 --> Loader Class Initialized
INFO - 2023-09-03 06:51:43 --> Helper loaded: url_helper
INFO - 2023-09-03 06:51:43 --> Helper loaded: file_helper
INFO - 2023-09-03 06:51:43 --> Helper loaded: html_helper
INFO - 2023-09-03 06:51:43 --> Helper loaded: text_helper
INFO - 2023-09-03 06:51:43 --> Helper loaded: form_helper
INFO - 2023-09-03 06:51:43 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:51:43 --> Helper loaded: security_helper
INFO - 2023-09-03 06:51:43 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:51:43 --> Database Driver Class Initialized
INFO - 2023-09-03 06:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:51:43 --> Parser Class Initialized
INFO - 2023-09-03 06:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:51:43 --> Pagination Class Initialized
INFO - 2023-09-03 06:51:43 --> Form Validation Class Initialized
INFO - 2023-09-03 06:51:43 --> Controller Class Initialized
DEBUG - 2023-09-03 06:51:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:43 --> Model Class Initialized
DEBUG - 2023-09-03 06:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:51:43 --> Model Class Initialized
INFO - 2023-09-03 06:51:43 --> Final output sent to browser
DEBUG - 2023-09-03 06:51:43 --> Total execution time: 0.1752
ERROR - 2023-09-03 06:52:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:52:01 --> Config Class Initialized
INFO - 2023-09-03 06:52:01 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:52:01 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:52:01 --> Utf8 Class Initialized
INFO - 2023-09-03 06:52:01 --> URI Class Initialized
INFO - 2023-09-03 06:52:01 --> Router Class Initialized
INFO - 2023-09-03 06:52:01 --> Output Class Initialized
INFO - 2023-09-03 06:52:01 --> Security Class Initialized
DEBUG - 2023-09-03 06:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:52:01 --> Input Class Initialized
INFO - 2023-09-03 06:52:01 --> Language Class Initialized
INFO - 2023-09-03 06:52:01 --> Loader Class Initialized
INFO - 2023-09-03 06:52:01 --> Helper loaded: url_helper
INFO - 2023-09-03 06:52:01 --> Helper loaded: file_helper
INFO - 2023-09-03 06:52:01 --> Helper loaded: html_helper
INFO - 2023-09-03 06:52:01 --> Helper loaded: text_helper
INFO - 2023-09-03 06:52:01 --> Helper loaded: form_helper
INFO - 2023-09-03 06:52:01 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:52:01 --> Helper loaded: security_helper
INFO - 2023-09-03 06:52:01 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:52:01 --> Database Driver Class Initialized
INFO - 2023-09-03 06:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:52:01 --> Parser Class Initialized
INFO - 2023-09-03 06:52:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:52:01 --> Pagination Class Initialized
INFO - 2023-09-03 06:52:01 --> Form Validation Class Initialized
INFO - 2023-09-03 06:52:01 --> Controller Class Initialized
DEBUG - 2023-09-03 06:52:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:52:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:01 --> Model Class Initialized
DEBUG - 2023-09-03 06:52:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:01 --> Model Class Initialized
INFO - 2023-09-03 06:52:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-09-03 06:52:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:52:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:52:01 --> Model Class Initialized
INFO - 2023-09-03 06:52:01 --> Model Class Initialized
INFO - 2023-09-03 06:52:01 --> Model Class Initialized
INFO - 2023-09-03 06:52:01 --> Model Class Initialized
INFO - 2023-09-03 06:52:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:52:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:52:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:52:01 --> Final output sent to browser
DEBUG - 2023-09-03 06:52:01 --> Total execution time: 0.1658
ERROR - 2023-09-03 06:52:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:52:12 --> Config Class Initialized
INFO - 2023-09-03 06:52:12 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:52:12 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:52:12 --> Utf8 Class Initialized
INFO - 2023-09-03 06:52:12 --> URI Class Initialized
INFO - 2023-09-03 06:52:12 --> Router Class Initialized
INFO - 2023-09-03 06:52:12 --> Output Class Initialized
INFO - 2023-09-03 06:52:12 --> Security Class Initialized
DEBUG - 2023-09-03 06:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:52:12 --> Input Class Initialized
INFO - 2023-09-03 06:52:12 --> Language Class Initialized
INFO - 2023-09-03 06:52:12 --> Loader Class Initialized
INFO - 2023-09-03 06:52:12 --> Helper loaded: url_helper
INFO - 2023-09-03 06:52:12 --> Helper loaded: file_helper
INFO - 2023-09-03 06:52:12 --> Helper loaded: html_helper
INFO - 2023-09-03 06:52:12 --> Helper loaded: text_helper
INFO - 2023-09-03 06:52:12 --> Helper loaded: form_helper
INFO - 2023-09-03 06:52:12 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:52:12 --> Helper loaded: security_helper
INFO - 2023-09-03 06:52:12 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:52:12 --> Database Driver Class Initialized
INFO - 2023-09-03 06:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:52:12 --> Parser Class Initialized
INFO - 2023-09-03 06:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:52:12 --> Pagination Class Initialized
INFO - 2023-09-03 06:52:12 --> Form Validation Class Initialized
INFO - 2023-09-03 06:52:12 --> Controller Class Initialized
DEBUG - 2023-09-03 06:52:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:12 --> Model Class Initialized
DEBUG - 2023-09-03 06:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:12 --> Model Class Initialized
DEBUG - 2023-09-03 06:52:12 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:12 --> Model Class Initialized
INFO - 2023-09-03 06:52:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-03 06:52:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 06:52:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 06:52:12 --> Model Class Initialized
INFO - 2023-09-03 06:52:12 --> Model Class Initialized
INFO - 2023-09-03 06:52:12 --> Model Class Initialized
INFO - 2023-09-03 06:52:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 06:52:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 06:52:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 06:52:13 --> Final output sent to browser
DEBUG - 2023-09-03 06:52:13 --> Total execution time: 0.1384
ERROR - 2023-09-03 06:52:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:52:13 --> Config Class Initialized
INFO - 2023-09-03 06:52:13 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:52:13 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:52:13 --> Utf8 Class Initialized
INFO - 2023-09-03 06:52:13 --> URI Class Initialized
INFO - 2023-09-03 06:52:13 --> Router Class Initialized
INFO - 2023-09-03 06:52:13 --> Output Class Initialized
INFO - 2023-09-03 06:52:13 --> Security Class Initialized
DEBUG - 2023-09-03 06:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:52:13 --> Input Class Initialized
INFO - 2023-09-03 06:52:13 --> Language Class Initialized
INFO - 2023-09-03 06:52:13 --> Loader Class Initialized
INFO - 2023-09-03 06:52:13 --> Helper loaded: url_helper
INFO - 2023-09-03 06:52:13 --> Helper loaded: file_helper
INFO - 2023-09-03 06:52:13 --> Helper loaded: html_helper
INFO - 2023-09-03 06:52:13 --> Helper loaded: text_helper
INFO - 2023-09-03 06:52:13 --> Helper loaded: form_helper
INFO - 2023-09-03 06:52:13 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:52:13 --> Helper loaded: security_helper
INFO - 2023-09-03 06:52:13 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:52:13 --> Database Driver Class Initialized
INFO - 2023-09-03 06:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:52:13 --> Parser Class Initialized
INFO - 2023-09-03 06:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:52:13 --> Pagination Class Initialized
INFO - 2023-09-03 06:52:13 --> Form Validation Class Initialized
INFO - 2023-09-03 06:52:13 --> Controller Class Initialized
DEBUG - 2023-09-03 06:52:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:52:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:13 --> Model Class Initialized
DEBUG - 2023-09-03 06:52:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:13 --> Model Class Initialized
INFO - 2023-09-03 06:52:13 --> Final output sent to browser
DEBUG - 2023-09-03 06:52:13 --> Total execution time: 0.0302
ERROR - 2023-09-03 06:52:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 06:52:19 --> Config Class Initialized
INFO - 2023-09-03 06:52:19 --> Hooks Class Initialized
DEBUG - 2023-09-03 06:52:19 --> UTF-8 Support Enabled
INFO - 2023-09-03 06:52:19 --> Utf8 Class Initialized
INFO - 2023-09-03 06:52:19 --> URI Class Initialized
INFO - 2023-09-03 06:52:19 --> Router Class Initialized
INFO - 2023-09-03 06:52:19 --> Output Class Initialized
INFO - 2023-09-03 06:52:19 --> Security Class Initialized
DEBUG - 2023-09-03 06:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 06:52:19 --> Input Class Initialized
INFO - 2023-09-03 06:52:19 --> Language Class Initialized
INFO - 2023-09-03 06:52:19 --> Loader Class Initialized
INFO - 2023-09-03 06:52:19 --> Helper loaded: url_helper
INFO - 2023-09-03 06:52:19 --> Helper loaded: file_helper
INFO - 2023-09-03 06:52:19 --> Helper loaded: html_helper
INFO - 2023-09-03 06:52:19 --> Helper loaded: text_helper
INFO - 2023-09-03 06:52:19 --> Helper loaded: form_helper
INFO - 2023-09-03 06:52:19 --> Helper loaded: lang_helper
INFO - 2023-09-03 06:52:19 --> Helper loaded: security_helper
INFO - 2023-09-03 06:52:19 --> Helper loaded: cookie_helper
INFO - 2023-09-03 06:52:19 --> Database Driver Class Initialized
INFO - 2023-09-03 06:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 06:52:19 --> Parser Class Initialized
INFO - 2023-09-03 06:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 06:52:19 --> Pagination Class Initialized
INFO - 2023-09-03 06:52:19 --> Form Validation Class Initialized
INFO - 2023-09-03 06:52:19 --> Controller Class Initialized
DEBUG - 2023-09-03 06:52:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 06:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:19 --> Model Class Initialized
DEBUG - 2023-09-03 06:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 06:52:19 --> Model Class Initialized
INFO - 2023-09-03 06:52:20 --> Final output sent to browser
DEBUG - 2023-09-03 06:52:20 --> Total execution time: 0.1551
ERROR - 2023-09-03 10:36:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 10:36:18 --> Config Class Initialized
INFO - 2023-09-03 10:36:18 --> Hooks Class Initialized
DEBUG - 2023-09-03 10:36:18 --> UTF-8 Support Enabled
INFO - 2023-09-03 10:36:18 --> Utf8 Class Initialized
INFO - 2023-09-03 10:36:18 --> URI Class Initialized
DEBUG - 2023-09-03 10:36:18 --> No URI present. Default controller set.
INFO - 2023-09-03 10:36:18 --> Router Class Initialized
INFO - 2023-09-03 10:36:18 --> Output Class Initialized
INFO - 2023-09-03 10:36:18 --> Security Class Initialized
DEBUG - 2023-09-03 10:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 10:36:18 --> Input Class Initialized
INFO - 2023-09-03 10:36:18 --> Language Class Initialized
INFO - 2023-09-03 10:36:18 --> Loader Class Initialized
INFO - 2023-09-03 10:36:18 --> Helper loaded: url_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: file_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: html_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: text_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: form_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: lang_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: security_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: cookie_helper
INFO - 2023-09-03 10:36:18 --> Database Driver Class Initialized
INFO - 2023-09-03 10:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 10:36:18 --> Parser Class Initialized
INFO - 2023-09-03 10:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 10:36:18 --> Pagination Class Initialized
INFO - 2023-09-03 10:36:18 --> Form Validation Class Initialized
INFO - 2023-09-03 10:36:18 --> Controller Class Initialized
INFO - 2023-09-03 10:36:18 --> Model Class Initialized
DEBUG - 2023-09-03 10:36:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 10:36:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 10:36:18 --> Config Class Initialized
INFO - 2023-09-03 10:36:18 --> Hooks Class Initialized
DEBUG - 2023-09-03 10:36:18 --> UTF-8 Support Enabled
INFO - 2023-09-03 10:36:18 --> Utf8 Class Initialized
INFO - 2023-09-03 10:36:18 --> URI Class Initialized
INFO - 2023-09-03 10:36:18 --> Router Class Initialized
INFO - 2023-09-03 10:36:18 --> Output Class Initialized
INFO - 2023-09-03 10:36:18 --> Security Class Initialized
DEBUG - 2023-09-03 10:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 10:36:18 --> Input Class Initialized
INFO - 2023-09-03 10:36:18 --> Language Class Initialized
INFO - 2023-09-03 10:36:18 --> Loader Class Initialized
INFO - 2023-09-03 10:36:18 --> Helper loaded: url_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: file_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: html_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: text_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: form_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: lang_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: security_helper
INFO - 2023-09-03 10:36:18 --> Helper loaded: cookie_helper
INFO - 2023-09-03 10:36:18 --> Database Driver Class Initialized
INFO - 2023-09-03 10:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 10:36:18 --> Parser Class Initialized
INFO - 2023-09-03 10:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 10:36:18 --> Pagination Class Initialized
INFO - 2023-09-03 10:36:18 --> Form Validation Class Initialized
INFO - 2023-09-03 10:36:18 --> Controller Class Initialized
INFO - 2023-09-03 10:36:18 --> Model Class Initialized
DEBUG - 2023-09-03 10:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 10:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 10:36:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 10:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 10:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 10:36:18 --> Model Class Initialized
INFO - 2023-09-03 10:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 10:36:18 --> Final output sent to browser
DEBUG - 2023-09-03 10:36:18 --> Total execution time: 0.0320
ERROR - 2023-09-03 11:28:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:37 --> Config Class Initialized
INFO - 2023-09-03 11:28:37 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:37 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:37 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:37 --> URI Class Initialized
DEBUG - 2023-09-03 11:28:37 --> No URI present. Default controller set.
INFO - 2023-09-03 11:28:37 --> Router Class Initialized
INFO - 2023-09-03 11:28:37 --> Output Class Initialized
INFO - 2023-09-03 11:28:37 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:37 --> Input Class Initialized
INFO - 2023-09-03 11:28:37 --> Language Class Initialized
INFO - 2023-09-03 11:28:37 --> Loader Class Initialized
INFO - 2023-09-03 11:28:37 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:37 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:37 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:37 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:37 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:37 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:37 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:37 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:37 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:37 --> Parser Class Initialized
INFO - 2023-09-03 11:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:37 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:37 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:37 --> Controller Class Initialized
INFO - 2023-09-03 11:28:37 --> Model Class Initialized
DEBUG - 2023-09-03 11:28:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 11:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:38 --> Config Class Initialized
INFO - 2023-09-03 11:28:38 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:38 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:38 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:38 --> URI Class Initialized
INFO - 2023-09-03 11:28:38 --> Router Class Initialized
INFO - 2023-09-03 11:28:38 --> Output Class Initialized
INFO - 2023-09-03 11:28:38 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:38 --> Input Class Initialized
INFO - 2023-09-03 11:28:38 --> Language Class Initialized
INFO - 2023-09-03 11:28:38 --> Loader Class Initialized
INFO - 2023-09-03 11:28:38 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:38 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:38 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:38 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:38 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:38 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:38 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:38 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:38 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:38 --> Parser Class Initialized
INFO - 2023-09-03 11:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:38 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:38 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:38 --> Controller Class Initialized
INFO - 2023-09-03 11:28:38 --> Model Class Initialized
DEBUG - 2023-09-03 11:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 11:28:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:28:38 --> Model Class Initialized
INFO - 2023-09-03 11:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:28:38 --> Final output sent to browser
DEBUG - 2023-09-03 11:28:38 --> Total execution time: 0.0303
ERROR - 2023-09-03 11:28:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:41 --> Config Class Initialized
INFO - 2023-09-03 11:28:41 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:41 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:41 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:41 --> URI Class Initialized
INFO - 2023-09-03 11:28:41 --> Router Class Initialized
INFO - 2023-09-03 11:28:41 --> Output Class Initialized
INFO - 2023-09-03 11:28:41 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:41 --> Input Class Initialized
INFO - 2023-09-03 11:28:41 --> Language Class Initialized
INFO - 2023-09-03 11:28:41 --> Loader Class Initialized
INFO - 2023-09-03 11:28:41 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:41 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:41 --> Parser Class Initialized
INFO - 2023-09-03 11:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:41 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:41 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:41 --> Controller Class Initialized
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
DEBUG - 2023-09-03 11:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
INFO - 2023-09-03 11:28:41 --> Final output sent to browser
DEBUG - 2023-09-03 11:28:41 --> Total execution time: 0.0184
ERROR - 2023-09-03 11:28:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:41 --> Config Class Initialized
INFO - 2023-09-03 11:28:41 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:41 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:41 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:41 --> URI Class Initialized
DEBUG - 2023-09-03 11:28:41 --> No URI present. Default controller set.
INFO - 2023-09-03 11:28:41 --> Router Class Initialized
INFO - 2023-09-03 11:28:41 --> Output Class Initialized
INFO - 2023-09-03 11:28:41 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:41 --> Input Class Initialized
INFO - 2023-09-03 11:28:41 --> Language Class Initialized
INFO - 2023-09-03 11:28:41 --> Loader Class Initialized
INFO - 2023-09-03 11:28:41 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:41 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:41 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:41 --> Parser Class Initialized
INFO - 2023-09-03 11:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:41 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:41 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:41 --> Controller Class Initialized
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
DEBUG - 2023-09-03 11:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
DEBUG - 2023-09-03 11:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
DEBUG - 2023-09-03 11:28:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
INFO - 2023-09-03 11:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:28:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:28:41 --> Model Class Initialized
INFO - 2023-09-03 11:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:28:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:28:41 --> Final output sent to browser
DEBUG - 2023-09-03 11:28:41 --> Total execution time: 0.1865
ERROR - 2023-09-03 11:28:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:42 --> Config Class Initialized
INFO - 2023-09-03 11:28:42 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:42 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:42 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:42 --> URI Class Initialized
INFO - 2023-09-03 11:28:42 --> Router Class Initialized
INFO - 2023-09-03 11:28:42 --> Output Class Initialized
INFO - 2023-09-03 11:28:42 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:42 --> Input Class Initialized
INFO - 2023-09-03 11:28:42 --> Language Class Initialized
INFO - 2023-09-03 11:28:42 --> Loader Class Initialized
INFO - 2023-09-03 11:28:42 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:42 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:42 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:42 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:42 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:42 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:42 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:42 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:42 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:42 --> Parser Class Initialized
INFO - 2023-09-03 11:28:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:42 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:42 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:42 --> Controller Class Initialized
DEBUG - 2023-09-03 11:28:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:28:42 --> Model Class Initialized
INFO - 2023-09-03 11:28:42 --> Final output sent to browser
DEBUG - 2023-09-03 11:28:42 --> Total execution time: 0.0137
ERROR - 2023-09-03 11:28:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:50 --> Config Class Initialized
INFO - 2023-09-03 11:28:50 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:50 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:50 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:50 --> URI Class Initialized
INFO - 2023-09-03 11:28:50 --> Router Class Initialized
INFO - 2023-09-03 11:28:50 --> Output Class Initialized
INFO - 2023-09-03 11:28:50 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:50 --> Input Class Initialized
INFO - 2023-09-03 11:28:50 --> Language Class Initialized
INFO - 2023-09-03 11:28:50 --> Loader Class Initialized
INFO - 2023-09-03 11:28:50 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:50 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:50 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:50 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:50 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:50 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:50 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:50 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:50 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:50 --> Parser Class Initialized
INFO - 2023-09-03 11:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:50 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:50 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:50 --> Controller Class Initialized
INFO - 2023-09-03 11:28:50 --> Model Class Initialized
INFO - 2023-09-03 11:28:50 --> Model Class Initialized
INFO - 2023-09-03 11:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-09-03 11:28:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:28:50 --> Model Class Initialized
INFO - 2023-09-03 11:28:50 --> Model Class Initialized
INFO - 2023-09-03 11:28:50 --> Model Class Initialized
INFO - 2023-09-03 11:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:28:50 --> Final output sent to browser
DEBUG - 2023-09-03 11:28:50 --> Total execution time: 0.1438
ERROR - 2023-09-03 11:28:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:51 --> Config Class Initialized
INFO - 2023-09-03 11:28:51 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:51 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:51 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:51 --> URI Class Initialized
INFO - 2023-09-03 11:28:51 --> Router Class Initialized
INFO - 2023-09-03 11:28:51 --> Output Class Initialized
INFO - 2023-09-03 11:28:51 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:51 --> Input Class Initialized
INFO - 2023-09-03 11:28:51 --> Language Class Initialized
INFO - 2023-09-03 11:28:51 --> Loader Class Initialized
INFO - 2023-09-03 11:28:51 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:51 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:51 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:51 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:51 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:51 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:51 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:51 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:51 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:51 --> Parser Class Initialized
INFO - 2023-09-03 11:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:51 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:51 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:51 --> Controller Class Initialized
INFO - 2023-09-03 11:28:51 --> Model Class Initialized
INFO - 2023-09-03 11:28:51 --> Model Class Initialized
INFO - 2023-09-03 11:28:51 --> Final output sent to browser
DEBUG - 2023-09-03 11:28:51 --> Total execution time: 0.0441
ERROR - 2023-09-03 11:28:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:57 --> Config Class Initialized
INFO - 2023-09-03 11:28:57 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:57 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:57 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:57 --> URI Class Initialized
INFO - 2023-09-03 11:28:57 --> Router Class Initialized
INFO - 2023-09-03 11:28:57 --> Output Class Initialized
INFO - 2023-09-03 11:28:57 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:57 --> Input Class Initialized
INFO - 2023-09-03 11:28:57 --> Language Class Initialized
INFO - 2023-09-03 11:28:57 --> Loader Class Initialized
INFO - 2023-09-03 11:28:57 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:57 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:57 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:57 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:57 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:57 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:57 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:57 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:57 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:57 --> Parser Class Initialized
INFO - 2023-09-03 11:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:57 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:57 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:57 --> Controller Class Initialized
INFO - 2023-09-03 11:28:57 --> Model Class Initialized
INFO - 2023-09-03 11:28:57 --> Model Class Initialized
INFO - 2023-09-03 11:28:58 --> Final output sent to browser
DEBUG - 2023-09-03 11:28:58 --> Total execution time: 0.0338
ERROR - 2023-09-03 11:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:58 --> Config Class Initialized
INFO - 2023-09-03 11:28:58 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:58 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:58 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:58 --> URI Class Initialized
INFO - 2023-09-03 11:28:58 --> Router Class Initialized
INFO - 2023-09-03 11:28:58 --> Output Class Initialized
INFO - 2023-09-03 11:28:58 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:58 --> Input Class Initialized
INFO - 2023-09-03 11:28:58 --> Language Class Initialized
INFO - 2023-09-03 11:28:58 --> Loader Class Initialized
INFO - 2023-09-03 11:28:58 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:58 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:58 --> Parser Class Initialized
INFO - 2023-09-03 11:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:58 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:58 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:58 --> Controller Class Initialized
INFO - 2023-09-03 11:28:58 --> Model Class Initialized
INFO - 2023-09-03 11:28:58 --> Model Class Initialized
INFO - 2023-09-03 11:28:58 --> Final output sent to browser
DEBUG - 2023-09-03 11:28:58 --> Total execution time: 0.0363
ERROR - 2023-09-03 11:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:28:58 --> Config Class Initialized
INFO - 2023-09-03 11:28:58 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:28:58 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:28:58 --> Utf8 Class Initialized
INFO - 2023-09-03 11:28:58 --> URI Class Initialized
INFO - 2023-09-03 11:28:58 --> Router Class Initialized
INFO - 2023-09-03 11:28:58 --> Output Class Initialized
INFO - 2023-09-03 11:28:58 --> Security Class Initialized
DEBUG - 2023-09-03 11:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:28:58 --> Input Class Initialized
INFO - 2023-09-03 11:28:58 --> Language Class Initialized
INFO - 2023-09-03 11:28:58 --> Loader Class Initialized
INFO - 2023-09-03 11:28:58 --> Helper loaded: url_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: file_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: html_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: text_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: form_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: security_helper
INFO - 2023-09-03 11:28:58 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:28:58 --> Database Driver Class Initialized
INFO - 2023-09-03 11:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:28:58 --> Parser Class Initialized
INFO - 2023-09-03 11:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:28:58 --> Pagination Class Initialized
INFO - 2023-09-03 11:28:58 --> Form Validation Class Initialized
INFO - 2023-09-03 11:28:58 --> Controller Class Initialized
INFO - 2023-09-03 11:28:58 --> Model Class Initialized
INFO - 2023-09-03 11:28:58 --> Model Class Initialized
INFO - 2023-09-03 11:28:58 --> Final output sent to browser
DEBUG - 2023-09-03 11:28:58 --> Total execution time: 0.0333
ERROR - 2023-09-03 11:29:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:29:07 --> Config Class Initialized
INFO - 2023-09-03 11:29:07 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:29:07 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:29:07 --> Utf8 Class Initialized
INFO - 2023-09-03 11:29:07 --> URI Class Initialized
INFO - 2023-09-03 11:29:07 --> Router Class Initialized
INFO - 2023-09-03 11:29:07 --> Output Class Initialized
INFO - 2023-09-03 11:29:07 --> Security Class Initialized
DEBUG - 2023-09-03 11:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:29:07 --> Input Class Initialized
INFO - 2023-09-03 11:29:07 --> Language Class Initialized
INFO - 2023-09-03 11:29:07 --> Loader Class Initialized
INFO - 2023-09-03 11:29:07 --> Helper loaded: url_helper
INFO - 2023-09-03 11:29:07 --> Helper loaded: file_helper
INFO - 2023-09-03 11:29:07 --> Helper loaded: html_helper
INFO - 2023-09-03 11:29:07 --> Helper loaded: text_helper
INFO - 2023-09-03 11:29:07 --> Helper loaded: form_helper
INFO - 2023-09-03 11:29:07 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:29:07 --> Helper loaded: security_helper
INFO - 2023-09-03 11:29:07 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:29:07 --> Database Driver Class Initialized
INFO - 2023-09-03 11:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:29:07 --> Parser Class Initialized
INFO - 2023-09-03 11:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:29:07 --> Pagination Class Initialized
INFO - 2023-09-03 11:29:07 --> Form Validation Class Initialized
INFO - 2023-09-03 11:29:07 --> Controller Class Initialized
INFO - 2023-09-03 11:29:07 --> Model Class Initialized
INFO - 2023-09-03 11:29:07 --> Model Class Initialized
INFO - 2023-09-03 11:29:07 --> Final output sent to browser
DEBUG - 2023-09-03 11:29:07 --> Total execution time: 0.0334
ERROR - 2023-09-03 11:29:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:29:36 --> Config Class Initialized
INFO - 2023-09-03 11:29:36 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:29:36 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:29:36 --> Utf8 Class Initialized
INFO - 2023-09-03 11:29:36 --> URI Class Initialized
INFO - 2023-09-03 11:29:36 --> Router Class Initialized
INFO - 2023-09-03 11:29:36 --> Output Class Initialized
INFO - 2023-09-03 11:29:36 --> Security Class Initialized
DEBUG - 2023-09-03 11:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:29:36 --> Input Class Initialized
INFO - 2023-09-03 11:29:36 --> Language Class Initialized
INFO - 2023-09-03 11:29:36 --> Loader Class Initialized
INFO - 2023-09-03 11:29:36 --> Helper loaded: url_helper
INFO - 2023-09-03 11:29:36 --> Helper loaded: file_helper
INFO - 2023-09-03 11:29:36 --> Helper loaded: html_helper
INFO - 2023-09-03 11:29:36 --> Helper loaded: text_helper
INFO - 2023-09-03 11:29:36 --> Helper loaded: form_helper
INFO - 2023-09-03 11:29:36 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:29:36 --> Helper loaded: security_helper
INFO - 2023-09-03 11:29:36 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:29:36 --> Database Driver Class Initialized
INFO - 2023-09-03 11:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:29:36 --> Parser Class Initialized
INFO - 2023-09-03 11:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:29:36 --> Pagination Class Initialized
INFO - 2023-09-03 11:29:36 --> Form Validation Class Initialized
INFO - 2023-09-03 11:29:36 --> Controller Class Initialized
INFO - 2023-09-03 11:29:36 --> Model Class Initialized
INFO - 2023-09-03 11:29:36 --> Model Class Initialized
INFO - 2023-09-03 11:29:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-09-03 11:29:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:29:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:29:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:29:36 --> Model Class Initialized
INFO - 2023-09-03 11:29:36 --> Model Class Initialized
INFO - 2023-09-03 11:29:36 --> Model Class Initialized
INFO - 2023-09-03 11:29:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:29:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:29:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:29:36 --> Final output sent to browser
DEBUG - 2023-09-03 11:29:36 --> Total execution time: 0.1471
ERROR - 2023-09-03 11:29:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:29:47 --> Config Class Initialized
INFO - 2023-09-03 11:29:47 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:29:47 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:29:47 --> Utf8 Class Initialized
INFO - 2023-09-03 11:29:47 --> URI Class Initialized
DEBUG - 2023-09-03 11:29:47 --> No URI present. Default controller set.
INFO - 2023-09-03 11:29:47 --> Router Class Initialized
INFO - 2023-09-03 11:29:47 --> Output Class Initialized
INFO - 2023-09-03 11:29:47 --> Security Class Initialized
DEBUG - 2023-09-03 11:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:29:47 --> Input Class Initialized
INFO - 2023-09-03 11:29:47 --> Language Class Initialized
INFO - 2023-09-03 11:29:47 --> Loader Class Initialized
INFO - 2023-09-03 11:29:47 --> Helper loaded: url_helper
INFO - 2023-09-03 11:29:47 --> Helper loaded: file_helper
INFO - 2023-09-03 11:29:47 --> Helper loaded: html_helper
INFO - 2023-09-03 11:29:47 --> Helper loaded: text_helper
INFO - 2023-09-03 11:29:47 --> Helper loaded: form_helper
INFO - 2023-09-03 11:29:47 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:29:47 --> Helper loaded: security_helper
INFO - 2023-09-03 11:29:47 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:29:47 --> Database Driver Class Initialized
INFO - 2023-09-03 11:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:29:47 --> Parser Class Initialized
INFO - 2023-09-03 11:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:29:47 --> Pagination Class Initialized
INFO - 2023-09-03 11:29:47 --> Form Validation Class Initialized
INFO - 2023-09-03 11:29:47 --> Controller Class Initialized
INFO - 2023-09-03 11:29:47 --> Model Class Initialized
DEBUG - 2023-09-03 11:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:29:47 --> Model Class Initialized
DEBUG - 2023-09-03 11:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:29:47 --> Model Class Initialized
INFO - 2023-09-03 11:29:47 --> Model Class Initialized
INFO - 2023-09-03 11:29:47 --> Model Class Initialized
INFO - 2023-09-03 11:29:47 --> Model Class Initialized
DEBUG - 2023-09-03 11:29:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:29:47 --> Model Class Initialized
INFO - 2023-09-03 11:29:47 --> Model Class Initialized
INFO - 2023-09-03 11:29:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:29:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:29:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:29:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:29:47 --> Model Class Initialized
INFO - 2023-09-03 11:29:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:29:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:29:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:29:47 --> Final output sent to browser
DEBUG - 2023-09-03 11:29:47 --> Total execution time: 0.1835
ERROR - 2023-09-03 11:30:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:30:01 --> Config Class Initialized
INFO - 2023-09-03 11:30:01 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:30:01 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:30:01 --> Utf8 Class Initialized
INFO - 2023-09-03 11:30:01 --> URI Class Initialized
DEBUG - 2023-09-03 11:30:01 --> No URI present. Default controller set.
INFO - 2023-09-03 11:30:01 --> Router Class Initialized
INFO - 2023-09-03 11:30:01 --> Output Class Initialized
INFO - 2023-09-03 11:30:01 --> Security Class Initialized
DEBUG - 2023-09-03 11:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:30:01 --> Input Class Initialized
INFO - 2023-09-03 11:30:01 --> Language Class Initialized
INFO - 2023-09-03 11:30:01 --> Loader Class Initialized
INFO - 2023-09-03 11:30:01 --> Helper loaded: url_helper
INFO - 2023-09-03 11:30:01 --> Helper loaded: file_helper
INFO - 2023-09-03 11:30:01 --> Helper loaded: html_helper
INFO - 2023-09-03 11:30:01 --> Helper loaded: text_helper
INFO - 2023-09-03 11:30:01 --> Helper loaded: form_helper
INFO - 2023-09-03 11:30:01 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:30:01 --> Helper loaded: security_helper
INFO - 2023-09-03 11:30:01 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:30:01 --> Database Driver Class Initialized
INFO - 2023-09-03 11:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:30:01 --> Parser Class Initialized
INFO - 2023-09-03 11:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:30:01 --> Pagination Class Initialized
INFO - 2023-09-03 11:30:01 --> Form Validation Class Initialized
INFO - 2023-09-03 11:30:01 --> Controller Class Initialized
INFO - 2023-09-03 11:30:01 --> Model Class Initialized
DEBUG - 2023-09-03 11:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:01 --> Model Class Initialized
DEBUG - 2023-09-03 11:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:01 --> Model Class Initialized
INFO - 2023-09-03 11:30:01 --> Model Class Initialized
INFO - 2023-09-03 11:30:01 --> Model Class Initialized
INFO - 2023-09-03 11:30:01 --> Model Class Initialized
DEBUG - 2023-09-03 11:30:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:01 --> Model Class Initialized
INFO - 2023-09-03 11:30:01 --> Model Class Initialized
INFO - 2023-09-03 11:30:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:30:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:30:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:30:01 --> Model Class Initialized
INFO - 2023-09-03 11:30:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:30:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:30:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:30:01 --> Final output sent to browser
DEBUG - 2023-09-03 11:30:01 --> Total execution time: 0.2032
ERROR - 2023-09-03 11:30:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:30:13 --> Config Class Initialized
INFO - 2023-09-03 11:30:13 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:30:13 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:30:13 --> Utf8 Class Initialized
INFO - 2023-09-03 11:30:13 --> URI Class Initialized
INFO - 2023-09-03 11:30:13 --> Router Class Initialized
INFO - 2023-09-03 11:30:13 --> Output Class Initialized
INFO - 2023-09-03 11:30:13 --> Security Class Initialized
DEBUG - 2023-09-03 11:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:30:13 --> Input Class Initialized
INFO - 2023-09-03 11:30:13 --> Language Class Initialized
INFO - 2023-09-03 11:30:13 --> Loader Class Initialized
INFO - 2023-09-03 11:30:13 --> Helper loaded: url_helper
INFO - 2023-09-03 11:30:13 --> Helper loaded: file_helper
INFO - 2023-09-03 11:30:13 --> Helper loaded: html_helper
INFO - 2023-09-03 11:30:13 --> Helper loaded: text_helper
INFO - 2023-09-03 11:30:13 --> Helper loaded: form_helper
INFO - 2023-09-03 11:30:13 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:30:13 --> Helper loaded: security_helper
INFO - 2023-09-03 11:30:13 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:30:13 --> Database Driver Class Initialized
INFO - 2023-09-03 11:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:30:13 --> Parser Class Initialized
INFO - 2023-09-03 11:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:30:13 --> Pagination Class Initialized
INFO - 2023-09-03 11:30:13 --> Form Validation Class Initialized
INFO - 2023-09-03 11:30:13 --> Controller Class Initialized
DEBUG - 2023-09-03 11:30:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:13 --> Model Class Initialized
INFO - 2023-09-03 11:30:13 --> Model Class Initialized
DEBUG - 2023-09-03 11:30:13 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:13 --> Model Class Initialized
INFO - 2023-09-03 11:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-09-03 11:30:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:30:13 --> Model Class Initialized
INFO - 2023-09-03 11:30:13 --> Model Class Initialized
INFO - 2023-09-03 11:30:13 --> Model Class Initialized
INFO - 2023-09-03 11:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:30:13 --> Final output sent to browser
DEBUG - 2023-09-03 11:30:13 --> Total execution time: 0.1338
ERROR - 2023-09-03 11:30:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:30:14 --> Config Class Initialized
INFO - 2023-09-03 11:30:14 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:30:14 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:30:14 --> Utf8 Class Initialized
INFO - 2023-09-03 11:30:14 --> URI Class Initialized
INFO - 2023-09-03 11:30:14 --> Router Class Initialized
INFO - 2023-09-03 11:30:14 --> Output Class Initialized
INFO - 2023-09-03 11:30:14 --> Security Class Initialized
DEBUG - 2023-09-03 11:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:30:14 --> Input Class Initialized
INFO - 2023-09-03 11:30:14 --> Language Class Initialized
INFO - 2023-09-03 11:30:14 --> Loader Class Initialized
INFO - 2023-09-03 11:30:14 --> Helper loaded: url_helper
INFO - 2023-09-03 11:30:14 --> Helper loaded: file_helper
INFO - 2023-09-03 11:30:14 --> Helper loaded: html_helper
INFO - 2023-09-03 11:30:14 --> Helper loaded: text_helper
INFO - 2023-09-03 11:30:14 --> Helper loaded: form_helper
INFO - 2023-09-03 11:30:14 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:30:14 --> Helper loaded: security_helper
INFO - 2023-09-03 11:30:14 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:30:14 --> Database Driver Class Initialized
INFO - 2023-09-03 11:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:30:14 --> Parser Class Initialized
INFO - 2023-09-03 11:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:30:14 --> Pagination Class Initialized
INFO - 2023-09-03 11:30:14 --> Form Validation Class Initialized
INFO - 2023-09-03 11:30:14 --> Controller Class Initialized
DEBUG - 2023-09-03 11:30:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:14 --> Model Class Initialized
INFO - 2023-09-03 11:30:14 --> Model Class Initialized
INFO - 2023-09-03 11:30:14 --> Final output sent to browser
DEBUG - 2023-09-03 11:30:14 --> Total execution time: 0.0245
ERROR - 2023-09-03 11:30:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:30:20 --> Config Class Initialized
INFO - 2023-09-03 11:30:20 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:30:20 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:30:20 --> Utf8 Class Initialized
INFO - 2023-09-03 11:30:20 --> URI Class Initialized
INFO - 2023-09-03 11:30:20 --> Router Class Initialized
INFO - 2023-09-03 11:30:20 --> Output Class Initialized
INFO - 2023-09-03 11:30:20 --> Security Class Initialized
DEBUG - 2023-09-03 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:30:20 --> Input Class Initialized
INFO - 2023-09-03 11:30:20 --> Language Class Initialized
INFO - 2023-09-03 11:30:20 --> Loader Class Initialized
INFO - 2023-09-03 11:30:20 --> Helper loaded: url_helper
INFO - 2023-09-03 11:30:20 --> Helper loaded: file_helper
INFO - 2023-09-03 11:30:20 --> Helper loaded: html_helper
INFO - 2023-09-03 11:30:20 --> Helper loaded: text_helper
INFO - 2023-09-03 11:30:20 --> Helper loaded: form_helper
INFO - 2023-09-03 11:30:20 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:30:20 --> Helper loaded: security_helper
INFO - 2023-09-03 11:30:20 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:30:20 --> Database Driver Class Initialized
INFO - 2023-09-03 11:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:30:20 --> Parser Class Initialized
INFO - 2023-09-03 11:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:30:20 --> Pagination Class Initialized
INFO - 2023-09-03 11:30:20 --> Form Validation Class Initialized
INFO - 2023-09-03 11:30:20 --> Controller Class Initialized
DEBUG - 2023-09-03 11:30:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:20 --> Model Class Initialized
INFO - 2023-09-03 11:30:20 --> Model Class Initialized
INFO - 2023-09-03 11:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr_change_password_form.php
DEBUG - 2023-09-03 11:30:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:30:20 --> Model Class Initialized
INFO - 2023-09-03 11:30:20 --> Model Class Initialized
INFO - 2023-09-03 11:30:20 --> Model Class Initialized
INFO - 2023-09-03 11:30:20 --> Model Class Initialized
INFO - 2023-09-03 11:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:30:20 --> Final output sent to browser
DEBUG - 2023-09-03 11:30:20 --> Total execution time: 0.1254
ERROR - 2023-09-03 11:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:30:31 --> Config Class Initialized
INFO - 2023-09-03 11:30:31 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:30:31 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:30:31 --> Utf8 Class Initialized
INFO - 2023-09-03 11:30:31 --> URI Class Initialized
INFO - 2023-09-03 11:30:31 --> Router Class Initialized
INFO - 2023-09-03 11:30:31 --> Output Class Initialized
INFO - 2023-09-03 11:30:31 --> Security Class Initialized
DEBUG - 2023-09-03 11:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:30:31 --> Input Class Initialized
INFO - 2023-09-03 11:30:31 --> Language Class Initialized
INFO - 2023-09-03 11:30:31 --> Loader Class Initialized
INFO - 2023-09-03 11:30:31 --> Helper loaded: url_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: file_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: html_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: text_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: form_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: security_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:30:31 --> Database Driver Class Initialized
INFO - 2023-09-03 11:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:30:31 --> Parser Class Initialized
INFO - 2023-09-03 11:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:30:31 --> Pagination Class Initialized
INFO - 2023-09-03 11:30:31 --> Form Validation Class Initialized
INFO - 2023-09-03 11:30:31 --> Controller Class Initialized
DEBUG - 2023-09-03 11:30:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
ERROR - 2023-09-03 11:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:30:31 --> Config Class Initialized
INFO - 2023-09-03 11:30:31 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:30:31 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:30:31 --> Utf8 Class Initialized
INFO - 2023-09-03 11:30:31 --> URI Class Initialized
INFO - 2023-09-03 11:30:31 --> Router Class Initialized
INFO - 2023-09-03 11:30:31 --> Output Class Initialized
INFO - 2023-09-03 11:30:31 --> Security Class Initialized
DEBUG - 2023-09-03 11:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:30:31 --> Input Class Initialized
INFO - 2023-09-03 11:30:31 --> Language Class Initialized
INFO - 2023-09-03 11:30:31 --> Loader Class Initialized
INFO - 2023-09-03 11:30:31 --> Helper loaded: url_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: file_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: html_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: text_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: form_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: security_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:30:31 --> Database Driver Class Initialized
INFO - 2023-09-03 11:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:30:31 --> Parser Class Initialized
INFO - 2023-09-03 11:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:30:31 --> Pagination Class Initialized
INFO - 2023-09-03 11:30:31 --> Form Validation Class Initialized
INFO - 2023-09-03 11:30:31 --> Controller Class Initialized
DEBUG - 2023-09-03 11:30:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
DEBUG - 2023-09-03 11:30:31 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
INFO - 2023-09-03 11:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-09-03 11:30:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
INFO - 2023-09-03 11:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:30:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:30:31 --> Final output sent to browser
DEBUG - 2023-09-03 11:30:31 --> Total execution time: 0.1365
ERROR - 2023-09-03 11:30:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:30:31 --> Config Class Initialized
INFO - 2023-09-03 11:30:31 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:30:31 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:30:31 --> Utf8 Class Initialized
INFO - 2023-09-03 11:30:31 --> URI Class Initialized
INFO - 2023-09-03 11:30:31 --> Router Class Initialized
INFO - 2023-09-03 11:30:31 --> Output Class Initialized
INFO - 2023-09-03 11:30:31 --> Security Class Initialized
DEBUG - 2023-09-03 11:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:30:31 --> Input Class Initialized
INFO - 2023-09-03 11:30:31 --> Language Class Initialized
INFO - 2023-09-03 11:30:31 --> Loader Class Initialized
INFO - 2023-09-03 11:30:31 --> Helper loaded: url_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: file_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: html_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: text_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: form_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: security_helper
INFO - 2023-09-03 11:30:31 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:30:31 --> Database Driver Class Initialized
INFO - 2023-09-03 11:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:30:31 --> Parser Class Initialized
INFO - 2023-09-03 11:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:30:31 --> Pagination Class Initialized
INFO - 2023-09-03 11:30:31 --> Form Validation Class Initialized
INFO - 2023-09-03 11:30:31 --> Controller Class Initialized
DEBUG - 2023-09-03 11:30:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
INFO - 2023-09-03 11:30:31 --> Model Class Initialized
INFO - 2023-09-03 11:30:32 --> Final output sent to browser
DEBUG - 2023-09-03 11:30:32 --> Total execution time: 0.0199
ERROR - 2023-09-03 11:30:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:30:59 --> Config Class Initialized
INFO - 2023-09-03 11:30:59 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:30:59 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:30:59 --> Utf8 Class Initialized
INFO - 2023-09-03 11:30:59 --> URI Class Initialized
DEBUG - 2023-09-03 11:30:59 --> No URI present. Default controller set.
INFO - 2023-09-03 11:30:59 --> Router Class Initialized
INFO - 2023-09-03 11:30:59 --> Output Class Initialized
INFO - 2023-09-03 11:30:59 --> Security Class Initialized
DEBUG - 2023-09-03 11:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:30:59 --> Input Class Initialized
INFO - 2023-09-03 11:30:59 --> Language Class Initialized
INFO - 2023-09-03 11:30:59 --> Loader Class Initialized
INFO - 2023-09-03 11:30:59 --> Helper loaded: url_helper
INFO - 2023-09-03 11:30:59 --> Helper loaded: file_helper
INFO - 2023-09-03 11:30:59 --> Helper loaded: html_helper
INFO - 2023-09-03 11:30:59 --> Helper loaded: text_helper
INFO - 2023-09-03 11:30:59 --> Helper loaded: form_helper
INFO - 2023-09-03 11:30:59 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:30:59 --> Helper loaded: security_helper
INFO - 2023-09-03 11:30:59 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:30:59 --> Database Driver Class Initialized
INFO - 2023-09-03 11:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:30:59 --> Parser Class Initialized
INFO - 2023-09-03 11:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:30:59 --> Pagination Class Initialized
INFO - 2023-09-03 11:30:59 --> Form Validation Class Initialized
INFO - 2023-09-03 11:30:59 --> Controller Class Initialized
INFO - 2023-09-03 11:30:59 --> Model Class Initialized
DEBUG - 2023-09-03 11:30:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 11:31:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:31:00 --> Config Class Initialized
INFO - 2023-09-03 11:31:00 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:31:00 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:31:00 --> Utf8 Class Initialized
INFO - 2023-09-03 11:31:00 --> URI Class Initialized
INFO - 2023-09-03 11:31:00 --> Router Class Initialized
INFO - 2023-09-03 11:31:00 --> Output Class Initialized
INFO - 2023-09-03 11:31:00 --> Security Class Initialized
DEBUG - 2023-09-03 11:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:31:00 --> Input Class Initialized
INFO - 2023-09-03 11:31:00 --> Language Class Initialized
INFO - 2023-09-03 11:31:00 --> Loader Class Initialized
INFO - 2023-09-03 11:31:00 --> Helper loaded: url_helper
INFO - 2023-09-03 11:31:00 --> Helper loaded: file_helper
INFO - 2023-09-03 11:31:00 --> Helper loaded: html_helper
INFO - 2023-09-03 11:31:00 --> Helper loaded: text_helper
INFO - 2023-09-03 11:31:00 --> Helper loaded: form_helper
INFO - 2023-09-03 11:31:00 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:31:00 --> Helper loaded: security_helper
INFO - 2023-09-03 11:31:00 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:31:00 --> Database Driver Class Initialized
INFO - 2023-09-03 11:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:31:00 --> Parser Class Initialized
INFO - 2023-09-03 11:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:31:00 --> Pagination Class Initialized
INFO - 2023-09-03 11:31:00 --> Form Validation Class Initialized
INFO - 2023-09-03 11:31:00 --> Controller Class Initialized
INFO - 2023-09-03 11:31:00 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 11:31:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:31:00 --> Model Class Initialized
INFO - 2023-09-03 11:31:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:31:00 --> Final output sent to browser
DEBUG - 2023-09-03 11:31:00 --> Total execution time: 0.0277
ERROR - 2023-09-03 11:31:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:31:22 --> Config Class Initialized
INFO - 2023-09-03 11:31:22 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:31:22 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:31:22 --> Utf8 Class Initialized
INFO - 2023-09-03 11:31:22 --> URI Class Initialized
INFO - 2023-09-03 11:31:22 --> Router Class Initialized
INFO - 2023-09-03 11:31:22 --> Output Class Initialized
INFO - 2023-09-03 11:31:22 --> Security Class Initialized
DEBUG - 2023-09-03 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:31:22 --> Input Class Initialized
INFO - 2023-09-03 11:31:22 --> Language Class Initialized
INFO - 2023-09-03 11:31:22 --> Loader Class Initialized
INFO - 2023-09-03 11:31:22 --> Helper loaded: url_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: file_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: html_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: text_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: form_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: security_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:31:22 --> Database Driver Class Initialized
INFO - 2023-09-03 11:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:31:22 --> Parser Class Initialized
INFO - 2023-09-03 11:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:31:22 --> Pagination Class Initialized
INFO - 2023-09-03 11:31:22 --> Form Validation Class Initialized
INFO - 2023-09-03 11:31:22 --> Controller Class Initialized
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
INFO - 2023-09-03 11:31:22 --> Final output sent to browser
DEBUG - 2023-09-03 11:31:22 --> Total execution time: 0.0200
ERROR - 2023-09-03 11:31:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:31:22 --> Config Class Initialized
INFO - 2023-09-03 11:31:22 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:31:22 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:31:22 --> Utf8 Class Initialized
INFO - 2023-09-03 11:31:22 --> URI Class Initialized
DEBUG - 2023-09-03 11:31:22 --> No URI present. Default controller set.
INFO - 2023-09-03 11:31:22 --> Router Class Initialized
INFO - 2023-09-03 11:31:22 --> Output Class Initialized
INFO - 2023-09-03 11:31:22 --> Security Class Initialized
DEBUG - 2023-09-03 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:31:22 --> Input Class Initialized
INFO - 2023-09-03 11:31:22 --> Language Class Initialized
INFO - 2023-09-03 11:31:22 --> Loader Class Initialized
INFO - 2023-09-03 11:31:22 --> Helper loaded: url_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: file_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: html_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: text_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: form_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: security_helper
INFO - 2023-09-03 11:31:22 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:31:22 --> Database Driver Class Initialized
INFO - 2023-09-03 11:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:31:22 --> Parser Class Initialized
INFO - 2023-09-03 11:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:31:22 --> Pagination Class Initialized
INFO - 2023-09-03 11:31:22 --> Form Validation Class Initialized
INFO - 2023-09-03 11:31:22 --> Controller Class Initialized
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
INFO - 2023-09-03 11:31:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:31:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:31:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:31:22 --> Model Class Initialized
INFO - 2023-09-03 11:31:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:31:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:31:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:31:22 --> Final output sent to browser
DEBUG - 2023-09-03 11:31:22 --> Total execution time: 0.1069
ERROR - 2023-09-03 11:31:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:31:38 --> Config Class Initialized
INFO - 2023-09-03 11:31:38 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:31:38 --> Utf8 Class Initialized
INFO - 2023-09-03 11:31:38 --> URI Class Initialized
INFO - 2023-09-03 11:31:38 --> Router Class Initialized
INFO - 2023-09-03 11:31:38 --> Output Class Initialized
INFO - 2023-09-03 11:31:38 --> Security Class Initialized
DEBUG - 2023-09-03 11:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:31:38 --> Input Class Initialized
INFO - 2023-09-03 11:31:38 --> Language Class Initialized
INFO - 2023-09-03 11:31:38 --> Loader Class Initialized
INFO - 2023-09-03 11:31:38 --> Helper loaded: url_helper
INFO - 2023-09-03 11:31:38 --> Helper loaded: file_helper
INFO - 2023-09-03 11:31:38 --> Helper loaded: html_helper
INFO - 2023-09-03 11:31:38 --> Helper loaded: text_helper
INFO - 2023-09-03 11:31:38 --> Helper loaded: form_helper
INFO - 2023-09-03 11:31:38 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:31:38 --> Helper loaded: security_helper
INFO - 2023-09-03 11:31:38 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:31:38 --> Database Driver Class Initialized
INFO - 2023-09-03 11:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:31:39 --> Parser Class Initialized
INFO - 2023-09-03 11:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:31:39 --> Pagination Class Initialized
INFO - 2023-09-03 11:31:39 --> Form Validation Class Initialized
INFO - 2023-09-03 11:31:39 --> Controller Class Initialized
INFO - 2023-09-03 11:31:39 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:39 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:39 --> Model Class Initialized
INFO - 2023-09-03 11:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-03 11:31:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:31:39 --> Model Class Initialized
INFO - 2023-09-03 11:31:39 --> Model Class Initialized
INFO - 2023-09-03 11:31:39 --> Model Class Initialized
INFO - 2023-09-03 11:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:31:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:31:39 --> Final output sent to browser
DEBUG - 2023-09-03 11:31:39 --> Total execution time: 0.0804
ERROR - 2023-09-03 11:31:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:31:39 --> Config Class Initialized
INFO - 2023-09-03 11:31:39 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:31:39 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:31:39 --> Utf8 Class Initialized
INFO - 2023-09-03 11:31:39 --> URI Class Initialized
INFO - 2023-09-03 11:31:39 --> Router Class Initialized
INFO - 2023-09-03 11:31:39 --> Output Class Initialized
INFO - 2023-09-03 11:31:39 --> Security Class Initialized
DEBUG - 2023-09-03 11:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:31:39 --> Input Class Initialized
INFO - 2023-09-03 11:31:39 --> Language Class Initialized
INFO - 2023-09-03 11:31:39 --> Loader Class Initialized
INFO - 2023-09-03 11:31:39 --> Helper loaded: url_helper
INFO - 2023-09-03 11:31:39 --> Helper loaded: file_helper
INFO - 2023-09-03 11:31:39 --> Helper loaded: html_helper
INFO - 2023-09-03 11:31:39 --> Helper loaded: text_helper
INFO - 2023-09-03 11:31:39 --> Helper loaded: form_helper
INFO - 2023-09-03 11:31:39 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:31:39 --> Helper loaded: security_helper
INFO - 2023-09-03 11:31:39 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:31:39 --> Database Driver Class Initialized
INFO - 2023-09-03 11:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:31:39 --> Parser Class Initialized
INFO - 2023-09-03 11:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:31:39 --> Pagination Class Initialized
INFO - 2023-09-03 11:31:39 --> Form Validation Class Initialized
INFO - 2023-09-03 11:31:39 --> Controller Class Initialized
INFO - 2023-09-03 11:31:39 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:39 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:39 --> Model Class Initialized
INFO - 2023-09-03 11:31:39 --> Final output sent to browser
DEBUG - 2023-09-03 11:31:39 --> Total execution time: 0.0366
ERROR - 2023-09-03 11:31:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:31:56 --> Config Class Initialized
INFO - 2023-09-03 11:31:56 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:31:56 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:31:56 --> Utf8 Class Initialized
INFO - 2023-09-03 11:31:56 --> URI Class Initialized
INFO - 2023-09-03 11:31:56 --> Router Class Initialized
INFO - 2023-09-03 11:31:56 --> Output Class Initialized
INFO - 2023-09-03 11:31:56 --> Security Class Initialized
DEBUG - 2023-09-03 11:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:31:56 --> Input Class Initialized
INFO - 2023-09-03 11:31:56 --> Language Class Initialized
INFO - 2023-09-03 11:31:56 --> Loader Class Initialized
INFO - 2023-09-03 11:31:56 --> Helper loaded: url_helper
INFO - 2023-09-03 11:31:56 --> Helper loaded: file_helper
INFO - 2023-09-03 11:31:56 --> Helper loaded: html_helper
INFO - 2023-09-03 11:31:56 --> Helper loaded: text_helper
INFO - 2023-09-03 11:31:56 --> Helper loaded: form_helper
INFO - 2023-09-03 11:31:56 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:31:56 --> Helper loaded: security_helper
INFO - 2023-09-03 11:31:56 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:31:56 --> Database Driver Class Initialized
INFO - 2023-09-03 11:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:31:56 --> Parser Class Initialized
INFO - 2023-09-03 11:31:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:31:56 --> Pagination Class Initialized
INFO - 2023-09-03 11:31:56 --> Form Validation Class Initialized
INFO - 2023-09-03 11:31:56 --> Controller Class Initialized
INFO - 2023-09-03 11:31:56 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:31:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:56 --> Model Class Initialized
DEBUG - 2023-09-03 11:31:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:31:56 --> Model Class Initialized
INFO - 2023-09-03 11:31:56 --> Final output sent to browser
DEBUG - 2023-09-03 11:31:56 --> Total execution time: 0.1223
ERROR - 2023-09-03 11:32:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:32:57 --> Config Class Initialized
INFO - 2023-09-03 11:32:57 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:32:57 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:32:57 --> Utf8 Class Initialized
INFO - 2023-09-03 11:32:57 --> URI Class Initialized
INFO - 2023-09-03 11:32:57 --> Router Class Initialized
INFO - 2023-09-03 11:32:57 --> Output Class Initialized
INFO - 2023-09-03 11:32:57 --> Security Class Initialized
DEBUG - 2023-09-03 11:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:32:57 --> Input Class Initialized
INFO - 2023-09-03 11:32:57 --> Language Class Initialized
INFO - 2023-09-03 11:32:57 --> Loader Class Initialized
INFO - 2023-09-03 11:32:57 --> Helper loaded: url_helper
INFO - 2023-09-03 11:32:57 --> Helper loaded: file_helper
INFO - 2023-09-03 11:32:57 --> Helper loaded: html_helper
INFO - 2023-09-03 11:32:57 --> Helper loaded: text_helper
INFO - 2023-09-03 11:32:57 --> Helper loaded: form_helper
INFO - 2023-09-03 11:32:57 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:32:57 --> Helper loaded: security_helper
INFO - 2023-09-03 11:32:57 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:32:57 --> Database Driver Class Initialized
INFO - 2023-09-03 11:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:32:57 --> Parser Class Initialized
INFO - 2023-09-03 11:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:32:57 --> Pagination Class Initialized
INFO - 2023-09-03 11:32:57 --> Form Validation Class Initialized
INFO - 2023-09-03 11:32:57 --> Controller Class Initialized
INFO - 2023-09-03 11:32:57 --> Model Class Initialized
DEBUG - 2023-09-03 11:32:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:32:57 --> Model Class Initialized
DEBUG - 2023-09-03 11:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:32:57 --> Model Class Initialized
DEBUG - 2023-09-03 11:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:32:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-03 11:32:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:32:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:32:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:32:57 --> Model Class Initialized
INFO - 2023-09-03 11:32:57 --> Model Class Initialized
INFO - 2023-09-03 11:32:57 --> Model Class Initialized
INFO - 2023-09-03 11:32:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:32:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:32:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:32:57 --> Final output sent to browser
DEBUG - 2023-09-03 11:32:57 --> Total execution time: 0.0893
ERROR - 2023-09-03 11:33:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:33:05 --> Config Class Initialized
INFO - 2023-09-03 11:33:05 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:33:05 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:33:05 --> Utf8 Class Initialized
INFO - 2023-09-03 11:33:05 --> URI Class Initialized
DEBUG - 2023-09-03 11:33:05 --> No URI present. Default controller set.
INFO - 2023-09-03 11:33:05 --> Router Class Initialized
INFO - 2023-09-03 11:33:05 --> Output Class Initialized
INFO - 2023-09-03 11:33:05 --> Security Class Initialized
DEBUG - 2023-09-03 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:33:05 --> Input Class Initialized
INFO - 2023-09-03 11:33:05 --> Language Class Initialized
INFO - 2023-09-03 11:33:05 --> Loader Class Initialized
INFO - 2023-09-03 11:33:05 --> Helper loaded: url_helper
INFO - 2023-09-03 11:33:05 --> Helper loaded: file_helper
INFO - 2023-09-03 11:33:05 --> Helper loaded: html_helper
INFO - 2023-09-03 11:33:05 --> Helper loaded: text_helper
INFO - 2023-09-03 11:33:05 --> Helper loaded: form_helper
INFO - 2023-09-03 11:33:05 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:33:05 --> Helper loaded: security_helper
INFO - 2023-09-03 11:33:05 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:33:05 --> Database Driver Class Initialized
INFO - 2023-09-03 11:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:33:05 --> Parser Class Initialized
INFO - 2023-09-03 11:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:33:05 --> Pagination Class Initialized
INFO - 2023-09-03 11:33:05 --> Form Validation Class Initialized
INFO - 2023-09-03 11:33:05 --> Controller Class Initialized
INFO - 2023-09-03 11:33:05 --> Model Class Initialized
DEBUG - 2023-09-03 11:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:33:05 --> Model Class Initialized
DEBUG - 2023-09-03 11:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:33:05 --> Model Class Initialized
INFO - 2023-09-03 11:33:05 --> Model Class Initialized
INFO - 2023-09-03 11:33:05 --> Model Class Initialized
INFO - 2023-09-03 11:33:05 --> Model Class Initialized
DEBUG - 2023-09-03 11:33:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:33:05 --> Model Class Initialized
INFO - 2023-09-03 11:33:05 --> Model Class Initialized
INFO - 2023-09-03 11:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:33:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:33:05 --> Model Class Initialized
INFO - 2023-09-03 11:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:33:05 --> Final output sent to browser
DEBUG - 2023-09-03 11:33:05 --> Total execution time: 0.1975
ERROR - 2023-09-03 11:56:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:29 --> Config Class Initialized
INFO - 2023-09-03 11:56:29 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:29 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:29 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:29 --> URI Class Initialized
INFO - 2023-09-03 11:56:29 --> Router Class Initialized
INFO - 2023-09-03 11:56:29 --> Output Class Initialized
INFO - 2023-09-03 11:56:29 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:29 --> Input Class Initialized
INFO - 2023-09-03 11:56:29 --> Language Class Initialized
INFO - 2023-09-03 11:56:29 --> Loader Class Initialized
INFO - 2023-09-03 11:56:29 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:29 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:29 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:29 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:29 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:29 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:29 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:29 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:29 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:29 --> Parser Class Initialized
INFO - 2023-09-03 11:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:29 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:29 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:29 --> Controller Class Initialized
INFO - 2023-09-03 11:56:29 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:29 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:29 --> Model Class Initialized
INFO - 2023-09-03 11:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-09-03 11:56:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:56:29 --> Model Class Initialized
INFO - 2023-09-03 11:56:29 --> Model Class Initialized
INFO - 2023-09-03 11:56:29 --> Model Class Initialized
INFO - 2023-09-03 11:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:56:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:56:29 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:29 --> Total execution time: 0.1085
ERROR - 2023-09-03 11:56:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:31 --> Config Class Initialized
INFO - 2023-09-03 11:56:31 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:31 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:31 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:31 --> URI Class Initialized
INFO - 2023-09-03 11:56:31 --> Router Class Initialized
INFO - 2023-09-03 11:56:31 --> Output Class Initialized
INFO - 2023-09-03 11:56:31 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:31 --> Input Class Initialized
INFO - 2023-09-03 11:56:31 --> Language Class Initialized
INFO - 2023-09-03 11:56:31 --> Loader Class Initialized
INFO - 2023-09-03 11:56:31 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:31 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:31 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:31 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:31 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:31 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:31 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:31 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:31 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:31 --> Parser Class Initialized
INFO - 2023-09-03 11:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:31 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:31 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:31 --> Controller Class Initialized
INFO - 2023-09-03 11:56:32 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:32 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:32 --> Model Class Initialized
INFO - 2023-09-03 11:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-03 11:56:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:56:32 --> Model Class Initialized
INFO - 2023-09-03 11:56:32 --> Model Class Initialized
INFO - 2023-09-03 11:56:32 --> Model Class Initialized
INFO - 2023-09-03 11:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:56:32 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:32 --> Total execution time: 0.0857
ERROR - 2023-09-03 11:56:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:33 --> Config Class Initialized
INFO - 2023-09-03 11:56:33 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:33 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:33 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:33 --> URI Class Initialized
INFO - 2023-09-03 11:56:33 --> Router Class Initialized
INFO - 2023-09-03 11:56:33 --> Output Class Initialized
INFO - 2023-09-03 11:56:33 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:33 --> Input Class Initialized
INFO - 2023-09-03 11:56:33 --> Language Class Initialized
INFO - 2023-09-03 11:56:33 --> Loader Class Initialized
INFO - 2023-09-03 11:56:33 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:33 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:33 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:33 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:33 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:33 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:33 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:33 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:33 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:33 --> Parser Class Initialized
INFO - 2023-09-03 11:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:33 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:33 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:33 --> Controller Class Initialized
INFO - 2023-09-03 11:56:33 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:33 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:33 --> Model Class Initialized
INFO - 2023-09-03 11:56:33 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:33 --> Total execution time: 0.0456
ERROR - 2023-09-03 11:56:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:34 --> Config Class Initialized
INFO - 2023-09-03 11:56:34 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:34 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:34 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:34 --> URI Class Initialized
DEBUG - 2023-09-03 11:56:34 --> No URI present. Default controller set.
INFO - 2023-09-03 11:56:34 --> Router Class Initialized
INFO - 2023-09-03 11:56:34 --> Output Class Initialized
INFO - 2023-09-03 11:56:34 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:34 --> Input Class Initialized
INFO - 2023-09-03 11:56:34 --> Language Class Initialized
INFO - 2023-09-03 11:56:34 --> Loader Class Initialized
INFO - 2023-09-03 11:56:34 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:34 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:34 --> Parser Class Initialized
INFO - 2023-09-03 11:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:34 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:34 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:34 --> Controller Class Initialized
INFO - 2023-09-03 11:56:34 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 11:56:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:34 --> Config Class Initialized
INFO - 2023-09-03 11:56:34 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:34 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:34 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:34 --> URI Class Initialized
INFO - 2023-09-03 11:56:34 --> Router Class Initialized
INFO - 2023-09-03 11:56:34 --> Output Class Initialized
INFO - 2023-09-03 11:56:34 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:34 --> Input Class Initialized
INFO - 2023-09-03 11:56:34 --> Language Class Initialized
INFO - 2023-09-03 11:56:34 --> Loader Class Initialized
INFO - 2023-09-03 11:56:34 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:34 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:34 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:34 --> Parser Class Initialized
INFO - 2023-09-03 11:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:34 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:34 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:34 --> Controller Class Initialized
INFO - 2023-09-03 11:56:34 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 11:56:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:56:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:56:34 --> Model Class Initialized
INFO - 2023-09-03 11:56:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:56:34 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:34 --> Total execution time: 0.0292
ERROR - 2023-09-03 11:56:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:41 --> Config Class Initialized
INFO - 2023-09-03 11:56:41 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:41 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:41 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:41 --> URI Class Initialized
INFO - 2023-09-03 11:56:41 --> Router Class Initialized
INFO - 2023-09-03 11:56:41 --> Output Class Initialized
INFO - 2023-09-03 11:56:41 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:41 --> Input Class Initialized
INFO - 2023-09-03 11:56:41 --> Language Class Initialized
INFO - 2023-09-03 11:56:41 --> Loader Class Initialized
INFO - 2023-09-03 11:56:41 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:41 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:41 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:41 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:41 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:41 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:41 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:41 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:41 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:41 --> Parser Class Initialized
INFO - 2023-09-03 11:56:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:41 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:41 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:41 --> Controller Class Initialized
INFO - 2023-09-03 11:56:41 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:41 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:41 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-03 11:56:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:56:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:56:41 --> Model Class Initialized
INFO - 2023-09-03 11:56:41 --> Model Class Initialized
INFO - 2023-09-03 11:56:41 --> Model Class Initialized
INFO - 2023-09-03 11:56:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:56:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:56:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:56:41 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:41 --> Total execution time: 0.0833
ERROR - 2023-09-03 11:56:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:51 --> Config Class Initialized
INFO - 2023-09-03 11:56:51 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:51 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:51 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:51 --> URI Class Initialized
DEBUG - 2023-09-03 11:56:51 --> No URI present. Default controller set.
INFO - 2023-09-03 11:56:51 --> Router Class Initialized
INFO - 2023-09-03 11:56:51 --> Output Class Initialized
INFO - 2023-09-03 11:56:51 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:51 --> Input Class Initialized
INFO - 2023-09-03 11:56:51 --> Language Class Initialized
INFO - 2023-09-03 11:56:51 --> Loader Class Initialized
INFO - 2023-09-03 11:56:51 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:51 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:51 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:51 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:51 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:51 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:51 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:51 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:51 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:51 --> Parser Class Initialized
INFO - 2023-09-03 11:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:51 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:51 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:51 --> Controller Class Initialized
INFO - 2023-09-03 11:56:51 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:51 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:51 --> Model Class Initialized
INFO - 2023-09-03 11:56:51 --> Model Class Initialized
INFO - 2023-09-03 11:56:51 --> Model Class Initialized
INFO - 2023-09-03 11:56:51 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:51 --> Model Class Initialized
INFO - 2023-09-03 11:56:51 --> Model Class Initialized
INFO - 2023-09-03 11:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:56:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:56:51 --> Model Class Initialized
INFO - 2023-09-03 11:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:56:51 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:51 --> Total execution time: 0.0921
ERROR - 2023-09-03 11:56:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:58 --> Config Class Initialized
INFO - 2023-09-03 11:56:58 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:58 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:58 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:58 --> URI Class Initialized
INFO - 2023-09-03 11:56:58 --> Router Class Initialized
INFO - 2023-09-03 11:56:58 --> Output Class Initialized
INFO - 2023-09-03 11:56:58 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:58 --> Input Class Initialized
INFO - 2023-09-03 11:56:58 --> Language Class Initialized
INFO - 2023-09-03 11:56:58 --> Loader Class Initialized
INFO - 2023-09-03 11:56:58 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:58 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:58 --> Parser Class Initialized
INFO - 2023-09-03 11:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:58 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:58 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:58 --> Controller Class Initialized
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
INFO - 2023-09-03 11:56:58 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:58 --> Total execution time: 0.0163
ERROR - 2023-09-03 11:56:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:58 --> Config Class Initialized
INFO - 2023-09-03 11:56:58 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:58 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:58 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:58 --> URI Class Initialized
DEBUG - 2023-09-03 11:56:58 --> No URI present. Default controller set.
INFO - 2023-09-03 11:56:58 --> Router Class Initialized
INFO - 2023-09-03 11:56:58 --> Output Class Initialized
INFO - 2023-09-03 11:56:58 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:58 --> Input Class Initialized
INFO - 2023-09-03 11:56:58 --> Language Class Initialized
INFO - 2023-09-03 11:56:58 --> Loader Class Initialized
INFO - 2023-09-03 11:56:58 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:58 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:58 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:58 --> Parser Class Initialized
INFO - 2023-09-03 11:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:58 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:58 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:58 --> Controller Class Initialized
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
INFO - 2023-09-03 11:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:56:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:56:58 --> Model Class Initialized
INFO - 2023-09-03 11:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:56:58 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:58 --> Total execution time: 0.0836
ERROR - 2023-09-03 11:56:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:59 --> Config Class Initialized
INFO - 2023-09-03 11:56:59 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:59 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:59 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:59 --> URI Class Initialized
INFO - 2023-09-03 11:56:59 --> Router Class Initialized
INFO - 2023-09-03 11:56:59 --> Output Class Initialized
INFO - 2023-09-03 11:56:59 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:59 --> Input Class Initialized
INFO - 2023-09-03 11:56:59 --> Language Class Initialized
INFO - 2023-09-03 11:56:59 --> Loader Class Initialized
INFO - 2023-09-03 11:56:59 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:59 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:59 --> Parser Class Initialized
INFO - 2023-09-03 11:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:59 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:59 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:59 --> Controller Class Initialized
INFO - 2023-09-03 11:56:59 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:59 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:59 --> Model Class Initialized
INFO - 2023-09-03 11:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-03 11:56:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:56:59 --> Model Class Initialized
INFO - 2023-09-03 11:56:59 --> Model Class Initialized
INFO - 2023-09-03 11:56:59 --> Model Class Initialized
INFO - 2023-09-03 11:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:56:59 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:59 --> Total execution time: 0.0775
ERROR - 2023-09-03 11:56:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:56:59 --> Config Class Initialized
INFO - 2023-09-03 11:56:59 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:56:59 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:56:59 --> Utf8 Class Initialized
INFO - 2023-09-03 11:56:59 --> URI Class Initialized
INFO - 2023-09-03 11:56:59 --> Router Class Initialized
INFO - 2023-09-03 11:56:59 --> Output Class Initialized
INFO - 2023-09-03 11:56:59 --> Security Class Initialized
DEBUG - 2023-09-03 11:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:56:59 --> Input Class Initialized
INFO - 2023-09-03 11:56:59 --> Language Class Initialized
INFO - 2023-09-03 11:56:59 --> Loader Class Initialized
INFO - 2023-09-03 11:56:59 --> Helper loaded: url_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: file_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: html_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: text_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: form_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: security_helper
INFO - 2023-09-03 11:56:59 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:56:59 --> Database Driver Class Initialized
INFO - 2023-09-03 11:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:56:59 --> Parser Class Initialized
INFO - 2023-09-03 11:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:56:59 --> Pagination Class Initialized
INFO - 2023-09-03 11:56:59 --> Form Validation Class Initialized
INFO - 2023-09-03 11:56:59 --> Controller Class Initialized
INFO - 2023-09-03 11:56:59 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:59 --> Model Class Initialized
DEBUG - 2023-09-03 11:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:56:59 --> Model Class Initialized
INFO - 2023-09-03 11:56:59 --> Final output sent to browser
DEBUG - 2023-09-03 11:56:59 --> Total execution time: 0.0353
ERROR - 2023-09-03 11:57:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:57:01 --> Config Class Initialized
INFO - 2023-09-03 11:57:01 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:57:01 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:57:01 --> Utf8 Class Initialized
INFO - 2023-09-03 11:57:01 --> URI Class Initialized
INFO - 2023-09-03 11:57:01 --> Router Class Initialized
INFO - 2023-09-03 11:57:01 --> Output Class Initialized
INFO - 2023-09-03 11:57:01 --> Security Class Initialized
DEBUG - 2023-09-03 11:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:57:01 --> Input Class Initialized
INFO - 2023-09-03 11:57:01 --> Language Class Initialized
INFO - 2023-09-03 11:57:01 --> Loader Class Initialized
INFO - 2023-09-03 11:57:01 --> Helper loaded: url_helper
INFO - 2023-09-03 11:57:01 --> Helper loaded: file_helper
INFO - 2023-09-03 11:57:01 --> Helper loaded: html_helper
INFO - 2023-09-03 11:57:01 --> Helper loaded: text_helper
INFO - 2023-09-03 11:57:01 --> Helper loaded: form_helper
INFO - 2023-09-03 11:57:01 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:57:01 --> Helper loaded: security_helper
INFO - 2023-09-03 11:57:01 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:57:01 --> Database Driver Class Initialized
INFO - 2023-09-03 11:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:57:01 --> Parser Class Initialized
INFO - 2023-09-03 11:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:57:01 --> Pagination Class Initialized
INFO - 2023-09-03 11:57:01 --> Form Validation Class Initialized
INFO - 2023-09-03 11:57:01 --> Controller Class Initialized
INFO - 2023-09-03 11:57:01 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:01 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:01 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-03 11:57:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:57:01 --> Model Class Initialized
INFO - 2023-09-03 11:57:01 --> Model Class Initialized
INFO - 2023-09-03 11:57:01 --> Model Class Initialized
INFO - 2023-09-03 11:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:57:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:57:01 --> Final output sent to browser
DEBUG - 2023-09-03 11:57:01 --> Total execution time: 0.0956
ERROR - 2023-09-03 11:57:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:57:12 --> Config Class Initialized
INFO - 2023-09-03 11:57:12 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:57:12 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:57:12 --> Utf8 Class Initialized
INFO - 2023-09-03 11:57:12 --> URI Class Initialized
INFO - 2023-09-03 11:57:12 --> Router Class Initialized
INFO - 2023-09-03 11:57:12 --> Output Class Initialized
INFO - 2023-09-03 11:57:12 --> Security Class Initialized
DEBUG - 2023-09-03 11:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:57:12 --> Input Class Initialized
INFO - 2023-09-03 11:57:12 --> Language Class Initialized
INFO - 2023-09-03 11:57:12 --> Loader Class Initialized
INFO - 2023-09-03 11:57:12 --> Helper loaded: url_helper
INFO - 2023-09-03 11:57:12 --> Helper loaded: file_helper
INFO - 2023-09-03 11:57:12 --> Helper loaded: html_helper
INFO - 2023-09-03 11:57:12 --> Helper loaded: text_helper
INFO - 2023-09-03 11:57:12 --> Helper loaded: form_helper
INFO - 2023-09-03 11:57:12 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:57:12 --> Helper loaded: security_helper
INFO - 2023-09-03 11:57:12 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:57:12 --> Database Driver Class Initialized
INFO - 2023-09-03 11:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:57:12 --> Parser Class Initialized
INFO - 2023-09-03 11:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:57:12 --> Pagination Class Initialized
INFO - 2023-09-03 11:57:12 --> Form Validation Class Initialized
INFO - 2023-09-03 11:57:12 --> Controller Class Initialized
DEBUG - 2023-09-03 11:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:12 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:12 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:12 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:12 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:12 --> Model Class Initialized
INFO - 2023-09-03 11:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-03 11:57:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:57:12 --> Model Class Initialized
INFO - 2023-09-03 11:57:12 --> Model Class Initialized
INFO - 2023-09-03 11:57:12 --> Model Class Initialized
INFO - 2023-09-03 11:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:57:12 --> Final output sent to browser
DEBUG - 2023-09-03 11:57:12 --> Total execution time: 0.0684
ERROR - 2023-09-03 11:57:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:57:13 --> Config Class Initialized
INFO - 2023-09-03 11:57:13 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:57:13 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:57:13 --> Utf8 Class Initialized
INFO - 2023-09-03 11:57:13 --> URI Class Initialized
INFO - 2023-09-03 11:57:13 --> Router Class Initialized
INFO - 2023-09-03 11:57:13 --> Output Class Initialized
INFO - 2023-09-03 11:57:13 --> Security Class Initialized
DEBUG - 2023-09-03 11:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:57:13 --> Input Class Initialized
INFO - 2023-09-03 11:57:13 --> Language Class Initialized
INFO - 2023-09-03 11:57:13 --> Loader Class Initialized
INFO - 2023-09-03 11:57:13 --> Helper loaded: url_helper
INFO - 2023-09-03 11:57:13 --> Helper loaded: file_helper
INFO - 2023-09-03 11:57:13 --> Helper loaded: html_helper
INFO - 2023-09-03 11:57:13 --> Helper loaded: text_helper
INFO - 2023-09-03 11:57:13 --> Helper loaded: form_helper
INFO - 2023-09-03 11:57:13 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:57:13 --> Helper loaded: security_helper
INFO - 2023-09-03 11:57:13 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:57:13 --> Database Driver Class Initialized
INFO - 2023-09-03 11:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:57:13 --> Parser Class Initialized
INFO - 2023-09-03 11:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:57:13 --> Pagination Class Initialized
INFO - 2023-09-03 11:57:13 --> Form Validation Class Initialized
INFO - 2023-09-03 11:57:13 --> Controller Class Initialized
DEBUG - 2023-09-03 11:57:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:13 --> Model Class Initialized
INFO - 2023-09-03 11:57:13 --> Final output sent to browser
DEBUG - 2023-09-03 11:57:13 --> Total execution time: 0.0213
ERROR - 2023-09-03 11:57:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:57:19 --> Config Class Initialized
INFO - 2023-09-03 11:57:19 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:57:19 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:57:19 --> Utf8 Class Initialized
INFO - 2023-09-03 11:57:19 --> URI Class Initialized
DEBUG - 2023-09-03 11:57:19 --> No URI present. Default controller set.
INFO - 2023-09-03 11:57:19 --> Router Class Initialized
INFO - 2023-09-03 11:57:19 --> Output Class Initialized
INFO - 2023-09-03 11:57:19 --> Security Class Initialized
DEBUG - 2023-09-03 11:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:57:19 --> Input Class Initialized
INFO - 2023-09-03 11:57:19 --> Language Class Initialized
INFO - 2023-09-03 11:57:19 --> Loader Class Initialized
INFO - 2023-09-03 11:57:19 --> Helper loaded: url_helper
INFO - 2023-09-03 11:57:19 --> Helper loaded: file_helper
INFO - 2023-09-03 11:57:19 --> Helper loaded: html_helper
INFO - 2023-09-03 11:57:19 --> Helper loaded: text_helper
INFO - 2023-09-03 11:57:19 --> Helper loaded: form_helper
INFO - 2023-09-03 11:57:19 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:57:19 --> Helper loaded: security_helper
INFO - 2023-09-03 11:57:19 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:57:19 --> Database Driver Class Initialized
INFO - 2023-09-03 11:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:57:19 --> Parser Class Initialized
INFO - 2023-09-03 11:57:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:57:19 --> Pagination Class Initialized
INFO - 2023-09-03 11:57:19 --> Form Validation Class Initialized
INFO - 2023-09-03 11:57:19 --> Controller Class Initialized
INFO - 2023-09-03 11:57:19 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:19 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:19 --> Model Class Initialized
INFO - 2023-09-03 11:57:19 --> Model Class Initialized
INFO - 2023-09-03 11:57:19 --> Model Class Initialized
INFO - 2023-09-03 11:57:19 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:19 --> Model Class Initialized
INFO - 2023-09-03 11:57:19 --> Model Class Initialized
INFO - 2023-09-03 11:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:57:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:57:20 --> Model Class Initialized
INFO - 2023-09-03 11:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:57:20 --> Final output sent to browser
DEBUG - 2023-09-03 11:57:20 --> Total execution time: 0.1086
ERROR - 2023-09-03 11:57:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:57:23 --> Config Class Initialized
INFO - 2023-09-03 11:57:23 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:57:23 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:57:23 --> Utf8 Class Initialized
INFO - 2023-09-03 11:57:23 --> URI Class Initialized
DEBUG - 2023-09-03 11:57:23 --> No URI present. Default controller set.
INFO - 2023-09-03 11:57:23 --> Router Class Initialized
INFO - 2023-09-03 11:57:23 --> Output Class Initialized
INFO - 2023-09-03 11:57:23 --> Security Class Initialized
DEBUG - 2023-09-03 11:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:57:23 --> Input Class Initialized
INFO - 2023-09-03 11:57:23 --> Language Class Initialized
INFO - 2023-09-03 11:57:23 --> Loader Class Initialized
INFO - 2023-09-03 11:57:23 --> Helper loaded: url_helper
INFO - 2023-09-03 11:57:23 --> Helper loaded: file_helper
INFO - 2023-09-03 11:57:23 --> Helper loaded: html_helper
INFO - 2023-09-03 11:57:23 --> Helper loaded: text_helper
INFO - 2023-09-03 11:57:23 --> Helper loaded: form_helper
INFO - 2023-09-03 11:57:23 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:57:23 --> Helper loaded: security_helper
INFO - 2023-09-03 11:57:23 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:57:23 --> Database Driver Class Initialized
INFO - 2023-09-03 11:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:57:23 --> Parser Class Initialized
INFO - 2023-09-03 11:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:57:23 --> Pagination Class Initialized
INFO - 2023-09-03 11:57:23 --> Form Validation Class Initialized
INFO - 2023-09-03 11:57:23 --> Controller Class Initialized
INFO - 2023-09-03 11:57:23 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:23 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:23 --> Model Class Initialized
INFO - 2023-09-03 11:57:23 --> Model Class Initialized
INFO - 2023-09-03 11:57:23 --> Model Class Initialized
INFO - 2023-09-03 11:57:23 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:23 --> Model Class Initialized
INFO - 2023-09-03 11:57:23 --> Model Class Initialized
INFO - 2023-09-03 11:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:57:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:57:23 --> Model Class Initialized
INFO - 2023-09-03 11:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:57:23 --> Final output sent to browser
DEBUG - 2023-09-03 11:57:23 --> Total execution time: 0.0968
ERROR - 2023-09-03 11:57:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:57:32 --> Config Class Initialized
INFO - 2023-09-03 11:57:32 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:57:32 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:57:32 --> Utf8 Class Initialized
INFO - 2023-09-03 11:57:32 --> URI Class Initialized
INFO - 2023-09-03 11:57:32 --> Router Class Initialized
INFO - 2023-09-03 11:57:32 --> Output Class Initialized
INFO - 2023-09-03 11:57:32 --> Security Class Initialized
DEBUG - 2023-09-03 11:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:57:32 --> Input Class Initialized
INFO - 2023-09-03 11:57:32 --> Language Class Initialized
INFO - 2023-09-03 11:57:32 --> Loader Class Initialized
INFO - 2023-09-03 11:57:32 --> Helper loaded: url_helper
INFO - 2023-09-03 11:57:32 --> Helper loaded: file_helper
INFO - 2023-09-03 11:57:32 --> Helper loaded: html_helper
INFO - 2023-09-03 11:57:32 --> Helper loaded: text_helper
INFO - 2023-09-03 11:57:32 --> Helper loaded: form_helper
INFO - 2023-09-03 11:57:32 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:57:32 --> Helper loaded: security_helper
INFO - 2023-09-03 11:57:32 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:57:32 --> Database Driver Class Initialized
INFO - 2023-09-03 11:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:57:32 --> Parser Class Initialized
INFO - 2023-09-03 11:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:57:32 --> Pagination Class Initialized
INFO - 2023-09-03 11:57:32 --> Form Validation Class Initialized
INFO - 2023-09-03 11:57:32 --> Controller Class Initialized
INFO - 2023-09-03 11:57:32 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:32 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:32 --> Model Class Initialized
INFO - 2023-09-03 11:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-03 11:57:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:57:32 --> Model Class Initialized
INFO - 2023-09-03 11:57:32 --> Model Class Initialized
INFO - 2023-09-03 11:57:32 --> Model Class Initialized
INFO - 2023-09-03 11:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:57:32 --> Final output sent to browser
DEBUG - 2023-09-03 11:57:32 --> Total execution time: 0.0804
ERROR - 2023-09-03 11:57:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:57:33 --> Config Class Initialized
INFO - 2023-09-03 11:57:33 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:57:33 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:57:33 --> Utf8 Class Initialized
INFO - 2023-09-03 11:57:33 --> URI Class Initialized
INFO - 2023-09-03 11:57:33 --> Router Class Initialized
INFO - 2023-09-03 11:57:33 --> Output Class Initialized
INFO - 2023-09-03 11:57:33 --> Security Class Initialized
DEBUG - 2023-09-03 11:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:57:33 --> Input Class Initialized
INFO - 2023-09-03 11:57:33 --> Language Class Initialized
INFO - 2023-09-03 11:57:33 --> Loader Class Initialized
INFO - 2023-09-03 11:57:33 --> Helper loaded: url_helper
INFO - 2023-09-03 11:57:33 --> Helper loaded: file_helper
INFO - 2023-09-03 11:57:33 --> Helper loaded: html_helper
INFO - 2023-09-03 11:57:33 --> Helper loaded: text_helper
INFO - 2023-09-03 11:57:33 --> Helper loaded: form_helper
INFO - 2023-09-03 11:57:33 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:57:33 --> Helper loaded: security_helper
INFO - 2023-09-03 11:57:33 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:57:33 --> Database Driver Class Initialized
INFO - 2023-09-03 11:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:57:33 --> Parser Class Initialized
INFO - 2023-09-03 11:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:57:33 --> Pagination Class Initialized
INFO - 2023-09-03 11:57:33 --> Form Validation Class Initialized
INFO - 2023-09-03 11:57:33 --> Controller Class Initialized
INFO - 2023-09-03 11:57:33 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:33 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:33 --> Model Class Initialized
INFO - 2023-09-03 11:57:33 --> Final output sent to browser
DEBUG - 2023-09-03 11:57:33 --> Total execution time: 0.0382
ERROR - 2023-09-03 11:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:57:36 --> Config Class Initialized
INFO - 2023-09-03 11:57:36 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:57:36 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:57:36 --> Utf8 Class Initialized
INFO - 2023-09-03 11:57:36 --> URI Class Initialized
INFO - 2023-09-03 11:57:36 --> Router Class Initialized
INFO - 2023-09-03 11:57:36 --> Output Class Initialized
INFO - 2023-09-03 11:57:36 --> Security Class Initialized
DEBUG - 2023-09-03 11:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:57:36 --> Input Class Initialized
INFO - 2023-09-03 11:57:36 --> Language Class Initialized
INFO - 2023-09-03 11:57:36 --> Loader Class Initialized
INFO - 2023-09-03 11:57:36 --> Helper loaded: url_helper
INFO - 2023-09-03 11:57:36 --> Helper loaded: file_helper
INFO - 2023-09-03 11:57:36 --> Helper loaded: html_helper
INFO - 2023-09-03 11:57:36 --> Helper loaded: text_helper
INFO - 2023-09-03 11:57:36 --> Helper loaded: form_helper
INFO - 2023-09-03 11:57:36 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:57:36 --> Helper loaded: security_helper
INFO - 2023-09-03 11:57:36 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:57:36 --> Database Driver Class Initialized
INFO - 2023-09-03 11:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:57:36 --> Parser Class Initialized
INFO - 2023-09-03 11:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:57:36 --> Pagination Class Initialized
INFO - 2023-09-03 11:57:36 --> Form Validation Class Initialized
INFO - 2023-09-03 11:57:36 --> Controller Class Initialized
INFO - 2023-09-03 11:57:36 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:36 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:36 --> Model Class Initialized
INFO - 2023-09-03 11:57:36 --> Final output sent to browser
DEBUG - 2023-09-03 11:57:36 --> Total execution time: 0.1284
ERROR - 2023-09-03 11:57:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:57:50 --> Config Class Initialized
INFO - 2023-09-03 11:57:50 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:57:50 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:57:50 --> Utf8 Class Initialized
INFO - 2023-09-03 11:57:50 --> URI Class Initialized
DEBUG - 2023-09-03 11:57:50 --> No URI present. Default controller set.
INFO - 2023-09-03 11:57:50 --> Router Class Initialized
INFO - 2023-09-03 11:57:50 --> Output Class Initialized
INFO - 2023-09-03 11:57:50 --> Security Class Initialized
DEBUG - 2023-09-03 11:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:57:50 --> Input Class Initialized
INFO - 2023-09-03 11:57:50 --> Language Class Initialized
INFO - 2023-09-03 11:57:50 --> Loader Class Initialized
INFO - 2023-09-03 11:57:50 --> Helper loaded: url_helper
INFO - 2023-09-03 11:57:50 --> Helper loaded: file_helper
INFO - 2023-09-03 11:57:50 --> Helper loaded: html_helper
INFO - 2023-09-03 11:57:50 --> Helper loaded: text_helper
INFO - 2023-09-03 11:57:50 --> Helper loaded: form_helper
INFO - 2023-09-03 11:57:50 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:57:50 --> Helper loaded: security_helper
INFO - 2023-09-03 11:57:50 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:57:50 --> Database Driver Class Initialized
INFO - 2023-09-03 11:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:57:50 --> Parser Class Initialized
INFO - 2023-09-03 11:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:57:50 --> Pagination Class Initialized
INFO - 2023-09-03 11:57:50 --> Form Validation Class Initialized
INFO - 2023-09-03 11:57:50 --> Controller Class Initialized
INFO - 2023-09-03 11:57:50 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:50 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:50 --> Model Class Initialized
INFO - 2023-09-03 11:57:50 --> Model Class Initialized
INFO - 2023-09-03 11:57:50 --> Model Class Initialized
INFO - 2023-09-03 11:57:50 --> Model Class Initialized
DEBUG - 2023-09-03 11:57:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:50 --> Model Class Initialized
INFO - 2023-09-03 11:57:50 --> Model Class Initialized
INFO - 2023-09-03 11:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:57:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:57:50 --> Model Class Initialized
INFO - 2023-09-03 11:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:57:50 --> Final output sent to browser
DEBUG - 2023-09-03 11:57:50 --> Total execution time: 0.0840
ERROR - 2023-09-03 11:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:58:09 --> Config Class Initialized
INFO - 2023-09-03 11:58:09 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:58:09 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:58:09 --> Utf8 Class Initialized
INFO - 2023-09-03 11:58:09 --> URI Class Initialized
INFO - 2023-09-03 11:58:09 --> Router Class Initialized
INFO - 2023-09-03 11:58:09 --> Output Class Initialized
INFO - 2023-09-03 11:58:09 --> Security Class Initialized
DEBUG - 2023-09-03 11:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:58:09 --> Input Class Initialized
INFO - 2023-09-03 11:58:09 --> Language Class Initialized
INFO - 2023-09-03 11:58:09 --> Loader Class Initialized
INFO - 2023-09-03 11:58:09 --> Helper loaded: url_helper
INFO - 2023-09-03 11:58:09 --> Helper loaded: file_helper
INFO - 2023-09-03 11:58:09 --> Helper loaded: html_helper
INFO - 2023-09-03 11:58:09 --> Helper loaded: text_helper
INFO - 2023-09-03 11:58:09 --> Helper loaded: form_helper
INFO - 2023-09-03 11:58:09 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:58:09 --> Helper loaded: security_helper
INFO - 2023-09-03 11:58:09 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:58:09 --> Database Driver Class Initialized
INFO - 2023-09-03 11:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:58:09 --> Parser Class Initialized
INFO - 2023-09-03 11:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:58:09 --> Pagination Class Initialized
INFO - 2023-09-03 11:58:09 --> Form Validation Class Initialized
INFO - 2023-09-03 11:58:09 --> Controller Class Initialized
DEBUG - 2023-09-03 11:58:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:09 --> Model Class Initialized
DEBUG - 2023-09-03 11:58:09 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:09 --> Model Class Initialized
DEBUG - 2023-09-03 11:58:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:09 --> Model Class Initialized
DEBUG - 2023-09-03 11:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:09 --> Model Class Initialized
INFO - 2023-09-03 11:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-03 11:58:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:58:09 --> Model Class Initialized
INFO - 2023-09-03 11:58:09 --> Model Class Initialized
INFO - 2023-09-03 11:58:09 --> Model Class Initialized
INFO - 2023-09-03 11:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:58:09 --> Final output sent to browser
DEBUG - 2023-09-03 11:58:09 --> Total execution time: 0.0658
ERROR - 2023-09-03 11:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:58:11 --> Config Class Initialized
INFO - 2023-09-03 11:58:11 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:58:11 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:58:11 --> Utf8 Class Initialized
INFO - 2023-09-03 11:58:11 --> URI Class Initialized
INFO - 2023-09-03 11:58:11 --> Router Class Initialized
INFO - 2023-09-03 11:58:11 --> Output Class Initialized
INFO - 2023-09-03 11:58:11 --> Security Class Initialized
DEBUG - 2023-09-03 11:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:58:11 --> Input Class Initialized
INFO - 2023-09-03 11:58:11 --> Language Class Initialized
INFO - 2023-09-03 11:58:11 --> Loader Class Initialized
INFO - 2023-09-03 11:58:11 --> Helper loaded: url_helper
INFO - 2023-09-03 11:58:11 --> Helper loaded: file_helper
INFO - 2023-09-03 11:58:11 --> Helper loaded: html_helper
INFO - 2023-09-03 11:58:11 --> Helper loaded: text_helper
INFO - 2023-09-03 11:58:11 --> Helper loaded: form_helper
INFO - 2023-09-03 11:58:11 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:58:11 --> Helper loaded: security_helper
INFO - 2023-09-03 11:58:11 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:58:11 --> Database Driver Class Initialized
INFO - 2023-09-03 11:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:58:11 --> Parser Class Initialized
INFO - 2023-09-03 11:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:58:11 --> Pagination Class Initialized
INFO - 2023-09-03 11:58:11 --> Form Validation Class Initialized
INFO - 2023-09-03 11:58:11 --> Controller Class Initialized
DEBUG - 2023-09-03 11:58:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:11 --> Model Class Initialized
INFO - 2023-09-03 11:58:11 --> Final output sent to browser
DEBUG - 2023-09-03 11:58:11 --> Total execution time: 0.0195
ERROR - 2023-09-03 11:58:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 11:58:57 --> Config Class Initialized
INFO - 2023-09-03 11:58:57 --> Hooks Class Initialized
DEBUG - 2023-09-03 11:58:57 --> UTF-8 Support Enabled
INFO - 2023-09-03 11:58:57 --> Utf8 Class Initialized
INFO - 2023-09-03 11:58:57 --> URI Class Initialized
DEBUG - 2023-09-03 11:58:57 --> No URI present. Default controller set.
INFO - 2023-09-03 11:58:57 --> Router Class Initialized
INFO - 2023-09-03 11:58:57 --> Output Class Initialized
INFO - 2023-09-03 11:58:57 --> Security Class Initialized
DEBUG - 2023-09-03 11:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 11:58:57 --> Input Class Initialized
INFO - 2023-09-03 11:58:57 --> Language Class Initialized
INFO - 2023-09-03 11:58:57 --> Loader Class Initialized
INFO - 2023-09-03 11:58:57 --> Helper loaded: url_helper
INFO - 2023-09-03 11:58:57 --> Helper loaded: file_helper
INFO - 2023-09-03 11:58:57 --> Helper loaded: html_helper
INFO - 2023-09-03 11:58:57 --> Helper loaded: text_helper
INFO - 2023-09-03 11:58:57 --> Helper loaded: form_helper
INFO - 2023-09-03 11:58:57 --> Helper loaded: lang_helper
INFO - 2023-09-03 11:58:57 --> Helper loaded: security_helper
INFO - 2023-09-03 11:58:57 --> Helper loaded: cookie_helper
INFO - 2023-09-03 11:58:57 --> Database Driver Class Initialized
INFO - 2023-09-03 11:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 11:58:57 --> Parser Class Initialized
INFO - 2023-09-03 11:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 11:58:57 --> Pagination Class Initialized
INFO - 2023-09-03 11:58:57 --> Form Validation Class Initialized
INFO - 2023-09-03 11:58:57 --> Controller Class Initialized
INFO - 2023-09-03 11:58:57 --> Model Class Initialized
DEBUG - 2023-09-03 11:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:57 --> Model Class Initialized
DEBUG - 2023-09-03 11:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:57 --> Model Class Initialized
INFO - 2023-09-03 11:58:57 --> Model Class Initialized
INFO - 2023-09-03 11:58:57 --> Model Class Initialized
INFO - 2023-09-03 11:58:57 --> Model Class Initialized
DEBUG - 2023-09-03 11:58:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 11:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:57 --> Model Class Initialized
INFO - 2023-09-03 11:58:57 --> Model Class Initialized
INFO - 2023-09-03 11:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 11:58:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 11:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 11:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 11:58:57 --> Model Class Initialized
INFO - 2023-09-03 11:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 11:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 11:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 11:58:57 --> Final output sent to browser
DEBUG - 2023-09-03 11:58:57 --> Total execution time: 0.0894
ERROR - 2023-09-03 14:56:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:56:11 --> Config Class Initialized
INFO - 2023-09-03 14:56:11 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:56:11 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:56:11 --> Utf8 Class Initialized
INFO - 2023-09-03 14:56:11 --> URI Class Initialized
DEBUG - 2023-09-03 14:56:11 --> No URI present. Default controller set.
INFO - 2023-09-03 14:56:11 --> Router Class Initialized
INFO - 2023-09-03 14:56:11 --> Output Class Initialized
INFO - 2023-09-03 14:56:11 --> Security Class Initialized
DEBUG - 2023-09-03 14:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:56:11 --> Input Class Initialized
INFO - 2023-09-03 14:56:11 --> Language Class Initialized
INFO - 2023-09-03 14:56:11 --> Loader Class Initialized
INFO - 2023-09-03 14:56:11 --> Helper loaded: url_helper
INFO - 2023-09-03 14:56:11 --> Helper loaded: file_helper
INFO - 2023-09-03 14:56:11 --> Helper loaded: html_helper
INFO - 2023-09-03 14:56:11 --> Helper loaded: text_helper
INFO - 2023-09-03 14:56:11 --> Helper loaded: form_helper
INFO - 2023-09-03 14:56:11 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:56:11 --> Helper loaded: security_helper
INFO - 2023-09-03 14:56:11 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:56:11 --> Database Driver Class Initialized
INFO - 2023-09-03 14:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:56:11 --> Parser Class Initialized
INFO - 2023-09-03 14:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:56:11 --> Pagination Class Initialized
INFO - 2023-09-03 14:56:11 --> Form Validation Class Initialized
INFO - 2023-09-03 14:56:11 --> Controller Class Initialized
INFO - 2023-09-03 14:56:11 --> Model Class Initialized
DEBUG - 2023-09-03 14:56:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 14:56:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:56:21 --> Config Class Initialized
INFO - 2023-09-03 14:56:21 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:56:21 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:56:21 --> Utf8 Class Initialized
INFO - 2023-09-03 14:56:21 --> URI Class Initialized
INFO - 2023-09-03 14:56:21 --> Router Class Initialized
INFO - 2023-09-03 14:56:21 --> Output Class Initialized
INFO - 2023-09-03 14:56:21 --> Security Class Initialized
DEBUG - 2023-09-03 14:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:56:21 --> Input Class Initialized
INFO - 2023-09-03 14:56:21 --> Language Class Initialized
INFO - 2023-09-03 14:56:21 --> Loader Class Initialized
INFO - 2023-09-03 14:56:21 --> Helper loaded: url_helper
INFO - 2023-09-03 14:56:21 --> Helper loaded: file_helper
INFO - 2023-09-03 14:56:21 --> Helper loaded: html_helper
INFO - 2023-09-03 14:56:21 --> Helper loaded: text_helper
INFO - 2023-09-03 14:56:21 --> Helper loaded: form_helper
INFO - 2023-09-03 14:56:21 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:56:21 --> Helper loaded: security_helper
INFO - 2023-09-03 14:56:21 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:56:21 --> Database Driver Class Initialized
INFO - 2023-09-03 14:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:56:21 --> Parser Class Initialized
INFO - 2023-09-03 14:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:56:21 --> Pagination Class Initialized
INFO - 2023-09-03 14:56:21 --> Form Validation Class Initialized
INFO - 2023-09-03 14:56:21 --> Controller Class Initialized
INFO - 2023-09-03 14:56:21 --> Model Class Initialized
DEBUG - 2023-09-03 14:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 14:56:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 14:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 14:56:21 --> Model Class Initialized
INFO - 2023-09-03 14:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 14:56:21 --> Final output sent to browser
DEBUG - 2023-09-03 14:56:21 --> Total execution time: 0.0425
ERROR - 2023-09-03 14:56:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:56:48 --> Config Class Initialized
INFO - 2023-09-03 14:56:48 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:56:48 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:56:48 --> Utf8 Class Initialized
INFO - 2023-09-03 14:56:48 --> URI Class Initialized
INFO - 2023-09-03 14:56:48 --> Router Class Initialized
INFO - 2023-09-03 14:56:48 --> Output Class Initialized
INFO - 2023-09-03 14:56:48 --> Security Class Initialized
DEBUG - 2023-09-03 14:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:56:48 --> Input Class Initialized
INFO - 2023-09-03 14:56:48 --> Language Class Initialized
INFO - 2023-09-03 14:56:48 --> Loader Class Initialized
INFO - 2023-09-03 14:56:48 --> Helper loaded: url_helper
INFO - 2023-09-03 14:56:48 --> Helper loaded: file_helper
INFO - 2023-09-03 14:56:48 --> Helper loaded: html_helper
INFO - 2023-09-03 14:56:48 --> Helper loaded: text_helper
INFO - 2023-09-03 14:56:48 --> Helper loaded: form_helper
INFO - 2023-09-03 14:56:48 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:56:48 --> Helper loaded: security_helper
INFO - 2023-09-03 14:56:48 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:56:48 --> Database Driver Class Initialized
INFO - 2023-09-03 14:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:56:48 --> Parser Class Initialized
INFO - 2023-09-03 14:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:56:48 --> Pagination Class Initialized
INFO - 2023-09-03 14:56:48 --> Form Validation Class Initialized
INFO - 2023-09-03 14:56:48 --> Controller Class Initialized
INFO - 2023-09-03 14:56:48 --> Model Class Initialized
DEBUG - 2023-09-03 14:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:48 --> Model Class Initialized
INFO - 2023-09-03 14:56:48 --> Final output sent to browser
DEBUG - 2023-09-03 14:56:48 --> Total execution time: 0.0216
ERROR - 2023-09-03 14:56:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:56:49 --> Config Class Initialized
INFO - 2023-09-03 14:56:49 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:56:49 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:56:49 --> Utf8 Class Initialized
INFO - 2023-09-03 14:56:49 --> URI Class Initialized
DEBUG - 2023-09-03 14:56:49 --> No URI present. Default controller set.
INFO - 2023-09-03 14:56:49 --> Router Class Initialized
INFO - 2023-09-03 14:56:49 --> Output Class Initialized
INFO - 2023-09-03 14:56:49 --> Security Class Initialized
DEBUG - 2023-09-03 14:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:56:49 --> Input Class Initialized
INFO - 2023-09-03 14:56:49 --> Language Class Initialized
INFO - 2023-09-03 14:56:49 --> Loader Class Initialized
INFO - 2023-09-03 14:56:49 --> Helper loaded: url_helper
INFO - 2023-09-03 14:56:49 --> Helper loaded: file_helper
INFO - 2023-09-03 14:56:49 --> Helper loaded: html_helper
INFO - 2023-09-03 14:56:49 --> Helper loaded: text_helper
INFO - 2023-09-03 14:56:49 --> Helper loaded: form_helper
INFO - 2023-09-03 14:56:49 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:56:49 --> Helper loaded: security_helper
INFO - 2023-09-03 14:56:49 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:56:49 --> Database Driver Class Initialized
INFO - 2023-09-03 14:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:56:49 --> Parser Class Initialized
INFO - 2023-09-03 14:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:56:49 --> Pagination Class Initialized
INFO - 2023-09-03 14:56:49 --> Form Validation Class Initialized
INFO - 2023-09-03 14:56:49 --> Controller Class Initialized
INFO - 2023-09-03 14:56:49 --> Model Class Initialized
DEBUG - 2023-09-03 14:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:49 --> Model Class Initialized
DEBUG - 2023-09-03 14:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:49 --> Model Class Initialized
INFO - 2023-09-03 14:56:49 --> Model Class Initialized
INFO - 2023-09-03 14:56:49 --> Model Class Initialized
INFO - 2023-09-03 14:56:49 --> Model Class Initialized
DEBUG - 2023-09-03 14:56:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:49 --> Model Class Initialized
INFO - 2023-09-03 14:56:49 --> Model Class Initialized
INFO - 2023-09-03 14:56:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 14:56:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 14:56:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 14:56:49 --> Model Class Initialized
INFO - 2023-09-03 14:56:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 14:56:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 14:56:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 14:56:49 --> Final output sent to browser
DEBUG - 2023-09-03 14:56:49 --> Total execution time: 0.0946
ERROR - 2023-09-03 14:56:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:56:59 --> Config Class Initialized
INFO - 2023-09-03 14:56:59 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:56:59 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:56:59 --> Utf8 Class Initialized
INFO - 2023-09-03 14:56:59 --> URI Class Initialized
INFO - 2023-09-03 14:56:59 --> Router Class Initialized
INFO - 2023-09-03 14:56:59 --> Output Class Initialized
INFO - 2023-09-03 14:56:59 --> Security Class Initialized
DEBUG - 2023-09-03 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:56:59 --> Input Class Initialized
INFO - 2023-09-03 14:56:59 --> Language Class Initialized
INFO - 2023-09-03 14:56:59 --> Loader Class Initialized
INFO - 2023-09-03 14:56:59 --> Helper loaded: url_helper
INFO - 2023-09-03 14:56:59 --> Helper loaded: file_helper
INFO - 2023-09-03 14:56:59 --> Helper loaded: html_helper
INFO - 2023-09-03 14:56:59 --> Helper loaded: text_helper
INFO - 2023-09-03 14:56:59 --> Helper loaded: form_helper
INFO - 2023-09-03 14:56:59 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:56:59 --> Helper loaded: security_helper
INFO - 2023-09-03 14:56:59 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:56:59 --> Database Driver Class Initialized
INFO - 2023-09-03 14:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:56:59 --> Parser Class Initialized
INFO - 2023-09-03 14:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:56:59 --> Pagination Class Initialized
INFO - 2023-09-03 14:56:59 --> Form Validation Class Initialized
INFO - 2023-09-03 14:56:59 --> Controller Class Initialized
DEBUG - 2023-09-03 14:56:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:59 --> Model Class Initialized
DEBUG - 2023-09-03 14:56:59 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:59 --> Model Class Initialized
DEBUG - 2023-09-03 14:56:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:59 --> Model Class Initialized
DEBUG - 2023-09-03 14:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:59 --> Model Class Initialized
INFO - 2023-09-03 14:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-03 14:56:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 14:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 14:56:59 --> Model Class Initialized
INFO - 2023-09-03 14:56:59 --> Model Class Initialized
INFO - 2023-09-03 14:56:59 --> Model Class Initialized
INFO - 2023-09-03 14:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 14:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 14:56:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 14:56:59 --> Final output sent to browser
DEBUG - 2023-09-03 14:56:59 --> Total execution time: 0.0687
ERROR - 2023-09-03 14:57:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:57:01 --> Config Class Initialized
INFO - 2023-09-03 14:57:01 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:57:01 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:57:01 --> Utf8 Class Initialized
INFO - 2023-09-03 14:57:01 --> URI Class Initialized
INFO - 2023-09-03 14:57:01 --> Router Class Initialized
INFO - 2023-09-03 14:57:01 --> Output Class Initialized
INFO - 2023-09-03 14:57:01 --> Security Class Initialized
DEBUG - 2023-09-03 14:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:57:01 --> Input Class Initialized
INFO - 2023-09-03 14:57:01 --> Language Class Initialized
INFO - 2023-09-03 14:57:01 --> Loader Class Initialized
INFO - 2023-09-03 14:57:01 --> Helper loaded: url_helper
INFO - 2023-09-03 14:57:01 --> Helper loaded: file_helper
INFO - 2023-09-03 14:57:01 --> Helper loaded: html_helper
INFO - 2023-09-03 14:57:01 --> Helper loaded: text_helper
INFO - 2023-09-03 14:57:01 --> Helper loaded: form_helper
INFO - 2023-09-03 14:57:01 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:57:01 --> Helper loaded: security_helper
INFO - 2023-09-03 14:57:01 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:57:01 --> Database Driver Class Initialized
INFO - 2023-09-03 14:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:57:01 --> Parser Class Initialized
INFO - 2023-09-03 14:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:57:01 --> Pagination Class Initialized
INFO - 2023-09-03 14:57:01 --> Form Validation Class Initialized
INFO - 2023-09-03 14:57:01 --> Controller Class Initialized
DEBUG - 2023-09-03 14:57:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:57:01 --> Model Class Initialized
INFO - 2023-09-03 14:57:01 --> Final output sent to browser
DEBUG - 2023-09-03 14:57:01 --> Total execution time: 0.0212
ERROR - 2023-09-03 14:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:58:11 --> Config Class Initialized
INFO - 2023-09-03 14:58:11 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:58:11 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:58:11 --> Utf8 Class Initialized
INFO - 2023-09-03 14:58:11 --> URI Class Initialized
DEBUG - 2023-09-03 14:58:11 --> No URI present. Default controller set.
INFO - 2023-09-03 14:58:11 --> Router Class Initialized
INFO - 2023-09-03 14:58:11 --> Output Class Initialized
INFO - 2023-09-03 14:58:11 --> Security Class Initialized
DEBUG - 2023-09-03 14:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:58:11 --> Input Class Initialized
INFO - 2023-09-03 14:58:11 --> Language Class Initialized
INFO - 2023-09-03 14:58:11 --> Loader Class Initialized
INFO - 2023-09-03 14:58:11 --> Helper loaded: url_helper
INFO - 2023-09-03 14:58:11 --> Helper loaded: file_helper
INFO - 2023-09-03 14:58:11 --> Helper loaded: html_helper
INFO - 2023-09-03 14:58:11 --> Helper loaded: text_helper
INFO - 2023-09-03 14:58:11 --> Helper loaded: form_helper
INFO - 2023-09-03 14:58:11 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:58:11 --> Helper loaded: security_helper
INFO - 2023-09-03 14:58:11 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:58:11 --> Database Driver Class Initialized
INFO - 2023-09-03 14:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:58:11 --> Parser Class Initialized
INFO - 2023-09-03 14:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:58:11 --> Pagination Class Initialized
INFO - 2023-09-03 14:58:11 --> Form Validation Class Initialized
INFO - 2023-09-03 14:58:11 --> Controller Class Initialized
INFO - 2023-09-03 14:58:11 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:11 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:11 --> Model Class Initialized
INFO - 2023-09-03 14:58:11 --> Model Class Initialized
INFO - 2023-09-03 14:58:11 --> Model Class Initialized
INFO - 2023-09-03 14:58:11 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:11 --> Model Class Initialized
INFO - 2023-09-03 14:58:11 --> Model Class Initialized
INFO - 2023-09-03 14:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 14:58:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 14:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 14:58:11 --> Model Class Initialized
INFO - 2023-09-03 14:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 14:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 14:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 14:58:11 --> Final output sent to browser
DEBUG - 2023-09-03 14:58:11 --> Total execution time: 0.0852
ERROR - 2023-09-03 14:58:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:58:12 --> Config Class Initialized
INFO - 2023-09-03 14:58:12 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:58:12 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:58:12 --> Utf8 Class Initialized
INFO - 2023-09-03 14:58:12 --> URI Class Initialized
INFO - 2023-09-03 14:58:12 --> Router Class Initialized
INFO - 2023-09-03 14:58:12 --> Output Class Initialized
INFO - 2023-09-03 14:58:12 --> Security Class Initialized
DEBUG - 2023-09-03 14:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:58:12 --> Input Class Initialized
INFO - 2023-09-03 14:58:12 --> Language Class Initialized
INFO - 2023-09-03 14:58:12 --> Loader Class Initialized
INFO - 2023-09-03 14:58:12 --> Helper loaded: url_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: file_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: html_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: text_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: form_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: security_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:58:12 --> Database Driver Class Initialized
INFO - 2023-09-03 14:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:58:12 --> Parser Class Initialized
INFO - 2023-09-03 14:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:58:12 --> Pagination Class Initialized
INFO - 2023-09-03 14:58:12 --> Form Validation Class Initialized
INFO - 2023-09-03 14:58:12 --> Controller Class Initialized
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 14:58:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 14:58:12 --> Final output sent to browser
DEBUG - 2023-09-03 14:58:12 --> Total execution time: 0.0280
ERROR - 2023-09-03 14:58:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:58:12 --> Config Class Initialized
INFO - 2023-09-03 14:58:12 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:58:12 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:58:12 --> Utf8 Class Initialized
INFO - 2023-09-03 14:58:12 --> URI Class Initialized
INFO - 2023-09-03 14:58:12 --> Router Class Initialized
INFO - 2023-09-03 14:58:12 --> Output Class Initialized
INFO - 2023-09-03 14:58:12 --> Security Class Initialized
DEBUG - 2023-09-03 14:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:58:12 --> Input Class Initialized
INFO - 2023-09-03 14:58:12 --> Language Class Initialized
INFO - 2023-09-03 14:58:12 --> Loader Class Initialized
INFO - 2023-09-03 14:58:12 --> Helper loaded: url_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: file_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: html_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: text_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: form_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: security_helper
INFO - 2023-09-03 14:58:12 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:58:12 --> Database Driver Class Initialized
INFO - 2023-09-03 14:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:58:12 --> Parser Class Initialized
INFO - 2023-09-03 14:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:58:12 --> Pagination Class Initialized
INFO - 2023-09-03 14:58:12 --> Form Validation Class Initialized
INFO - 2023-09-03 14:58:12 --> Controller Class Initialized
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 14:58:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 14:58:12 --> Model Class Initialized
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 14:58:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 14:58:12 --> Final output sent to browser
DEBUG - 2023-09-03 14:58:12 --> Total execution time: 0.0919
ERROR - 2023-09-03 14:58:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:58:32 --> Config Class Initialized
INFO - 2023-09-03 14:58:32 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:58:32 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:58:32 --> Utf8 Class Initialized
INFO - 2023-09-03 14:58:32 --> URI Class Initialized
DEBUG - 2023-09-03 14:58:32 --> No URI present. Default controller set.
INFO - 2023-09-03 14:58:32 --> Router Class Initialized
INFO - 2023-09-03 14:58:32 --> Output Class Initialized
INFO - 2023-09-03 14:58:32 --> Security Class Initialized
DEBUG - 2023-09-03 14:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:58:32 --> Input Class Initialized
INFO - 2023-09-03 14:58:32 --> Language Class Initialized
INFO - 2023-09-03 14:58:32 --> Loader Class Initialized
INFO - 2023-09-03 14:58:32 --> Helper loaded: url_helper
INFO - 2023-09-03 14:58:32 --> Helper loaded: file_helper
INFO - 2023-09-03 14:58:32 --> Helper loaded: html_helper
INFO - 2023-09-03 14:58:32 --> Helper loaded: text_helper
INFO - 2023-09-03 14:58:32 --> Helper loaded: form_helper
INFO - 2023-09-03 14:58:32 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:58:32 --> Helper loaded: security_helper
INFO - 2023-09-03 14:58:32 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:58:32 --> Database Driver Class Initialized
INFO - 2023-09-03 14:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:58:32 --> Parser Class Initialized
INFO - 2023-09-03 14:58:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:58:32 --> Pagination Class Initialized
INFO - 2023-09-03 14:58:32 --> Form Validation Class Initialized
INFO - 2023-09-03 14:58:32 --> Controller Class Initialized
INFO - 2023-09-03 14:58:32 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:32 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:32 --> Model Class Initialized
INFO - 2023-09-03 14:58:32 --> Model Class Initialized
INFO - 2023-09-03 14:58:32 --> Model Class Initialized
INFO - 2023-09-03 14:58:32 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:32 --> Model Class Initialized
INFO - 2023-09-03 14:58:32 --> Model Class Initialized
INFO - 2023-09-03 14:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 14:58:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 14:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 14:58:32 --> Model Class Initialized
INFO - 2023-09-03 14:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 14:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 14:58:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 14:58:32 --> Final output sent to browser
DEBUG - 2023-09-03 14:58:32 --> Total execution time: 0.0849
ERROR - 2023-09-03 14:58:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:58:43 --> Config Class Initialized
INFO - 2023-09-03 14:58:43 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:58:43 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:58:43 --> Utf8 Class Initialized
INFO - 2023-09-03 14:58:43 --> URI Class Initialized
INFO - 2023-09-03 14:58:43 --> Router Class Initialized
INFO - 2023-09-03 14:58:43 --> Output Class Initialized
INFO - 2023-09-03 14:58:43 --> Security Class Initialized
DEBUG - 2023-09-03 14:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:58:43 --> Input Class Initialized
INFO - 2023-09-03 14:58:43 --> Language Class Initialized
INFO - 2023-09-03 14:58:43 --> Loader Class Initialized
INFO - 2023-09-03 14:58:43 --> Helper loaded: url_helper
INFO - 2023-09-03 14:58:43 --> Helper loaded: file_helper
INFO - 2023-09-03 14:58:43 --> Helper loaded: html_helper
INFO - 2023-09-03 14:58:43 --> Helper loaded: text_helper
INFO - 2023-09-03 14:58:43 --> Helper loaded: form_helper
INFO - 2023-09-03 14:58:43 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:58:43 --> Helper loaded: security_helper
INFO - 2023-09-03 14:58:43 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:58:43 --> Database Driver Class Initialized
INFO - 2023-09-03 14:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:58:43 --> Parser Class Initialized
INFO - 2023-09-03 14:58:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:58:43 --> Pagination Class Initialized
INFO - 2023-09-03 14:58:43 --> Form Validation Class Initialized
INFO - 2023-09-03 14:58:43 --> Controller Class Initialized
DEBUG - 2023-09-03 14:58:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:43 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:43 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:43 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:43 --> Model Class Initialized
DEBUG - 2023-09-03 14:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:43 --> Model Class Initialized
INFO - 2023-09-03 14:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-09-03 14:58:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 14:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 14:58:43 --> Model Class Initialized
INFO - 2023-09-03 14:58:43 --> Model Class Initialized
INFO - 2023-09-03 14:58:43 --> Model Class Initialized
INFO - 2023-09-03 14:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 14:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 14:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 14:58:43 --> Final output sent to browser
DEBUG - 2023-09-03 14:58:43 --> Total execution time: 0.0713
ERROR - 2023-09-03 14:58:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 14:58:44 --> Config Class Initialized
INFO - 2023-09-03 14:58:44 --> Hooks Class Initialized
DEBUG - 2023-09-03 14:58:44 --> UTF-8 Support Enabled
INFO - 2023-09-03 14:58:44 --> Utf8 Class Initialized
INFO - 2023-09-03 14:58:44 --> URI Class Initialized
INFO - 2023-09-03 14:58:44 --> Router Class Initialized
INFO - 2023-09-03 14:58:44 --> Output Class Initialized
INFO - 2023-09-03 14:58:44 --> Security Class Initialized
DEBUG - 2023-09-03 14:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 14:58:44 --> Input Class Initialized
INFO - 2023-09-03 14:58:44 --> Language Class Initialized
INFO - 2023-09-03 14:58:44 --> Loader Class Initialized
INFO - 2023-09-03 14:58:44 --> Helper loaded: url_helper
INFO - 2023-09-03 14:58:44 --> Helper loaded: file_helper
INFO - 2023-09-03 14:58:44 --> Helper loaded: html_helper
INFO - 2023-09-03 14:58:44 --> Helper loaded: text_helper
INFO - 2023-09-03 14:58:44 --> Helper loaded: form_helper
INFO - 2023-09-03 14:58:44 --> Helper loaded: lang_helper
INFO - 2023-09-03 14:58:44 --> Helper loaded: security_helper
INFO - 2023-09-03 14:58:44 --> Helper loaded: cookie_helper
INFO - 2023-09-03 14:58:44 --> Database Driver Class Initialized
INFO - 2023-09-03 14:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 14:58:44 --> Parser Class Initialized
INFO - 2023-09-03 14:58:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 14:58:44 --> Pagination Class Initialized
INFO - 2023-09-03 14:58:44 --> Form Validation Class Initialized
INFO - 2023-09-03 14:58:44 --> Controller Class Initialized
DEBUG - 2023-09-03 14:58:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 14:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 14:58:44 --> Model Class Initialized
INFO - 2023-09-03 14:58:44 --> Final output sent to browser
DEBUG - 2023-09-03 14:58:44 --> Total execution time: 0.0272
ERROR - 2023-09-03 15:02:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 15:02:27 --> Config Class Initialized
INFO - 2023-09-03 15:02:27 --> Hooks Class Initialized
DEBUG - 2023-09-03 15:02:27 --> UTF-8 Support Enabled
INFO - 2023-09-03 15:02:27 --> Utf8 Class Initialized
INFO - 2023-09-03 15:02:27 --> URI Class Initialized
DEBUG - 2023-09-03 15:02:27 --> No URI present. Default controller set.
INFO - 2023-09-03 15:02:27 --> Router Class Initialized
INFO - 2023-09-03 15:02:27 --> Output Class Initialized
INFO - 2023-09-03 15:02:27 --> Security Class Initialized
DEBUG - 2023-09-03 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 15:02:27 --> Input Class Initialized
INFO - 2023-09-03 15:02:27 --> Language Class Initialized
INFO - 2023-09-03 15:02:27 --> Loader Class Initialized
INFO - 2023-09-03 15:02:27 --> Helper loaded: url_helper
INFO - 2023-09-03 15:02:27 --> Helper loaded: file_helper
INFO - 2023-09-03 15:02:27 --> Helper loaded: html_helper
INFO - 2023-09-03 15:02:27 --> Helper loaded: text_helper
INFO - 2023-09-03 15:02:27 --> Helper loaded: form_helper
INFO - 2023-09-03 15:02:27 --> Helper loaded: lang_helper
INFO - 2023-09-03 15:02:27 --> Helper loaded: security_helper
INFO - 2023-09-03 15:02:27 --> Helper loaded: cookie_helper
INFO - 2023-09-03 15:02:27 --> Database Driver Class Initialized
INFO - 2023-09-03 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 15:02:27 --> Parser Class Initialized
INFO - 2023-09-03 15:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 15:02:27 --> Pagination Class Initialized
INFO - 2023-09-03 15:02:27 --> Form Validation Class Initialized
INFO - 2023-09-03 15:02:27 --> Controller Class Initialized
INFO - 2023-09-03 15:02:27 --> Model Class Initialized
DEBUG - 2023-09-03 15:02:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 15:02:27 --> Model Class Initialized
DEBUG - 2023-09-03 15:02:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 15:02:27 --> Model Class Initialized
INFO - 2023-09-03 15:02:27 --> Model Class Initialized
INFO - 2023-09-03 15:02:27 --> Model Class Initialized
INFO - 2023-09-03 15:02:27 --> Model Class Initialized
DEBUG - 2023-09-03 15:02:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-03 15:02:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 15:02:27 --> Model Class Initialized
INFO - 2023-09-03 15:02:27 --> Model Class Initialized
INFO - 2023-09-03 15:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-03 15:02:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 15:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 15:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 15:02:27 --> Model Class Initialized
INFO - 2023-09-03 15:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-03 15:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-03 15:02:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 15:02:27 --> Final output sent to browser
DEBUG - 2023-09-03 15:02:27 --> Total execution time: 0.0918
ERROR - 2023-09-03 17:36:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 17:36:29 --> Config Class Initialized
INFO - 2023-09-03 17:36:29 --> Hooks Class Initialized
DEBUG - 2023-09-03 17:36:29 --> UTF-8 Support Enabled
INFO - 2023-09-03 17:36:29 --> Utf8 Class Initialized
INFO - 2023-09-03 17:36:29 --> URI Class Initialized
DEBUG - 2023-09-03 17:36:29 --> No URI present. Default controller set.
INFO - 2023-09-03 17:36:29 --> Router Class Initialized
INFO - 2023-09-03 17:36:29 --> Output Class Initialized
INFO - 2023-09-03 17:36:29 --> Security Class Initialized
DEBUG - 2023-09-03 17:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 17:36:29 --> Input Class Initialized
INFO - 2023-09-03 17:36:29 --> Language Class Initialized
INFO - 2023-09-03 17:36:29 --> Loader Class Initialized
INFO - 2023-09-03 17:36:29 --> Helper loaded: url_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: file_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: html_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: text_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: form_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: lang_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: security_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: cookie_helper
INFO - 2023-09-03 17:36:29 --> Database Driver Class Initialized
INFO - 2023-09-03 17:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 17:36:29 --> Parser Class Initialized
INFO - 2023-09-03 17:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 17:36:29 --> Pagination Class Initialized
INFO - 2023-09-03 17:36:29 --> Form Validation Class Initialized
INFO - 2023-09-03 17:36:29 --> Controller Class Initialized
INFO - 2023-09-03 17:36:29 --> Model Class Initialized
DEBUG - 2023-09-03 17:36:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-03 17:36:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 17:36:29 --> Config Class Initialized
INFO - 2023-09-03 17:36:29 --> Hooks Class Initialized
DEBUG - 2023-09-03 17:36:29 --> UTF-8 Support Enabled
INFO - 2023-09-03 17:36:29 --> Utf8 Class Initialized
INFO - 2023-09-03 17:36:29 --> URI Class Initialized
INFO - 2023-09-03 17:36:29 --> Router Class Initialized
INFO - 2023-09-03 17:36:29 --> Output Class Initialized
INFO - 2023-09-03 17:36:29 --> Security Class Initialized
DEBUG - 2023-09-03 17:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 17:36:29 --> Input Class Initialized
INFO - 2023-09-03 17:36:29 --> Language Class Initialized
INFO - 2023-09-03 17:36:29 --> Loader Class Initialized
INFO - 2023-09-03 17:36:29 --> Helper loaded: url_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: file_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: html_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: text_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: form_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: lang_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: security_helper
INFO - 2023-09-03 17:36:29 --> Helper loaded: cookie_helper
INFO - 2023-09-03 17:36:29 --> Database Driver Class Initialized
INFO - 2023-09-03 17:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 17:36:29 --> Parser Class Initialized
INFO - 2023-09-03 17:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 17:36:29 --> Pagination Class Initialized
INFO - 2023-09-03 17:36:29 --> Form Validation Class Initialized
INFO - 2023-09-03 17:36:29 --> Controller Class Initialized
INFO - 2023-09-03 17:36:29 --> Model Class Initialized
DEBUG - 2023-09-03 17:36:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 17:36:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 17:36:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 17:36:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 17:36:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 17:36:29 --> Model Class Initialized
INFO - 2023-09-03 17:36:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 17:36:29 --> Final output sent to browser
DEBUG - 2023-09-03 17:36:29 --> Total execution time: 0.0348
ERROR - 2023-09-03 17:37:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 17:37:03 --> Config Class Initialized
INFO - 2023-09-03 17:37:03 --> Hooks Class Initialized
DEBUG - 2023-09-03 17:37:03 --> UTF-8 Support Enabled
INFO - 2023-09-03 17:37:03 --> Utf8 Class Initialized
INFO - 2023-09-03 17:37:03 --> URI Class Initialized
INFO - 2023-09-03 17:37:03 --> Router Class Initialized
INFO - 2023-09-03 17:37:03 --> Output Class Initialized
INFO - 2023-09-03 17:37:03 --> Security Class Initialized
DEBUG - 2023-09-03 17:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 17:37:03 --> Input Class Initialized
INFO - 2023-09-03 17:37:03 --> Language Class Initialized
INFO - 2023-09-03 17:37:03 --> Loader Class Initialized
INFO - 2023-09-03 17:37:03 --> Helper loaded: url_helper
INFO - 2023-09-03 17:37:03 --> Helper loaded: file_helper
INFO - 2023-09-03 17:37:03 --> Helper loaded: html_helper
INFO - 2023-09-03 17:37:03 --> Helper loaded: text_helper
INFO - 2023-09-03 17:37:03 --> Helper loaded: form_helper
INFO - 2023-09-03 17:37:03 --> Helper loaded: lang_helper
INFO - 2023-09-03 17:37:03 --> Helper loaded: security_helper
INFO - 2023-09-03 17:37:03 --> Helper loaded: cookie_helper
INFO - 2023-09-03 17:37:03 --> Database Driver Class Initialized
INFO - 2023-09-03 17:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 17:37:03 --> Parser Class Initialized
INFO - 2023-09-03 17:37:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 17:37:03 --> Pagination Class Initialized
INFO - 2023-09-03 17:37:03 --> Form Validation Class Initialized
INFO - 2023-09-03 17:37:03 --> Controller Class Initialized
INFO - 2023-09-03 17:37:03 --> Model Class Initialized
DEBUG - 2023-09-03 17:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 17:37:03 --> Model Class Initialized
INFO - 2023-09-03 17:37:03 --> Final output sent to browser
DEBUG - 2023-09-03 17:37:03 --> Total execution time: 0.0216
ERROR - 2023-09-03 17:37:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 17:37:04 --> Config Class Initialized
INFO - 2023-09-03 17:37:04 --> Hooks Class Initialized
DEBUG - 2023-09-03 17:37:04 --> UTF-8 Support Enabled
INFO - 2023-09-03 17:37:04 --> Utf8 Class Initialized
INFO - 2023-09-03 17:37:04 --> URI Class Initialized
INFO - 2023-09-03 17:37:04 --> Router Class Initialized
INFO - 2023-09-03 17:37:04 --> Output Class Initialized
INFO - 2023-09-03 17:37:04 --> Security Class Initialized
DEBUG - 2023-09-03 17:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 17:37:04 --> Input Class Initialized
INFO - 2023-09-03 17:37:04 --> Language Class Initialized
INFO - 2023-09-03 17:37:04 --> Loader Class Initialized
INFO - 2023-09-03 17:37:04 --> Helper loaded: url_helper
INFO - 2023-09-03 17:37:04 --> Helper loaded: file_helper
INFO - 2023-09-03 17:37:04 --> Helper loaded: html_helper
INFO - 2023-09-03 17:37:04 --> Helper loaded: text_helper
INFO - 2023-09-03 17:37:04 --> Helper loaded: form_helper
INFO - 2023-09-03 17:37:04 --> Helper loaded: lang_helper
INFO - 2023-09-03 17:37:04 --> Helper loaded: security_helper
INFO - 2023-09-03 17:37:04 --> Helper loaded: cookie_helper
INFO - 2023-09-03 17:37:04 --> Database Driver Class Initialized
INFO - 2023-09-03 17:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 17:37:04 --> Parser Class Initialized
INFO - 2023-09-03 17:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 17:37:04 --> Pagination Class Initialized
INFO - 2023-09-03 17:37:04 --> Form Validation Class Initialized
INFO - 2023-09-03 17:37:04 --> Controller Class Initialized
INFO - 2023-09-03 17:37:04 --> Model Class Initialized
DEBUG - 2023-09-03 17:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 17:37:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 17:37:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 17:37:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 17:37:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 17:37:04 --> Model Class Initialized
INFO - 2023-09-03 17:37:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 17:37:04 --> Final output sent to browser
DEBUG - 2023-09-03 17:37:04 --> Total execution time: 0.0367
ERROR - 2023-09-03 17:37:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-03 17:37:12 --> Config Class Initialized
INFO - 2023-09-03 17:37:12 --> Hooks Class Initialized
DEBUG - 2023-09-03 17:37:12 --> UTF-8 Support Enabled
INFO - 2023-09-03 17:37:12 --> Utf8 Class Initialized
INFO - 2023-09-03 17:37:12 --> URI Class Initialized
INFO - 2023-09-03 17:37:12 --> Router Class Initialized
INFO - 2023-09-03 17:37:12 --> Output Class Initialized
INFO - 2023-09-03 17:37:12 --> Security Class Initialized
DEBUG - 2023-09-03 17:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 17:37:12 --> Input Class Initialized
INFO - 2023-09-03 17:37:12 --> Language Class Initialized
INFO - 2023-09-03 17:37:12 --> Loader Class Initialized
INFO - 2023-09-03 17:37:12 --> Helper loaded: url_helper
INFO - 2023-09-03 17:37:12 --> Helper loaded: file_helper
INFO - 2023-09-03 17:37:12 --> Helper loaded: html_helper
INFO - 2023-09-03 17:37:12 --> Helper loaded: text_helper
INFO - 2023-09-03 17:37:12 --> Helper loaded: form_helper
INFO - 2023-09-03 17:37:12 --> Helper loaded: lang_helper
INFO - 2023-09-03 17:37:12 --> Helper loaded: security_helper
INFO - 2023-09-03 17:37:12 --> Helper loaded: cookie_helper
INFO - 2023-09-03 17:37:12 --> Database Driver Class Initialized
INFO - 2023-09-03 17:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 17:37:12 --> Parser Class Initialized
INFO - 2023-09-03 17:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-03 17:37:12 --> Pagination Class Initialized
INFO - 2023-09-03 17:37:12 --> Form Validation Class Initialized
INFO - 2023-09-03 17:37:12 --> Controller Class Initialized
INFO - 2023-09-03 17:37:12 --> Model Class Initialized
DEBUG - 2023-09-03 17:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-03 17:37:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-03 17:37:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-03 17:37:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-03 17:37:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-03 17:37:12 --> Model Class Initialized
INFO - 2023-09-03 17:37:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-03 17:37:12 --> Final output sent to browser
DEBUG - 2023-09-03 17:37:12 --> Total execution time: 0.0293
