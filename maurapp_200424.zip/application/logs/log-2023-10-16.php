<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-16 01:26:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 01:26:36 --> Config Class Initialized
INFO - 2023-10-16 01:26:36 --> Hooks Class Initialized
DEBUG - 2023-10-16 01:26:36 --> UTF-8 Support Enabled
INFO - 2023-10-16 01:26:36 --> Utf8 Class Initialized
INFO - 2023-10-16 01:26:36 --> URI Class Initialized
INFO - 2023-10-16 01:26:36 --> Router Class Initialized
INFO - 2023-10-16 01:26:36 --> Output Class Initialized
INFO - 2023-10-16 01:26:36 --> Security Class Initialized
DEBUG - 2023-10-16 01:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 01:26:36 --> Input Class Initialized
INFO - 2023-10-16 01:26:36 --> Language Class Initialized
INFO - 2023-10-16 01:26:36 --> Loader Class Initialized
INFO - 2023-10-16 01:26:36 --> Helper loaded: url_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: file_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: html_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: text_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: form_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: lang_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: security_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: cookie_helper
INFO - 2023-10-16 01:26:36 --> Database Driver Class Initialized
INFO - 2023-10-16 01:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 01:26:36 --> Parser Class Initialized
INFO - 2023-10-16 01:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 01:26:36 --> Pagination Class Initialized
INFO - 2023-10-16 01:26:36 --> Form Validation Class Initialized
INFO - 2023-10-16 01:26:36 --> Controller Class Initialized
ERROR - 2023-10-16 01:26:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 01:26:36 --> Config Class Initialized
INFO - 2023-10-16 01:26:36 --> Hooks Class Initialized
DEBUG - 2023-10-16 01:26:36 --> UTF-8 Support Enabled
INFO - 2023-10-16 01:26:36 --> Utf8 Class Initialized
INFO - 2023-10-16 01:26:36 --> URI Class Initialized
INFO - 2023-10-16 01:26:36 --> Router Class Initialized
INFO - 2023-10-16 01:26:36 --> Output Class Initialized
INFO - 2023-10-16 01:26:36 --> Security Class Initialized
DEBUG - 2023-10-16 01:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 01:26:36 --> Input Class Initialized
INFO - 2023-10-16 01:26:36 --> Language Class Initialized
INFO - 2023-10-16 01:26:36 --> Loader Class Initialized
INFO - 2023-10-16 01:26:36 --> Helper loaded: url_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: file_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: html_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: text_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: form_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: lang_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: security_helper
INFO - 2023-10-16 01:26:36 --> Helper loaded: cookie_helper
INFO - 2023-10-16 01:26:36 --> Database Driver Class Initialized
INFO - 2023-10-16 01:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 01:26:36 --> Parser Class Initialized
INFO - 2023-10-16 01:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 01:26:36 --> Pagination Class Initialized
INFO - 2023-10-16 01:26:36 --> Form Validation Class Initialized
INFO - 2023-10-16 01:26:36 --> Controller Class Initialized
INFO - 2023-10-16 01:26:36 --> Model Class Initialized
DEBUG - 2023-10-16 01:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 01:26:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-16 01:26:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 01:26:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 01:26:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 01:26:36 --> Model Class Initialized
INFO - 2023-10-16 01:26:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 01:26:36 --> Final output sent to browser
DEBUG - 2023-10-16 01:26:36 --> Total execution time: 0.0349
ERROR - 2023-10-16 01:26:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 01:26:37 --> Config Class Initialized
INFO - 2023-10-16 01:26:37 --> Hooks Class Initialized
DEBUG - 2023-10-16 01:26:37 --> UTF-8 Support Enabled
INFO - 2023-10-16 01:26:37 --> Utf8 Class Initialized
INFO - 2023-10-16 01:26:37 --> URI Class Initialized
INFO - 2023-10-16 01:26:37 --> Router Class Initialized
INFO - 2023-10-16 01:26:37 --> Output Class Initialized
INFO - 2023-10-16 01:26:37 --> Security Class Initialized
DEBUG - 2023-10-16 01:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 01:26:37 --> Input Class Initialized
INFO - 2023-10-16 01:26:37 --> Language Class Initialized
ERROR - 2023-10-16 01:26:37 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2023-10-16 01:26:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 01:26:37 --> Config Class Initialized
INFO - 2023-10-16 01:26:37 --> Hooks Class Initialized
DEBUG - 2023-10-16 01:26:37 --> UTF-8 Support Enabled
INFO - 2023-10-16 01:26:37 --> Utf8 Class Initialized
INFO - 2023-10-16 01:26:37 --> URI Class Initialized
INFO - 2023-10-16 01:26:37 --> Router Class Initialized
INFO - 2023-10-16 01:26:37 --> Output Class Initialized
INFO - 2023-10-16 01:26:37 --> Security Class Initialized
DEBUG - 2023-10-16 01:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 01:26:37 --> Input Class Initialized
INFO - 2023-10-16 01:26:37 --> Language Class Initialized
ERROR - 2023-10-16 01:26:37 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2023-10-16 01:26:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 01:26:38 --> Config Class Initialized
INFO - 2023-10-16 01:26:38 --> Hooks Class Initialized
DEBUG - 2023-10-16 01:26:38 --> UTF-8 Support Enabled
INFO - 2023-10-16 01:26:38 --> Utf8 Class Initialized
INFO - 2023-10-16 01:26:38 --> URI Class Initialized
INFO - 2023-10-16 01:26:38 --> Router Class Initialized
INFO - 2023-10-16 01:26:38 --> Output Class Initialized
INFO - 2023-10-16 01:26:38 --> Security Class Initialized
DEBUG - 2023-10-16 01:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 01:26:38 --> Input Class Initialized
INFO - 2023-10-16 01:26:38 --> Language Class Initialized
ERROR - 2023-10-16 01:26:38 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-10-16 01:26:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 01:26:38 --> Config Class Initialized
INFO - 2023-10-16 01:26:38 --> Hooks Class Initialized
DEBUG - 2023-10-16 01:26:38 --> UTF-8 Support Enabled
INFO - 2023-10-16 01:26:38 --> Utf8 Class Initialized
INFO - 2023-10-16 01:26:38 --> URI Class Initialized
INFO - 2023-10-16 01:26:38 --> Router Class Initialized
INFO - 2023-10-16 01:26:38 --> Output Class Initialized
INFO - 2023-10-16 01:26:38 --> Security Class Initialized
DEBUG - 2023-10-16 01:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 01:26:38 --> Input Class Initialized
INFO - 2023-10-16 01:26:38 --> Language Class Initialized
ERROR - 2023-10-16 01:26:38 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-10-16 01:32:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 01:32:36 --> Config Class Initialized
INFO - 2023-10-16 01:32:36 --> Hooks Class Initialized
DEBUG - 2023-10-16 01:32:36 --> UTF-8 Support Enabled
INFO - 2023-10-16 01:32:36 --> Utf8 Class Initialized
INFO - 2023-10-16 01:32:36 --> URI Class Initialized
DEBUG - 2023-10-16 01:32:36 --> No URI present. Default controller set.
INFO - 2023-10-16 01:32:36 --> Router Class Initialized
INFO - 2023-10-16 01:32:36 --> Output Class Initialized
INFO - 2023-10-16 01:32:36 --> Security Class Initialized
DEBUG - 2023-10-16 01:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 01:32:36 --> Input Class Initialized
INFO - 2023-10-16 01:32:36 --> Language Class Initialized
INFO - 2023-10-16 01:32:36 --> Loader Class Initialized
INFO - 2023-10-16 01:32:36 --> Helper loaded: url_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: file_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: html_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: text_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: form_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: lang_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: security_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: cookie_helper
INFO - 2023-10-16 01:32:36 --> Database Driver Class Initialized
INFO - 2023-10-16 01:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 01:32:36 --> Parser Class Initialized
INFO - 2023-10-16 01:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 01:32:36 --> Pagination Class Initialized
INFO - 2023-10-16 01:32:36 --> Form Validation Class Initialized
INFO - 2023-10-16 01:32:36 --> Controller Class Initialized
INFO - 2023-10-16 01:32:36 --> Model Class Initialized
DEBUG - 2023-10-16 01:32:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-16 01:32:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 01:32:36 --> Config Class Initialized
INFO - 2023-10-16 01:32:36 --> Hooks Class Initialized
DEBUG - 2023-10-16 01:32:36 --> UTF-8 Support Enabled
INFO - 2023-10-16 01:32:36 --> Utf8 Class Initialized
INFO - 2023-10-16 01:32:36 --> URI Class Initialized
INFO - 2023-10-16 01:32:36 --> Router Class Initialized
INFO - 2023-10-16 01:32:36 --> Output Class Initialized
INFO - 2023-10-16 01:32:36 --> Security Class Initialized
DEBUG - 2023-10-16 01:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 01:32:36 --> Input Class Initialized
INFO - 2023-10-16 01:32:36 --> Language Class Initialized
INFO - 2023-10-16 01:32:36 --> Loader Class Initialized
INFO - 2023-10-16 01:32:36 --> Helper loaded: url_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: file_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: html_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: text_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: form_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: lang_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: security_helper
INFO - 2023-10-16 01:32:36 --> Helper loaded: cookie_helper
INFO - 2023-10-16 01:32:36 --> Database Driver Class Initialized
INFO - 2023-10-16 01:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 01:32:36 --> Parser Class Initialized
INFO - 2023-10-16 01:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 01:32:36 --> Pagination Class Initialized
INFO - 2023-10-16 01:32:36 --> Form Validation Class Initialized
INFO - 2023-10-16 01:32:36 --> Controller Class Initialized
INFO - 2023-10-16 01:32:36 --> Model Class Initialized
DEBUG - 2023-10-16 01:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 01:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-16 01:32:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 01:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 01:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 01:32:36 --> Model Class Initialized
INFO - 2023-10-16 01:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 01:32:36 --> Final output sent to browser
DEBUG - 2023-10-16 01:32:36 --> Total execution time: 0.0310
ERROR - 2023-10-16 03:00:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 03:00:50 --> Config Class Initialized
INFO - 2023-10-16 03:00:50 --> Hooks Class Initialized
DEBUG - 2023-10-16 03:00:50 --> UTF-8 Support Enabled
INFO - 2023-10-16 03:00:50 --> Utf8 Class Initialized
INFO - 2023-10-16 03:00:50 --> URI Class Initialized
INFO - 2023-10-16 03:00:50 --> Router Class Initialized
INFO - 2023-10-16 03:00:50 --> Output Class Initialized
INFO - 2023-10-16 03:00:50 --> Security Class Initialized
DEBUG - 2023-10-16 03:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 03:00:50 --> Input Class Initialized
INFO - 2023-10-16 03:00:50 --> Language Class Initialized
ERROR - 2023-10-16 03:00:50 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-16 05:13:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 05:13:54 --> Config Class Initialized
INFO - 2023-10-16 05:13:54 --> Hooks Class Initialized
DEBUG - 2023-10-16 05:13:54 --> UTF-8 Support Enabled
INFO - 2023-10-16 05:13:54 --> Utf8 Class Initialized
INFO - 2023-10-16 05:13:54 --> URI Class Initialized
DEBUG - 2023-10-16 05:13:54 --> No URI present. Default controller set.
INFO - 2023-10-16 05:13:54 --> Router Class Initialized
INFO - 2023-10-16 05:13:54 --> Output Class Initialized
INFO - 2023-10-16 05:13:54 --> Security Class Initialized
DEBUG - 2023-10-16 05:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 05:13:54 --> Input Class Initialized
INFO - 2023-10-16 05:13:54 --> Language Class Initialized
INFO - 2023-10-16 05:13:54 --> Loader Class Initialized
INFO - 2023-10-16 05:13:54 --> Helper loaded: url_helper
INFO - 2023-10-16 05:13:54 --> Helper loaded: file_helper
INFO - 2023-10-16 05:13:54 --> Helper loaded: html_helper
INFO - 2023-10-16 05:13:54 --> Helper loaded: text_helper
INFO - 2023-10-16 05:13:54 --> Helper loaded: form_helper
INFO - 2023-10-16 05:13:54 --> Helper loaded: lang_helper
INFO - 2023-10-16 05:13:54 --> Helper loaded: security_helper
INFO - 2023-10-16 05:13:54 --> Helper loaded: cookie_helper
INFO - 2023-10-16 05:13:54 --> Database Driver Class Initialized
INFO - 2023-10-16 05:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 05:13:54 --> Parser Class Initialized
INFO - 2023-10-16 05:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 05:13:54 --> Pagination Class Initialized
INFO - 2023-10-16 05:13:54 --> Form Validation Class Initialized
INFO - 2023-10-16 05:13:54 --> Controller Class Initialized
INFO - 2023-10-16 05:13:54 --> Model Class Initialized
DEBUG - 2023-10-16 05:13:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-16 05:13:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 05:13:55 --> Config Class Initialized
INFO - 2023-10-16 05:13:55 --> Hooks Class Initialized
DEBUG - 2023-10-16 05:13:55 --> UTF-8 Support Enabled
INFO - 2023-10-16 05:13:55 --> Utf8 Class Initialized
INFO - 2023-10-16 05:13:55 --> URI Class Initialized
INFO - 2023-10-16 05:13:55 --> Router Class Initialized
INFO - 2023-10-16 05:13:55 --> Output Class Initialized
INFO - 2023-10-16 05:13:55 --> Security Class Initialized
DEBUG - 2023-10-16 05:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 05:13:55 --> Input Class Initialized
INFO - 2023-10-16 05:13:55 --> Language Class Initialized
INFO - 2023-10-16 05:13:55 --> Loader Class Initialized
INFO - 2023-10-16 05:13:55 --> Helper loaded: url_helper
INFO - 2023-10-16 05:13:55 --> Helper loaded: file_helper
INFO - 2023-10-16 05:13:55 --> Helper loaded: html_helper
INFO - 2023-10-16 05:13:55 --> Helper loaded: text_helper
INFO - 2023-10-16 05:13:55 --> Helper loaded: form_helper
INFO - 2023-10-16 05:13:55 --> Helper loaded: lang_helper
INFO - 2023-10-16 05:13:55 --> Helper loaded: security_helper
INFO - 2023-10-16 05:13:55 --> Helper loaded: cookie_helper
INFO - 2023-10-16 05:13:55 --> Database Driver Class Initialized
INFO - 2023-10-16 05:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 05:13:55 --> Parser Class Initialized
INFO - 2023-10-16 05:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 05:13:55 --> Pagination Class Initialized
INFO - 2023-10-16 05:13:55 --> Form Validation Class Initialized
INFO - 2023-10-16 05:13:55 --> Controller Class Initialized
INFO - 2023-10-16 05:13:55 --> Model Class Initialized
DEBUG - 2023-10-16 05:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 05:13:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-16 05:13:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 05:13:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 05:13:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 05:13:55 --> Model Class Initialized
INFO - 2023-10-16 05:13:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 05:13:55 --> Final output sent to browser
DEBUG - 2023-10-16 05:13:55 --> Total execution time: 0.0328
ERROR - 2023-10-16 05:14:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 05:14:55 --> Config Class Initialized
INFO - 2023-10-16 05:14:55 --> Hooks Class Initialized
DEBUG - 2023-10-16 05:14:55 --> UTF-8 Support Enabled
INFO - 2023-10-16 05:14:55 --> Utf8 Class Initialized
INFO - 2023-10-16 05:14:55 --> URI Class Initialized
DEBUG - 2023-10-16 05:14:55 --> No URI present. Default controller set.
INFO - 2023-10-16 05:14:55 --> Router Class Initialized
INFO - 2023-10-16 05:14:55 --> Output Class Initialized
INFO - 2023-10-16 05:14:55 --> Security Class Initialized
DEBUG - 2023-10-16 05:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 05:14:55 --> Input Class Initialized
INFO - 2023-10-16 05:14:55 --> Language Class Initialized
INFO - 2023-10-16 05:14:55 --> Loader Class Initialized
INFO - 2023-10-16 05:14:55 --> Helper loaded: url_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: file_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: html_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: text_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: form_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: lang_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: security_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: cookie_helper
INFO - 2023-10-16 05:14:55 --> Database Driver Class Initialized
INFO - 2023-10-16 05:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 05:14:55 --> Parser Class Initialized
INFO - 2023-10-16 05:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 05:14:55 --> Pagination Class Initialized
INFO - 2023-10-16 05:14:55 --> Form Validation Class Initialized
INFO - 2023-10-16 05:14:55 --> Controller Class Initialized
INFO - 2023-10-16 05:14:55 --> Model Class Initialized
DEBUG - 2023-10-16 05:14:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-16 05:14:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 05:14:55 --> Config Class Initialized
INFO - 2023-10-16 05:14:55 --> Hooks Class Initialized
DEBUG - 2023-10-16 05:14:55 --> UTF-8 Support Enabled
INFO - 2023-10-16 05:14:55 --> Utf8 Class Initialized
INFO - 2023-10-16 05:14:55 --> URI Class Initialized
INFO - 2023-10-16 05:14:55 --> Router Class Initialized
INFO - 2023-10-16 05:14:55 --> Output Class Initialized
INFO - 2023-10-16 05:14:55 --> Security Class Initialized
DEBUG - 2023-10-16 05:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 05:14:55 --> Input Class Initialized
INFO - 2023-10-16 05:14:55 --> Language Class Initialized
INFO - 2023-10-16 05:14:55 --> Loader Class Initialized
INFO - 2023-10-16 05:14:55 --> Helper loaded: url_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: file_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: html_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: text_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: form_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: lang_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: security_helper
INFO - 2023-10-16 05:14:55 --> Helper loaded: cookie_helper
INFO - 2023-10-16 05:14:55 --> Database Driver Class Initialized
INFO - 2023-10-16 05:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 05:14:55 --> Parser Class Initialized
INFO - 2023-10-16 05:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 05:14:55 --> Pagination Class Initialized
INFO - 2023-10-16 05:14:55 --> Form Validation Class Initialized
INFO - 2023-10-16 05:14:55 --> Controller Class Initialized
INFO - 2023-10-16 05:14:55 --> Model Class Initialized
DEBUG - 2023-10-16 05:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 05:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-16 05:14:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 05:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 05:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 05:14:55 --> Model Class Initialized
INFO - 2023-10-16 05:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 05:14:55 --> Final output sent to browser
DEBUG - 2023-10-16 05:14:55 --> Total execution time: 0.0293
ERROR - 2023-10-16 05:30:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 05:30:51 --> Config Class Initialized
INFO - 2023-10-16 05:30:51 --> Hooks Class Initialized
DEBUG - 2023-10-16 05:30:51 --> UTF-8 Support Enabled
INFO - 2023-10-16 05:30:51 --> Utf8 Class Initialized
INFO - 2023-10-16 05:30:51 --> URI Class Initialized
INFO - 2023-10-16 05:30:51 --> Router Class Initialized
INFO - 2023-10-16 05:30:51 --> Output Class Initialized
INFO - 2023-10-16 05:30:51 --> Security Class Initialized
DEBUG - 2023-10-16 05:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 05:30:51 --> Input Class Initialized
INFO - 2023-10-16 05:30:51 --> Language Class Initialized
ERROR - 2023-10-16 05:30:51 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-16 08:32:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 08:32:26 --> Config Class Initialized
INFO - 2023-10-16 08:32:26 --> Hooks Class Initialized
DEBUG - 2023-10-16 08:32:26 --> UTF-8 Support Enabled
INFO - 2023-10-16 08:32:26 --> Utf8 Class Initialized
INFO - 2023-10-16 08:32:26 --> URI Class Initialized
DEBUG - 2023-10-16 08:32:26 --> No URI present. Default controller set.
INFO - 2023-10-16 08:32:26 --> Router Class Initialized
INFO - 2023-10-16 08:32:26 --> Output Class Initialized
INFO - 2023-10-16 08:32:26 --> Security Class Initialized
DEBUG - 2023-10-16 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 08:32:26 --> Input Class Initialized
INFO - 2023-10-16 08:32:26 --> Language Class Initialized
INFO - 2023-10-16 08:32:26 --> Loader Class Initialized
INFO - 2023-10-16 08:32:26 --> Helper loaded: url_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: file_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: html_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: text_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: form_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: lang_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: security_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: cookie_helper
INFO - 2023-10-16 08:32:26 --> Database Driver Class Initialized
INFO - 2023-10-16 08:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 08:32:26 --> Parser Class Initialized
INFO - 2023-10-16 08:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 08:32:26 --> Pagination Class Initialized
INFO - 2023-10-16 08:32:26 --> Form Validation Class Initialized
INFO - 2023-10-16 08:32:26 --> Controller Class Initialized
INFO - 2023-10-16 08:32:26 --> Model Class Initialized
DEBUG - 2023-10-16 08:32:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-16 08:32:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 08:32:26 --> Config Class Initialized
INFO - 2023-10-16 08:32:26 --> Hooks Class Initialized
DEBUG - 2023-10-16 08:32:26 --> UTF-8 Support Enabled
INFO - 2023-10-16 08:32:26 --> Utf8 Class Initialized
INFO - 2023-10-16 08:32:26 --> URI Class Initialized
INFO - 2023-10-16 08:32:26 --> Router Class Initialized
INFO - 2023-10-16 08:32:26 --> Output Class Initialized
INFO - 2023-10-16 08:32:26 --> Security Class Initialized
DEBUG - 2023-10-16 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 08:32:26 --> Input Class Initialized
INFO - 2023-10-16 08:32:26 --> Language Class Initialized
INFO - 2023-10-16 08:32:26 --> Loader Class Initialized
INFO - 2023-10-16 08:32:26 --> Helper loaded: url_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: file_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: html_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: text_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: form_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: lang_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: security_helper
INFO - 2023-10-16 08:32:26 --> Helper loaded: cookie_helper
INFO - 2023-10-16 08:32:26 --> Database Driver Class Initialized
INFO - 2023-10-16 08:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 08:32:26 --> Parser Class Initialized
INFO - 2023-10-16 08:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 08:32:26 --> Pagination Class Initialized
INFO - 2023-10-16 08:32:26 --> Form Validation Class Initialized
INFO - 2023-10-16 08:32:26 --> Controller Class Initialized
INFO - 2023-10-16 08:32:26 --> Model Class Initialized
DEBUG - 2023-10-16 08:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 08:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-16 08:32:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 08:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 08:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 08:32:26 --> Model Class Initialized
INFO - 2023-10-16 08:32:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 08:32:26 --> Final output sent to browser
DEBUG - 2023-10-16 08:32:26 --> Total execution time: 0.0304
ERROR - 2023-10-16 10:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 10:05:51 --> Config Class Initialized
INFO - 2023-10-16 10:05:51 --> Hooks Class Initialized
DEBUG - 2023-10-16 10:05:51 --> UTF-8 Support Enabled
INFO - 2023-10-16 10:05:51 --> Utf8 Class Initialized
INFO - 2023-10-16 10:05:51 --> URI Class Initialized
DEBUG - 2023-10-16 10:05:51 --> No URI present. Default controller set.
INFO - 2023-10-16 10:05:51 --> Router Class Initialized
INFO - 2023-10-16 10:05:51 --> Output Class Initialized
INFO - 2023-10-16 10:05:51 --> Security Class Initialized
DEBUG - 2023-10-16 10:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 10:05:51 --> Input Class Initialized
INFO - 2023-10-16 10:05:51 --> Language Class Initialized
INFO - 2023-10-16 10:05:51 --> Loader Class Initialized
INFO - 2023-10-16 10:05:51 --> Helper loaded: url_helper
INFO - 2023-10-16 10:05:51 --> Helper loaded: file_helper
INFO - 2023-10-16 10:05:51 --> Helper loaded: html_helper
INFO - 2023-10-16 10:05:51 --> Helper loaded: text_helper
INFO - 2023-10-16 10:05:51 --> Helper loaded: form_helper
INFO - 2023-10-16 10:05:51 --> Helper loaded: lang_helper
INFO - 2023-10-16 10:05:51 --> Helper loaded: security_helper
INFO - 2023-10-16 10:05:51 --> Helper loaded: cookie_helper
INFO - 2023-10-16 10:05:51 --> Database Driver Class Initialized
INFO - 2023-10-16 10:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 10:05:51 --> Parser Class Initialized
INFO - 2023-10-16 10:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 10:05:51 --> Pagination Class Initialized
INFO - 2023-10-16 10:05:51 --> Form Validation Class Initialized
INFO - 2023-10-16 10:05:51 --> Controller Class Initialized
INFO - 2023-10-16 10:05:51 --> Model Class Initialized
DEBUG - 2023-10-16 10:05:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-16 10:05:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 10:05:52 --> Config Class Initialized
INFO - 2023-10-16 10:05:52 --> Hooks Class Initialized
DEBUG - 2023-10-16 10:05:52 --> UTF-8 Support Enabled
INFO - 2023-10-16 10:05:52 --> Utf8 Class Initialized
INFO - 2023-10-16 10:05:52 --> URI Class Initialized
INFO - 2023-10-16 10:05:52 --> Router Class Initialized
INFO - 2023-10-16 10:05:52 --> Output Class Initialized
INFO - 2023-10-16 10:05:52 --> Security Class Initialized
DEBUG - 2023-10-16 10:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 10:05:52 --> Input Class Initialized
INFO - 2023-10-16 10:05:52 --> Language Class Initialized
INFO - 2023-10-16 10:05:52 --> Loader Class Initialized
INFO - 2023-10-16 10:05:52 --> Helper loaded: url_helper
INFO - 2023-10-16 10:05:52 --> Helper loaded: file_helper
INFO - 2023-10-16 10:05:52 --> Helper loaded: html_helper
INFO - 2023-10-16 10:05:52 --> Helper loaded: text_helper
INFO - 2023-10-16 10:05:52 --> Helper loaded: form_helper
INFO - 2023-10-16 10:05:52 --> Helper loaded: lang_helper
INFO - 2023-10-16 10:05:52 --> Helper loaded: security_helper
INFO - 2023-10-16 10:05:52 --> Helper loaded: cookie_helper
INFO - 2023-10-16 10:05:52 --> Database Driver Class Initialized
INFO - 2023-10-16 10:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 10:05:52 --> Parser Class Initialized
INFO - 2023-10-16 10:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 10:05:52 --> Pagination Class Initialized
INFO - 2023-10-16 10:05:52 --> Form Validation Class Initialized
INFO - 2023-10-16 10:05:52 --> Controller Class Initialized
INFO - 2023-10-16 10:05:52 --> Model Class Initialized
DEBUG - 2023-10-16 10:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 10:05:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-16 10:05:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 10:05:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 10:05:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 10:05:52 --> Model Class Initialized
INFO - 2023-10-16 10:05:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 10:05:52 --> Final output sent to browser
DEBUG - 2023-10-16 10:05:52 --> Total execution time: 0.0292
ERROR - 2023-10-16 11:43:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:43:56 --> Config Class Initialized
INFO - 2023-10-16 11:43:56 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:43:56 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:43:56 --> Utf8 Class Initialized
INFO - 2023-10-16 11:43:56 --> URI Class Initialized
DEBUG - 2023-10-16 11:43:56 --> No URI present. Default controller set.
INFO - 2023-10-16 11:43:56 --> Router Class Initialized
INFO - 2023-10-16 11:43:56 --> Output Class Initialized
INFO - 2023-10-16 11:43:56 --> Security Class Initialized
DEBUG - 2023-10-16 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:43:56 --> Input Class Initialized
INFO - 2023-10-16 11:43:56 --> Language Class Initialized
INFO - 2023-10-16 11:43:56 --> Loader Class Initialized
INFO - 2023-10-16 11:43:56 --> Helper loaded: url_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: file_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: html_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: text_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: form_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: security_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:43:56 --> Database Driver Class Initialized
INFO - 2023-10-16 11:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:43:56 --> Parser Class Initialized
INFO - 2023-10-16 11:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:43:56 --> Pagination Class Initialized
INFO - 2023-10-16 11:43:56 --> Form Validation Class Initialized
INFO - 2023-10-16 11:43:56 --> Controller Class Initialized
INFO - 2023-10-16 11:43:56 --> Model Class Initialized
DEBUG - 2023-10-16 11:43:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-16 11:43:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:43:56 --> Config Class Initialized
INFO - 2023-10-16 11:43:56 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:43:56 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:43:56 --> Utf8 Class Initialized
INFO - 2023-10-16 11:43:56 --> URI Class Initialized
INFO - 2023-10-16 11:43:56 --> Router Class Initialized
INFO - 2023-10-16 11:43:56 --> Output Class Initialized
INFO - 2023-10-16 11:43:56 --> Security Class Initialized
DEBUG - 2023-10-16 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:43:56 --> Input Class Initialized
INFO - 2023-10-16 11:43:56 --> Language Class Initialized
INFO - 2023-10-16 11:43:56 --> Loader Class Initialized
INFO - 2023-10-16 11:43:56 --> Helper loaded: url_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: file_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: html_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: text_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: form_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: security_helper
INFO - 2023-10-16 11:43:56 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:43:56 --> Database Driver Class Initialized
INFO - 2023-10-16 11:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:43:56 --> Parser Class Initialized
INFO - 2023-10-16 11:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:43:56 --> Pagination Class Initialized
INFO - 2023-10-16 11:43:56 --> Form Validation Class Initialized
INFO - 2023-10-16 11:43:56 --> Controller Class Initialized
INFO - 2023-10-16 11:43:56 --> Model Class Initialized
DEBUG - 2023-10-16 11:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-16 11:43:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:43:56 --> Model Class Initialized
INFO - 2023-10-16 11:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:43:56 --> Final output sent to browser
DEBUG - 2023-10-16 11:43:56 --> Total execution time: 0.0303
ERROR - 2023-10-16 11:44:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:00 --> Config Class Initialized
INFO - 2023-10-16 11:44:00 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:00 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:00 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:00 --> URI Class Initialized
INFO - 2023-10-16 11:44:00 --> Router Class Initialized
INFO - 2023-10-16 11:44:00 --> Output Class Initialized
INFO - 2023-10-16 11:44:00 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:00 --> Input Class Initialized
INFO - 2023-10-16 11:44:00 --> Language Class Initialized
INFO - 2023-10-16 11:44:00 --> Loader Class Initialized
INFO - 2023-10-16 11:44:00 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:00 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:00 --> Parser Class Initialized
INFO - 2023-10-16 11:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:00 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:00 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:00 --> Controller Class Initialized
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
INFO - 2023-10-16 11:44:00 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:00 --> Total execution time: 0.0174
ERROR - 2023-10-16 11:44:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:00 --> Config Class Initialized
INFO - 2023-10-16 11:44:00 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:00 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:00 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:00 --> URI Class Initialized
DEBUG - 2023-10-16 11:44:00 --> No URI present. Default controller set.
INFO - 2023-10-16 11:44:00 --> Router Class Initialized
INFO - 2023-10-16 11:44:00 --> Output Class Initialized
INFO - 2023-10-16 11:44:00 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:00 --> Input Class Initialized
INFO - 2023-10-16 11:44:00 --> Language Class Initialized
INFO - 2023-10-16 11:44:00 --> Loader Class Initialized
INFO - 2023-10-16 11:44:00 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:00 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:00 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:00 --> Parser Class Initialized
INFO - 2023-10-16 11:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:00 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:00 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:00 --> Controller Class Initialized
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
INFO - 2023-10-16 11:44:00 --> Model Class Initialized
INFO - 2023-10-16 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-16 11:44:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:44:01 --> Model Class Initialized
INFO - 2023-10-16 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:44:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:44:01 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:01 --> Total execution time: 0.3439
ERROR - 2023-10-16 11:44:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:02 --> Config Class Initialized
INFO - 2023-10-16 11:44:02 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:02 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:02 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:02 --> URI Class Initialized
INFO - 2023-10-16 11:44:02 --> Router Class Initialized
INFO - 2023-10-16 11:44:02 --> Output Class Initialized
INFO - 2023-10-16 11:44:02 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:02 --> Input Class Initialized
INFO - 2023-10-16 11:44:02 --> Language Class Initialized
INFO - 2023-10-16 11:44:02 --> Loader Class Initialized
INFO - 2023-10-16 11:44:02 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:02 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:02 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:02 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:02 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:02 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:02 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:02 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:02 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:02 --> Parser Class Initialized
INFO - 2023-10-16 11:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:02 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:02 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:02 --> Controller Class Initialized
DEBUG - 2023-10-16 11:44:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:02 --> Model Class Initialized
INFO - 2023-10-16 11:44:02 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:02 --> Total execution time: 0.0161
ERROR - 2023-10-16 11:44:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:07 --> Config Class Initialized
INFO - 2023-10-16 11:44:07 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:07 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:07 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:07 --> URI Class Initialized
INFO - 2023-10-16 11:44:07 --> Router Class Initialized
INFO - 2023-10-16 11:44:07 --> Output Class Initialized
INFO - 2023-10-16 11:44:07 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:07 --> Input Class Initialized
INFO - 2023-10-16 11:44:07 --> Language Class Initialized
INFO - 2023-10-16 11:44:07 --> Loader Class Initialized
INFO - 2023-10-16 11:44:07 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:07 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:07 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:07 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:07 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:07 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:07 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:07 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:07 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:08 --> Parser Class Initialized
INFO - 2023-10-16 11:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:08 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:08 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:08 --> Controller Class Initialized
INFO - 2023-10-16 11:44:08 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:08 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:08 --> Model Class Initialized
INFO - 2023-10-16 11:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-16 11:44:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:44:08 --> Model Class Initialized
INFO - 2023-10-16 11:44:08 --> Model Class Initialized
INFO - 2023-10-16 11:44:08 --> Model Class Initialized
INFO - 2023-10-16 11:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:44:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:44:08 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:08 --> Total execution time: 0.1855
ERROR - 2023-10-16 11:44:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:09 --> Config Class Initialized
INFO - 2023-10-16 11:44:09 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:09 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:09 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:09 --> URI Class Initialized
INFO - 2023-10-16 11:44:09 --> Router Class Initialized
INFO - 2023-10-16 11:44:09 --> Output Class Initialized
INFO - 2023-10-16 11:44:09 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:09 --> Input Class Initialized
INFO - 2023-10-16 11:44:09 --> Language Class Initialized
INFO - 2023-10-16 11:44:09 --> Loader Class Initialized
INFO - 2023-10-16 11:44:09 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:09 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:09 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:09 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:09 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:09 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:09 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:09 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:09 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:09 --> Parser Class Initialized
INFO - 2023-10-16 11:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:09 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:09 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:09 --> Controller Class Initialized
INFO - 2023-10-16 11:44:09 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:09 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:09 --> Model Class Initialized
INFO - 2023-10-16 11:44:09 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:09 --> Total execution time: 0.0529
ERROR - 2023-10-16 11:44:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:18 --> Config Class Initialized
INFO - 2023-10-16 11:44:18 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:18 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:18 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:18 --> URI Class Initialized
INFO - 2023-10-16 11:44:18 --> Router Class Initialized
INFO - 2023-10-16 11:44:18 --> Output Class Initialized
INFO - 2023-10-16 11:44:18 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:18 --> Input Class Initialized
INFO - 2023-10-16 11:44:18 --> Language Class Initialized
INFO - 2023-10-16 11:44:18 --> Loader Class Initialized
INFO - 2023-10-16 11:44:18 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:18 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:18 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:18 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:18 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:18 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:18 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:18 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:18 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:18 --> Parser Class Initialized
INFO - 2023-10-16 11:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:18 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:18 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:18 --> Controller Class Initialized
INFO - 2023-10-16 11:44:18 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:18 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:18 --> Model Class Initialized
INFO - 2023-10-16 11:44:18 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:18 --> Total execution time: 0.0577
ERROR - 2023-10-16 11:44:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:19 --> Config Class Initialized
INFO - 2023-10-16 11:44:19 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:19 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:19 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:19 --> URI Class Initialized
INFO - 2023-10-16 11:44:19 --> Router Class Initialized
INFO - 2023-10-16 11:44:19 --> Output Class Initialized
INFO - 2023-10-16 11:44:19 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:19 --> Input Class Initialized
INFO - 2023-10-16 11:44:19 --> Language Class Initialized
INFO - 2023-10-16 11:44:19 --> Loader Class Initialized
INFO - 2023-10-16 11:44:19 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:19 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:19 --> Parser Class Initialized
INFO - 2023-10-16 11:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:19 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:19 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:19 --> Controller Class Initialized
INFO - 2023-10-16 11:44:19 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:19 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:19 --> Model Class Initialized
INFO - 2023-10-16 11:44:19 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:19 --> Total execution time: 0.0549
ERROR - 2023-10-16 11:44:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:19 --> Config Class Initialized
INFO - 2023-10-16 11:44:19 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:19 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:19 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:19 --> URI Class Initialized
INFO - 2023-10-16 11:44:19 --> Router Class Initialized
INFO - 2023-10-16 11:44:19 --> Output Class Initialized
INFO - 2023-10-16 11:44:19 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:19 --> Input Class Initialized
INFO - 2023-10-16 11:44:19 --> Language Class Initialized
INFO - 2023-10-16 11:44:19 --> Loader Class Initialized
INFO - 2023-10-16 11:44:19 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:19 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:19 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:19 --> Parser Class Initialized
INFO - 2023-10-16 11:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:19 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:19 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:19 --> Controller Class Initialized
INFO - 2023-10-16 11:44:19 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:19 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:19 --> Model Class Initialized
INFO - 2023-10-16 11:44:19 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:19 --> Total execution time: 0.0220
ERROR - 2023-10-16 11:44:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:20 --> Config Class Initialized
INFO - 2023-10-16 11:44:20 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:20 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:20 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:20 --> URI Class Initialized
INFO - 2023-10-16 11:44:20 --> Router Class Initialized
INFO - 2023-10-16 11:44:20 --> Output Class Initialized
INFO - 2023-10-16 11:44:20 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:20 --> Input Class Initialized
INFO - 2023-10-16 11:44:20 --> Language Class Initialized
INFO - 2023-10-16 11:44:20 --> Loader Class Initialized
INFO - 2023-10-16 11:44:20 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:20 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:20 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:20 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:20 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:20 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:20 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:20 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:20 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:20 --> Parser Class Initialized
INFO - 2023-10-16 11:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:20 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:20 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:20 --> Controller Class Initialized
INFO - 2023-10-16 11:44:20 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:20 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:20 --> Model Class Initialized
INFO - 2023-10-16 11:44:21 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:21 --> Total execution time: 0.0537
ERROR - 2023-10-16 11:44:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:21 --> Config Class Initialized
INFO - 2023-10-16 11:44:21 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:21 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:21 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:21 --> URI Class Initialized
INFO - 2023-10-16 11:44:21 --> Router Class Initialized
INFO - 2023-10-16 11:44:21 --> Output Class Initialized
INFO - 2023-10-16 11:44:21 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:21 --> Input Class Initialized
INFO - 2023-10-16 11:44:21 --> Language Class Initialized
INFO - 2023-10-16 11:44:21 --> Loader Class Initialized
INFO - 2023-10-16 11:44:21 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:21 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:21 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:21 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:21 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:21 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:21 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:21 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:21 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:21 --> Parser Class Initialized
INFO - 2023-10-16 11:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:21 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:21 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:21 --> Controller Class Initialized
INFO - 2023-10-16 11:44:21 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:21 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:21 --> Model Class Initialized
INFO - 2023-10-16 11:44:21 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:21 --> Total execution time: 0.0528
ERROR - 2023-10-16 11:44:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:22 --> Config Class Initialized
INFO - 2023-10-16 11:44:22 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:22 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:22 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:22 --> URI Class Initialized
INFO - 2023-10-16 11:44:22 --> Router Class Initialized
INFO - 2023-10-16 11:44:22 --> Output Class Initialized
INFO - 2023-10-16 11:44:22 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:22 --> Input Class Initialized
INFO - 2023-10-16 11:44:22 --> Language Class Initialized
INFO - 2023-10-16 11:44:22 --> Loader Class Initialized
INFO - 2023-10-16 11:44:22 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:22 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:22 --> Parser Class Initialized
INFO - 2023-10-16 11:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:22 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:22 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:22 --> Controller Class Initialized
INFO - 2023-10-16 11:44:22 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:22 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:22 --> Model Class Initialized
INFO - 2023-10-16 11:44:22 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:22 --> Total execution time: 0.0546
ERROR - 2023-10-16 11:44:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:22 --> Config Class Initialized
INFO - 2023-10-16 11:44:22 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:22 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:22 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:22 --> URI Class Initialized
INFO - 2023-10-16 11:44:22 --> Router Class Initialized
INFO - 2023-10-16 11:44:22 --> Output Class Initialized
INFO - 2023-10-16 11:44:22 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:22 --> Input Class Initialized
INFO - 2023-10-16 11:44:22 --> Language Class Initialized
INFO - 2023-10-16 11:44:22 --> Loader Class Initialized
INFO - 2023-10-16 11:44:22 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:22 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:22 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:22 --> Parser Class Initialized
INFO - 2023-10-16 11:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:22 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:22 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:22 --> Controller Class Initialized
INFO - 2023-10-16 11:44:22 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:22 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:22 --> Model Class Initialized
INFO - 2023-10-16 11:44:22 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:22 --> Total execution time: 0.0531
ERROR - 2023-10-16 11:44:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:23 --> Config Class Initialized
INFO - 2023-10-16 11:44:23 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:23 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:23 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:23 --> URI Class Initialized
INFO - 2023-10-16 11:44:23 --> Router Class Initialized
INFO - 2023-10-16 11:44:23 --> Output Class Initialized
INFO - 2023-10-16 11:44:23 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:23 --> Input Class Initialized
INFO - 2023-10-16 11:44:23 --> Language Class Initialized
INFO - 2023-10-16 11:44:23 --> Loader Class Initialized
INFO - 2023-10-16 11:44:23 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:23 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:23 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:23 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:23 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:23 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:23 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:23 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:23 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:23 --> Parser Class Initialized
INFO - 2023-10-16 11:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:23 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:23 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:23 --> Controller Class Initialized
INFO - 2023-10-16 11:44:23 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:23 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:23 --> Model Class Initialized
INFO - 2023-10-16 11:44:23 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:23 --> Total execution time: 0.0530
ERROR - 2023-10-16 11:44:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:24 --> Config Class Initialized
INFO - 2023-10-16 11:44:24 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:24 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:24 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:24 --> URI Class Initialized
INFO - 2023-10-16 11:44:24 --> Router Class Initialized
INFO - 2023-10-16 11:44:24 --> Output Class Initialized
INFO - 2023-10-16 11:44:24 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:24 --> Input Class Initialized
INFO - 2023-10-16 11:44:24 --> Language Class Initialized
INFO - 2023-10-16 11:44:24 --> Loader Class Initialized
INFO - 2023-10-16 11:44:24 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:24 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:24 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:24 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:24 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:24 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:24 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:24 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:24 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:24 --> Parser Class Initialized
INFO - 2023-10-16 11:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:24 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:24 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:24 --> Controller Class Initialized
INFO - 2023-10-16 11:44:24 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:24 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:24 --> Model Class Initialized
INFO - 2023-10-16 11:44:24 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:24 --> Total execution time: 0.0575
ERROR - 2023-10-16 11:44:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:35 --> Config Class Initialized
INFO - 2023-10-16 11:44:35 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:35 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:35 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:35 --> URI Class Initialized
INFO - 2023-10-16 11:44:35 --> Router Class Initialized
INFO - 2023-10-16 11:44:35 --> Output Class Initialized
INFO - 2023-10-16 11:44:35 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:35 --> Input Class Initialized
INFO - 2023-10-16 11:44:35 --> Language Class Initialized
INFO - 2023-10-16 11:44:35 --> Loader Class Initialized
INFO - 2023-10-16 11:44:35 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:35 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:35 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:35 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:35 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:35 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:35 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:35 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:35 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:35 --> Parser Class Initialized
INFO - 2023-10-16 11:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:35 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:35 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:35 --> Controller Class Initialized
INFO - 2023-10-16 11:44:35 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:35 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:35 --> Model Class Initialized
INFO - 2023-10-16 11:44:35 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:35 --> Total execution time: 0.1582
ERROR - 2023-10-16 11:44:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:44:50 --> Config Class Initialized
INFO - 2023-10-16 11:44:50 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:44:50 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:44:50 --> Utf8 Class Initialized
INFO - 2023-10-16 11:44:50 --> URI Class Initialized
INFO - 2023-10-16 11:44:50 --> Router Class Initialized
INFO - 2023-10-16 11:44:50 --> Output Class Initialized
INFO - 2023-10-16 11:44:50 --> Security Class Initialized
DEBUG - 2023-10-16 11:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:44:50 --> Input Class Initialized
INFO - 2023-10-16 11:44:50 --> Language Class Initialized
INFO - 2023-10-16 11:44:50 --> Loader Class Initialized
INFO - 2023-10-16 11:44:50 --> Helper loaded: url_helper
INFO - 2023-10-16 11:44:50 --> Helper loaded: file_helper
INFO - 2023-10-16 11:44:50 --> Helper loaded: html_helper
INFO - 2023-10-16 11:44:50 --> Helper loaded: text_helper
INFO - 2023-10-16 11:44:50 --> Helper loaded: form_helper
INFO - 2023-10-16 11:44:50 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:44:50 --> Helper loaded: security_helper
INFO - 2023-10-16 11:44:50 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:44:50 --> Database Driver Class Initialized
INFO - 2023-10-16 11:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:44:50 --> Parser Class Initialized
INFO - 2023-10-16 11:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:44:50 --> Pagination Class Initialized
INFO - 2023-10-16 11:44:50 --> Form Validation Class Initialized
INFO - 2023-10-16 11:44:50 --> Controller Class Initialized
INFO - 2023-10-16 11:44:50 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:50 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:50 --> Model Class Initialized
DEBUG - 2023-10-16 11:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-16 11:44:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:44:50 --> Model Class Initialized
INFO - 2023-10-16 11:44:50 --> Model Class Initialized
INFO - 2023-10-16 11:44:50 --> Model Class Initialized
INFO - 2023-10-16 11:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:44:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:44:50 --> Final output sent to browser
DEBUG - 2023-10-16 11:44:50 --> Total execution time: 0.2005
ERROR - 2023-10-16 11:48:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:48:22 --> Config Class Initialized
INFO - 2023-10-16 11:48:22 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:48:22 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:48:22 --> Utf8 Class Initialized
INFO - 2023-10-16 11:48:22 --> URI Class Initialized
INFO - 2023-10-16 11:48:22 --> Router Class Initialized
INFO - 2023-10-16 11:48:22 --> Output Class Initialized
INFO - 2023-10-16 11:48:22 --> Security Class Initialized
DEBUG - 2023-10-16 11:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:48:22 --> Input Class Initialized
INFO - 2023-10-16 11:48:22 --> Language Class Initialized
INFO - 2023-10-16 11:48:22 --> Loader Class Initialized
INFO - 2023-10-16 11:48:22 --> Helper loaded: url_helper
INFO - 2023-10-16 11:48:22 --> Helper loaded: file_helper
INFO - 2023-10-16 11:48:22 --> Helper loaded: html_helper
INFO - 2023-10-16 11:48:22 --> Helper loaded: text_helper
INFO - 2023-10-16 11:48:22 --> Helper loaded: form_helper
INFO - 2023-10-16 11:48:22 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:48:22 --> Helper loaded: security_helper
INFO - 2023-10-16 11:48:22 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:48:22 --> Database Driver Class Initialized
INFO - 2023-10-16 11:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:48:22 --> Parser Class Initialized
INFO - 2023-10-16 11:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:48:22 --> Pagination Class Initialized
INFO - 2023-10-16 11:48:22 --> Form Validation Class Initialized
INFO - 2023-10-16 11:48:22 --> Controller Class Initialized
INFO - 2023-10-16 11:48:22 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:22 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:22 --> Model Class Initialized
INFO - 2023-10-16 11:48:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-16 11:48:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:48:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:48:22 --> Model Class Initialized
INFO - 2023-10-16 11:48:22 --> Model Class Initialized
INFO - 2023-10-16 11:48:22 --> Model Class Initialized
INFO - 2023-10-16 11:48:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:48:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:48:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:48:22 --> Final output sent to browser
DEBUG - 2023-10-16 11:48:22 --> Total execution time: 0.1995
ERROR - 2023-10-16 11:48:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:48:23 --> Config Class Initialized
INFO - 2023-10-16 11:48:23 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:48:23 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:48:23 --> Utf8 Class Initialized
INFO - 2023-10-16 11:48:23 --> URI Class Initialized
INFO - 2023-10-16 11:48:23 --> Router Class Initialized
INFO - 2023-10-16 11:48:23 --> Output Class Initialized
INFO - 2023-10-16 11:48:23 --> Security Class Initialized
DEBUG - 2023-10-16 11:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:48:23 --> Input Class Initialized
INFO - 2023-10-16 11:48:23 --> Language Class Initialized
INFO - 2023-10-16 11:48:23 --> Loader Class Initialized
INFO - 2023-10-16 11:48:23 --> Helper loaded: url_helper
INFO - 2023-10-16 11:48:23 --> Helper loaded: file_helper
INFO - 2023-10-16 11:48:23 --> Helper loaded: html_helper
INFO - 2023-10-16 11:48:23 --> Helper loaded: text_helper
INFO - 2023-10-16 11:48:23 --> Helper loaded: form_helper
INFO - 2023-10-16 11:48:23 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:48:23 --> Helper loaded: security_helper
INFO - 2023-10-16 11:48:23 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:48:23 --> Database Driver Class Initialized
INFO - 2023-10-16 11:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:48:23 --> Parser Class Initialized
INFO - 2023-10-16 11:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:48:23 --> Pagination Class Initialized
INFO - 2023-10-16 11:48:23 --> Form Validation Class Initialized
INFO - 2023-10-16 11:48:23 --> Controller Class Initialized
INFO - 2023-10-16 11:48:23 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:23 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:23 --> Model Class Initialized
INFO - 2023-10-16 11:48:23 --> Final output sent to browser
DEBUG - 2023-10-16 11:48:23 --> Total execution time: 0.0543
ERROR - 2023-10-16 11:48:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:48:39 --> Config Class Initialized
INFO - 2023-10-16 11:48:39 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:48:39 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:48:39 --> Utf8 Class Initialized
INFO - 2023-10-16 11:48:39 --> URI Class Initialized
INFO - 2023-10-16 11:48:39 --> Router Class Initialized
INFO - 2023-10-16 11:48:39 --> Output Class Initialized
INFO - 2023-10-16 11:48:39 --> Security Class Initialized
DEBUG - 2023-10-16 11:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:48:39 --> Input Class Initialized
INFO - 2023-10-16 11:48:39 --> Language Class Initialized
INFO - 2023-10-16 11:48:39 --> Loader Class Initialized
INFO - 2023-10-16 11:48:39 --> Helper loaded: url_helper
INFO - 2023-10-16 11:48:39 --> Helper loaded: file_helper
INFO - 2023-10-16 11:48:39 --> Helper loaded: html_helper
INFO - 2023-10-16 11:48:39 --> Helper loaded: text_helper
INFO - 2023-10-16 11:48:39 --> Helper loaded: form_helper
INFO - 2023-10-16 11:48:39 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:48:39 --> Helper loaded: security_helper
INFO - 2023-10-16 11:48:39 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:48:39 --> Database Driver Class Initialized
INFO - 2023-10-16 11:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:48:39 --> Parser Class Initialized
INFO - 2023-10-16 11:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:48:39 --> Pagination Class Initialized
INFO - 2023-10-16 11:48:39 --> Form Validation Class Initialized
INFO - 2023-10-16 11:48:39 --> Controller Class Initialized
INFO - 2023-10-16 11:48:39 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:39 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:39 --> Model Class Initialized
INFO - 2023-10-16 11:48:39 --> Final output sent to browser
DEBUG - 2023-10-16 11:48:39 --> Total execution time: 0.0619
ERROR - 2023-10-16 11:48:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:48:44 --> Config Class Initialized
INFO - 2023-10-16 11:48:44 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:48:44 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:48:44 --> Utf8 Class Initialized
INFO - 2023-10-16 11:48:44 --> URI Class Initialized
INFO - 2023-10-16 11:48:44 --> Router Class Initialized
INFO - 2023-10-16 11:48:44 --> Output Class Initialized
INFO - 2023-10-16 11:48:44 --> Security Class Initialized
DEBUG - 2023-10-16 11:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:48:44 --> Input Class Initialized
INFO - 2023-10-16 11:48:44 --> Language Class Initialized
INFO - 2023-10-16 11:48:44 --> Loader Class Initialized
INFO - 2023-10-16 11:48:44 --> Helper loaded: url_helper
INFO - 2023-10-16 11:48:44 --> Helper loaded: file_helper
INFO - 2023-10-16 11:48:44 --> Helper loaded: html_helper
INFO - 2023-10-16 11:48:44 --> Helper loaded: text_helper
INFO - 2023-10-16 11:48:44 --> Helper loaded: form_helper
INFO - 2023-10-16 11:48:44 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:48:44 --> Helper loaded: security_helper
INFO - 2023-10-16 11:48:44 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:48:44 --> Database Driver Class Initialized
INFO - 2023-10-16 11:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:48:44 --> Parser Class Initialized
INFO - 2023-10-16 11:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:48:44 --> Pagination Class Initialized
INFO - 2023-10-16 11:48:44 --> Form Validation Class Initialized
INFO - 2023-10-16 11:48:44 --> Controller Class Initialized
INFO - 2023-10-16 11:48:44 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:44 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:44 --> Model Class Initialized
INFO - 2023-10-16 11:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-16 11:48:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:48:44 --> Model Class Initialized
INFO - 2023-10-16 11:48:44 --> Model Class Initialized
INFO - 2023-10-16 11:48:44 --> Model Class Initialized
INFO - 2023-10-16 11:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:48:44 --> Final output sent to browser
DEBUG - 2023-10-16 11:48:44 --> Total execution time: 0.1932
ERROR - 2023-10-16 11:48:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:48:45 --> Config Class Initialized
INFO - 2023-10-16 11:48:45 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:48:45 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:48:45 --> Utf8 Class Initialized
INFO - 2023-10-16 11:48:45 --> URI Class Initialized
INFO - 2023-10-16 11:48:45 --> Router Class Initialized
INFO - 2023-10-16 11:48:45 --> Output Class Initialized
INFO - 2023-10-16 11:48:45 --> Security Class Initialized
DEBUG - 2023-10-16 11:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:48:45 --> Input Class Initialized
INFO - 2023-10-16 11:48:45 --> Language Class Initialized
INFO - 2023-10-16 11:48:45 --> Loader Class Initialized
INFO - 2023-10-16 11:48:45 --> Helper loaded: url_helper
INFO - 2023-10-16 11:48:45 --> Helper loaded: file_helper
INFO - 2023-10-16 11:48:45 --> Helper loaded: html_helper
INFO - 2023-10-16 11:48:45 --> Helper loaded: text_helper
INFO - 2023-10-16 11:48:45 --> Helper loaded: form_helper
INFO - 2023-10-16 11:48:45 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:48:45 --> Helper loaded: security_helper
INFO - 2023-10-16 11:48:45 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:48:45 --> Database Driver Class Initialized
INFO - 2023-10-16 11:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:48:45 --> Parser Class Initialized
INFO - 2023-10-16 11:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:48:45 --> Pagination Class Initialized
INFO - 2023-10-16 11:48:45 --> Form Validation Class Initialized
INFO - 2023-10-16 11:48:45 --> Controller Class Initialized
INFO - 2023-10-16 11:48:45 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:45 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:45 --> Model Class Initialized
INFO - 2023-10-16 11:48:45 --> Final output sent to browser
DEBUG - 2023-10-16 11:48:45 --> Total execution time: 0.0468
ERROR - 2023-10-16 11:48:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:48:59 --> Config Class Initialized
INFO - 2023-10-16 11:48:59 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:48:59 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:48:59 --> Utf8 Class Initialized
INFO - 2023-10-16 11:48:59 --> URI Class Initialized
INFO - 2023-10-16 11:48:59 --> Router Class Initialized
INFO - 2023-10-16 11:48:59 --> Output Class Initialized
INFO - 2023-10-16 11:48:59 --> Security Class Initialized
DEBUG - 2023-10-16 11:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:48:59 --> Input Class Initialized
INFO - 2023-10-16 11:48:59 --> Language Class Initialized
INFO - 2023-10-16 11:48:59 --> Loader Class Initialized
INFO - 2023-10-16 11:48:59 --> Helper loaded: url_helper
INFO - 2023-10-16 11:48:59 --> Helper loaded: file_helper
INFO - 2023-10-16 11:48:59 --> Helper loaded: html_helper
INFO - 2023-10-16 11:48:59 --> Helper loaded: text_helper
INFO - 2023-10-16 11:48:59 --> Helper loaded: form_helper
INFO - 2023-10-16 11:48:59 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:48:59 --> Helper loaded: security_helper
INFO - 2023-10-16 11:48:59 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:48:59 --> Database Driver Class Initialized
INFO - 2023-10-16 11:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:48:59 --> Parser Class Initialized
INFO - 2023-10-16 11:48:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:48:59 --> Pagination Class Initialized
INFO - 2023-10-16 11:48:59 --> Form Validation Class Initialized
INFO - 2023-10-16 11:48:59 --> Controller Class Initialized
INFO - 2023-10-16 11:48:59 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:59 --> Model Class Initialized
DEBUG - 2023-10-16 11:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:48:59 --> Model Class Initialized
INFO - 2023-10-16 11:48:59 --> Final output sent to browser
DEBUG - 2023-10-16 11:48:59 --> Total execution time: 0.0491
ERROR - 2023-10-16 11:49:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:49:06 --> Config Class Initialized
INFO - 2023-10-16 11:49:06 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:49:06 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:49:06 --> Utf8 Class Initialized
INFO - 2023-10-16 11:49:06 --> URI Class Initialized
INFO - 2023-10-16 11:49:06 --> Router Class Initialized
INFO - 2023-10-16 11:49:06 --> Output Class Initialized
INFO - 2023-10-16 11:49:06 --> Security Class Initialized
DEBUG - 2023-10-16 11:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:49:06 --> Input Class Initialized
INFO - 2023-10-16 11:49:06 --> Language Class Initialized
INFO - 2023-10-16 11:49:06 --> Loader Class Initialized
INFO - 2023-10-16 11:49:06 --> Helper loaded: url_helper
INFO - 2023-10-16 11:49:06 --> Helper loaded: file_helper
INFO - 2023-10-16 11:49:06 --> Helper loaded: html_helper
INFO - 2023-10-16 11:49:06 --> Helper loaded: text_helper
INFO - 2023-10-16 11:49:06 --> Helper loaded: form_helper
INFO - 2023-10-16 11:49:06 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:49:06 --> Helper loaded: security_helper
INFO - 2023-10-16 11:49:06 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:49:06 --> Database Driver Class Initialized
INFO - 2023-10-16 11:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:49:06 --> Parser Class Initialized
INFO - 2023-10-16 11:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:49:06 --> Pagination Class Initialized
INFO - 2023-10-16 11:49:06 --> Form Validation Class Initialized
INFO - 2023-10-16 11:49:06 --> Controller Class Initialized
INFO - 2023-10-16 11:49:06 --> Model Class Initialized
DEBUG - 2023-10-16 11:49:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:49:06 --> Model Class Initialized
DEBUG - 2023-10-16 11:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:49:06 --> Model Class Initialized
INFO - 2023-10-16 11:49:06 --> Final output sent to browser
DEBUG - 2023-10-16 11:49:06 --> Total execution time: 0.1196
ERROR - 2023-10-16 11:50:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:50:00 --> Config Class Initialized
INFO - 2023-10-16 11:50:00 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:50:00 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:50:00 --> Utf8 Class Initialized
INFO - 2023-10-16 11:50:00 --> URI Class Initialized
INFO - 2023-10-16 11:50:00 --> Router Class Initialized
INFO - 2023-10-16 11:50:00 --> Output Class Initialized
INFO - 2023-10-16 11:50:00 --> Security Class Initialized
DEBUG - 2023-10-16 11:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:50:00 --> Input Class Initialized
INFO - 2023-10-16 11:50:00 --> Language Class Initialized
INFO - 2023-10-16 11:50:00 --> Loader Class Initialized
INFO - 2023-10-16 11:50:00 --> Helper loaded: url_helper
INFO - 2023-10-16 11:50:00 --> Helper loaded: file_helper
INFO - 2023-10-16 11:50:00 --> Helper loaded: html_helper
INFO - 2023-10-16 11:50:00 --> Helper loaded: text_helper
INFO - 2023-10-16 11:50:00 --> Helper loaded: form_helper
INFO - 2023-10-16 11:50:00 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:50:00 --> Helper loaded: security_helper
INFO - 2023-10-16 11:50:00 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:50:00 --> Database Driver Class Initialized
INFO - 2023-10-16 11:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:50:00 --> Parser Class Initialized
INFO - 2023-10-16 11:50:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:50:00 --> Pagination Class Initialized
INFO - 2023-10-16 11:50:00 --> Form Validation Class Initialized
INFO - 2023-10-16 11:50:00 --> Controller Class Initialized
INFO - 2023-10-16 11:50:00 --> Model Class Initialized
DEBUG - 2023-10-16 11:50:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:50:00 --> Model Class Initialized
DEBUG - 2023-10-16 11:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:50:00 --> Model Class Initialized
INFO - 2023-10-16 11:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-10-16 11:50:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:50:00 --> Model Class Initialized
INFO - 2023-10-16 11:50:00 --> Model Class Initialized
INFO - 2023-10-16 11:50:00 --> Model Class Initialized
INFO - 2023-10-16 11:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:50:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:50:00 --> Final output sent to browser
DEBUG - 2023-10-16 11:50:00 --> Total execution time: 0.1988
ERROR - 2023-10-16 11:50:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:50:12 --> Config Class Initialized
INFO - 2023-10-16 11:50:12 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:50:12 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:50:12 --> Utf8 Class Initialized
INFO - 2023-10-16 11:50:12 --> URI Class Initialized
INFO - 2023-10-16 11:50:12 --> Router Class Initialized
INFO - 2023-10-16 11:50:12 --> Output Class Initialized
INFO - 2023-10-16 11:50:12 --> Security Class Initialized
DEBUG - 2023-10-16 11:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:50:12 --> Input Class Initialized
INFO - 2023-10-16 11:50:12 --> Language Class Initialized
INFO - 2023-10-16 11:50:12 --> Loader Class Initialized
INFO - 2023-10-16 11:50:12 --> Helper loaded: url_helper
INFO - 2023-10-16 11:50:12 --> Helper loaded: file_helper
INFO - 2023-10-16 11:50:12 --> Helper loaded: html_helper
INFO - 2023-10-16 11:50:12 --> Helper loaded: text_helper
INFO - 2023-10-16 11:50:12 --> Helper loaded: form_helper
INFO - 2023-10-16 11:50:12 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:50:12 --> Helper loaded: security_helper
INFO - 2023-10-16 11:50:12 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:50:12 --> Database Driver Class Initialized
INFO - 2023-10-16 11:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:50:12 --> Parser Class Initialized
INFO - 2023-10-16 11:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:50:12 --> Pagination Class Initialized
INFO - 2023-10-16 11:50:12 --> Form Validation Class Initialized
INFO - 2023-10-16 11:50:12 --> Controller Class Initialized
INFO - 2023-10-16 11:50:12 --> Model Class Initialized
DEBUG - 2023-10-16 11:50:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:50:12 --> Model Class Initialized
DEBUG - 2023-10-16 11:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:50:12 --> Model Class Initialized
INFO - 2023-10-16 11:50:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-16 11:50:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:50:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:50:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:50:12 --> Model Class Initialized
INFO - 2023-10-16 11:50:12 --> Model Class Initialized
INFO - 2023-10-16 11:50:12 --> Model Class Initialized
INFO - 2023-10-16 11:50:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:50:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:50:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:50:12 --> Final output sent to browser
DEBUG - 2023-10-16 11:50:12 --> Total execution time: 0.1925
ERROR - 2023-10-16 11:50:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:50:13 --> Config Class Initialized
INFO - 2023-10-16 11:50:13 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:50:13 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:50:13 --> Utf8 Class Initialized
INFO - 2023-10-16 11:50:13 --> URI Class Initialized
INFO - 2023-10-16 11:50:13 --> Router Class Initialized
INFO - 2023-10-16 11:50:13 --> Output Class Initialized
INFO - 2023-10-16 11:50:13 --> Security Class Initialized
DEBUG - 2023-10-16 11:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:50:13 --> Input Class Initialized
INFO - 2023-10-16 11:50:13 --> Language Class Initialized
INFO - 2023-10-16 11:50:13 --> Loader Class Initialized
INFO - 2023-10-16 11:50:13 --> Helper loaded: url_helper
INFO - 2023-10-16 11:50:13 --> Helper loaded: file_helper
INFO - 2023-10-16 11:50:13 --> Helper loaded: html_helper
INFO - 2023-10-16 11:50:13 --> Helper loaded: text_helper
INFO - 2023-10-16 11:50:13 --> Helper loaded: form_helper
INFO - 2023-10-16 11:50:13 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:50:13 --> Helper loaded: security_helper
INFO - 2023-10-16 11:50:13 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:50:13 --> Database Driver Class Initialized
INFO - 2023-10-16 11:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:50:13 --> Parser Class Initialized
INFO - 2023-10-16 11:50:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:50:13 --> Pagination Class Initialized
INFO - 2023-10-16 11:50:13 --> Form Validation Class Initialized
INFO - 2023-10-16 11:50:13 --> Controller Class Initialized
INFO - 2023-10-16 11:50:13 --> Model Class Initialized
DEBUG - 2023-10-16 11:50:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:50:13 --> Model Class Initialized
DEBUG - 2023-10-16 11:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:50:13 --> Model Class Initialized
INFO - 2023-10-16 11:50:13 --> Final output sent to browser
DEBUG - 2023-10-16 11:50:13 --> Total execution time: 0.0463
ERROR - 2023-10-16 11:52:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:52:28 --> Config Class Initialized
INFO - 2023-10-16 11:52:28 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:52:28 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:52:28 --> Utf8 Class Initialized
INFO - 2023-10-16 11:52:28 --> URI Class Initialized
INFO - 2023-10-16 11:52:28 --> Router Class Initialized
INFO - 2023-10-16 11:52:28 --> Output Class Initialized
INFO - 2023-10-16 11:52:28 --> Security Class Initialized
DEBUG - 2023-10-16 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:52:28 --> Input Class Initialized
INFO - 2023-10-16 11:52:28 --> Language Class Initialized
INFO - 2023-10-16 11:52:28 --> Loader Class Initialized
INFO - 2023-10-16 11:52:28 --> Helper loaded: url_helper
INFO - 2023-10-16 11:52:28 --> Helper loaded: file_helper
INFO - 2023-10-16 11:52:28 --> Helper loaded: html_helper
INFO - 2023-10-16 11:52:28 --> Helper loaded: text_helper
INFO - 2023-10-16 11:52:28 --> Helper loaded: form_helper
INFO - 2023-10-16 11:52:28 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:52:28 --> Helper loaded: security_helper
INFO - 2023-10-16 11:52:28 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:52:28 --> Database Driver Class Initialized
INFO - 2023-10-16 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:52:28 --> Parser Class Initialized
INFO - 2023-10-16 11:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:52:28 --> Pagination Class Initialized
INFO - 2023-10-16 11:52:28 --> Form Validation Class Initialized
INFO - 2023-10-16 11:52:28 --> Controller Class Initialized
INFO - 2023-10-16 11:52:28 --> Model Class Initialized
DEBUG - 2023-10-16 11:52:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:52:28 --> Model Class Initialized
DEBUG - 2023-10-16 11:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:52:28 --> Model Class Initialized
INFO - 2023-10-16 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-16 11:52:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:52:28 --> Model Class Initialized
INFO - 2023-10-16 11:52:28 --> Model Class Initialized
INFO - 2023-10-16 11:52:28 --> Model Class Initialized
INFO - 2023-10-16 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:52:28 --> Final output sent to browser
DEBUG - 2023-10-16 11:52:28 --> Total execution time: 0.2013
ERROR - 2023-10-16 11:52:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:52:29 --> Config Class Initialized
INFO - 2023-10-16 11:52:29 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:52:29 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:52:29 --> Utf8 Class Initialized
INFO - 2023-10-16 11:52:29 --> URI Class Initialized
INFO - 2023-10-16 11:52:29 --> Router Class Initialized
INFO - 2023-10-16 11:52:29 --> Output Class Initialized
INFO - 2023-10-16 11:52:29 --> Security Class Initialized
DEBUG - 2023-10-16 11:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:52:29 --> Input Class Initialized
INFO - 2023-10-16 11:52:29 --> Language Class Initialized
INFO - 2023-10-16 11:52:29 --> Loader Class Initialized
INFO - 2023-10-16 11:52:29 --> Helper loaded: url_helper
INFO - 2023-10-16 11:52:29 --> Helper loaded: file_helper
INFO - 2023-10-16 11:52:29 --> Helper loaded: html_helper
INFO - 2023-10-16 11:52:29 --> Helper loaded: text_helper
INFO - 2023-10-16 11:52:29 --> Helper loaded: form_helper
INFO - 2023-10-16 11:52:29 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:52:29 --> Helper loaded: security_helper
INFO - 2023-10-16 11:52:29 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:52:29 --> Database Driver Class Initialized
INFO - 2023-10-16 11:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:52:29 --> Parser Class Initialized
INFO - 2023-10-16 11:52:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:52:29 --> Pagination Class Initialized
INFO - 2023-10-16 11:52:29 --> Form Validation Class Initialized
INFO - 2023-10-16 11:52:29 --> Controller Class Initialized
INFO - 2023-10-16 11:52:29 --> Model Class Initialized
DEBUG - 2023-10-16 11:52:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:52:29 --> Model Class Initialized
DEBUG - 2023-10-16 11:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:52:29 --> Model Class Initialized
INFO - 2023-10-16 11:52:29 --> Final output sent to browser
DEBUG - 2023-10-16 11:52:29 --> Total execution time: 0.0504
ERROR - 2023-10-16 11:52:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:52:31 --> Config Class Initialized
INFO - 2023-10-16 11:52:31 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:52:31 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:52:31 --> Utf8 Class Initialized
INFO - 2023-10-16 11:52:31 --> URI Class Initialized
DEBUG - 2023-10-16 11:52:31 --> No URI present. Default controller set.
INFO - 2023-10-16 11:52:31 --> Router Class Initialized
INFO - 2023-10-16 11:52:31 --> Output Class Initialized
INFO - 2023-10-16 11:52:31 --> Security Class Initialized
DEBUG - 2023-10-16 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:52:31 --> Input Class Initialized
INFO - 2023-10-16 11:52:31 --> Language Class Initialized
INFO - 2023-10-16 11:52:31 --> Loader Class Initialized
INFO - 2023-10-16 11:52:31 --> Helper loaded: url_helper
INFO - 2023-10-16 11:52:31 --> Helper loaded: file_helper
INFO - 2023-10-16 11:52:31 --> Helper loaded: html_helper
INFO - 2023-10-16 11:52:31 --> Helper loaded: text_helper
INFO - 2023-10-16 11:52:31 --> Helper loaded: form_helper
INFO - 2023-10-16 11:52:31 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:52:31 --> Helper loaded: security_helper
INFO - 2023-10-16 11:52:31 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:52:31 --> Database Driver Class Initialized
INFO - 2023-10-16 11:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:52:31 --> Parser Class Initialized
INFO - 2023-10-16 11:52:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:52:31 --> Pagination Class Initialized
INFO - 2023-10-16 11:52:31 --> Form Validation Class Initialized
INFO - 2023-10-16 11:52:31 --> Controller Class Initialized
INFO - 2023-10-16 11:52:31 --> Model Class Initialized
DEBUG - 2023-10-16 11:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:52:31 --> Model Class Initialized
DEBUG - 2023-10-16 11:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:52:31 --> Model Class Initialized
INFO - 2023-10-16 11:52:31 --> Model Class Initialized
INFO - 2023-10-16 11:52:31 --> Model Class Initialized
INFO - 2023-10-16 11:52:31 --> Model Class Initialized
DEBUG - 2023-10-16 11:52:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:52:31 --> Model Class Initialized
INFO - 2023-10-16 11:52:31 --> Model Class Initialized
INFO - 2023-10-16 11:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-16 11:52:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:52:31 --> Model Class Initialized
INFO - 2023-10-16 11:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:52:31 --> Final output sent to browser
DEBUG - 2023-10-16 11:52:31 --> Total execution time: 0.3435
ERROR - 2023-10-16 11:54:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:54:24 --> Config Class Initialized
INFO - 2023-10-16 11:54:24 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:54:24 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:54:24 --> Utf8 Class Initialized
INFO - 2023-10-16 11:54:24 --> URI Class Initialized
DEBUG - 2023-10-16 11:54:24 --> No URI present. Default controller set.
INFO - 2023-10-16 11:54:24 --> Router Class Initialized
INFO - 2023-10-16 11:54:24 --> Output Class Initialized
INFO - 2023-10-16 11:54:24 --> Security Class Initialized
DEBUG - 2023-10-16 11:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:54:24 --> Input Class Initialized
INFO - 2023-10-16 11:54:24 --> Language Class Initialized
INFO - 2023-10-16 11:54:24 --> Loader Class Initialized
INFO - 2023-10-16 11:54:24 --> Helper loaded: url_helper
INFO - 2023-10-16 11:54:24 --> Helper loaded: file_helper
INFO - 2023-10-16 11:54:24 --> Helper loaded: html_helper
INFO - 2023-10-16 11:54:24 --> Helper loaded: text_helper
INFO - 2023-10-16 11:54:24 --> Helper loaded: form_helper
INFO - 2023-10-16 11:54:24 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:54:24 --> Helper loaded: security_helper
INFO - 2023-10-16 11:54:24 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:54:24 --> Database Driver Class Initialized
INFO - 2023-10-16 11:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:54:24 --> Parser Class Initialized
INFO - 2023-10-16 11:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:54:24 --> Pagination Class Initialized
INFO - 2023-10-16 11:54:24 --> Form Validation Class Initialized
INFO - 2023-10-16 11:54:24 --> Controller Class Initialized
INFO - 2023-10-16 11:54:24 --> Model Class Initialized
DEBUG - 2023-10-16 11:54:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-16 11:54:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:54:25 --> Config Class Initialized
INFO - 2023-10-16 11:54:25 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:54:25 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:54:25 --> Utf8 Class Initialized
INFO - 2023-10-16 11:54:25 --> URI Class Initialized
INFO - 2023-10-16 11:54:25 --> Router Class Initialized
INFO - 2023-10-16 11:54:25 --> Output Class Initialized
INFO - 2023-10-16 11:54:25 --> Security Class Initialized
DEBUG - 2023-10-16 11:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:54:25 --> Input Class Initialized
INFO - 2023-10-16 11:54:25 --> Language Class Initialized
INFO - 2023-10-16 11:54:25 --> Loader Class Initialized
INFO - 2023-10-16 11:54:25 --> Helper loaded: url_helper
INFO - 2023-10-16 11:54:25 --> Helper loaded: file_helper
INFO - 2023-10-16 11:54:25 --> Helper loaded: html_helper
INFO - 2023-10-16 11:54:25 --> Helper loaded: text_helper
INFO - 2023-10-16 11:54:25 --> Helper loaded: form_helper
INFO - 2023-10-16 11:54:25 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:54:25 --> Helper loaded: security_helper
INFO - 2023-10-16 11:54:25 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:54:25 --> Database Driver Class Initialized
INFO - 2023-10-16 11:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:54:25 --> Parser Class Initialized
INFO - 2023-10-16 11:54:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:54:25 --> Pagination Class Initialized
INFO - 2023-10-16 11:54:25 --> Form Validation Class Initialized
INFO - 2023-10-16 11:54:25 --> Controller Class Initialized
INFO - 2023-10-16 11:54:25 --> Model Class Initialized
DEBUG - 2023-10-16 11:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-16 11:54:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:54:25 --> Model Class Initialized
INFO - 2023-10-16 11:54:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:54:25 --> Final output sent to browser
DEBUG - 2023-10-16 11:54:25 --> Total execution time: 0.0286
ERROR - 2023-10-16 11:56:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:56:11 --> Config Class Initialized
INFO - 2023-10-16 11:56:11 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:56:11 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:56:11 --> Utf8 Class Initialized
INFO - 2023-10-16 11:56:11 --> URI Class Initialized
INFO - 2023-10-16 11:56:11 --> Router Class Initialized
INFO - 2023-10-16 11:56:11 --> Output Class Initialized
INFO - 2023-10-16 11:56:11 --> Security Class Initialized
DEBUG - 2023-10-16 11:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:56:11 --> Input Class Initialized
INFO - 2023-10-16 11:56:11 --> Language Class Initialized
INFO - 2023-10-16 11:56:11 --> Loader Class Initialized
INFO - 2023-10-16 11:56:11 --> Helper loaded: url_helper
INFO - 2023-10-16 11:56:11 --> Helper loaded: file_helper
INFO - 2023-10-16 11:56:11 --> Helper loaded: html_helper
INFO - 2023-10-16 11:56:11 --> Helper loaded: text_helper
INFO - 2023-10-16 11:56:11 --> Helper loaded: form_helper
INFO - 2023-10-16 11:56:11 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:56:11 --> Helper loaded: security_helper
INFO - 2023-10-16 11:56:11 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:56:11 --> Database Driver Class Initialized
INFO - 2023-10-16 11:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:56:11 --> Parser Class Initialized
INFO - 2023-10-16 11:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:56:11 --> Pagination Class Initialized
INFO - 2023-10-16 11:56:11 --> Form Validation Class Initialized
INFO - 2023-10-16 11:56:11 --> Controller Class Initialized
INFO - 2023-10-16 11:56:11 --> Model Class Initialized
DEBUG - 2023-10-16 11:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:56:11 --> Model Class Initialized
INFO - 2023-10-16 11:56:11 --> Final output sent to browser
DEBUG - 2023-10-16 11:56:11 --> Total execution time: 0.0216
ERROR - 2023-10-16 11:56:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:56:12 --> Config Class Initialized
INFO - 2023-10-16 11:56:12 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:56:12 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:56:12 --> Utf8 Class Initialized
INFO - 2023-10-16 11:56:12 --> URI Class Initialized
DEBUG - 2023-10-16 11:56:12 --> No URI present. Default controller set.
INFO - 2023-10-16 11:56:12 --> Router Class Initialized
INFO - 2023-10-16 11:56:12 --> Output Class Initialized
INFO - 2023-10-16 11:56:12 --> Security Class Initialized
DEBUG - 2023-10-16 11:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:56:12 --> Input Class Initialized
INFO - 2023-10-16 11:56:12 --> Language Class Initialized
INFO - 2023-10-16 11:56:12 --> Loader Class Initialized
INFO - 2023-10-16 11:56:12 --> Helper loaded: url_helper
INFO - 2023-10-16 11:56:12 --> Helper loaded: file_helper
INFO - 2023-10-16 11:56:12 --> Helper loaded: html_helper
INFO - 2023-10-16 11:56:12 --> Helper loaded: text_helper
INFO - 2023-10-16 11:56:12 --> Helper loaded: form_helper
INFO - 2023-10-16 11:56:12 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:56:12 --> Helper loaded: security_helper
INFO - 2023-10-16 11:56:12 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:56:12 --> Database Driver Class Initialized
INFO - 2023-10-16 11:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:56:12 --> Parser Class Initialized
INFO - 2023-10-16 11:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:56:12 --> Pagination Class Initialized
INFO - 2023-10-16 11:56:12 --> Form Validation Class Initialized
INFO - 2023-10-16 11:56:12 --> Controller Class Initialized
INFO - 2023-10-16 11:56:12 --> Model Class Initialized
DEBUG - 2023-10-16 11:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:56:12 --> Model Class Initialized
DEBUG - 2023-10-16 11:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:56:12 --> Model Class Initialized
INFO - 2023-10-16 11:56:12 --> Model Class Initialized
INFO - 2023-10-16 11:56:12 --> Model Class Initialized
INFO - 2023-10-16 11:56:12 --> Model Class Initialized
DEBUG - 2023-10-16 11:56:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:56:12 --> Model Class Initialized
INFO - 2023-10-16 11:56:12 --> Model Class Initialized
INFO - 2023-10-16 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-16 11:56:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:56:12 --> Model Class Initialized
INFO - 2023-10-16 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:56:12 --> Final output sent to browser
DEBUG - 2023-10-16 11:56:12 --> Total execution time: 0.1884
ERROR - 2023-10-16 11:58:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:58:42 --> Config Class Initialized
INFO - 2023-10-16 11:58:42 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:58:42 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:58:42 --> Utf8 Class Initialized
INFO - 2023-10-16 11:58:42 --> URI Class Initialized
INFO - 2023-10-16 11:58:42 --> Router Class Initialized
INFO - 2023-10-16 11:58:42 --> Output Class Initialized
INFO - 2023-10-16 11:58:42 --> Security Class Initialized
DEBUG - 2023-10-16 11:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:58:42 --> Input Class Initialized
INFO - 2023-10-16 11:58:42 --> Language Class Initialized
INFO - 2023-10-16 11:58:42 --> Loader Class Initialized
INFO - 2023-10-16 11:58:42 --> Helper loaded: url_helper
INFO - 2023-10-16 11:58:42 --> Helper loaded: file_helper
INFO - 2023-10-16 11:58:42 --> Helper loaded: html_helper
INFO - 2023-10-16 11:58:42 --> Helper loaded: text_helper
INFO - 2023-10-16 11:58:42 --> Helper loaded: form_helper
INFO - 2023-10-16 11:58:42 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:58:42 --> Helper loaded: security_helper
INFO - 2023-10-16 11:58:42 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:58:42 --> Database Driver Class Initialized
INFO - 2023-10-16 11:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:58:42 --> Parser Class Initialized
INFO - 2023-10-16 11:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:58:42 --> Pagination Class Initialized
INFO - 2023-10-16 11:58:42 --> Form Validation Class Initialized
INFO - 2023-10-16 11:58:42 --> Controller Class Initialized
INFO - 2023-10-16 11:58:42 --> Model Class Initialized
DEBUG - 2023-10-16 11:58:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:58:42 --> Model Class Initialized
DEBUG - 2023-10-16 11:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:58:42 --> Model Class Initialized
INFO - 2023-10-16 11:58:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-16 11:58:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:58:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 11:58:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 11:58:42 --> Model Class Initialized
INFO - 2023-10-16 11:58:42 --> Model Class Initialized
INFO - 2023-10-16 11:58:42 --> Model Class Initialized
INFO - 2023-10-16 11:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 11:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 11:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 11:58:43 --> Final output sent to browser
DEBUG - 2023-10-16 11:58:43 --> Total execution time: 0.1299
ERROR - 2023-10-16 11:58:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:58:43 --> Config Class Initialized
INFO - 2023-10-16 11:58:43 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:58:43 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:58:43 --> Utf8 Class Initialized
INFO - 2023-10-16 11:58:43 --> URI Class Initialized
INFO - 2023-10-16 11:58:43 --> Router Class Initialized
INFO - 2023-10-16 11:58:43 --> Output Class Initialized
INFO - 2023-10-16 11:58:43 --> Security Class Initialized
DEBUG - 2023-10-16 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:58:43 --> Input Class Initialized
INFO - 2023-10-16 11:58:43 --> Language Class Initialized
INFO - 2023-10-16 11:58:43 --> Loader Class Initialized
INFO - 2023-10-16 11:58:43 --> Helper loaded: url_helper
INFO - 2023-10-16 11:58:43 --> Helper loaded: file_helper
INFO - 2023-10-16 11:58:43 --> Helper loaded: html_helper
INFO - 2023-10-16 11:58:43 --> Helper loaded: text_helper
INFO - 2023-10-16 11:58:43 --> Helper loaded: form_helper
INFO - 2023-10-16 11:58:43 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:58:43 --> Helper loaded: security_helper
INFO - 2023-10-16 11:58:43 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:58:43 --> Database Driver Class Initialized
INFO - 2023-10-16 11:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:58:43 --> Parser Class Initialized
INFO - 2023-10-16 11:58:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:58:43 --> Pagination Class Initialized
INFO - 2023-10-16 11:58:43 --> Form Validation Class Initialized
INFO - 2023-10-16 11:58:43 --> Controller Class Initialized
INFO - 2023-10-16 11:58:43 --> Model Class Initialized
DEBUG - 2023-10-16 11:58:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:58:43 --> Model Class Initialized
DEBUG - 2023-10-16 11:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:58:43 --> Model Class Initialized
INFO - 2023-10-16 11:58:43 --> Final output sent to browser
DEBUG - 2023-10-16 11:58:43 --> Total execution time: 0.0376
ERROR - 2023-10-16 11:59:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 11:59:33 --> Config Class Initialized
INFO - 2023-10-16 11:59:33 --> Hooks Class Initialized
DEBUG - 2023-10-16 11:59:33 --> UTF-8 Support Enabled
INFO - 2023-10-16 11:59:33 --> Utf8 Class Initialized
INFO - 2023-10-16 11:59:33 --> URI Class Initialized
INFO - 2023-10-16 11:59:33 --> Router Class Initialized
INFO - 2023-10-16 11:59:33 --> Output Class Initialized
INFO - 2023-10-16 11:59:33 --> Security Class Initialized
DEBUG - 2023-10-16 11:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 11:59:33 --> Input Class Initialized
INFO - 2023-10-16 11:59:33 --> Language Class Initialized
INFO - 2023-10-16 11:59:33 --> Loader Class Initialized
INFO - 2023-10-16 11:59:33 --> Helper loaded: url_helper
INFO - 2023-10-16 11:59:33 --> Helper loaded: file_helper
INFO - 2023-10-16 11:59:33 --> Helper loaded: html_helper
INFO - 2023-10-16 11:59:33 --> Helper loaded: text_helper
INFO - 2023-10-16 11:59:33 --> Helper loaded: form_helper
INFO - 2023-10-16 11:59:33 --> Helper loaded: lang_helper
INFO - 2023-10-16 11:59:33 --> Helper loaded: security_helper
INFO - 2023-10-16 11:59:33 --> Helper loaded: cookie_helper
INFO - 2023-10-16 11:59:33 --> Database Driver Class Initialized
INFO - 2023-10-16 11:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 11:59:33 --> Parser Class Initialized
INFO - 2023-10-16 11:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 11:59:33 --> Pagination Class Initialized
INFO - 2023-10-16 11:59:33 --> Form Validation Class Initialized
INFO - 2023-10-16 11:59:33 --> Controller Class Initialized
INFO - 2023-10-16 11:59:33 --> Model Class Initialized
DEBUG - 2023-10-16 11:59:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 11:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:59:33 --> Model Class Initialized
DEBUG - 2023-10-16 11:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 11:59:33 --> Model Class Initialized
INFO - 2023-10-16 11:59:33 --> Final output sent to browser
DEBUG - 2023-10-16 11:59:33 --> Total execution time: 0.0642
ERROR - 2023-10-16 12:17:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 12:17:38 --> Config Class Initialized
INFO - 2023-10-16 12:17:38 --> Hooks Class Initialized
DEBUG - 2023-10-16 12:17:38 --> UTF-8 Support Enabled
INFO - 2023-10-16 12:17:38 --> Utf8 Class Initialized
INFO - 2023-10-16 12:17:38 --> URI Class Initialized
DEBUG - 2023-10-16 12:17:38 --> No URI present. Default controller set.
INFO - 2023-10-16 12:17:38 --> Router Class Initialized
INFO - 2023-10-16 12:17:38 --> Output Class Initialized
INFO - 2023-10-16 12:17:38 --> Security Class Initialized
DEBUG - 2023-10-16 12:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 12:17:38 --> Input Class Initialized
INFO - 2023-10-16 12:17:38 --> Language Class Initialized
INFO - 2023-10-16 12:17:38 --> Loader Class Initialized
INFO - 2023-10-16 12:17:38 --> Helper loaded: url_helper
INFO - 2023-10-16 12:17:38 --> Helper loaded: file_helper
INFO - 2023-10-16 12:17:38 --> Helper loaded: html_helper
INFO - 2023-10-16 12:17:38 --> Helper loaded: text_helper
INFO - 2023-10-16 12:17:38 --> Helper loaded: form_helper
INFO - 2023-10-16 12:17:38 --> Helper loaded: lang_helper
INFO - 2023-10-16 12:17:38 --> Helper loaded: security_helper
INFO - 2023-10-16 12:17:38 --> Helper loaded: cookie_helper
INFO - 2023-10-16 12:17:38 --> Database Driver Class Initialized
INFO - 2023-10-16 12:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 12:17:38 --> Parser Class Initialized
INFO - 2023-10-16 12:17:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 12:17:38 --> Pagination Class Initialized
INFO - 2023-10-16 12:17:38 --> Form Validation Class Initialized
INFO - 2023-10-16 12:17:38 --> Controller Class Initialized
INFO - 2023-10-16 12:17:38 --> Model Class Initialized
DEBUG - 2023-10-16 12:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 12:17:38 --> Model Class Initialized
DEBUG - 2023-10-16 12:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 12:17:38 --> Model Class Initialized
INFO - 2023-10-16 12:17:38 --> Model Class Initialized
INFO - 2023-10-16 12:17:38 --> Model Class Initialized
INFO - 2023-10-16 12:17:38 --> Model Class Initialized
DEBUG - 2023-10-16 12:17:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-16 12:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 12:17:38 --> Model Class Initialized
INFO - 2023-10-16 12:17:38 --> Model Class Initialized
INFO - 2023-10-16 12:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-16 12:17:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 12:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 12:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 12:17:38 --> Model Class Initialized
INFO - 2023-10-16 12:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-16 12:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-16 12:17:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 12:17:38 --> Final output sent to browser
DEBUG - 2023-10-16 12:17:38 --> Total execution time: 0.3715
ERROR - 2023-10-16 14:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 14:13:37 --> Config Class Initialized
INFO - 2023-10-16 14:13:37 --> Hooks Class Initialized
DEBUG - 2023-10-16 14:13:37 --> UTF-8 Support Enabled
INFO - 2023-10-16 14:13:37 --> Utf8 Class Initialized
INFO - 2023-10-16 14:13:37 --> URI Class Initialized
DEBUG - 2023-10-16 14:13:37 --> No URI present. Default controller set.
INFO - 2023-10-16 14:13:37 --> Router Class Initialized
INFO - 2023-10-16 14:13:37 --> Output Class Initialized
INFO - 2023-10-16 14:13:37 --> Security Class Initialized
DEBUG - 2023-10-16 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 14:13:37 --> Input Class Initialized
INFO - 2023-10-16 14:13:37 --> Language Class Initialized
INFO - 2023-10-16 14:13:37 --> Loader Class Initialized
INFO - 2023-10-16 14:13:37 --> Helper loaded: url_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: file_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: html_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: text_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: form_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: lang_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: security_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: cookie_helper
INFO - 2023-10-16 14:13:37 --> Database Driver Class Initialized
INFO - 2023-10-16 14:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 14:13:37 --> Parser Class Initialized
INFO - 2023-10-16 14:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 14:13:37 --> Pagination Class Initialized
INFO - 2023-10-16 14:13:37 --> Form Validation Class Initialized
INFO - 2023-10-16 14:13:37 --> Controller Class Initialized
INFO - 2023-10-16 14:13:37 --> Model Class Initialized
DEBUG - 2023-10-16 14:13:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-16 14:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-16 14:13:37 --> Config Class Initialized
INFO - 2023-10-16 14:13:37 --> Hooks Class Initialized
DEBUG - 2023-10-16 14:13:37 --> UTF-8 Support Enabled
INFO - 2023-10-16 14:13:37 --> Utf8 Class Initialized
INFO - 2023-10-16 14:13:37 --> URI Class Initialized
INFO - 2023-10-16 14:13:37 --> Router Class Initialized
INFO - 2023-10-16 14:13:37 --> Output Class Initialized
INFO - 2023-10-16 14:13:37 --> Security Class Initialized
DEBUG - 2023-10-16 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-16 14:13:37 --> Input Class Initialized
INFO - 2023-10-16 14:13:37 --> Language Class Initialized
INFO - 2023-10-16 14:13:37 --> Loader Class Initialized
INFO - 2023-10-16 14:13:37 --> Helper loaded: url_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: file_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: html_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: text_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: form_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: lang_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: security_helper
INFO - 2023-10-16 14:13:37 --> Helper loaded: cookie_helper
INFO - 2023-10-16 14:13:37 --> Database Driver Class Initialized
INFO - 2023-10-16 14:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-16 14:13:37 --> Parser Class Initialized
INFO - 2023-10-16 14:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-16 14:13:37 --> Pagination Class Initialized
INFO - 2023-10-16 14:13:37 --> Form Validation Class Initialized
INFO - 2023-10-16 14:13:37 --> Controller Class Initialized
INFO - 2023-10-16 14:13:37 --> Model Class Initialized
DEBUG - 2023-10-16 14:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-16 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-16 14:13:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-16 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-16 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-16 14:13:37 --> Model Class Initialized
INFO - 2023-10-16 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-16 14:13:37 --> Final output sent to browser
DEBUG - 2023-10-16 14:13:37 --> Total execution time: 0.0336
