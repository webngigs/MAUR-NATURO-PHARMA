<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-27 04:13:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 04:13:21 --> Config Class Initialized
INFO - 2024-03-27 04:13:21 --> Hooks Class Initialized
DEBUG - 2024-03-27 04:13:21 --> UTF-8 Support Enabled
INFO - 2024-03-27 04:13:21 --> Utf8 Class Initialized
INFO - 2024-03-27 04:13:21 --> URI Class Initialized
DEBUG - 2024-03-27 04:13:21 --> No URI present. Default controller set.
INFO - 2024-03-27 04:13:21 --> Router Class Initialized
INFO - 2024-03-27 04:13:21 --> Output Class Initialized
INFO - 2024-03-27 04:13:21 --> Security Class Initialized
DEBUG - 2024-03-27 04:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 04:13:21 --> Input Class Initialized
INFO - 2024-03-27 04:13:21 --> Language Class Initialized
INFO - 2024-03-27 04:13:21 --> Loader Class Initialized
INFO - 2024-03-27 04:13:21 --> Helper loaded: url_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: file_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: html_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: text_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: form_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: lang_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: security_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: cookie_helper
INFO - 2024-03-27 04:13:21 --> Database Driver Class Initialized
INFO - 2024-03-27 04:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 04:13:21 --> Parser Class Initialized
INFO - 2024-03-27 04:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 04:13:21 --> Pagination Class Initialized
INFO - 2024-03-27 04:13:21 --> Form Validation Class Initialized
INFO - 2024-03-27 04:13:21 --> Controller Class Initialized
INFO - 2024-03-27 04:13:21 --> Model Class Initialized
DEBUG - 2024-03-27 04:13:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-27 04:13:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 04:13:21 --> Config Class Initialized
INFO - 2024-03-27 04:13:21 --> Hooks Class Initialized
DEBUG - 2024-03-27 04:13:21 --> UTF-8 Support Enabled
INFO - 2024-03-27 04:13:21 --> Utf8 Class Initialized
INFO - 2024-03-27 04:13:21 --> URI Class Initialized
INFO - 2024-03-27 04:13:21 --> Router Class Initialized
INFO - 2024-03-27 04:13:21 --> Output Class Initialized
INFO - 2024-03-27 04:13:21 --> Security Class Initialized
DEBUG - 2024-03-27 04:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 04:13:21 --> Input Class Initialized
INFO - 2024-03-27 04:13:21 --> Language Class Initialized
INFO - 2024-03-27 04:13:21 --> Loader Class Initialized
INFO - 2024-03-27 04:13:21 --> Helper loaded: url_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: file_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: html_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: text_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: form_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: lang_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: security_helper
INFO - 2024-03-27 04:13:21 --> Helper loaded: cookie_helper
INFO - 2024-03-27 04:13:21 --> Database Driver Class Initialized
INFO - 2024-03-27 04:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 04:13:21 --> Parser Class Initialized
INFO - 2024-03-27 04:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 04:13:21 --> Pagination Class Initialized
INFO - 2024-03-27 04:13:21 --> Form Validation Class Initialized
INFO - 2024-03-27 04:13:21 --> Controller Class Initialized
INFO - 2024-03-27 04:13:21 --> Model Class Initialized
DEBUG - 2024-03-27 04:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 04:13:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 04:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 04:13:21 --> Model Class Initialized
INFO - 2024-03-27 04:13:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 04:13:21 --> Final output sent to browser
DEBUG - 2024-03-27 04:13:21 --> Total execution time: 0.0340
ERROR - 2024-03-27 04:21:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 04:21:09 --> Config Class Initialized
INFO - 2024-03-27 04:21:09 --> Hooks Class Initialized
DEBUG - 2024-03-27 04:21:09 --> UTF-8 Support Enabled
INFO - 2024-03-27 04:21:09 --> Utf8 Class Initialized
INFO - 2024-03-27 04:21:09 --> URI Class Initialized
INFO - 2024-03-27 04:21:09 --> Router Class Initialized
INFO - 2024-03-27 04:21:09 --> Output Class Initialized
INFO - 2024-03-27 04:21:09 --> Security Class Initialized
DEBUG - 2024-03-27 04:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 04:21:09 --> Input Class Initialized
INFO - 2024-03-27 04:21:09 --> Language Class Initialized
INFO - 2024-03-27 04:21:09 --> Loader Class Initialized
INFO - 2024-03-27 04:21:09 --> Helper loaded: url_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: file_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: html_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: text_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: form_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: lang_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: security_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: cookie_helper
INFO - 2024-03-27 04:21:09 --> Database Driver Class Initialized
INFO - 2024-03-27 04:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 04:21:09 --> Parser Class Initialized
INFO - 2024-03-27 04:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 04:21:09 --> Pagination Class Initialized
INFO - 2024-03-27 04:21:09 --> Form Validation Class Initialized
INFO - 2024-03-27 04:21:09 --> Controller Class Initialized
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
DEBUG - 2024-03-27 04:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
INFO - 2024-03-27 04:21:09 --> Final output sent to browser
DEBUG - 2024-03-27 04:21:09 --> Total execution time: 0.0334
ERROR - 2024-03-27 04:21:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 04:21:09 --> Config Class Initialized
INFO - 2024-03-27 04:21:09 --> Hooks Class Initialized
DEBUG - 2024-03-27 04:21:09 --> UTF-8 Support Enabled
INFO - 2024-03-27 04:21:09 --> Utf8 Class Initialized
INFO - 2024-03-27 04:21:09 --> URI Class Initialized
DEBUG - 2024-03-27 04:21:09 --> No URI present. Default controller set.
INFO - 2024-03-27 04:21:09 --> Router Class Initialized
INFO - 2024-03-27 04:21:09 --> Output Class Initialized
INFO - 2024-03-27 04:21:09 --> Security Class Initialized
DEBUG - 2024-03-27 04:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 04:21:09 --> Input Class Initialized
INFO - 2024-03-27 04:21:09 --> Language Class Initialized
INFO - 2024-03-27 04:21:09 --> Loader Class Initialized
INFO - 2024-03-27 04:21:09 --> Helper loaded: url_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: file_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: html_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: text_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: form_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: lang_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: security_helper
INFO - 2024-03-27 04:21:09 --> Helper loaded: cookie_helper
INFO - 2024-03-27 04:21:09 --> Database Driver Class Initialized
INFO - 2024-03-27 04:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 04:21:09 --> Parser Class Initialized
INFO - 2024-03-27 04:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 04:21:09 --> Pagination Class Initialized
INFO - 2024-03-27 04:21:09 --> Form Validation Class Initialized
INFO - 2024-03-27 04:21:09 --> Controller Class Initialized
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
DEBUG - 2024-03-27 04:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
DEBUG - 2024-03-27 04:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
DEBUG - 2024-03-27 04:21:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 04:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
INFO - 2024-03-27 04:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-27 04:21:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 04:21:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 04:21:09 --> Model Class Initialized
INFO - 2024-03-27 04:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-27 04:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-27 04:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 04:21:10 --> Final output sent to browser
DEBUG - 2024-03-27 04:21:10 --> Total execution time: 0.4713
ERROR - 2024-03-27 04:21:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 04:21:11 --> Config Class Initialized
INFO - 2024-03-27 04:21:11 --> Hooks Class Initialized
DEBUG - 2024-03-27 04:21:11 --> UTF-8 Support Enabled
INFO - 2024-03-27 04:21:11 --> Utf8 Class Initialized
INFO - 2024-03-27 04:21:11 --> URI Class Initialized
INFO - 2024-03-27 04:21:11 --> Router Class Initialized
INFO - 2024-03-27 04:21:11 --> Output Class Initialized
INFO - 2024-03-27 04:21:11 --> Security Class Initialized
DEBUG - 2024-03-27 04:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 04:21:11 --> Input Class Initialized
INFO - 2024-03-27 04:21:11 --> Language Class Initialized
INFO - 2024-03-27 04:21:11 --> Loader Class Initialized
INFO - 2024-03-27 04:21:11 --> Helper loaded: url_helper
INFO - 2024-03-27 04:21:11 --> Helper loaded: file_helper
INFO - 2024-03-27 04:21:11 --> Helper loaded: html_helper
INFO - 2024-03-27 04:21:11 --> Helper loaded: text_helper
INFO - 2024-03-27 04:21:11 --> Helper loaded: form_helper
INFO - 2024-03-27 04:21:11 --> Helper loaded: lang_helper
INFO - 2024-03-27 04:21:11 --> Helper loaded: security_helper
INFO - 2024-03-27 04:21:11 --> Helper loaded: cookie_helper
INFO - 2024-03-27 04:21:11 --> Database Driver Class Initialized
INFO - 2024-03-27 04:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 04:21:11 --> Parser Class Initialized
INFO - 2024-03-27 04:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 04:21:11 --> Pagination Class Initialized
INFO - 2024-03-27 04:21:11 --> Form Validation Class Initialized
INFO - 2024-03-27 04:21:11 --> Controller Class Initialized
DEBUG - 2024-03-27 04:21:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 04:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:11 --> Model Class Initialized
INFO - 2024-03-27 04:21:11 --> Final output sent to browser
DEBUG - 2024-03-27 04:21:11 --> Total execution time: 0.0130
ERROR - 2024-03-27 04:21:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 04:21:24 --> Config Class Initialized
INFO - 2024-03-27 04:21:24 --> Hooks Class Initialized
DEBUG - 2024-03-27 04:21:24 --> UTF-8 Support Enabled
INFO - 2024-03-27 04:21:24 --> Utf8 Class Initialized
INFO - 2024-03-27 04:21:24 --> URI Class Initialized
INFO - 2024-03-27 04:21:24 --> Router Class Initialized
INFO - 2024-03-27 04:21:24 --> Output Class Initialized
INFO - 2024-03-27 04:21:24 --> Security Class Initialized
DEBUG - 2024-03-27 04:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 04:21:24 --> Input Class Initialized
INFO - 2024-03-27 04:21:24 --> Language Class Initialized
INFO - 2024-03-27 04:21:24 --> Loader Class Initialized
INFO - 2024-03-27 04:21:24 --> Helper loaded: url_helper
INFO - 2024-03-27 04:21:24 --> Helper loaded: file_helper
INFO - 2024-03-27 04:21:24 --> Helper loaded: html_helper
INFO - 2024-03-27 04:21:24 --> Helper loaded: text_helper
INFO - 2024-03-27 04:21:24 --> Helper loaded: form_helper
INFO - 2024-03-27 04:21:24 --> Helper loaded: lang_helper
INFO - 2024-03-27 04:21:24 --> Helper loaded: security_helper
INFO - 2024-03-27 04:21:24 --> Helper loaded: cookie_helper
INFO - 2024-03-27 04:21:24 --> Database Driver Class Initialized
INFO - 2024-03-27 04:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 04:21:24 --> Parser Class Initialized
INFO - 2024-03-27 04:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 04:21:24 --> Pagination Class Initialized
INFO - 2024-03-27 04:21:24 --> Form Validation Class Initialized
INFO - 2024-03-27 04:21:24 --> Controller Class Initialized
DEBUG - 2024-03-27 04:21:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 04:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:24 --> Model Class Initialized
DEBUG - 2024-03-27 04:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:24 --> Model Class Initialized
DEBUG - 2024-03-27 04:21:24 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:24 --> Model Class Initialized
INFO - 2024-03-27 04:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-27 04:21:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 04:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 04:21:24 --> Model Class Initialized
INFO - 2024-03-27 04:21:24 --> Model Class Initialized
INFO - 2024-03-27 04:21:24 --> Model Class Initialized
INFO - 2024-03-27 04:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-27 04:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-27 04:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 04:21:24 --> Final output sent to browser
DEBUG - 2024-03-27 04:21:24 --> Total execution time: 0.2399
ERROR - 2024-03-27 04:21:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 04:21:25 --> Config Class Initialized
INFO - 2024-03-27 04:21:25 --> Hooks Class Initialized
DEBUG - 2024-03-27 04:21:25 --> UTF-8 Support Enabled
INFO - 2024-03-27 04:21:25 --> Utf8 Class Initialized
INFO - 2024-03-27 04:21:25 --> URI Class Initialized
INFO - 2024-03-27 04:21:25 --> Router Class Initialized
INFO - 2024-03-27 04:21:25 --> Output Class Initialized
INFO - 2024-03-27 04:21:25 --> Security Class Initialized
DEBUG - 2024-03-27 04:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 04:21:25 --> Input Class Initialized
INFO - 2024-03-27 04:21:25 --> Language Class Initialized
INFO - 2024-03-27 04:21:25 --> Loader Class Initialized
INFO - 2024-03-27 04:21:25 --> Helper loaded: url_helper
INFO - 2024-03-27 04:21:25 --> Helper loaded: file_helper
INFO - 2024-03-27 04:21:25 --> Helper loaded: html_helper
INFO - 2024-03-27 04:21:25 --> Helper loaded: text_helper
INFO - 2024-03-27 04:21:25 --> Helper loaded: form_helper
INFO - 2024-03-27 04:21:25 --> Helper loaded: lang_helper
INFO - 2024-03-27 04:21:25 --> Helper loaded: security_helper
INFO - 2024-03-27 04:21:25 --> Helper loaded: cookie_helper
INFO - 2024-03-27 04:21:25 --> Database Driver Class Initialized
INFO - 2024-03-27 04:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 04:21:25 --> Parser Class Initialized
INFO - 2024-03-27 04:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 04:21:25 --> Pagination Class Initialized
INFO - 2024-03-27 04:21:25 --> Form Validation Class Initialized
INFO - 2024-03-27 04:21:25 --> Controller Class Initialized
DEBUG - 2024-03-27 04:21:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 04:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:25 --> Model Class Initialized
DEBUG - 2024-03-27 04:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 04:21:25 --> Model Class Initialized
INFO - 2024-03-27 04:21:25 --> Final output sent to browser
DEBUG - 2024-03-27 04:21:25 --> Total execution time: 0.0358
ERROR - 2024-03-27 08:20:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:20:55 --> Config Class Initialized
INFO - 2024-03-27 08:20:55 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:20:55 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:20:55 --> Utf8 Class Initialized
INFO - 2024-03-27 08:20:55 --> URI Class Initialized
DEBUG - 2024-03-27 08:20:55 --> No URI present. Default controller set.
INFO - 2024-03-27 08:20:55 --> Router Class Initialized
INFO - 2024-03-27 08:20:55 --> Output Class Initialized
INFO - 2024-03-27 08:20:55 --> Security Class Initialized
DEBUG - 2024-03-27 08:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:20:55 --> Input Class Initialized
INFO - 2024-03-27 08:20:55 --> Language Class Initialized
INFO - 2024-03-27 08:20:55 --> Loader Class Initialized
INFO - 2024-03-27 08:20:55 --> Helper loaded: url_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: file_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: html_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: text_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: form_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: security_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:20:55 --> Database Driver Class Initialized
INFO - 2024-03-27 08:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:20:55 --> Parser Class Initialized
INFO - 2024-03-27 08:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:20:55 --> Pagination Class Initialized
INFO - 2024-03-27 08:20:55 --> Form Validation Class Initialized
INFO - 2024-03-27 08:20:55 --> Controller Class Initialized
INFO - 2024-03-27 08:20:55 --> Model Class Initialized
DEBUG - 2024-03-27 08:20:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-27 08:20:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:20:55 --> Config Class Initialized
INFO - 2024-03-27 08:20:55 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:20:55 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:20:55 --> Utf8 Class Initialized
INFO - 2024-03-27 08:20:55 --> URI Class Initialized
INFO - 2024-03-27 08:20:55 --> Router Class Initialized
INFO - 2024-03-27 08:20:55 --> Output Class Initialized
INFO - 2024-03-27 08:20:55 --> Security Class Initialized
DEBUG - 2024-03-27 08:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:20:55 --> Input Class Initialized
INFO - 2024-03-27 08:20:55 --> Language Class Initialized
INFO - 2024-03-27 08:20:55 --> Loader Class Initialized
INFO - 2024-03-27 08:20:55 --> Helper loaded: url_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: file_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: html_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: text_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: form_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: security_helper
INFO - 2024-03-27 08:20:55 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:20:55 --> Database Driver Class Initialized
INFO - 2024-03-27 08:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:20:55 --> Parser Class Initialized
INFO - 2024-03-27 08:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:20:55 --> Pagination Class Initialized
INFO - 2024-03-27 08:20:55 --> Form Validation Class Initialized
INFO - 2024-03-27 08:20:55 --> Controller Class Initialized
INFO - 2024-03-27 08:20:55 --> Model Class Initialized
DEBUG - 2024-03-27 08:20:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:20:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 08:20:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:20:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 08:20:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 08:20:55 --> Model Class Initialized
INFO - 2024-03-27 08:20:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 08:20:55 --> Final output sent to browser
DEBUG - 2024-03-27 08:20:55 --> Total execution time: 0.0311
ERROR - 2024-03-27 08:21:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:21:04 --> Config Class Initialized
INFO - 2024-03-27 08:21:04 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:21:04 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:21:04 --> Utf8 Class Initialized
INFO - 2024-03-27 08:21:04 --> URI Class Initialized
INFO - 2024-03-27 08:21:04 --> Router Class Initialized
INFO - 2024-03-27 08:21:04 --> Output Class Initialized
INFO - 2024-03-27 08:21:04 --> Security Class Initialized
DEBUG - 2024-03-27 08:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:21:04 --> Input Class Initialized
INFO - 2024-03-27 08:21:04 --> Language Class Initialized
INFO - 2024-03-27 08:21:04 --> Loader Class Initialized
INFO - 2024-03-27 08:21:04 --> Helper loaded: url_helper
INFO - 2024-03-27 08:21:04 --> Helper loaded: file_helper
INFO - 2024-03-27 08:21:04 --> Helper loaded: html_helper
INFO - 2024-03-27 08:21:04 --> Helper loaded: text_helper
INFO - 2024-03-27 08:21:04 --> Helper loaded: form_helper
INFO - 2024-03-27 08:21:04 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:21:04 --> Helper loaded: security_helper
INFO - 2024-03-27 08:21:04 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:21:04 --> Database Driver Class Initialized
INFO - 2024-03-27 08:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:21:04 --> Parser Class Initialized
INFO - 2024-03-27 08:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:21:04 --> Pagination Class Initialized
INFO - 2024-03-27 08:21:04 --> Form Validation Class Initialized
INFO - 2024-03-27 08:21:04 --> Controller Class Initialized
INFO - 2024-03-27 08:21:04 --> Model Class Initialized
DEBUG - 2024-03-27 08:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:04 --> Model Class Initialized
INFO - 2024-03-27 08:21:04 --> Final output sent to browser
DEBUG - 2024-03-27 08:21:04 --> Total execution time: 0.0194
ERROR - 2024-03-27 08:21:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:21:05 --> Config Class Initialized
INFO - 2024-03-27 08:21:05 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:21:05 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:21:05 --> Utf8 Class Initialized
INFO - 2024-03-27 08:21:05 --> URI Class Initialized
DEBUG - 2024-03-27 08:21:05 --> No URI present. Default controller set.
INFO - 2024-03-27 08:21:05 --> Router Class Initialized
INFO - 2024-03-27 08:21:05 --> Output Class Initialized
INFO - 2024-03-27 08:21:05 --> Security Class Initialized
DEBUG - 2024-03-27 08:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:21:05 --> Input Class Initialized
INFO - 2024-03-27 08:21:05 --> Language Class Initialized
INFO - 2024-03-27 08:21:05 --> Loader Class Initialized
INFO - 2024-03-27 08:21:05 --> Helper loaded: url_helper
INFO - 2024-03-27 08:21:05 --> Helper loaded: file_helper
INFO - 2024-03-27 08:21:05 --> Helper loaded: html_helper
INFO - 2024-03-27 08:21:05 --> Helper loaded: text_helper
INFO - 2024-03-27 08:21:05 --> Helper loaded: form_helper
INFO - 2024-03-27 08:21:05 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:21:05 --> Helper loaded: security_helper
INFO - 2024-03-27 08:21:05 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:21:05 --> Database Driver Class Initialized
INFO - 2024-03-27 08:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:21:05 --> Parser Class Initialized
INFO - 2024-03-27 08:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:21:05 --> Pagination Class Initialized
INFO - 2024-03-27 08:21:05 --> Form Validation Class Initialized
INFO - 2024-03-27 08:21:05 --> Controller Class Initialized
INFO - 2024-03-27 08:21:05 --> Model Class Initialized
DEBUG - 2024-03-27 08:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:05 --> Model Class Initialized
DEBUG - 2024-03-27 08:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:05 --> Model Class Initialized
INFO - 2024-03-27 08:21:05 --> Model Class Initialized
INFO - 2024-03-27 08:21:05 --> Model Class Initialized
INFO - 2024-03-27 08:21:05 --> Model Class Initialized
DEBUG - 2024-03-27 08:21:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:05 --> Model Class Initialized
INFO - 2024-03-27 08:21:05 --> Model Class Initialized
INFO - 2024-03-27 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-27 08:21:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 08:21:05 --> Model Class Initialized
INFO - 2024-03-27 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-27 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-27 08:21:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 08:21:05 --> Final output sent to browser
DEBUG - 2024-03-27 08:21:05 --> Total execution time: 0.2557
ERROR - 2024-03-27 08:21:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:21:30 --> Config Class Initialized
INFO - 2024-03-27 08:21:30 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:21:30 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:21:30 --> Utf8 Class Initialized
INFO - 2024-03-27 08:21:30 --> URI Class Initialized
INFO - 2024-03-27 08:21:30 --> Router Class Initialized
INFO - 2024-03-27 08:21:30 --> Output Class Initialized
INFO - 2024-03-27 08:21:30 --> Security Class Initialized
DEBUG - 2024-03-27 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:21:30 --> Input Class Initialized
INFO - 2024-03-27 08:21:30 --> Language Class Initialized
INFO - 2024-03-27 08:21:30 --> Loader Class Initialized
INFO - 2024-03-27 08:21:30 --> Helper loaded: url_helper
INFO - 2024-03-27 08:21:30 --> Helper loaded: file_helper
INFO - 2024-03-27 08:21:30 --> Helper loaded: html_helper
INFO - 2024-03-27 08:21:30 --> Helper loaded: text_helper
INFO - 2024-03-27 08:21:30 --> Helper loaded: form_helper
INFO - 2024-03-27 08:21:30 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:21:30 --> Helper loaded: security_helper
INFO - 2024-03-27 08:21:30 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:21:30 --> Database Driver Class Initialized
INFO - 2024-03-27 08:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:21:30 --> Parser Class Initialized
INFO - 2024-03-27 08:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:21:30 --> Pagination Class Initialized
INFO - 2024-03-27 08:21:30 --> Form Validation Class Initialized
INFO - 2024-03-27 08:21:30 --> Controller Class Initialized
DEBUG - 2024-03-27 08:21:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:30 --> Model Class Initialized
DEBUG - 2024-03-27 08:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:30 --> Model Class Initialized
DEBUG - 2024-03-27 08:21:30 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:30 --> Model Class Initialized
INFO - 2024-03-27 08:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-27 08:21:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 08:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 08:21:30 --> Model Class Initialized
INFO - 2024-03-27 08:21:30 --> Model Class Initialized
INFO - 2024-03-27 08:21:30 --> Model Class Initialized
INFO - 2024-03-27 08:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-27 08:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-27 08:21:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 08:21:30 --> Final output sent to browser
DEBUG - 2024-03-27 08:21:30 --> Total execution time: 0.1699
ERROR - 2024-03-27 08:21:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:21:31 --> Config Class Initialized
INFO - 2024-03-27 08:21:31 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:21:31 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:21:31 --> Utf8 Class Initialized
INFO - 2024-03-27 08:21:31 --> URI Class Initialized
INFO - 2024-03-27 08:21:31 --> Router Class Initialized
INFO - 2024-03-27 08:21:31 --> Output Class Initialized
INFO - 2024-03-27 08:21:31 --> Security Class Initialized
DEBUG - 2024-03-27 08:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:21:31 --> Input Class Initialized
INFO - 2024-03-27 08:21:31 --> Language Class Initialized
INFO - 2024-03-27 08:21:31 --> Loader Class Initialized
INFO - 2024-03-27 08:21:31 --> Helper loaded: url_helper
INFO - 2024-03-27 08:21:31 --> Helper loaded: file_helper
INFO - 2024-03-27 08:21:31 --> Helper loaded: html_helper
INFO - 2024-03-27 08:21:31 --> Helper loaded: text_helper
INFO - 2024-03-27 08:21:31 --> Helper loaded: form_helper
INFO - 2024-03-27 08:21:31 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:21:31 --> Helper loaded: security_helper
INFO - 2024-03-27 08:21:31 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:21:31 --> Database Driver Class Initialized
INFO - 2024-03-27 08:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:21:31 --> Parser Class Initialized
INFO - 2024-03-27 08:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:21:31 --> Pagination Class Initialized
INFO - 2024-03-27 08:21:31 --> Form Validation Class Initialized
INFO - 2024-03-27 08:21:31 --> Controller Class Initialized
DEBUG - 2024-03-27 08:21:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:31 --> Model Class Initialized
DEBUG - 2024-03-27 08:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:31 --> Model Class Initialized
INFO - 2024-03-27 08:21:31 --> Final output sent to browser
DEBUG - 2024-03-27 08:21:31 --> Total execution time: 0.0241
ERROR - 2024-03-27 08:21:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:21:36 --> Config Class Initialized
INFO - 2024-03-27 08:21:36 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:21:36 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:21:36 --> Utf8 Class Initialized
INFO - 2024-03-27 08:21:36 --> URI Class Initialized
INFO - 2024-03-27 08:21:36 --> Router Class Initialized
INFO - 2024-03-27 08:21:36 --> Output Class Initialized
INFO - 2024-03-27 08:21:36 --> Security Class Initialized
DEBUG - 2024-03-27 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:21:36 --> Input Class Initialized
INFO - 2024-03-27 08:21:36 --> Language Class Initialized
INFO - 2024-03-27 08:21:36 --> Loader Class Initialized
INFO - 2024-03-27 08:21:36 --> Helper loaded: url_helper
INFO - 2024-03-27 08:21:36 --> Helper loaded: file_helper
INFO - 2024-03-27 08:21:36 --> Helper loaded: html_helper
INFO - 2024-03-27 08:21:36 --> Helper loaded: text_helper
INFO - 2024-03-27 08:21:36 --> Helper loaded: form_helper
INFO - 2024-03-27 08:21:36 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:21:36 --> Helper loaded: security_helper
INFO - 2024-03-27 08:21:36 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:21:36 --> Database Driver Class Initialized
INFO - 2024-03-27 08:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:21:36 --> Parser Class Initialized
INFO - 2024-03-27 08:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:21:36 --> Pagination Class Initialized
INFO - 2024-03-27 08:21:36 --> Form Validation Class Initialized
INFO - 2024-03-27 08:21:36 --> Controller Class Initialized
DEBUG - 2024-03-27 08:21:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:36 --> Model Class Initialized
DEBUG - 2024-03-27 08:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:21:36 --> Model Class Initialized
INFO - 2024-03-27 08:21:36 --> Final output sent to browser
DEBUG - 2024-03-27 08:21:36 --> Total execution time: 0.0389
ERROR - 2024-03-27 08:22:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:12 --> Config Class Initialized
INFO - 2024-03-27 08:22:12 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:12 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:12 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:12 --> URI Class Initialized
DEBUG - 2024-03-27 08:22:12 --> No URI present. Default controller set.
INFO - 2024-03-27 08:22:12 --> Router Class Initialized
INFO - 2024-03-27 08:22:12 --> Output Class Initialized
INFO - 2024-03-27 08:22:12 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:12 --> Input Class Initialized
INFO - 2024-03-27 08:22:12 --> Language Class Initialized
INFO - 2024-03-27 08:22:12 --> Loader Class Initialized
INFO - 2024-03-27 08:22:12 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:12 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:12 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:12 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:12 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:12 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:12 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:12 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:12 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:12 --> Parser Class Initialized
INFO - 2024-03-27 08:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:12 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:12 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:12 --> Controller Class Initialized
INFO - 2024-03-27 08:22:12 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:12 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:12 --> Model Class Initialized
INFO - 2024-03-27 08:22:12 --> Model Class Initialized
INFO - 2024-03-27 08:22:12 --> Model Class Initialized
INFO - 2024-03-27 08:22:12 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:12 --> Model Class Initialized
INFO - 2024-03-27 08:22:12 --> Model Class Initialized
INFO - 2024-03-27 08:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-27 08:22:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 08:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 08:22:12 --> Model Class Initialized
INFO - 2024-03-27 08:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-27 08:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-27 08:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 08:22:12 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:12 --> Total execution time: 0.2458
ERROR - 2024-03-27 08:22:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:18 --> Config Class Initialized
INFO - 2024-03-27 08:22:18 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:18 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:18 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:18 --> URI Class Initialized
INFO - 2024-03-27 08:22:18 --> Router Class Initialized
INFO - 2024-03-27 08:22:18 --> Output Class Initialized
INFO - 2024-03-27 08:22:18 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:18 --> Input Class Initialized
INFO - 2024-03-27 08:22:18 --> Language Class Initialized
INFO - 2024-03-27 08:22:18 --> Loader Class Initialized
INFO - 2024-03-27 08:22:18 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:18 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:18 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:18 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:18 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:18 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:18 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:18 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:18 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:18 --> Parser Class Initialized
INFO - 2024-03-27 08:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:18 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:18 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:18 --> Controller Class Initialized
INFO - 2024-03-27 08:22:18 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:18 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:18 --> Model Class Initialized
INFO - 2024-03-27 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-27 08:22:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 08:22:18 --> Model Class Initialized
INFO - 2024-03-27 08:22:18 --> Model Class Initialized
INFO - 2024-03-27 08:22:18 --> Model Class Initialized
INFO - 2024-03-27 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-27 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-27 08:22:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 08:22:18 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:18 --> Total execution time: 0.2088
ERROR - 2024-03-27 08:22:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:25 --> Config Class Initialized
INFO - 2024-03-27 08:22:25 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:25 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:25 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:25 --> URI Class Initialized
INFO - 2024-03-27 08:22:25 --> Router Class Initialized
INFO - 2024-03-27 08:22:25 --> Output Class Initialized
INFO - 2024-03-27 08:22:25 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:25 --> Input Class Initialized
INFO - 2024-03-27 08:22:25 --> Language Class Initialized
INFO - 2024-03-27 08:22:25 --> Loader Class Initialized
INFO - 2024-03-27 08:22:25 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:25 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:25 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:25 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:25 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:25 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:25 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:25 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:25 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:25 --> Parser Class Initialized
INFO - 2024-03-27 08:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:25 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:25 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:25 --> Controller Class Initialized
INFO - 2024-03-27 08:22:25 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:25 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:25 --> Total execution time: 0.0189
ERROR - 2024-03-27 08:22:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:28 --> Config Class Initialized
INFO - 2024-03-27 08:22:28 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:28 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:28 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:28 --> URI Class Initialized
INFO - 2024-03-27 08:22:28 --> Router Class Initialized
INFO - 2024-03-27 08:22:28 --> Output Class Initialized
INFO - 2024-03-27 08:22:28 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:28 --> Input Class Initialized
INFO - 2024-03-27 08:22:28 --> Language Class Initialized
INFO - 2024-03-27 08:22:28 --> Loader Class Initialized
INFO - 2024-03-27 08:22:28 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:28 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:28 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:28 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:28 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:28 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:28 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:28 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:28 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:28 --> Parser Class Initialized
INFO - 2024-03-27 08:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:28 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:28 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:28 --> Controller Class Initialized
INFO - 2024-03-27 08:22:28 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:28 --> Total execution time: 0.0137
ERROR - 2024-03-27 08:22:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:34 --> Config Class Initialized
INFO - 2024-03-27 08:22:34 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:34 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:34 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:34 --> URI Class Initialized
INFO - 2024-03-27 08:22:34 --> Router Class Initialized
INFO - 2024-03-27 08:22:34 --> Output Class Initialized
INFO - 2024-03-27 08:22:34 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:34 --> Input Class Initialized
INFO - 2024-03-27 08:22:34 --> Language Class Initialized
INFO - 2024-03-27 08:22:34 --> Loader Class Initialized
INFO - 2024-03-27 08:22:34 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:34 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:34 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:34 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:34 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:34 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:34 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:34 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:34 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:34 --> Parser Class Initialized
INFO - 2024-03-27 08:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:34 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:34 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:34 --> Controller Class Initialized
INFO - 2024-03-27 08:22:34 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:34 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:34 --> Model Class Initialized
INFO - 2024-03-27 08:22:34 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:34 --> Total execution time: 0.1480
ERROR - 2024-03-27 08:22:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:35 --> Config Class Initialized
INFO - 2024-03-27 08:22:35 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:35 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:35 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:35 --> URI Class Initialized
INFO - 2024-03-27 08:22:35 --> Router Class Initialized
INFO - 2024-03-27 08:22:35 --> Output Class Initialized
INFO - 2024-03-27 08:22:35 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:35 --> Input Class Initialized
INFO - 2024-03-27 08:22:35 --> Language Class Initialized
INFO - 2024-03-27 08:22:35 --> Loader Class Initialized
INFO - 2024-03-27 08:22:35 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:35 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:35 --> Parser Class Initialized
INFO - 2024-03-27 08:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:35 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:35 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:35 --> Controller Class Initialized
INFO - 2024-03-27 08:22:35 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:35 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:35 --> Model Class Initialized
INFO - 2024-03-27 08:22:35 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:35 --> Total execution time: 0.1434
ERROR - 2024-03-27 08:22:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:35 --> Config Class Initialized
INFO - 2024-03-27 08:22:35 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:35 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:35 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:35 --> URI Class Initialized
INFO - 2024-03-27 08:22:35 --> Router Class Initialized
INFO - 2024-03-27 08:22:35 --> Output Class Initialized
INFO - 2024-03-27 08:22:35 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:35 --> Input Class Initialized
INFO - 2024-03-27 08:22:35 --> Language Class Initialized
INFO - 2024-03-27 08:22:35 --> Loader Class Initialized
INFO - 2024-03-27 08:22:35 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:35 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:35 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:35 --> Parser Class Initialized
INFO - 2024-03-27 08:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:35 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:35 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:35 --> Controller Class Initialized
INFO - 2024-03-27 08:22:35 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:35 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:35 --> Model Class Initialized
INFO - 2024-03-27 08:22:35 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:35 --> Total execution time: 0.1525
ERROR - 2024-03-27 08:22:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:40 --> Config Class Initialized
INFO - 2024-03-27 08:22:40 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:40 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:40 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:40 --> URI Class Initialized
INFO - 2024-03-27 08:22:40 --> Router Class Initialized
INFO - 2024-03-27 08:22:40 --> Output Class Initialized
INFO - 2024-03-27 08:22:40 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:40 --> Input Class Initialized
INFO - 2024-03-27 08:22:40 --> Language Class Initialized
INFO - 2024-03-27 08:22:40 --> Loader Class Initialized
INFO - 2024-03-27 08:22:40 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:40 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:40 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:40 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:40 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:40 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:40 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:40 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:40 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:40 --> Parser Class Initialized
INFO - 2024-03-27 08:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:40 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:40 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:40 --> Controller Class Initialized
INFO - 2024-03-27 08:22:40 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:40 --> Model Class Initialized
INFO - 2024-03-27 08:22:40 --> Model Class Initialized
INFO - 2024-03-27 08:22:40 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:40 --> Total execution time: 0.0192
ERROR - 2024-03-27 08:22:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:43 --> Config Class Initialized
INFO - 2024-03-27 08:22:43 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:43 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:43 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:43 --> URI Class Initialized
INFO - 2024-03-27 08:22:43 --> Router Class Initialized
INFO - 2024-03-27 08:22:43 --> Output Class Initialized
INFO - 2024-03-27 08:22:43 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:43 --> Input Class Initialized
INFO - 2024-03-27 08:22:43 --> Language Class Initialized
INFO - 2024-03-27 08:22:43 --> Loader Class Initialized
INFO - 2024-03-27 08:22:43 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:43 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:43 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:43 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:43 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:43 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:43 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:43 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:43 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:43 --> Parser Class Initialized
INFO - 2024-03-27 08:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:43 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:43 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:43 --> Controller Class Initialized
INFO - 2024-03-27 08:22:43 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:43 --> Model Class Initialized
INFO - 2024-03-27 08:22:43 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:43 --> Total execution time: 0.0170
ERROR - 2024-03-27 08:22:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:55 --> Config Class Initialized
INFO - 2024-03-27 08:22:55 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:55 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:55 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:55 --> URI Class Initialized
INFO - 2024-03-27 08:22:55 --> Router Class Initialized
INFO - 2024-03-27 08:22:55 --> Output Class Initialized
INFO - 2024-03-27 08:22:55 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:55 --> Input Class Initialized
INFO - 2024-03-27 08:22:55 --> Language Class Initialized
INFO - 2024-03-27 08:22:55 --> Loader Class Initialized
INFO - 2024-03-27 08:22:55 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:55 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:55 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:55 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:55 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:55 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:55 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:55 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:55 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:55 --> Parser Class Initialized
INFO - 2024-03-27 08:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:55 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:55 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:55 --> Controller Class Initialized
INFO - 2024-03-27 08:22:55 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:55 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:55 --> Model Class Initialized
INFO - 2024-03-27 08:22:55 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:55 --> Total execution time: 0.1586
ERROR - 2024-03-27 08:22:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:56 --> Config Class Initialized
INFO - 2024-03-27 08:22:56 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:56 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:56 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:56 --> URI Class Initialized
INFO - 2024-03-27 08:22:56 --> Router Class Initialized
INFO - 2024-03-27 08:22:56 --> Output Class Initialized
INFO - 2024-03-27 08:22:56 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:56 --> Input Class Initialized
INFO - 2024-03-27 08:22:56 --> Language Class Initialized
INFO - 2024-03-27 08:22:56 --> Loader Class Initialized
INFO - 2024-03-27 08:22:56 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:56 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:56 --> Parser Class Initialized
INFO - 2024-03-27 08:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:56 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:56 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:56 --> Controller Class Initialized
INFO - 2024-03-27 08:22:56 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:56 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:56 --> Model Class Initialized
INFO - 2024-03-27 08:22:56 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:56 --> Total execution time: 0.1422
ERROR - 2024-03-27 08:22:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:22:56 --> Config Class Initialized
INFO - 2024-03-27 08:22:56 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:22:56 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:22:56 --> Utf8 Class Initialized
INFO - 2024-03-27 08:22:56 --> URI Class Initialized
INFO - 2024-03-27 08:22:56 --> Router Class Initialized
INFO - 2024-03-27 08:22:56 --> Output Class Initialized
INFO - 2024-03-27 08:22:56 --> Security Class Initialized
DEBUG - 2024-03-27 08:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:22:56 --> Input Class Initialized
INFO - 2024-03-27 08:22:56 --> Language Class Initialized
INFO - 2024-03-27 08:22:56 --> Loader Class Initialized
INFO - 2024-03-27 08:22:56 --> Helper loaded: url_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: file_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: html_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: text_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: form_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: security_helper
INFO - 2024-03-27 08:22:56 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:22:56 --> Database Driver Class Initialized
INFO - 2024-03-27 08:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:22:56 --> Parser Class Initialized
INFO - 2024-03-27 08:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:22:56 --> Pagination Class Initialized
INFO - 2024-03-27 08:22:56 --> Form Validation Class Initialized
INFO - 2024-03-27 08:22:56 --> Controller Class Initialized
INFO - 2024-03-27 08:22:56 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:57 --> Model Class Initialized
DEBUG - 2024-03-27 08:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:22:57 --> Model Class Initialized
INFO - 2024-03-27 08:22:57 --> Final output sent to browser
DEBUG - 2024-03-27 08:22:57 --> Total execution time: 0.1489
ERROR - 2024-03-27 08:23:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:13 --> Config Class Initialized
INFO - 2024-03-27 08:23:13 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:13 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:13 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:13 --> URI Class Initialized
INFO - 2024-03-27 08:23:13 --> Router Class Initialized
INFO - 2024-03-27 08:23:13 --> Output Class Initialized
INFO - 2024-03-27 08:23:13 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:13 --> Input Class Initialized
INFO - 2024-03-27 08:23:13 --> Language Class Initialized
INFO - 2024-03-27 08:23:13 --> Loader Class Initialized
INFO - 2024-03-27 08:23:13 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:13 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:13 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:13 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:13 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:13 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:13 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:13 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:13 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:13 --> Parser Class Initialized
INFO - 2024-03-27 08:23:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:13 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:13 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:13 --> Controller Class Initialized
INFO - 2024-03-27 08:23:13 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:13 --> Model Class Initialized
INFO - 2024-03-27 08:23:13 --> Model Class Initialized
INFO - 2024-03-27 08:23:13 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:13 --> Total execution time: 0.0223
ERROR - 2024-03-27 08:23:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:17 --> Config Class Initialized
INFO - 2024-03-27 08:23:17 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:17 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:17 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:17 --> URI Class Initialized
INFO - 2024-03-27 08:23:17 --> Router Class Initialized
INFO - 2024-03-27 08:23:17 --> Output Class Initialized
INFO - 2024-03-27 08:23:17 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:17 --> Input Class Initialized
INFO - 2024-03-27 08:23:17 --> Language Class Initialized
INFO - 2024-03-27 08:23:17 --> Loader Class Initialized
INFO - 2024-03-27 08:23:17 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:17 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:17 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:17 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:17 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:17 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:17 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:17 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:17 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:17 --> Parser Class Initialized
INFO - 2024-03-27 08:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:17 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:17 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:17 --> Controller Class Initialized
INFO - 2024-03-27 08:23:17 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:17 --> Model Class Initialized
INFO - 2024-03-27 08:23:17 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:17 --> Total execution time: 0.0163
ERROR - 2024-03-27 08:23:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:20 --> Config Class Initialized
INFO - 2024-03-27 08:23:20 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:20 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:20 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:20 --> URI Class Initialized
INFO - 2024-03-27 08:23:20 --> Router Class Initialized
INFO - 2024-03-27 08:23:20 --> Output Class Initialized
INFO - 2024-03-27 08:23:20 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:20 --> Input Class Initialized
INFO - 2024-03-27 08:23:20 --> Language Class Initialized
INFO - 2024-03-27 08:23:20 --> Loader Class Initialized
INFO - 2024-03-27 08:23:20 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:20 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:20 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:20 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:20 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:20 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:20 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:20 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:20 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:20 --> Parser Class Initialized
INFO - 2024-03-27 08:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:20 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:20 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:20 --> Controller Class Initialized
INFO - 2024-03-27 08:23:20 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:20 --> Model Class Initialized
INFO - 2024-03-27 08:23:20 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:20 --> Total execution time: 0.0183
ERROR - 2024-03-27 08:23:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:23 --> Config Class Initialized
INFO - 2024-03-27 08:23:23 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:23 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:23 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:23 --> URI Class Initialized
INFO - 2024-03-27 08:23:23 --> Router Class Initialized
INFO - 2024-03-27 08:23:23 --> Output Class Initialized
INFO - 2024-03-27 08:23:23 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:23 --> Input Class Initialized
INFO - 2024-03-27 08:23:23 --> Language Class Initialized
INFO - 2024-03-27 08:23:23 --> Loader Class Initialized
INFO - 2024-03-27 08:23:23 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:23 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:23 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:23 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:23 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:23 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:23 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:23 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:23 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:23 --> Parser Class Initialized
INFO - 2024-03-27 08:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:23 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:23 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:23 --> Controller Class Initialized
INFO - 2024-03-27 08:23:23 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:23 --> Model Class Initialized
INFO - 2024-03-27 08:23:23 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:23 --> Total execution time: 0.0186
ERROR - 2024-03-27 08:23:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:35 --> Config Class Initialized
INFO - 2024-03-27 08:23:35 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:35 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:35 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:35 --> URI Class Initialized
INFO - 2024-03-27 08:23:35 --> Router Class Initialized
INFO - 2024-03-27 08:23:35 --> Output Class Initialized
INFO - 2024-03-27 08:23:35 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:35 --> Input Class Initialized
INFO - 2024-03-27 08:23:35 --> Language Class Initialized
INFO - 2024-03-27 08:23:35 --> Loader Class Initialized
INFO - 2024-03-27 08:23:35 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:35 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:35 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:35 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:35 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:35 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:35 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:35 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:35 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:35 --> Parser Class Initialized
INFO - 2024-03-27 08:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:35 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:35 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:35 --> Controller Class Initialized
INFO - 2024-03-27 08:23:35 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:35 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:35 --> Model Class Initialized
INFO - 2024-03-27 08:23:36 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:36 --> Total execution time: 0.1626
ERROR - 2024-03-27 08:23:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:39 --> Config Class Initialized
INFO - 2024-03-27 08:23:39 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:40 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:40 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:40 --> URI Class Initialized
INFO - 2024-03-27 08:23:40 --> Router Class Initialized
INFO - 2024-03-27 08:23:40 --> Output Class Initialized
INFO - 2024-03-27 08:23:40 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:40 --> Input Class Initialized
INFO - 2024-03-27 08:23:40 --> Language Class Initialized
INFO - 2024-03-27 08:23:40 --> Loader Class Initialized
INFO - 2024-03-27 08:23:40 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:40 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:40 --> Parser Class Initialized
INFO - 2024-03-27 08:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:40 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:40 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:40 --> Controller Class Initialized
INFO - 2024-03-27 08:23:40 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:40 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:40 --> Model Class Initialized
INFO - 2024-03-27 08:23:40 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:40 --> Total execution time: 0.1640
ERROR - 2024-03-27 08:23:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:40 --> Config Class Initialized
INFO - 2024-03-27 08:23:40 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:40 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:40 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:40 --> URI Class Initialized
INFO - 2024-03-27 08:23:40 --> Router Class Initialized
INFO - 2024-03-27 08:23:40 --> Output Class Initialized
INFO - 2024-03-27 08:23:40 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:40 --> Input Class Initialized
INFO - 2024-03-27 08:23:40 --> Language Class Initialized
INFO - 2024-03-27 08:23:40 --> Loader Class Initialized
INFO - 2024-03-27 08:23:40 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:40 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:40 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:40 --> Parser Class Initialized
INFO - 2024-03-27 08:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:40 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:40 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:40 --> Controller Class Initialized
INFO - 2024-03-27 08:23:40 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:40 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:40 --> Model Class Initialized
INFO - 2024-03-27 08:23:40 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:40 --> Total execution time: 0.0244
ERROR - 2024-03-27 08:23:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:41 --> Config Class Initialized
INFO - 2024-03-27 08:23:41 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:41 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:41 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:41 --> URI Class Initialized
INFO - 2024-03-27 08:23:41 --> Router Class Initialized
INFO - 2024-03-27 08:23:41 --> Output Class Initialized
INFO - 2024-03-27 08:23:41 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:41 --> Input Class Initialized
INFO - 2024-03-27 08:23:41 --> Language Class Initialized
INFO - 2024-03-27 08:23:41 --> Loader Class Initialized
INFO - 2024-03-27 08:23:41 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:41 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:41 --> Parser Class Initialized
INFO - 2024-03-27 08:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:41 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:41 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:41 --> Controller Class Initialized
INFO - 2024-03-27 08:23:41 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:41 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:41 --> Model Class Initialized
INFO - 2024-03-27 08:23:41 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:41 --> Total execution time: 0.1448
ERROR - 2024-03-27 08:23:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:41 --> Config Class Initialized
INFO - 2024-03-27 08:23:41 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:41 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:41 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:41 --> URI Class Initialized
INFO - 2024-03-27 08:23:41 --> Router Class Initialized
INFO - 2024-03-27 08:23:41 --> Output Class Initialized
INFO - 2024-03-27 08:23:41 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:41 --> Input Class Initialized
INFO - 2024-03-27 08:23:41 --> Language Class Initialized
INFO - 2024-03-27 08:23:41 --> Loader Class Initialized
INFO - 2024-03-27 08:23:41 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:41 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:41 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:41 --> Parser Class Initialized
INFO - 2024-03-27 08:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:41 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:41 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:41 --> Controller Class Initialized
INFO - 2024-03-27 08:23:41 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:41 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:41 --> Model Class Initialized
INFO - 2024-03-27 08:23:42 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:42 --> Total execution time: 0.1584
ERROR - 2024-03-27 08:23:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:43 --> Config Class Initialized
INFO - 2024-03-27 08:23:43 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:43 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:43 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:43 --> URI Class Initialized
INFO - 2024-03-27 08:23:43 --> Router Class Initialized
INFO - 2024-03-27 08:23:43 --> Output Class Initialized
INFO - 2024-03-27 08:23:43 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:43 --> Input Class Initialized
INFO - 2024-03-27 08:23:43 --> Language Class Initialized
INFO - 2024-03-27 08:23:43 --> Loader Class Initialized
INFO - 2024-03-27 08:23:43 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:43 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:43 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:43 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:43 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:43 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:43 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:43 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:43 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:43 --> Parser Class Initialized
INFO - 2024-03-27 08:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:43 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:43 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:43 --> Controller Class Initialized
INFO - 2024-03-27 08:23:43 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:43 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:43 --> Model Class Initialized
INFO - 2024-03-27 08:23:43 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:43 --> Total execution time: 0.1472
ERROR - 2024-03-27 08:23:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:44 --> Config Class Initialized
INFO - 2024-03-27 08:23:44 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:44 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:44 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:44 --> URI Class Initialized
INFO - 2024-03-27 08:23:44 --> Router Class Initialized
INFO - 2024-03-27 08:23:44 --> Output Class Initialized
INFO - 2024-03-27 08:23:44 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:44 --> Input Class Initialized
INFO - 2024-03-27 08:23:44 --> Language Class Initialized
INFO - 2024-03-27 08:23:44 --> Loader Class Initialized
INFO - 2024-03-27 08:23:44 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:44 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:44 --> Parser Class Initialized
INFO - 2024-03-27 08:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:44 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:44 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:44 --> Controller Class Initialized
INFO - 2024-03-27 08:23:44 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:44 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:44 --> Model Class Initialized
INFO - 2024-03-27 08:23:44 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:44 --> Total execution time: 0.1525
ERROR - 2024-03-27 08:23:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:44 --> Config Class Initialized
INFO - 2024-03-27 08:23:44 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:44 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:44 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:44 --> URI Class Initialized
INFO - 2024-03-27 08:23:44 --> Router Class Initialized
INFO - 2024-03-27 08:23:44 --> Output Class Initialized
INFO - 2024-03-27 08:23:44 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:44 --> Input Class Initialized
INFO - 2024-03-27 08:23:44 --> Language Class Initialized
INFO - 2024-03-27 08:23:44 --> Loader Class Initialized
INFO - 2024-03-27 08:23:44 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:44 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:44 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:44 --> Parser Class Initialized
INFO - 2024-03-27 08:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:44 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:44 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:44 --> Controller Class Initialized
INFO - 2024-03-27 08:23:44 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:44 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:44 --> Model Class Initialized
INFO - 2024-03-27 08:23:45 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:45 --> Total execution time: 0.1581
ERROR - 2024-03-27 08:23:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:45 --> Config Class Initialized
INFO - 2024-03-27 08:23:45 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:45 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:45 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:45 --> URI Class Initialized
INFO - 2024-03-27 08:23:45 --> Router Class Initialized
INFO - 2024-03-27 08:23:45 --> Output Class Initialized
INFO - 2024-03-27 08:23:45 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:45 --> Input Class Initialized
INFO - 2024-03-27 08:23:45 --> Language Class Initialized
INFO - 2024-03-27 08:23:45 --> Loader Class Initialized
INFO - 2024-03-27 08:23:45 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:45 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:45 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:45 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:45 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:45 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:45 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:45 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:45 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:45 --> Parser Class Initialized
INFO - 2024-03-27 08:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:45 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:45 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:45 --> Controller Class Initialized
INFO - 2024-03-27 08:23:45 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:45 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:45 --> Model Class Initialized
INFO - 2024-03-27 08:23:45 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:45 --> Total execution time: 0.0242
ERROR - 2024-03-27 08:23:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:46 --> Config Class Initialized
INFO - 2024-03-27 08:23:46 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:46 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:46 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:46 --> URI Class Initialized
INFO - 2024-03-27 08:23:46 --> Router Class Initialized
INFO - 2024-03-27 08:23:46 --> Output Class Initialized
INFO - 2024-03-27 08:23:46 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:46 --> Input Class Initialized
INFO - 2024-03-27 08:23:46 --> Language Class Initialized
INFO - 2024-03-27 08:23:46 --> Loader Class Initialized
INFO - 2024-03-27 08:23:46 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:46 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:46 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:46 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:46 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:46 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:46 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:46 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:46 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:46 --> Parser Class Initialized
INFO - 2024-03-27 08:23:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:46 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:46 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:46 --> Controller Class Initialized
INFO - 2024-03-27 08:23:46 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:46 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:46 --> Model Class Initialized
INFO - 2024-03-27 08:23:46 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:46 --> Total execution time: 0.1969
ERROR - 2024-03-27 08:23:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:48 --> Config Class Initialized
INFO - 2024-03-27 08:23:48 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:48 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:48 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:48 --> URI Class Initialized
INFO - 2024-03-27 08:23:48 --> Router Class Initialized
INFO - 2024-03-27 08:23:48 --> Output Class Initialized
INFO - 2024-03-27 08:23:48 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:48 --> Input Class Initialized
INFO - 2024-03-27 08:23:48 --> Language Class Initialized
INFO - 2024-03-27 08:23:48 --> Loader Class Initialized
INFO - 2024-03-27 08:23:48 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:48 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:48 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:48 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:48 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:48 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:48 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:48 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:48 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:48 --> Parser Class Initialized
INFO - 2024-03-27 08:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:48 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:48 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:48 --> Controller Class Initialized
INFO - 2024-03-27 08:23:48 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:48 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:48 --> Model Class Initialized
INFO - 2024-03-27 08:23:48 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:48 --> Total execution time: 0.1467
ERROR - 2024-03-27 08:23:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:50 --> Config Class Initialized
INFO - 2024-03-27 08:23:50 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:50 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:50 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:50 --> URI Class Initialized
INFO - 2024-03-27 08:23:50 --> Router Class Initialized
INFO - 2024-03-27 08:23:50 --> Output Class Initialized
INFO - 2024-03-27 08:23:50 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:50 --> Input Class Initialized
INFO - 2024-03-27 08:23:50 --> Language Class Initialized
INFO - 2024-03-27 08:23:50 --> Loader Class Initialized
INFO - 2024-03-27 08:23:50 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:50 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:50 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:50 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:50 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:50 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:50 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:50 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:50 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:50 --> Parser Class Initialized
INFO - 2024-03-27 08:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:50 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:50 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:50 --> Controller Class Initialized
INFO - 2024-03-27 08:23:50 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:50 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:50 --> Model Class Initialized
INFO - 2024-03-27 08:23:51 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:51 --> Total execution time: 0.1517
ERROR - 2024-03-27 08:23:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:23:52 --> Config Class Initialized
INFO - 2024-03-27 08:23:52 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:23:52 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:23:52 --> Utf8 Class Initialized
INFO - 2024-03-27 08:23:52 --> URI Class Initialized
INFO - 2024-03-27 08:23:52 --> Router Class Initialized
INFO - 2024-03-27 08:23:52 --> Output Class Initialized
INFO - 2024-03-27 08:23:52 --> Security Class Initialized
DEBUG - 2024-03-27 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:23:52 --> Input Class Initialized
INFO - 2024-03-27 08:23:52 --> Language Class Initialized
INFO - 2024-03-27 08:23:52 --> Loader Class Initialized
INFO - 2024-03-27 08:23:52 --> Helper loaded: url_helper
INFO - 2024-03-27 08:23:52 --> Helper loaded: file_helper
INFO - 2024-03-27 08:23:52 --> Helper loaded: html_helper
INFO - 2024-03-27 08:23:52 --> Helper loaded: text_helper
INFO - 2024-03-27 08:23:52 --> Helper loaded: form_helper
INFO - 2024-03-27 08:23:52 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:23:52 --> Helper loaded: security_helper
INFO - 2024-03-27 08:23:52 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:23:52 --> Database Driver Class Initialized
INFO - 2024-03-27 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:23:52 --> Parser Class Initialized
INFO - 2024-03-27 08:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:23:52 --> Pagination Class Initialized
INFO - 2024-03-27 08:23:52 --> Form Validation Class Initialized
INFO - 2024-03-27 08:23:52 --> Controller Class Initialized
INFO - 2024-03-27 08:23:52 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:52 --> Model Class Initialized
DEBUG - 2024-03-27 08:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:23:52 --> Model Class Initialized
INFO - 2024-03-27 08:23:52 --> Final output sent to browser
DEBUG - 2024-03-27 08:23:52 --> Total execution time: 0.1512
ERROR - 2024-03-27 08:24:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:24:11 --> Config Class Initialized
INFO - 2024-03-27 08:24:11 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:24:11 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:24:11 --> Utf8 Class Initialized
INFO - 2024-03-27 08:24:11 --> URI Class Initialized
INFO - 2024-03-27 08:24:11 --> Router Class Initialized
INFO - 2024-03-27 08:24:11 --> Output Class Initialized
INFO - 2024-03-27 08:24:11 --> Security Class Initialized
DEBUG - 2024-03-27 08:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:24:11 --> Input Class Initialized
INFO - 2024-03-27 08:24:11 --> Language Class Initialized
INFO - 2024-03-27 08:24:11 --> Loader Class Initialized
INFO - 2024-03-27 08:24:11 --> Helper loaded: url_helper
INFO - 2024-03-27 08:24:11 --> Helper loaded: file_helper
INFO - 2024-03-27 08:24:11 --> Helper loaded: html_helper
INFO - 2024-03-27 08:24:11 --> Helper loaded: text_helper
INFO - 2024-03-27 08:24:11 --> Helper loaded: form_helper
INFO - 2024-03-27 08:24:11 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:24:11 --> Helper loaded: security_helper
INFO - 2024-03-27 08:24:11 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:24:11 --> Database Driver Class Initialized
INFO - 2024-03-27 08:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:24:11 --> Parser Class Initialized
INFO - 2024-03-27 08:24:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:24:11 --> Pagination Class Initialized
INFO - 2024-03-27 08:24:11 --> Form Validation Class Initialized
INFO - 2024-03-27 08:24:11 --> Controller Class Initialized
INFO - 2024-03-27 08:24:11 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:11 --> Model Class Initialized
INFO - 2024-03-27 08:24:11 --> Final output sent to browser
DEBUG - 2024-03-27 08:24:11 --> Total execution time: 0.0198
ERROR - 2024-03-27 08:24:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:24:14 --> Config Class Initialized
INFO - 2024-03-27 08:24:14 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:24:14 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:24:14 --> Utf8 Class Initialized
INFO - 2024-03-27 08:24:14 --> URI Class Initialized
INFO - 2024-03-27 08:24:14 --> Router Class Initialized
INFO - 2024-03-27 08:24:14 --> Output Class Initialized
INFO - 2024-03-27 08:24:14 --> Security Class Initialized
DEBUG - 2024-03-27 08:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:24:14 --> Input Class Initialized
INFO - 2024-03-27 08:24:14 --> Language Class Initialized
INFO - 2024-03-27 08:24:14 --> Loader Class Initialized
INFO - 2024-03-27 08:24:14 --> Helper loaded: url_helper
INFO - 2024-03-27 08:24:14 --> Helper loaded: file_helper
INFO - 2024-03-27 08:24:14 --> Helper loaded: html_helper
INFO - 2024-03-27 08:24:14 --> Helper loaded: text_helper
INFO - 2024-03-27 08:24:14 --> Helper loaded: form_helper
INFO - 2024-03-27 08:24:14 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:24:14 --> Helper loaded: security_helper
INFO - 2024-03-27 08:24:14 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:24:14 --> Database Driver Class Initialized
INFO - 2024-03-27 08:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:24:14 --> Parser Class Initialized
INFO - 2024-03-27 08:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:24:14 --> Pagination Class Initialized
INFO - 2024-03-27 08:24:14 --> Form Validation Class Initialized
INFO - 2024-03-27 08:24:14 --> Controller Class Initialized
INFO - 2024-03-27 08:24:14 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:14 --> Model Class Initialized
INFO - 2024-03-27 08:24:14 --> Final output sent to browser
DEBUG - 2024-03-27 08:24:14 --> Total execution time: 0.0174
ERROR - 2024-03-27 08:24:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:24:27 --> Config Class Initialized
INFO - 2024-03-27 08:24:27 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:24:27 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:24:27 --> Utf8 Class Initialized
INFO - 2024-03-27 08:24:27 --> URI Class Initialized
INFO - 2024-03-27 08:24:27 --> Router Class Initialized
INFO - 2024-03-27 08:24:27 --> Output Class Initialized
INFO - 2024-03-27 08:24:27 --> Security Class Initialized
DEBUG - 2024-03-27 08:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:24:27 --> Input Class Initialized
INFO - 2024-03-27 08:24:27 --> Language Class Initialized
INFO - 2024-03-27 08:24:27 --> Loader Class Initialized
INFO - 2024-03-27 08:24:27 --> Helper loaded: url_helper
INFO - 2024-03-27 08:24:27 --> Helper loaded: file_helper
INFO - 2024-03-27 08:24:27 --> Helper loaded: html_helper
INFO - 2024-03-27 08:24:27 --> Helper loaded: text_helper
INFO - 2024-03-27 08:24:27 --> Helper loaded: form_helper
INFO - 2024-03-27 08:24:27 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:24:27 --> Helper loaded: security_helper
INFO - 2024-03-27 08:24:27 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:24:27 --> Database Driver Class Initialized
INFO - 2024-03-27 08:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:24:27 --> Parser Class Initialized
INFO - 2024-03-27 08:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:24:27 --> Pagination Class Initialized
INFO - 2024-03-27 08:24:27 --> Form Validation Class Initialized
INFO - 2024-03-27 08:24:27 --> Controller Class Initialized
INFO - 2024-03-27 08:24:27 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:27 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:27 --> Model Class Initialized
INFO - 2024-03-27 08:24:27 --> Final output sent to browser
DEBUG - 2024-03-27 08:24:27 --> Total execution time: 0.0243
ERROR - 2024-03-27 08:24:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:24:30 --> Config Class Initialized
INFO - 2024-03-27 08:24:30 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:24:30 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:24:30 --> Utf8 Class Initialized
INFO - 2024-03-27 08:24:30 --> URI Class Initialized
INFO - 2024-03-27 08:24:30 --> Router Class Initialized
INFO - 2024-03-27 08:24:30 --> Output Class Initialized
INFO - 2024-03-27 08:24:30 --> Security Class Initialized
DEBUG - 2024-03-27 08:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:24:30 --> Input Class Initialized
INFO - 2024-03-27 08:24:30 --> Language Class Initialized
INFO - 2024-03-27 08:24:30 --> Loader Class Initialized
INFO - 2024-03-27 08:24:30 --> Helper loaded: url_helper
INFO - 2024-03-27 08:24:30 --> Helper loaded: file_helper
INFO - 2024-03-27 08:24:30 --> Helper loaded: html_helper
INFO - 2024-03-27 08:24:30 --> Helper loaded: text_helper
INFO - 2024-03-27 08:24:30 --> Helper loaded: form_helper
INFO - 2024-03-27 08:24:30 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:24:30 --> Helper loaded: security_helper
INFO - 2024-03-27 08:24:30 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:24:30 --> Database Driver Class Initialized
INFO - 2024-03-27 08:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:24:30 --> Parser Class Initialized
INFO - 2024-03-27 08:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:24:30 --> Pagination Class Initialized
INFO - 2024-03-27 08:24:30 --> Form Validation Class Initialized
INFO - 2024-03-27 08:24:30 --> Controller Class Initialized
INFO - 2024-03-27 08:24:30 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:30 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:30 --> Model Class Initialized
INFO - 2024-03-27 08:24:30 --> Final output sent to browser
DEBUG - 2024-03-27 08:24:30 --> Total execution time: 0.1524
ERROR - 2024-03-27 08:24:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:24:43 --> Config Class Initialized
INFO - 2024-03-27 08:24:43 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:24:43 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:24:43 --> Utf8 Class Initialized
INFO - 2024-03-27 08:24:43 --> URI Class Initialized
INFO - 2024-03-27 08:24:43 --> Router Class Initialized
INFO - 2024-03-27 08:24:43 --> Output Class Initialized
INFO - 2024-03-27 08:24:43 --> Security Class Initialized
DEBUG - 2024-03-27 08:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:24:43 --> Input Class Initialized
INFO - 2024-03-27 08:24:43 --> Language Class Initialized
INFO - 2024-03-27 08:24:43 --> Loader Class Initialized
INFO - 2024-03-27 08:24:43 --> Helper loaded: url_helper
INFO - 2024-03-27 08:24:43 --> Helper loaded: file_helper
INFO - 2024-03-27 08:24:43 --> Helper loaded: html_helper
INFO - 2024-03-27 08:24:43 --> Helper loaded: text_helper
INFO - 2024-03-27 08:24:43 --> Helper loaded: form_helper
INFO - 2024-03-27 08:24:43 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:24:43 --> Helper loaded: security_helper
INFO - 2024-03-27 08:24:43 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:24:43 --> Database Driver Class Initialized
INFO - 2024-03-27 08:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:24:43 --> Parser Class Initialized
INFO - 2024-03-27 08:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:24:43 --> Pagination Class Initialized
INFO - 2024-03-27 08:24:43 --> Form Validation Class Initialized
INFO - 2024-03-27 08:24:43 --> Controller Class Initialized
INFO - 2024-03-27 08:24:43 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:43 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:43 --> Model Class Initialized
INFO - 2024-03-27 08:24:43 --> Final output sent to browser
DEBUG - 2024-03-27 08:24:43 --> Total execution time: 0.1503
ERROR - 2024-03-27 08:24:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:24:44 --> Config Class Initialized
INFO - 2024-03-27 08:24:44 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:24:44 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:24:44 --> Utf8 Class Initialized
INFO - 2024-03-27 08:24:44 --> URI Class Initialized
INFO - 2024-03-27 08:24:44 --> Router Class Initialized
INFO - 2024-03-27 08:24:44 --> Output Class Initialized
INFO - 2024-03-27 08:24:44 --> Security Class Initialized
DEBUG - 2024-03-27 08:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:24:44 --> Input Class Initialized
INFO - 2024-03-27 08:24:44 --> Language Class Initialized
INFO - 2024-03-27 08:24:44 --> Loader Class Initialized
INFO - 2024-03-27 08:24:44 --> Helper loaded: url_helper
INFO - 2024-03-27 08:24:44 --> Helper loaded: file_helper
INFO - 2024-03-27 08:24:44 --> Helper loaded: html_helper
INFO - 2024-03-27 08:24:44 --> Helper loaded: text_helper
INFO - 2024-03-27 08:24:44 --> Helper loaded: form_helper
INFO - 2024-03-27 08:24:44 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:24:44 --> Helper loaded: security_helper
INFO - 2024-03-27 08:24:44 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:24:44 --> Database Driver Class Initialized
INFO - 2024-03-27 08:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:24:44 --> Parser Class Initialized
INFO - 2024-03-27 08:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:24:44 --> Pagination Class Initialized
INFO - 2024-03-27 08:24:44 --> Form Validation Class Initialized
INFO - 2024-03-27 08:24:44 --> Controller Class Initialized
INFO - 2024-03-27 08:24:44 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:44 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:44 --> Model Class Initialized
INFO - 2024-03-27 08:24:44 --> Final output sent to browser
DEBUG - 2024-03-27 08:24:44 --> Total execution time: 0.1463
ERROR - 2024-03-27 08:24:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:24:45 --> Config Class Initialized
INFO - 2024-03-27 08:24:45 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:24:45 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:24:45 --> Utf8 Class Initialized
INFO - 2024-03-27 08:24:45 --> URI Class Initialized
INFO - 2024-03-27 08:24:45 --> Router Class Initialized
INFO - 2024-03-27 08:24:45 --> Output Class Initialized
INFO - 2024-03-27 08:24:45 --> Security Class Initialized
DEBUG - 2024-03-27 08:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:24:45 --> Input Class Initialized
INFO - 2024-03-27 08:24:45 --> Language Class Initialized
INFO - 2024-03-27 08:24:45 --> Loader Class Initialized
INFO - 2024-03-27 08:24:45 --> Helper loaded: url_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: file_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: html_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: text_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: form_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: security_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:24:45 --> Database Driver Class Initialized
INFO - 2024-03-27 08:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:24:45 --> Parser Class Initialized
INFO - 2024-03-27 08:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:24:45 --> Pagination Class Initialized
INFO - 2024-03-27 08:24:45 --> Form Validation Class Initialized
INFO - 2024-03-27 08:24:45 --> Controller Class Initialized
INFO - 2024-03-27 08:24:45 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:45 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:45 --> Model Class Initialized
INFO - 2024-03-27 08:24:45 --> Final output sent to browser
DEBUG - 2024-03-27 08:24:45 --> Total execution time: 0.1428
ERROR - 2024-03-27 08:24:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:24:45 --> Config Class Initialized
INFO - 2024-03-27 08:24:45 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:24:45 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:24:45 --> Utf8 Class Initialized
INFO - 2024-03-27 08:24:45 --> URI Class Initialized
INFO - 2024-03-27 08:24:45 --> Router Class Initialized
INFO - 2024-03-27 08:24:45 --> Output Class Initialized
INFO - 2024-03-27 08:24:45 --> Security Class Initialized
DEBUG - 2024-03-27 08:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:24:45 --> Input Class Initialized
INFO - 2024-03-27 08:24:45 --> Language Class Initialized
INFO - 2024-03-27 08:24:45 --> Loader Class Initialized
INFO - 2024-03-27 08:24:45 --> Helper loaded: url_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: file_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: html_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: text_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: form_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: security_helper
INFO - 2024-03-27 08:24:45 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:24:45 --> Database Driver Class Initialized
INFO - 2024-03-27 08:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:24:45 --> Parser Class Initialized
INFO - 2024-03-27 08:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:24:45 --> Pagination Class Initialized
INFO - 2024-03-27 08:24:45 --> Form Validation Class Initialized
INFO - 2024-03-27 08:24:45 --> Controller Class Initialized
INFO - 2024-03-27 08:24:45 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:45 --> Model Class Initialized
DEBUG - 2024-03-27 08:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:24:45 --> Model Class Initialized
INFO - 2024-03-27 08:24:45 --> Final output sent to browser
DEBUG - 2024-03-27 08:24:45 --> Total execution time: 0.1651
ERROR - 2024-03-27 08:25:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:25:02 --> Config Class Initialized
INFO - 2024-03-27 08:25:02 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:25:02 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:25:02 --> Utf8 Class Initialized
INFO - 2024-03-27 08:25:02 --> URI Class Initialized
INFO - 2024-03-27 08:25:02 --> Router Class Initialized
INFO - 2024-03-27 08:25:02 --> Output Class Initialized
INFO - 2024-03-27 08:25:02 --> Security Class Initialized
DEBUG - 2024-03-27 08:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:25:02 --> Input Class Initialized
INFO - 2024-03-27 08:25:02 --> Language Class Initialized
INFO - 2024-03-27 08:25:02 --> Loader Class Initialized
INFO - 2024-03-27 08:25:02 --> Helper loaded: url_helper
INFO - 2024-03-27 08:25:02 --> Helper loaded: file_helper
INFO - 2024-03-27 08:25:02 --> Helper loaded: html_helper
INFO - 2024-03-27 08:25:02 --> Helper loaded: text_helper
INFO - 2024-03-27 08:25:02 --> Helper loaded: form_helper
INFO - 2024-03-27 08:25:02 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:25:02 --> Helper loaded: security_helper
INFO - 2024-03-27 08:25:02 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:25:02 --> Database Driver Class Initialized
INFO - 2024-03-27 08:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:25:02 --> Parser Class Initialized
INFO - 2024-03-27 08:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:25:02 --> Pagination Class Initialized
INFO - 2024-03-27 08:25:02 --> Form Validation Class Initialized
INFO - 2024-03-27 08:25:02 --> Controller Class Initialized
INFO - 2024-03-27 08:25:02 --> Model Class Initialized
DEBUG - 2024-03-27 08:25:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:25:02 --> Model Class Initialized
INFO - 2024-03-27 08:25:02 --> Model Class Initialized
INFO - 2024-03-27 08:25:02 --> Final output sent to browser
DEBUG - 2024-03-27 08:25:02 --> Total execution time: 0.0233
ERROR - 2024-03-27 08:25:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:25:10 --> Config Class Initialized
INFO - 2024-03-27 08:25:10 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:25:10 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:25:10 --> Utf8 Class Initialized
INFO - 2024-03-27 08:25:10 --> URI Class Initialized
INFO - 2024-03-27 08:25:10 --> Router Class Initialized
INFO - 2024-03-27 08:25:10 --> Output Class Initialized
INFO - 2024-03-27 08:25:10 --> Security Class Initialized
DEBUG - 2024-03-27 08:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:25:10 --> Input Class Initialized
INFO - 2024-03-27 08:25:10 --> Language Class Initialized
INFO - 2024-03-27 08:25:10 --> Loader Class Initialized
INFO - 2024-03-27 08:25:10 --> Helper loaded: url_helper
INFO - 2024-03-27 08:25:10 --> Helper loaded: file_helper
INFO - 2024-03-27 08:25:10 --> Helper loaded: html_helper
INFO - 2024-03-27 08:25:10 --> Helper loaded: text_helper
INFO - 2024-03-27 08:25:10 --> Helper loaded: form_helper
INFO - 2024-03-27 08:25:10 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:25:10 --> Helper loaded: security_helper
INFO - 2024-03-27 08:25:10 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:25:10 --> Database Driver Class Initialized
INFO - 2024-03-27 08:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:25:10 --> Parser Class Initialized
INFO - 2024-03-27 08:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:25:10 --> Pagination Class Initialized
INFO - 2024-03-27 08:25:10 --> Form Validation Class Initialized
INFO - 2024-03-27 08:25:10 --> Controller Class Initialized
INFO - 2024-03-27 08:25:10 --> Model Class Initialized
DEBUG - 2024-03-27 08:25:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:25:10 --> Model Class Initialized
INFO - 2024-03-27 08:25:10 --> Final output sent to browser
DEBUG - 2024-03-27 08:25:10 --> Total execution time: 0.0203
ERROR - 2024-03-27 08:25:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:25:40 --> Config Class Initialized
INFO - 2024-03-27 08:25:40 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:25:40 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:25:40 --> Utf8 Class Initialized
INFO - 2024-03-27 08:25:40 --> URI Class Initialized
INFO - 2024-03-27 08:25:40 --> Router Class Initialized
INFO - 2024-03-27 08:25:40 --> Output Class Initialized
INFO - 2024-03-27 08:25:40 --> Security Class Initialized
DEBUG - 2024-03-27 08:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:25:40 --> Input Class Initialized
INFO - 2024-03-27 08:25:40 --> Language Class Initialized
INFO - 2024-03-27 08:25:40 --> Loader Class Initialized
INFO - 2024-03-27 08:25:40 --> Helper loaded: url_helper
INFO - 2024-03-27 08:25:40 --> Helper loaded: file_helper
INFO - 2024-03-27 08:25:40 --> Helper loaded: html_helper
INFO - 2024-03-27 08:25:40 --> Helper loaded: text_helper
INFO - 2024-03-27 08:25:40 --> Helper loaded: form_helper
INFO - 2024-03-27 08:25:40 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:25:40 --> Helper loaded: security_helper
INFO - 2024-03-27 08:25:40 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:25:40 --> Database Driver Class Initialized
INFO - 2024-03-27 08:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:25:40 --> Parser Class Initialized
INFO - 2024-03-27 08:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:25:40 --> Pagination Class Initialized
INFO - 2024-03-27 08:25:40 --> Form Validation Class Initialized
INFO - 2024-03-27 08:25:40 --> Controller Class Initialized
INFO - 2024-03-27 08:25:40 --> Model Class Initialized
DEBUG - 2024-03-27 08:25:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:25:40 --> Model Class Initialized
DEBUG - 2024-03-27 08:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:25:40 --> Model Class Initialized
INFO - 2024-03-27 08:25:40 --> Email Class Initialized
DEBUG - 2024-03-27 08:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:25:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:40 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-27 08:25:41 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-03-27 08:25:41 --> Language file loaded: language/english/email_lang.php
INFO - 2024-03-27 08:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-03-27 08:25:41 --> Final output sent to browser
DEBUG - 2024-03-27 08:25:41 --> Total execution time: 0.2372
ERROR - 2024-03-27 08:25:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:25:43 --> Config Class Initialized
INFO - 2024-03-27 08:25:43 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:25:43 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:25:43 --> Utf8 Class Initialized
INFO - 2024-03-27 08:25:43 --> URI Class Initialized
INFO - 2024-03-27 08:25:43 --> Router Class Initialized
INFO - 2024-03-27 08:25:43 --> Output Class Initialized
INFO - 2024-03-27 08:25:43 --> Security Class Initialized
DEBUG - 2024-03-27 08:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:25:43 --> Input Class Initialized
INFO - 2024-03-27 08:25:43 --> Language Class Initialized
INFO - 2024-03-27 08:25:43 --> Loader Class Initialized
INFO - 2024-03-27 08:25:43 --> Helper loaded: url_helper
INFO - 2024-03-27 08:25:43 --> Helper loaded: file_helper
INFO - 2024-03-27 08:25:43 --> Helper loaded: html_helper
INFO - 2024-03-27 08:25:43 --> Helper loaded: text_helper
INFO - 2024-03-27 08:25:43 --> Helper loaded: form_helper
INFO - 2024-03-27 08:25:43 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:25:43 --> Helper loaded: security_helper
INFO - 2024-03-27 08:25:43 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:25:43 --> Database Driver Class Initialized
INFO - 2024-03-27 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:25:43 --> Parser Class Initialized
INFO - 2024-03-27 08:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:25:43 --> Pagination Class Initialized
INFO - 2024-03-27 08:25:43 --> Form Validation Class Initialized
INFO - 2024-03-27 08:25:43 --> Controller Class Initialized
INFO - 2024-03-27 08:25:43 --> Model Class Initialized
DEBUG - 2024-03-27 08:25:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:25:43 --> Model Class Initialized
DEBUG - 2024-03-27 08:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:25:43 --> Model Class Initialized
INFO - 2024-03-27 08:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-27 08:25:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 08:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 08:25:43 --> Model Class Initialized
INFO - 2024-03-27 08:25:43 --> Model Class Initialized
INFO - 2024-03-27 08:25:43 --> Model Class Initialized
INFO - 2024-03-27 08:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-27 08:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-27 08:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 08:25:43 --> Final output sent to browser
DEBUG - 2024-03-27 08:25:43 --> Total execution time: 0.1790
ERROR - 2024-03-27 08:28:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:28:33 --> Config Class Initialized
INFO - 2024-03-27 08:28:33 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:28:33 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:28:33 --> Utf8 Class Initialized
INFO - 2024-03-27 08:28:33 --> URI Class Initialized
DEBUG - 2024-03-27 08:28:33 --> No URI present. Default controller set.
INFO - 2024-03-27 08:28:33 --> Router Class Initialized
INFO - 2024-03-27 08:28:33 --> Output Class Initialized
INFO - 2024-03-27 08:28:33 --> Security Class Initialized
DEBUG - 2024-03-27 08:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:28:33 --> Input Class Initialized
INFO - 2024-03-27 08:28:33 --> Language Class Initialized
INFO - 2024-03-27 08:28:33 --> Loader Class Initialized
INFO - 2024-03-27 08:28:33 --> Helper loaded: url_helper
INFO - 2024-03-27 08:28:33 --> Helper loaded: file_helper
INFO - 2024-03-27 08:28:33 --> Helper loaded: html_helper
INFO - 2024-03-27 08:28:33 --> Helper loaded: text_helper
INFO - 2024-03-27 08:28:33 --> Helper loaded: form_helper
INFO - 2024-03-27 08:28:33 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:28:33 --> Helper loaded: security_helper
INFO - 2024-03-27 08:28:33 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:28:33 --> Database Driver Class Initialized
INFO - 2024-03-27 08:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:28:33 --> Parser Class Initialized
INFO - 2024-03-27 08:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:28:33 --> Pagination Class Initialized
INFO - 2024-03-27 08:28:33 --> Form Validation Class Initialized
INFO - 2024-03-27 08:28:33 --> Controller Class Initialized
INFO - 2024-03-27 08:28:33 --> Model Class Initialized
DEBUG - 2024-03-27 08:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:28:33 --> Model Class Initialized
DEBUG - 2024-03-27 08:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:28:33 --> Model Class Initialized
INFO - 2024-03-27 08:28:33 --> Model Class Initialized
INFO - 2024-03-27 08:28:33 --> Model Class Initialized
INFO - 2024-03-27 08:28:33 --> Model Class Initialized
DEBUG - 2024-03-27 08:28:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:28:33 --> Model Class Initialized
INFO - 2024-03-27 08:28:33 --> Model Class Initialized
INFO - 2024-03-27 08:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-27 08:28:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 08:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 08:28:33 --> Model Class Initialized
INFO - 2024-03-27 08:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-27 08:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-27 08:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 08:28:33 --> Final output sent to browser
DEBUG - 2024-03-27 08:28:33 --> Total execution time: 0.2513
ERROR - 2024-03-27 08:29:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:29:53 --> Config Class Initialized
INFO - 2024-03-27 08:29:53 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:29:53 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:29:53 --> Utf8 Class Initialized
INFO - 2024-03-27 08:29:53 --> URI Class Initialized
INFO - 2024-03-27 08:29:53 --> Router Class Initialized
INFO - 2024-03-27 08:29:53 --> Output Class Initialized
INFO - 2024-03-27 08:29:53 --> Security Class Initialized
DEBUG - 2024-03-27 08:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:29:53 --> Input Class Initialized
INFO - 2024-03-27 08:29:53 --> Language Class Initialized
INFO - 2024-03-27 08:29:53 --> Loader Class Initialized
INFO - 2024-03-27 08:29:53 --> Helper loaded: url_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: file_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: html_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: text_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: form_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: security_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:29:53 --> Database Driver Class Initialized
INFO - 2024-03-27 08:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:29:53 --> Parser Class Initialized
INFO - 2024-03-27 08:29:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:29:53 --> Pagination Class Initialized
INFO - 2024-03-27 08:29:53 --> Form Validation Class Initialized
INFO - 2024-03-27 08:29:53 --> Controller Class Initialized
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
DEBUG - 2024-03-27 08:29:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 08:29:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 08:29:53 --> Final output sent to browser
DEBUG - 2024-03-27 08:29:53 --> Total execution time: 0.0322
ERROR - 2024-03-27 08:29:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 08:29:53 --> Config Class Initialized
INFO - 2024-03-27 08:29:53 --> Hooks Class Initialized
DEBUG - 2024-03-27 08:29:53 --> UTF-8 Support Enabled
INFO - 2024-03-27 08:29:53 --> Utf8 Class Initialized
INFO - 2024-03-27 08:29:53 --> URI Class Initialized
INFO - 2024-03-27 08:29:53 --> Router Class Initialized
INFO - 2024-03-27 08:29:53 --> Output Class Initialized
INFO - 2024-03-27 08:29:53 --> Security Class Initialized
DEBUG - 2024-03-27 08:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 08:29:53 --> Input Class Initialized
INFO - 2024-03-27 08:29:53 --> Language Class Initialized
INFO - 2024-03-27 08:29:53 --> Loader Class Initialized
INFO - 2024-03-27 08:29:53 --> Helper loaded: url_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: file_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: html_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: text_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: form_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: lang_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: security_helper
INFO - 2024-03-27 08:29:53 --> Helper loaded: cookie_helper
INFO - 2024-03-27 08:29:53 --> Database Driver Class Initialized
INFO - 2024-03-27 08:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 08:29:53 --> Parser Class Initialized
INFO - 2024-03-27 08:29:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 08:29:53 --> Pagination Class Initialized
INFO - 2024-03-27 08:29:53 --> Form Validation Class Initialized
INFO - 2024-03-27 08:29:53 --> Controller Class Initialized
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
DEBUG - 2024-03-27 08:29:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
DEBUG - 2024-03-27 08:29:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
DEBUG - 2024-03-27 08:29:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-27 08:29:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-27 08:29:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 08:29:53 --> Model Class Initialized
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-27 08:29:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 08:29:53 --> Final output sent to browser
DEBUG - 2024-03-27 08:29:53 --> Total execution time: 0.2677
ERROR - 2024-03-27 12:07:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 12:07:03 --> Config Class Initialized
INFO - 2024-03-27 12:07:03 --> Hooks Class Initialized
DEBUG - 2024-03-27 12:07:03 --> UTF-8 Support Enabled
INFO - 2024-03-27 12:07:03 --> Utf8 Class Initialized
INFO - 2024-03-27 12:07:03 --> URI Class Initialized
DEBUG - 2024-03-27 12:07:03 --> No URI present. Default controller set.
INFO - 2024-03-27 12:07:03 --> Router Class Initialized
INFO - 2024-03-27 12:07:03 --> Output Class Initialized
INFO - 2024-03-27 12:07:03 --> Security Class Initialized
DEBUG - 2024-03-27 12:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 12:07:03 --> Input Class Initialized
INFO - 2024-03-27 12:07:03 --> Language Class Initialized
INFO - 2024-03-27 12:07:03 --> Loader Class Initialized
INFO - 2024-03-27 12:07:03 --> Helper loaded: url_helper
INFO - 2024-03-27 12:07:03 --> Helper loaded: file_helper
INFO - 2024-03-27 12:07:03 --> Helper loaded: html_helper
INFO - 2024-03-27 12:07:03 --> Helper loaded: text_helper
INFO - 2024-03-27 12:07:03 --> Helper loaded: form_helper
INFO - 2024-03-27 12:07:03 --> Helper loaded: lang_helper
INFO - 2024-03-27 12:07:03 --> Helper loaded: security_helper
INFO - 2024-03-27 12:07:03 --> Helper loaded: cookie_helper
INFO - 2024-03-27 12:07:03 --> Database Driver Class Initialized
INFO - 2024-03-27 12:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 12:07:03 --> Parser Class Initialized
INFO - 2024-03-27 12:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 12:07:03 --> Pagination Class Initialized
INFO - 2024-03-27 12:07:03 --> Form Validation Class Initialized
INFO - 2024-03-27 12:07:03 --> Controller Class Initialized
INFO - 2024-03-27 12:07:03 --> Model Class Initialized
DEBUG - 2024-03-27 12:07:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-27 13:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:58:09 --> Config Class Initialized
INFO - 2024-03-27 13:58:09 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:58:09 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:58:09 --> Utf8 Class Initialized
INFO - 2024-03-27 13:58:09 --> URI Class Initialized
DEBUG - 2024-03-27 13:58:09 --> No URI present. Default controller set.
INFO - 2024-03-27 13:58:09 --> Router Class Initialized
INFO - 2024-03-27 13:58:09 --> Output Class Initialized
INFO - 2024-03-27 13:58:09 --> Security Class Initialized
DEBUG - 2024-03-27 13:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:58:09 --> Input Class Initialized
INFO - 2024-03-27 13:58:09 --> Language Class Initialized
INFO - 2024-03-27 13:58:09 --> Loader Class Initialized
INFO - 2024-03-27 13:58:09 --> Helper loaded: url_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: file_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: html_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: text_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: form_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: security_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:58:09 --> Database Driver Class Initialized
INFO - 2024-03-27 13:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:58:09 --> Parser Class Initialized
INFO - 2024-03-27 13:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:58:09 --> Pagination Class Initialized
INFO - 2024-03-27 13:58:09 --> Form Validation Class Initialized
INFO - 2024-03-27 13:58:09 --> Controller Class Initialized
INFO - 2024-03-27 13:58:09 --> Model Class Initialized
DEBUG - 2024-03-27 13:58:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-27 13:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:58:09 --> Config Class Initialized
INFO - 2024-03-27 13:58:09 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:58:09 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:58:09 --> Utf8 Class Initialized
INFO - 2024-03-27 13:58:09 --> URI Class Initialized
INFO - 2024-03-27 13:58:09 --> Router Class Initialized
INFO - 2024-03-27 13:58:09 --> Output Class Initialized
INFO - 2024-03-27 13:58:09 --> Security Class Initialized
DEBUG - 2024-03-27 13:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:58:09 --> Input Class Initialized
INFO - 2024-03-27 13:58:09 --> Language Class Initialized
INFO - 2024-03-27 13:58:09 --> Loader Class Initialized
INFO - 2024-03-27 13:58:09 --> Helper loaded: url_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: file_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: html_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: text_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: form_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: security_helper
INFO - 2024-03-27 13:58:09 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:58:09 --> Database Driver Class Initialized
INFO - 2024-03-27 13:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:58:09 --> Parser Class Initialized
INFO - 2024-03-27 13:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:58:09 --> Pagination Class Initialized
INFO - 2024-03-27 13:58:09 --> Form Validation Class Initialized
INFO - 2024-03-27 13:58:09 --> Controller Class Initialized
INFO - 2024-03-27 13:58:09 --> Model Class Initialized
DEBUG - 2024-03-27 13:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 13:58:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 13:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 13:58:09 --> Model Class Initialized
INFO - 2024-03-27 13:58:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 13:58:09 --> Final output sent to browser
DEBUG - 2024-03-27 13:58:09 --> Total execution time: 0.0360
ERROR - 2024-03-27 13:58:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:58:43 --> Config Class Initialized
INFO - 2024-03-27 13:58:43 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:58:43 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:58:43 --> Utf8 Class Initialized
INFO - 2024-03-27 13:58:43 --> URI Class Initialized
INFO - 2024-03-27 13:58:43 --> Router Class Initialized
INFO - 2024-03-27 13:58:43 --> Output Class Initialized
INFO - 2024-03-27 13:58:43 --> Security Class Initialized
DEBUG - 2024-03-27 13:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:58:43 --> Input Class Initialized
INFO - 2024-03-27 13:58:43 --> Language Class Initialized
INFO - 2024-03-27 13:58:43 --> Loader Class Initialized
INFO - 2024-03-27 13:58:43 --> Helper loaded: url_helper
INFO - 2024-03-27 13:58:43 --> Helper loaded: file_helper
INFO - 2024-03-27 13:58:43 --> Helper loaded: html_helper
INFO - 2024-03-27 13:58:43 --> Helper loaded: text_helper
INFO - 2024-03-27 13:58:43 --> Helper loaded: form_helper
INFO - 2024-03-27 13:58:43 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:58:43 --> Helper loaded: security_helper
INFO - 2024-03-27 13:58:43 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:58:43 --> Database Driver Class Initialized
INFO - 2024-03-27 13:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:58:43 --> Parser Class Initialized
INFO - 2024-03-27 13:58:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:58:43 --> Pagination Class Initialized
INFO - 2024-03-27 13:58:43 --> Form Validation Class Initialized
INFO - 2024-03-27 13:58:43 --> Controller Class Initialized
INFO - 2024-03-27 13:58:43 --> Model Class Initialized
DEBUG - 2024-03-27 13:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 13:58:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 13:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 13:58:43 --> Model Class Initialized
INFO - 2024-03-27 13:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 13:58:43 --> Final output sent to browser
DEBUG - 2024-03-27 13:58:43 --> Total execution time: 0.0352
ERROR - 2024-03-27 13:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:59:09 --> Config Class Initialized
INFO - 2024-03-27 13:59:09 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:59:09 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:59:09 --> Utf8 Class Initialized
INFO - 2024-03-27 13:59:09 --> URI Class Initialized
INFO - 2024-03-27 13:59:09 --> Router Class Initialized
INFO - 2024-03-27 13:59:09 --> Output Class Initialized
INFO - 2024-03-27 13:59:09 --> Security Class Initialized
DEBUG - 2024-03-27 13:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:59:09 --> Input Class Initialized
INFO - 2024-03-27 13:59:09 --> Language Class Initialized
INFO - 2024-03-27 13:59:09 --> Loader Class Initialized
INFO - 2024-03-27 13:59:09 --> Helper loaded: url_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: file_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: html_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: text_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: form_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: security_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:59:09 --> Database Driver Class Initialized
INFO - 2024-03-27 13:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:59:09 --> Parser Class Initialized
INFO - 2024-03-27 13:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:59:09 --> Pagination Class Initialized
INFO - 2024-03-27 13:59:09 --> Form Validation Class Initialized
INFO - 2024-03-27 13:59:09 --> Controller Class Initialized
INFO - 2024-03-27 13:59:09 --> Model Class Initialized
DEBUG - 2024-03-27 13:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:09 --> Model Class Initialized
INFO - 2024-03-27 13:59:09 --> Final output sent to browser
DEBUG - 2024-03-27 13:59:09 --> Total execution time: 0.0208
ERROR - 2024-03-27 13:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:59:09 --> Config Class Initialized
INFO - 2024-03-27 13:59:09 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:59:09 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:59:09 --> Utf8 Class Initialized
INFO - 2024-03-27 13:59:09 --> URI Class Initialized
INFO - 2024-03-27 13:59:09 --> Router Class Initialized
INFO - 2024-03-27 13:59:09 --> Output Class Initialized
INFO - 2024-03-27 13:59:09 --> Security Class Initialized
DEBUG - 2024-03-27 13:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:59:09 --> Input Class Initialized
INFO - 2024-03-27 13:59:09 --> Language Class Initialized
INFO - 2024-03-27 13:59:09 --> Loader Class Initialized
INFO - 2024-03-27 13:59:09 --> Helper loaded: url_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: file_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: html_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: text_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: form_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: security_helper
INFO - 2024-03-27 13:59:09 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:59:09 --> Database Driver Class Initialized
INFO - 2024-03-27 13:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:59:09 --> Parser Class Initialized
INFO - 2024-03-27 13:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:59:09 --> Pagination Class Initialized
INFO - 2024-03-27 13:59:09 --> Form Validation Class Initialized
INFO - 2024-03-27 13:59:09 --> Controller Class Initialized
INFO - 2024-03-27 13:59:09 --> Model Class Initialized
DEBUG - 2024-03-27 13:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 13:59:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 13:59:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 13:59:09 --> Model Class Initialized
INFO - 2024-03-27 13:59:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 13:59:09 --> Final output sent to browser
DEBUG - 2024-03-27 13:59:09 --> Total execution time: 0.0337
ERROR - 2024-03-27 13:59:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:59:28 --> Config Class Initialized
INFO - 2024-03-27 13:59:28 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:59:28 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:59:28 --> Utf8 Class Initialized
INFO - 2024-03-27 13:59:28 --> URI Class Initialized
INFO - 2024-03-27 13:59:28 --> Router Class Initialized
INFO - 2024-03-27 13:59:28 --> Output Class Initialized
INFO - 2024-03-27 13:59:28 --> Security Class Initialized
DEBUG - 2024-03-27 13:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:59:28 --> Input Class Initialized
INFO - 2024-03-27 13:59:28 --> Language Class Initialized
INFO - 2024-03-27 13:59:28 --> Loader Class Initialized
INFO - 2024-03-27 13:59:28 --> Helper loaded: url_helper
INFO - 2024-03-27 13:59:28 --> Helper loaded: file_helper
INFO - 2024-03-27 13:59:28 --> Helper loaded: html_helper
INFO - 2024-03-27 13:59:28 --> Helper loaded: text_helper
INFO - 2024-03-27 13:59:28 --> Helper loaded: form_helper
INFO - 2024-03-27 13:59:28 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:59:28 --> Helper loaded: security_helper
INFO - 2024-03-27 13:59:28 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:59:28 --> Database Driver Class Initialized
INFO - 2024-03-27 13:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:59:28 --> Parser Class Initialized
INFO - 2024-03-27 13:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:59:28 --> Pagination Class Initialized
INFO - 2024-03-27 13:59:28 --> Form Validation Class Initialized
INFO - 2024-03-27 13:59:28 --> Controller Class Initialized
INFO - 2024-03-27 13:59:28 --> Model Class Initialized
DEBUG - 2024-03-27 13:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:28 --> Model Class Initialized
INFO - 2024-03-27 13:59:28 --> Final output sent to browser
DEBUG - 2024-03-27 13:59:28 --> Total execution time: 0.0196
ERROR - 2024-03-27 13:59:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:59:29 --> Config Class Initialized
INFO - 2024-03-27 13:59:29 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:59:29 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:59:29 --> Utf8 Class Initialized
INFO - 2024-03-27 13:59:29 --> URI Class Initialized
INFO - 2024-03-27 13:59:29 --> Router Class Initialized
INFO - 2024-03-27 13:59:29 --> Output Class Initialized
INFO - 2024-03-27 13:59:29 --> Security Class Initialized
DEBUG - 2024-03-27 13:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:59:29 --> Input Class Initialized
INFO - 2024-03-27 13:59:29 --> Language Class Initialized
INFO - 2024-03-27 13:59:29 --> Loader Class Initialized
INFO - 2024-03-27 13:59:29 --> Helper loaded: url_helper
INFO - 2024-03-27 13:59:29 --> Helper loaded: file_helper
INFO - 2024-03-27 13:59:29 --> Helper loaded: html_helper
INFO - 2024-03-27 13:59:29 --> Helper loaded: text_helper
INFO - 2024-03-27 13:59:29 --> Helper loaded: form_helper
INFO - 2024-03-27 13:59:29 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:59:29 --> Helper loaded: security_helper
INFO - 2024-03-27 13:59:29 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:59:29 --> Database Driver Class Initialized
INFO - 2024-03-27 13:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:59:29 --> Parser Class Initialized
INFO - 2024-03-27 13:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:59:29 --> Pagination Class Initialized
INFO - 2024-03-27 13:59:29 --> Form Validation Class Initialized
INFO - 2024-03-27 13:59:29 --> Controller Class Initialized
INFO - 2024-03-27 13:59:29 --> Model Class Initialized
DEBUG - 2024-03-27 13:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 13:59:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 13:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 13:59:29 --> Model Class Initialized
INFO - 2024-03-27 13:59:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 13:59:29 --> Final output sent to browser
DEBUG - 2024-03-27 13:59:29 --> Total execution time: 0.0294
ERROR - 2024-03-27 13:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:59:48 --> Config Class Initialized
INFO - 2024-03-27 13:59:48 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:59:48 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:59:48 --> Utf8 Class Initialized
INFO - 2024-03-27 13:59:48 --> URI Class Initialized
INFO - 2024-03-27 13:59:48 --> Router Class Initialized
INFO - 2024-03-27 13:59:48 --> Output Class Initialized
INFO - 2024-03-27 13:59:48 --> Security Class Initialized
DEBUG - 2024-03-27 13:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:59:48 --> Input Class Initialized
INFO - 2024-03-27 13:59:48 --> Language Class Initialized
INFO - 2024-03-27 13:59:48 --> Loader Class Initialized
INFO - 2024-03-27 13:59:48 --> Helper loaded: url_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: file_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: html_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: text_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: form_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: security_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:59:48 --> Database Driver Class Initialized
INFO - 2024-03-27 13:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:59:48 --> Parser Class Initialized
INFO - 2024-03-27 13:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:59:48 --> Pagination Class Initialized
INFO - 2024-03-27 13:59:48 --> Form Validation Class Initialized
INFO - 2024-03-27 13:59:48 --> Controller Class Initialized
INFO - 2024-03-27 13:59:48 --> Model Class Initialized
DEBUG - 2024-03-27 13:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:48 --> Model Class Initialized
INFO - 2024-03-27 13:59:48 --> Final output sent to browser
DEBUG - 2024-03-27 13:59:48 --> Total execution time: 0.0194
ERROR - 2024-03-27 13:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:59:48 --> Config Class Initialized
INFO - 2024-03-27 13:59:48 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:59:48 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:59:48 --> Utf8 Class Initialized
INFO - 2024-03-27 13:59:48 --> URI Class Initialized
INFO - 2024-03-27 13:59:48 --> Router Class Initialized
INFO - 2024-03-27 13:59:48 --> Output Class Initialized
INFO - 2024-03-27 13:59:48 --> Security Class Initialized
DEBUG - 2024-03-27 13:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:59:48 --> Input Class Initialized
INFO - 2024-03-27 13:59:48 --> Language Class Initialized
INFO - 2024-03-27 13:59:48 --> Loader Class Initialized
INFO - 2024-03-27 13:59:48 --> Helper loaded: url_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: file_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: html_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: text_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: form_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: security_helper
INFO - 2024-03-27 13:59:48 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:59:48 --> Database Driver Class Initialized
INFO - 2024-03-27 13:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:59:48 --> Parser Class Initialized
INFO - 2024-03-27 13:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:59:48 --> Pagination Class Initialized
INFO - 2024-03-27 13:59:48 --> Form Validation Class Initialized
INFO - 2024-03-27 13:59:48 --> Controller Class Initialized
INFO - 2024-03-27 13:59:48 --> Model Class Initialized
DEBUG - 2024-03-27 13:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 13:59:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 13:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 13:59:48 --> Model Class Initialized
INFO - 2024-03-27 13:59:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 13:59:48 --> Final output sent to browser
DEBUG - 2024-03-27 13:59:48 --> Total execution time: 0.0363
ERROR - 2024-03-27 13:59:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:59:51 --> Config Class Initialized
INFO - 2024-03-27 13:59:51 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:59:51 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:59:51 --> Utf8 Class Initialized
INFO - 2024-03-27 13:59:51 --> URI Class Initialized
INFO - 2024-03-27 13:59:51 --> Router Class Initialized
INFO - 2024-03-27 13:59:51 --> Output Class Initialized
INFO - 2024-03-27 13:59:51 --> Security Class Initialized
DEBUG - 2024-03-27 13:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:59:51 --> Input Class Initialized
INFO - 2024-03-27 13:59:51 --> Language Class Initialized
INFO - 2024-03-27 13:59:51 --> Loader Class Initialized
INFO - 2024-03-27 13:59:51 --> Helper loaded: url_helper
INFO - 2024-03-27 13:59:51 --> Helper loaded: file_helper
INFO - 2024-03-27 13:59:51 --> Helper loaded: html_helper
INFO - 2024-03-27 13:59:51 --> Helper loaded: text_helper
INFO - 2024-03-27 13:59:51 --> Helper loaded: form_helper
INFO - 2024-03-27 13:59:51 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:59:51 --> Helper loaded: security_helper
INFO - 2024-03-27 13:59:51 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:59:51 --> Database Driver Class Initialized
INFO - 2024-03-27 13:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:59:51 --> Parser Class Initialized
INFO - 2024-03-27 13:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:59:51 --> Pagination Class Initialized
INFO - 2024-03-27 13:59:51 --> Form Validation Class Initialized
INFO - 2024-03-27 13:59:51 --> Controller Class Initialized
INFO - 2024-03-27 13:59:51 --> Model Class Initialized
DEBUG - 2024-03-27 13:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 13:59:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 13:59:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 13:59:51 --> Model Class Initialized
INFO - 2024-03-27 13:59:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 13:59:51 --> Final output sent to browser
DEBUG - 2024-03-27 13:59:51 --> Total execution time: 0.0326
ERROR - 2024-03-27 13:59:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:59:53 --> Config Class Initialized
INFO - 2024-03-27 13:59:53 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:59:53 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:59:53 --> Utf8 Class Initialized
INFO - 2024-03-27 13:59:53 --> URI Class Initialized
INFO - 2024-03-27 13:59:53 --> Router Class Initialized
INFO - 2024-03-27 13:59:53 --> Output Class Initialized
INFO - 2024-03-27 13:59:53 --> Security Class Initialized
DEBUG - 2024-03-27 13:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:59:53 --> Input Class Initialized
INFO - 2024-03-27 13:59:53 --> Language Class Initialized
INFO - 2024-03-27 13:59:53 --> Loader Class Initialized
INFO - 2024-03-27 13:59:53 --> Helper loaded: url_helper
INFO - 2024-03-27 13:59:53 --> Helper loaded: file_helper
INFO - 2024-03-27 13:59:53 --> Helper loaded: html_helper
INFO - 2024-03-27 13:59:53 --> Helper loaded: text_helper
INFO - 2024-03-27 13:59:53 --> Helper loaded: form_helper
INFO - 2024-03-27 13:59:53 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:59:53 --> Helper loaded: security_helper
INFO - 2024-03-27 13:59:53 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:59:53 --> Database Driver Class Initialized
INFO - 2024-03-27 13:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:59:53 --> Parser Class Initialized
INFO - 2024-03-27 13:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:59:53 --> Pagination Class Initialized
INFO - 2024-03-27 13:59:53 --> Form Validation Class Initialized
INFO - 2024-03-27 13:59:53 --> Controller Class Initialized
INFO - 2024-03-27 13:59:53 --> Model Class Initialized
DEBUG - 2024-03-27 13:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 13:59:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 13:59:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 13:59:53 --> Model Class Initialized
INFO - 2024-03-27 13:59:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 13:59:53 --> Final output sent to browser
DEBUG - 2024-03-27 13:59:53 --> Total execution time: 0.0392
ERROR - 2024-03-27 13:59:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 13:59:55 --> Config Class Initialized
INFO - 2024-03-27 13:59:55 --> Hooks Class Initialized
DEBUG - 2024-03-27 13:59:55 --> UTF-8 Support Enabled
INFO - 2024-03-27 13:59:55 --> Utf8 Class Initialized
INFO - 2024-03-27 13:59:55 --> URI Class Initialized
INFO - 2024-03-27 13:59:55 --> Router Class Initialized
INFO - 2024-03-27 13:59:55 --> Output Class Initialized
INFO - 2024-03-27 13:59:55 --> Security Class Initialized
DEBUG - 2024-03-27 13:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 13:59:55 --> Input Class Initialized
INFO - 2024-03-27 13:59:55 --> Language Class Initialized
INFO - 2024-03-27 13:59:55 --> Loader Class Initialized
INFO - 2024-03-27 13:59:55 --> Helper loaded: url_helper
INFO - 2024-03-27 13:59:55 --> Helper loaded: file_helper
INFO - 2024-03-27 13:59:55 --> Helper loaded: html_helper
INFO - 2024-03-27 13:59:55 --> Helper loaded: text_helper
INFO - 2024-03-27 13:59:55 --> Helper loaded: form_helper
INFO - 2024-03-27 13:59:55 --> Helper loaded: lang_helper
INFO - 2024-03-27 13:59:55 --> Helper loaded: security_helper
INFO - 2024-03-27 13:59:55 --> Helper loaded: cookie_helper
INFO - 2024-03-27 13:59:55 --> Database Driver Class Initialized
INFO - 2024-03-27 13:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 13:59:55 --> Parser Class Initialized
INFO - 2024-03-27 13:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 13:59:55 --> Pagination Class Initialized
INFO - 2024-03-27 13:59:55 --> Form Validation Class Initialized
INFO - 2024-03-27 13:59:55 --> Controller Class Initialized
INFO - 2024-03-27 13:59:55 --> Model Class Initialized
DEBUG - 2024-03-27 13:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 13:59:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 13:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 13:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 13:59:55 --> Model Class Initialized
INFO - 2024-03-27 13:59:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 13:59:55 --> Final output sent to browser
DEBUG - 2024-03-27 13:59:55 --> Total execution time: 0.0321
ERROR - 2024-03-27 14:12:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:12:41 --> Config Class Initialized
INFO - 2024-03-27 14:12:41 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:12:41 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:12:41 --> Utf8 Class Initialized
INFO - 2024-03-27 14:12:41 --> URI Class Initialized
DEBUG - 2024-03-27 14:12:41 --> No URI present. Default controller set.
INFO - 2024-03-27 14:12:41 --> Router Class Initialized
INFO - 2024-03-27 14:12:41 --> Output Class Initialized
INFO - 2024-03-27 14:12:41 --> Security Class Initialized
DEBUG - 2024-03-27 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:12:41 --> Input Class Initialized
INFO - 2024-03-27 14:12:41 --> Language Class Initialized
INFO - 2024-03-27 14:12:41 --> Loader Class Initialized
INFO - 2024-03-27 14:12:41 --> Helper loaded: url_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: file_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: html_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: text_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: form_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: security_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:12:41 --> Database Driver Class Initialized
INFO - 2024-03-27 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:12:41 --> Parser Class Initialized
INFO - 2024-03-27 14:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:12:41 --> Pagination Class Initialized
INFO - 2024-03-27 14:12:41 --> Form Validation Class Initialized
INFO - 2024-03-27 14:12:41 --> Controller Class Initialized
INFO - 2024-03-27 14:12:41 --> Model Class Initialized
DEBUG - 2024-03-27 14:12:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-27 14:12:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:12:41 --> Config Class Initialized
INFO - 2024-03-27 14:12:41 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:12:41 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:12:41 --> Utf8 Class Initialized
INFO - 2024-03-27 14:12:41 --> URI Class Initialized
INFO - 2024-03-27 14:12:41 --> Router Class Initialized
INFO - 2024-03-27 14:12:41 --> Output Class Initialized
INFO - 2024-03-27 14:12:41 --> Security Class Initialized
DEBUG - 2024-03-27 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:12:41 --> Input Class Initialized
INFO - 2024-03-27 14:12:41 --> Language Class Initialized
INFO - 2024-03-27 14:12:41 --> Loader Class Initialized
INFO - 2024-03-27 14:12:41 --> Helper loaded: url_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: file_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: html_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: text_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: form_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: security_helper
INFO - 2024-03-27 14:12:41 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:12:41 --> Database Driver Class Initialized
INFO - 2024-03-27 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:12:41 --> Parser Class Initialized
INFO - 2024-03-27 14:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:12:41 --> Pagination Class Initialized
INFO - 2024-03-27 14:12:41 --> Form Validation Class Initialized
INFO - 2024-03-27 14:12:41 --> Controller Class Initialized
INFO - 2024-03-27 14:12:41 --> Model Class Initialized
DEBUG - 2024-03-27 14:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 14:12:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 14:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 14:12:42 --> Model Class Initialized
INFO - 2024-03-27 14:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 14:12:42 --> Final output sent to browser
DEBUG - 2024-03-27 14:12:42 --> Total execution time: 0.0323
ERROR - 2024-03-27 14:12:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:12:45 --> Config Class Initialized
INFO - 2024-03-27 14:12:45 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:12:45 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:12:45 --> Utf8 Class Initialized
INFO - 2024-03-27 14:12:45 --> URI Class Initialized
INFO - 2024-03-27 14:12:45 --> Router Class Initialized
INFO - 2024-03-27 14:12:45 --> Output Class Initialized
INFO - 2024-03-27 14:12:45 --> Security Class Initialized
DEBUG - 2024-03-27 14:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:12:45 --> Input Class Initialized
INFO - 2024-03-27 14:12:45 --> Language Class Initialized
INFO - 2024-03-27 14:12:45 --> Loader Class Initialized
INFO - 2024-03-27 14:12:45 --> Helper loaded: url_helper
INFO - 2024-03-27 14:12:45 --> Helper loaded: file_helper
INFO - 2024-03-27 14:12:45 --> Helper loaded: html_helper
INFO - 2024-03-27 14:12:45 --> Helper loaded: text_helper
INFO - 2024-03-27 14:12:45 --> Helper loaded: form_helper
INFO - 2024-03-27 14:12:45 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:12:45 --> Helper loaded: security_helper
INFO - 2024-03-27 14:12:45 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:12:45 --> Database Driver Class Initialized
INFO - 2024-03-27 14:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:12:45 --> Parser Class Initialized
INFO - 2024-03-27 14:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:12:45 --> Pagination Class Initialized
INFO - 2024-03-27 14:12:45 --> Form Validation Class Initialized
INFO - 2024-03-27 14:12:45 --> Controller Class Initialized
INFO - 2024-03-27 14:12:45 --> Model Class Initialized
DEBUG - 2024-03-27 14:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 14:12:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 14:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 14:12:45 --> Model Class Initialized
INFO - 2024-03-27 14:12:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 14:12:45 --> Final output sent to browser
DEBUG - 2024-03-27 14:12:45 --> Total execution time: 0.0313
ERROR - 2024-03-27 14:13:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:13:29 --> Config Class Initialized
INFO - 2024-03-27 14:13:29 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:13:29 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:13:29 --> Utf8 Class Initialized
INFO - 2024-03-27 14:13:29 --> URI Class Initialized
INFO - 2024-03-27 14:13:29 --> Router Class Initialized
INFO - 2024-03-27 14:13:29 --> Output Class Initialized
INFO - 2024-03-27 14:13:29 --> Security Class Initialized
DEBUG - 2024-03-27 14:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:13:29 --> Input Class Initialized
INFO - 2024-03-27 14:13:29 --> Language Class Initialized
INFO - 2024-03-27 14:13:29 --> Loader Class Initialized
INFO - 2024-03-27 14:13:29 --> Helper loaded: url_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: file_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: html_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: text_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: form_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: security_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:13:29 --> Database Driver Class Initialized
INFO - 2024-03-27 14:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:13:29 --> Parser Class Initialized
INFO - 2024-03-27 14:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:13:29 --> Pagination Class Initialized
INFO - 2024-03-27 14:13:29 --> Form Validation Class Initialized
INFO - 2024-03-27 14:13:29 --> Controller Class Initialized
INFO - 2024-03-27 14:13:29 --> Model Class Initialized
DEBUG - 2024-03-27 14:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:13:29 --> Model Class Initialized
INFO - 2024-03-27 14:13:29 --> Final output sent to browser
DEBUG - 2024-03-27 14:13:29 --> Total execution time: 0.0236
ERROR - 2024-03-27 14:13:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:13:29 --> Config Class Initialized
INFO - 2024-03-27 14:13:29 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:13:29 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:13:29 --> Utf8 Class Initialized
INFO - 2024-03-27 14:13:29 --> URI Class Initialized
INFO - 2024-03-27 14:13:29 --> Router Class Initialized
INFO - 2024-03-27 14:13:29 --> Output Class Initialized
INFO - 2024-03-27 14:13:29 --> Security Class Initialized
DEBUG - 2024-03-27 14:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:13:29 --> Input Class Initialized
INFO - 2024-03-27 14:13:29 --> Language Class Initialized
INFO - 2024-03-27 14:13:29 --> Loader Class Initialized
INFO - 2024-03-27 14:13:29 --> Helper loaded: url_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: file_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: html_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: text_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: form_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: security_helper
INFO - 2024-03-27 14:13:29 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:13:29 --> Database Driver Class Initialized
INFO - 2024-03-27 14:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:13:29 --> Parser Class Initialized
INFO - 2024-03-27 14:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:13:29 --> Pagination Class Initialized
INFO - 2024-03-27 14:13:29 --> Form Validation Class Initialized
INFO - 2024-03-27 14:13:29 --> Controller Class Initialized
INFO - 2024-03-27 14:13:29 --> Model Class Initialized
DEBUG - 2024-03-27 14:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 14:13:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 14:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 14:13:30 --> Model Class Initialized
INFO - 2024-03-27 14:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 14:13:30 --> Final output sent to browser
DEBUG - 2024-03-27 14:13:30 --> Total execution time: 0.0314
ERROR - 2024-03-27 14:13:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:13:59 --> Config Class Initialized
INFO - 2024-03-27 14:13:59 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:13:59 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:13:59 --> Utf8 Class Initialized
INFO - 2024-03-27 14:13:59 --> URI Class Initialized
INFO - 2024-03-27 14:13:59 --> Router Class Initialized
INFO - 2024-03-27 14:13:59 --> Output Class Initialized
INFO - 2024-03-27 14:13:59 --> Security Class Initialized
DEBUG - 2024-03-27 14:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:13:59 --> Input Class Initialized
INFO - 2024-03-27 14:13:59 --> Language Class Initialized
INFO - 2024-03-27 14:13:59 --> Loader Class Initialized
INFO - 2024-03-27 14:13:59 --> Helper loaded: url_helper
INFO - 2024-03-27 14:13:59 --> Helper loaded: file_helper
INFO - 2024-03-27 14:13:59 --> Helper loaded: html_helper
INFO - 2024-03-27 14:13:59 --> Helper loaded: text_helper
INFO - 2024-03-27 14:13:59 --> Helper loaded: form_helper
INFO - 2024-03-27 14:13:59 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:13:59 --> Helper loaded: security_helper
INFO - 2024-03-27 14:13:59 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:13:59 --> Database Driver Class Initialized
INFO - 2024-03-27 14:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:13:59 --> Parser Class Initialized
INFO - 2024-03-27 14:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:13:59 --> Pagination Class Initialized
INFO - 2024-03-27 14:13:59 --> Form Validation Class Initialized
INFO - 2024-03-27 14:13:59 --> Controller Class Initialized
INFO - 2024-03-27 14:13:59 --> Model Class Initialized
DEBUG - 2024-03-27 14:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 14:13:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 14:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 14:13:59 --> Model Class Initialized
INFO - 2024-03-27 14:13:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 14:13:59 --> Final output sent to browser
DEBUG - 2024-03-27 14:13:59 --> Total execution time: 0.0396
ERROR - 2024-03-27 14:14:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:14:28 --> Config Class Initialized
INFO - 2024-03-27 14:14:28 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:14:28 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:14:28 --> Utf8 Class Initialized
INFO - 2024-03-27 14:14:28 --> URI Class Initialized
INFO - 2024-03-27 14:14:28 --> Router Class Initialized
INFO - 2024-03-27 14:14:28 --> Output Class Initialized
INFO - 2024-03-27 14:14:28 --> Security Class Initialized
DEBUG - 2024-03-27 14:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:14:28 --> Input Class Initialized
INFO - 2024-03-27 14:14:28 --> Language Class Initialized
INFO - 2024-03-27 14:14:28 --> Loader Class Initialized
INFO - 2024-03-27 14:14:28 --> Helper loaded: url_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: file_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: html_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: text_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: form_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: security_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:14:28 --> Database Driver Class Initialized
INFO - 2024-03-27 14:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:14:28 --> Parser Class Initialized
INFO - 2024-03-27 14:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:14:28 --> Pagination Class Initialized
INFO - 2024-03-27 14:14:28 --> Form Validation Class Initialized
INFO - 2024-03-27 14:14:28 --> Controller Class Initialized
INFO - 2024-03-27 14:14:28 --> Model Class Initialized
DEBUG - 2024-03-27 14:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:14:28 --> Model Class Initialized
INFO - 2024-03-27 14:14:28 --> Final output sent to browser
DEBUG - 2024-03-27 14:14:28 --> Total execution time: 0.0200
ERROR - 2024-03-27 14:14:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:14:28 --> Config Class Initialized
INFO - 2024-03-27 14:14:28 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:14:28 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:14:28 --> Utf8 Class Initialized
INFO - 2024-03-27 14:14:28 --> URI Class Initialized
INFO - 2024-03-27 14:14:28 --> Router Class Initialized
INFO - 2024-03-27 14:14:28 --> Output Class Initialized
INFO - 2024-03-27 14:14:28 --> Security Class Initialized
DEBUG - 2024-03-27 14:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:14:28 --> Input Class Initialized
INFO - 2024-03-27 14:14:28 --> Language Class Initialized
INFO - 2024-03-27 14:14:28 --> Loader Class Initialized
INFO - 2024-03-27 14:14:28 --> Helper loaded: url_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: file_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: html_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: text_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: form_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: security_helper
INFO - 2024-03-27 14:14:28 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:14:28 --> Database Driver Class Initialized
INFO - 2024-03-27 14:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:14:28 --> Parser Class Initialized
INFO - 2024-03-27 14:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:14:28 --> Pagination Class Initialized
INFO - 2024-03-27 14:14:28 --> Form Validation Class Initialized
INFO - 2024-03-27 14:14:28 --> Controller Class Initialized
INFO - 2024-03-27 14:14:28 --> Model Class Initialized
DEBUG - 2024-03-27 14:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:14:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 14:14:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:14:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 14:14:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 14:14:28 --> Model Class Initialized
INFO - 2024-03-27 14:14:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 14:14:28 --> Final output sent to browser
DEBUG - 2024-03-27 14:14:28 --> Total execution time: 0.0334
ERROR - 2024-03-27 14:19:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:19:00 --> Config Class Initialized
INFO - 2024-03-27 14:19:00 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:19:00 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:19:00 --> Utf8 Class Initialized
INFO - 2024-03-27 14:19:00 --> URI Class Initialized
INFO - 2024-03-27 14:19:00 --> Router Class Initialized
INFO - 2024-03-27 14:19:00 --> Output Class Initialized
INFO - 2024-03-27 14:19:00 --> Security Class Initialized
DEBUG - 2024-03-27 14:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:19:00 --> Input Class Initialized
INFO - 2024-03-27 14:19:00 --> Language Class Initialized
INFO - 2024-03-27 14:19:00 --> Loader Class Initialized
INFO - 2024-03-27 14:19:00 --> Helper loaded: url_helper
INFO - 2024-03-27 14:19:00 --> Helper loaded: file_helper
INFO - 2024-03-27 14:19:00 --> Helper loaded: html_helper
INFO - 2024-03-27 14:19:00 --> Helper loaded: text_helper
INFO - 2024-03-27 14:19:00 --> Helper loaded: form_helper
INFO - 2024-03-27 14:19:00 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:19:00 --> Helper loaded: security_helper
INFO - 2024-03-27 14:19:00 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:19:00 --> Database Driver Class Initialized
INFO - 2024-03-27 14:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:19:00 --> Parser Class Initialized
INFO - 2024-03-27 14:19:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:19:00 --> Pagination Class Initialized
INFO - 2024-03-27 14:19:00 --> Form Validation Class Initialized
INFO - 2024-03-27 14:19:00 --> Controller Class Initialized
INFO - 2024-03-27 14:19:00 --> Model Class Initialized
DEBUG - 2024-03-27 14:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 14:19:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 14:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 14:19:00 --> Model Class Initialized
INFO - 2024-03-27 14:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 14:19:00 --> Final output sent to browser
DEBUG - 2024-03-27 14:19:00 --> Total execution time: 0.0357
ERROR - 2024-03-27 14:19:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:19:06 --> Config Class Initialized
INFO - 2024-03-27 14:19:06 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:19:06 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:19:06 --> Utf8 Class Initialized
INFO - 2024-03-27 14:19:06 --> URI Class Initialized
INFO - 2024-03-27 14:19:06 --> Router Class Initialized
INFO - 2024-03-27 14:19:06 --> Output Class Initialized
INFO - 2024-03-27 14:19:06 --> Security Class Initialized
DEBUG - 2024-03-27 14:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:19:06 --> Input Class Initialized
INFO - 2024-03-27 14:19:06 --> Language Class Initialized
INFO - 2024-03-27 14:19:06 --> Loader Class Initialized
INFO - 2024-03-27 14:19:06 --> Helper loaded: url_helper
INFO - 2024-03-27 14:19:06 --> Helper loaded: file_helper
INFO - 2024-03-27 14:19:06 --> Helper loaded: html_helper
INFO - 2024-03-27 14:19:06 --> Helper loaded: text_helper
INFO - 2024-03-27 14:19:06 --> Helper loaded: form_helper
INFO - 2024-03-27 14:19:06 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:19:06 --> Helper loaded: security_helper
INFO - 2024-03-27 14:19:06 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:19:06 --> Database Driver Class Initialized
INFO - 2024-03-27 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:19:06 --> Parser Class Initialized
INFO - 2024-03-27 14:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:19:06 --> Pagination Class Initialized
INFO - 2024-03-27 14:19:06 --> Form Validation Class Initialized
INFO - 2024-03-27 14:19:06 --> Controller Class Initialized
INFO - 2024-03-27 14:19:06 --> Model Class Initialized
DEBUG - 2024-03-27 14:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 14:19:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 14:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 14:19:06 --> Model Class Initialized
INFO - 2024-03-27 14:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 14:19:06 --> Final output sent to browser
DEBUG - 2024-03-27 14:19:06 --> Total execution time: 0.0307
ERROR - 2024-03-27 14:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 14:19:15 --> Config Class Initialized
INFO - 2024-03-27 14:19:15 --> Hooks Class Initialized
DEBUG - 2024-03-27 14:19:15 --> UTF-8 Support Enabled
INFO - 2024-03-27 14:19:15 --> Utf8 Class Initialized
INFO - 2024-03-27 14:19:15 --> URI Class Initialized
INFO - 2024-03-27 14:19:15 --> Router Class Initialized
INFO - 2024-03-27 14:19:15 --> Output Class Initialized
INFO - 2024-03-27 14:19:15 --> Security Class Initialized
DEBUG - 2024-03-27 14:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 14:19:15 --> Input Class Initialized
INFO - 2024-03-27 14:19:15 --> Language Class Initialized
INFO - 2024-03-27 14:19:15 --> Loader Class Initialized
INFO - 2024-03-27 14:19:15 --> Helper loaded: url_helper
INFO - 2024-03-27 14:19:15 --> Helper loaded: file_helper
INFO - 2024-03-27 14:19:15 --> Helper loaded: html_helper
INFO - 2024-03-27 14:19:15 --> Helper loaded: text_helper
INFO - 2024-03-27 14:19:15 --> Helper loaded: form_helper
INFO - 2024-03-27 14:19:15 --> Helper loaded: lang_helper
INFO - 2024-03-27 14:19:15 --> Helper loaded: security_helper
INFO - 2024-03-27 14:19:15 --> Helper loaded: cookie_helper
INFO - 2024-03-27 14:19:15 --> Database Driver Class Initialized
INFO - 2024-03-27 14:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 14:19:15 --> Parser Class Initialized
INFO - 2024-03-27 14:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 14:19:15 --> Pagination Class Initialized
INFO - 2024-03-27 14:19:15 --> Form Validation Class Initialized
INFO - 2024-03-27 14:19:15 --> Controller Class Initialized
INFO - 2024-03-27 14:19:15 --> Model Class Initialized
DEBUG - 2024-03-27 14:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-27 14:19:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-27 14:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-27 14:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-27 14:19:15 --> Model Class Initialized
INFO - 2024-03-27 14:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-27 14:19:15 --> Final output sent to browser
DEBUG - 2024-03-27 14:19:15 --> Total execution time: 0.0375
ERROR - 2024-03-27 15:56:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 15:56:16 --> Config Class Initialized
INFO - 2024-03-27 15:56:16 --> Hooks Class Initialized
DEBUG - 2024-03-27 15:56:16 --> UTF-8 Support Enabled
INFO - 2024-03-27 15:56:16 --> Utf8 Class Initialized
INFO - 2024-03-27 15:56:16 --> URI Class Initialized
INFO - 2024-03-27 15:56:16 --> Router Class Initialized
INFO - 2024-03-27 15:56:16 --> Output Class Initialized
INFO - 2024-03-27 15:56:16 --> Security Class Initialized
DEBUG - 2024-03-27 15:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 15:56:16 --> Input Class Initialized
INFO - 2024-03-27 15:56:16 --> Language Class Initialized
ERROR - 2024-03-27 15:56:16 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-27 20:37:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 20:37:48 --> Config Class Initialized
INFO - 2024-03-27 20:37:48 --> Hooks Class Initialized
DEBUG - 2024-03-27 20:37:48 --> UTF-8 Support Enabled
INFO - 2024-03-27 20:37:48 --> Utf8 Class Initialized
INFO - 2024-03-27 20:37:48 --> URI Class Initialized
DEBUG - 2024-03-27 20:37:48 --> No URI present. Default controller set.
INFO - 2024-03-27 20:37:48 --> Router Class Initialized
INFO - 2024-03-27 20:37:48 --> Output Class Initialized
INFO - 2024-03-27 20:37:48 --> Security Class Initialized
DEBUG - 2024-03-27 20:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 20:37:48 --> Input Class Initialized
INFO - 2024-03-27 20:37:48 --> Language Class Initialized
INFO - 2024-03-27 20:37:48 --> Loader Class Initialized
INFO - 2024-03-27 20:37:48 --> Helper loaded: url_helper
INFO - 2024-03-27 20:37:48 --> Helper loaded: file_helper
INFO - 2024-03-27 20:37:48 --> Helper loaded: html_helper
INFO - 2024-03-27 20:37:48 --> Helper loaded: text_helper
INFO - 2024-03-27 20:37:48 --> Helper loaded: form_helper
INFO - 2024-03-27 20:37:48 --> Helper loaded: lang_helper
INFO - 2024-03-27 20:37:48 --> Helper loaded: security_helper
INFO - 2024-03-27 20:37:48 --> Helper loaded: cookie_helper
INFO - 2024-03-27 20:37:48 --> Database Driver Class Initialized
INFO - 2024-03-27 20:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-27 20:37:48 --> Parser Class Initialized
INFO - 2024-03-27 20:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-27 20:37:48 --> Pagination Class Initialized
INFO - 2024-03-27 20:37:48 --> Form Validation Class Initialized
INFO - 2024-03-27 20:37:48 --> Controller Class Initialized
INFO - 2024-03-27 20:37:48 --> Model Class Initialized
DEBUG - 2024-03-27 20:37:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-27 21:26:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-27 21:26:24 --> Config Class Initialized
INFO - 2024-03-27 21:26:24 --> Hooks Class Initialized
DEBUG - 2024-03-27 21:26:24 --> UTF-8 Support Enabled
INFO - 2024-03-27 21:26:24 --> Utf8 Class Initialized
INFO - 2024-03-27 21:26:24 --> URI Class Initialized
INFO - 2024-03-27 21:26:24 --> Router Class Initialized
INFO - 2024-03-27 21:26:24 --> Output Class Initialized
INFO - 2024-03-27 21:26:24 --> Security Class Initialized
DEBUG - 2024-03-27 21:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-27 21:26:24 --> Input Class Initialized
INFO - 2024-03-27 21:26:24 --> Language Class Initialized
ERROR - 2024-03-27 21:26:24 --> 404 Page Not Found: Well-known/assetlinks.json
