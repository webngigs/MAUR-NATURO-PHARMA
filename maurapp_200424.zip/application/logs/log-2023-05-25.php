<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-25 00:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:48:54 --> Config Class Initialized
INFO - 2023-05-25 00:48:54 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:48:54 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:48:54 --> Utf8 Class Initialized
INFO - 2023-05-25 00:48:54 --> URI Class Initialized
DEBUG - 2023-05-25 00:48:54 --> No URI present. Default controller set.
INFO - 2023-05-25 00:48:54 --> Router Class Initialized
INFO - 2023-05-25 00:48:54 --> Output Class Initialized
INFO - 2023-05-25 00:48:54 --> Security Class Initialized
DEBUG - 2023-05-25 00:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:48:54 --> Input Class Initialized
INFO - 2023-05-25 00:48:54 --> Language Class Initialized
INFO - 2023-05-25 00:48:54 --> Loader Class Initialized
INFO - 2023-05-25 00:48:54 --> Helper loaded: url_helper
INFO - 2023-05-25 00:48:54 --> Helper loaded: file_helper
INFO - 2023-05-25 00:48:54 --> Helper loaded: html_helper
INFO - 2023-05-25 00:48:54 --> Helper loaded: text_helper
INFO - 2023-05-25 00:48:54 --> Helper loaded: form_helper
INFO - 2023-05-25 00:48:54 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:48:54 --> Helper loaded: security_helper
INFO - 2023-05-25 00:48:54 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:48:54 --> Database Driver Class Initialized
INFO - 2023-05-25 00:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:48:54 --> Parser Class Initialized
INFO - 2023-05-25 00:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:48:54 --> Pagination Class Initialized
INFO - 2023-05-25 00:48:54 --> Form Validation Class Initialized
INFO - 2023-05-25 00:48:54 --> Controller Class Initialized
INFO - 2023-05-25 00:48:54 --> Model Class Initialized
DEBUG - 2023-05-25 00:48:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-25 00:48:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:48:55 --> Config Class Initialized
INFO - 2023-05-25 00:48:55 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:48:55 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:48:55 --> Utf8 Class Initialized
INFO - 2023-05-25 00:48:55 --> URI Class Initialized
INFO - 2023-05-25 00:48:55 --> Router Class Initialized
INFO - 2023-05-25 00:48:55 --> Output Class Initialized
INFO - 2023-05-25 00:48:55 --> Security Class Initialized
DEBUG - 2023-05-25 00:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:48:55 --> Input Class Initialized
INFO - 2023-05-25 00:48:55 --> Language Class Initialized
INFO - 2023-05-25 00:48:55 --> Loader Class Initialized
INFO - 2023-05-25 00:48:55 --> Helper loaded: url_helper
INFO - 2023-05-25 00:48:55 --> Helper loaded: file_helper
INFO - 2023-05-25 00:48:55 --> Helper loaded: html_helper
INFO - 2023-05-25 00:48:55 --> Helper loaded: text_helper
INFO - 2023-05-25 00:48:55 --> Helper loaded: form_helper
INFO - 2023-05-25 00:48:55 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:48:55 --> Helper loaded: security_helper
INFO - 2023-05-25 00:48:55 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:48:55 --> Database Driver Class Initialized
INFO - 2023-05-25 00:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:48:55 --> Parser Class Initialized
INFO - 2023-05-25 00:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:48:55 --> Pagination Class Initialized
INFO - 2023-05-25 00:48:55 --> Form Validation Class Initialized
INFO - 2023-05-25 00:48:55 --> Controller Class Initialized
INFO - 2023-05-25 00:48:55 --> Model Class Initialized
DEBUG - 2023-05-25 00:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-25 00:48:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:48:55 --> Model Class Initialized
INFO - 2023-05-25 00:48:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:48:55 --> Final output sent to browser
DEBUG - 2023-05-25 00:48:55 --> Total execution time: 0.0321
ERROR - 2023-05-25 00:49:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:49:16 --> Config Class Initialized
INFO - 2023-05-25 00:49:16 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:49:16 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:49:16 --> Utf8 Class Initialized
INFO - 2023-05-25 00:49:16 --> URI Class Initialized
INFO - 2023-05-25 00:49:16 --> Router Class Initialized
INFO - 2023-05-25 00:49:16 --> Output Class Initialized
INFO - 2023-05-25 00:49:16 --> Security Class Initialized
DEBUG - 2023-05-25 00:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:49:16 --> Input Class Initialized
INFO - 2023-05-25 00:49:16 --> Language Class Initialized
INFO - 2023-05-25 00:49:16 --> Loader Class Initialized
INFO - 2023-05-25 00:49:16 --> Helper loaded: url_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: file_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: html_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: text_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: form_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: security_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:49:16 --> Database Driver Class Initialized
INFO - 2023-05-25 00:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:49:16 --> Parser Class Initialized
INFO - 2023-05-25 00:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:49:16 --> Pagination Class Initialized
INFO - 2023-05-25 00:49:16 --> Form Validation Class Initialized
INFO - 2023-05-25 00:49:16 --> Controller Class Initialized
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
DEBUG - 2023-05-25 00:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
INFO - 2023-05-25 00:49:16 --> Final output sent to browser
DEBUG - 2023-05-25 00:49:16 --> Total execution time: 0.0208
ERROR - 2023-05-25 00:49:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:49:16 --> Config Class Initialized
INFO - 2023-05-25 00:49:16 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:49:16 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:49:16 --> Utf8 Class Initialized
INFO - 2023-05-25 00:49:16 --> URI Class Initialized
DEBUG - 2023-05-25 00:49:16 --> No URI present. Default controller set.
INFO - 2023-05-25 00:49:16 --> Router Class Initialized
INFO - 2023-05-25 00:49:16 --> Output Class Initialized
INFO - 2023-05-25 00:49:16 --> Security Class Initialized
DEBUG - 2023-05-25 00:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:49:16 --> Input Class Initialized
INFO - 2023-05-25 00:49:16 --> Language Class Initialized
INFO - 2023-05-25 00:49:16 --> Loader Class Initialized
INFO - 2023-05-25 00:49:16 --> Helper loaded: url_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: file_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: html_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: text_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: form_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: security_helper
INFO - 2023-05-25 00:49:16 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:49:16 --> Database Driver Class Initialized
INFO - 2023-05-25 00:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:49:16 --> Parser Class Initialized
INFO - 2023-05-25 00:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:49:16 --> Pagination Class Initialized
INFO - 2023-05-25 00:49:16 --> Form Validation Class Initialized
INFO - 2023-05-25 00:49:16 --> Controller Class Initialized
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
DEBUG - 2023-05-25 00:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
DEBUG - 2023-05-25 00:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
DEBUG - 2023-05-25 00:49:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
INFO - 2023-05-25 00:49:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-25 00:49:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:49:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:49:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:49:16 --> Model Class Initialized
INFO - 2023-05-25 00:49:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 00:49:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 00:49:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:49:16 --> Final output sent to browser
DEBUG - 2023-05-25 00:49:16 --> Total execution time: 0.0664
ERROR - 2023-05-25 00:49:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:49:31 --> Config Class Initialized
INFO - 2023-05-25 00:49:31 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:49:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:49:31 --> Utf8 Class Initialized
INFO - 2023-05-25 00:49:31 --> URI Class Initialized
INFO - 2023-05-25 00:49:31 --> Router Class Initialized
INFO - 2023-05-25 00:49:31 --> Output Class Initialized
INFO - 2023-05-25 00:49:31 --> Security Class Initialized
DEBUG - 2023-05-25 00:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:49:31 --> Input Class Initialized
INFO - 2023-05-25 00:49:31 --> Language Class Initialized
INFO - 2023-05-25 00:49:31 --> Loader Class Initialized
INFO - 2023-05-25 00:49:31 --> Helper loaded: url_helper
INFO - 2023-05-25 00:49:31 --> Helper loaded: file_helper
INFO - 2023-05-25 00:49:31 --> Helper loaded: html_helper
INFO - 2023-05-25 00:49:31 --> Helper loaded: text_helper
INFO - 2023-05-25 00:49:31 --> Helper loaded: form_helper
INFO - 2023-05-25 00:49:31 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:49:31 --> Helper loaded: security_helper
INFO - 2023-05-25 00:49:31 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:49:31 --> Database Driver Class Initialized
INFO - 2023-05-25 00:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:49:31 --> Parser Class Initialized
INFO - 2023-05-25 00:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:49:31 --> Pagination Class Initialized
INFO - 2023-05-25 00:49:31 --> Form Validation Class Initialized
INFO - 2023-05-25 00:49:31 --> Controller Class Initialized
INFO - 2023-05-25 00:49:31 --> Model Class Initialized
INFO - 2023-05-25 00:49:31 --> Model Class Initialized
INFO - 2023-05-25 00:49:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-05-25 00:49:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:49:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:49:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:49:31 --> Model Class Initialized
INFO - 2023-05-25 00:49:31 --> Model Class Initialized
INFO - 2023-05-25 00:49:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 00:49:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 00:49:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:49:31 --> Final output sent to browser
DEBUG - 2023-05-25 00:49:31 --> Total execution time: 0.0586
ERROR - 2023-05-25 00:49:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:49:32 --> Config Class Initialized
INFO - 2023-05-25 00:49:32 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:49:32 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:49:32 --> Utf8 Class Initialized
INFO - 2023-05-25 00:49:32 --> URI Class Initialized
INFO - 2023-05-25 00:49:32 --> Router Class Initialized
INFO - 2023-05-25 00:49:32 --> Output Class Initialized
INFO - 2023-05-25 00:49:32 --> Security Class Initialized
DEBUG - 2023-05-25 00:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:49:32 --> Input Class Initialized
INFO - 2023-05-25 00:49:32 --> Language Class Initialized
INFO - 2023-05-25 00:49:32 --> Loader Class Initialized
INFO - 2023-05-25 00:49:32 --> Helper loaded: url_helper
INFO - 2023-05-25 00:49:32 --> Helper loaded: file_helper
INFO - 2023-05-25 00:49:32 --> Helper loaded: html_helper
INFO - 2023-05-25 00:49:32 --> Helper loaded: text_helper
INFO - 2023-05-25 00:49:32 --> Helper loaded: form_helper
INFO - 2023-05-25 00:49:32 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:49:32 --> Helper loaded: security_helper
INFO - 2023-05-25 00:49:32 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:49:32 --> Database Driver Class Initialized
INFO - 2023-05-25 00:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:49:32 --> Parser Class Initialized
INFO - 2023-05-25 00:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:49:32 --> Pagination Class Initialized
INFO - 2023-05-25 00:49:32 --> Form Validation Class Initialized
INFO - 2023-05-25 00:49:32 --> Controller Class Initialized
INFO - 2023-05-25 00:49:32 --> Model Class Initialized
INFO - 2023-05-25 00:49:32 --> Model Class Initialized
INFO - 2023-05-25 00:49:32 --> Final output sent to browser
DEBUG - 2023-05-25 00:49:32 --> Total execution time: 0.0197
ERROR - 2023-05-25 00:50:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:03 --> Config Class Initialized
INFO - 2023-05-25 00:50:03 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:03 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:03 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:03 --> URI Class Initialized
DEBUG - 2023-05-25 00:50:03 --> No URI present. Default controller set.
INFO - 2023-05-25 00:50:03 --> Router Class Initialized
INFO - 2023-05-25 00:50:03 --> Output Class Initialized
INFO - 2023-05-25 00:50:03 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:03 --> Input Class Initialized
INFO - 2023-05-25 00:50:03 --> Language Class Initialized
INFO - 2023-05-25 00:50:03 --> Loader Class Initialized
INFO - 2023-05-25 00:50:03 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:03 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:03 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:03 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:03 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:03 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:03 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:03 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:03 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:03 --> Parser Class Initialized
INFO - 2023-05-25 00:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:03 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:03 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:03 --> Controller Class Initialized
INFO - 2023-05-25 00:50:03 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:03 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:03 --> Model Class Initialized
INFO - 2023-05-25 00:50:03 --> Model Class Initialized
INFO - 2023-05-25 00:50:03 --> Model Class Initialized
INFO - 2023-05-25 00:50:03 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:03 --> Model Class Initialized
INFO - 2023-05-25 00:50:03 --> Model Class Initialized
INFO - 2023-05-25 00:50:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-25 00:50:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:50:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:50:03 --> Model Class Initialized
INFO - 2023-05-25 00:50:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 00:50:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 00:50:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:50:03 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:03 --> Total execution time: 0.0663
ERROR - 2023-05-25 00:50:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:09 --> Config Class Initialized
INFO - 2023-05-25 00:50:09 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:09 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:09 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:09 --> URI Class Initialized
INFO - 2023-05-25 00:50:09 --> Router Class Initialized
INFO - 2023-05-25 00:50:09 --> Output Class Initialized
INFO - 2023-05-25 00:50:09 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:09 --> Input Class Initialized
INFO - 2023-05-25 00:50:09 --> Language Class Initialized
INFO - 2023-05-25 00:50:09 --> Loader Class Initialized
INFO - 2023-05-25 00:50:09 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:09 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:09 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:09 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:09 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:09 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:09 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:09 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:09 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:09 --> Parser Class Initialized
INFO - 2023-05-25 00:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:09 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:09 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:09 --> Controller Class Initialized
DEBUG - 2023-05-25 00:50:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:09 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:09 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:09 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:09 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:09 --> Model Class Initialized
INFO - 2023-05-25 00:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-05-25 00:50:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:50:09 --> Model Class Initialized
INFO - 2023-05-25 00:50:09 --> Model Class Initialized
INFO - 2023-05-25 00:50:09 --> Model Class Initialized
INFO - 2023-05-25 00:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 00:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 00:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:50:09 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:09 --> Total execution time: 0.0588
ERROR - 2023-05-25 00:50:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:10 --> Config Class Initialized
INFO - 2023-05-25 00:50:10 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:10 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:10 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:10 --> URI Class Initialized
INFO - 2023-05-25 00:50:10 --> Router Class Initialized
INFO - 2023-05-25 00:50:10 --> Output Class Initialized
INFO - 2023-05-25 00:50:10 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:10 --> Input Class Initialized
INFO - 2023-05-25 00:50:10 --> Language Class Initialized
INFO - 2023-05-25 00:50:10 --> Loader Class Initialized
INFO - 2023-05-25 00:50:10 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:10 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:10 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:10 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:10 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:10 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:10 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:10 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:10 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:10 --> Parser Class Initialized
INFO - 2023-05-25 00:50:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:10 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:10 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:10 --> Controller Class Initialized
DEBUG - 2023-05-25 00:50:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:10 --> Model Class Initialized
INFO - 2023-05-25 00:50:10 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:10 --> Total execution time: 0.0178
ERROR - 2023-05-25 00:50:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:16 --> Config Class Initialized
INFO - 2023-05-25 00:50:16 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:16 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:16 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:16 --> URI Class Initialized
INFO - 2023-05-25 00:50:16 --> Router Class Initialized
INFO - 2023-05-25 00:50:16 --> Output Class Initialized
INFO - 2023-05-25 00:50:16 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:16 --> Input Class Initialized
INFO - 2023-05-25 00:50:16 --> Language Class Initialized
INFO - 2023-05-25 00:50:16 --> Loader Class Initialized
INFO - 2023-05-25 00:50:16 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:16 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:16 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:16 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:16 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:16 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:16 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:16 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:16 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:16 --> Parser Class Initialized
INFO - 2023-05-25 00:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:16 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:16 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:16 --> Controller Class Initialized
DEBUG - 2023-05-25 00:50:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:16 --> Model Class Initialized
INFO - 2023-05-25 00:50:16 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:16 --> Total execution time: 0.0157
ERROR - 2023-05-25 00:50:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:18 --> Config Class Initialized
INFO - 2023-05-25 00:50:18 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:18 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:18 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:18 --> URI Class Initialized
INFO - 2023-05-25 00:50:18 --> Router Class Initialized
INFO - 2023-05-25 00:50:18 --> Output Class Initialized
INFO - 2023-05-25 00:50:18 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:18 --> Input Class Initialized
INFO - 2023-05-25 00:50:18 --> Language Class Initialized
INFO - 2023-05-25 00:50:18 --> Loader Class Initialized
INFO - 2023-05-25 00:50:18 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:18 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:18 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:18 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:18 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:18 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:18 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:18 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:18 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:18 --> Parser Class Initialized
INFO - 2023-05-25 00:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:18 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:18 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:18 --> Controller Class Initialized
DEBUG - 2023-05-25 00:50:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:18 --> Model Class Initialized
INFO - 2023-05-25 00:50:18 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:18 --> Total execution time: 0.0185
ERROR - 2023-05-25 00:50:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:21 --> Config Class Initialized
INFO - 2023-05-25 00:50:21 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:21 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:21 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:21 --> URI Class Initialized
DEBUG - 2023-05-25 00:50:21 --> No URI present. Default controller set.
INFO - 2023-05-25 00:50:21 --> Router Class Initialized
INFO - 2023-05-25 00:50:21 --> Output Class Initialized
INFO - 2023-05-25 00:50:21 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:21 --> Input Class Initialized
INFO - 2023-05-25 00:50:21 --> Language Class Initialized
INFO - 2023-05-25 00:50:21 --> Loader Class Initialized
INFO - 2023-05-25 00:50:21 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:21 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:21 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:21 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:21 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:21 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:21 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:21 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:21 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:21 --> Parser Class Initialized
INFO - 2023-05-25 00:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:21 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:21 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:21 --> Controller Class Initialized
INFO - 2023-05-25 00:50:21 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:21 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:21 --> Model Class Initialized
INFO - 2023-05-25 00:50:21 --> Model Class Initialized
INFO - 2023-05-25 00:50:21 --> Model Class Initialized
INFO - 2023-05-25 00:50:21 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:21 --> Model Class Initialized
INFO - 2023-05-25 00:50:21 --> Model Class Initialized
INFO - 2023-05-25 00:50:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-25 00:50:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:50:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:50:21 --> Model Class Initialized
INFO - 2023-05-25 00:50:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 00:50:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 00:50:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:50:21 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:21 --> Total execution time: 0.0654
ERROR - 2023-05-25 00:50:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:32 --> Config Class Initialized
INFO - 2023-05-25 00:50:32 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:32 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:32 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:32 --> URI Class Initialized
INFO - 2023-05-25 00:50:32 --> Router Class Initialized
INFO - 2023-05-25 00:50:32 --> Output Class Initialized
INFO - 2023-05-25 00:50:32 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:32 --> Input Class Initialized
INFO - 2023-05-25 00:50:32 --> Language Class Initialized
INFO - 2023-05-25 00:50:32 --> Loader Class Initialized
INFO - 2023-05-25 00:50:32 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:32 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:32 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:32 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:32 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:32 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:32 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:32 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:32 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:32 --> Parser Class Initialized
INFO - 2023-05-25 00:50:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:32 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:32 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:32 --> Controller Class Initialized
INFO - 2023-05-25 00:50:32 --> Model Class Initialized
INFO - 2023-05-25 00:50:32 --> Model Class Initialized
INFO - 2023-05-25 00:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-05-25 00:50:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:50:32 --> Model Class Initialized
INFO - 2023-05-25 00:50:32 --> Model Class Initialized
INFO - 2023-05-25 00:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 00:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 00:50:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:50:32 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:32 --> Total execution time: 0.0508
ERROR - 2023-05-25 00:50:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:33 --> Config Class Initialized
INFO - 2023-05-25 00:50:33 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:33 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:33 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:33 --> URI Class Initialized
INFO - 2023-05-25 00:50:33 --> Router Class Initialized
INFO - 2023-05-25 00:50:33 --> Output Class Initialized
INFO - 2023-05-25 00:50:33 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:33 --> Input Class Initialized
INFO - 2023-05-25 00:50:33 --> Language Class Initialized
INFO - 2023-05-25 00:50:33 --> Loader Class Initialized
INFO - 2023-05-25 00:50:33 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:33 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:33 --> Parser Class Initialized
INFO - 2023-05-25 00:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:33 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:33 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:33 --> Controller Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:33 --> Total execution time: 0.0171
ERROR - 2023-05-25 00:50:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:33 --> Config Class Initialized
INFO - 2023-05-25 00:50:33 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:33 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:33 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:33 --> URI Class Initialized
DEBUG - 2023-05-25 00:50:33 --> No URI present. Default controller set.
INFO - 2023-05-25 00:50:33 --> Router Class Initialized
INFO - 2023-05-25 00:50:33 --> Output Class Initialized
INFO - 2023-05-25 00:50:33 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:33 --> Input Class Initialized
INFO - 2023-05-25 00:50:33 --> Language Class Initialized
INFO - 2023-05-25 00:50:33 --> Loader Class Initialized
INFO - 2023-05-25 00:50:33 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:33 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:33 --> Parser Class Initialized
INFO - 2023-05-25 00:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:33 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:33 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:33 --> Controller Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-25 00:50:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:50:33 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:33 --> Total execution time: 0.0607
ERROR - 2023-05-25 00:50:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:33 --> Config Class Initialized
INFO - 2023-05-25 00:50:33 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:33 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:33 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:33 --> URI Class Initialized
INFO - 2023-05-25 00:50:33 --> Router Class Initialized
INFO - 2023-05-25 00:50:33 --> Output Class Initialized
INFO - 2023-05-25 00:50:33 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:33 --> Input Class Initialized
INFO - 2023-05-25 00:50:33 --> Language Class Initialized
INFO - 2023-05-25 00:50:33 --> Loader Class Initialized
INFO - 2023-05-25 00:50:33 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:33 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:33 --> Parser Class Initialized
INFO - 2023-05-25 00:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:33 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:33 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:33 --> Controller Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-25 00:50:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:50:33 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:33 --> Total execution time: 0.0274
ERROR - 2023-05-25 00:50:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 00:50:33 --> Config Class Initialized
INFO - 2023-05-25 00:50:33 --> Hooks Class Initialized
DEBUG - 2023-05-25 00:50:33 --> UTF-8 Support Enabled
INFO - 2023-05-25 00:50:33 --> Utf8 Class Initialized
INFO - 2023-05-25 00:50:33 --> URI Class Initialized
INFO - 2023-05-25 00:50:33 --> Router Class Initialized
INFO - 2023-05-25 00:50:33 --> Output Class Initialized
INFO - 2023-05-25 00:50:33 --> Security Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 00:50:33 --> Input Class Initialized
INFO - 2023-05-25 00:50:33 --> Language Class Initialized
INFO - 2023-05-25 00:50:33 --> Loader Class Initialized
INFO - 2023-05-25 00:50:33 --> Helper loaded: url_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: file_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: html_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: text_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: form_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: lang_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: security_helper
INFO - 2023-05-25 00:50:33 --> Helper loaded: cookie_helper
INFO - 2023-05-25 00:50:33 --> Database Driver Class Initialized
INFO - 2023-05-25 00:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 00:50:33 --> Parser Class Initialized
INFO - 2023-05-25 00:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 00:50:33 --> Pagination Class Initialized
INFO - 2023-05-25 00:50:33 --> Form Validation Class Initialized
INFO - 2023-05-25 00:50:33 --> Controller Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
DEBUG - 2023-05-25 00:50:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 00:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-25 00:50:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 00:50:33 --> Model Class Initialized
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 00:50:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 00:50:33 --> Final output sent to browser
DEBUG - 2023-05-25 00:50:33 --> Total execution time: 0.0582
ERROR - 2023-05-25 01:35:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 01:35:28 --> Config Class Initialized
INFO - 2023-05-25 01:35:28 --> Hooks Class Initialized
DEBUG - 2023-05-25 01:35:28 --> UTF-8 Support Enabled
INFO - 2023-05-25 01:35:28 --> Utf8 Class Initialized
INFO - 2023-05-25 01:35:28 --> URI Class Initialized
INFO - 2023-05-25 01:35:28 --> Router Class Initialized
INFO - 2023-05-25 01:35:28 --> Output Class Initialized
INFO - 2023-05-25 01:35:28 --> Security Class Initialized
DEBUG - 2023-05-25 01:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 01:35:28 --> Input Class Initialized
INFO - 2023-05-25 01:35:28 --> Language Class Initialized
INFO - 2023-05-25 01:35:28 --> Loader Class Initialized
INFO - 2023-05-25 01:35:28 --> Helper loaded: url_helper
INFO - 2023-05-25 01:35:28 --> Helper loaded: file_helper
INFO - 2023-05-25 01:35:28 --> Helper loaded: html_helper
INFO - 2023-05-25 01:35:28 --> Helper loaded: text_helper
INFO - 2023-05-25 01:35:28 --> Helper loaded: form_helper
INFO - 2023-05-25 01:35:28 --> Helper loaded: lang_helper
INFO - 2023-05-25 01:35:28 --> Helper loaded: security_helper
INFO - 2023-05-25 01:35:28 --> Helper loaded: cookie_helper
INFO - 2023-05-25 01:35:28 --> Database Driver Class Initialized
INFO - 2023-05-25 01:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 01:35:28 --> Parser Class Initialized
INFO - 2023-05-25 01:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 01:35:28 --> Pagination Class Initialized
INFO - 2023-05-25 01:35:28 --> Form Validation Class Initialized
INFO - 2023-05-25 01:35:28 --> Controller Class Initialized
INFO - 2023-05-25 01:35:28 --> Model Class Initialized
ERROR - 2023-05-25 10:55:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 10:55:28 --> Config Class Initialized
INFO - 2023-05-25 10:55:28 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:55:28 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:55:28 --> Utf8 Class Initialized
INFO - 2023-05-25 10:55:28 --> URI Class Initialized
DEBUG - 2023-05-25 10:55:28 --> No URI present. Default controller set.
INFO - 2023-05-25 10:55:28 --> Router Class Initialized
INFO - 2023-05-25 10:55:28 --> Output Class Initialized
INFO - 2023-05-25 10:55:28 --> Security Class Initialized
DEBUG - 2023-05-25 10:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:55:28 --> Input Class Initialized
INFO - 2023-05-25 10:55:28 --> Language Class Initialized
INFO - 2023-05-25 10:55:28 --> Loader Class Initialized
INFO - 2023-05-25 10:55:28 --> Helper loaded: url_helper
INFO - 2023-05-25 10:55:28 --> Helper loaded: file_helper
INFO - 2023-05-25 10:55:28 --> Helper loaded: html_helper
INFO - 2023-05-25 10:55:28 --> Helper loaded: text_helper
INFO - 2023-05-25 10:55:28 --> Helper loaded: form_helper
INFO - 2023-05-25 10:55:28 --> Helper loaded: lang_helper
INFO - 2023-05-25 10:55:28 --> Helper loaded: security_helper
INFO - 2023-05-25 10:55:28 --> Helper loaded: cookie_helper
INFO - 2023-05-25 10:55:28 --> Database Driver Class Initialized
INFO - 2023-05-25 10:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 10:55:28 --> Parser Class Initialized
INFO - 2023-05-25 10:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 10:55:28 --> Pagination Class Initialized
INFO - 2023-05-25 10:55:28 --> Form Validation Class Initialized
INFO - 2023-05-25 10:55:28 --> Controller Class Initialized
INFO - 2023-05-25 10:55:28 --> Model Class Initialized
DEBUG - 2023-05-25 10:55:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-25 16:22:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:22:49 --> Config Class Initialized
INFO - 2023-05-25 16:22:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:22:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:22:49 --> Utf8 Class Initialized
INFO - 2023-05-25 16:22:49 --> URI Class Initialized
DEBUG - 2023-05-25 16:22:49 --> No URI present. Default controller set.
INFO - 2023-05-25 16:22:49 --> Router Class Initialized
INFO - 2023-05-25 16:22:49 --> Output Class Initialized
INFO - 2023-05-25 16:22:49 --> Security Class Initialized
DEBUG - 2023-05-25 16:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:22:49 --> Input Class Initialized
INFO - 2023-05-25 16:22:49 --> Language Class Initialized
INFO - 2023-05-25 16:22:49 --> Loader Class Initialized
INFO - 2023-05-25 16:22:49 --> Helper loaded: url_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: file_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: html_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: text_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: form_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: security_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:22:49 --> Database Driver Class Initialized
INFO - 2023-05-25 16:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:22:49 --> Parser Class Initialized
INFO - 2023-05-25 16:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:22:49 --> Pagination Class Initialized
INFO - 2023-05-25 16:22:49 --> Form Validation Class Initialized
INFO - 2023-05-25 16:22:49 --> Controller Class Initialized
INFO - 2023-05-25 16:22:49 --> Model Class Initialized
DEBUG - 2023-05-25 16:22:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-25 16:22:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:22:49 --> Config Class Initialized
INFO - 2023-05-25 16:22:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:22:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:22:49 --> Utf8 Class Initialized
INFO - 2023-05-25 16:22:49 --> URI Class Initialized
INFO - 2023-05-25 16:22:49 --> Router Class Initialized
INFO - 2023-05-25 16:22:49 --> Output Class Initialized
INFO - 2023-05-25 16:22:49 --> Security Class Initialized
DEBUG - 2023-05-25 16:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:22:49 --> Input Class Initialized
INFO - 2023-05-25 16:22:49 --> Language Class Initialized
INFO - 2023-05-25 16:22:49 --> Loader Class Initialized
INFO - 2023-05-25 16:22:49 --> Helper loaded: url_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: file_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: html_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: text_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: form_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: security_helper
INFO - 2023-05-25 16:22:49 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:22:49 --> Database Driver Class Initialized
INFO - 2023-05-25 16:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:22:49 --> Parser Class Initialized
INFO - 2023-05-25 16:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:22:49 --> Pagination Class Initialized
INFO - 2023-05-25 16:22:49 --> Form Validation Class Initialized
INFO - 2023-05-25 16:22:49 --> Controller Class Initialized
INFO - 2023-05-25 16:22:49 --> Model Class Initialized
DEBUG - 2023-05-25 16:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-25 16:22:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 16:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 16:22:49 --> Model Class Initialized
INFO - 2023-05-25 16:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 16:22:49 --> Final output sent to browser
DEBUG - 2023-05-25 16:22:49 --> Total execution time: 0.0345
ERROR - 2023-05-25 16:23:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:23:08 --> Config Class Initialized
INFO - 2023-05-25 16:23:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:23:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:23:08 --> Utf8 Class Initialized
INFO - 2023-05-25 16:23:08 --> URI Class Initialized
INFO - 2023-05-25 16:23:08 --> Router Class Initialized
INFO - 2023-05-25 16:23:08 --> Output Class Initialized
INFO - 2023-05-25 16:23:08 --> Security Class Initialized
DEBUG - 2023-05-25 16:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:23:08 --> Input Class Initialized
INFO - 2023-05-25 16:23:08 --> Language Class Initialized
INFO - 2023-05-25 16:23:08 --> Loader Class Initialized
INFO - 2023-05-25 16:23:08 --> Helper loaded: url_helper
INFO - 2023-05-25 16:23:08 --> Helper loaded: file_helper
INFO - 2023-05-25 16:23:08 --> Helper loaded: html_helper
INFO - 2023-05-25 16:23:08 --> Helper loaded: text_helper
INFO - 2023-05-25 16:23:08 --> Helper loaded: form_helper
INFO - 2023-05-25 16:23:08 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:23:08 --> Helper loaded: security_helper
INFO - 2023-05-25 16:23:08 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:23:08 --> Database Driver Class Initialized
INFO - 2023-05-25 16:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:23:08 --> Parser Class Initialized
INFO - 2023-05-25 16:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:23:08 --> Pagination Class Initialized
INFO - 2023-05-25 16:23:08 --> Form Validation Class Initialized
INFO - 2023-05-25 16:23:08 --> Controller Class Initialized
INFO - 2023-05-25 16:23:08 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:08 --> Model Class Initialized
INFO - 2023-05-25 16:23:08 --> Final output sent to browser
DEBUG - 2023-05-25 16:23:08 --> Total execution time: 0.0198
ERROR - 2023-05-25 16:23:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:23:09 --> Config Class Initialized
INFO - 2023-05-25 16:23:09 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:23:09 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:23:09 --> Utf8 Class Initialized
INFO - 2023-05-25 16:23:09 --> URI Class Initialized
DEBUG - 2023-05-25 16:23:09 --> No URI present. Default controller set.
INFO - 2023-05-25 16:23:09 --> Router Class Initialized
INFO - 2023-05-25 16:23:09 --> Output Class Initialized
INFO - 2023-05-25 16:23:09 --> Security Class Initialized
DEBUG - 2023-05-25 16:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:23:09 --> Input Class Initialized
INFO - 2023-05-25 16:23:09 --> Language Class Initialized
INFO - 2023-05-25 16:23:09 --> Loader Class Initialized
INFO - 2023-05-25 16:23:09 --> Helper loaded: url_helper
INFO - 2023-05-25 16:23:09 --> Helper loaded: file_helper
INFO - 2023-05-25 16:23:09 --> Helper loaded: html_helper
INFO - 2023-05-25 16:23:09 --> Helper loaded: text_helper
INFO - 2023-05-25 16:23:09 --> Helper loaded: form_helper
INFO - 2023-05-25 16:23:09 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:23:09 --> Helper loaded: security_helper
INFO - 2023-05-25 16:23:09 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:23:09 --> Database Driver Class Initialized
INFO - 2023-05-25 16:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:23:09 --> Parser Class Initialized
INFO - 2023-05-25 16:23:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:23:09 --> Pagination Class Initialized
INFO - 2023-05-25 16:23:09 --> Form Validation Class Initialized
INFO - 2023-05-25 16:23:09 --> Controller Class Initialized
INFO - 2023-05-25 16:23:09 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:09 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:09 --> Model Class Initialized
INFO - 2023-05-25 16:23:09 --> Model Class Initialized
INFO - 2023-05-25 16:23:09 --> Model Class Initialized
INFO - 2023-05-25 16:23:09 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 16:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:09 --> Model Class Initialized
INFO - 2023-05-25 16:23:09 --> Model Class Initialized
INFO - 2023-05-25 16:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-25 16:23:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 16:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 16:23:09 --> Model Class Initialized
INFO - 2023-05-25 16:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 16:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 16:23:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 16:23:09 --> Final output sent to browser
DEBUG - 2023-05-25 16:23:09 --> Total execution time: 0.1779
ERROR - 2023-05-25 16:23:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:23:10 --> Config Class Initialized
INFO - 2023-05-25 16:23:10 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:23:10 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:23:10 --> Utf8 Class Initialized
INFO - 2023-05-25 16:23:10 --> URI Class Initialized
INFO - 2023-05-25 16:23:10 --> Router Class Initialized
INFO - 2023-05-25 16:23:10 --> Output Class Initialized
INFO - 2023-05-25 16:23:10 --> Security Class Initialized
DEBUG - 2023-05-25 16:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:23:10 --> Input Class Initialized
INFO - 2023-05-25 16:23:10 --> Language Class Initialized
INFO - 2023-05-25 16:23:10 --> Loader Class Initialized
INFO - 2023-05-25 16:23:10 --> Helper loaded: url_helper
INFO - 2023-05-25 16:23:10 --> Helper loaded: file_helper
INFO - 2023-05-25 16:23:10 --> Helper loaded: html_helper
INFO - 2023-05-25 16:23:10 --> Helper loaded: text_helper
INFO - 2023-05-25 16:23:10 --> Helper loaded: form_helper
INFO - 2023-05-25 16:23:10 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:23:10 --> Helper loaded: security_helper
INFO - 2023-05-25 16:23:10 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:23:10 --> Database Driver Class Initialized
INFO - 2023-05-25 16:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:23:10 --> Parser Class Initialized
INFO - 2023-05-25 16:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:23:10 --> Pagination Class Initialized
INFO - 2023-05-25 16:23:10 --> Form Validation Class Initialized
INFO - 2023-05-25 16:23:10 --> Controller Class Initialized
DEBUG - 2023-05-25 16:23:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 16:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:10 --> Model Class Initialized
INFO - 2023-05-25 16:23:10 --> Final output sent to browser
DEBUG - 2023-05-25 16:23:10 --> Total execution time: 0.0166
ERROR - 2023-05-25 16:23:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:23:22 --> Config Class Initialized
INFO - 2023-05-25 16:23:22 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:23:22 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:23:22 --> Utf8 Class Initialized
INFO - 2023-05-25 16:23:22 --> URI Class Initialized
INFO - 2023-05-25 16:23:22 --> Router Class Initialized
INFO - 2023-05-25 16:23:22 --> Output Class Initialized
INFO - 2023-05-25 16:23:22 --> Security Class Initialized
DEBUG - 2023-05-25 16:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:23:22 --> Input Class Initialized
INFO - 2023-05-25 16:23:22 --> Language Class Initialized
INFO - 2023-05-25 16:23:22 --> Loader Class Initialized
INFO - 2023-05-25 16:23:22 --> Helper loaded: url_helper
INFO - 2023-05-25 16:23:22 --> Helper loaded: file_helper
INFO - 2023-05-25 16:23:22 --> Helper loaded: html_helper
INFO - 2023-05-25 16:23:22 --> Helper loaded: text_helper
INFO - 2023-05-25 16:23:22 --> Helper loaded: form_helper
INFO - 2023-05-25 16:23:22 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:23:22 --> Helper loaded: security_helper
INFO - 2023-05-25 16:23:22 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:23:22 --> Database Driver Class Initialized
INFO - 2023-05-25 16:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:23:22 --> Parser Class Initialized
INFO - 2023-05-25 16:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:23:22 --> Pagination Class Initialized
INFO - 2023-05-25 16:23:22 --> Form Validation Class Initialized
INFO - 2023-05-25 16:23:22 --> Controller Class Initialized
INFO - 2023-05-25 16:23:22 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 16:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:22 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:22 --> Model Class Initialized
INFO - 2023-05-25 16:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-25 16:23:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 16:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 16:23:22 --> Model Class Initialized
INFO - 2023-05-25 16:23:22 --> Model Class Initialized
INFO - 2023-05-25 16:23:22 --> Model Class Initialized
INFO - 2023-05-25 16:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 16:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 16:23:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 16:23:22 --> Final output sent to browser
DEBUG - 2023-05-25 16:23:22 --> Total execution time: 0.1441
ERROR - 2023-05-25 16:23:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:23:23 --> Config Class Initialized
INFO - 2023-05-25 16:23:23 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:23:23 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:23:23 --> Utf8 Class Initialized
INFO - 2023-05-25 16:23:23 --> URI Class Initialized
INFO - 2023-05-25 16:23:23 --> Router Class Initialized
INFO - 2023-05-25 16:23:23 --> Output Class Initialized
INFO - 2023-05-25 16:23:23 --> Security Class Initialized
DEBUG - 2023-05-25 16:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:23:23 --> Input Class Initialized
INFO - 2023-05-25 16:23:23 --> Language Class Initialized
INFO - 2023-05-25 16:23:23 --> Loader Class Initialized
INFO - 2023-05-25 16:23:23 --> Helper loaded: url_helper
INFO - 2023-05-25 16:23:23 --> Helper loaded: file_helper
INFO - 2023-05-25 16:23:23 --> Helper loaded: html_helper
INFO - 2023-05-25 16:23:23 --> Helper loaded: text_helper
INFO - 2023-05-25 16:23:23 --> Helper loaded: form_helper
INFO - 2023-05-25 16:23:23 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:23:23 --> Helper loaded: security_helper
INFO - 2023-05-25 16:23:23 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:23:23 --> Database Driver Class Initialized
INFO - 2023-05-25 16:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:23:23 --> Parser Class Initialized
INFO - 2023-05-25 16:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:23:23 --> Pagination Class Initialized
INFO - 2023-05-25 16:23:23 --> Form Validation Class Initialized
INFO - 2023-05-25 16:23:23 --> Controller Class Initialized
INFO - 2023-05-25 16:23:23 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 16:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:23 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:23 --> Model Class Initialized
INFO - 2023-05-25 16:23:23 --> Final output sent to browser
DEBUG - 2023-05-25 16:23:23 --> Total execution time: 0.0486
ERROR - 2023-05-25 16:23:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:23:38 --> Config Class Initialized
INFO - 2023-05-25 16:23:38 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:23:38 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:23:38 --> Utf8 Class Initialized
INFO - 2023-05-25 16:23:38 --> URI Class Initialized
INFO - 2023-05-25 16:23:38 --> Router Class Initialized
INFO - 2023-05-25 16:23:38 --> Output Class Initialized
INFO - 2023-05-25 16:23:38 --> Security Class Initialized
DEBUG - 2023-05-25 16:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:23:38 --> Input Class Initialized
INFO - 2023-05-25 16:23:38 --> Language Class Initialized
INFO - 2023-05-25 16:23:38 --> Loader Class Initialized
INFO - 2023-05-25 16:23:38 --> Helper loaded: url_helper
INFO - 2023-05-25 16:23:38 --> Helper loaded: file_helper
INFO - 2023-05-25 16:23:38 --> Helper loaded: html_helper
INFO - 2023-05-25 16:23:38 --> Helper loaded: text_helper
INFO - 2023-05-25 16:23:38 --> Helper loaded: form_helper
INFO - 2023-05-25 16:23:38 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:23:38 --> Helper loaded: security_helper
INFO - 2023-05-25 16:23:38 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:23:38 --> Database Driver Class Initialized
INFO - 2023-05-25 16:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:23:39 --> Parser Class Initialized
INFO - 2023-05-25 16:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:23:39 --> Pagination Class Initialized
INFO - 2023-05-25 16:23:39 --> Form Validation Class Initialized
INFO - 2023-05-25 16:23:39 --> Controller Class Initialized
INFO - 2023-05-25 16:23:39 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 16:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:39 --> Model Class Initialized
DEBUG - 2023-05-25 16:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:23:39 --> Model Class Initialized
INFO - 2023-05-25 16:23:39 --> Final output sent to browser
DEBUG - 2023-05-25 16:23:39 --> Total execution time: 0.1476
ERROR - 2023-05-25 16:43:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:43:21 --> Config Class Initialized
INFO - 2023-05-25 16:43:21 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:43:21 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:43:21 --> Utf8 Class Initialized
INFO - 2023-05-25 16:43:21 --> URI Class Initialized
DEBUG - 2023-05-25 16:43:21 --> No URI present. Default controller set.
INFO - 2023-05-25 16:43:21 --> Router Class Initialized
INFO - 2023-05-25 16:43:21 --> Output Class Initialized
INFO - 2023-05-25 16:43:21 --> Security Class Initialized
DEBUG - 2023-05-25 16:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:43:21 --> Input Class Initialized
INFO - 2023-05-25 16:43:21 --> Language Class Initialized
INFO - 2023-05-25 16:43:21 --> Loader Class Initialized
INFO - 2023-05-25 16:43:21 --> Helper loaded: url_helper
INFO - 2023-05-25 16:43:21 --> Helper loaded: file_helper
INFO - 2023-05-25 16:43:21 --> Helper loaded: html_helper
INFO - 2023-05-25 16:43:21 --> Helper loaded: text_helper
INFO - 2023-05-25 16:43:21 --> Helper loaded: form_helper
INFO - 2023-05-25 16:43:21 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:43:21 --> Helper loaded: security_helper
INFO - 2023-05-25 16:43:21 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:43:21 --> Database Driver Class Initialized
INFO - 2023-05-25 16:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:43:21 --> Parser Class Initialized
INFO - 2023-05-25 16:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:43:21 --> Pagination Class Initialized
INFO - 2023-05-25 16:43:21 --> Form Validation Class Initialized
INFO - 2023-05-25 16:43:21 --> Controller Class Initialized
INFO - 2023-05-25 16:43:21 --> Model Class Initialized
DEBUG - 2023-05-25 16:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:43:21 --> Model Class Initialized
DEBUG - 2023-05-25 16:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:43:21 --> Model Class Initialized
INFO - 2023-05-25 16:43:21 --> Model Class Initialized
INFO - 2023-05-25 16:43:21 --> Model Class Initialized
INFO - 2023-05-25 16:43:21 --> Model Class Initialized
DEBUG - 2023-05-25 16:43:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 16:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:43:21 --> Model Class Initialized
INFO - 2023-05-25 16:43:21 --> Model Class Initialized
INFO - 2023-05-25 16:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-25 16:43:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 16:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 16:43:21 --> Model Class Initialized
INFO - 2023-05-25 16:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 16:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 16:43:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 16:43:22 --> Final output sent to browser
DEBUG - 2023-05-25 16:43:22 --> Total execution time: 0.1700
ERROR - 2023-05-25 16:44:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:44:07 --> Config Class Initialized
INFO - 2023-05-25 16:44:07 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:44:07 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:44:07 --> Utf8 Class Initialized
INFO - 2023-05-25 16:44:07 --> URI Class Initialized
INFO - 2023-05-25 16:44:07 --> Router Class Initialized
INFO - 2023-05-25 16:44:07 --> Output Class Initialized
INFO - 2023-05-25 16:44:07 --> Security Class Initialized
DEBUG - 2023-05-25 16:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:44:07 --> Input Class Initialized
INFO - 2023-05-25 16:44:07 --> Language Class Initialized
INFO - 2023-05-25 16:44:07 --> Loader Class Initialized
INFO - 2023-05-25 16:44:07 --> Helper loaded: url_helper
INFO - 2023-05-25 16:44:07 --> Helper loaded: file_helper
INFO - 2023-05-25 16:44:07 --> Helper loaded: html_helper
INFO - 2023-05-25 16:44:07 --> Helper loaded: text_helper
INFO - 2023-05-25 16:44:07 --> Helper loaded: form_helper
INFO - 2023-05-25 16:44:07 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:44:07 --> Helper loaded: security_helper
INFO - 2023-05-25 16:44:07 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:44:07 --> Database Driver Class Initialized
INFO - 2023-05-25 16:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:44:07 --> Parser Class Initialized
INFO - 2023-05-25 16:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:44:07 --> Pagination Class Initialized
INFO - 2023-05-25 16:44:07 --> Form Validation Class Initialized
INFO - 2023-05-25 16:44:07 --> Controller Class Initialized
INFO - 2023-05-25 16:44:07 --> Model Class Initialized
DEBUG - 2023-05-25 16:44:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 16:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:44:07 --> Model Class Initialized
DEBUG - 2023-05-25 16:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:44:07 --> Model Class Initialized
INFO - 2023-05-25 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-25 16:44:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 16:44:07 --> Model Class Initialized
INFO - 2023-05-25 16:44:07 --> Model Class Initialized
INFO - 2023-05-25 16:44:07 --> Model Class Initialized
INFO - 2023-05-25 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 16:44:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 16:44:07 --> Final output sent to browser
DEBUG - 2023-05-25 16:44:07 --> Total execution time: 0.1423
ERROR - 2023-05-25 16:44:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 16:44:08 --> Config Class Initialized
INFO - 2023-05-25 16:44:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 16:44:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 16:44:08 --> Utf8 Class Initialized
INFO - 2023-05-25 16:44:08 --> URI Class Initialized
INFO - 2023-05-25 16:44:08 --> Router Class Initialized
INFO - 2023-05-25 16:44:08 --> Output Class Initialized
INFO - 2023-05-25 16:44:08 --> Security Class Initialized
DEBUG - 2023-05-25 16:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 16:44:08 --> Input Class Initialized
INFO - 2023-05-25 16:44:08 --> Language Class Initialized
INFO - 2023-05-25 16:44:08 --> Loader Class Initialized
INFO - 2023-05-25 16:44:08 --> Helper loaded: url_helper
INFO - 2023-05-25 16:44:08 --> Helper loaded: file_helper
INFO - 2023-05-25 16:44:08 --> Helper loaded: html_helper
INFO - 2023-05-25 16:44:08 --> Helper loaded: text_helper
INFO - 2023-05-25 16:44:08 --> Helper loaded: form_helper
INFO - 2023-05-25 16:44:08 --> Helper loaded: lang_helper
INFO - 2023-05-25 16:44:08 --> Helper loaded: security_helper
INFO - 2023-05-25 16:44:08 --> Helper loaded: cookie_helper
INFO - 2023-05-25 16:44:08 --> Database Driver Class Initialized
INFO - 2023-05-25 16:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 16:44:08 --> Parser Class Initialized
INFO - 2023-05-25 16:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 16:44:08 --> Pagination Class Initialized
INFO - 2023-05-25 16:44:08 --> Form Validation Class Initialized
INFO - 2023-05-25 16:44:08 --> Controller Class Initialized
INFO - 2023-05-25 16:44:08 --> Model Class Initialized
DEBUG - 2023-05-25 16:44:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 16:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:44:08 --> Model Class Initialized
DEBUG - 2023-05-25 16:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 16:44:08 --> Model Class Initialized
INFO - 2023-05-25 16:44:08 --> Final output sent to browser
DEBUG - 2023-05-25 16:44:08 --> Total execution time: 0.0523
ERROR - 2023-05-25 17:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 17:16:31 --> Config Class Initialized
INFO - 2023-05-25 17:16:31 --> Hooks Class Initialized
DEBUG - 2023-05-25 17:16:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 17:16:31 --> Utf8 Class Initialized
INFO - 2023-05-25 17:16:31 --> URI Class Initialized
DEBUG - 2023-05-25 17:16:31 --> No URI present. Default controller set.
INFO - 2023-05-25 17:16:31 --> Router Class Initialized
INFO - 2023-05-25 17:16:31 --> Output Class Initialized
INFO - 2023-05-25 17:16:31 --> Security Class Initialized
DEBUG - 2023-05-25 17:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 17:16:31 --> Input Class Initialized
INFO - 2023-05-25 17:16:31 --> Language Class Initialized
INFO - 2023-05-25 17:16:31 --> Loader Class Initialized
INFO - 2023-05-25 17:16:31 --> Helper loaded: url_helper
INFO - 2023-05-25 17:16:31 --> Helper loaded: file_helper
INFO - 2023-05-25 17:16:31 --> Helper loaded: html_helper
INFO - 2023-05-25 17:16:31 --> Helper loaded: text_helper
INFO - 2023-05-25 17:16:31 --> Helper loaded: form_helper
INFO - 2023-05-25 17:16:31 --> Helper loaded: lang_helper
INFO - 2023-05-25 17:16:31 --> Helper loaded: security_helper
INFO - 2023-05-25 17:16:31 --> Helper loaded: cookie_helper
INFO - 2023-05-25 17:16:31 --> Database Driver Class Initialized
INFO - 2023-05-25 17:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 17:16:31 --> Parser Class Initialized
INFO - 2023-05-25 17:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 17:16:31 --> Pagination Class Initialized
INFO - 2023-05-25 17:16:31 --> Form Validation Class Initialized
INFO - 2023-05-25 17:16:31 --> Controller Class Initialized
INFO - 2023-05-25 17:16:31 --> Model Class Initialized
DEBUG - 2023-05-25 17:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:31 --> Model Class Initialized
DEBUG - 2023-05-25 17:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:31 --> Model Class Initialized
INFO - 2023-05-25 17:16:31 --> Model Class Initialized
INFO - 2023-05-25 17:16:31 --> Model Class Initialized
INFO - 2023-05-25 17:16:31 --> Model Class Initialized
DEBUG - 2023-05-25 17:16:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 17:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:31 --> Model Class Initialized
INFO - 2023-05-25 17:16:31 --> Model Class Initialized
INFO - 2023-05-25 17:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-25 17:16:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 17:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 17:16:31 --> Model Class Initialized
INFO - 2023-05-25 17:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 17:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 17:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 17:16:31 --> Final output sent to browser
DEBUG - 2023-05-25 17:16:31 --> Total execution time: 0.1762
ERROR - 2023-05-25 17:16:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 17:16:44 --> Config Class Initialized
INFO - 2023-05-25 17:16:44 --> Hooks Class Initialized
DEBUG - 2023-05-25 17:16:44 --> UTF-8 Support Enabled
INFO - 2023-05-25 17:16:44 --> Utf8 Class Initialized
INFO - 2023-05-25 17:16:44 --> URI Class Initialized
INFO - 2023-05-25 17:16:44 --> Router Class Initialized
INFO - 2023-05-25 17:16:44 --> Output Class Initialized
INFO - 2023-05-25 17:16:44 --> Security Class Initialized
DEBUG - 2023-05-25 17:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 17:16:44 --> Input Class Initialized
INFO - 2023-05-25 17:16:44 --> Language Class Initialized
INFO - 2023-05-25 17:16:44 --> Loader Class Initialized
INFO - 2023-05-25 17:16:44 --> Helper loaded: url_helper
INFO - 2023-05-25 17:16:44 --> Helper loaded: file_helper
INFO - 2023-05-25 17:16:44 --> Helper loaded: html_helper
INFO - 2023-05-25 17:16:44 --> Helper loaded: text_helper
INFO - 2023-05-25 17:16:44 --> Helper loaded: form_helper
INFO - 2023-05-25 17:16:44 --> Helper loaded: lang_helper
INFO - 2023-05-25 17:16:44 --> Helper loaded: security_helper
INFO - 2023-05-25 17:16:44 --> Helper loaded: cookie_helper
INFO - 2023-05-25 17:16:44 --> Database Driver Class Initialized
INFO - 2023-05-25 17:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 17:16:44 --> Parser Class Initialized
INFO - 2023-05-25 17:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 17:16:44 --> Pagination Class Initialized
INFO - 2023-05-25 17:16:44 --> Form Validation Class Initialized
INFO - 2023-05-25 17:16:44 --> Controller Class Initialized
DEBUG - 2023-05-25 17:16:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 17:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:44 --> Model Class Initialized
DEBUG - 2023-05-25 17:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:44 --> Model Class Initialized
DEBUG - 2023-05-25 17:16:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:44 --> Model Class Initialized
INFO - 2023-05-25 17:16:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-25 17:16:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-25 17:16:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-25 17:16:44 --> Model Class Initialized
INFO - 2023-05-25 17:16:44 --> Model Class Initialized
INFO - 2023-05-25 17:16:44 --> Model Class Initialized
INFO - 2023-05-25 17:16:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-25 17:16:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-25 17:16:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-25 17:16:44 --> Final output sent to browser
DEBUG - 2023-05-25 17:16:44 --> Total execution time: 0.1468
ERROR - 2023-05-25 17:16:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 17:16:46 --> Config Class Initialized
INFO - 2023-05-25 17:16:46 --> Hooks Class Initialized
DEBUG - 2023-05-25 17:16:46 --> UTF-8 Support Enabled
INFO - 2023-05-25 17:16:46 --> Utf8 Class Initialized
INFO - 2023-05-25 17:16:46 --> URI Class Initialized
INFO - 2023-05-25 17:16:46 --> Router Class Initialized
INFO - 2023-05-25 17:16:46 --> Output Class Initialized
INFO - 2023-05-25 17:16:46 --> Security Class Initialized
DEBUG - 2023-05-25 17:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 17:16:46 --> Input Class Initialized
INFO - 2023-05-25 17:16:46 --> Language Class Initialized
INFO - 2023-05-25 17:16:46 --> Loader Class Initialized
INFO - 2023-05-25 17:16:46 --> Helper loaded: url_helper
INFO - 2023-05-25 17:16:46 --> Helper loaded: file_helper
INFO - 2023-05-25 17:16:46 --> Helper loaded: html_helper
INFO - 2023-05-25 17:16:46 --> Helper loaded: text_helper
INFO - 2023-05-25 17:16:46 --> Helper loaded: form_helper
INFO - 2023-05-25 17:16:46 --> Helper loaded: lang_helper
INFO - 2023-05-25 17:16:46 --> Helper loaded: security_helper
INFO - 2023-05-25 17:16:46 --> Helper loaded: cookie_helper
INFO - 2023-05-25 17:16:46 --> Database Driver Class Initialized
INFO - 2023-05-25 17:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 17:16:46 --> Parser Class Initialized
INFO - 2023-05-25 17:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 17:16:46 --> Pagination Class Initialized
INFO - 2023-05-25 17:16:46 --> Form Validation Class Initialized
INFO - 2023-05-25 17:16:46 --> Controller Class Initialized
DEBUG - 2023-05-25 17:16:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 17:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:46 --> Model Class Initialized
DEBUG - 2023-05-25 17:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:46 --> Model Class Initialized
INFO - 2023-05-25 17:16:46 --> Final output sent to browser
DEBUG - 2023-05-25 17:16:46 --> Total execution time: 0.0339
ERROR - 2023-05-25 17:16:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-25 17:16:51 --> Config Class Initialized
INFO - 2023-05-25 17:16:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 17:16:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 17:16:51 --> Utf8 Class Initialized
INFO - 2023-05-25 17:16:51 --> URI Class Initialized
INFO - 2023-05-25 17:16:51 --> Router Class Initialized
INFO - 2023-05-25 17:16:51 --> Output Class Initialized
INFO - 2023-05-25 17:16:51 --> Security Class Initialized
DEBUG - 2023-05-25 17:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 17:16:51 --> Input Class Initialized
INFO - 2023-05-25 17:16:51 --> Language Class Initialized
INFO - 2023-05-25 17:16:51 --> Loader Class Initialized
INFO - 2023-05-25 17:16:51 --> Helper loaded: url_helper
INFO - 2023-05-25 17:16:51 --> Helper loaded: file_helper
INFO - 2023-05-25 17:16:51 --> Helper loaded: html_helper
INFO - 2023-05-25 17:16:51 --> Helper loaded: text_helper
INFO - 2023-05-25 17:16:51 --> Helper loaded: form_helper
INFO - 2023-05-25 17:16:51 --> Helper loaded: lang_helper
INFO - 2023-05-25 17:16:51 --> Helper loaded: security_helper
INFO - 2023-05-25 17:16:51 --> Helper loaded: cookie_helper
INFO - 2023-05-25 17:16:51 --> Database Driver Class Initialized
INFO - 2023-05-25 17:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-25 17:16:51 --> Parser Class Initialized
INFO - 2023-05-25 17:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-25 17:16:51 --> Pagination Class Initialized
INFO - 2023-05-25 17:16:51 --> Form Validation Class Initialized
INFO - 2023-05-25 17:16:51 --> Controller Class Initialized
DEBUG - 2023-05-25 17:16:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-25 17:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:51 --> Model Class Initialized
DEBUG - 2023-05-25 17:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-25 17:16:51 --> Model Class Initialized
INFO - 2023-05-25 17:16:51 --> Final output sent to browser
DEBUG - 2023-05-25 17:16:51 --> Total execution time: 0.0980
