<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-11 01:51:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 01:51:03 --> Config Class Initialized
INFO - 2023-08-11 01:51:03 --> Hooks Class Initialized
DEBUG - 2023-08-11 01:51:03 --> UTF-8 Support Enabled
INFO - 2023-08-11 01:51:03 --> Utf8 Class Initialized
INFO - 2023-08-11 01:51:03 --> URI Class Initialized
DEBUG - 2023-08-11 01:51:03 --> No URI present. Default controller set.
INFO - 2023-08-11 01:51:03 --> Router Class Initialized
INFO - 2023-08-11 01:51:03 --> Output Class Initialized
INFO - 2023-08-11 01:51:03 --> Security Class Initialized
DEBUG - 2023-08-11 01:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 01:51:03 --> Input Class Initialized
INFO - 2023-08-11 01:51:03 --> Language Class Initialized
INFO - 2023-08-11 01:51:03 --> Loader Class Initialized
INFO - 2023-08-11 01:51:03 --> Helper loaded: url_helper
INFO - 2023-08-11 01:51:03 --> Helper loaded: file_helper
INFO - 2023-08-11 01:51:03 --> Helper loaded: html_helper
INFO - 2023-08-11 01:51:03 --> Helper loaded: text_helper
INFO - 2023-08-11 01:51:03 --> Helper loaded: form_helper
INFO - 2023-08-11 01:51:03 --> Helper loaded: lang_helper
INFO - 2023-08-11 01:51:03 --> Helper loaded: security_helper
INFO - 2023-08-11 01:51:03 --> Helper loaded: cookie_helper
INFO - 2023-08-11 01:51:03 --> Database Driver Class Initialized
INFO - 2023-08-11 01:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 01:51:03 --> Parser Class Initialized
INFO - 2023-08-11 01:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 01:51:03 --> Pagination Class Initialized
INFO - 2023-08-11 01:51:03 --> Form Validation Class Initialized
INFO - 2023-08-11 01:51:03 --> Controller Class Initialized
INFO - 2023-08-11 01:51:03 --> Model Class Initialized
DEBUG - 2023-08-11 01:51:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 01:51:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 01:51:04 --> Config Class Initialized
INFO - 2023-08-11 01:51:04 --> Hooks Class Initialized
DEBUG - 2023-08-11 01:51:04 --> UTF-8 Support Enabled
INFO - 2023-08-11 01:51:04 --> Utf8 Class Initialized
INFO - 2023-08-11 01:51:04 --> URI Class Initialized
INFO - 2023-08-11 01:51:04 --> Router Class Initialized
INFO - 2023-08-11 01:51:04 --> Output Class Initialized
INFO - 2023-08-11 01:51:04 --> Security Class Initialized
DEBUG - 2023-08-11 01:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 01:51:04 --> Input Class Initialized
INFO - 2023-08-11 01:51:04 --> Language Class Initialized
INFO - 2023-08-11 01:51:04 --> Loader Class Initialized
INFO - 2023-08-11 01:51:04 --> Helper loaded: url_helper
INFO - 2023-08-11 01:51:04 --> Helper loaded: file_helper
INFO - 2023-08-11 01:51:04 --> Helper loaded: html_helper
INFO - 2023-08-11 01:51:04 --> Helper loaded: text_helper
INFO - 2023-08-11 01:51:04 --> Helper loaded: form_helper
INFO - 2023-08-11 01:51:04 --> Helper loaded: lang_helper
INFO - 2023-08-11 01:51:04 --> Helper loaded: security_helper
INFO - 2023-08-11 01:51:04 --> Helper loaded: cookie_helper
INFO - 2023-08-11 01:51:04 --> Database Driver Class Initialized
INFO - 2023-08-11 01:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 01:51:04 --> Parser Class Initialized
INFO - 2023-08-11 01:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 01:51:04 --> Pagination Class Initialized
INFO - 2023-08-11 01:51:04 --> Form Validation Class Initialized
INFO - 2023-08-11 01:51:04 --> Controller Class Initialized
INFO - 2023-08-11 01:51:04 --> Model Class Initialized
DEBUG - 2023-08-11 01:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 01:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 01:51:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 01:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 01:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 01:51:04 --> Model Class Initialized
INFO - 2023-08-11 01:51:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 01:51:04 --> Final output sent to browser
DEBUG - 2023-08-11 01:51:04 --> Total execution time: 0.0383
ERROR - 2023-08-11 03:07:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:06 --> Config Class Initialized
INFO - 2023-08-11 03:07:06 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:06 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:06 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:06 --> URI Class Initialized
DEBUG - 2023-08-11 03:07:06 --> No URI present. Default controller set.
INFO - 2023-08-11 03:07:06 --> Router Class Initialized
INFO - 2023-08-11 03:07:06 --> Output Class Initialized
INFO - 2023-08-11 03:07:06 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:06 --> Input Class Initialized
INFO - 2023-08-11 03:07:06 --> Language Class Initialized
INFO - 2023-08-11 03:07:06 --> Loader Class Initialized
INFO - 2023-08-11 03:07:06 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:06 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:06 --> Parser Class Initialized
INFO - 2023-08-11 03:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:06 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:06 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:06 --> Controller Class Initialized
INFO - 2023-08-11 03:07:06 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 03:07:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:06 --> Config Class Initialized
INFO - 2023-08-11 03:07:06 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:06 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:06 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:06 --> URI Class Initialized
INFO - 2023-08-11 03:07:06 --> Router Class Initialized
INFO - 2023-08-11 03:07:06 --> Output Class Initialized
INFO - 2023-08-11 03:07:06 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:06 --> Input Class Initialized
INFO - 2023-08-11 03:07:06 --> Language Class Initialized
INFO - 2023-08-11 03:07:06 --> Loader Class Initialized
INFO - 2023-08-11 03:07:06 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:06 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:06 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:06 --> Parser Class Initialized
INFO - 2023-08-11 03:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:06 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:06 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:06 --> Controller Class Initialized
INFO - 2023-08-11 03:07:06 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 03:07:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 03:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 03:07:06 --> Model Class Initialized
INFO - 2023-08-11 03:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 03:07:06 --> Final output sent to browser
DEBUG - 2023-08-11 03:07:06 --> Total execution time: 0.0306
ERROR - 2023-08-11 03:07:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:26 --> Config Class Initialized
INFO - 2023-08-11 03:07:26 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:26 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:26 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:26 --> URI Class Initialized
INFO - 2023-08-11 03:07:26 --> Router Class Initialized
INFO - 2023-08-11 03:07:26 --> Output Class Initialized
INFO - 2023-08-11 03:07:26 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:26 --> Input Class Initialized
INFO - 2023-08-11 03:07:26 --> Language Class Initialized
INFO - 2023-08-11 03:07:26 --> Loader Class Initialized
INFO - 2023-08-11 03:07:26 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:26 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:26 --> Parser Class Initialized
INFO - 2023-08-11 03:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:26 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:26 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:26 --> Controller Class Initialized
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
INFO - 2023-08-11 03:07:26 --> Final output sent to browser
DEBUG - 2023-08-11 03:07:26 --> Total execution time: 0.0213
ERROR - 2023-08-11 03:07:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:26 --> Config Class Initialized
INFO - 2023-08-11 03:07:26 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:26 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:26 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:26 --> URI Class Initialized
DEBUG - 2023-08-11 03:07:26 --> No URI present. Default controller set.
INFO - 2023-08-11 03:07:26 --> Router Class Initialized
INFO - 2023-08-11 03:07:26 --> Output Class Initialized
INFO - 2023-08-11 03:07:26 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:26 --> Input Class Initialized
INFO - 2023-08-11 03:07:26 --> Language Class Initialized
INFO - 2023-08-11 03:07:26 --> Loader Class Initialized
INFO - 2023-08-11 03:07:26 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:26 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:26 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:26 --> Parser Class Initialized
INFO - 2023-08-11 03:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:26 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:26 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:26 --> Controller Class Initialized
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
INFO - 2023-08-11 03:07:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 03:07:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 03:07:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 03:07:26 --> Model Class Initialized
INFO - 2023-08-11 03:07:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 03:07:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 03:07:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 03:07:26 --> Final output sent to browser
DEBUG - 2023-08-11 03:07:26 --> Total execution time: 0.0966
ERROR - 2023-08-11 03:07:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:29 --> Config Class Initialized
INFO - 2023-08-11 03:07:29 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:29 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:29 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:29 --> URI Class Initialized
INFO - 2023-08-11 03:07:29 --> Router Class Initialized
INFO - 2023-08-11 03:07:29 --> Output Class Initialized
INFO - 2023-08-11 03:07:29 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:29 --> Input Class Initialized
INFO - 2023-08-11 03:07:29 --> Language Class Initialized
INFO - 2023-08-11 03:07:29 --> Loader Class Initialized
INFO - 2023-08-11 03:07:29 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:29 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:29 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:29 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:29 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:29 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:29 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:29 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:29 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:29 --> Parser Class Initialized
INFO - 2023-08-11 03:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:29 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:29 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:29 --> Controller Class Initialized
INFO - 2023-08-11 03:07:29 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:29 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:29 --> Model Class Initialized
INFO - 2023-08-11 03:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-11 03:07:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 03:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 03:07:29 --> Model Class Initialized
INFO - 2023-08-11 03:07:29 --> Model Class Initialized
INFO - 2023-08-11 03:07:29 --> Model Class Initialized
INFO - 2023-08-11 03:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 03:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 03:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 03:07:29 --> Final output sent to browser
DEBUG - 2023-08-11 03:07:29 --> Total execution time: 0.0787
ERROR - 2023-08-11 03:07:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:30 --> Config Class Initialized
INFO - 2023-08-11 03:07:30 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:30 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:30 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:30 --> URI Class Initialized
INFO - 2023-08-11 03:07:30 --> Router Class Initialized
INFO - 2023-08-11 03:07:30 --> Output Class Initialized
INFO - 2023-08-11 03:07:30 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:30 --> Input Class Initialized
INFO - 2023-08-11 03:07:30 --> Language Class Initialized
INFO - 2023-08-11 03:07:30 --> Loader Class Initialized
INFO - 2023-08-11 03:07:30 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:30 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:30 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:30 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:30 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:30 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:30 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:30 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:30 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:30 --> Parser Class Initialized
INFO - 2023-08-11 03:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:30 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:30 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:30 --> Controller Class Initialized
INFO - 2023-08-11 03:07:30 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:30 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:30 --> Model Class Initialized
INFO - 2023-08-11 03:07:30 --> Final output sent to browser
DEBUG - 2023-08-11 03:07:30 --> Total execution time: 0.0375
ERROR - 2023-08-11 03:07:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:35 --> Config Class Initialized
INFO - 2023-08-11 03:07:35 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:35 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:35 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:35 --> URI Class Initialized
INFO - 2023-08-11 03:07:35 --> Router Class Initialized
INFO - 2023-08-11 03:07:35 --> Output Class Initialized
INFO - 2023-08-11 03:07:35 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:35 --> Input Class Initialized
INFO - 2023-08-11 03:07:35 --> Language Class Initialized
INFO - 2023-08-11 03:07:35 --> Loader Class Initialized
INFO - 2023-08-11 03:07:35 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:35 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:35 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:35 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:35 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:35 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:35 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:35 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:35 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:35 --> Parser Class Initialized
INFO - 2023-08-11 03:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:35 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:35 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:35 --> Controller Class Initialized
INFO - 2023-08-11 03:07:35 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:35 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:35 --> Model Class Initialized
INFO - 2023-08-11 03:07:35 --> Final output sent to browser
DEBUG - 2023-08-11 03:07:35 --> Total execution time: 0.0359
ERROR - 2023-08-11 03:07:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:43 --> Config Class Initialized
INFO - 2023-08-11 03:07:43 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:43 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:43 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:43 --> URI Class Initialized
INFO - 2023-08-11 03:07:43 --> Router Class Initialized
INFO - 2023-08-11 03:07:43 --> Output Class Initialized
INFO - 2023-08-11 03:07:43 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:43 --> Input Class Initialized
INFO - 2023-08-11 03:07:43 --> Language Class Initialized
INFO - 2023-08-11 03:07:43 --> Loader Class Initialized
INFO - 2023-08-11 03:07:43 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:43 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:43 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:43 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:43 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:43 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:43 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:43 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:43 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:43 --> Parser Class Initialized
INFO - 2023-08-11 03:07:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:43 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:43 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:43 --> Controller Class Initialized
INFO - 2023-08-11 03:07:43 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:43 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:43 --> Model Class Initialized
INFO - 2023-08-11 03:07:43 --> Final output sent to browser
DEBUG - 2023-08-11 03:07:43 --> Total execution time: 0.0357
ERROR - 2023-08-11 03:07:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:58 --> Config Class Initialized
INFO - 2023-08-11 03:07:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:58 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:58 --> URI Class Initialized
INFO - 2023-08-11 03:07:58 --> Router Class Initialized
INFO - 2023-08-11 03:07:58 --> Output Class Initialized
INFO - 2023-08-11 03:07:58 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:58 --> Input Class Initialized
INFO - 2023-08-11 03:07:58 --> Language Class Initialized
INFO - 2023-08-11 03:07:58 --> Loader Class Initialized
INFO - 2023-08-11 03:07:58 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:58 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:58 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:58 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:58 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:58 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:58 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:58 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:58 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:58 --> Parser Class Initialized
INFO - 2023-08-11 03:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:58 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:58 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:58 --> Controller Class Initialized
INFO - 2023-08-11 03:07:58 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:58 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:58 --> Model Class Initialized
INFO - 2023-08-11 03:07:58 --> Final output sent to browser
DEBUG - 2023-08-11 03:07:58 --> Total execution time: 0.0394
ERROR - 2023-08-11 03:07:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:07:59 --> Config Class Initialized
INFO - 2023-08-11 03:07:59 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:07:59 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:07:59 --> Utf8 Class Initialized
INFO - 2023-08-11 03:07:59 --> URI Class Initialized
INFO - 2023-08-11 03:07:59 --> Router Class Initialized
INFO - 2023-08-11 03:07:59 --> Output Class Initialized
INFO - 2023-08-11 03:07:59 --> Security Class Initialized
DEBUG - 2023-08-11 03:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:07:59 --> Input Class Initialized
INFO - 2023-08-11 03:07:59 --> Language Class Initialized
INFO - 2023-08-11 03:07:59 --> Loader Class Initialized
INFO - 2023-08-11 03:07:59 --> Helper loaded: url_helper
INFO - 2023-08-11 03:07:59 --> Helper loaded: file_helper
INFO - 2023-08-11 03:07:59 --> Helper loaded: html_helper
INFO - 2023-08-11 03:07:59 --> Helper loaded: text_helper
INFO - 2023-08-11 03:07:59 --> Helper loaded: form_helper
INFO - 2023-08-11 03:07:59 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:07:59 --> Helper loaded: security_helper
INFO - 2023-08-11 03:07:59 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:07:59 --> Database Driver Class Initialized
INFO - 2023-08-11 03:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:07:59 --> Parser Class Initialized
INFO - 2023-08-11 03:07:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:07:59 --> Pagination Class Initialized
INFO - 2023-08-11 03:07:59 --> Form Validation Class Initialized
INFO - 2023-08-11 03:07:59 --> Controller Class Initialized
INFO - 2023-08-11 03:07:59 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:07:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:59 --> Model Class Initialized
DEBUG - 2023-08-11 03:07:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:07:59 --> Model Class Initialized
INFO - 2023-08-11 03:07:59 --> Final output sent to browser
DEBUG - 2023-08-11 03:07:59 --> Total execution time: 0.0364
ERROR - 2023-08-11 03:08:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:08:00 --> Config Class Initialized
INFO - 2023-08-11 03:08:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:08:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:08:00 --> Utf8 Class Initialized
INFO - 2023-08-11 03:08:00 --> URI Class Initialized
INFO - 2023-08-11 03:08:00 --> Router Class Initialized
INFO - 2023-08-11 03:08:00 --> Output Class Initialized
INFO - 2023-08-11 03:08:00 --> Security Class Initialized
DEBUG - 2023-08-11 03:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:08:00 --> Input Class Initialized
INFO - 2023-08-11 03:08:00 --> Language Class Initialized
INFO - 2023-08-11 03:08:00 --> Loader Class Initialized
INFO - 2023-08-11 03:08:00 --> Helper loaded: url_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: file_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: html_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: text_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: form_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: security_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:08:00 --> Database Driver Class Initialized
INFO - 2023-08-11 03:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:08:00 --> Parser Class Initialized
INFO - 2023-08-11 03:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:08:00 --> Pagination Class Initialized
INFO - 2023-08-11 03:08:00 --> Form Validation Class Initialized
INFO - 2023-08-11 03:08:00 --> Controller Class Initialized
INFO - 2023-08-11 03:08:00 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:00 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:00 --> Model Class Initialized
INFO - 2023-08-11 03:08:00 --> Final output sent to browser
DEBUG - 2023-08-11 03:08:00 --> Total execution time: 0.0364
ERROR - 2023-08-11 03:08:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:08:00 --> Config Class Initialized
INFO - 2023-08-11 03:08:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:08:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:08:00 --> Utf8 Class Initialized
INFO - 2023-08-11 03:08:00 --> URI Class Initialized
INFO - 2023-08-11 03:08:00 --> Router Class Initialized
INFO - 2023-08-11 03:08:00 --> Output Class Initialized
INFO - 2023-08-11 03:08:00 --> Security Class Initialized
DEBUG - 2023-08-11 03:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:08:00 --> Input Class Initialized
INFO - 2023-08-11 03:08:00 --> Language Class Initialized
INFO - 2023-08-11 03:08:00 --> Loader Class Initialized
INFO - 2023-08-11 03:08:00 --> Helper loaded: url_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: file_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: html_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: text_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: form_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: security_helper
INFO - 2023-08-11 03:08:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:08:00 --> Database Driver Class Initialized
INFO - 2023-08-11 03:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:08:00 --> Parser Class Initialized
INFO - 2023-08-11 03:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:08:00 --> Pagination Class Initialized
INFO - 2023-08-11 03:08:00 --> Form Validation Class Initialized
INFO - 2023-08-11 03:08:00 --> Controller Class Initialized
INFO - 2023-08-11 03:08:00 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:00 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:00 --> Model Class Initialized
INFO - 2023-08-11 03:08:00 --> Final output sent to browser
DEBUG - 2023-08-11 03:08:00 --> Total execution time: 0.0284
ERROR - 2023-08-11 03:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:08:01 --> Config Class Initialized
INFO - 2023-08-11 03:08:01 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:08:01 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:08:01 --> Utf8 Class Initialized
INFO - 2023-08-11 03:08:01 --> URI Class Initialized
INFO - 2023-08-11 03:08:01 --> Router Class Initialized
INFO - 2023-08-11 03:08:01 --> Output Class Initialized
INFO - 2023-08-11 03:08:01 --> Security Class Initialized
DEBUG - 2023-08-11 03:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:08:01 --> Input Class Initialized
INFO - 2023-08-11 03:08:01 --> Language Class Initialized
INFO - 2023-08-11 03:08:01 --> Loader Class Initialized
INFO - 2023-08-11 03:08:01 --> Helper loaded: url_helper
INFO - 2023-08-11 03:08:01 --> Helper loaded: file_helper
INFO - 2023-08-11 03:08:01 --> Helper loaded: html_helper
INFO - 2023-08-11 03:08:01 --> Helper loaded: text_helper
INFO - 2023-08-11 03:08:01 --> Helper loaded: form_helper
INFO - 2023-08-11 03:08:01 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:08:01 --> Helper loaded: security_helper
INFO - 2023-08-11 03:08:01 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:08:01 --> Database Driver Class Initialized
INFO - 2023-08-11 03:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:08:01 --> Parser Class Initialized
INFO - 2023-08-11 03:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:08:01 --> Pagination Class Initialized
INFO - 2023-08-11 03:08:01 --> Form Validation Class Initialized
INFO - 2023-08-11 03:08:01 --> Controller Class Initialized
INFO - 2023-08-11 03:08:01 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:01 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:01 --> Model Class Initialized
INFO - 2023-08-11 03:08:01 --> Final output sent to browser
DEBUG - 2023-08-11 03:08:01 --> Total execution time: 0.0231
ERROR - 2023-08-11 03:08:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:08:03 --> Config Class Initialized
INFO - 2023-08-11 03:08:03 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:08:03 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:08:03 --> Utf8 Class Initialized
INFO - 2023-08-11 03:08:03 --> URI Class Initialized
INFO - 2023-08-11 03:08:03 --> Router Class Initialized
INFO - 2023-08-11 03:08:03 --> Output Class Initialized
INFO - 2023-08-11 03:08:03 --> Security Class Initialized
DEBUG - 2023-08-11 03:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:08:03 --> Input Class Initialized
INFO - 2023-08-11 03:08:03 --> Language Class Initialized
INFO - 2023-08-11 03:08:03 --> Loader Class Initialized
INFO - 2023-08-11 03:08:03 --> Helper loaded: url_helper
INFO - 2023-08-11 03:08:03 --> Helper loaded: file_helper
INFO - 2023-08-11 03:08:03 --> Helper loaded: html_helper
INFO - 2023-08-11 03:08:03 --> Helper loaded: text_helper
INFO - 2023-08-11 03:08:03 --> Helper loaded: form_helper
INFO - 2023-08-11 03:08:03 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:08:03 --> Helper loaded: security_helper
INFO - 2023-08-11 03:08:03 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:08:03 --> Database Driver Class Initialized
INFO - 2023-08-11 03:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:08:03 --> Parser Class Initialized
INFO - 2023-08-11 03:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:08:03 --> Pagination Class Initialized
INFO - 2023-08-11 03:08:03 --> Form Validation Class Initialized
INFO - 2023-08-11 03:08:03 --> Controller Class Initialized
INFO - 2023-08-11 03:08:03 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:03 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:03 --> Model Class Initialized
INFO - 2023-08-11 03:08:03 --> Final output sent to browser
DEBUG - 2023-08-11 03:08:03 --> Total execution time: 0.0212
ERROR - 2023-08-11 03:08:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:08:07 --> Config Class Initialized
INFO - 2023-08-11 03:08:07 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:08:07 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:08:07 --> Utf8 Class Initialized
INFO - 2023-08-11 03:08:07 --> URI Class Initialized
DEBUG - 2023-08-11 03:08:07 --> No URI present. Default controller set.
INFO - 2023-08-11 03:08:07 --> Router Class Initialized
INFO - 2023-08-11 03:08:07 --> Output Class Initialized
INFO - 2023-08-11 03:08:07 --> Security Class Initialized
DEBUG - 2023-08-11 03:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:08:07 --> Input Class Initialized
INFO - 2023-08-11 03:08:07 --> Language Class Initialized
INFO - 2023-08-11 03:08:07 --> Loader Class Initialized
INFO - 2023-08-11 03:08:07 --> Helper loaded: url_helper
INFO - 2023-08-11 03:08:07 --> Helper loaded: file_helper
INFO - 2023-08-11 03:08:07 --> Helper loaded: html_helper
INFO - 2023-08-11 03:08:07 --> Helper loaded: text_helper
INFO - 2023-08-11 03:08:07 --> Helper loaded: form_helper
INFO - 2023-08-11 03:08:07 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:08:07 --> Helper loaded: security_helper
INFO - 2023-08-11 03:08:07 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:08:07 --> Database Driver Class Initialized
INFO - 2023-08-11 03:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:08:07 --> Parser Class Initialized
INFO - 2023-08-11 03:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:08:07 --> Pagination Class Initialized
INFO - 2023-08-11 03:08:07 --> Form Validation Class Initialized
INFO - 2023-08-11 03:08:07 --> Controller Class Initialized
INFO - 2023-08-11 03:08:07 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:07 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:07 --> Model Class Initialized
INFO - 2023-08-11 03:08:07 --> Model Class Initialized
INFO - 2023-08-11 03:08:07 --> Model Class Initialized
INFO - 2023-08-11 03:08:07 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:07 --> Model Class Initialized
INFO - 2023-08-11 03:08:07 --> Model Class Initialized
INFO - 2023-08-11 03:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 03:08:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 03:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 03:08:07 --> Model Class Initialized
INFO - 2023-08-11 03:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 03:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 03:08:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 03:08:07 --> Final output sent to browser
DEBUG - 2023-08-11 03:08:07 --> Total execution time: 0.0805
ERROR - 2023-08-11 03:08:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:08:15 --> Config Class Initialized
INFO - 2023-08-11 03:08:15 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:08:15 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:08:15 --> Utf8 Class Initialized
INFO - 2023-08-11 03:08:15 --> URI Class Initialized
INFO - 2023-08-11 03:08:15 --> Router Class Initialized
INFO - 2023-08-11 03:08:15 --> Output Class Initialized
INFO - 2023-08-11 03:08:15 --> Security Class Initialized
DEBUG - 2023-08-11 03:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:08:15 --> Input Class Initialized
INFO - 2023-08-11 03:08:15 --> Language Class Initialized
INFO - 2023-08-11 03:08:15 --> Loader Class Initialized
INFO - 2023-08-11 03:08:15 --> Helper loaded: url_helper
INFO - 2023-08-11 03:08:15 --> Helper loaded: file_helper
INFO - 2023-08-11 03:08:15 --> Helper loaded: html_helper
INFO - 2023-08-11 03:08:15 --> Helper loaded: text_helper
INFO - 2023-08-11 03:08:15 --> Helper loaded: form_helper
INFO - 2023-08-11 03:08:15 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:08:15 --> Helper loaded: security_helper
INFO - 2023-08-11 03:08:15 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:08:15 --> Database Driver Class Initialized
INFO - 2023-08-11 03:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:08:15 --> Parser Class Initialized
INFO - 2023-08-11 03:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:08:15 --> Pagination Class Initialized
INFO - 2023-08-11 03:08:15 --> Form Validation Class Initialized
INFO - 2023-08-11 03:08:15 --> Controller Class Initialized
INFO - 2023-08-11 03:08:15 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:15 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:15 --> Model Class Initialized
INFO - 2023-08-11 03:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-11 03:08:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 03:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 03:08:15 --> Model Class Initialized
INFO - 2023-08-11 03:08:15 --> Model Class Initialized
INFO - 2023-08-11 03:08:15 --> Model Class Initialized
INFO - 2023-08-11 03:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 03:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 03:08:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 03:08:15 --> Final output sent to browser
DEBUG - 2023-08-11 03:08:15 --> Total execution time: 0.0742
ERROR - 2023-08-11 03:08:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:08:16 --> Config Class Initialized
INFO - 2023-08-11 03:08:16 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:08:16 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:08:16 --> Utf8 Class Initialized
INFO - 2023-08-11 03:08:16 --> URI Class Initialized
INFO - 2023-08-11 03:08:16 --> Router Class Initialized
INFO - 2023-08-11 03:08:16 --> Output Class Initialized
INFO - 2023-08-11 03:08:16 --> Security Class Initialized
DEBUG - 2023-08-11 03:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:08:16 --> Input Class Initialized
INFO - 2023-08-11 03:08:16 --> Language Class Initialized
INFO - 2023-08-11 03:08:16 --> Loader Class Initialized
INFO - 2023-08-11 03:08:16 --> Helper loaded: url_helper
INFO - 2023-08-11 03:08:16 --> Helper loaded: file_helper
INFO - 2023-08-11 03:08:16 --> Helper loaded: html_helper
INFO - 2023-08-11 03:08:16 --> Helper loaded: text_helper
INFO - 2023-08-11 03:08:16 --> Helper loaded: form_helper
INFO - 2023-08-11 03:08:16 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:08:16 --> Helper loaded: security_helper
INFO - 2023-08-11 03:08:16 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:08:16 --> Database Driver Class Initialized
INFO - 2023-08-11 03:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:08:16 --> Parser Class Initialized
INFO - 2023-08-11 03:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:08:16 --> Pagination Class Initialized
INFO - 2023-08-11 03:08:16 --> Form Validation Class Initialized
INFO - 2023-08-11 03:08:16 --> Controller Class Initialized
INFO - 2023-08-11 03:08:16 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:16 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:16 --> Model Class Initialized
INFO - 2023-08-11 03:08:16 --> Final output sent to browser
DEBUG - 2023-08-11 03:08:16 --> Total execution time: 0.0347
ERROR - 2023-08-11 03:08:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:08:30 --> Config Class Initialized
INFO - 2023-08-11 03:08:30 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:08:30 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:08:30 --> Utf8 Class Initialized
INFO - 2023-08-11 03:08:30 --> URI Class Initialized
INFO - 2023-08-11 03:08:30 --> Router Class Initialized
INFO - 2023-08-11 03:08:30 --> Output Class Initialized
INFO - 2023-08-11 03:08:30 --> Security Class Initialized
DEBUG - 2023-08-11 03:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:08:30 --> Input Class Initialized
INFO - 2023-08-11 03:08:30 --> Language Class Initialized
INFO - 2023-08-11 03:08:30 --> Loader Class Initialized
INFO - 2023-08-11 03:08:30 --> Helper loaded: url_helper
INFO - 2023-08-11 03:08:30 --> Helper loaded: file_helper
INFO - 2023-08-11 03:08:30 --> Helper loaded: html_helper
INFO - 2023-08-11 03:08:30 --> Helper loaded: text_helper
INFO - 2023-08-11 03:08:30 --> Helper loaded: form_helper
INFO - 2023-08-11 03:08:30 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:08:30 --> Helper loaded: security_helper
INFO - 2023-08-11 03:08:30 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:08:30 --> Database Driver Class Initialized
INFO - 2023-08-11 03:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:08:30 --> Parser Class Initialized
INFO - 2023-08-11 03:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:08:30 --> Pagination Class Initialized
INFO - 2023-08-11 03:08:30 --> Form Validation Class Initialized
INFO - 2023-08-11 03:08:30 --> Controller Class Initialized
INFO - 2023-08-11 03:08:30 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:30 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:30 --> Model Class Initialized
INFO - 2023-08-11 03:08:30 --> Final output sent to browser
DEBUG - 2023-08-11 03:08:30 --> Total execution time: 0.1778
ERROR - 2023-08-11 03:08:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:08:34 --> Config Class Initialized
INFO - 2023-08-11 03:08:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:08:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:08:34 --> Utf8 Class Initialized
INFO - 2023-08-11 03:08:34 --> URI Class Initialized
INFO - 2023-08-11 03:08:34 --> Router Class Initialized
INFO - 2023-08-11 03:08:34 --> Output Class Initialized
INFO - 2023-08-11 03:08:34 --> Security Class Initialized
DEBUG - 2023-08-11 03:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:08:34 --> Input Class Initialized
INFO - 2023-08-11 03:08:34 --> Language Class Initialized
INFO - 2023-08-11 03:08:34 --> Loader Class Initialized
INFO - 2023-08-11 03:08:34 --> Helper loaded: url_helper
INFO - 2023-08-11 03:08:34 --> Helper loaded: file_helper
INFO - 2023-08-11 03:08:34 --> Helper loaded: html_helper
INFO - 2023-08-11 03:08:34 --> Helper loaded: text_helper
INFO - 2023-08-11 03:08:34 --> Helper loaded: form_helper
INFO - 2023-08-11 03:08:34 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:08:34 --> Helper loaded: security_helper
INFO - 2023-08-11 03:08:34 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:08:34 --> Database Driver Class Initialized
INFO - 2023-08-11 03:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:08:34 --> Parser Class Initialized
INFO - 2023-08-11 03:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:08:34 --> Pagination Class Initialized
INFO - 2023-08-11 03:08:34 --> Form Validation Class Initialized
INFO - 2023-08-11 03:08:34 --> Controller Class Initialized
INFO - 2023-08-11 03:08:34 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:34 --> Model Class Initialized
DEBUG - 2023-08-11 03:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:08:34 --> Model Class Initialized
INFO - 2023-08-11 03:08:34 --> Final output sent to browser
DEBUG - 2023-08-11 03:08:34 --> Total execution time: 0.1054
ERROR - 2023-08-11 03:09:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:09:29 --> Config Class Initialized
INFO - 2023-08-11 03:09:29 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:09:29 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:09:29 --> Utf8 Class Initialized
INFO - 2023-08-11 03:09:29 --> URI Class Initialized
INFO - 2023-08-11 03:09:29 --> Router Class Initialized
INFO - 2023-08-11 03:09:29 --> Output Class Initialized
INFO - 2023-08-11 03:09:29 --> Security Class Initialized
DEBUG - 2023-08-11 03:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:09:29 --> Input Class Initialized
INFO - 2023-08-11 03:09:29 --> Language Class Initialized
INFO - 2023-08-11 03:09:29 --> Loader Class Initialized
INFO - 2023-08-11 03:09:29 --> Helper loaded: url_helper
INFO - 2023-08-11 03:09:29 --> Helper loaded: file_helper
INFO - 2023-08-11 03:09:29 --> Helper loaded: html_helper
INFO - 2023-08-11 03:09:29 --> Helper loaded: text_helper
INFO - 2023-08-11 03:09:29 --> Helper loaded: form_helper
INFO - 2023-08-11 03:09:29 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:09:29 --> Helper loaded: security_helper
INFO - 2023-08-11 03:09:29 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:09:29 --> Database Driver Class Initialized
INFO - 2023-08-11 03:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:09:29 --> Parser Class Initialized
INFO - 2023-08-11 03:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:09:29 --> Pagination Class Initialized
INFO - 2023-08-11 03:09:29 --> Form Validation Class Initialized
INFO - 2023-08-11 03:09:29 --> Controller Class Initialized
INFO - 2023-08-11 03:09:29 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:29 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:29 --> Model Class Initialized
INFO - 2023-08-11 03:09:29 --> Final output sent to browser
DEBUG - 2023-08-11 03:09:29 --> Total execution time: 0.1013
ERROR - 2023-08-11 03:09:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:09:52 --> Config Class Initialized
INFO - 2023-08-11 03:09:52 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:09:52 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:09:52 --> Utf8 Class Initialized
INFO - 2023-08-11 03:09:52 --> URI Class Initialized
INFO - 2023-08-11 03:09:52 --> Router Class Initialized
INFO - 2023-08-11 03:09:52 --> Output Class Initialized
INFO - 2023-08-11 03:09:52 --> Security Class Initialized
DEBUG - 2023-08-11 03:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:09:52 --> Input Class Initialized
INFO - 2023-08-11 03:09:52 --> Language Class Initialized
INFO - 2023-08-11 03:09:52 --> Loader Class Initialized
INFO - 2023-08-11 03:09:52 --> Helper loaded: url_helper
INFO - 2023-08-11 03:09:52 --> Helper loaded: file_helper
INFO - 2023-08-11 03:09:52 --> Helper loaded: html_helper
INFO - 2023-08-11 03:09:52 --> Helper loaded: text_helper
INFO - 2023-08-11 03:09:52 --> Helper loaded: form_helper
INFO - 2023-08-11 03:09:52 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:09:52 --> Helper loaded: security_helper
INFO - 2023-08-11 03:09:52 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:09:52 --> Database Driver Class Initialized
INFO - 2023-08-11 03:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:09:52 --> Parser Class Initialized
INFO - 2023-08-11 03:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:09:52 --> Pagination Class Initialized
INFO - 2023-08-11 03:09:52 --> Form Validation Class Initialized
INFO - 2023-08-11 03:09:52 --> Controller Class Initialized
INFO - 2023-08-11 03:09:52 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:52 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:52 --> Model Class Initialized
INFO - 2023-08-11 03:09:53 --> Final output sent to browser
DEBUG - 2023-08-11 03:09:53 --> Total execution time: 0.0638
ERROR - 2023-08-11 03:09:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:09:53 --> Config Class Initialized
INFO - 2023-08-11 03:09:53 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:09:53 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:09:53 --> Utf8 Class Initialized
INFO - 2023-08-11 03:09:53 --> URI Class Initialized
INFO - 2023-08-11 03:09:53 --> Router Class Initialized
INFO - 2023-08-11 03:09:53 --> Output Class Initialized
INFO - 2023-08-11 03:09:53 --> Security Class Initialized
DEBUG - 2023-08-11 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:09:53 --> Input Class Initialized
INFO - 2023-08-11 03:09:53 --> Language Class Initialized
INFO - 2023-08-11 03:09:53 --> Loader Class Initialized
INFO - 2023-08-11 03:09:53 --> Helper loaded: url_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: file_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: html_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: text_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: form_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: security_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:09:53 --> Database Driver Class Initialized
INFO - 2023-08-11 03:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:09:53 --> Parser Class Initialized
INFO - 2023-08-11 03:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:09:53 --> Pagination Class Initialized
INFO - 2023-08-11 03:09:53 --> Form Validation Class Initialized
INFO - 2023-08-11 03:09:53 --> Controller Class Initialized
INFO - 2023-08-11 03:09:53 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:53 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:53 --> Model Class Initialized
INFO - 2023-08-11 03:09:53 --> Final output sent to browser
DEBUG - 2023-08-11 03:09:53 --> Total execution time: 0.0347
ERROR - 2023-08-11 03:09:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:09:53 --> Config Class Initialized
INFO - 2023-08-11 03:09:53 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:09:53 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:09:53 --> Utf8 Class Initialized
INFO - 2023-08-11 03:09:53 --> URI Class Initialized
INFO - 2023-08-11 03:09:53 --> Router Class Initialized
INFO - 2023-08-11 03:09:53 --> Output Class Initialized
INFO - 2023-08-11 03:09:53 --> Security Class Initialized
DEBUG - 2023-08-11 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:09:53 --> Input Class Initialized
INFO - 2023-08-11 03:09:53 --> Language Class Initialized
INFO - 2023-08-11 03:09:53 --> Loader Class Initialized
INFO - 2023-08-11 03:09:53 --> Helper loaded: url_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: file_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: html_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: text_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: form_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: security_helper
INFO - 2023-08-11 03:09:53 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:09:53 --> Database Driver Class Initialized
INFO - 2023-08-11 03:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:09:53 --> Parser Class Initialized
INFO - 2023-08-11 03:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:09:53 --> Pagination Class Initialized
INFO - 2023-08-11 03:09:53 --> Form Validation Class Initialized
INFO - 2023-08-11 03:09:53 --> Controller Class Initialized
INFO - 2023-08-11 03:09:53 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:53 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:53 --> Model Class Initialized
INFO - 2023-08-11 03:09:53 --> Final output sent to browser
DEBUG - 2023-08-11 03:09:53 --> Total execution time: 0.0292
ERROR - 2023-08-11 03:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:09:55 --> Config Class Initialized
INFO - 2023-08-11 03:09:55 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:09:55 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:09:55 --> Utf8 Class Initialized
INFO - 2023-08-11 03:09:55 --> URI Class Initialized
INFO - 2023-08-11 03:09:55 --> Router Class Initialized
INFO - 2023-08-11 03:09:55 --> Output Class Initialized
INFO - 2023-08-11 03:09:55 --> Security Class Initialized
DEBUG - 2023-08-11 03:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:09:55 --> Input Class Initialized
INFO - 2023-08-11 03:09:55 --> Language Class Initialized
INFO - 2023-08-11 03:09:55 --> Loader Class Initialized
INFO - 2023-08-11 03:09:55 --> Helper loaded: url_helper
INFO - 2023-08-11 03:09:55 --> Helper loaded: file_helper
INFO - 2023-08-11 03:09:55 --> Helper loaded: html_helper
INFO - 2023-08-11 03:09:55 --> Helper loaded: text_helper
INFO - 2023-08-11 03:09:55 --> Helper loaded: form_helper
INFO - 2023-08-11 03:09:55 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:09:55 --> Helper loaded: security_helper
INFO - 2023-08-11 03:09:55 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:09:55 --> Database Driver Class Initialized
INFO - 2023-08-11 03:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:09:55 --> Parser Class Initialized
INFO - 2023-08-11 03:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:09:55 --> Pagination Class Initialized
INFO - 2023-08-11 03:09:55 --> Form Validation Class Initialized
INFO - 2023-08-11 03:09:55 --> Controller Class Initialized
INFO - 2023-08-11 03:09:55 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:55 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:55 --> Model Class Initialized
INFO - 2023-08-11 03:09:55 --> Final output sent to browser
DEBUG - 2023-08-11 03:09:55 --> Total execution time: 0.0250
ERROR - 2023-08-11 03:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:09:56 --> Config Class Initialized
INFO - 2023-08-11 03:09:56 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:09:56 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:09:56 --> Utf8 Class Initialized
INFO - 2023-08-11 03:09:56 --> URI Class Initialized
INFO - 2023-08-11 03:09:56 --> Router Class Initialized
INFO - 2023-08-11 03:09:56 --> Output Class Initialized
INFO - 2023-08-11 03:09:56 --> Security Class Initialized
DEBUG - 2023-08-11 03:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:09:56 --> Input Class Initialized
INFO - 2023-08-11 03:09:56 --> Language Class Initialized
INFO - 2023-08-11 03:09:56 --> Loader Class Initialized
INFO - 2023-08-11 03:09:56 --> Helper loaded: url_helper
INFO - 2023-08-11 03:09:56 --> Helper loaded: file_helper
INFO - 2023-08-11 03:09:56 --> Helper loaded: html_helper
INFO - 2023-08-11 03:09:56 --> Helper loaded: text_helper
INFO - 2023-08-11 03:09:56 --> Helper loaded: form_helper
INFO - 2023-08-11 03:09:56 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:09:56 --> Helper loaded: security_helper
INFO - 2023-08-11 03:09:56 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:09:56 --> Database Driver Class Initialized
INFO - 2023-08-11 03:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:09:56 --> Parser Class Initialized
INFO - 2023-08-11 03:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:09:56 --> Pagination Class Initialized
INFO - 2023-08-11 03:09:56 --> Form Validation Class Initialized
INFO - 2023-08-11 03:09:56 --> Controller Class Initialized
INFO - 2023-08-11 03:09:56 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:56 --> Model Class Initialized
DEBUG - 2023-08-11 03:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:09:56 --> Model Class Initialized
INFO - 2023-08-11 03:09:56 --> Final output sent to browser
DEBUG - 2023-08-11 03:09:56 --> Total execution time: 0.0320
ERROR - 2023-08-11 03:10:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:10:00 --> Config Class Initialized
INFO - 2023-08-11 03:10:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:10:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:10:00 --> Utf8 Class Initialized
INFO - 2023-08-11 03:10:00 --> URI Class Initialized
INFO - 2023-08-11 03:10:00 --> Router Class Initialized
INFO - 2023-08-11 03:10:00 --> Output Class Initialized
INFO - 2023-08-11 03:10:00 --> Security Class Initialized
DEBUG - 2023-08-11 03:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:10:00 --> Input Class Initialized
INFO - 2023-08-11 03:10:00 --> Language Class Initialized
INFO - 2023-08-11 03:10:00 --> Loader Class Initialized
INFO - 2023-08-11 03:10:00 --> Helper loaded: url_helper
INFO - 2023-08-11 03:10:00 --> Helper loaded: file_helper
INFO - 2023-08-11 03:10:00 --> Helper loaded: html_helper
INFO - 2023-08-11 03:10:00 --> Helper loaded: text_helper
INFO - 2023-08-11 03:10:00 --> Helper loaded: form_helper
INFO - 2023-08-11 03:10:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:10:00 --> Helper loaded: security_helper
INFO - 2023-08-11 03:10:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:10:00 --> Database Driver Class Initialized
INFO - 2023-08-11 03:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:10:00 --> Parser Class Initialized
INFO - 2023-08-11 03:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:10:00 --> Pagination Class Initialized
INFO - 2023-08-11 03:10:00 --> Form Validation Class Initialized
INFO - 2023-08-11 03:10:00 --> Controller Class Initialized
INFO - 2023-08-11 03:10:00 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:00 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:00 --> Model Class Initialized
INFO - 2023-08-11 03:10:00 --> Final output sent to browser
DEBUG - 2023-08-11 03:10:00 --> Total execution time: 0.0204
ERROR - 2023-08-11 03:10:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:10:01 --> Config Class Initialized
INFO - 2023-08-11 03:10:01 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:10:01 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:10:01 --> Utf8 Class Initialized
INFO - 2023-08-11 03:10:01 --> URI Class Initialized
INFO - 2023-08-11 03:10:01 --> Router Class Initialized
INFO - 2023-08-11 03:10:01 --> Output Class Initialized
INFO - 2023-08-11 03:10:01 --> Security Class Initialized
DEBUG - 2023-08-11 03:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:10:01 --> Input Class Initialized
INFO - 2023-08-11 03:10:01 --> Language Class Initialized
INFO - 2023-08-11 03:10:01 --> Loader Class Initialized
INFO - 2023-08-11 03:10:01 --> Helper loaded: url_helper
INFO - 2023-08-11 03:10:01 --> Helper loaded: file_helper
INFO - 2023-08-11 03:10:01 --> Helper loaded: html_helper
INFO - 2023-08-11 03:10:01 --> Helper loaded: text_helper
INFO - 2023-08-11 03:10:01 --> Helper loaded: form_helper
INFO - 2023-08-11 03:10:01 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:10:01 --> Helper loaded: security_helper
INFO - 2023-08-11 03:10:01 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:10:01 --> Database Driver Class Initialized
INFO - 2023-08-11 03:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:10:01 --> Parser Class Initialized
INFO - 2023-08-11 03:10:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:10:01 --> Pagination Class Initialized
INFO - 2023-08-11 03:10:01 --> Form Validation Class Initialized
INFO - 2023-08-11 03:10:01 --> Controller Class Initialized
INFO - 2023-08-11 03:10:01 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:01 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:01 --> Model Class Initialized
INFO - 2023-08-11 03:10:01 --> Final output sent to browser
DEBUG - 2023-08-11 03:10:01 --> Total execution time: 0.0251
ERROR - 2023-08-11 03:10:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:10:09 --> Config Class Initialized
INFO - 2023-08-11 03:10:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:10:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:10:09 --> Utf8 Class Initialized
INFO - 2023-08-11 03:10:09 --> URI Class Initialized
INFO - 2023-08-11 03:10:09 --> Router Class Initialized
INFO - 2023-08-11 03:10:09 --> Output Class Initialized
INFO - 2023-08-11 03:10:09 --> Security Class Initialized
DEBUG - 2023-08-11 03:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:10:09 --> Input Class Initialized
INFO - 2023-08-11 03:10:09 --> Language Class Initialized
INFO - 2023-08-11 03:10:09 --> Loader Class Initialized
INFO - 2023-08-11 03:10:09 --> Helper loaded: url_helper
INFO - 2023-08-11 03:10:09 --> Helper loaded: file_helper
INFO - 2023-08-11 03:10:09 --> Helper loaded: html_helper
INFO - 2023-08-11 03:10:09 --> Helper loaded: text_helper
INFO - 2023-08-11 03:10:09 --> Helper loaded: form_helper
INFO - 2023-08-11 03:10:09 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:10:09 --> Helper loaded: security_helper
INFO - 2023-08-11 03:10:09 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:10:09 --> Database Driver Class Initialized
INFO - 2023-08-11 03:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:10:09 --> Parser Class Initialized
INFO - 2023-08-11 03:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:10:09 --> Pagination Class Initialized
INFO - 2023-08-11 03:10:09 --> Form Validation Class Initialized
INFO - 2023-08-11 03:10:09 --> Controller Class Initialized
INFO - 2023-08-11 03:10:09 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:09 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:09 --> Model Class Initialized
INFO - 2023-08-11 03:10:09 --> Final output sent to browser
DEBUG - 2023-08-11 03:10:09 --> Total execution time: 0.0205
ERROR - 2023-08-11 03:10:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:10:10 --> Config Class Initialized
INFO - 2023-08-11 03:10:10 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:10:10 --> Utf8 Class Initialized
INFO - 2023-08-11 03:10:10 --> URI Class Initialized
INFO - 2023-08-11 03:10:10 --> Router Class Initialized
INFO - 2023-08-11 03:10:10 --> Output Class Initialized
INFO - 2023-08-11 03:10:10 --> Security Class Initialized
DEBUG - 2023-08-11 03:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:10:10 --> Input Class Initialized
INFO - 2023-08-11 03:10:10 --> Language Class Initialized
INFO - 2023-08-11 03:10:10 --> Loader Class Initialized
INFO - 2023-08-11 03:10:10 --> Helper loaded: url_helper
INFO - 2023-08-11 03:10:10 --> Helper loaded: file_helper
INFO - 2023-08-11 03:10:10 --> Helper loaded: html_helper
INFO - 2023-08-11 03:10:10 --> Helper loaded: text_helper
INFO - 2023-08-11 03:10:10 --> Helper loaded: form_helper
INFO - 2023-08-11 03:10:10 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:10:10 --> Helper loaded: security_helper
INFO - 2023-08-11 03:10:10 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:10:10 --> Database Driver Class Initialized
INFO - 2023-08-11 03:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:10:10 --> Parser Class Initialized
INFO - 2023-08-11 03:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:10:10 --> Pagination Class Initialized
INFO - 2023-08-11 03:10:10 --> Form Validation Class Initialized
INFO - 2023-08-11 03:10:10 --> Controller Class Initialized
INFO - 2023-08-11 03:10:10 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:10 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:10 --> Model Class Initialized
INFO - 2023-08-11 03:10:10 --> Final output sent to browser
DEBUG - 2023-08-11 03:10:10 --> Total execution time: 0.0215
ERROR - 2023-08-11 03:10:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:10:19 --> Config Class Initialized
INFO - 2023-08-11 03:10:19 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:10:19 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:10:19 --> Utf8 Class Initialized
INFO - 2023-08-11 03:10:19 --> URI Class Initialized
INFO - 2023-08-11 03:10:19 --> Router Class Initialized
INFO - 2023-08-11 03:10:19 --> Output Class Initialized
INFO - 2023-08-11 03:10:19 --> Security Class Initialized
DEBUG - 2023-08-11 03:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:10:19 --> Input Class Initialized
INFO - 2023-08-11 03:10:19 --> Language Class Initialized
INFO - 2023-08-11 03:10:19 --> Loader Class Initialized
INFO - 2023-08-11 03:10:19 --> Helper loaded: url_helper
INFO - 2023-08-11 03:10:19 --> Helper loaded: file_helper
INFO - 2023-08-11 03:10:19 --> Helper loaded: html_helper
INFO - 2023-08-11 03:10:19 --> Helper loaded: text_helper
INFO - 2023-08-11 03:10:19 --> Helper loaded: form_helper
INFO - 2023-08-11 03:10:19 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:10:19 --> Helper loaded: security_helper
INFO - 2023-08-11 03:10:19 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:10:19 --> Database Driver Class Initialized
INFO - 2023-08-11 03:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:10:19 --> Parser Class Initialized
INFO - 2023-08-11 03:10:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:10:19 --> Pagination Class Initialized
INFO - 2023-08-11 03:10:19 --> Form Validation Class Initialized
INFO - 2023-08-11 03:10:19 --> Controller Class Initialized
INFO - 2023-08-11 03:10:19 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:19 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:19 --> Model Class Initialized
INFO - 2023-08-11 03:10:19 --> Final output sent to browser
DEBUG - 2023-08-11 03:10:19 --> Total execution time: 0.0246
ERROR - 2023-08-11 03:10:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 03:10:34 --> Config Class Initialized
INFO - 2023-08-11 03:10:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 03:10:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 03:10:34 --> Utf8 Class Initialized
INFO - 2023-08-11 03:10:34 --> URI Class Initialized
INFO - 2023-08-11 03:10:34 --> Router Class Initialized
INFO - 2023-08-11 03:10:34 --> Output Class Initialized
INFO - 2023-08-11 03:10:34 --> Security Class Initialized
DEBUG - 2023-08-11 03:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 03:10:34 --> Input Class Initialized
INFO - 2023-08-11 03:10:34 --> Language Class Initialized
INFO - 2023-08-11 03:10:34 --> Loader Class Initialized
INFO - 2023-08-11 03:10:34 --> Helper loaded: url_helper
INFO - 2023-08-11 03:10:34 --> Helper loaded: file_helper
INFO - 2023-08-11 03:10:34 --> Helper loaded: html_helper
INFO - 2023-08-11 03:10:34 --> Helper loaded: text_helper
INFO - 2023-08-11 03:10:34 --> Helper loaded: form_helper
INFO - 2023-08-11 03:10:34 --> Helper loaded: lang_helper
INFO - 2023-08-11 03:10:34 --> Helper loaded: security_helper
INFO - 2023-08-11 03:10:34 --> Helper loaded: cookie_helper
INFO - 2023-08-11 03:10:34 --> Database Driver Class Initialized
INFO - 2023-08-11 03:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 03:10:34 --> Parser Class Initialized
INFO - 2023-08-11 03:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 03:10:34 --> Pagination Class Initialized
INFO - 2023-08-11 03:10:34 --> Form Validation Class Initialized
INFO - 2023-08-11 03:10:34 --> Controller Class Initialized
INFO - 2023-08-11 03:10:34 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 03:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:34 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:34 --> Model Class Initialized
DEBUG - 2023-08-11 03:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 03:10:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 03:10:34 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-11 03:10:34 --> Final output sent to browser
DEBUG - 2023-08-11 03:10:34 --> Total execution time: 0.2210
ERROR - 2023-08-11 04:49:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:49:22 --> Config Class Initialized
INFO - 2023-08-11 04:49:22 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:49:22 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:49:22 --> Utf8 Class Initialized
INFO - 2023-08-11 04:49:22 --> URI Class Initialized
DEBUG - 2023-08-11 04:49:22 --> No URI present. Default controller set.
INFO - 2023-08-11 04:49:22 --> Router Class Initialized
INFO - 2023-08-11 04:49:22 --> Output Class Initialized
INFO - 2023-08-11 04:49:22 --> Security Class Initialized
DEBUG - 2023-08-11 04:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:49:22 --> Input Class Initialized
INFO - 2023-08-11 04:49:22 --> Language Class Initialized
INFO - 2023-08-11 04:49:22 --> Loader Class Initialized
INFO - 2023-08-11 04:49:22 --> Helper loaded: url_helper
INFO - 2023-08-11 04:49:22 --> Helper loaded: file_helper
INFO - 2023-08-11 04:49:22 --> Helper loaded: html_helper
INFO - 2023-08-11 04:49:22 --> Helper loaded: text_helper
INFO - 2023-08-11 04:49:22 --> Helper loaded: form_helper
INFO - 2023-08-11 04:49:22 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:49:22 --> Helper loaded: security_helper
INFO - 2023-08-11 04:49:22 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:49:22 --> Database Driver Class Initialized
INFO - 2023-08-11 04:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:49:22 --> Parser Class Initialized
INFO - 2023-08-11 04:49:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:49:22 --> Pagination Class Initialized
INFO - 2023-08-11 04:49:22 --> Form Validation Class Initialized
INFO - 2023-08-11 04:49:22 --> Controller Class Initialized
INFO - 2023-08-11 04:49:22 --> Model Class Initialized
DEBUG - 2023-08-11 04:49:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 04:49:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:49:23 --> Config Class Initialized
INFO - 2023-08-11 04:49:23 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:49:23 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:49:23 --> Utf8 Class Initialized
INFO - 2023-08-11 04:49:23 --> URI Class Initialized
INFO - 2023-08-11 04:49:23 --> Router Class Initialized
INFO - 2023-08-11 04:49:23 --> Output Class Initialized
INFO - 2023-08-11 04:49:23 --> Security Class Initialized
DEBUG - 2023-08-11 04:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:49:23 --> Input Class Initialized
INFO - 2023-08-11 04:49:23 --> Language Class Initialized
INFO - 2023-08-11 04:49:23 --> Loader Class Initialized
INFO - 2023-08-11 04:49:23 --> Helper loaded: url_helper
INFO - 2023-08-11 04:49:23 --> Helper loaded: file_helper
INFO - 2023-08-11 04:49:23 --> Helper loaded: html_helper
INFO - 2023-08-11 04:49:23 --> Helper loaded: text_helper
INFO - 2023-08-11 04:49:23 --> Helper loaded: form_helper
INFO - 2023-08-11 04:49:23 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:49:23 --> Helper loaded: security_helper
INFO - 2023-08-11 04:49:23 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:49:23 --> Database Driver Class Initialized
INFO - 2023-08-11 04:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:49:23 --> Parser Class Initialized
INFO - 2023-08-11 04:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:49:23 --> Pagination Class Initialized
INFO - 2023-08-11 04:49:23 --> Form Validation Class Initialized
INFO - 2023-08-11 04:49:23 --> Controller Class Initialized
INFO - 2023-08-11 04:49:23 --> Model Class Initialized
DEBUG - 2023-08-11 04:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 04:49:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:49:23 --> Model Class Initialized
INFO - 2023-08-11 04:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:49:23 --> Final output sent to browser
DEBUG - 2023-08-11 04:49:23 --> Total execution time: 0.0325
ERROR - 2023-08-11 04:49:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:49:33 --> Config Class Initialized
INFO - 2023-08-11 04:49:33 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:49:33 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:49:33 --> Utf8 Class Initialized
INFO - 2023-08-11 04:49:33 --> URI Class Initialized
INFO - 2023-08-11 04:49:33 --> Router Class Initialized
INFO - 2023-08-11 04:49:33 --> Output Class Initialized
INFO - 2023-08-11 04:49:33 --> Security Class Initialized
DEBUG - 2023-08-11 04:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:49:33 --> Input Class Initialized
INFO - 2023-08-11 04:49:33 --> Language Class Initialized
INFO - 2023-08-11 04:49:33 --> Loader Class Initialized
INFO - 2023-08-11 04:49:33 --> Helper loaded: url_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: file_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: html_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: text_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: form_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: security_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:49:33 --> Database Driver Class Initialized
INFO - 2023-08-11 04:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:49:33 --> Parser Class Initialized
INFO - 2023-08-11 04:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:49:33 --> Pagination Class Initialized
INFO - 2023-08-11 04:49:33 --> Form Validation Class Initialized
INFO - 2023-08-11 04:49:33 --> Controller Class Initialized
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
DEBUG - 2023-08-11 04:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
INFO - 2023-08-11 04:49:33 --> Final output sent to browser
DEBUG - 2023-08-11 04:49:33 --> Total execution time: 0.0233
ERROR - 2023-08-11 04:49:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:49:33 --> Config Class Initialized
INFO - 2023-08-11 04:49:33 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:49:33 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:49:33 --> Utf8 Class Initialized
INFO - 2023-08-11 04:49:33 --> URI Class Initialized
DEBUG - 2023-08-11 04:49:33 --> No URI present. Default controller set.
INFO - 2023-08-11 04:49:33 --> Router Class Initialized
INFO - 2023-08-11 04:49:33 --> Output Class Initialized
INFO - 2023-08-11 04:49:33 --> Security Class Initialized
DEBUG - 2023-08-11 04:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:49:33 --> Input Class Initialized
INFO - 2023-08-11 04:49:33 --> Language Class Initialized
INFO - 2023-08-11 04:49:33 --> Loader Class Initialized
INFO - 2023-08-11 04:49:33 --> Helper loaded: url_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: file_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: html_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: text_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: form_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: security_helper
INFO - 2023-08-11 04:49:33 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:49:33 --> Database Driver Class Initialized
INFO - 2023-08-11 04:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:49:33 --> Parser Class Initialized
INFO - 2023-08-11 04:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:49:33 --> Pagination Class Initialized
INFO - 2023-08-11 04:49:33 --> Form Validation Class Initialized
INFO - 2023-08-11 04:49:33 --> Controller Class Initialized
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
DEBUG - 2023-08-11 04:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
DEBUG - 2023-08-11 04:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
DEBUG - 2023-08-11 04:49:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
INFO - 2023-08-11 04:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 04:49:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:49:33 --> Model Class Initialized
INFO - 2023-08-11 04:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 04:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 04:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:49:33 --> Final output sent to browser
DEBUG - 2023-08-11 04:49:33 --> Total execution time: 0.0920
ERROR - 2023-08-11 04:49:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:49:44 --> Config Class Initialized
INFO - 2023-08-11 04:49:44 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:49:44 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:49:44 --> Utf8 Class Initialized
INFO - 2023-08-11 04:49:44 --> URI Class Initialized
INFO - 2023-08-11 04:49:44 --> Router Class Initialized
INFO - 2023-08-11 04:49:44 --> Output Class Initialized
INFO - 2023-08-11 04:49:44 --> Security Class Initialized
DEBUG - 2023-08-11 04:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:49:44 --> Input Class Initialized
INFO - 2023-08-11 04:49:44 --> Language Class Initialized
INFO - 2023-08-11 04:49:44 --> Loader Class Initialized
INFO - 2023-08-11 04:49:44 --> Helper loaded: url_helper
INFO - 2023-08-11 04:49:44 --> Helper loaded: file_helper
INFO - 2023-08-11 04:49:44 --> Helper loaded: html_helper
INFO - 2023-08-11 04:49:44 --> Helper loaded: text_helper
INFO - 2023-08-11 04:49:44 --> Helper loaded: form_helper
INFO - 2023-08-11 04:49:44 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:49:44 --> Helper loaded: security_helper
INFO - 2023-08-11 04:49:44 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:49:44 --> Database Driver Class Initialized
INFO - 2023-08-11 04:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:49:44 --> Parser Class Initialized
INFO - 2023-08-11 04:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:49:44 --> Pagination Class Initialized
INFO - 2023-08-11 04:49:44 --> Form Validation Class Initialized
INFO - 2023-08-11 04:49:44 --> Controller Class Initialized
DEBUG - 2023-08-11 04:49:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:44 --> Model Class Initialized
DEBUG - 2023-08-11 04:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:44 --> Model Class Initialized
INFO - 2023-08-11 04:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-08-11 04:49:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:49:44 --> Model Class Initialized
INFO - 2023-08-11 04:49:44 --> Model Class Initialized
INFO - 2023-08-11 04:49:44 --> Model Class Initialized
INFO - 2023-08-11 04:49:44 --> Model Class Initialized
INFO - 2023-08-11 04:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 04:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 04:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:49:44 --> Final output sent to browser
DEBUG - 2023-08-11 04:49:44 --> Total execution time: 0.1013
ERROR - 2023-08-11 04:55:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:55:22 --> Config Class Initialized
INFO - 2023-08-11 04:55:22 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:55:22 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:55:22 --> Utf8 Class Initialized
INFO - 2023-08-11 04:55:22 --> URI Class Initialized
INFO - 2023-08-11 04:55:22 --> Router Class Initialized
INFO - 2023-08-11 04:55:22 --> Output Class Initialized
INFO - 2023-08-11 04:55:22 --> Security Class Initialized
DEBUG - 2023-08-11 04:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:55:22 --> Input Class Initialized
INFO - 2023-08-11 04:55:22 --> Language Class Initialized
INFO - 2023-08-11 04:55:22 --> Loader Class Initialized
INFO - 2023-08-11 04:55:22 --> Helper loaded: url_helper
INFO - 2023-08-11 04:55:22 --> Helper loaded: file_helper
INFO - 2023-08-11 04:55:22 --> Helper loaded: html_helper
INFO - 2023-08-11 04:55:22 --> Helper loaded: text_helper
INFO - 2023-08-11 04:55:22 --> Helper loaded: form_helper
INFO - 2023-08-11 04:55:22 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:55:22 --> Helper loaded: security_helper
INFO - 2023-08-11 04:55:22 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:55:22 --> Database Driver Class Initialized
INFO - 2023-08-11 04:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:55:22 --> Parser Class Initialized
INFO - 2023-08-11 04:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:55:22 --> Pagination Class Initialized
INFO - 2023-08-11 04:55:22 --> Form Validation Class Initialized
INFO - 2023-08-11 04:55:22 --> Controller Class Initialized
DEBUG - 2023-08-11 04:55:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:22 --> Model Class Initialized
DEBUG - 2023-08-11 04:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:22 --> Model Class Initialized
DEBUG - 2023-08-11 04:55:22 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:22 --> Final output sent to browser
DEBUG - 2023-08-11 04:55:22 --> Total execution time: 0.0259
ERROR - 2023-08-11 04:55:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:55:32 --> Config Class Initialized
INFO - 2023-08-11 04:55:32 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:55:32 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:55:32 --> Utf8 Class Initialized
INFO - 2023-08-11 04:55:32 --> URI Class Initialized
DEBUG - 2023-08-11 04:55:32 --> No URI present. Default controller set.
INFO - 2023-08-11 04:55:32 --> Router Class Initialized
INFO - 2023-08-11 04:55:32 --> Output Class Initialized
INFO - 2023-08-11 04:55:32 --> Security Class Initialized
DEBUG - 2023-08-11 04:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:55:32 --> Input Class Initialized
INFO - 2023-08-11 04:55:32 --> Language Class Initialized
INFO - 2023-08-11 04:55:32 --> Loader Class Initialized
INFO - 2023-08-11 04:55:32 --> Helper loaded: url_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: file_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: html_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: text_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: form_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: security_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:55:32 --> Database Driver Class Initialized
INFO - 2023-08-11 04:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:55:32 --> Parser Class Initialized
INFO - 2023-08-11 04:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:55:32 --> Pagination Class Initialized
INFO - 2023-08-11 04:55:32 --> Form Validation Class Initialized
INFO - 2023-08-11 04:55:32 --> Controller Class Initialized
INFO - 2023-08-11 04:55:32 --> Model Class Initialized
DEBUG - 2023-08-11 04:55:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 04:55:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:55:32 --> Config Class Initialized
INFO - 2023-08-11 04:55:32 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:55:32 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:55:32 --> Utf8 Class Initialized
INFO - 2023-08-11 04:55:32 --> URI Class Initialized
INFO - 2023-08-11 04:55:32 --> Router Class Initialized
INFO - 2023-08-11 04:55:32 --> Output Class Initialized
INFO - 2023-08-11 04:55:32 --> Security Class Initialized
DEBUG - 2023-08-11 04:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:55:32 --> Input Class Initialized
INFO - 2023-08-11 04:55:32 --> Language Class Initialized
INFO - 2023-08-11 04:55:32 --> Loader Class Initialized
INFO - 2023-08-11 04:55:32 --> Helper loaded: url_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: file_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: html_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: text_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: form_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: security_helper
INFO - 2023-08-11 04:55:32 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:55:32 --> Database Driver Class Initialized
INFO - 2023-08-11 04:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:55:32 --> Parser Class Initialized
INFO - 2023-08-11 04:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:55:32 --> Pagination Class Initialized
INFO - 2023-08-11 04:55:32 --> Form Validation Class Initialized
INFO - 2023-08-11 04:55:32 --> Controller Class Initialized
INFO - 2023-08-11 04:55:32 --> Model Class Initialized
DEBUG - 2023-08-11 04:55:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 04:55:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:55:32 --> Model Class Initialized
INFO - 2023-08-11 04:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:55:32 --> Final output sent to browser
DEBUG - 2023-08-11 04:55:32 --> Total execution time: 0.0330
ERROR - 2023-08-11 04:55:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:55:36 --> Config Class Initialized
INFO - 2023-08-11 04:55:36 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:55:36 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:55:36 --> Utf8 Class Initialized
INFO - 2023-08-11 04:55:36 --> URI Class Initialized
INFO - 2023-08-11 04:55:36 --> Router Class Initialized
INFO - 2023-08-11 04:55:36 --> Output Class Initialized
INFO - 2023-08-11 04:55:36 --> Security Class Initialized
DEBUG - 2023-08-11 04:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:55:36 --> Input Class Initialized
INFO - 2023-08-11 04:55:36 --> Language Class Initialized
INFO - 2023-08-11 04:55:36 --> Loader Class Initialized
INFO - 2023-08-11 04:55:36 --> Helper loaded: url_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: file_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: html_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: text_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: form_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: security_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:55:36 --> Database Driver Class Initialized
INFO - 2023-08-11 04:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:55:36 --> Parser Class Initialized
INFO - 2023-08-11 04:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:55:36 --> Pagination Class Initialized
INFO - 2023-08-11 04:55:36 --> Form Validation Class Initialized
INFO - 2023-08-11 04:55:36 --> Controller Class Initialized
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
DEBUG - 2023-08-11 04:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
INFO - 2023-08-11 04:55:36 --> Final output sent to browser
DEBUG - 2023-08-11 04:55:36 --> Total execution time: 0.0170
ERROR - 2023-08-11 04:55:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:55:36 --> Config Class Initialized
INFO - 2023-08-11 04:55:36 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:55:36 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:55:36 --> Utf8 Class Initialized
INFO - 2023-08-11 04:55:36 --> URI Class Initialized
DEBUG - 2023-08-11 04:55:36 --> No URI present. Default controller set.
INFO - 2023-08-11 04:55:36 --> Router Class Initialized
INFO - 2023-08-11 04:55:36 --> Output Class Initialized
INFO - 2023-08-11 04:55:36 --> Security Class Initialized
DEBUG - 2023-08-11 04:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:55:36 --> Input Class Initialized
INFO - 2023-08-11 04:55:36 --> Language Class Initialized
INFO - 2023-08-11 04:55:36 --> Loader Class Initialized
INFO - 2023-08-11 04:55:36 --> Helper loaded: url_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: file_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: html_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: text_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: form_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: security_helper
INFO - 2023-08-11 04:55:36 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:55:36 --> Database Driver Class Initialized
INFO - 2023-08-11 04:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:55:36 --> Parser Class Initialized
INFO - 2023-08-11 04:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:55:36 --> Pagination Class Initialized
INFO - 2023-08-11 04:55:36 --> Form Validation Class Initialized
INFO - 2023-08-11 04:55:36 --> Controller Class Initialized
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
DEBUG - 2023-08-11 04:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
DEBUG - 2023-08-11 04:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
DEBUG - 2023-08-11 04:55:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
INFO - 2023-08-11 04:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 04:55:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:55:36 --> Model Class Initialized
INFO - 2023-08-11 04:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 04:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 04:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:55:36 --> Final output sent to browser
DEBUG - 2023-08-11 04:55:36 --> Total execution time: 0.1775
ERROR - 2023-08-11 04:55:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:55:37 --> Config Class Initialized
INFO - 2023-08-11 04:55:37 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:55:37 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:55:37 --> Utf8 Class Initialized
INFO - 2023-08-11 04:55:37 --> URI Class Initialized
INFO - 2023-08-11 04:55:37 --> Router Class Initialized
INFO - 2023-08-11 04:55:37 --> Output Class Initialized
INFO - 2023-08-11 04:55:37 --> Security Class Initialized
DEBUG - 2023-08-11 04:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:55:37 --> Input Class Initialized
INFO - 2023-08-11 04:55:37 --> Language Class Initialized
INFO - 2023-08-11 04:55:37 --> Loader Class Initialized
INFO - 2023-08-11 04:55:37 --> Helper loaded: url_helper
INFO - 2023-08-11 04:55:37 --> Helper loaded: file_helper
INFO - 2023-08-11 04:55:37 --> Helper loaded: html_helper
INFO - 2023-08-11 04:55:37 --> Helper loaded: text_helper
INFO - 2023-08-11 04:55:37 --> Helper loaded: form_helper
INFO - 2023-08-11 04:55:37 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:55:37 --> Helper loaded: security_helper
INFO - 2023-08-11 04:55:37 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:55:37 --> Database Driver Class Initialized
INFO - 2023-08-11 04:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:55:37 --> Parser Class Initialized
INFO - 2023-08-11 04:55:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:55:37 --> Pagination Class Initialized
INFO - 2023-08-11 04:55:37 --> Form Validation Class Initialized
INFO - 2023-08-11 04:55:37 --> Controller Class Initialized
DEBUG - 2023-08-11 04:55:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:55:37 --> Model Class Initialized
INFO - 2023-08-11 04:55:37 --> Final output sent to browser
DEBUG - 2023-08-11 04:55:37 --> Total execution time: 0.0158
ERROR - 2023-08-11 04:56:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:56:36 --> Config Class Initialized
INFO - 2023-08-11 04:56:36 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:56:36 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:56:36 --> Utf8 Class Initialized
INFO - 2023-08-11 04:56:36 --> URI Class Initialized
DEBUG - 2023-08-11 04:56:36 --> No URI present. Default controller set.
INFO - 2023-08-11 04:56:36 --> Router Class Initialized
INFO - 2023-08-11 04:56:36 --> Output Class Initialized
INFO - 2023-08-11 04:56:36 --> Security Class Initialized
DEBUG - 2023-08-11 04:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:56:36 --> Input Class Initialized
INFO - 2023-08-11 04:56:36 --> Language Class Initialized
INFO - 2023-08-11 04:56:36 --> Loader Class Initialized
INFO - 2023-08-11 04:56:36 --> Helper loaded: url_helper
INFO - 2023-08-11 04:56:36 --> Helper loaded: file_helper
INFO - 2023-08-11 04:56:36 --> Helper loaded: html_helper
INFO - 2023-08-11 04:56:36 --> Helper loaded: text_helper
INFO - 2023-08-11 04:56:36 --> Helper loaded: form_helper
INFO - 2023-08-11 04:56:36 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:56:36 --> Helper loaded: security_helper
INFO - 2023-08-11 04:56:36 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:56:36 --> Database Driver Class Initialized
INFO - 2023-08-11 04:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:56:36 --> Parser Class Initialized
INFO - 2023-08-11 04:56:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:56:36 --> Pagination Class Initialized
INFO - 2023-08-11 04:56:36 --> Form Validation Class Initialized
INFO - 2023-08-11 04:56:36 --> Controller Class Initialized
INFO - 2023-08-11 04:56:36 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 04:56:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:56:37 --> Config Class Initialized
INFO - 2023-08-11 04:56:37 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:56:37 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:56:37 --> Utf8 Class Initialized
INFO - 2023-08-11 04:56:37 --> URI Class Initialized
INFO - 2023-08-11 04:56:37 --> Router Class Initialized
INFO - 2023-08-11 04:56:37 --> Output Class Initialized
INFO - 2023-08-11 04:56:37 --> Security Class Initialized
DEBUG - 2023-08-11 04:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:56:37 --> Input Class Initialized
INFO - 2023-08-11 04:56:37 --> Language Class Initialized
INFO - 2023-08-11 04:56:37 --> Loader Class Initialized
INFO - 2023-08-11 04:56:37 --> Helper loaded: url_helper
INFO - 2023-08-11 04:56:37 --> Helper loaded: file_helper
INFO - 2023-08-11 04:56:37 --> Helper loaded: html_helper
INFO - 2023-08-11 04:56:37 --> Helper loaded: text_helper
INFO - 2023-08-11 04:56:37 --> Helper loaded: form_helper
INFO - 2023-08-11 04:56:37 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:56:37 --> Helper loaded: security_helper
INFO - 2023-08-11 04:56:37 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:56:37 --> Database Driver Class Initialized
INFO - 2023-08-11 04:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:56:37 --> Parser Class Initialized
INFO - 2023-08-11 04:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:56:37 --> Pagination Class Initialized
INFO - 2023-08-11 04:56:37 --> Form Validation Class Initialized
INFO - 2023-08-11 04:56:37 --> Controller Class Initialized
INFO - 2023-08-11 04:56:37 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 04:56:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:56:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:56:37 --> Model Class Initialized
INFO - 2023-08-11 04:56:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:56:37 --> Final output sent to browser
DEBUG - 2023-08-11 04:56:37 --> Total execution time: 0.0318
ERROR - 2023-08-11 04:56:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:56:47 --> Config Class Initialized
INFO - 2023-08-11 04:56:47 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:56:47 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:56:47 --> Utf8 Class Initialized
INFO - 2023-08-11 04:56:47 --> URI Class Initialized
INFO - 2023-08-11 04:56:47 --> Router Class Initialized
INFO - 2023-08-11 04:56:47 --> Output Class Initialized
INFO - 2023-08-11 04:56:47 --> Security Class Initialized
DEBUG - 2023-08-11 04:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:56:47 --> Input Class Initialized
INFO - 2023-08-11 04:56:47 --> Language Class Initialized
INFO - 2023-08-11 04:56:47 --> Loader Class Initialized
INFO - 2023-08-11 04:56:47 --> Helper loaded: url_helper
INFO - 2023-08-11 04:56:47 --> Helper loaded: file_helper
INFO - 2023-08-11 04:56:47 --> Helper loaded: html_helper
INFO - 2023-08-11 04:56:47 --> Helper loaded: text_helper
INFO - 2023-08-11 04:56:47 --> Helper loaded: form_helper
INFO - 2023-08-11 04:56:47 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:56:47 --> Helper loaded: security_helper
INFO - 2023-08-11 04:56:47 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:56:47 --> Database Driver Class Initialized
INFO - 2023-08-11 04:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:56:47 --> Parser Class Initialized
INFO - 2023-08-11 04:56:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:56:47 --> Pagination Class Initialized
INFO - 2023-08-11 04:56:47 --> Form Validation Class Initialized
INFO - 2023-08-11 04:56:47 --> Controller Class Initialized
DEBUG - 2023-08-11 04:56:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:47 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:47 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:47 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:47 --> Model Class Initialized
INFO - 2023-08-11 04:56:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-11 04:56:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:56:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:56:47 --> Model Class Initialized
INFO - 2023-08-11 04:56:47 --> Model Class Initialized
INFO - 2023-08-11 04:56:47 --> Model Class Initialized
INFO - 2023-08-11 04:56:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 04:56:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 04:56:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:56:48 --> Final output sent to browser
DEBUG - 2023-08-11 04:56:48 --> Total execution time: 0.1264
ERROR - 2023-08-11 04:56:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:56:48 --> Config Class Initialized
INFO - 2023-08-11 04:56:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:56:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:56:48 --> Utf8 Class Initialized
INFO - 2023-08-11 04:56:48 --> URI Class Initialized
INFO - 2023-08-11 04:56:48 --> Router Class Initialized
INFO - 2023-08-11 04:56:48 --> Output Class Initialized
INFO - 2023-08-11 04:56:48 --> Security Class Initialized
DEBUG - 2023-08-11 04:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:56:48 --> Input Class Initialized
INFO - 2023-08-11 04:56:48 --> Language Class Initialized
INFO - 2023-08-11 04:56:48 --> Loader Class Initialized
INFO - 2023-08-11 04:56:48 --> Helper loaded: url_helper
INFO - 2023-08-11 04:56:48 --> Helper loaded: file_helper
INFO - 2023-08-11 04:56:48 --> Helper loaded: html_helper
INFO - 2023-08-11 04:56:48 --> Helper loaded: text_helper
INFO - 2023-08-11 04:56:48 --> Helper loaded: form_helper
INFO - 2023-08-11 04:56:48 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:56:48 --> Helper loaded: security_helper
INFO - 2023-08-11 04:56:48 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:56:48 --> Database Driver Class Initialized
INFO - 2023-08-11 04:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:56:48 --> Parser Class Initialized
INFO - 2023-08-11 04:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:56:48 --> Pagination Class Initialized
INFO - 2023-08-11 04:56:48 --> Form Validation Class Initialized
INFO - 2023-08-11 04:56:48 --> Controller Class Initialized
DEBUG - 2023-08-11 04:56:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:48 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:48 --> Model Class Initialized
INFO - 2023-08-11 04:56:48 --> Final output sent to browser
DEBUG - 2023-08-11 04:56:48 --> Total execution time: 0.0302
ERROR - 2023-08-11 04:56:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:56:53 --> Config Class Initialized
INFO - 2023-08-11 04:56:53 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:56:53 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:56:53 --> Utf8 Class Initialized
INFO - 2023-08-11 04:56:53 --> URI Class Initialized
INFO - 2023-08-11 04:56:53 --> Router Class Initialized
INFO - 2023-08-11 04:56:53 --> Output Class Initialized
INFO - 2023-08-11 04:56:53 --> Security Class Initialized
DEBUG - 2023-08-11 04:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:56:53 --> Input Class Initialized
INFO - 2023-08-11 04:56:53 --> Language Class Initialized
INFO - 2023-08-11 04:56:53 --> Loader Class Initialized
INFO - 2023-08-11 04:56:53 --> Helper loaded: url_helper
INFO - 2023-08-11 04:56:53 --> Helper loaded: file_helper
INFO - 2023-08-11 04:56:53 --> Helper loaded: html_helper
INFO - 2023-08-11 04:56:53 --> Helper loaded: text_helper
INFO - 2023-08-11 04:56:53 --> Helper loaded: form_helper
INFO - 2023-08-11 04:56:53 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:56:53 --> Helper loaded: security_helper
INFO - 2023-08-11 04:56:53 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:56:53 --> Database Driver Class Initialized
INFO - 2023-08-11 04:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:56:53 --> Parser Class Initialized
INFO - 2023-08-11 04:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:56:53 --> Pagination Class Initialized
INFO - 2023-08-11 04:56:53 --> Form Validation Class Initialized
INFO - 2023-08-11 04:56:53 --> Controller Class Initialized
DEBUG - 2023-08-11 04:56:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:53 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:53 --> Model Class Initialized
INFO - 2023-08-11 04:56:53 --> Final output sent to browser
DEBUG - 2023-08-11 04:56:53 --> Total execution time: 0.0182
ERROR - 2023-08-11 04:56:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:56:55 --> Config Class Initialized
INFO - 2023-08-11 04:56:55 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:56:55 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:56:55 --> Utf8 Class Initialized
INFO - 2023-08-11 04:56:55 --> URI Class Initialized
INFO - 2023-08-11 04:56:55 --> Router Class Initialized
INFO - 2023-08-11 04:56:55 --> Output Class Initialized
INFO - 2023-08-11 04:56:55 --> Security Class Initialized
DEBUG - 2023-08-11 04:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:56:55 --> Input Class Initialized
INFO - 2023-08-11 04:56:55 --> Language Class Initialized
INFO - 2023-08-11 04:56:55 --> Loader Class Initialized
INFO - 2023-08-11 04:56:55 --> Helper loaded: url_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: file_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: html_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: text_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: form_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: security_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:56:55 --> Database Driver Class Initialized
INFO - 2023-08-11 04:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:56:55 --> Parser Class Initialized
INFO - 2023-08-11 04:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:56:55 --> Pagination Class Initialized
INFO - 2023-08-11 04:56:55 --> Form Validation Class Initialized
INFO - 2023-08-11 04:56:55 --> Controller Class Initialized
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
INFO - 2023-08-11 04:56:55 --> Final output sent to browser
DEBUG - 2023-08-11 04:56:55 --> Total execution time: 0.0161
ERROR - 2023-08-11 04:56:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:56:55 --> Config Class Initialized
INFO - 2023-08-11 04:56:55 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:56:55 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:56:55 --> Utf8 Class Initialized
INFO - 2023-08-11 04:56:55 --> URI Class Initialized
DEBUG - 2023-08-11 04:56:55 --> No URI present. Default controller set.
INFO - 2023-08-11 04:56:55 --> Router Class Initialized
INFO - 2023-08-11 04:56:55 --> Output Class Initialized
INFO - 2023-08-11 04:56:55 --> Security Class Initialized
DEBUG - 2023-08-11 04:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:56:55 --> Input Class Initialized
INFO - 2023-08-11 04:56:55 --> Language Class Initialized
INFO - 2023-08-11 04:56:55 --> Loader Class Initialized
INFO - 2023-08-11 04:56:55 --> Helper loaded: url_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: file_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: html_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: text_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: form_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: security_helper
INFO - 2023-08-11 04:56:55 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:56:55 --> Database Driver Class Initialized
INFO - 2023-08-11 04:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:56:55 --> Parser Class Initialized
INFO - 2023-08-11 04:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:56:55 --> Pagination Class Initialized
INFO - 2023-08-11 04:56:55 --> Form Validation Class Initialized
INFO - 2023-08-11 04:56:55 --> Controller Class Initialized
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
INFO - 2023-08-11 04:56:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 04:56:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:56:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:56:55 --> Model Class Initialized
INFO - 2023-08-11 04:56:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 04:56:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 04:56:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:56:55 --> Final output sent to browser
DEBUG - 2023-08-11 04:56:55 --> Total execution time: 0.0769
ERROR - 2023-08-11 04:56:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:56:56 --> Config Class Initialized
INFO - 2023-08-11 04:56:56 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:56:56 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:56:56 --> Utf8 Class Initialized
INFO - 2023-08-11 04:56:56 --> URI Class Initialized
INFO - 2023-08-11 04:56:56 --> Router Class Initialized
INFO - 2023-08-11 04:56:56 --> Output Class Initialized
INFO - 2023-08-11 04:56:56 --> Security Class Initialized
DEBUG - 2023-08-11 04:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:56:56 --> Input Class Initialized
INFO - 2023-08-11 04:56:56 --> Language Class Initialized
INFO - 2023-08-11 04:56:56 --> Loader Class Initialized
INFO - 2023-08-11 04:56:56 --> Helper loaded: url_helper
INFO - 2023-08-11 04:56:56 --> Helper loaded: file_helper
INFO - 2023-08-11 04:56:56 --> Helper loaded: html_helper
INFO - 2023-08-11 04:56:56 --> Helper loaded: text_helper
INFO - 2023-08-11 04:56:56 --> Helper loaded: form_helper
INFO - 2023-08-11 04:56:56 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:56:56 --> Helper loaded: security_helper
INFO - 2023-08-11 04:56:56 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:56:56 --> Database Driver Class Initialized
INFO - 2023-08-11 04:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:56:56 --> Parser Class Initialized
INFO - 2023-08-11 04:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:56:56 --> Pagination Class Initialized
INFO - 2023-08-11 04:56:56 --> Form Validation Class Initialized
INFO - 2023-08-11 04:56:56 --> Controller Class Initialized
DEBUG - 2023-08-11 04:56:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:56 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:56 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:56 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:56 --> Model Class Initialized
INFO - 2023-08-11 04:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-11 04:56:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:56:56 --> Model Class Initialized
INFO - 2023-08-11 04:56:56 --> Model Class Initialized
INFO - 2023-08-11 04:56:56 --> Model Class Initialized
INFO - 2023-08-11 04:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 04:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 04:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:56:56 --> Final output sent to browser
DEBUG - 2023-08-11 04:56:56 --> Total execution time: 0.1310
ERROR - 2023-08-11 04:56:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:56:57 --> Config Class Initialized
INFO - 2023-08-11 04:56:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:56:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:56:57 --> Utf8 Class Initialized
INFO - 2023-08-11 04:56:57 --> URI Class Initialized
INFO - 2023-08-11 04:56:57 --> Router Class Initialized
INFO - 2023-08-11 04:56:57 --> Output Class Initialized
INFO - 2023-08-11 04:56:57 --> Security Class Initialized
DEBUG - 2023-08-11 04:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:56:57 --> Input Class Initialized
INFO - 2023-08-11 04:56:57 --> Language Class Initialized
INFO - 2023-08-11 04:56:57 --> Loader Class Initialized
INFO - 2023-08-11 04:56:57 --> Helper loaded: url_helper
INFO - 2023-08-11 04:56:57 --> Helper loaded: file_helper
INFO - 2023-08-11 04:56:57 --> Helper loaded: html_helper
INFO - 2023-08-11 04:56:57 --> Helper loaded: text_helper
INFO - 2023-08-11 04:56:57 --> Helper loaded: form_helper
INFO - 2023-08-11 04:56:57 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:56:57 --> Helper loaded: security_helper
INFO - 2023-08-11 04:56:57 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:56:57 --> Database Driver Class Initialized
INFO - 2023-08-11 04:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:56:57 --> Parser Class Initialized
INFO - 2023-08-11 04:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:56:57 --> Pagination Class Initialized
INFO - 2023-08-11 04:56:57 --> Form Validation Class Initialized
INFO - 2023-08-11 04:56:57 --> Controller Class Initialized
DEBUG - 2023-08-11 04:56:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:57 --> Model Class Initialized
DEBUG - 2023-08-11 04:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:56:57 --> Model Class Initialized
INFO - 2023-08-11 04:56:57 --> Final output sent to browser
DEBUG - 2023-08-11 04:56:57 --> Total execution time: 0.0294
ERROR - 2023-08-11 04:57:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:21 --> Config Class Initialized
INFO - 2023-08-11 04:57:21 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:21 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:21 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:21 --> URI Class Initialized
DEBUG - 2023-08-11 04:57:21 --> No URI present. Default controller set.
INFO - 2023-08-11 04:57:21 --> Router Class Initialized
INFO - 2023-08-11 04:57:21 --> Output Class Initialized
INFO - 2023-08-11 04:57:21 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:21 --> Input Class Initialized
INFO - 2023-08-11 04:57:21 --> Language Class Initialized
INFO - 2023-08-11 04:57:21 --> Loader Class Initialized
INFO - 2023-08-11 04:57:21 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:21 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:21 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:21 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:21 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:21 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:21 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:21 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:21 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:21 --> Parser Class Initialized
INFO - 2023-08-11 04:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:21 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:21 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:21 --> Controller Class Initialized
INFO - 2023-08-11 04:57:21 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:21 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:21 --> Model Class Initialized
INFO - 2023-08-11 04:57:21 --> Model Class Initialized
INFO - 2023-08-11 04:57:21 --> Model Class Initialized
INFO - 2023-08-11 04:57:21 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:21 --> Model Class Initialized
INFO - 2023-08-11 04:57:21 --> Model Class Initialized
INFO - 2023-08-11 04:57:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 04:57:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:57:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:57:21 --> Model Class Initialized
INFO - 2023-08-11 04:57:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 04:57:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 04:57:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:57:21 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:21 --> Total execution time: 0.0985
ERROR - 2023-08-11 04:57:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:27 --> Config Class Initialized
INFO - 2023-08-11 04:57:27 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:27 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:27 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:27 --> URI Class Initialized
INFO - 2023-08-11 04:57:27 --> Router Class Initialized
INFO - 2023-08-11 04:57:27 --> Output Class Initialized
INFO - 2023-08-11 04:57:27 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:27 --> Input Class Initialized
INFO - 2023-08-11 04:57:27 --> Language Class Initialized
INFO - 2023-08-11 04:57:27 --> Loader Class Initialized
INFO - 2023-08-11 04:57:27 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:27 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:27 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:27 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:27 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:27 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:27 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:27 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:27 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:27 --> Parser Class Initialized
INFO - 2023-08-11 04:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:27 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:27 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:27 --> Controller Class Initialized
INFO - 2023-08-11 04:57:27 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:27 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:27 --> Model Class Initialized
INFO - 2023-08-11 04:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-11 04:57:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 04:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 04:57:27 --> Model Class Initialized
INFO - 2023-08-11 04:57:27 --> Model Class Initialized
INFO - 2023-08-11 04:57:27 --> Model Class Initialized
INFO - 2023-08-11 04:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 04:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 04:57:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 04:57:27 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:27 --> Total execution time: 0.0973
ERROR - 2023-08-11 04:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:36 --> Config Class Initialized
INFO - 2023-08-11 04:57:36 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:36 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:36 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:36 --> URI Class Initialized
INFO - 2023-08-11 04:57:36 --> Router Class Initialized
INFO - 2023-08-11 04:57:36 --> Output Class Initialized
INFO - 2023-08-11 04:57:36 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:36 --> Input Class Initialized
INFO - 2023-08-11 04:57:36 --> Language Class Initialized
INFO - 2023-08-11 04:57:36 --> Loader Class Initialized
INFO - 2023-08-11 04:57:36 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:36 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:36 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:36 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:36 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:36 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:36 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:36 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:36 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:36 --> Parser Class Initialized
INFO - 2023-08-11 04:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:36 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:36 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:36 --> Controller Class Initialized
INFO - 2023-08-11 04:57:36 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:36 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:36 --> Total execution time: 0.0167
ERROR - 2023-08-11 04:57:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:37 --> Config Class Initialized
INFO - 2023-08-11 04:57:37 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:37 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:37 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:37 --> URI Class Initialized
INFO - 2023-08-11 04:57:37 --> Router Class Initialized
INFO - 2023-08-11 04:57:37 --> Output Class Initialized
INFO - 2023-08-11 04:57:37 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:37 --> Input Class Initialized
INFO - 2023-08-11 04:57:37 --> Language Class Initialized
INFO - 2023-08-11 04:57:37 --> Loader Class Initialized
INFO - 2023-08-11 04:57:37 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:37 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:37 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:37 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:37 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:37 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:37 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:37 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:37 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:37 --> Parser Class Initialized
INFO - 2023-08-11 04:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:37 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:37 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:37 --> Controller Class Initialized
INFO - 2023-08-11 04:57:37 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:37 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:37 --> Total execution time: 0.0151
ERROR - 2023-08-11 04:57:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:39 --> Config Class Initialized
INFO - 2023-08-11 04:57:39 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:39 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:39 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:39 --> URI Class Initialized
INFO - 2023-08-11 04:57:39 --> Router Class Initialized
INFO - 2023-08-11 04:57:39 --> Output Class Initialized
INFO - 2023-08-11 04:57:39 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:39 --> Input Class Initialized
INFO - 2023-08-11 04:57:39 --> Language Class Initialized
INFO - 2023-08-11 04:57:39 --> Loader Class Initialized
INFO - 2023-08-11 04:57:39 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:39 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:39 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:39 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:39 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:39 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:39 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:39 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:39 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:39 --> Parser Class Initialized
INFO - 2023-08-11 04:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:39 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:39 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:39 --> Controller Class Initialized
INFO - 2023-08-11 04:57:39 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:39 --> Total execution time: 0.0143
ERROR - 2023-08-11 04:57:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:42 --> Config Class Initialized
INFO - 2023-08-11 04:57:42 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:42 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:42 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:42 --> URI Class Initialized
INFO - 2023-08-11 04:57:42 --> Router Class Initialized
INFO - 2023-08-11 04:57:42 --> Output Class Initialized
INFO - 2023-08-11 04:57:42 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:42 --> Input Class Initialized
INFO - 2023-08-11 04:57:42 --> Language Class Initialized
INFO - 2023-08-11 04:57:42 --> Loader Class Initialized
INFO - 2023-08-11 04:57:42 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:42 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:42 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:42 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:42 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:42 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:42 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:42 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:42 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:42 --> Parser Class Initialized
INFO - 2023-08-11 04:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:42 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:42 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:42 --> Controller Class Initialized
INFO - 2023-08-11 04:57:42 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:42 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:42 --> Model Class Initialized
INFO - 2023-08-11 04:57:42 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:42 --> Total execution time: 0.0551
ERROR - 2023-08-11 04:57:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:43 --> Config Class Initialized
INFO - 2023-08-11 04:57:43 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:43 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:43 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:43 --> URI Class Initialized
INFO - 2023-08-11 04:57:43 --> Router Class Initialized
INFO - 2023-08-11 04:57:43 --> Output Class Initialized
INFO - 2023-08-11 04:57:43 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:43 --> Input Class Initialized
INFO - 2023-08-11 04:57:43 --> Language Class Initialized
INFO - 2023-08-11 04:57:43 --> Loader Class Initialized
INFO - 2023-08-11 04:57:43 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:43 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:43 --> Parser Class Initialized
INFO - 2023-08-11 04:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:43 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:43 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:43 --> Controller Class Initialized
INFO - 2023-08-11 04:57:43 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:43 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:43 --> Model Class Initialized
INFO - 2023-08-11 04:57:43 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:43 --> Total execution time: 0.0573
ERROR - 2023-08-11 04:57:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:43 --> Config Class Initialized
INFO - 2023-08-11 04:57:43 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:43 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:43 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:43 --> URI Class Initialized
INFO - 2023-08-11 04:57:43 --> Router Class Initialized
INFO - 2023-08-11 04:57:43 --> Output Class Initialized
INFO - 2023-08-11 04:57:43 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:43 --> Input Class Initialized
INFO - 2023-08-11 04:57:43 --> Language Class Initialized
INFO - 2023-08-11 04:57:43 --> Loader Class Initialized
INFO - 2023-08-11 04:57:43 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:43 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:43 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:43 --> Parser Class Initialized
INFO - 2023-08-11 04:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:43 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:43 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:43 --> Controller Class Initialized
INFO - 2023-08-11 04:57:43 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:43 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:43 --> Model Class Initialized
INFO - 2023-08-11 04:57:43 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:43 --> Total execution time: 0.0197
ERROR - 2023-08-11 04:57:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:45 --> Config Class Initialized
INFO - 2023-08-11 04:57:45 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:45 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:45 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:45 --> URI Class Initialized
INFO - 2023-08-11 04:57:45 --> Router Class Initialized
INFO - 2023-08-11 04:57:45 --> Output Class Initialized
INFO - 2023-08-11 04:57:45 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:45 --> Input Class Initialized
INFO - 2023-08-11 04:57:45 --> Language Class Initialized
INFO - 2023-08-11 04:57:45 --> Loader Class Initialized
INFO - 2023-08-11 04:57:45 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:45 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:45 --> Parser Class Initialized
INFO - 2023-08-11 04:57:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:45 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:45 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:45 --> Controller Class Initialized
INFO - 2023-08-11 04:57:45 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:45 --> Model Class Initialized
INFO - 2023-08-11 04:57:45 --> Model Class Initialized
ERROR - 2023-08-11 04:57:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:45 --> Config Class Initialized
INFO - 2023-08-11 04:57:45 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:45 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:45 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:45 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:45 --> Total execution time: 0.0238
INFO - 2023-08-11 04:57:45 --> URI Class Initialized
INFO - 2023-08-11 04:57:45 --> Router Class Initialized
INFO - 2023-08-11 04:57:45 --> Output Class Initialized
INFO - 2023-08-11 04:57:45 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:45 --> Input Class Initialized
INFO - 2023-08-11 04:57:45 --> Language Class Initialized
INFO - 2023-08-11 04:57:45 --> Loader Class Initialized
INFO - 2023-08-11 04:57:45 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:45 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:45 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:45 --> Parser Class Initialized
INFO - 2023-08-11 04:57:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:45 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:45 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:45 --> Controller Class Initialized
INFO - 2023-08-11 04:57:45 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:45 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:45 --> Model Class Initialized
INFO - 2023-08-11 04:57:45 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:45 --> Total execution time: 0.0222
ERROR - 2023-08-11 04:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:48 --> Config Class Initialized
INFO - 2023-08-11 04:57:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:48 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:48 --> URI Class Initialized
INFO - 2023-08-11 04:57:48 --> Router Class Initialized
INFO - 2023-08-11 04:57:48 --> Output Class Initialized
INFO - 2023-08-11 04:57:48 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:48 --> Input Class Initialized
INFO - 2023-08-11 04:57:48 --> Language Class Initialized
INFO - 2023-08-11 04:57:48 --> Loader Class Initialized
INFO - 2023-08-11 04:57:48 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:48 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:48 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:48 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:48 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:48 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:48 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:48 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:48 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:48 --> Parser Class Initialized
INFO - 2023-08-11 04:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:48 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:48 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:48 --> Controller Class Initialized
INFO - 2023-08-11 04:57:48 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:48 --> Model Class Initialized
INFO - 2023-08-11 04:57:48 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:48 --> Total execution time: 0.0168
ERROR - 2023-08-11 04:57:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:57:57 --> Config Class Initialized
INFO - 2023-08-11 04:57:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:57:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:57:57 --> Utf8 Class Initialized
INFO - 2023-08-11 04:57:57 --> URI Class Initialized
INFO - 2023-08-11 04:57:57 --> Router Class Initialized
INFO - 2023-08-11 04:57:57 --> Output Class Initialized
INFO - 2023-08-11 04:57:57 --> Security Class Initialized
DEBUG - 2023-08-11 04:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:57:57 --> Input Class Initialized
INFO - 2023-08-11 04:57:57 --> Language Class Initialized
INFO - 2023-08-11 04:57:57 --> Loader Class Initialized
INFO - 2023-08-11 04:57:57 --> Helper loaded: url_helper
INFO - 2023-08-11 04:57:57 --> Helper loaded: file_helper
INFO - 2023-08-11 04:57:57 --> Helper loaded: html_helper
INFO - 2023-08-11 04:57:57 --> Helper loaded: text_helper
INFO - 2023-08-11 04:57:57 --> Helper loaded: form_helper
INFO - 2023-08-11 04:57:57 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:57:57 --> Helper loaded: security_helper
INFO - 2023-08-11 04:57:57 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:57:57 --> Database Driver Class Initialized
INFO - 2023-08-11 04:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:57:57 --> Parser Class Initialized
INFO - 2023-08-11 04:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:57:57 --> Pagination Class Initialized
INFO - 2023-08-11 04:57:57 --> Form Validation Class Initialized
INFO - 2023-08-11 04:57:57 --> Controller Class Initialized
INFO - 2023-08-11 04:57:57 --> Model Class Initialized
DEBUG - 2023-08-11 04:57:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:57:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:57:57 --> Model Class Initialized
INFO - 2023-08-11 04:57:57 --> Final output sent to browser
DEBUG - 2023-08-11 04:57:57 --> Total execution time: 0.0205
ERROR - 2023-08-11 04:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:04 --> Config Class Initialized
INFO - 2023-08-11 04:58:04 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:04 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:04 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:04 --> URI Class Initialized
INFO - 2023-08-11 04:58:04 --> Router Class Initialized
INFO - 2023-08-11 04:58:04 --> Output Class Initialized
INFO - 2023-08-11 04:58:04 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:04 --> Input Class Initialized
INFO - 2023-08-11 04:58:04 --> Language Class Initialized
INFO - 2023-08-11 04:58:04 --> Loader Class Initialized
INFO - 2023-08-11 04:58:04 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:04 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:04 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:04 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:04 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:04 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:04 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:04 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:04 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:04 --> Parser Class Initialized
INFO - 2023-08-11 04:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:04 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:04 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:04 --> Controller Class Initialized
INFO - 2023-08-11 04:58:04 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:04 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:04 --> Model Class Initialized
INFO - 2023-08-11 04:58:04 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:04 --> Total execution time: 0.0544
ERROR - 2023-08-11 04:58:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:07 --> Config Class Initialized
INFO - 2023-08-11 04:58:07 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:07 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:07 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:07 --> URI Class Initialized
INFO - 2023-08-11 04:58:07 --> Router Class Initialized
INFO - 2023-08-11 04:58:07 --> Output Class Initialized
INFO - 2023-08-11 04:58:07 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:07 --> Input Class Initialized
INFO - 2023-08-11 04:58:07 --> Language Class Initialized
INFO - 2023-08-11 04:58:07 --> Loader Class Initialized
INFO - 2023-08-11 04:58:07 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:07 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:07 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:07 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:07 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:07 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:07 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:07 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:07 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:07 --> Parser Class Initialized
INFO - 2023-08-11 04:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:07 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:07 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:07 --> Controller Class Initialized
INFO - 2023-08-11 04:58:07 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:07 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:07 --> Model Class Initialized
INFO - 2023-08-11 04:58:07 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:07 --> Total execution time: 0.0205
ERROR - 2023-08-11 04:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:09 --> Config Class Initialized
INFO - 2023-08-11 04:58:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:09 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:09 --> URI Class Initialized
INFO - 2023-08-11 04:58:09 --> Router Class Initialized
INFO - 2023-08-11 04:58:09 --> Output Class Initialized
INFO - 2023-08-11 04:58:09 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:09 --> Input Class Initialized
INFO - 2023-08-11 04:58:09 --> Language Class Initialized
INFO - 2023-08-11 04:58:09 --> Loader Class Initialized
INFO - 2023-08-11 04:58:09 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:09 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:09 --> Parser Class Initialized
INFO - 2023-08-11 04:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:09 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:09 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:09 --> Controller Class Initialized
INFO - 2023-08-11 04:58:09 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:09 --> Model Class Initialized
INFO - 2023-08-11 04:58:09 --> Model Class Initialized
INFO - 2023-08-11 04:58:09 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:09 --> Total execution time: 0.0199
ERROR - 2023-08-11 04:58:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:09 --> Config Class Initialized
INFO - 2023-08-11 04:58:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:09 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:09 --> URI Class Initialized
INFO - 2023-08-11 04:58:09 --> Router Class Initialized
INFO - 2023-08-11 04:58:09 --> Output Class Initialized
INFO - 2023-08-11 04:58:09 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:09 --> Input Class Initialized
INFO - 2023-08-11 04:58:09 --> Language Class Initialized
INFO - 2023-08-11 04:58:09 --> Loader Class Initialized
INFO - 2023-08-11 04:58:09 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:09 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:09 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:09 --> Parser Class Initialized
INFO - 2023-08-11 04:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:09 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:09 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:09 --> Controller Class Initialized
INFO - 2023-08-11 04:58:09 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:09 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:09 --> Model Class Initialized
INFO - 2023-08-11 04:58:09 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:09 --> Total execution time: 0.0187
ERROR - 2023-08-11 04:58:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:12 --> Config Class Initialized
INFO - 2023-08-11 04:58:12 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:12 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:12 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:12 --> URI Class Initialized
INFO - 2023-08-11 04:58:12 --> Router Class Initialized
INFO - 2023-08-11 04:58:12 --> Output Class Initialized
INFO - 2023-08-11 04:58:12 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:12 --> Input Class Initialized
INFO - 2023-08-11 04:58:12 --> Language Class Initialized
INFO - 2023-08-11 04:58:12 --> Loader Class Initialized
INFO - 2023-08-11 04:58:12 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:12 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:12 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:12 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:12 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:12 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:12 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:12 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:12 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:12 --> Parser Class Initialized
INFO - 2023-08-11 04:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:12 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:12 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:12 --> Controller Class Initialized
INFO - 2023-08-11 04:58:12 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:12 --> Model Class Initialized
INFO - 2023-08-11 04:58:12 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:12 --> Total execution time: 0.0159
ERROR - 2023-08-11 04:58:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:22 --> Config Class Initialized
INFO - 2023-08-11 04:58:22 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:22 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:22 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:22 --> URI Class Initialized
INFO - 2023-08-11 04:58:22 --> Router Class Initialized
INFO - 2023-08-11 04:58:22 --> Output Class Initialized
INFO - 2023-08-11 04:58:22 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:22 --> Input Class Initialized
INFO - 2023-08-11 04:58:22 --> Language Class Initialized
INFO - 2023-08-11 04:58:22 --> Loader Class Initialized
INFO - 2023-08-11 04:58:22 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:22 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:22 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:22 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:22 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:22 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:22 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:22 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:22 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:22 --> Parser Class Initialized
INFO - 2023-08-11 04:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:22 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:22 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:22 --> Controller Class Initialized
INFO - 2023-08-11 04:58:22 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:22 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:22 --> Model Class Initialized
INFO - 2023-08-11 04:58:22 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:22 --> Total execution time: 0.0197
ERROR - 2023-08-11 04:58:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:24 --> Config Class Initialized
INFO - 2023-08-11 04:58:24 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:24 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:24 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:24 --> URI Class Initialized
INFO - 2023-08-11 04:58:24 --> Router Class Initialized
INFO - 2023-08-11 04:58:24 --> Output Class Initialized
INFO - 2023-08-11 04:58:24 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:24 --> Input Class Initialized
INFO - 2023-08-11 04:58:24 --> Language Class Initialized
INFO - 2023-08-11 04:58:24 --> Loader Class Initialized
INFO - 2023-08-11 04:58:24 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:24 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:24 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:24 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:24 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:24 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:24 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:24 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:24 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:24 --> Parser Class Initialized
INFO - 2023-08-11 04:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:24 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:24 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:24 --> Controller Class Initialized
INFO - 2023-08-11 04:58:24 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:24 --> Model Class Initialized
INFO - 2023-08-11 04:58:24 --> Model Class Initialized
INFO - 2023-08-11 04:58:24 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:24 --> Total execution time: 0.0226
ERROR - 2023-08-11 04:58:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:27 --> Config Class Initialized
INFO - 2023-08-11 04:58:27 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:27 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:27 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:27 --> URI Class Initialized
INFO - 2023-08-11 04:58:27 --> Router Class Initialized
INFO - 2023-08-11 04:58:27 --> Output Class Initialized
INFO - 2023-08-11 04:58:27 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:27 --> Input Class Initialized
INFO - 2023-08-11 04:58:27 --> Language Class Initialized
INFO - 2023-08-11 04:58:27 --> Loader Class Initialized
INFO - 2023-08-11 04:58:27 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:27 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:27 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:27 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:27 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:27 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:27 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:27 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:27 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:27 --> Parser Class Initialized
INFO - 2023-08-11 04:58:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:27 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:27 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:27 --> Controller Class Initialized
INFO - 2023-08-11 04:58:27 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:27 --> Model Class Initialized
INFO - 2023-08-11 04:58:27 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:27 --> Total execution time: 0.0197
ERROR - 2023-08-11 04:58:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:34 --> Config Class Initialized
INFO - 2023-08-11 04:58:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:34 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:34 --> URI Class Initialized
INFO - 2023-08-11 04:58:34 --> Router Class Initialized
INFO - 2023-08-11 04:58:34 --> Output Class Initialized
INFO - 2023-08-11 04:58:34 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:34 --> Input Class Initialized
INFO - 2023-08-11 04:58:34 --> Language Class Initialized
INFO - 2023-08-11 04:58:34 --> Loader Class Initialized
INFO - 2023-08-11 04:58:34 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:34 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:34 --> Parser Class Initialized
INFO - 2023-08-11 04:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:34 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:34 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:34 --> Controller Class Initialized
INFO - 2023-08-11 04:58:34 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:34 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:34 --> Model Class Initialized
INFO - 2023-08-11 04:58:34 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:34 --> Total execution time: 0.0203
ERROR - 2023-08-11 04:58:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:34 --> Config Class Initialized
INFO - 2023-08-11 04:58:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:34 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:34 --> URI Class Initialized
INFO - 2023-08-11 04:58:34 --> Router Class Initialized
INFO - 2023-08-11 04:58:34 --> Output Class Initialized
INFO - 2023-08-11 04:58:34 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:34 --> Input Class Initialized
INFO - 2023-08-11 04:58:34 --> Language Class Initialized
INFO - 2023-08-11 04:58:34 --> Loader Class Initialized
INFO - 2023-08-11 04:58:34 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:34 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:34 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:34 --> Parser Class Initialized
INFO - 2023-08-11 04:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:34 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:34 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:34 --> Controller Class Initialized
INFO - 2023-08-11 04:58:34 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:34 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:34 --> Model Class Initialized
INFO - 2023-08-11 04:58:34 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:34 --> Total execution time: 0.0194
ERROR - 2023-08-11 04:58:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:35 --> Config Class Initialized
INFO - 2023-08-11 04:58:35 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:35 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:35 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:35 --> URI Class Initialized
INFO - 2023-08-11 04:58:35 --> Router Class Initialized
INFO - 2023-08-11 04:58:35 --> Output Class Initialized
INFO - 2023-08-11 04:58:35 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:35 --> Input Class Initialized
INFO - 2023-08-11 04:58:35 --> Language Class Initialized
INFO - 2023-08-11 04:58:35 --> Loader Class Initialized
INFO - 2023-08-11 04:58:35 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:35 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:35 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:35 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:35 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:35 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:35 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:35 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:35 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:35 --> Parser Class Initialized
INFO - 2023-08-11 04:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:35 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:35 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:35 --> Controller Class Initialized
INFO - 2023-08-11 04:58:35 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:35 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:35 --> Model Class Initialized
INFO - 2023-08-11 04:58:35 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:35 --> Total execution time: 0.0205
ERROR - 2023-08-11 04:58:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:36 --> Config Class Initialized
INFO - 2023-08-11 04:58:36 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:36 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:36 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:36 --> URI Class Initialized
INFO - 2023-08-11 04:58:36 --> Router Class Initialized
INFO - 2023-08-11 04:58:36 --> Output Class Initialized
INFO - 2023-08-11 04:58:36 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:36 --> Input Class Initialized
INFO - 2023-08-11 04:58:36 --> Language Class Initialized
INFO - 2023-08-11 04:58:36 --> Loader Class Initialized
INFO - 2023-08-11 04:58:36 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:36 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:36 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:36 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:36 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:36 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:36 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:36 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:36 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:36 --> Parser Class Initialized
INFO - 2023-08-11 04:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:36 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:36 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:36 --> Controller Class Initialized
INFO - 2023-08-11 04:58:36 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:36 --> Model Class Initialized
INFO - 2023-08-11 04:58:36 --> Model Class Initialized
INFO - 2023-08-11 04:58:36 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:36 --> Total execution time: 0.0191
ERROR - 2023-08-11 04:58:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:38 --> Config Class Initialized
INFO - 2023-08-11 04:58:38 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:38 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:38 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:38 --> URI Class Initialized
INFO - 2023-08-11 04:58:38 --> Router Class Initialized
INFO - 2023-08-11 04:58:38 --> Output Class Initialized
INFO - 2023-08-11 04:58:38 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:38 --> Input Class Initialized
INFO - 2023-08-11 04:58:38 --> Language Class Initialized
INFO - 2023-08-11 04:58:38 --> Loader Class Initialized
INFO - 2023-08-11 04:58:38 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:38 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:38 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:38 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:38 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:38 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:38 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:38 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:38 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:38 --> Parser Class Initialized
INFO - 2023-08-11 04:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:38 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:38 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:38 --> Controller Class Initialized
INFO - 2023-08-11 04:58:38 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:38 --> Model Class Initialized
INFO - 2023-08-11 04:58:38 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:38 --> Total execution time: 0.0172
ERROR - 2023-08-11 04:58:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:58 --> Config Class Initialized
INFO - 2023-08-11 04:58:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:58 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:58 --> URI Class Initialized
INFO - 2023-08-11 04:58:58 --> Router Class Initialized
INFO - 2023-08-11 04:58:58 --> Output Class Initialized
INFO - 2023-08-11 04:58:58 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:58 --> Input Class Initialized
INFO - 2023-08-11 04:58:58 --> Language Class Initialized
INFO - 2023-08-11 04:58:58 --> Loader Class Initialized
INFO - 2023-08-11 04:58:58 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:58 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:58 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:58 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:58 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:58 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:58 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:58 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:58 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:58 --> Parser Class Initialized
INFO - 2023-08-11 04:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:58 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:58 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:58 --> Controller Class Initialized
INFO - 2023-08-11 04:58:58 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:58 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:58 --> Model Class Initialized
INFO - 2023-08-11 04:58:58 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:58 --> Total execution time: 0.0582
ERROR - 2023-08-11 04:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:58:59 --> Config Class Initialized
INFO - 2023-08-11 04:58:59 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:58:59 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:58:59 --> Utf8 Class Initialized
INFO - 2023-08-11 04:58:59 --> URI Class Initialized
INFO - 2023-08-11 04:58:59 --> Router Class Initialized
INFO - 2023-08-11 04:58:59 --> Output Class Initialized
INFO - 2023-08-11 04:58:59 --> Security Class Initialized
DEBUG - 2023-08-11 04:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:58:59 --> Input Class Initialized
INFO - 2023-08-11 04:58:59 --> Language Class Initialized
INFO - 2023-08-11 04:58:59 --> Loader Class Initialized
INFO - 2023-08-11 04:58:59 --> Helper loaded: url_helper
INFO - 2023-08-11 04:58:59 --> Helper loaded: file_helper
INFO - 2023-08-11 04:58:59 --> Helper loaded: html_helper
INFO - 2023-08-11 04:58:59 --> Helper loaded: text_helper
INFO - 2023-08-11 04:58:59 --> Helper loaded: form_helper
INFO - 2023-08-11 04:58:59 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:58:59 --> Helper loaded: security_helper
INFO - 2023-08-11 04:58:59 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:58:59 --> Database Driver Class Initialized
INFO - 2023-08-11 04:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:58:59 --> Parser Class Initialized
INFO - 2023-08-11 04:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:58:59 --> Pagination Class Initialized
INFO - 2023-08-11 04:58:59 --> Form Validation Class Initialized
INFO - 2023-08-11 04:58:59 --> Controller Class Initialized
INFO - 2023-08-11 04:58:59 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:59 --> Model Class Initialized
DEBUG - 2023-08-11 04:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:58:59 --> Model Class Initialized
INFO - 2023-08-11 04:58:59 --> Final output sent to browser
DEBUG - 2023-08-11 04:58:59 --> Total execution time: 0.0655
ERROR - 2023-08-11 04:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:00 --> Config Class Initialized
INFO - 2023-08-11 04:59:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:00 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:00 --> URI Class Initialized
INFO - 2023-08-11 04:59:00 --> Router Class Initialized
INFO - 2023-08-11 04:59:00 --> Output Class Initialized
INFO - 2023-08-11 04:59:00 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:00 --> Input Class Initialized
INFO - 2023-08-11 04:59:00 --> Language Class Initialized
INFO - 2023-08-11 04:59:00 --> Loader Class Initialized
INFO - 2023-08-11 04:59:00 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:00 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:00 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:00 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:00 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:00 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:00 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:00 --> Parser Class Initialized
INFO - 2023-08-11 04:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:00 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:00 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:00 --> Controller Class Initialized
INFO - 2023-08-11 04:59:00 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:00 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:00 --> Model Class Initialized
INFO - 2023-08-11 04:59:00 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:00 --> Total execution time: 0.0322
ERROR - 2023-08-11 04:59:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:03 --> Config Class Initialized
INFO - 2023-08-11 04:59:03 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:03 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:03 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:03 --> URI Class Initialized
INFO - 2023-08-11 04:59:03 --> Router Class Initialized
INFO - 2023-08-11 04:59:03 --> Output Class Initialized
INFO - 2023-08-11 04:59:03 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:03 --> Input Class Initialized
INFO - 2023-08-11 04:59:03 --> Language Class Initialized
INFO - 2023-08-11 04:59:03 --> Loader Class Initialized
INFO - 2023-08-11 04:59:03 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:03 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:03 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:03 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:03 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:03 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:03 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:03 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:03 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:03 --> Parser Class Initialized
INFO - 2023-08-11 04:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:03 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:03 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:03 --> Controller Class Initialized
INFO - 2023-08-11 04:59:03 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:03 --> Model Class Initialized
INFO - 2023-08-11 04:59:03 --> Model Class Initialized
INFO - 2023-08-11 04:59:03 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:03 --> Total execution time: 0.0200
ERROR - 2023-08-11 04:59:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:05 --> Config Class Initialized
INFO - 2023-08-11 04:59:05 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:05 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:05 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:05 --> URI Class Initialized
INFO - 2023-08-11 04:59:05 --> Router Class Initialized
INFO - 2023-08-11 04:59:05 --> Output Class Initialized
INFO - 2023-08-11 04:59:05 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:05 --> Input Class Initialized
INFO - 2023-08-11 04:59:05 --> Language Class Initialized
INFO - 2023-08-11 04:59:05 --> Loader Class Initialized
INFO - 2023-08-11 04:59:05 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:05 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:05 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:05 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:05 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:05 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:05 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:05 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:05 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:05 --> Parser Class Initialized
INFO - 2023-08-11 04:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:05 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:05 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:05 --> Controller Class Initialized
INFO - 2023-08-11 04:59:05 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:05 --> Model Class Initialized
INFO - 2023-08-11 04:59:05 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:05 --> Total execution time: 0.0161
ERROR - 2023-08-11 04:59:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:13 --> Config Class Initialized
INFO - 2023-08-11 04:59:13 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:13 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:13 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:13 --> URI Class Initialized
INFO - 2023-08-11 04:59:13 --> Router Class Initialized
INFO - 2023-08-11 04:59:13 --> Output Class Initialized
INFO - 2023-08-11 04:59:13 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:13 --> Input Class Initialized
INFO - 2023-08-11 04:59:13 --> Language Class Initialized
INFO - 2023-08-11 04:59:13 --> Loader Class Initialized
INFO - 2023-08-11 04:59:13 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:13 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:13 --> Parser Class Initialized
INFO - 2023-08-11 04:59:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:13 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:13 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:13 --> Controller Class Initialized
INFO - 2023-08-11 04:59:13 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:13 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:13 --> Model Class Initialized
INFO - 2023-08-11 04:59:13 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:13 --> Total execution time: 0.0626
ERROR - 2023-08-11 04:59:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:13 --> Config Class Initialized
INFO - 2023-08-11 04:59:13 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:13 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:13 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:13 --> URI Class Initialized
INFO - 2023-08-11 04:59:13 --> Router Class Initialized
INFO - 2023-08-11 04:59:13 --> Output Class Initialized
INFO - 2023-08-11 04:59:13 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:13 --> Input Class Initialized
INFO - 2023-08-11 04:59:13 --> Language Class Initialized
INFO - 2023-08-11 04:59:13 --> Loader Class Initialized
INFO - 2023-08-11 04:59:13 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:13 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:13 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:13 --> Parser Class Initialized
INFO - 2023-08-11 04:59:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:13 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:13 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:13 --> Controller Class Initialized
INFO - 2023-08-11 04:59:13 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:13 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:13 --> Model Class Initialized
INFO - 2023-08-11 04:59:13 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:13 --> Total execution time: 0.0549
ERROR - 2023-08-11 04:59:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:14 --> Config Class Initialized
INFO - 2023-08-11 04:59:14 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:14 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:14 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:14 --> URI Class Initialized
INFO - 2023-08-11 04:59:14 --> Router Class Initialized
INFO - 2023-08-11 04:59:14 --> Output Class Initialized
INFO - 2023-08-11 04:59:14 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:14 --> Input Class Initialized
INFO - 2023-08-11 04:59:14 --> Language Class Initialized
INFO - 2023-08-11 04:59:14 --> Loader Class Initialized
INFO - 2023-08-11 04:59:14 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:14 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:14 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:14 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:14 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:14 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:14 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:14 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:14 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:14 --> Parser Class Initialized
INFO - 2023-08-11 04:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:14 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:14 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:14 --> Controller Class Initialized
INFO - 2023-08-11 04:59:14 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:14 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:14 --> Model Class Initialized
INFO - 2023-08-11 04:59:14 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:14 --> Total execution time: 0.0282
ERROR - 2023-08-11 04:59:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:16 --> Config Class Initialized
INFO - 2023-08-11 04:59:16 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:16 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:16 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:16 --> URI Class Initialized
INFO - 2023-08-11 04:59:16 --> Router Class Initialized
INFO - 2023-08-11 04:59:16 --> Output Class Initialized
INFO - 2023-08-11 04:59:16 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:16 --> Input Class Initialized
INFO - 2023-08-11 04:59:16 --> Language Class Initialized
INFO - 2023-08-11 04:59:16 --> Loader Class Initialized
INFO - 2023-08-11 04:59:16 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:16 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:16 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:16 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:16 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:16 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:16 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:16 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:16 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:16 --> Parser Class Initialized
INFO - 2023-08-11 04:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:16 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:16 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:16 --> Controller Class Initialized
INFO - 2023-08-11 04:59:16 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:16 --> Model Class Initialized
INFO - 2023-08-11 04:59:16 --> Model Class Initialized
INFO - 2023-08-11 04:59:16 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:16 --> Total execution time: 0.0200
ERROR - 2023-08-11 04:59:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:18 --> Config Class Initialized
INFO - 2023-08-11 04:59:18 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:18 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:18 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:18 --> URI Class Initialized
INFO - 2023-08-11 04:59:18 --> Router Class Initialized
INFO - 2023-08-11 04:59:18 --> Output Class Initialized
INFO - 2023-08-11 04:59:18 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:18 --> Input Class Initialized
INFO - 2023-08-11 04:59:18 --> Language Class Initialized
INFO - 2023-08-11 04:59:18 --> Loader Class Initialized
INFO - 2023-08-11 04:59:18 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:18 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:18 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:18 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:18 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:18 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:18 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:18 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:18 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:18 --> Parser Class Initialized
INFO - 2023-08-11 04:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:18 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:18 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:18 --> Controller Class Initialized
INFO - 2023-08-11 04:59:18 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:18 --> Model Class Initialized
INFO - 2023-08-11 04:59:18 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:18 --> Total execution time: 0.0168
ERROR - 2023-08-11 04:59:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:29 --> Config Class Initialized
INFO - 2023-08-11 04:59:29 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:29 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:29 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:29 --> URI Class Initialized
INFO - 2023-08-11 04:59:29 --> Router Class Initialized
INFO - 2023-08-11 04:59:29 --> Output Class Initialized
INFO - 2023-08-11 04:59:29 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:29 --> Input Class Initialized
INFO - 2023-08-11 04:59:29 --> Language Class Initialized
INFO - 2023-08-11 04:59:29 --> Loader Class Initialized
INFO - 2023-08-11 04:59:29 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:29 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:29 --> Parser Class Initialized
INFO - 2023-08-11 04:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:29 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:29 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:29 --> Controller Class Initialized
INFO - 2023-08-11 04:59:29 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:29 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:29 --> Model Class Initialized
INFO - 2023-08-11 04:59:29 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:29 --> Total execution time: 0.0695
ERROR - 2023-08-11 04:59:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:29 --> Config Class Initialized
INFO - 2023-08-11 04:59:29 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:29 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:29 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:29 --> URI Class Initialized
INFO - 2023-08-11 04:59:29 --> Router Class Initialized
INFO - 2023-08-11 04:59:29 --> Output Class Initialized
INFO - 2023-08-11 04:59:29 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:29 --> Input Class Initialized
INFO - 2023-08-11 04:59:29 --> Language Class Initialized
INFO - 2023-08-11 04:59:29 --> Loader Class Initialized
INFO - 2023-08-11 04:59:29 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:29 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:29 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:29 --> Parser Class Initialized
INFO - 2023-08-11 04:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:29 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:29 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:29 --> Controller Class Initialized
INFO - 2023-08-11 04:59:29 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:29 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:29 --> Model Class Initialized
INFO - 2023-08-11 04:59:29 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:29 --> Total execution time: 0.0223
ERROR - 2023-08-11 04:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:30 --> Config Class Initialized
INFO - 2023-08-11 04:59:30 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:30 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:30 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:30 --> URI Class Initialized
INFO - 2023-08-11 04:59:30 --> Router Class Initialized
INFO - 2023-08-11 04:59:30 --> Output Class Initialized
INFO - 2023-08-11 04:59:30 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:30 --> Input Class Initialized
INFO - 2023-08-11 04:59:30 --> Language Class Initialized
INFO - 2023-08-11 04:59:30 --> Loader Class Initialized
INFO - 2023-08-11 04:59:30 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:30 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:30 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:30 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:30 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:30 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:30 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:30 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:30 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:30 --> Parser Class Initialized
INFO - 2023-08-11 04:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:30 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:30 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:30 --> Controller Class Initialized
INFO - 2023-08-11 04:59:30 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:30 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:30 --> Model Class Initialized
INFO - 2023-08-11 04:59:30 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:30 --> Total execution time: 0.0538
ERROR - 2023-08-11 04:59:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:31 --> Config Class Initialized
INFO - 2023-08-11 04:59:31 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:31 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:31 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:31 --> URI Class Initialized
INFO - 2023-08-11 04:59:31 --> Router Class Initialized
INFO - 2023-08-11 04:59:31 --> Output Class Initialized
INFO - 2023-08-11 04:59:31 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:31 --> Input Class Initialized
INFO - 2023-08-11 04:59:31 --> Language Class Initialized
INFO - 2023-08-11 04:59:31 --> Loader Class Initialized
INFO - 2023-08-11 04:59:31 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:31 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:31 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:31 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:31 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:31 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:31 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:31 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:31 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:31 --> Parser Class Initialized
INFO - 2023-08-11 04:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:31 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:31 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:31 --> Controller Class Initialized
INFO - 2023-08-11 04:59:31 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:31 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:31 --> Model Class Initialized
INFO - 2023-08-11 04:59:31 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:31 --> Total execution time: 0.0582
ERROR - 2023-08-11 04:59:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:35 --> Config Class Initialized
INFO - 2023-08-11 04:59:35 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:35 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:35 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:35 --> URI Class Initialized
INFO - 2023-08-11 04:59:35 --> Router Class Initialized
INFO - 2023-08-11 04:59:35 --> Output Class Initialized
INFO - 2023-08-11 04:59:35 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:35 --> Input Class Initialized
INFO - 2023-08-11 04:59:35 --> Language Class Initialized
INFO - 2023-08-11 04:59:35 --> Loader Class Initialized
INFO - 2023-08-11 04:59:35 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:35 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:35 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:35 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:35 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:35 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:35 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:35 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:35 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:35 --> Parser Class Initialized
INFO - 2023-08-11 04:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:35 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:35 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:35 --> Controller Class Initialized
INFO - 2023-08-11 04:59:35 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:35 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:35 --> Model Class Initialized
INFO - 2023-08-11 04:59:35 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:35 --> Total execution time: 0.0241
ERROR - 2023-08-11 04:59:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:41 --> Config Class Initialized
INFO - 2023-08-11 04:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:41 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:41 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:41 --> URI Class Initialized
INFO - 2023-08-11 04:59:41 --> Router Class Initialized
INFO - 2023-08-11 04:59:41 --> Output Class Initialized
INFO - 2023-08-11 04:59:41 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:41 --> Input Class Initialized
INFO - 2023-08-11 04:59:41 --> Language Class Initialized
INFO - 2023-08-11 04:59:41 --> Loader Class Initialized
INFO - 2023-08-11 04:59:41 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: lang_helper
ERROR - 2023-08-11 04:59:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:41 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:41 --> Config Class Initialized
INFO - 2023-08-11 04:59:41 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:41 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:41 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:41 --> URI Class Initialized
INFO - 2023-08-11 04:59:41 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:41 --> Router Class Initialized
INFO - 2023-08-11 04:59:41 --> Output Class Initialized
INFO - 2023-08-11 04:59:41 --> Security Class Initialized
INFO - 2023-08-11 04:59:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2023-08-11 04:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:41 --> Parser Class Initialized
INFO - 2023-08-11 04:59:41 --> Input Class Initialized
INFO - 2023-08-11 04:59:41 --> Language Class Initialized
INFO - 2023-08-11 04:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:41 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:41 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:41 --> Controller Class Initialized
INFO - 2023-08-11 04:59:41 --> Loader Class Initialized
INFO - 2023-08-11 04:59:41 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:41 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:41 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:41 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:41 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:41 --> Model Class Initialized
INFO - 2023-08-11 04:59:41 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:41 --> Total execution time: 0.0184
INFO - 2023-08-11 04:59:41 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:41 --> Parser Class Initialized
INFO - 2023-08-11 04:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:41 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:41 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:41 --> Controller Class Initialized
INFO - 2023-08-11 04:59:41 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:41 --> Model Class Initialized
INFO - 2023-08-11 04:59:41 --> Model Class Initialized
INFO - 2023-08-11 04:59:41 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:41 --> Total execution time: 0.0249
ERROR - 2023-08-11 04:59:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:44 --> Config Class Initialized
INFO - 2023-08-11 04:59:44 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:44 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:44 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:44 --> URI Class Initialized
INFO - 2023-08-11 04:59:44 --> Router Class Initialized
INFO - 2023-08-11 04:59:44 --> Output Class Initialized
INFO - 2023-08-11 04:59:44 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:44 --> Input Class Initialized
INFO - 2023-08-11 04:59:44 --> Language Class Initialized
INFO - 2023-08-11 04:59:44 --> Loader Class Initialized
INFO - 2023-08-11 04:59:44 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:44 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:44 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:44 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:44 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:44 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:44 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:44 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:44 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:44 --> Parser Class Initialized
INFO - 2023-08-11 04:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:44 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:44 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:44 --> Controller Class Initialized
INFO - 2023-08-11 04:59:44 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:44 --> Model Class Initialized
INFO - 2023-08-11 04:59:44 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:44 --> Total execution time: 0.0175
ERROR - 2023-08-11 04:59:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:56 --> Config Class Initialized
INFO - 2023-08-11 04:59:56 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:56 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:56 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:56 --> URI Class Initialized
INFO - 2023-08-11 04:59:56 --> Router Class Initialized
INFO - 2023-08-11 04:59:56 --> Output Class Initialized
INFO - 2023-08-11 04:59:56 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:56 --> Input Class Initialized
INFO - 2023-08-11 04:59:56 --> Language Class Initialized
INFO - 2023-08-11 04:59:56 --> Loader Class Initialized
INFO - 2023-08-11 04:59:56 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:56 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:56 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:56 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:56 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:56 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:56 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:56 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:56 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:56 --> Parser Class Initialized
INFO - 2023-08-11 04:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:56 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:56 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:56 --> Controller Class Initialized
INFO - 2023-08-11 04:59:56 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:56 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:56 --> Model Class Initialized
INFO - 2023-08-11 04:59:56 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:56 --> Total execution time: 0.0663
ERROR - 2023-08-11 04:59:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:57 --> Config Class Initialized
INFO - 2023-08-11 04:59:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:57 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:57 --> URI Class Initialized
INFO - 2023-08-11 04:59:57 --> Router Class Initialized
INFO - 2023-08-11 04:59:57 --> Output Class Initialized
INFO - 2023-08-11 04:59:57 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:57 --> Input Class Initialized
INFO - 2023-08-11 04:59:57 --> Language Class Initialized
INFO - 2023-08-11 04:59:57 --> Loader Class Initialized
INFO - 2023-08-11 04:59:57 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:57 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:57 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:57 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:57 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:57 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:57 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:57 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:57 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:57 --> Parser Class Initialized
INFO - 2023-08-11 04:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:57 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:57 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:57 --> Controller Class Initialized
INFO - 2023-08-11 04:59:57 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:57 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:57 --> Model Class Initialized
INFO - 2023-08-11 04:59:57 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:57 --> Total execution time: 0.0584
ERROR - 2023-08-11 04:59:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 04:59:58 --> Config Class Initialized
INFO - 2023-08-11 04:59:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 04:59:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 04:59:58 --> Utf8 Class Initialized
INFO - 2023-08-11 04:59:58 --> URI Class Initialized
INFO - 2023-08-11 04:59:58 --> Router Class Initialized
INFO - 2023-08-11 04:59:58 --> Output Class Initialized
INFO - 2023-08-11 04:59:58 --> Security Class Initialized
DEBUG - 2023-08-11 04:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 04:59:58 --> Input Class Initialized
INFO - 2023-08-11 04:59:58 --> Language Class Initialized
INFO - 2023-08-11 04:59:58 --> Loader Class Initialized
INFO - 2023-08-11 04:59:58 --> Helper loaded: url_helper
INFO - 2023-08-11 04:59:58 --> Helper loaded: file_helper
INFO - 2023-08-11 04:59:58 --> Helper loaded: html_helper
INFO - 2023-08-11 04:59:58 --> Helper loaded: text_helper
INFO - 2023-08-11 04:59:58 --> Helper loaded: form_helper
INFO - 2023-08-11 04:59:58 --> Helper loaded: lang_helper
INFO - 2023-08-11 04:59:58 --> Helper loaded: security_helper
INFO - 2023-08-11 04:59:58 --> Helper loaded: cookie_helper
INFO - 2023-08-11 04:59:58 --> Database Driver Class Initialized
INFO - 2023-08-11 04:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 04:59:58 --> Parser Class Initialized
INFO - 2023-08-11 04:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 04:59:58 --> Pagination Class Initialized
INFO - 2023-08-11 04:59:58 --> Form Validation Class Initialized
INFO - 2023-08-11 04:59:58 --> Controller Class Initialized
INFO - 2023-08-11 04:59:58 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 04:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:58 --> Model Class Initialized
DEBUG - 2023-08-11 04:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 04:59:58 --> Model Class Initialized
INFO - 2023-08-11 04:59:58 --> Final output sent to browser
DEBUG - 2023-08-11 04:59:58 --> Total execution time: 0.0265
ERROR - 2023-08-11 05:00:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:00:00 --> Config Class Initialized
INFO - 2023-08-11 05:00:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:00:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:00:00 --> Utf8 Class Initialized
INFO - 2023-08-11 05:00:00 --> URI Class Initialized
INFO - 2023-08-11 05:00:00 --> Router Class Initialized
INFO - 2023-08-11 05:00:00 --> Output Class Initialized
INFO - 2023-08-11 05:00:00 --> Security Class Initialized
DEBUG - 2023-08-11 05:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:00:00 --> Input Class Initialized
INFO - 2023-08-11 05:00:00 --> Language Class Initialized
INFO - 2023-08-11 05:00:00 --> Loader Class Initialized
INFO - 2023-08-11 05:00:00 --> Helper loaded: url_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: file_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: html_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: text_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: form_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: security_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:00:00 --> Database Driver Class Initialized
INFO - 2023-08-11 05:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:00:00 --> Parser Class Initialized
INFO - 2023-08-11 05:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:00:00 --> Pagination Class Initialized
INFO - 2023-08-11 05:00:00 --> Form Validation Class Initialized
INFO - 2023-08-11 05:00:00 --> Controller Class Initialized
INFO - 2023-08-11 05:00:00 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:00 --> Model Class Initialized
INFO - 2023-08-11 05:00:00 --> Model Class Initialized
INFO - 2023-08-11 05:00:00 --> Final output sent to browser
DEBUG - 2023-08-11 05:00:00 --> Total execution time: 0.0196
ERROR - 2023-08-11 05:00:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:00:00 --> Config Class Initialized
INFO - 2023-08-11 05:00:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:00:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:00:00 --> Utf8 Class Initialized
INFO - 2023-08-11 05:00:00 --> URI Class Initialized
INFO - 2023-08-11 05:00:00 --> Router Class Initialized
INFO - 2023-08-11 05:00:00 --> Output Class Initialized
INFO - 2023-08-11 05:00:00 --> Security Class Initialized
DEBUG - 2023-08-11 05:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:00:00 --> Input Class Initialized
INFO - 2023-08-11 05:00:00 --> Language Class Initialized
INFO - 2023-08-11 05:00:00 --> Loader Class Initialized
INFO - 2023-08-11 05:00:00 --> Helper loaded: url_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: file_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: html_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: text_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: form_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: security_helper
INFO - 2023-08-11 05:00:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:00:00 --> Database Driver Class Initialized
INFO - 2023-08-11 05:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:00:00 --> Parser Class Initialized
INFO - 2023-08-11 05:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:00:00 --> Pagination Class Initialized
INFO - 2023-08-11 05:00:00 --> Form Validation Class Initialized
INFO - 2023-08-11 05:00:00 --> Controller Class Initialized
INFO - 2023-08-11 05:00:00 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:00 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:00 --> Model Class Initialized
INFO - 2023-08-11 05:00:00 --> Final output sent to browser
DEBUG - 2023-08-11 05:00:00 --> Total execution time: 0.0225
ERROR - 2023-08-11 05:00:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:00:02 --> Config Class Initialized
INFO - 2023-08-11 05:00:02 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:00:02 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:00:02 --> Utf8 Class Initialized
INFO - 2023-08-11 05:00:02 --> URI Class Initialized
INFO - 2023-08-11 05:00:02 --> Router Class Initialized
INFO - 2023-08-11 05:00:02 --> Output Class Initialized
INFO - 2023-08-11 05:00:02 --> Security Class Initialized
DEBUG - 2023-08-11 05:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:00:02 --> Input Class Initialized
INFO - 2023-08-11 05:00:02 --> Language Class Initialized
INFO - 2023-08-11 05:00:02 --> Loader Class Initialized
INFO - 2023-08-11 05:00:02 --> Helper loaded: url_helper
INFO - 2023-08-11 05:00:02 --> Helper loaded: file_helper
INFO - 2023-08-11 05:00:02 --> Helper loaded: html_helper
INFO - 2023-08-11 05:00:02 --> Helper loaded: text_helper
INFO - 2023-08-11 05:00:02 --> Helper loaded: form_helper
INFO - 2023-08-11 05:00:02 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:00:02 --> Helper loaded: security_helper
INFO - 2023-08-11 05:00:02 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:00:02 --> Database Driver Class Initialized
INFO - 2023-08-11 05:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:00:02 --> Parser Class Initialized
INFO - 2023-08-11 05:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:00:02 --> Pagination Class Initialized
INFO - 2023-08-11 05:00:02 --> Form Validation Class Initialized
INFO - 2023-08-11 05:00:02 --> Controller Class Initialized
INFO - 2023-08-11 05:00:02 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:02 --> Model Class Initialized
INFO - 2023-08-11 05:00:02 --> Final output sent to browser
DEBUG - 2023-08-11 05:00:02 --> Total execution time: 0.0174
ERROR - 2023-08-11 05:00:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:00:46 --> Config Class Initialized
INFO - 2023-08-11 05:00:46 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:00:46 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:00:46 --> Utf8 Class Initialized
INFO - 2023-08-11 05:00:46 --> URI Class Initialized
INFO - 2023-08-11 05:00:46 --> Router Class Initialized
INFO - 2023-08-11 05:00:46 --> Output Class Initialized
INFO - 2023-08-11 05:00:46 --> Security Class Initialized
DEBUG - 2023-08-11 05:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:00:46 --> Input Class Initialized
INFO - 2023-08-11 05:00:46 --> Language Class Initialized
INFO - 2023-08-11 05:00:46 --> Loader Class Initialized
INFO - 2023-08-11 05:00:46 --> Helper loaded: url_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: file_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: html_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: text_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: form_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: security_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:00:46 --> Database Driver Class Initialized
INFO - 2023-08-11 05:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:00:46 --> Parser Class Initialized
INFO - 2023-08-11 05:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:00:46 --> Pagination Class Initialized
INFO - 2023-08-11 05:00:46 --> Form Validation Class Initialized
INFO - 2023-08-11 05:00:46 --> Controller Class Initialized
INFO - 2023-08-11 05:00:46 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:46 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:46 --> Model Class Initialized
INFO - 2023-08-11 05:00:46 --> Final output sent to browser
DEBUG - 2023-08-11 05:00:46 --> Total execution time: 0.0609
ERROR - 2023-08-11 05:00:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:00:46 --> Config Class Initialized
INFO - 2023-08-11 05:00:46 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:00:46 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:00:46 --> Utf8 Class Initialized
INFO - 2023-08-11 05:00:46 --> URI Class Initialized
INFO - 2023-08-11 05:00:46 --> Router Class Initialized
INFO - 2023-08-11 05:00:46 --> Output Class Initialized
INFO - 2023-08-11 05:00:46 --> Security Class Initialized
DEBUG - 2023-08-11 05:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:00:46 --> Input Class Initialized
INFO - 2023-08-11 05:00:46 --> Language Class Initialized
INFO - 2023-08-11 05:00:46 --> Loader Class Initialized
INFO - 2023-08-11 05:00:46 --> Helper loaded: url_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: file_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: html_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: text_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: form_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: security_helper
INFO - 2023-08-11 05:00:46 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:00:46 --> Database Driver Class Initialized
INFO - 2023-08-11 05:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:00:46 --> Parser Class Initialized
INFO - 2023-08-11 05:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:00:46 --> Pagination Class Initialized
INFO - 2023-08-11 05:00:46 --> Form Validation Class Initialized
INFO - 2023-08-11 05:00:46 --> Controller Class Initialized
INFO - 2023-08-11 05:00:46 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:46 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:46 --> Model Class Initialized
INFO - 2023-08-11 05:00:46 --> Final output sent to browser
DEBUG - 2023-08-11 05:00:46 --> Total execution time: 0.0535
ERROR - 2023-08-11 05:00:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:00:50 --> Config Class Initialized
INFO - 2023-08-11 05:00:50 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:00:50 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:00:50 --> Utf8 Class Initialized
INFO - 2023-08-11 05:00:50 --> URI Class Initialized
INFO - 2023-08-11 05:00:50 --> Router Class Initialized
INFO - 2023-08-11 05:00:50 --> Output Class Initialized
INFO - 2023-08-11 05:00:50 --> Security Class Initialized
DEBUG - 2023-08-11 05:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:00:50 --> Input Class Initialized
INFO - 2023-08-11 05:00:50 --> Language Class Initialized
INFO - 2023-08-11 05:00:50 --> Loader Class Initialized
INFO - 2023-08-11 05:00:50 --> Helper loaded: url_helper
INFO - 2023-08-11 05:00:50 --> Helper loaded: file_helper
INFO - 2023-08-11 05:00:50 --> Helper loaded: html_helper
INFO - 2023-08-11 05:00:50 --> Helper loaded: text_helper
INFO - 2023-08-11 05:00:50 --> Helper loaded: form_helper
INFO - 2023-08-11 05:00:50 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:00:50 --> Helper loaded: security_helper
INFO - 2023-08-11 05:00:50 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:00:50 --> Database Driver Class Initialized
INFO - 2023-08-11 05:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:00:50 --> Parser Class Initialized
INFO - 2023-08-11 05:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:00:50 --> Pagination Class Initialized
INFO - 2023-08-11 05:00:50 --> Form Validation Class Initialized
INFO - 2023-08-11 05:00:50 --> Controller Class Initialized
INFO - 2023-08-11 05:00:50 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:50 --> Model Class Initialized
INFO - 2023-08-11 05:00:50 --> Model Class Initialized
INFO - 2023-08-11 05:00:50 --> Final output sent to browser
DEBUG - 2023-08-11 05:00:50 --> Total execution time: 0.0211
ERROR - 2023-08-11 05:00:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:00:52 --> Config Class Initialized
INFO - 2023-08-11 05:00:52 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:00:52 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:00:52 --> Utf8 Class Initialized
INFO - 2023-08-11 05:00:52 --> URI Class Initialized
INFO - 2023-08-11 05:00:52 --> Router Class Initialized
INFO - 2023-08-11 05:00:52 --> Output Class Initialized
INFO - 2023-08-11 05:00:52 --> Security Class Initialized
DEBUG - 2023-08-11 05:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:00:52 --> Input Class Initialized
INFO - 2023-08-11 05:00:52 --> Language Class Initialized
INFO - 2023-08-11 05:00:52 --> Loader Class Initialized
INFO - 2023-08-11 05:00:52 --> Helper loaded: url_helper
INFO - 2023-08-11 05:00:52 --> Helper loaded: file_helper
INFO - 2023-08-11 05:00:52 --> Helper loaded: html_helper
INFO - 2023-08-11 05:00:52 --> Helper loaded: text_helper
INFO - 2023-08-11 05:00:52 --> Helper loaded: form_helper
INFO - 2023-08-11 05:00:52 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:00:52 --> Helper loaded: security_helper
INFO - 2023-08-11 05:00:52 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:00:52 --> Database Driver Class Initialized
INFO - 2023-08-11 05:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:00:52 --> Parser Class Initialized
INFO - 2023-08-11 05:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:00:52 --> Pagination Class Initialized
INFO - 2023-08-11 05:00:52 --> Form Validation Class Initialized
INFO - 2023-08-11 05:00:52 --> Controller Class Initialized
INFO - 2023-08-11 05:00:52 --> Model Class Initialized
DEBUG - 2023-08-11 05:00:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:00:52 --> Model Class Initialized
INFO - 2023-08-11 05:00:52 --> Final output sent to browser
DEBUG - 2023-08-11 05:00:52 --> Total execution time: 0.0175
ERROR - 2023-08-11 05:01:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:01:01 --> Config Class Initialized
INFO - 2023-08-11 05:01:01 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:01:01 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:01:01 --> Utf8 Class Initialized
INFO - 2023-08-11 05:01:01 --> URI Class Initialized
INFO - 2023-08-11 05:01:01 --> Router Class Initialized
INFO - 2023-08-11 05:01:01 --> Output Class Initialized
INFO - 2023-08-11 05:01:01 --> Security Class Initialized
DEBUG - 2023-08-11 05:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:01:01 --> Input Class Initialized
INFO - 2023-08-11 05:01:01 --> Language Class Initialized
INFO - 2023-08-11 05:01:01 --> Loader Class Initialized
INFO - 2023-08-11 05:01:01 --> Helper loaded: url_helper
INFO - 2023-08-11 05:01:01 --> Helper loaded: file_helper
INFO - 2023-08-11 05:01:01 --> Helper loaded: html_helper
INFO - 2023-08-11 05:01:01 --> Helper loaded: text_helper
INFO - 2023-08-11 05:01:01 --> Helper loaded: form_helper
INFO - 2023-08-11 05:01:01 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:01:01 --> Helper loaded: security_helper
INFO - 2023-08-11 05:01:01 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:01:01 --> Database Driver Class Initialized
INFO - 2023-08-11 05:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:01:01 --> Parser Class Initialized
INFO - 2023-08-11 05:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:01:01 --> Pagination Class Initialized
INFO - 2023-08-11 05:01:01 --> Form Validation Class Initialized
INFO - 2023-08-11 05:01:01 --> Controller Class Initialized
INFO - 2023-08-11 05:01:01 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:01 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:01 --> Model Class Initialized
INFO - 2023-08-11 05:01:01 --> Final output sent to browser
DEBUG - 2023-08-11 05:01:01 --> Total execution time: 0.0553
ERROR - 2023-08-11 05:01:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:01:03 --> Config Class Initialized
INFO - 2023-08-11 05:01:03 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:01:03 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:01:03 --> Utf8 Class Initialized
INFO - 2023-08-11 05:01:03 --> URI Class Initialized
INFO - 2023-08-11 05:01:03 --> Router Class Initialized
INFO - 2023-08-11 05:01:03 --> Output Class Initialized
INFO - 2023-08-11 05:01:03 --> Security Class Initialized
DEBUG - 2023-08-11 05:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:01:03 --> Input Class Initialized
INFO - 2023-08-11 05:01:03 --> Language Class Initialized
INFO - 2023-08-11 05:01:03 --> Loader Class Initialized
INFO - 2023-08-11 05:01:03 --> Helper loaded: url_helper
INFO - 2023-08-11 05:01:03 --> Helper loaded: file_helper
INFO - 2023-08-11 05:01:03 --> Helper loaded: html_helper
INFO - 2023-08-11 05:01:03 --> Helper loaded: text_helper
INFO - 2023-08-11 05:01:03 --> Helper loaded: form_helper
INFO - 2023-08-11 05:01:03 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:01:03 --> Helper loaded: security_helper
INFO - 2023-08-11 05:01:03 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:01:03 --> Database Driver Class Initialized
INFO - 2023-08-11 05:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:01:03 --> Parser Class Initialized
INFO - 2023-08-11 05:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:01:03 --> Pagination Class Initialized
INFO - 2023-08-11 05:01:03 --> Form Validation Class Initialized
INFO - 2023-08-11 05:01:03 --> Controller Class Initialized
INFO - 2023-08-11 05:01:03 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:03 --> Model Class Initialized
INFO - 2023-08-11 05:01:03 --> Model Class Initialized
INFO - 2023-08-11 05:01:03 --> Final output sent to browser
DEBUG - 2023-08-11 05:01:03 --> Total execution time: 0.0192
ERROR - 2023-08-11 05:01:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:01:06 --> Config Class Initialized
INFO - 2023-08-11 05:01:06 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:01:06 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:01:06 --> Utf8 Class Initialized
INFO - 2023-08-11 05:01:06 --> URI Class Initialized
INFO - 2023-08-11 05:01:06 --> Router Class Initialized
INFO - 2023-08-11 05:01:06 --> Output Class Initialized
INFO - 2023-08-11 05:01:06 --> Security Class Initialized
DEBUG - 2023-08-11 05:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:01:06 --> Input Class Initialized
INFO - 2023-08-11 05:01:06 --> Language Class Initialized
INFO - 2023-08-11 05:01:06 --> Loader Class Initialized
INFO - 2023-08-11 05:01:06 --> Helper loaded: url_helper
INFO - 2023-08-11 05:01:06 --> Helper loaded: file_helper
INFO - 2023-08-11 05:01:06 --> Helper loaded: html_helper
INFO - 2023-08-11 05:01:06 --> Helper loaded: text_helper
INFO - 2023-08-11 05:01:06 --> Helper loaded: form_helper
INFO - 2023-08-11 05:01:06 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:01:06 --> Helper loaded: security_helper
INFO - 2023-08-11 05:01:06 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:01:06 --> Database Driver Class Initialized
INFO - 2023-08-11 05:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:01:06 --> Parser Class Initialized
INFO - 2023-08-11 05:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:01:06 --> Pagination Class Initialized
INFO - 2023-08-11 05:01:06 --> Form Validation Class Initialized
INFO - 2023-08-11 05:01:06 --> Controller Class Initialized
INFO - 2023-08-11 05:01:06 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:06 --> Model Class Initialized
INFO - 2023-08-11 05:01:06 --> Final output sent to browser
DEBUG - 2023-08-11 05:01:06 --> Total execution time: 0.0172
ERROR - 2023-08-11 05:01:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:01:27 --> Config Class Initialized
INFO - 2023-08-11 05:01:27 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:01:27 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:01:27 --> Utf8 Class Initialized
INFO - 2023-08-11 05:01:27 --> URI Class Initialized
INFO - 2023-08-11 05:01:27 --> Router Class Initialized
INFO - 2023-08-11 05:01:27 --> Output Class Initialized
INFO - 2023-08-11 05:01:27 --> Security Class Initialized
DEBUG - 2023-08-11 05:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:01:27 --> Input Class Initialized
INFO - 2023-08-11 05:01:27 --> Language Class Initialized
INFO - 2023-08-11 05:01:27 --> Loader Class Initialized
INFO - 2023-08-11 05:01:27 --> Helper loaded: url_helper
INFO - 2023-08-11 05:01:27 --> Helper loaded: file_helper
INFO - 2023-08-11 05:01:27 --> Helper loaded: html_helper
INFO - 2023-08-11 05:01:27 --> Helper loaded: text_helper
INFO - 2023-08-11 05:01:27 --> Helper loaded: form_helper
INFO - 2023-08-11 05:01:27 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:01:27 --> Helper loaded: security_helper
INFO - 2023-08-11 05:01:27 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:01:27 --> Database Driver Class Initialized
INFO - 2023-08-11 05:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:01:27 --> Parser Class Initialized
INFO - 2023-08-11 05:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:01:27 --> Pagination Class Initialized
INFO - 2023-08-11 05:01:27 --> Form Validation Class Initialized
INFO - 2023-08-11 05:01:27 --> Controller Class Initialized
INFO - 2023-08-11 05:01:27 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:27 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:27 --> Model Class Initialized
INFO - 2023-08-11 05:01:27 --> Email Class Initialized
DEBUG - 2023-08-11 05:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-11 05:01:27 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-11 05:01:28 --> Language file loaded: language/english/email_lang.php
INFO - 2023-08-11 05:01:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-08-11 05:01:28 --> Final output sent to browser
DEBUG - 2023-08-11 05:01:28 --> Total execution time: 1.0371
ERROR - 2023-08-11 05:01:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:01:32 --> Config Class Initialized
INFO - 2023-08-11 05:01:32 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:01:32 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:01:32 --> Utf8 Class Initialized
INFO - 2023-08-11 05:01:32 --> URI Class Initialized
INFO - 2023-08-11 05:01:32 --> Router Class Initialized
INFO - 2023-08-11 05:01:32 --> Output Class Initialized
INFO - 2023-08-11 05:01:32 --> Security Class Initialized
DEBUG - 2023-08-11 05:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:01:32 --> Input Class Initialized
INFO - 2023-08-11 05:01:32 --> Language Class Initialized
INFO - 2023-08-11 05:01:32 --> Loader Class Initialized
INFO - 2023-08-11 05:01:32 --> Helper loaded: url_helper
INFO - 2023-08-11 05:01:32 --> Helper loaded: file_helper
INFO - 2023-08-11 05:01:32 --> Helper loaded: html_helper
INFO - 2023-08-11 05:01:32 --> Helper loaded: text_helper
INFO - 2023-08-11 05:01:32 --> Helper loaded: form_helper
INFO - 2023-08-11 05:01:32 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:01:32 --> Helper loaded: security_helper
INFO - 2023-08-11 05:01:32 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:01:32 --> Database Driver Class Initialized
INFO - 2023-08-11 05:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:01:32 --> Parser Class Initialized
INFO - 2023-08-11 05:01:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:01:32 --> Pagination Class Initialized
INFO - 2023-08-11 05:01:32 --> Form Validation Class Initialized
INFO - 2023-08-11 05:01:32 --> Controller Class Initialized
INFO - 2023-08-11 05:01:32 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:32 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:32 --> Model Class Initialized
INFO - 2023-08-11 05:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-11 05:01:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:01:32 --> Model Class Initialized
INFO - 2023-08-11 05:01:32 --> Model Class Initialized
INFO - 2023-08-11 05:01:32 --> Model Class Initialized
INFO - 2023-08-11 05:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:01:32 --> Final output sent to browser
DEBUG - 2023-08-11 05:01:32 --> Total execution time: 0.0921
ERROR - 2023-08-11 05:01:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:01:35 --> Config Class Initialized
INFO - 2023-08-11 05:01:35 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:01:35 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:01:35 --> Utf8 Class Initialized
INFO - 2023-08-11 05:01:35 --> URI Class Initialized
INFO - 2023-08-11 05:01:35 --> Router Class Initialized
INFO - 2023-08-11 05:01:35 --> Output Class Initialized
INFO - 2023-08-11 05:01:35 --> Security Class Initialized
DEBUG - 2023-08-11 05:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:01:35 --> Input Class Initialized
INFO - 2023-08-11 05:01:35 --> Language Class Initialized
INFO - 2023-08-11 05:01:35 --> Loader Class Initialized
INFO - 2023-08-11 05:01:35 --> Helper loaded: url_helper
INFO - 2023-08-11 05:01:35 --> Helper loaded: file_helper
INFO - 2023-08-11 05:01:35 --> Helper loaded: html_helper
INFO - 2023-08-11 05:01:35 --> Helper loaded: text_helper
INFO - 2023-08-11 05:01:35 --> Helper loaded: form_helper
INFO - 2023-08-11 05:01:35 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:01:35 --> Helper loaded: security_helper
INFO - 2023-08-11 05:01:35 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:01:35 --> Database Driver Class Initialized
INFO - 2023-08-11 05:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:01:35 --> Parser Class Initialized
INFO - 2023-08-11 05:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:01:35 --> Pagination Class Initialized
INFO - 2023-08-11 05:01:35 --> Form Validation Class Initialized
INFO - 2023-08-11 05:01:35 --> Controller Class Initialized
INFO - 2023-08-11 05:01:35 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:35 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:35 --> Model Class Initialized
INFO - 2023-08-11 05:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-11 05:01:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:01:35 --> Model Class Initialized
INFO - 2023-08-11 05:01:35 --> Model Class Initialized
INFO - 2023-08-11 05:01:35 --> Model Class Initialized
INFO - 2023-08-11 05:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:01:35 --> Final output sent to browser
DEBUG - 2023-08-11 05:01:35 --> Total execution time: 0.0849
ERROR - 2023-08-11 05:01:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:01:36 --> Config Class Initialized
INFO - 2023-08-11 05:01:36 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:01:36 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:01:36 --> Utf8 Class Initialized
INFO - 2023-08-11 05:01:36 --> URI Class Initialized
INFO - 2023-08-11 05:01:36 --> Router Class Initialized
INFO - 2023-08-11 05:01:36 --> Output Class Initialized
INFO - 2023-08-11 05:01:36 --> Security Class Initialized
DEBUG - 2023-08-11 05:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:01:36 --> Input Class Initialized
INFO - 2023-08-11 05:01:36 --> Language Class Initialized
INFO - 2023-08-11 05:01:36 --> Loader Class Initialized
INFO - 2023-08-11 05:01:36 --> Helper loaded: url_helper
INFO - 2023-08-11 05:01:36 --> Helper loaded: file_helper
INFO - 2023-08-11 05:01:36 --> Helper loaded: html_helper
INFO - 2023-08-11 05:01:36 --> Helper loaded: text_helper
INFO - 2023-08-11 05:01:36 --> Helper loaded: form_helper
INFO - 2023-08-11 05:01:36 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:01:36 --> Helper loaded: security_helper
INFO - 2023-08-11 05:01:36 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:01:36 --> Database Driver Class Initialized
INFO - 2023-08-11 05:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:01:36 --> Parser Class Initialized
INFO - 2023-08-11 05:01:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:01:36 --> Pagination Class Initialized
INFO - 2023-08-11 05:01:36 --> Form Validation Class Initialized
INFO - 2023-08-11 05:01:36 --> Controller Class Initialized
INFO - 2023-08-11 05:01:36 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:36 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:36 --> Model Class Initialized
INFO - 2023-08-11 05:01:36 --> Final output sent to browser
DEBUG - 2023-08-11 05:01:36 --> Total execution time: 0.0363
ERROR - 2023-08-11 05:01:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:01:38 --> Config Class Initialized
INFO - 2023-08-11 05:01:38 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:01:38 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:01:38 --> Utf8 Class Initialized
INFO - 2023-08-11 05:01:38 --> URI Class Initialized
INFO - 2023-08-11 05:01:38 --> Router Class Initialized
INFO - 2023-08-11 05:01:38 --> Output Class Initialized
INFO - 2023-08-11 05:01:38 --> Security Class Initialized
DEBUG - 2023-08-11 05:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:01:38 --> Input Class Initialized
INFO - 2023-08-11 05:01:38 --> Language Class Initialized
INFO - 2023-08-11 05:01:38 --> Loader Class Initialized
INFO - 2023-08-11 05:01:38 --> Helper loaded: url_helper
INFO - 2023-08-11 05:01:38 --> Helper loaded: file_helper
INFO - 2023-08-11 05:01:38 --> Helper loaded: html_helper
INFO - 2023-08-11 05:01:38 --> Helper loaded: text_helper
INFO - 2023-08-11 05:01:38 --> Helper loaded: form_helper
INFO - 2023-08-11 05:01:38 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:01:38 --> Helper loaded: security_helper
INFO - 2023-08-11 05:01:38 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:01:38 --> Database Driver Class Initialized
INFO - 2023-08-11 05:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:01:38 --> Parser Class Initialized
INFO - 2023-08-11 05:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:01:38 --> Pagination Class Initialized
INFO - 2023-08-11 05:01:38 --> Form Validation Class Initialized
INFO - 2023-08-11 05:01:38 --> Controller Class Initialized
INFO - 2023-08-11 05:01:38 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:38 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:38 --> Model Class Initialized
DEBUG - 2023-08-11 05:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-11 05:01:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:01:39 --> Model Class Initialized
INFO - 2023-08-11 05:01:39 --> Model Class Initialized
INFO - 2023-08-11 05:01:39 --> Model Class Initialized
INFO - 2023-08-11 05:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:01:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:01:39 --> Final output sent to browser
DEBUG - 2023-08-11 05:01:39 --> Total execution time: 0.0772
ERROR - 2023-08-11 05:03:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:03:33 --> Config Class Initialized
INFO - 2023-08-11 05:03:33 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:03:33 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:03:33 --> Utf8 Class Initialized
INFO - 2023-08-11 05:03:33 --> URI Class Initialized
DEBUG - 2023-08-11 05:03:33 --> No URI present. Default controller set.
INFO - 2023-08-11 05:03:33 --> Router Class Initialized
INFO - 2023-08-11 05:03:33 --> Output Class Initialized
INFO - 2023-08-11 05:03:33 --> Security Class Initialized
DEBUG - 2023-08-11 05:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:03:33 --> Input Class Initialized
INFO - 2023-08-11 05:03:33 --> Language Class Initialized
INFO - 2023-08-11 05:03:33 --> Loader Class Initialized
INFO - 2023-08-11 05:03:33 --> Helper loaded: url_helper
INFO - 2023-08-11 05:03:33 --> Helper loaded: file_helper
INFO - 2023-08-11 05:03:33 --> Helper loaded: html_helper
INFO - 2023-08-11 05:03:33 --> Helper loaded: text_helper
INFO - 2023-08-11 05:03:33 --> Helper loaded: form_helper
INFO - 2023-08-11 05:03:33 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:03:33 --> Helper loaded: security_helper
INFO - 2023-08-11 05:03:33 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:03:33 --> Database Driver Class Initialized
INFO - 2023-08-11 05:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:03:33 --> Parser Class Initialized
INFO - 2023-08-11 05:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:03:33 --> Pagination Class Initialized
INFO - 2023-08-11 05:03:33 --> Form Validation Class Initialized
INFO - 2023-08-11 05:03:33 --> Controller Class Initialized
INFO - 2023-08-11 05:03:33 --> Model Class Initialized
DEBUG - 2023-08-11 05:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:33 --> Model Class Initialized
DEBUG - 2023-08-11 05:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:33 --> Model Class Initialized
INFO - 2023-08-11 05:03:33 --> Model Class Initialized
INFO - 2023-08-11 05:03:33 --> Model Class Initialized
INFO - 2023-08-11 05:03:33 --> Model Class Initialized
DEBUG - 2023-08-11 05:03:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:33 --> Model Class Initialized
INFO - 2023-08-11 05:03:33 --> Model Class Initialized
INFO - 2023-08-11 05:03:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 05:03:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:03:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:03:33 --> Model Class Initialized
INFO - 2023-08-11 05:03:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:03:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:03:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:03:33 --> Final output sent to browser
DEBUG - 2023-08-11 05:03:33 --> Total execution time: 0.0807
ERROR - 2023-08-11 05:03:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:03:47 --> Config Class Initialized
INFO - 2023-08-11 05:03:47 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:03:47 --> Utf8 Class Initialized
INFO - 2023-08-11 05:03:47 --> URI Class Initialized
INFO - 2023-08-11 05:03:47 --> Router Class Initialized
INFO - 2023-08-11 05:03:47 --> Output Class Initialized
INFO - 2023-08-11 05:03:47 --> Security Class Initialized
DEBUG - 2023-08-11 05:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:03:47 --> Input Class Initialized
INFO - 2023-08-11 05:03:47 --> Language Class Initialized
INFO - 2023-08-11 05:03:47 --> Loader Class Initialized
INFO - 2023-08-11 05:03:47 --> Helper loaded: url_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: file_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: html_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: text_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: form_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: security_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:03:47 --> Database Driver Class Initialized
INFO - 2023-08-11 05:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:03:47 --> Parser Class Initialized
INFO - 2023-08-11 05:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:03:47 --> Pagination Class Initialized
INFO - 2023-08-11 05:03:47 --> Form Validation Class Initialized
INFO - 2023-08-11 05:03:47 --> Controller Class Initialized
DEBUG - 2023-08-11 05:03:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:47 --> Model Class Initialized
DEBUG - 2023-08-11 05:03:47 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:47 --> Model Class Initialized
DEBUG - 2023-08-11 05:03:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:47 --> Model Class Initialized
DEBUG - 2023-08-11 05:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:47 --> Model Class Initialized
INFO - 2023-08-11 05:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-08-11 05:03:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:03:47 --> Model Class Initialized
INFO - 2023-08-11 05:03:47 --> Model Class Initialized
INFO - 2023-08-11 05:03:47 --> Model Class Initialized
INFO - 2023-08-11 05:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:03:47 --> Final output sent to browser
DEBUG - 2023-08-11 05:03:47 --> Total execution time: 0.0700
ERROR - 2023-08-11 05:03:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:03:47 --> Config Class Initialized
INFO - 2023-08-11 05:03:47 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:03:47 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:03:47 --> Utf8 Class Initialized
INFO - 2023-08-11 05:03:47 --> URI Class Initialized
INFO - 2023-08-11 05:03:47 --> Router Class Initialized
INFO - 2023-08-11 05:03:47 --> Output Class Initialized
INFO - 2023-08-11 05:03:47 --> Security Class Initialized
DEBUG - 2023-08-11 05:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:03:47 --> Input Class Initialized
INFO - 2023-08-11 05:03:47 --> Language Class Initialized
INFO - 2023-08-11 05:03:47 --> Loader Class Initialized
INFO - 2023-08-11 05:03:47 --> Helper loaded: url_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: file_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: html_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: text_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: form_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: security_helper
INFO - 2023-08-11 05:03:47 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:03:47 --> Database Driver Class Initialized
INFO - 2023-08-11 05:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:03:47 --> Parser Class Initialized
INFO - 2023-08-11 05:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:03:47 --> Pagination Class Initialized
INFO - 2023-08-11 05:03:47 --> Form Validation Class Initialized
INFO - 2023-08-11 05:03:47 --> Controller Class Initialized
DEBUG - 2023-08-11 05:03:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:47 --> Model Class Initialized
INFO - 2023-08-11 05:03:47 --> Final output sent to browser
DEBUG - 2023-08-11 05:03:47 --> Total execution time: 0.0177
ERROR - 2023-08-11 05:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:03:59 --> Config Class Initialized
INFO - 2023-08-11 05:03:59 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:03:59 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:03:59 --> Utf8 Class Initialized
INFO - 2023-08-11 05:03:59 --> URI Class Initialized
DEBUG - 2023-08-11 05:03:59 --> No URI present. Default controller set.
INFO - 2023-08-11 05:03:59 --> Router Class Initialized
INFO - 2023-08-11 05:03:59 --> Output Class Initialized
INFO - 2023-08-11 05:03:59 --> Security Class Initialized
DEBUG - 2023-08-11 05:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:03:59 --> Input Class Initialized
INFO - 2023-08-11 05:03:59 --> Language Class Initialized
INFO - 2023-08-11 05:03:59 --> Loader Class Initialized
INFO - 2023-08-11 05:03:59 --> Helper loaded: url_helper
INFO - 2023-08-11 05:03:59 --> Helper loaded: file_helper
INFO - 2023-08-11 05:03:59 --> Helper loaded: html_helper
INFO - 2023-08-11 05:03:59 --> Helper loaded: text_helper
INFO - 2023-08-11 05:03:59 --> Helper loaded: form_helper
INFO - 2023-08-11 05:03:59 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:03:59 --> Helper loaded: security_helper
INFO - 2023-08-11 05:03:59 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:03:59 --> Database Driver Class Initialized
INFO - 2023-08-11 05:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:03:59 --> Parser Class Initialized
INFO - 2023-08-11 05:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:03:59 --> Pagination Class Initialized
INFO - 2023-08-11 05:03:59 --> Form Validation Class Initialized
INFO - 2023-08-11 05:03:59 --> Controller Class Initialized
INFO - 2023-08-11 05:03:59 --> Model Class Initialized
DEBUG - 2023-08-11 05:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:59 --> Model Class Initialized
DEBUG - 2023-08-11 05:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:59 --> Model Class Initialized
INFO - 2023-08-11 05:03:59 --> Model Class Initialized
INFO - 2023-08-11 05:03:59 --> Model Class Initialized
INFO - 2023-08-11 05:03:59 --> Model Class Initialized
DEBUG - 2023-08-11 05:03:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:59 --> Model Class Initialized
INFO - 2023-08-11 05:03:59 --> Model Class Initialized
INFO - 2023-08-11 05:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 05:03:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:03:59 --> Model Class Initialized
INFO - 2023-08-11 05:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:03:59 --> Final output sent to browser
DEBUG - 2023-08-11 05:03:59 --> Total execution time: 0.0752
ERROR - 2023-08-11 05:04:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:04:07 --> Config Class Initialized
INFO - 2023-08-11 05:04:07 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:04:07 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:04:07 --> Utf8 Class Initialized
INFO - 2023-08-11 05:04:07 --> URI Class Initialized
INFO - 2023-08-11 05:04:07 --> Router Class Initialized
INFO - 2023-08-11 05:04:07 --> Output Class Initialized
INFO - 2023-08-11 05:04:07 --> Security Class Initialized
DEBUG - 2023-08-11 05:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:04:07 --> Input Class Initialized
INFO - 2023-08-11 05:04:07 --> Language Class Initialized
INFO - 2023-08-11 05:04:07 --> Loader Class Initialized
INFO - 2023-08-11 05:04:07 --> Helper loaded: url_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: file_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: html_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: text_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: form_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: security_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:04:07 --> Database Driver Class Initialized
INFO - 2023-08-11 05:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:04:07 --> Parser Class Initialized
INFO - 2023-08-11 05:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:04:07 --> Pagination Class Initialized
INFO - 2023-08-11 05:04:07 --> Form Validation Class Initialized
INFO - 2023-08-11 05:04:07 --> Controller Class Initialized
INFO - 2023-08-11 05:04:07 --> Model Class Initialized
DEBUG - 2023-08-11 05:04:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:07 --> Model Class Initialized
DEBUG - 2023-08-11 05:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:07 --> Model Class Initialized
INFO - 2023-08-11 05:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-11 05:04:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:04:07 --> Model Class Initialized
INFO - 2023-08-11 05:04:07 --> Model Class Initialized
INFO - 2023-08-11 05:04:07 --> Model Class Initialized
INFO - 2023-08-11 05:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:04:07 --> Final output sent to browser
DEBUG - 2023-08-11 05:04:07 --> Total execution time: 0.0640
ERROR - 2023-08-11 05:04:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:04:07 --> Config Class Initialized
INFO - 2023-08-11 05:04:07 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:04:07 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:04:07 --> Utf8 Class Initialized
INFO - 2023-08-11 05:04:07 --> URI Class Initialized
INFO - 2023-08-11 05:04:07 --> Router Class Initialized
INFO - 2023-08-11 05:04:07 --> Output Class Initialized
INFO - 2023-08-11 05:04:07 --> Security Class Initialized
DEBUG - 2023-08-11 05:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:04:07 --> Input Class Initialized
INFO - 2023-08-11 05:04:07 --> Language Class Initialized
INFO - 2023-08-11 05:04:07 --> Loader Class Initialized
INFO - 2023-08-11 05:04:07 --> Helper loaded: url_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: file_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: html_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: text_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: form_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: security_helper
INFO - 2023-08-11 05:04:07 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:04:07 --> Database Driver Class Initialized
INFO - 2023-08-11 05:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:04:07 --> Parser Class Initialized
INFO - 2023-08-11 05:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:04:07 --> Pagination Class Initialized
INFO - 2023-08-11 05:04:07 --> Form Validation Class Initialized
INFO - 2023-08-11 05:04:07 --> Controller Class Initialized
INFO - 2023-08-11 05:04:07 --> Model Class Initialized
DEBUG - 2023-08-11 05:04:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:07 --> Model Class Initialized
DEBUG - 2023-08-11 05:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:07 --> Model Class Initialized
INFO - 2023-08-11 05:04:07 --> Final output sent to browser
DEBUG - 2023-08-11 05:04:07 --> Total execution time: 0.0198
ERROR - 2023-08-11 05:04:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:04:13 --> Config Class Initialized
INFO - 2023-08-11 05:04:13 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:04:13 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:04:13 --> Utf8 Class Initialized
INFO - 2023-08-11 05:04:13 --> URI Class Initialized
INFO - 2023-08-11 05:04:13 --> Router Class Initialized
INFO - 2023-08-11 05:04:13 --> Output Class Initialized
INFO - 2023-08-11 05:04:13 --> Security Class Initialized
DEBUG - 2023-08-11 05:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:04:13 --> Input Class Initialized
INFO - 2023-08-11 05:04:13 --> Language Class Initialized
INFO - 2023-08-11 05:04:13 --> Loader Class Initialized
INFO - 2023-08-11 05:04:13 --> Helper loaded: url_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: file_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: html_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: text_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: form_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: security_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:04:13 --> Database Driver Class Initialized
INFO - 2023-08-11 05:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:04:13 --> Parser Class Initialized
INFO - 2023-08-11 05:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:04:13 --> Pagination Class Initialized
INFO - 2023-08-11 05:04:13 --> Form Validation Class Initialized
INFO - 2023-08-11 05:04:13 --> Controller Class Initialized
INFO - 2023-08-11 05:04:13 --> Model Class Initialized
DEBUG - 2023-08-11 05:04:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:13 --> Model Class Initialized
DEBUG - 2023-08-11 05:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:13 --> Model Class Initialized
INFO - 2023-08-11 05:04:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-11 05:04:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:04:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:04:13 --> Model Class Initialized
INFO - 2023-08-11 05:04:13 --> Model Class Initialized
INFO - 2023-08-11 05:04:13 --> Model Class Initialized
INFO - 2023-08-11 05:04:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:04:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:04:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:04:13 --> Final output sent to browser
DEBUG - 2023-08-11 05:04:13 --> Total execution time: 0.0690
ERROR - 2023-08-11 05:04:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:04:13 --> Config Class Initialized
INFO - 2023-08-11 05:04:13 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:04:13 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:04:13 --> Utf8 Class Initialized
INFO - 2023-08-11 05:04:13 --> URI Class Initialized
INFO - 2023-08-11 05:04:13 --> Router Class Initialized
INFO - 2023-08-11 05:04:13 --> Output Class Initialized
INFO - 2023-08-11 05:04:13 --> Security Class Initialized
DEBUG - 2023-08-11 05:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:04:13 --> Input Class Initialized
INFO - 2023-08-11 05:04:13 --> Language Class Initialized
INFO - 2023-08-11 05:04:13 --> Loader Class Initialized
INFO - 2023-08-11 05:04:13 --> Helper loaded: url_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: file_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: html_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: text_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: form_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: security_helper
INFO - 2023-08-11 05:04:13 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:04:13 --> Database Driver Class Initialized
INFO - 2023-08-11 05:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:04:13 --> Parser Class Initialized
INFO - 2023-08-11 05:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:04:13 --> Pagination Class Initialized
INFO - 2023-08-11 05:04:13 --> Form Validation Class Initialized
INFO - 2023-08-11 05:04:13 --> Controller Class Initialized
INFO - 2023-08-11 05:04:13 --> Model Class Initialized
DEBUG - 2023-08-11 05:04:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:13 --> Model Class Initialized
DEBUG - 2023-08-11 05:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:04:13 --> Model Class Initialized
INFO - 2023-08-11 05:04:13 --> Final output sent to browser
DEBUG - 2023-08-11 05:04:13 --> Total execution time: 0.0213
ERROR - 2023-08-11 05:38:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:38:27 --> Config Class Initialized
INFO - 2023-08-11 05:38:27 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:38:27 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:38:27 --> Utf8 Class Initialized
INFO - 2023-08-11 05:38:27 --> URI Class Initialized
DEBUG - 2023-08-11 05:38:27 --> No URI present. Default controller set.
INFO - 2023-08-11 05:38:27 --> Router Class Initialized
INFO - 2023-08-11 05:38:27 --> Output Class Initialized
INFO - 2023-08-11 05:38:27 --> Security Class Initialized
DEBUG - 2023-08-11 05:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:38:27 --> Input Class Initialized
INFO - 2023-08-11 05:38:27 --> Language Class Initialized
INFO - 2023-08-11 05:38:27 --> Loader Class Initialized
INFO - 2023-08-11 05:38:27 --> Helper loaded: url_helper
INFO - 2023-08-11 05:38:27 --> Helper loaded: file_helper
INFO - 2023-08-11 05:38:27 --> Helper loaded: html_helper
INFO - 2023-08-11 05:38:27 --> Helper loaded: text_helper
INFO - 2023-08-11 05:38:27 --> Helper loaded: form_helper
INFO - 2023-08-11 05:38:27 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:38:27 --> Helper loaded: security_helper
INFO - 2023-08-11 05:38:27 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:38:27 --> Database Driver Class Initialized
INFO - 2023-08-11 05:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:38:27 --> Parser Class Initialized
INFO - 2023-08-11 05:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:38:27 --> Pagination Class Initialized
INFO - 2023-08-11 05:38:27 --> Form Validation Class Initialized
INFO - 2023-08-11 05:38:27 --> Controller Class Initialized
INFO - 2023-08-11 05:38:27 --> Model Class Initialized
DEBUG - 2023-08-11 05:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:38:27 --> Model Class Initialized
DEBUG - 2023-08-11 05:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:38:27 --> Model Class Initialized
INFO - 2023-08-11 05:38:27 --> Model Class Initialized
INFO - 2023-08-11 05:38:27 --> Model Class Initialized
INFO - 2023-08-11 05:38:27 --> Model Class Initialized
DEBUG - 2023-08-11 05:38:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:38:27 --> Model Class Initialized
INFO - 2023-08-11 05:38:27 --> Model Class Initialized
INFO - 2023-08-11 05:38:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 05:38:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:38:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:38:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:38:27 --> Model Class Initialized
INFO - 2023-08-11 05:38:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:38:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:38:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:38:27 --> Final output sent to browser
DEBUG - 2023-08-11 05:38:27 --> Total execution time: 0.0781
ERROR - 2023-08-11 05:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:40:03 --> Config Class Initialized
INFO - 2023-08-11 05:40:03 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:40:03 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:40:03 --> Utf8 Class Initialized
INFO - 2023-08-11 05:40:03 --> URI Class Initialized
INFO - 2023-08-11 05:40:03 --> Router Class Initialized
INFO - 2023-08-11 05:40:03 --> Output Class Initialized
INFO - 2023-08-11 05:40:03 --> Security Class Initialized
DEBUG - 2023-08-11 05:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:40:03 --> Input Class Initialized
INFO - 2023-08-11 05:40:03 --> Language Class Initialized
INFO - 2023-08-11 05:40:03 --> Loader Class Initialized
INFO - 2023-08-11 05:40:03 --> Helper loaded: url_helper
INFO - 2023-08-11 05:40:03 --> Helper loaded: file_helper
INFO - 2023-08-11 05:40:03 --> Helper loaded: html_helper
INFO - 2023-08-11 05:40:03 --> Helper loaded: text_helper
INFO - 2023-08-11 05:40:03 --> Helper loaded: form_helper
INFO - 2023-08-11 05:40:03 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:40:03 --> Helper loaded: security_helper
INFO - 2023-08-11 05:40:03 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:40:03 --> Database Driver Class Initialized
INFO - 2023-08-11 05:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:40:03 --> Parser Class Initialized
INFO - 2023-08-11 05:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:40:03 --> Pagination Class Initialized
INFO - 2023-08-11 05:40:03 --> Form Validation Class Initialized
INFO - 2023-08-11 05:40:03 --> Controller Class Initialized
DEBUG - 2023-08-11 05:40:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:03 --> Model Class Initialized
DEBUG - 2023-08-11 05:40:03 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:03 --> Model Class Initialized
DEBUG - 2023-08-11 05:40:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:03 --> Model Class Initialized
DEBUG - 2023-08-11 05:40:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:03 --> Model Class Initialized
INFO - 2023-08-11 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-08-11 05:40:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:40:03 --> Model Class Initialized
INFO - 2023-08-11 05:40:03 --> Model Class Initialized
INFO - 2023-08-11 05:40:03 --> Model Class Initialized
INFO - 2023-08-11 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:40:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:40:03 --> Final output sent to browser
DEBUG - 2023-08-11 05:40:03 --> Total execution time: 0.0629
ERROR - 2023-08-11 05:40:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:40:04 --> Config Class Initialized
INFO - 2023-08-11 05:40:04 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:40:04 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:40:04 --> Utf8 Class Initialized
INFO - 2023-08-11 05:40:04 --> URI Class Initialized
INFO - 2023-08-11 05:40:04 --> Router Class Initialized
INFO - 2023-08-11 05:40:04 --> Output Class Initialized
INFO - 2023-08-11 05:40:04 --> Security Class Initialized
DEBUG - 2023-08-11 05:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:40:04 --> Input Class Initialized
INFO - 2023-08-11 05:40:04 --> Language Class Initialized
INFO - 2023-08-11 05:40:04 --> Loader Class Initialized
INFO - 2023-08-11 05:40:04 --> Helper loaded: url_helper
INFO - 2023-08-11 05:40:04 --> Helper loaded: file_helper
INFO - 2023-08-11 05:40:04 --> Helper loaded: html_helper
INFO - 2023-08-11 05:40:04 --> Helper loaded: text_helper
INFO - 2023-08-11 05:40:04 --> Helper loaded: form_helper
INFO - 2023-08-11 05:40:04 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:40:04 --> Helper loaded: security_helper
INFO - 2023-08-11 05:40:04 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:40:04 --> Database Driver Class Initialized
INFO - 2023-08-11 05:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:40:04 --> Parser Class Initialized
INFO - 2023-08-11 05:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:40:04 --> Pagination Class Initialized
INFO - 2023-08-11 05:40:04 --> Form Validation Class Initialized
INFO - 2023-08-11 05:40:04 --> Controller Class Initialized
DEBUG - 2023-08-11 05:40:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:04 --> Model Class Initialized
INFO - 2023-08-11 05:40:04 --> Final output sent to browser
DEBUG - 2023-08-11 05:40:04 --> Total execution time: 0.0174
ERROR - 2023-08-11 05:40:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:40:31 --> Config Class Initialized
INFO - 2023-08-11 05:40:31 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:40:31 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:40:31 --> Utf8 Class Initialized
INFO - 2023-08-11 05:40:31 --> URI Class Initialized
DEBUG - 2023-08-11 05:40:31 --> No URI present. Default controller set.
INFO - 2023-08-11 05:40:31 --> Router Class Initialized
INFO - 2023-08-11 05:40:31 --> Output Class Initialized
INFO - 2023-08-11 05:40:31 --> Security Class Initialized
DEBUG - 2023-08-11 05:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:40:31 --> Input Class Initialized
INFO - 2023-08-11 05:40:31 --> Language Class Initialized
INFO - 2023-08-11 05:40:31 --> Loader Class Initialized
INFO - 2023-08-11 05:40:31 --> Helper loaded: url_helper
INFO - 2023-08-11 05:40:31 --> Helper loaded: file_helper
INFO - 2023-08-11 05:40:31 --> Helper loaded: html_helper
INFO - 2023-08-11 05:40:31 --> Helper loaded: text_helper
INFO - 2023-08-11 05:40:31 --> Helper loaded: form_helper
INFO - 2023-08-11 05:40:31 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:40:31 --> Helper loaded: security_helper
INFO - 2023-08-11 05:40:31 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:40:31 --> Database Driver Class Initialized
INFO - 2023-08-11 05:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:40:31 --> Parser Class Initialized
INFO - 2023-08-11 05:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:40:31 --> Pagination Class Initialized
INFO - 2023-08-11 05:40:31 --> Form Validation Class Initialized
INFO - 2023-08-11 05:40:31 --> Controller Class Initialized
INFO - 2023-08-11 05:40:31 --> Model Class Initialized
DEBUG - 2023-08-11 05:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:31 --> Model Class Initialized
DEBUG - 2023-08-11 05:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:31 --> Model Class Initialized
INFO - 2023-08-11 05:40:31 --> Model Class Initialized
INFO - 2023-08-11 05:40:31 --> Model Class Initialized
INFO - 2023-08-11 05:40:31 --> Model Class Initialized
DEBUG - 2023-08-11 05:40:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:31 --> Model Class Initialized
INFO - 2023-08-11 05:40:31 --> Model Class Initialized
INFO - 2023-08-11 05:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 05:40:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:40:31 --> Model Class Initialized
INFO - 2023-08-11 05:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:40:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:40:31 --> Final output sent to browser
DEBUG - 2023-08-11 05:40:31 --> Total execution time: 0.0801
ERROR - 2023-08-11 05:41:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:41:27 --> Config Class Initialized
INFO - 2023-08-11 05:41:27 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:41:27 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:41:27 --> Utf8 Class Initialized
INFO - 2023-08-11 05:41:27 --> URI Class Initialized
DEBUG - 2023-08-11 05:41:27 --> No URI present. Default controller set.
INFO - 2023-08-11 05:41:27 --> Router Class Initialized
INFO - 2023-08-11 05:41:27 --> Output Class Initialized
INFO - 2023-08-11 05:41:27 --> Security Class Initialized
DEBUG - 2023-08-11 05:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:41:27 --> Input Class Initialized
INFO - 2023-08-11 05:41:27 --> Language Class Initialized
INFO - 2023-08-11 05:41:27 --> Loader Class Initialized
INFO - 2023-08-11 05:41:27 --> Helper loaded: url_helper
INFO - 2023-08-11 05:41:27 --> Helper loaded: file_helper
INFO - 2023-08-11 05:41:27 --> Helper loaded: html_helper
INFO - 2023-08-11 05:41:27 --> Helper loaded: text_helper
INFO - 2023-08-11 05:41:27 --> Helper loaded: form_helper
INFO - 2023-08-11 05:41:27 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:41:27 --> Helper loaded: security_helper
INFO - 2023-08-11 05:41:27 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:41:28 --> Database Driver Class Initialized
INFO - 2023-08-11 05:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:41:28 --> Parser Class Initialized
INFO - 2023-08-11 05:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:41:28 --> Pagination Class Initialized
INFO - 2023-08-11 05:41:28 --> Form Validation Class Initialized
INFO - 2023-08-11 05:41:28 --> Controller Class Initialized
INFO - 2023-08-11 05:41:28 --> Model Class Initialized
DEBUG - 2023-08-11 05:41:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 05:41:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:41:28 --> Config Class Initialized
INFO - 2023-08-11 05:41:28 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:41:28 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:41:28 --> Utf8 Class Initialized
INFO - 2023-08-11 05:41:28 --> URI Class Initialized
INFO - 2023-08-11 05:41:28 --> Router Class Initialized
INFO - 2023-08-11 05:41:28 --> Output Class Initialized
INFO - 2023-08-11 05:41:28 --> Security Class Initialized
DEBUG - 2023-08-11 05:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:41:28 --> Input Class Initialized
INFO - 2023-08-11 05:41:28 --> Language Class Initialized
INFO - 2023-08-11 05:41:28 --> Loader Class Initialized
INFO - 2023-08-11 05:41:28 --> Helper loaded: url_helper
INFO - 2023-08-11 05:41:28 --> Helper loaded: file_helper
INFO - 2023-08-11 05:41:28 --> Helper loaded: html_helper
INFO - 2023-08-11 05:41:28 --> Helper loaded: text_helper
INFO - 2023-08-11 05:41:28 --> Helper loaded: form_helper
INFO - 2023-08-11 05:41:28 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:41:28 --> Helper loaded: security_helper
INFO - 2023-08-11 05:41:28 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:41:28 --> Database Driver Class Initialized
INFO - 2023-08-11 05:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:41:28 --> Parser Class Initialized
INFO - 2023-08-11 05:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:41:28 --> Pagination Class Initialized
INFO - 2023-08-11 05:41:28 --> Form Validation Class Initialized
INFO - 2023-08-11 05:41:28 --> Controller Class Initialized
INFO - 2023-08-11 05:41:28 --> Model Class Initialized
DEBUG - 2023-08-11 05:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 05:41:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:41:28 --> Model Class Initialized
INFO - 2023-08-11 05:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:41:28 --> Final output sent to browser
DEBUG - 2023-08-11 05:41:28 --> Total execution time: 0.0349
ERROR - 2023-08-11 05:42:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:42:22 --> Config Class Initialized
INFO - 2023-08-11 05:42:22 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:42:22 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:42:22 --> Utf8 Class Initialized
INFO - 2023-08-11 05:42:22 --> URI Class Initialized
INFO - 2023-08-11 05:42:22 --> Router Class Initialized
INFO - 2023-08-11 05:42:22 --> Output Class Initialized
INFO - 2023-08-11 05:42:22 --> Security Class Initialized
DEBUG - 2023-08-11 05:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:42:22 --> Input Class Initialized
INFO - 2023-08-11 05:42:22 --> Language Class Initialized
INFO - 2023-08-11 05:42:22 --> Loader Class Initialized
INFO - 2023-08-11 05:42:22 --> Helper loaded: url_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: file_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: html_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: text_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: form_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: security_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:42:22 --> Database Driver Class Initialized
INFO - 2023-08-11 05:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:42:22 --> Parser Class Initialized
INFO - 2023-08-11 05:42:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:42:22 --> Pagination Class Initialized
INFO - 2023-08-11 05:42:22 --> Form Validation Class Initialized
INFO - 2023-08-11 05:42:22 --> Controller Class Initialized
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
INFO - 2023-08-11 05:42:22 --> Final output sent to browser
DEBUG - 2023-08-11 05:42:22 --> Total execution time: 0.0195
ERROR - 2023-08-11 05:42:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:42:22 --> Config Class Initialized
INFO - 2023-08-11 05:42:22 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:42:22 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:42:22 --> Utf8 Class Initialized
INFO - 2023-08-11 05:42:22 --> URI Class Initialized
DEBUG - 2023-08-11 05:42:22 --> No URI present. Default controller set.
INFO - 2023-08-11 05:42:22 --> Router Class Initialized
INFO - 2023-08-11 05:42:22 --> Output Class Initialized
INFO - 2023-08-11 05:42:22 --> Security Class Initialized
DEBUG - 2023-08-11 05:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:42:22 --> Input Class Initialized
INFO - 2023-08-11 05:42:22 --> Language Class Initialized
INFO - 2023-08-11 05:42:22 --> Loader Class Initialized
INFO - 2023-08-11 05:42:22 --> Helper loaded: url_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: file_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: html_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: text_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: form_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: security_helper
INFO - 2023-08-11 05:42:22 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:42:22 --> Database Driver Class Initialized
INFO - 2023-08-11 05:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:42:22 --> Parser Class Initialized
INFO - 2023-08-11 05:42:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:42:22 --> Pagination Class Initialized
INFO - 2023-08-11 05:42:22 --> Form Validation Class Initialized
INFO - 2023-08-11 05:42:22 --> Controller Class Initialized
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
INFO - 2023-08-11 05:42:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 05:42:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:42:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:42:22 --> Model Class Initialized
INFO - 2023-08-11 05:42:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:42:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:42:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:42:22 --> Final output sent to browser
DEBUG - 2023-08-11 05:42:22 --> Total execution time: 0.0895
ERROR - 2023-08-11 05:42:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:42:34 --> Config Class Initialized
INFO - 2023-08-11 05:42:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:42:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:42:34 --> Utf8 Class Initialized
INFO - 2023-08-11 05:42:34 --> URI Class Initialized
INFO - 2023-08-11 05:42:34 --> Router Class Initialized
INFO - 2023-08-11 05:42:34 --> Output Class Initialized
INFO - 2023-08-11 05:42:34 --> Security Class Initialized
DEBUG - 2023-08-11 05:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:42:34 --> Input Class Initialized
INFO - 2023-08-11 05:42:34 --> Language Class Initialized
INFO - 2023-08-11 05:42:34 --> Loader Class Initialized
INFO - 2023-08-11 05:42:34 --> Helper loaded: url_helper
INFO - 2023-08-11 05:42:34 --> Helper loaded: file_helper
INFO - 2023-08-11 05:42:34 --> Helper loaded: html_helper
INFO - 2023-08-11 05:42:34 --> Helper loaded: text_helper
INFO - 2023-08-11 05:42:34 --> Helper loaded: form_helper
INFO - 2023-08-11 05:42:34 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:42:34 --> Helper loaded: security_helper
INFO - 2023-08-11 05:42:34 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:42:34 --> Database Driver Class Initialized
INFO - 2023-08-11 05:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:42:34 --> Parser Class Initialized
INFO - 2023-08-11 05:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:42:34 --> Pagination Class Initialized
INFO - 2023-08-11 05:42:34 --> Form Validation Class Initialized
INFO - 2023-08-11 05:42:34 --> Controller Class Initialized
INFO - 2023-08-11 05:42:34 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:34 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:34 --> Model Class Initialized
INFO - 2023-08-11 05:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-11 05:42:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:42:34 --> Model Class Initialized
INFO - 2023-08-11 05:42:34 --> Model Class Initialized
INFO - 2023-08-11 05:42:34 --> Model Class Initialized
INFO - 2023-08-11 05:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:42:34 --> Final output sent to browser
DEBUG - 2023-08-11 05:42:34 --> Total execution time: 0.0760
ERROR - 2023-08-11 05:42:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:42:35 --> Config Class Initialized
INFO - 2023-08-11 05:42:35 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:42:35 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:42:35 --> Utf8 Class Initialized
INFO - 2023-08-11 05:42:35 --> URI Class Initialized
INFO - 2023-08-11 05:42:35 --> Router Class Initialized
INFO - 2023-08-11 05:42:35 --> Output Class Initialized
INFO - 2023-08-11 05:42:35 --> Security Class Initialized
DEBUG - 2023-08-11 05:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:42:35 --> Input Class Initialized
INFO - 2023-08-11 05:42:35 --> Language Class Initialized
INFO - 2023-08-11 05:42:35 --> Loader Class Initialized
INFO - 2023-08-11 05:42:35 --> Helper loaded: url_helper
INFO - 2023-08-11 05:42:35 --> Helper loaded: file_helper
INFO - 2023-08-11 05:42:35 --> Helper loaded: html_helper
INFO - 2023-08-11 05:42:35 --> Helper loaded: text_helper
INFO - 2023-08-11 05:42:35 --> Helper loaded: form_helper
INFO - 2023-08-11 05:42:35 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:42:35 --> Helper loaded: security_helper
INFO - 2023-08-11 05:42:35 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:42:35 --> Database Driver Class Initialized
INFO - 2023-08-11 05:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:42:35 --> Parser Class Initialized
INFO - 2023-08-11 05:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:42:35 --> Pagination Class Initialized
INFO - 2023-08-11 05:42:35 --> Form Validation Class Initialized
INFO - 2023-08-11 05:42:35 --> Controller Class Initialized
INFO - 2023-08-11 05:42:35 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:35 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:35 --> Model Class Initialized
INFO - 2023-08-11 05:42:35 --> Final output sent to browser
DEBUG - 2023-08-11 05:42:35 --> Total execution time: 0.0370
ERROR - 2023-08-11 05:42:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:42:56 --> Config Class Initialized
INFO - 2023-08-11 05:42:56 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:42:56 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:42:56 --> Utf8 Class Initialized
INFO - 2023-08-11 05:42:56 --> URI Class Initialized
INFO - 2023-08-11 05:42:56 --> Router Class Initialized
INFO - 2023-08-11 05:42:56 --> Output Class Initialized
INFO - 2023-08-11 05:42:56 --> Security Class Initialized
DEBUG - 2023-08-11 05:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:42:56 --> Input Class Initialized
INFO - 2023-08-11 05:42:56 --> Language Class Initialized
INFO - 2023-08-11 05:42:56 --> Loader Class Initialized
INFO - 2023-08-11 05:42:56 --> Helper loaded: url_helper
INFO - 2023-08-11 05:42:56 --> Helper loaded: file_helper
INFO - 2023-08-11 05:42:56 --> Helper loaded: html_helper
INFO - 2023-08-11 05:42:56 --> Helper loaded: text_helper
INFO - 2023-08-11 05:42:56 --> Helper loaded: form_helper
INFO - 2023-08-11 05:42:56 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:42:56 --> Helper loaded: security_helper
INFO - 2023-08-11 05:42:56 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:42:56 --> Database Driver Class Initialized
INFO - 2023-08-11 05:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:42:56 --> Parser Class Initialized
INFO - 2023-08-11 05:42:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:42:56 --> Pagination Class Initialized
INFO - 2023-08-11 05:42:56 --> Form Validation Class Initialized
INFO - 2023-08-11 05:42:56 --> Controller Class Initialized
INFO - 2023-08-11 05:42:56 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:56 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:56 --> Model Class Initialized
DEBUG - 2023-08-11 05:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-11 05:42:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:42:56 --> Model Class Initialized
INFO - 2023-08-11 05:42:56 --> Model Class Initialized
INFO - 2023-08-11 05:42:56 --> Model Class Initialized
INFO - 2023-08-11 05:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:42:56 --> Final output sent to browser
DEBUG - 2023-08-11 05:42:56 --> Total execution time: 0.0808
ERROR - 2023-08-11 05:43:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:43:23 --> Config Class Initialized
INFO - 2023-08-11 05:43:23 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:43:23 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:43:23 --> Utf8 Class Initialized
INFO - 2023-08-11 05:43:23 --> URI Class Initialized
INFO - 2023-08-11 05:43:23 --> Router Class Initialized
INFO - 2023-08-11 05:43:23 --> Output Class Initialized
INFO - 2023-08-11 05:43:23 --> Security Class Initialized
DEBUG - 2023-08-11 05:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:43:23 --> Input Class Initialized
INFO - 2023-08-11 05:43:23 --> Language Class Initialized
INFO - 2023-08-11 05:43:23 --> Loader Class Initialized
INFO - 2023-08-11 05:43:23 --> Helper loaded: url_helper
INFO - 2023-08-11 05:43:23 --> Helper loaded: file_helper
INFO - 2023-08-11 05:43:23 --> Helper loaded: html_helper
INFO - 2023-08-11 05:43:23 --> Helper loaded: text_helper
INFO - 2023-08-11 05:43:23 --> Helper loaded: form_helper
INFO - 2023-08-11 05:43:23 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:43:23 --> Helper loaded: security_helper
INFO - 2023-08-11 05:43:23 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:43:23 --> Database Driver Class Initialized
INFO - 2023-08-11 05:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:43:23 --> Parser Class Initialized
INFO - 2023-08-11 05:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:43:23 --> Pagination Class Initialized
INFO - 2023-08-11 05:43:23 --> Form Validation Class Initialized
INFO - 2023-08-11 05:43:23 --> Controller Class Initialized
INFO - 2023-08-11 05:43:23 --> Model Class Initialized
DEBUG - 2023-08-11 05:43:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:43:23 --> Model Class Initialized
DEBUG - 2023-08-11 05:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:43:23 --> Model Class Initialized
INFO - 2023-08-11 05:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-11 05:43:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:43:24 --> Model Class Initialized
INFO - 2023-08-11 05:43:24 --> Model Class Initialized
INFO - 2023-08-11 05:43:24 --> Model Class Initialized
INFO - 2023-08-11 05:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:43:24 --> Final output sent to browser
DEBUG - 2023-08-11 05:43:24 --> Total execution time: 0.0853
ERROR - 2023-08-11 05:43:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:43:25 --> Config Class Initialized
INFO - 2023-08-11 05:43:25 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:43:25 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:43:25 --> Utf8 Class Initialized
INFO - 2023-08-11 05:43:25 --> URI Class Initialized
INFO - 2023-08-11 05:43:25 --> Router Class Initialized
INFO - 2023-08-11 05:43:25 --> Output Class Initialized
INFO - 2023-08-11 05:43:25 --> Security Class Initialized
DEBUG - 2023-08-11 05:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:43:25 --> Input Class Initialized
INFO - 2023-08-11 05:43:25 --> Language Class Initialized
INFO - 2023-08-11 05:43:25 --> Loader Class Initialized
INFO - 2023-08-11 05:43:25 --> Helper loaded: url_helper
INFO - 2023-08-11 05:43:25 --> Helper loaded: file_helper
INFO - 2023-08-11 05:43:25 --> Helper loaded: html_helper
INFO - 2023-08-11 05:43:25 --> Helper loaded: text_helper
INFO - 2023-08-11 05:43:25 --> Helper loaded: form_helper
INFO - 2023-08-11 05:43:25 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:43:25 --> Helper loaded: security_helper
INFO - 2023-08-11 05:43:25 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:43:25 --> Database Driver Class Initialized
INFO - 2023-08-11 05:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:43:25 --> Parser Class Initialized
INFO - 2023-08-11 05:43:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:43:25 --> Pagination Class Initialized
INFO - 2023-08-11 05:43:25 --> Form Validation Class Initialized
INFO - 2023-08-11 05:43:25 --> Controller Class Initialized
INFO - 2023-08-11 05:43:25 --> Model Class Initialized
DEBUG - 2023-08-11 05:43:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:43:25 --> Model Class Initialized
DEBUG - 2023-08-11 05:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:43:25 --> Model Class Initialized
INFO - 2023-08-11 05:43:25 --> Final output sent to browser
DEBUG - 2023-08-11 05:43:25 --> Total execution time: 0.0368
ERROR - 2023-08-11 05:58:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:58:40 --> Config Class Initialized
INFO - 2023-08-11 05:58:40 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:58:40 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:58:40 --> Utf8 Class Initialized
INFO - 2023-08-11 05:58:40 --> URI Class Initialized
DEBUG - 2023-08-11 05:58:40 --> No URI present. Default controller set.
INFO - 2023-08-11 05:58:40 --> Router Class Initialized
INFO - 2023-08-11 05:58:40 --> Output Class Initialized
INFO - 2023-08-11 05:58:40 --> Security Class Initialized
DEBUG - 2023-08-11 05:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:58:40 --> Input Class Initialized
INFO - 2023-08-11 05:58:40 --> Language Class Initialized
INFO - 2023-08-11 05:58:40 --> Loader Class Initialized
INFO - 2023-08-11 05:58:40 --> Helper loaded: url_helper
INFO - 2023-08-11 05:58:40 --> Helper loaded: file_helper
INFO - 2023-08-11 05:58:40 --> Helper loaded: html_helper
INFO - 2023-08-11 05:58:40 --> Helper loaded: text_helper
INFO - 2023-08-11 05:58:40 --> Helper loaded: form_helper
INFO - 2023-08-11 05:58:40 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:58:40 --> Helper loaded: security_helper
INFO - 2023-08-11 05:58:40 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:58:40 --> Database Driver Class Initialized
INFO - 2023-08-11 05:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:58:40 --> Parser Class Initialized
INFO - 2023-08-11 05:58:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:58:40 --> Pagination Class Initialized
INFO - 2023-08-11 05:58:40 --> Form Validation Class Initialized
INFO - 2023-08-11 05:58:40 --> Controller Class Initialized
INFO - 2023-08-11 05:58:40 --> Model Class Initialized
DEBUG - 2023-08-11 05:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:58:40 --> Model Class Initialized
DEBUG - 2023-08-11 05:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:58:40 --> Model Class Initialized
INFO - 2023-08-11 05:58:40 --> Model Class Initialized
INFO - 2023-08-11 05:58:40 --> Model Class Initialized
INFO - 2023-08-11 05:58:40 --> Model Class Initialized
DEBUG - 2023-08-11 05:58:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:58:40 --> Model Class Initialized
INFO - 2023-08-11 05:58:40 --> Model Class Initialized
INFO - 2023-08-11 05:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 05:58:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:58:40 --> Model Class Initialized
INFO - 2023-08-11 05:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:58:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:58:40 --> Final output sent to browser
DEBUG - 2023-08-11 05:58:40 --> Total execution time: 0.0905
ERROR - 2023-08-11 05:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:58:59 --> Config Class Initialized
INFO - 2023-08-11 05:58:59 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:58:59 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:58:59 --> Utf8 Class Initialized
INFO - 2023-08-11 05:58:59 --> URI Class Initialized
INFO - 2023-08-11 05:58:59 --> Router Class Initialized
INFO - 2023-08-11 05:58:59 --> Output Class Initialized
INFO - 2023-08-11 05:58:59 --> Security Class Initialized
DEBUG - 2023-08-11 05:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:58:59 --> Input Class Initialized
INFO - 2023-08-11 05:58:59 --> Language Class Initialized
INFO - 2023-08-11 05:58:59 --> Loader Class Initialized
INFO - 2023-08-11 05:58:59 --> Helper loaded: url_helper
INFO - 2023-08-11 05:58:59 --> Helper loaded: file_helper
INFO - 2023-08-11 05:58:59 --> Helper loaded: html_helper
INFO - 2023-08-11 05:58:59 --> Helper loaded: text_helper
INFO - 2023-08-11 05:58:59 --> Helper loaded: form_helper
INFO - 2023-08-11 05:58:59 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:58:59 --> Helper loaded: security_helper
INFO - 2023-08-11 05:58:59 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:58:59 --> Database Driver Class Initialized
INFO - 2023-08-11 05:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:58:59 --> Parser Class Initialized
INFO - 2023-08-11 05:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:58:59 --> Pagination Class Initialized
INFO - 2023-08-11 05:58:59 --> Form Validation Class Initialized
INFO - 2023-08-11 05:58:59 --> Controller Class Initialized
INFO - 2023-08-11 05:58:59 --> Model Class Initialized
DEBUG - 2023-08-11 05:58:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:58:59 --> Model Class Initialized
DEBUG - 2023-08-11 05:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:58:59 --> Model Class Initialized
INFO - 2023-08-11 05:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-11 05:58:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:58:59 --> Model Class Initialized
INFO - 2023-08-11 05:58:59 --> Model Class Initialized
INFO - 2023-08-11 05:58:59 --> Model Class Initialized
INFO - 2023-08-11 05:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:58:59 --> Final output sent to browser
DEBUG - 2023-08-11 05:58:59 --> Total execution time: 0.0869
ERROR - 2023-08-11 05:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:59:00 --> Config Class Initialized
INFO - 2023-08-11 05:59:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:59:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:59:00 --> Utf8 Class Initialized
INFO - 2023-08-11 05:59:00 --> URI Class Initialized
INFO - 2023-08-11 05:59:00 --> Router Class Initialized
INFO - 2023-08-11 05:59:00 --> Output Class Initialized
INFO - 2023-08-11 05:59:00 --> Security Class Initialized
DEBUG - 2023-08-11 05:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:59:00 --> Input Class Initialized
INFO - 2023-08-11 05:59:00 --> Language Class Initialized
INFO - 2023-08-11 05:59:00 --> Loader Class Initialized
INFO - 2023-08-11 05:59:00 --> Helper loaded: url_helper
INFO - 2023-08-11 05:59:00 --> Helper loaded: file_helper
INFO - 2023-08-11 05:59:00 --> Helper loaded: html_helper
INFO - 2023-08-11 05:59:00 --> Helper loaded: text_helper
INFO - 2023-08-11 05:59:00 --> Helper loaded: form_helper
INFO - 2023-08-11 05:59:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:59:00 --> Helper loaded: security_helper
INFO - 2023-08-11 05:59:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:59:00 --> Database Driver Class Initialized
INFO - 2023-08-11 05:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:59:00 --> Parser Class Initialized
INFO - 2023-08-11 05:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:59:00 --> Pagination Class Initialized
INFO - 2023-08-11 05:59:00 --> Form Validation Class Initialized
INFO - 2023-08-11 05:59:00 --> Controller Class Initialized
INFO - 2023-08-11 05:59:00 --> Model Class Initialized
DEBUG - 2023-08-11 05:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:00 --> Model Class Initialized
DEBUG - 2023-08-11 05:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:00 --> Model Class Initialized
INFO - 2023-08-11 05:59:00 --> Final output sent to browser
DEBUG - 2023-08-11 05:59:00 --> Total execution time: 0.0232
ERROR - 2023-08-11 05:59:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:59:04 --> Config Class Initialized
INFO - 2023-08-11 05:59:04 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:59:04 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:59:04 --> Utf8 Class Initialized
INFO - 2023-08-11 05:59:04 --> URI Class Initialized
DEBUG - 2023-08-11 05:59:04 --> No URI present. Default controller set.
INFO - 2023-08-11 05:59:04 --> Router Class Initialized
INFO - 2023-08-11 05:59:04 --> Output Class Initialized
INFO - 2023-08-11 05:59:04 --> Security Class Initialized
DEBUG - 2023-08-11 05:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:59:04 --> Input Class Initialized
INFO - 2023-08-11 05:59:04 --> Language Class Initialized
INFO - 2023-08-11 05:59:04 --> Loader Class Initialized
INFO - 2023-08-11 05:59:04 --> Helper loaded: url_helper
INFO - 2023-08-11 05:59:04 --> Helper loaded: file_helper
INFO - 2023-08-11 05:59:04 --> Helper loaded: html_helper
INFO - 2023-08-11 05:59:04 --> Helper loaded: text_helper
INFO - 2023-08-11 05:59:04 --> Helper loaded: form_helper
INFO - 2023-08-11 05:59:04 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:59:04 --> Helper loaded: security_helper
INFO - 2023-08-11 05:59:04 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:59:04 --> Database Driver Class Initialized
INFO - 2023-08-11 05:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:59:04 --> Parser Class Initialized
INFO - 2023-08-11 05:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:59:04 --> Pagination Class Initialized
INFO - 2023-08-11 05:59:04 --> Form Validation Class Initialized
INFO - 2023-08-11 05:59:04 --> Controller Class Initialized
INFO - 2023-08-11 05:59:04 --> Model Class Initialized
DEBUG - 2023-08-11 05:59:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:04 --> Model Class Initialized
DEBUG - 2023-08-11 05:59:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:04 --> Model Class Initialized
INFO - 2023-08-11 05:59:04 --> Model Class Initialized
INFO - 2023-08-11 05:59:04 --> Model Class Initialized
INFO - 2023-08-11 05:59:04 --> Model Class Initialized
DEBUG - 2023-08-11 05:59:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:59:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:04 --> Model Class Initialized
INFO - 2023-08-11 05:59:04 --> Model Class Initialized
INFO - 2023-08-11 05:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 05:59:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:59:04 --> Model Class Initialized
INFO - 2023-08-11 05:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:59:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:59:04 --> Final output sent to browser
DEBUG - 2023-08-11 05:59:04 --> Total execution time: 0.0888
ERROR - 2023-08-11 05:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:59:11 --> Config Class Initialized
INFO - 2023-08-11 05:59:11 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:59:11 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:59:11 --> Utf8 Class Initialized
INFO - 2023-08-11 05:59:11 --> URI Class Initialized
INFO - 2023-08-11 05:59:11 --> Router Class Initialized
INFO - 2023-08-11 05:59:11 --> Output Class Initialized
INFO - 2023-08-11 05:59:11 --> Security Class Initialized
DEBUG - 2023-08-11 05:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:59:11 --> Input Class Initialized
INFO - 2023-08-11 05:59:11 --> Language Class Initialized
INFO - 2023-08-11 05:59:11 --> Loader Class Initialized
INFO - 2023-08-11 05:59:11 --> Helper loaded: url_helper
INFO - 2023-08-11 05:59:11 --> Helper loaded: file_helper
INFO - 2023-08-11 05:59:11 --> Helper loaded: html_helper
INFO - 2023-08-11 05:59:11 --> Helper loaded: text_helper
INFO - 2023-08-11 05:59:11 --> Helper loaded: form_helper
INFO - 2023-08-11 05:59:11 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:59:11 --> Helper loaded: security_helper
INFO - 2023-08-11 05:59:11 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:59:11 --> Database Driver Class Initialized
INFO - 2023-08-11 05:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:59:11 --> Parser Class Initialized
INFO - 2023-08-11 05:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:59:11 --> Pagination Class Initialized
INFO - 2023-08-11 05:59:11 --> Form Validation Class Initialized
INFO - 2023-08-11 05:59:11 --> Controller Class Initialized
INFO - 2023-08-11 05:59:11 --> Model Class Initialized
DEBUG - 2023-08-11 05:59:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:11 --> Model Class Initialized
DEBUG - 2023-08-11 05:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:11 --> Model Class Initialized
INFO - 2023-08-11 05:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-11 05:59:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 05:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 05:59:11 --> Model Class Initialized
INFO - 2023-08-11 05:59:11 --> Model Class Initialized
INFO - 2023-08-11 05:59:11 --> Model Class Initialized
INFO - 2023-08-11 05:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 05:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 05:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 05:59:11 --> Final output sent to browser
DEBUG - 2023-08-11 05:59:11 --> Total execution time: 0.0743
ERROR - 2023-08-11 05:59:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 05:59:15 --> Config Class Initialized
INFO - 2023-08-11 05:59:15 --> Hooks Class Initialized
DEBUG - 2023-08-11 05:59:15 --> UTF-8 Support Enabled
INFO - 2023-08-11 05:59:15 --> Utf8 Class Initialized
INFO - 2023-08-11 05:59:15 --> URI Class Initialized
INFO - 2023-08-11 05:59:15 --> Router Class Initialized
INFO - 2023-08-11 05:59:15 --> Output Class Initialized
INFO - 2023-08-11 05:59:15 --> Security Class Initialized
DEBUG - 2023-08-11 05:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 05:59:15 --> Input Class Initialized
INFO - 2023-08-11 05:59:15 --> Language Class Initialized
INFO - 2023-08-11 05:59:15 --> Loader Class Initialized
INFO - 2023-08-11 05:59:15 --> Helper loaded: url_helper
INFO - 2023-08-11 05:59:15 --> Helper loaded: file_helper
INFO - 2023-08-11 05:59:15 --> Helper loaded: html_helper
INFO - 2023-08-11 05:59:15 --> Helper loaded: text_helper
INFO - 2023-08-11 05:59:15 --> Helper loaded: form_helper
INFO - 2023-08-11 05:59:15 --> Helper loaded: lang_helper
INFO - 2023-08-11 05:59:15 --> Helper loaded: security_helper
INFO - 2023-08-11 05:59:15 --> Helper loaded: cookie_helper
INFO - 2023-08-11 05:59:15 --> Database Driver Class Initialized
INFO - 2023-08-11 05:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 05:59:15 --> Parser Class Initialized
INFO - 2023-08-11 05:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 05:59:15 --> Pagination Class Initialized
INFO - 2023-08-11 05:59:15 --> Form Validation Class Initialized
INFO - 2023-08-11 05:59:15 --> Controller Class Initialized
INFO - 2023-08-11 05:59:15 --> Model Class Initialized
DEBUG - 2023-08-11 05:59:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 05:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:15 --> Model Class Initialized
DEBUG - 2023-08-11 05:59:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 05:59:15 --> Model Class Initialized
INFO - 2023-08-11 05:59:15 --> Final output sent to browser
DEBUG - 2023-08-11 05:59:15 --> Total execution time: 0.0265
ERROR - 2023-08-11 06:16:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 06:16:19 --> Config Class Initialized
INFO - 2023-08-11 06:16:19 --> Hooks Class Initialized
DEBUG - 2023-08-11 06:16:19 --> UTF-8 Support Enabled
INFO - 2023-08-11 06:16:19 --> Utf8 Class Initialized
INFO - 2023-08-11 06:16:19 --> URI Class Initialized
DEBUG - 2023-08-11 06:16:19 --> No URI present. Default controller set.
INFO - 2023-08-11 06:16:19 --> Router Class Initialized
INFO - 2023-08-11 06:16:19 --> Output Class Initialized
INFO - 2023-08-11 06:16:19 --> Security Class Initialized
DEBUG - 2023-08-11 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 06:16:19 --> Input Class Initialized
INFO - 2023-08-11 06:16:19 --> Language Class Initialized
INFO - 2023-08-11 06:16:19 --> Loader Class Initialized
INFO - 2023-08-11 06:16:19 --> Helper loaded: url_helper
INFO - 2023-08-11 06:16:19 --> Helper loaded: file_helper
INFO - 2023-08-11 06:16:19 --> Helper loaded: html_helper
INFO - 2023-08-11 06:16:19 --> Helper loaded: text_helper
INFO - 2023-08-11 06:16:19 --> Helper loaded: form_helper
INFO - 2023-08-11 06:16:19 --> Helper loaded: lang_helper
INFO - 2023-08-11 06:16:19 --> Helper loaded: security_helper
INFO - 2023-08-11 06:16:19 --> Helper loaded: cookie_helper
INFO - 2023-08-11 06:16:19 --> Database Driver Class Initialized
INFO - 2023-08-11 06:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 06:16:19 --> Parser Class Initialized
INFO - 2023-08-11 06:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 06:16:19 --> Pagination Class Initialized
INFO - 2023-08-11 06:16:19 --> Form Validation Class Initialized
INFO - 2023-08-11 06:16:19 --> Controller Class Initialized
INFO - 2023-08-11 06:16:19 --> Model Class Initialized
DEBUG - 2023-08-11 06:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 06:16:19 --> Model Class Initialized
DEBUG - 2023-08-11 06:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 06:16:19 --> Model Class Initialized
INFO - 2023-08-11 06:16:19 --> Model Class Initialized
INFO - 2023-08-11 06:16:19 --> Model Class Initialized
INFO - 2023-08-11 06:16:19 --> Model Class Initialized
DEBUG - 2023-08-11 06:16:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 06:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 06:16:19 --> Model Class Initialized
INFO - 2023-08-11 06:16:19 --> Model Class Initialized
INFO - 2023-08-11 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 06:16:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 06:16:19 --> Model Class Initialized
INFO - 2023-08-11 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 06:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 06:16:19 --> Final output sent to browser
DEBUG - 2023-08-11 06:16:19 --> Total execution time: 0.0833
ERROR - 2023-08-11 07:18:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:18:19 --> Config Class Initialized
INFO - 2023-08-11 07:18:19 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:18:19 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:18:19 --> Utf8 Class Initialized
INFO - 2023-08-11 07:18:19 --> URI Class Initialized
DEBUG - 2023-08-11 07:18:19 --> No URI present. Default controller set.
INFO - 2023-08-11 07:18:19 --> Router Class Initialized
INFO - 2023-08-11 07:18:19 --> Output Class Initialized
INFO - 2023-08-11 07:18:19 --> Security Class Initialized
DEBUG - 2023-08-11 07:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:18:19 --> Input Class Initialized
INFO - 2023-08-11 07:18:19 --> Language Class Initialized
INFO - 2023-08-11 07:18:19 --> Loader Class Initialized
INFO - 2023-08-11 07:18:19 --> Helper loaded: url_helper
INFO - 2023-08-11 07:18:19 --> Helper loaded: file_helper
INFO - 2023-08-11 07:18:19 --> Helper loaded: html_helper
INFO - 2023-08-11 07:18:19 --> Helper loaded: text_helper
INFO - 2023-08-11 07:18:19 --> Helper loaded: form_helper
INFO - 2023-08-11 07:18:19 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:18:19 --> Helper loaded: security_helper
INFO - 2023-08-11 07:18:19 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:18:19 --> Database Driver Class Initialized
INFO - 2023-08-11 07:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:18:19 --> Parser Class Initialized
INFO - 2023-08-11 07:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:18:19 --> Pagination Class Initialized
INFO - 2023-08-11 07:18:19 --> Form Validation Class Initialized
INFO - 2023-08-11 07:18:19 --> Controller Class Initialized
INFO - 2023-08-11 07:18:19 --> Model Class Initialized
DEBUG - 2023-08-11 07:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:18:19 --> Model Class Initialized
DEBUG - 2023-08-11 07:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:18:19 --> Model Class Initialized
INFO - 2023-08-11 07:18:19 --> Model Class Initialized
INFO - 2023-08-11 07:18:19 --> Model Class Initialized
INFO - 2023-08-11 07:18:19 --> Model Class Initialized
DEBUG - 2023-08-11 07:18:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:18:19 --> Model Class Initialized
INFO - 2023-08-11 07:18:19 --> Model Class Initialized
INFO - 2023-08-11 07:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 07:18:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 07:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 07:18:19 --> Model Class Initialized
INFO - 2023-08-11 07:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 07:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 07:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 07:18:19 --> Final output sent to browser
DEBUG - 2023-08-11 07:18:19 --> Total execution time: 0.1009
ERROR - 2023-08-11 07:18:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:18:48 --> Config Class Initialized
INFO - 2023-08-11 07:18:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:18:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:18:48 --> Utf8 Class Initialized
INFO - 2023-08-11 07:18:48 --> URI Class Initialized
INFO - 2023-08-11 07:18:48 --> Router Class Initialized
INFO - 2023-08-11 07:18:48 --> Output Class Initialized
INFO - 2023-08-11 07:18:48 --> Security Class Initialized
DEBUG - 2023-08-11 07:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:18:48 --> Input Class Initialized
INFO - 2023-08-11 07:18:48 --> Language Class Initialized
INFO - 2023-08-11 07:18:48 --> Loader Class Initialized
INFO - 2023-08-11 07:18:48 --> Helper loaded: url_helper
INFO - 2023-08-11 07:18:48 --> Helper loaded: file_helper
INFO - 2023-08-11 07:18:48 --> Helper loaded: html_helper
INFO - 2023-08-11 07:18:48 --> Helper loaded: text_helper
INFO - 2023-08-11 07:18:48 --> Helper loaded: form_helper
INFO - 2023-08-11 07:18:48 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:18:48 --> Helper loaded: security_helper
INFO - 2023-08-11 07:18:48 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:18:48 --> Database Driver Class Initialized
INFO - 2023-08-11 07:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:18:48 --> Parser Class Initialized
INFO - 2023-08-11 07:18:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:18:48 --> Pagination Class Initialized
INFO - 2023-08-11 07:18:48 --> Form Validation Class Initialized
INFO - 2023-08-11 07:18:48 --> Controller Class Initialized
INFO - 2023-08-11 07:18:48 --> Model Class Initialized
DEBUG - 2023-08-11 07:18:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:18:48 --> Model Class Initialized
DEBUG - 2023-08-11 07:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:18:48 --> Model Class Initialized
INFO - 2023-08-11 07:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-11 07:18:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 07:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 07:18:48 --> Model Class Initialized
INFO - 2023-08-11 07:18:48 --> Model Class Initialized
INFO - 2023-08-11 07:18:48 --> Model Class Initialized
INFO - 2023-08-11 07:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 07:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 07:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 07:18:48 --> Final output sent to browser
DEBUG - 2023-08-11 07:18:48 --> Total execution time: 0.0781
ERROR - 2023-08-11 07:18:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:18:49 --> Config Class Initialized
INFO - 2023-08-11 07:18:49 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:18:49 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:18:49 --> Utf8 Class Initialized
INFO - 2023-08-11 07:18:49 --> URI Class Initialized
INFO - 2023-08-11 07:18:49 --> Router Class Initialized
INFO - 2023-08-11 07:18:49 --> Output Class Initialized
INFO - 2023-08-11 07:18:49 --> Security Class Initialized
DEBUG - 2023-08-11 07:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:18:49 --> Input Class Initialized
INFO - 2023-08-11 07:18:49 --> Language Class Initialized
INFO - 2023-08-11 07:18:49 --> Loader Class Initialized
INFO - 2023-08-11 07:18:49 --> Helper loaded: url_helper
INFO - 2023-08-11 07:18:49 --> Helper loaded: file_helper
INFO - 2023-08-11 07:18:49 --> Helper loaded: html_helper
INFO - 2023-08-11 07:18:49 --> Helper loaded: text_helper
INFO - 2023-08-11 07:18:49 --> Helper loaded: form_helper
INFO - 2023-08-11 07:18:49 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:18:49 --> Helper loaded: security_helper
INFO - 2023-08-11 07:18:49 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:18:49 --> Database Driver Class Initialized
INFO - 2023-08-11 07:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:18:49 --> Parser Class Initialized
INFO - 2023-08-11 07:18:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:18:49 --> Pagination Class Initialized
INFO - 2023-08-11 07:18:49 --> Form Validation Class Initialized
INFO - 2023-08-11 07:18:49 --> Controller Class Initialized
INFO - 2023-08-11 07:18:49 --> Model Class Initialized
DEBUG - 2023-08-11 07:18:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:18:49 --> Model Class Initialized
DEBUG - 2023-08-11 07:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:18:49 --> Model Class Initialized
INFO - 2023-08-11 07:18:49 --> Final output sent to browser
DEBUG - 2023-08-11 07:18:49 --> Total execution time: 0.0436
ERROR - 2023-08-11 07:19:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:19:26 --> Config Class Initialized
INFO - 2023-08-11 07:19:26 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:19:26 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:19:26 --> Utf8 Class Initialized
INFO - 2023-08-11 07:19:26 --> URI Class Initialized
INFO - 2023-08-11 07:19:26 --> Router Class Initialized
INFO - 2023-08-11 07:19:26 --> Output Class Initialized
INFO - 2023-08-11 07:19:26 --> Security Class Initialized
DEBUG - 2023-08-11 07:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:19:26 --> Input Class Initialized
INFO - 2023-08-11 07:19:26 --> Language Class Initialized
INFO - 2023-08-11 07:19:26 --> Loader Class Initialized
INFO - 2023-08-11 07:19:26 --> Helper loaded: url_helper
INFO - 2023-08-11 07:19:26 --> Helper loaded: file_helper
INFO - 2023-08-11 07:19:26 --> Helper loaded: html_helper
INFO - 2023-08-11 07:19:26 --> Helper loaded: text_helper
INFO - 2023-08-11 07:19:26 --> Helper loaded: form_helper
INFO - 2023-08-11 07:19:26 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:19:26 --> Helper loaded: security_helper
INFO - 2023-08-11 07:19:26 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:19:26 --> Database Driver Class Initialized
INFO - 2023-08-11 07:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:19:26 --> Parser Class Initialized
INFO - 2023-08-11 07:19:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:19:26 --> Pagination Class Initialized
INFO - 2023-08-11 07:19:26 --> Form Validation Class Initialized
INFO - 2023-08-11 07:19:26 --> Controller Class Initialized
INFO - 2023-08-11 07:19:26 --> Model Class Initialized
DEBUG - 2023-08-11 07:19:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:19:26 --> Model Class Initialized
DEBUG - 2023-08-11 07:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:19:26 --> Model Class Initialized
INFO - 2023-08-11 07:19:26 --> Final output sent to browser
DEBUG - 2023-08-11 07:19:26 --> Total execution time: 0.0418
ERROR - 2023-08-11 07:19:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:19:33 --> Config Class Initialized
INFO - 2023-08-11 07:19:33 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:19:33 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:19:33 --> Utf8 Class Initialized
INFO - 2023-08-11 07:19:33 --> URI Class Initialized
INFO - 2023-08-11 07:19:33 --> Router Class Initialized
INFO - 2023-08-11 07:19:33 --> Output Class Initialized
INFO - 2023-08-11 07:19:33 --> Security Class Initialized
DEBUG - 2023-08-11 07:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:19:33 --> Input Class Initialized
INFO - 2023-08-11 07:19:33 --> Language Class Initialized
INFO - 2023-08-11 07:19:33 --> Loader Class Initialized
INFO - 2023-08-11 07:19:33 --> Helper loaded: url_helper
INFO - 2023-08-11 07:19:33 --> Helper loaded: file_helper
INFO - 2023-08-11 07:19:33 --> Helper loaded: html_helper
INFO - 2023-08-11 07:19:33 --> Helper loaded: text_helper
INFO - 2023-08-11 07:19:33 --> Helper loaded: form_helper
INFO - 2023-08-11 07:19:33 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:19:33 --> Helper loaded: security_helper
INFO - 2023-08-11 07:19:33 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:19:33 --> Database Driver Class Initialized
INFO - 2023-08-11 07:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:19:33 --> Parser Class Initialized
INFO - 2023-08-11 07:19:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:19:33 --> Pagination Class Initialized
INFO - 2023-08-11 07:19:33 --> Form Validation Class Initialized
INFO - 2023-08-11 07:19:33 --> Controller Class Initialized
INFO - 2023-08-11 07:19:33 --> Model Class Initialized
DEBUG - 2023-08-11 07:19:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:19:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:19:33 --> Model Class Initialized
DEBUG - 2023-08-11 07:19:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:19:33 --> Model Class Initialized
INFO - 2023-08-11 07:19:33 --> Final output sent to browser
DEBUG - 2023-08-11 07:19:33 --> Total execution time: 0.0400
ERROR - 2023-08-11 07:19:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:19:39 --> Config Class Initialized
INFO - 2023-08-11 07:19:39 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:19:39 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:19:39 --> Utf8 Class Initialized
INFO - 2023-08-11 07:19:39 --> URI Class Initialized
INFO - 2023-08-11 07:19:39 --> Router Class Initialized
INFO - 2023-08-11 07:19:39 --> Output Class Initialized
INFO - 2023-08-11 07:19:39 --> Security Class Initialized
DEBUG - 2023-08-11 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:19:39 --> Input Class Initialized
INFO - 2023-08-11 07:19:39 --> Language Class Initialized
INFO - 2023-08-11 07:19:39 --> Loader Class Initialized
INFO - 2023-08-11 07:19:39 --> Helper loaded: url_helper
INFO - 2023-08-11 07:19:39 --> Helper loaded: file_helper
INFO - 2023-08-11 07:19:39 --> Helper loaded: html_helper
INFO - 2023-08-11 07:19:39 --> Helper loaded: text_helper
INFO - 2023-08-11 07:19:39 --> Helper loaded: form_helper
INFO - 2023-08-11 07:19:39 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:19:39 --> Helper loaded: security_helper
INFO - 2023-08-11 07:19:39 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:19:39 --> Database Driver Class Initialized
INFO - 2023-08-11 07:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:19:39 --> Parser Class Initialized
INFO - 2023-08-11 07:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:19:39 --> Pagination Class Initialized
INFO - 2023-08-11 07:19:39 --> Form Validation Class Initialized
INFO - 2023-08-11 07:19:39 --> Controller Class Initialized
INFO - 2023-08-11 07:19:39 --> Model Class Initialized
DEBUG - 2023-08-11 07:19:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:19:39 --> Model Class Initialized
DEBUG - 2023-08-11 07:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:19:39 --> Model Class Initialized
DEBUG - 2023-08-11 07:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-11 07:19:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 07:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 07:19:39 --> Model Class Initialized
INFO - 2023-08-11 07:19:39 --> Model Class Initialized
INFO - 2023-08-11 07:19:39 --> Model Class Initialized
INFO - 2023-08-11 07:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 07:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 07:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 07:19:39 --> Final output sent to browser
DEBUG - 2023-08-11 07:19:39 --> Total execution time: 0.0813
ERROR - 2023-08-11 07:48:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:48:05 --> Config Class Initialized
INFO - 2023-08-11 07:48:05 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:48:05 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:48:05 --> Utf8 Class Initialized
INFO - 2023-08-11 07:48:05 --> URI Class Initialized
DEBUG - 2023-08-11 07:48:05 --> No URI present. Default controller set.
INFO - 2023-08-11 07:48:05 --> Router Class Initialized
INFO - 2023-08-11 07:48:05 --> Output Class Initialized
INFO - 2023-08-11 07:48:05 --> Security Class Initialized
DEBUG - 2023-08-11 07:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:48:05 --> Input Class Initialized
INFO - 2023-08-11 07:48:05 --> Language Class Initialized
INFO - 2023-08-11 07:48:05 --> Loader Class Initialized
INFO - 2023-08-11 07:48:05 --> Helper loaded: url_helper
INFO - 2023-08-11 07:48:05 --> Helper loaded: file_helper
INFO - 2023-08-11 07:48:05 --> Helper loaded: html_helper
INFO - 2023-08-11 07:48:05 --> Helper loaded: text_helper
INFO - 2023-08-11 07:48:05 --> Helper loaded: form_helper
INFO - 2023-08-11 07:48:05 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:48:05 --> Helper loaded: security_helper
INFO - 2023-08-11 07:48:05 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:48:05 --> Database Driver Class Initialized
INFO - 2023-08-11 07:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:48:05 --> Parser Class Initialized
INFO - 2023-08-11 07:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:48:05 --> Pagination Class Initialized
INFO - 2023-08-11 07:48:05 --> Form Validation Class Initialized
INFO - 2023-08-11 07:48:05 --> Controller Class Initialized
INFO - 2023-08-11 07:48:05 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:05 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:05 --> Model Class Initialized
INFO - 2023-08-11 07:48:05 --> Model Class Initialized
INFO - 2023-08-11 07:48:05 --> Model Class Initialized
INFO - 2023-08-11 07:48:05 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:05 --> Model Class Initialized
INFO - 2023-08-11 07:48:05 --> Model Class Initialized
INFO - 2023-08-11 07:48:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 07:48:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 07:48:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 07:48:05 --> Model Class Initialized
INFO - 2023-08-11 07:48:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 07:48:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 07:48:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 07:48:05 --> Final output sent to browser
DEBUG - 2023-08-11 07:48:05 --> Total execution time: 0.1191
ERROR - 2023-08-11 07:48:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:48:26 --> Config Class Initialized
INFO - 2023-08-11 07:48:26 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:48:26 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:48:26 --> Utf8 Class Initialized
INFO - 2023-08-11 07:48:26 --> URI Class Initialized
INFO - 2023-08-11 07:48:26 --> Router Class Initialized
INFO - 2023-08-11 07:48:26 --> Output Class Initialized
INFO - 2023-08-11 07:48:26 --> Security Class Initialized
DEBUG - 2023-08-11 07:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:48:26 --> Input Class Initialized
INFO - 2023-08-11 07:48:26 --> Language Class Initialized
INFO - 2023-08-11 07:48:26 --> Loader Class Initialized
INFO - 2023-08-11 07:48:26 --> Helper loaded: url_helper
INFO - 2023-08-11 07:48:26 --> Helper loaded: file_helper
INFO - 2023-08-11 07:48:26 --> Helper loaded: html_helper
INFO - 2023-08-11 07:48:26 --> Helper loaded: text_helper
INFO - 2023-08-11 07:48:26 --> Helper loaded: form_helper
INFO - 2023-08-11 07:48:26 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:48:26 --> Helper loaded: security_helper
INFO - 2023-08-11 07:48:26 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:48:26 --> Database Driver Class Initialized
INFO - 2023-08-11 07:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:48:26 --> Parser Class Initialized
INFO - 2023-08-11 07:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:48:26 --> Pagination Class Initialized
INFO - 2023-08-11 07:48:26 --> Form Validation Class Initialized
INFO - 2023-08-11 07:48:26 --> Controller Class Initialized
INFO - 2023-08-11 07:48:26 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:26 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:26 --> Model Class Initialized
INFO - 2023-08-11 07:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-11 07:48:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 07:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 07:48:26 --> Model Class Initialized
INFO - 2023-08-11 07:48:26 --> Model Class Initialized
INFO - 2023-08-11 07:48:26 --> Model Class Initialized
INFO - 2023-08-11 07:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 07:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 07:48:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 07:48:26 --> Final output sent to browser
DEBUG - 2023-08-11 07:48:26 --> Total execution time: 0.0825
ERROR - 2023-08-11 07:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:48:27 --> Config Class Initialized
INFO - 2023-08-11 07:48:27 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:48:27 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:48:27 --> Utf8 Class Initialized
INFO - 2023-08-11 07:48:27 --> URI Class Initialized
INFO - 2023-08-11 07:48:27 --> Router Class Initialized
INFO - 2023-08-11 07:48:27 --> Output Class Initialized
INFO - 2023-08-11 07:48:27 --> Security Class Initialized
DEBUG - 2023-08-11 07:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:48:27 --> Input Class Initialized
INFO - 2023-08-11 07:48:27 --> Language Class Initialized
INFO - 2023-08-11 07:48:27 --> Loader Class Initialized
INFO - 2023-08-11 07:48:27 --> Helper loaded: url_helper
INFO - 2023-08-11 07:48:27 --> Helper loaded: file_helper
INFO - 2023-08-11 07:48:27 --> Helper loaded: html_helper
INFO - 2023-08-11 07:48:27 --> Helper loaded: text_helper
INFO - 2023-08-11 07:48:27 --> Helper loaded: form_helper
INFO - 2023-08-11 07:48:27 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:48:27 --> Helper loaded: security_helper
INFO - 2023-08-11 07:48:27 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:48:27 --> Database Driver Class Initialized
INFO - 2023-08-11 07:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:48:27 --> Parser Class Initialized
INFO - 2023-08-11 07:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:48:27 --> Pagination Class Initialized
INFO - 2023-08-11 07:48:27 --> Form Validation Class Initialized
INFO - 2023-08-11 07:48:27 --> Controller Class Initialized
INFO - 2023-08-11 07:48:27 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:27 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:27 --> Model Class Initialized
INFO - 2023-08-11 07:48:27 --> Final output sent to browser
DEBUG - 2023-08-11 07:48:27 --> Total execution time: 0.0413
ERROR - 2023-08-11 07:48:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 07:48:40 --> Config Class Initialized
INFO - 2023-08-11 07:48:40 --> Hooks Class Initialized
DEBUG - 2023-08-11 07:48:40 --> UTF-8 Support Enabled
INFO - 2023-08-11 07:48:40 --> Utf8 Class Initialized
INFO - 2023-08-11 07:48:40 --> URI Class Initialized
DEBUG - 2023-08-11 07:48:40 --> No URI present. Default controller set.
INFO - 2023-08-11 07:48:40 --> Router Class Initialized
INFO - 2023-08-11 07:48:40 --> Output Class Initialized
INFO - 2023-08-11 07:48:40 --> Security Class Initialized
DEBUG - 2023-08-11 07:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 07:48:40 --> Input Class Initialized
INFO - 2023-08-11 07:48:40 --> Language Class Initialized
INFO - 2023-08-11 07:48:40 --> Loader Class Initialized
INFO - 2023-08-11 07:48:40 --> Helper loaded: url_helper
INFO - 2023-08-11 07:48:40 --> Helper loaded: file_helper
INFO - 2023-08-11 07:48:40 --> Helper loaded: html_helper
INFO - 2023-08-11 07:48:40 --> Helper loaded: text_helper
INFO - 2023-08-11 07:48:40 --> Helper loaded: form_helper
INFO - 2023-08-11 07:48:40 --> Helper loaded: lang_helper
INFO - 2023-08-11 07:48:40 --> Helper loaded: security_helper
INFO - 2023-08-11 07:48:40 --> Helper loaded: cookie_helper
INFO - 2023-08-11 07:48:40 --> Database Driver Class Initialized
INFO - 2023-08-11 07:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 07:48:40 --> Parser Class Initialized
INFO - 2023-08-11 07:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 07:48:40 --> Pagination Class Initialized
INFO - 2023-08-11 07:48:40 --> Form Validation Class Initialized
INFO - 2023-08-11 07:48:40 --> Controller Class Initialized
INFO - 2023-08-11 07:48:40 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:40 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:40 --> Model Class Initialized
INFO - 2023-08-11 07:48:40 --> Model Class Initialized
INFO - 2023-08-11 07:48:40 --> Model Class Initialized
INFO - 2023-08-11 07:48:40 --> Model Class Initialized
DEBUG - 2023-08-11 07:48:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 07:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:40 --> Model Class Initialized
INFO - 2023-08-11 07:48:40 --> Model Class Initialized
INFO - 2023-08-11 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 07:48:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 07:48:40 --> Model Class Initialized
INFO - 2023-08-11 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 07:48:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 07:48:40 --> Final output sent to browser
DEBUG - 2023-08-11 07:48:40 --> Total execution time: 0.0922
ERROR - 2023-08-11 08:36:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:36:59 --> Config Class Initialized
INFO - 2023-08-11 08:36:59 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:36:59 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:36:59 --> Utf8 Class Initialized
INFO - 2023-08-11 08:36:59 --> URI Class Initialized
DEBUG - 2023-08-11 08:36:59 --> No URI present. Default controller set.
INFO - 2023-08-11 08:36:59 --> Router Class Initialized
INFO - 2023-08-11 08:36:59 --> Output Class Initialized
INFO - 2023-08-11 08:36:59 --> Security Class Initialized
DEBUG - 2023-08-11 08:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:36:59 --> Input Class Initialized
INFO - 2023-08-11 08:36:59 --> Language Class Initialized
INFO - 2023-08-11 08:36:59 --> Loader Class Initialized
INFO - 2023-08-11 08:36:59 --> Helper loaded: url_helper
INFO - 2023-08-11 08:36:59 --> Helper loaded: file_helper
INFO - 2023-08-11 08:36:59 --> Helper loaded: html_helper
INFO - 2023-08-11 08:36:59 --> Helper loaded: text_helper
INFO - 2023-08-11 08:36:59 --> Helper loaded: form_helper
INFO - 2023-08-11 08:36:59 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:36:59 --> Helper loaded: security_helper
INFO - 2023-08-11 08:36:59 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:36:59 --> Database Driver Class Initialized
INFO - 2023-08-11 08:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:36:59 --> Parser Class Initialized
INFO - 2023-08-11 08:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:36:59 --> Pagination Class Initialized
INFO - 2023-08-11 08:36:59 --> Form Validation Class Initialized
INFO - 2023-08-11 08:36:59 --> Controller Class Initialized
INFO - 2023-08-11 08:36:59 --> Model Class Initialized
DEBUG - 2023-08-11 08:36:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 08:37:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:37:00 --> Config Class Initialized
INFO - 2023-08-11 08:37:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:37:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:37:00 --> Utf8 Class Initialized
INFO - 2023-08-11 08:37:00 --> URI Class Initialized
INFO - 2023-08-11 08:37:00 --> Router Class Initialized
INFO - 2023-08-11 08:37:00 --> Output Class Initialized
INFO - 2023-08-11 08:37:00 --> Security Class Initialized
DEBUG - 2023-08-11 08:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:37:00 --> Input Class Initialized
INFO - 2023-08-11 08:37:00 --> Language Class Initialized
INFO - 2023-08-11 08:37:00 --> Loader Class Initialized
INFO - 2023-08-11 08:37:00 --> Helper loaded: url_helper
INFO - 2023-08-11 08:37:00 --> Helper loaded: file_helper
INFO - 2023-08-11 08:37:00 --> Helper loaded: html_helper
INFO - 2023-08-11 08:37:00 --> Helper loaded: text_helper
INFO - 2023-08-11 08:37:00 --> Helper loaded: form_helper
INFO - 2023-08-11 08:37:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:37:00 --> Helper loaded: security_helper
INFO - 2023-08-11 08:37:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:37:00 --> Database Driver Class Initialized
INFO - 2023-08-11 08:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:37:00 --> Parser Class Initialized
INFO - 2023-08-11 08:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:37:00 --> Pagination Class Initialized
INFO - 2023-08-11 08:37:00 --> Form Validation Class Initialized
INFO - 2023-08-11 08:37:00 --> Controller Class Initialized
INFO - 2023-08-11 08:37:00 --> Model Class Initialized
DEBUG - 2023-08-11 08:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 08:37:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 08:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 08:37:00 --> Model Class Initialized
INFO - 2023-08-11 08:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 08:37:00 --> Final output sent to browser
DEBUG - 2023-08-11 08:37:00 --> Total execution time: 0.0293
ERROR - 2023-08-11 08:37:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:37:47 --> Config Class Initialized
INFO - 2023-08-11 08:37:47 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:37:47 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:37:47 --> Utf8 Class Initialized
INFO - 2023-08-11 08:37:47 --> URI Class Initialized
INFO - 2023-08-11 08:37:47 --> Router Class Initialized
INFO - 2023-08-11 08:37:47 --> Output Class Initialized
INFO - 2023-08-11 08:37:47 --> Security Class Initialized
DEBUG - 2023-08-11 08:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:37:47 --> Input Class Initialized
INFO - 2023-08-11 08:37:47 --> Language Class Initialized
INFO - 2023-08-11 08:37:47 --> Loader Class Initialized
INFO - 2023-08-11 08:37:47 --> Helper loaded: url_helper
INFO - 2023-08-11 08:37:47 --> Helper loaded: file_helper
INFO - 2023-08-11 08:37:47 --> Helper loaded: html_helper
INFO - 2023-08-11 08:37:47 --> Helper loaded: text_helper
INFO - 2023-08-11 08:37:47 --> Helper loaded: form_helper
INFO - 2023-08-11 08:37:47 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:37:47 --> Helper loaded: security_helper
INFO - 2023-08-11 08:37:47 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:37:47 --> Database Driver Class Initialized
INFO - 2023-08-11 08:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:37:47 --> Parser Class Initialized
INFO - 2023-08-11 08:37:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:37:47 --> Pagination Class Initialized
INFO - 2023-08-11 08:37:47 --> Form Validation Class Initialized
INFO - 2023-08-11 08:37:47 --> Controller Class Initialized
INFO - 2023-08-11 08:37:47 --> Model Class Initialized
DEBUG - 2023-08-11 08:37:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:37:47 --> Model Class Initialized
INFO - 2023-08-11 08:37:47 --> Final output sent to browser
DEBUG - 2023-08-11 08:37:47 --> Total execution time: 0.0211
ERROR - 2023-08-11 08:37:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:37:48 --> Config Class Initialized
INFO - 2023-08-11 08:37:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:37:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:37:48 --> Utf8 Class Initialized
INFO - 2023-08-11 08:37:48 --> URI Class Initialized
DEBUG - 2023-08-11 08:37:48 --> No URI present. Default controller set.
INFO - 2023-08-11 08:37:48 --> Router Class Initialized
INFO - 2023-08-11 08:37:48 --> Output Class Initialized
INFO - 2023-08-11 08:37:48 --> Security Class Initialized
DEBUG - 2023-08-11 08:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:37:48 --> Input Class Initialized
INFO - 2023-08-11 08:37:48 --> Language Class Initialized
INFO - 2023-08-11 08:37:48 --> Loader Class Initialized
INFO - 2023-08-11 08:37:48 --> Helper loaded: url_helper
INFO - 2023-08-11 08:37:48 --> Helper loaded: file_helper
INFO - 2023-08-11 08:37:48 --> Helper loaded: html_helper
INFO - 2023-08-11 08:37:48 --> Helper loaded: text_helper
INFO - 2023-08-11 08:37:48 --> Helper loaded: form_helper
INFO - 2023-08-11 08:37:48 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:37:48 --> Helper loaded: security_helper
INFO - 2023-08-11 08:37:48 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:37:48 --> Database Driver Class Initialized
INFO - 2023-08-11 08:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:37:48 --> Parser Class Initialized
INFO - 2023-08-11 08:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:37:48 --> Pagination Class Initialized
INFO - 2023-08-11 08:37:48 --> Form Validation Class Initialized
INFO - 2023-08-11 08:37:48 --> Controller Class Initialized
INFO - 2023-08-11 08:37:48 --> Model Class Initialized
DEBUG - 2023-08-11 08:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:37:48 --> Model Class Initialized
DEBUG - 2023-08-11 08:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:37:48 --> Model Class Initialized
INFO - 2023-08-11 08:37:48 --> Model Class Initialized
INFO - 2023-08-11 08:37:48 --> Model Class Initialized
INFO - 2023-08-11 08:37:48 --> Model Class Initialized
DEBUG - 2023-08-11 08:37:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 08:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:37:48 --> Model Class Initialized
INFO - 2023-08-11 08:37:48 --> Model Class Initialized
INFO - 2023-08-11 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 08:37:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 08:37:48 --> Model Class Initialized
INFO - 2023-08-11 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 08:37:48 --> Final output sent to browser
DEBUG - 2023-08-11 08:37:48 --> Total execution time: 0.0752
ERROR - 2023-08-11 08:38:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:38:22 --> Config Class Initialized
INFO - 2023-08-11 08:38:22 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:38:22 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:38:22 --> Utf8 Class Initialized
INFO - 2023-08-11 08:38:22 --> URI Class Initialized
INFO - 2023-08-11 08:38:22 --> Router Class Initialized
INFO - 2023-08-11 08:38:22 --> Output Class Initialized
INFO - 2023-08-11 08:38:22 --> Security Class Initialized
DEBUG - 2023-08-11 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:38:22 --> Input Class Initialized
INFO - 2023-08-11 08:38:22 --> Language Class Initialized
INFO - 2023-08-11 08:38:22 --> Loader Class Initialized
INFO - 2023-08-11 08:38:22 --> Helper loaded: url_helper
INFO - 2023-08-11 08:38:22 --> Helper loaded: file_helper
INFO - 2023-08-11 08:38:22 --> Helper loaded: html_helper
INFO - 2023-08-11 08:38:22 --> Helper loaded: text_helper
INFO - 2023-08-11 08:38:22 --> Helper loaded: form_helper
INFO - 2023-08-11 08:38:22 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:38:22 --> Helper loaded: security_helper
INFO - 2023-08-11 08:38:22 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:38:22 --> Database Driver Class Initialized
INFO - 2023-08-11 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:38:22 --> Parser Class Initialized
INFO - 2023-08-11 08:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:38:22 --> Pagination Class Initialized
INFO - 2023-08-11 08:38:22 --> Form Validation Class Initialized
INFO - 2023-08-11 08:38:22 --> Controller Class Initialized
INFO - 2023-08-11 08:38:22 --> Model Class Initialized
INFO - 2023-08-11 08:38:22 --> Model Class Initialized
INFO - 2023-08-11 08:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-11 08:38:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 08:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 08:38:22 --> Model Class Initialized
INFO - 2023-08-11 08:38:22 --> Model Class Initialized
INFO - 2023-08-11 08:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 08:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 08:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 08:38:22 --> Final output sent to browser
DEBUG - 2023-08-11 08:38:22 --> Total execution time: 0.0595
ERROR - 2023-08-11 08:38:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:38:25 --> Config Class Initialized
INFO - 2023-08-11 08:38:25 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:38:25 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:38:25 --> Utf8 Class Initialized
INFO - 2023-08-11 08:38:25 --> URI Class Initialized
INFO - 2023-08-11 08:38:25 --> Router Class Initialized
INFO - 2023-08-11 08:38:25 --> Output Class Initialized
INFO - 2023-08-11 08:38:25 --> Security Class Initialized
DEBUG - 2023-08-11 08:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:38:25 --> Input Class Initialized
INFO - 2023-08-11 08:38:25 --> Language Class Initialized
INFO - 2023-08-11 08:38:25 --> Loader Class Initialized
INFO - 2023-08-11 08:38:25 --> Helper loaded: url_helper
INFO - 2023-08-11 08:38:25 --> Helper loaded: file_helper
INFO - 2023-08-11 08:38:25 --> Helper loaded: html_helper
INFO - 2023-08-11 08:38:25 --> Helper loaded: text_helper
INFO - 2023-08-11 08:38:25 --> Helper loaded: form_helper
INFO - 2023-08-11 08:38:25 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:38:25 --> Helper loaded: security_helper
INFO - 2023-08-11 08:38:25 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:38:25 --> Database Driver Class Initialized
INFO - 2023-08-11 08:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:38:25 --> Parser Class Initialized
INFO - 2023-08-11 08:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:38:25 --> Pagination Class Initialized
INFO - 2023-08-11 08:38:25 --> Form Validation Class Initialized
INFO - 2023-08-11 08:38:25 --> Controller Class Initialized
INFO - 2023-08-11 08:38:25 --> Model Class Initialized
INFO - 2023-08-11 08:38:25 --> Model Class Initialized
INFO - 2023-08-11 08:38:25 --> Final output sent to browser
DEBUG - 2023-08-11 08:38:25 --> Total execution time: 0.0233
ERROR - 2023-08-11 08:38:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:38:33 --> Config Class Initialized
INFO - 2023-08-11 08:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:38:33 --> Utf8 Class Initialized
INFO - 2023-08-11 08:38:33 --> URI Class Initialized
INFO - 2023-08-11 08:38:33 --> Router Class Initialized
INFO - 2023-08-11 08:38:33 --> Output Class Initialized
INFO - 2023-08-11 08:38:33 --> Security Class Initialized
DEBUG - 2023-08-11 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:38:33 --> Input Class Initialized
INFO - 2023-08-11 08:38:33 --> Language Class Initialized
INFO - 2023-08-11 08:38:33 --> Loader Class Initialized
INFO - 2023-08-11 08:38:33 --> Helper loaded: url_helper
INFO - 2023-08-11 08:38:33 --> Helper loaded: file_helper
INFO - 2023-08-11 08:38:33 --> Helper loaded: html_helper
INFO - 2023-08-11 08:38:33 --> Helper loaded: text_helper
INFO - 2023-08-11 08:38:33 --> Helper loaded: form_helper
INFO - 2023-08-11 08:38:33 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:38:33 --> Helper loaded: security_helper
INFO - 2023-08-11 08:38:33 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:38:33 --> Database Driver Class Initialized
INFO - 2023-08-11 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:38:33 --> Parser Class Initialized
INFO - 2023-08-11 08:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:38:33 --> Pagination Class Initialized
INFO - 2023-08-11 08:38:33 --> Form Validation Class Initialized
INFO - 2023-08-11 08:38:33 --> Controller Class Initialized
INFO - 2023-08-11 08:38:33 --> Model Class Initialized
INFO - 2023-08-11 08:38:33 --> Model Class Initialized
INFO - 2023-08-11 08:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-11 08:38:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 08:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 08:38:33 --> Model Class Initialized
INFO - 2023-08-11 08:38:33 --> Model Class Initialized
INFO - 2023-08-11 08:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 08:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 08:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 08:38:33 --> Final output sent to browser
DEBUG - 2023-08-11 08:38:33 --> Total execution time: 0.0608
ERROR - 2023-08-11 08:38:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:38:34 --> Config Class Initialized
INFO - 2023-08-11 08:38:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:38:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:38:34 --> Utf8 Class Initialized
INFO - 2023-08-11 08:38:34 --> URI Class Initialized
INFO - 2023-08-11 08:38:34 --> Router Class Initialized
INFO - 2023-08-11 08:38:34 --> Output Class Initialized
INFO - 2023-08-11 08:38:34 --> Security Class Initialized
DEBUG - 2023-08-11 08:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:38:34 --> Input Class Initialized
INFO - 2023-08-11 08:38:34 --> Language Class Initialized
INFO - 2023-08-11 08:38:34 --> Loader Class Initialized
INFO - 2023-08-11 08:38:34 --> Helper loaded: url_helper
INFO - 2023-08-11 08:38:34 --> Helper loaded: file_helper
INFO - 2023-08-11 08:38:34 --> Helper loaded: html_helper
INFO - 2023-08-11 08:38:34 --> Helper loaded: text_helper
INFO - 2023-08-11 08:38:34 --> Helper loaded: form_helper
INFO - 2023-08-11 08:38:34 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:38:34 --> Helper loaded: security_helper
INFO - 2023-08-11 08:38:34 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:38:34 --> Database Driver Class Initialized
INFO - 2023-08-11 08:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:38:34 --> Parser Class Initialized
INFO - 2023-08-11 08:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:38:34 --> Pagination Class Initialized
INFO - 2023-08-11 08:38:34 --> Form Validation Class Initialized
INFO - 2023-08-11 08:38:34 --> Controller Class Initialized
INFO - 2023-08-11 08:38:34 --> Model Class Initialized
INFO - 2023-08-11 08:38:34 --> Model Class Initialized
INFO - 2023-08-11 08:38:34 --> Final output sent to browser
DEBUG - 2023-08-11 08:38:34 --> Total execution time: 0.0216
ERROR - 2023-08-11 08:38:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:38:39 --> Config Class Initialized
INFO - 2023-08-11 08:38:39 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:38:39 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:38:39 --> Utf8 Class Initialized
INFO - 2023-08-11 08:38:39 --> URI Class Initialized
INFO - 2023-08-11 08:38:39 --> Router Class Initialized
INFO - 2023-08-11 08:38:39 --> Output Class Initialized
INFO - 2023-08-11 08:38:39 --> Security Class Initialized
DEBUG - 2023-08-11 08:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:38:39 --> Input Class Initialized
INFO - 2023-08-11 08:38:39 --> Language Class Initialized
INFO - 2023-08-11 08:38:39 --> Loader Class Initialized
INFO - 2023-08-11 08:38:39 --> Helper loaded: url_helper
INFO - 2023-08-11 08:38:39 --> Helper loaded: file_helper
INFO - 2023-08-11 08:38:39 --> Helper loaded: html_helper
INFO - 2023-08-11 08:38:39 --> Helper loaded: text_helper
INFO - 2023-08-11 08:38:39 --> Helper loaded: form_helper
INFO - 2023-08-11 08:38:39 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:38:39 --> Helper loaded: security_helper
INFO - 2023-08-11 08:38:39 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:38:39 --> Database Driver Class Initialized
INFO - 2023-08-11 08:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:38:39 --> Parser Class Initialized
INFO - 2023-08-11 08:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:38:39 --> Pagination Class Initialized
INFO - 2023-08-11 08:38:39 --> Form Validation Class Initialized
INFO - 2023-08-11 08:38:39 --> Controller Class Initialized
INFO - 2023-08-11 08:38:39 --> Model Class Initialized
INFO - 2023-08-11 08:38:39 --> Model Class Initialized
INFO - 2023-08-11 08:38:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-08-11 08:38:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 08:38:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 08:38:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 08:38:39 --> Model Class Initialized
INFO - 2023-08-11 08:38:39 --> Model Class Initialized
INFO - 2023-08-11 08:38:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 08:38:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 08:38:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 08:38:39 --> Final output sent to browser
DEBUG - 2023-08-11 08:38:39 --> Total execution time: 0.0670
ERROR - 2023-08-11 08:38:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 08:38:41 --> Config Class Initialized
INFO - 2023-08-11 08:38:41 --> Hooks Class Initialized
DEBUG - 2023-08-11 08:38:41 --> UTF-8 Support Enabled
INFO - 2023-08-11 08:38:41 --> Utf8 Class Initialized
INFO - 2023-08-11 08:38:41 --> URI Class Initialized
INFO - 2023-08-11 08:38:41 --> Router Class Initialized
INFO - 2023-08-11 08:38:41 --> Output Class Initialized
INFO - 2023-08-11 08:38:41 --> Security Class Initialized
DEBUG - 2023-08-11 08:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 08:38:41 --> Input Class Initialized
INFO - 2023-08-11 08:38:41 --> Language Class Initialized
INFO - 2023-08-11 08:38:41 --> Loader Class Initialized
INFO - 2023-08-11 08:38:41 --> Helper loaded: url_helper
INFO - 2023-08-11 08:38:41 --> Helper loaded: file_helper
INFO - 2023-08-11 08:38:41 --> Helper loaded: html_helper
INFO - 2023-08-11 08:38:41 --> Helper loaded: text_helper
INFO - 2023-08-11 08:38:41 --> Helper loaded: form_helper
INFO - 2023-08-11 08:38:41 --> Helper loaded: lang_helper
INFO - 2023-08-11 08:38:41 --> Helper loaded: security_helper
INFO - 2023-08-11 08:38:41 --> Helper loaded: cookie_helper
INFO - 2023-08-11 08:38:41 --> Database Driver Class Initialized
INFO - 2023-08-11 08:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 08:38:41 --> Parser Class Initialized
INFO - 2023-08-11 08:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 08:38:41 --> Pagination Class Initialized
INFO - 2023-08-11 08:38:41 --> Form Validation Class Initialized
INFO - 2023-08-11 08:38:41 --> Controller Class Initialized
INFO - 2023-08-11 08:38:41 --> Model Class Initialized
INFO - 2023-08-11 08:38:41 --> Model Class Initialized
INFO - 2023-08-11 08:38:41 --> Final output sent to browser
DEBUG - 2023-08-11 08:38:41 --> Total execution time: 0.0384
ERROR - 2023-08-11 09:31:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 09:31:58 --> Config Class Initialized
INFO - 2023-08-11 09:31:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 09:31:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 09:31:58 --> Utf8 Class Initialized
INFO - 2023-08-11 09:31:58 --> URI Class Initialized
DEBUG - 2023-08-11 09:31:58 --> No URI present. Default controller set.
INFO - 2023-08-11 09:31:58 --> Router Class Initialized
INFO - 2023-08-11 09:31:58 --> Output Class Initialized
INFO - 2023-08-11 09:31:58 --> Security Class Initialized
DEBUG - 2023-08-11 09:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 09:31:58 --> Input Class Initialized
INFO - 2023-08-11 09:31:58 --> Language Class Initialized
INFO - 2023-08-11 09:31:58 --> Loader Class Initialized
INFO - 2023-08-11 09:31:58 --> Helper loaded: url_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: file_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: html_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: text_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: form_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: lang_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: security_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: cookie_helper
INFO - 2023-08-11 09:31:58 --> Database Driver Class Initialized
INFO - 2023-08-11 09:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 09:31:58 --> Parser Class Initialized
INFO - 2023-08-11 09:31:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 09:31:58 --> Pagination Class Initialized
INFO - 2023-08-11 09:31:58 --> Form Validation Class Initialized
INFO - 2023-08-11 09:31:58 --> Controller Class Initialized
INFO - 2023-08-11 09:31:58 --> Model Class Initialized
DEBUG - 2023-08-11 09:31:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 09:31:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 09:31:58 --> Config Class Initialized
INFO - 2023-08-11 09:31:58 --> Hooks Class Initialized
DEBUG - 2023-08-11 09:31:58 --> UTF-8 Support Enabled
INFO - 2023-08-11 09:31:58 --> Utf8 Class Initialized
INFO - 2023-08-11 09:31:58 --> URI Class Initialized
INFO - 2023-08-11 09:31:58 --> Router Class Initialized
INFO - 2023-08-11 09:31:58 --> Output Class Initialized
INFO - 2023-08-11 09:31:58 --> Security Class Initialized
DEBUG - 2023-08-11 09:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 09:31:58 --> Input Class Initialized
INFO - 2023-08-11 09:31:58 --> Language Class Initialized
INFO - 2023-08-11 09:31:58 --> Loader Class Initialized
INFO - 2023-08-11 09:31:58 --> Helper loaded: url_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: file_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: html_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: text_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: form_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: lang_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: security_helper
INFO - 2023-08-11 09:31:58 --> Helper loaded: cookie_helper
INFO - 2023-08-11 09:31:58 --> Database Driver Class Initialized
INFO - 2023-08-11 09:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 09:31:58 --> Parser Class Initialized
INFO - 2023-08-11 09:31:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 09:31:58 --> Pagination Class Initialized
INFO - 2023-08-11 09:31:58 --> Form Validation Class Initialized
INFO - 2023-08-11 09:31:58 --> Controller Class Initialized
INFO - 2023-08-11 09:31:58 --> Model Class Initialized
DEBUG - 2023-08-11 09:31:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 09:31:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 09:31:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 09:31:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 09:31:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 09:31:58 --> Model Class Initialized
INFO - 2023-08-11 09:31:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 09:31:58 --> Final output sent to browser
DEBUG - 2023-08-11 09:31:58 --> Total execution time: 0.0327
ERROR - 2023-08-11 09:32:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 09:32:11 --> Config Class Initialized
INFO - 2023-08-11 09:32:11 --> Hooks Class Initialized
DEBUG - 2023-08-11 09:32:11 --> UTF-8 Support Enabled
INFO - 2023-08-11 09:32:11 --> Utf8 Class Initialized
INFO - 2023-08-11 09:32:11 --> URI Class Initialized
INFO - 2023-08-11 09:32:11 --> Router Class Initialized
INFO - 2023-08-11 09:32:11 --> Output Class Initialized
INFO - 2023-08-11 09:32:11 --> Security Class Initialized
DEBUG - 2023-08-11 09:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 09:32:11 --> Input Class Initialized
INFO - 2023-08-11 09:32:11 --> Language Class Initialized
INFO - 2023-08-11 09:32:11 --> Loader Class Initialized
INFO - 2023-08-11 09:32:11 --> Helper loaded: url_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: file_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: html_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: text_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: form_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: lang_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: security_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: cookie_helper
INFO - 2023-08-11 09:32:11 --> Database Driver Class Initialized
INFO - 2023-08-11 09:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 09:32:11 --> Parser Class Initialized
INFO - 2023-08-11 09:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 09:32:11 --> Pagination Class Initialized
INFO - 2023-08-11 09:32:11 --> Form Validation Class Initialized
INFO - 2023-08-11 09:32:11 --> Controller Class Initialized
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
DEBUG - 2023-08-11 09:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
INFO - 2023-08-11 09:32:11 --> Final output sent to browser
DEBUG - 2023-08-11 09:32:11 --> Total execution time: 0.0220
ERROR - 2023-08-11 09:32:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 09:32:11 --> Config Class Initialized
INFO - 2023-08-11 09:32:11 --> Hooks Class Initialized
DEBUG - 2023-08-11 09:32:11 --> UTF-8 Support Enabled
INFO - 2023-08-11 09:32:11 --> Utf8 Class Initialized
INFO - 2023-08-11 09:32:11 --> URI Class Initialized
DEBUG - 2023-08-11 09:32:11 --> No URI present. Default controller set.
INFO - 2023-08-11 09:32:11 --> Router Class Initialized
INFO - 2023-08-11 09:32:11 --> Output Class Initialized
INFO - 2023-08-11 09:32:11 --> Security Class Initialized
DEBUG - 2023-08-11 09:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 09:32:11 --> Input Class Initialized
INFO - 2023-08-11 09:32:11 --> Language Class Initialized
INFO - 2023-08-11 09:32:11 --> Loader Class Initialized
INFO - 2023-08-11 09:32:11 --> Helper loaded: url_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: file_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: html_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: text_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: form_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: lang_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: security_helper
INFO - 2023-08-11 09:32:11 --> Helper loaded: cookie_helper
INFO - 2023-08-11 09:32:11 --> Database Driver Class Initialized
INFO - 2023-08-11 09:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 09:32:11 --> Parser Class Initialized
INFO - 2023-08-11 09:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 09:32:11 --> Pagination Class Initialized
INFO - 2023-08-11 09:32:11 --> Form Validation Class Initialized
INFO - 2023-08-11 09:32:11 --> Controller Class Initialized
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
DEBUG - 2023-08-11 09:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
DEBUG - 2023-08-11 09:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
DEBUG - 2023-08-11 09:32:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 09:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
INFO - 2023-08-11 09:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 09:32:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 09:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 09:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 09:32:11 --> Model Class Initialized
INFO - 2023-08-11 09:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 09:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 09:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 09:32:11 --> Final output sent to browser
DEBUG - 2023-08-11 09:32:11 --> Total execution time: 0.0872
ERROR - 2023-08-11 10:10:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 10:10:34 --> Config Class Initialized
INFO - 2023-08-11 10:10:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 10:10:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 10:10:34 --> Utf8 Class Initialized
INFO - 2023-08-11 10:10:34 --> URI Class Initialized
DEBUG - 2023-08-11 10:10:34 --> No URI present. Default controller set.
INFO - 2023-08-11 10:10:34 --> Router Class Initialized
INFO - 2023-08-11 10:10:34 --> Output Class Initialized
INFO - 2023-08-11 10:10:34 --> Security Class Initialized
DEBUG - 2023-08-11 10:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 10:10:34 --> Input Class Initialized
INFO - 2023-08-11 10:10:34 --> Language Class Initialized
INFO - 2023-08-11 10:10:34 --> Loader Class Initialized
INFO - 2023-08-11 10:10:34 --> Helper loaded: url_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: file_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: html_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: text_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: form_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: lang_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: security_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: cookie_helper
INFO - 2023-08-11 10:10:34 --> Database Driver Class Initialized
INFO - 2023-08-11 10:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 10:10:34 --> Parser Class Initialized
INFO - 2023-08-11 10:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 10:10:34 --> Pagination Class Initialized
INFO - 2023-08-11 10:10:34 --> Form Validation Class Initialized
INFO - 2023-08-11 10:10:34 --> Controller Class Initialized
INFO - 2023-08-11 10:10:34 --> Model Class Initialized
DEBUG - 2023-08-11 10:10:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 10:10:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 10:10:34 --> Config Class Initialized
INFO - 2023-08-11 10:10:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 10:10:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 10:10:34 --> Utf8 Class Initialized
INFO - 2023-08-11 10:10:34 --> URI Class Initialized
INFO - 2023-08-11 10:10:34 --> Router Class Initialized
INFO - 2023-08-11 10:10:34 --> Output Class Initialized
INFO - 2023-08-11 10:10:34 --> Security Class Initialized
DEBUG - 2023-08-11 10:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 10:10:34 --> Input Class Initialized
INFO - 2023-08-11 10:10:34 --> Language Class Initialized
INFO - 2023-08-11 10:10:34 --> Loader Class Initialized
INFO - 2023-08-11 10:10:34 --> Helper loaded: url_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: file_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: html_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: text_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: form_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: lang_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: security_helper
INFO - 2023-08-11 10:10:34 --> Helper loaded: cookie_helper
INFO - 2023-08-11 10:10:34 --> Database Driver Class Initialized
INFO - 2023-08-11 10:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 10:10:34 --> Parser Class Initialized
INFO - 2023-08-11 10:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 10:10:34 --> Pagination Class Initialized
INFO - 2023-08-11 10:10:34 --> Form Validation Class Initialized
INFO - 2023-08-11 10:10:34 --> Controller Class Initialized
INFO - 2023-08-11 10:10:34 --> Model Class Initialized
DEBUG - 2023-08-11 10:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 10:10:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 10:10:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 10:10:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 10:10:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 10:10:34 --> Model Class Initialized
INFO - 2023-08-11 10:10:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 10:10:34 --> Final output sent to browser
DEBUG - 2023-08-11 10:10:34 --> Total execution time: 0.0333
ERROR - 2023-08-11 10:10:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 10:10:44 --> Config Class Initialized
INFO - 2023-08-11 10:10:44 --> Hooks Class Initialized
DEBUG - 2023-08-11 10:10:44 --> UTF-8 Support Enabled
INFO - 2023-08-11 10:10:44 --> Utf8 Class Initialized
INFO - 2023-08-11 10:10:44 --> URI Class Initialized
DEBUG - 2023-08-11 10:10:44 --> No URI present. Default controller set.
INFO - 2023-08-11 10:10:44 --> Router Class Initialized
INFO - 2023-08-11 10:10:44 --> Output Class Initialized
INFO - 2023-08-11 10:10:44 --> Security Class Initialized
DEBUG - 2023-08-11 10:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 10:10:44 --> Input Class Initialized
INFO - 2023-08-11 10:10:44 --> Language Class Initialized
INFO - 2023-08-11 10:10:44 --> Loader Class Initialized
INFO - 2023-08-11 10:10:44 --> Helper loaded: url_helper
INFO - 2023-08-11 10:10:44 --> Helper loaded: file_helper
INFO - 2023-08-11 10:10:44 --> Helper loaded: html_helper
INFO - 2023-08-11 10:10:44 --> Helper loaded: text_helper
INFO - 2023-08-11 10:10:44 --> Helper loaded: form_helper
INFO - 2023-08-11 10:10:44 --> Helper loaded: lang_helper
INFO - 2023-08-11 10:10:44 --> Helper loaded: security_helper
INFO - 2023-08-11 10:10:44 --> Helper loaded: cookie_helper
INFO - 2023-08-11 10:10:44 --> Database Driver Class Initialized
INFO - 2023-08-11 10:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 10:10:44 --> Parser Class Initialized
INFO - 2023-08-11 10:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 10:10:44 --> Pagination Class Initialized
INFO - 2023-08-11 10:10:44 --> Form Validation Class Initialized
INFO - 2023-08-11 10:10:44 --> Controller Class Initialized
INFO - 2023-08-11 10:10:44 --> Model Class Initialized
DEBUG - 2023-08-11 10:10:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 10:10:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 10:10:45 --> Config Class Initialized
INFO - 2023-08-11 10:10:45 --> Hooks Class Initialized
DEBUG - 2023-08-11 10:10:45 --> UTF-8 Support Enabled
INFO - 2023-08-11 10:10:45 --> Utf8 Class Initialized
INFO - 2023-08-11 10:10:45 --> URI Class Initialized
INFO - 2023-08-11 10:10:45 --> Router Class Initialized
INFO - 2023-08-11 10:10:45 --> Output Class Initialized
INFO - 2023-08-11 10:10:45 --> Security Class Initialized
DEBUG - 2023-08-11 10:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 10:10:45 --> Input Class Initialized
INFO - 2023-08-11 10:10:45 --> Language Class Initialized
INFO - 2023-08-11 10:10:45 --> Loader Class Initialized
INFO - 2023-08-11 10:10:45 --> Helper loaded: url_helper
INFO - 2023-08-11 10:10:45 --> Helper loaded: file_helper
INFO - 2023-08-11 10:10:45 --> Helper loaded: html_helper
INFO - 2023-08-11 10:10:45 --> Helper loaded: text_helper
INFO - 2023-08-11 10:10:45 --> Helper loaded: form_helper
INFO - 2023-08-11 10:10:45 --> Helper loaded: lang_helper
INFO - 2023-08-11 10:10:45 --> Helper loaded: security_helper
INFO - 2023-08-11 10:10:45 --> Helper loaded: cookie_helper
INFO - 2023-08-11 10:10:45 --> Database Driver Class Initialized
INFO - 2023-08-11 10:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 10:10:45 --> Parser Class Initialized
INFO - 2023-08-11 10:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 10:10:45 --> Pagination Class Initialized
INFO - 2023-08-11 10:10:45 --> Form Validation Class Initialized
INFO - 2023-08-11 10:10:45 --> Controller Class Initialized
INFO - 2023-08-11 10:10:45 --> Model Class Initialized
DEBUG - 2023-08-11 10:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 10:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 10:10:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 10:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 10:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 10:10:45 --> Model Class Initialized
INFO - 2023-08-11 10:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 10:10:45 --> Final output sent to browser
DEBUG - 2023-08-11 10:10:45 --> Total execution time: 0.0348
ERROR - 2023-08-11 14:20:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:20:09 --> Config Class Initialized
INFO - 2023-08-11 14:20:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:20:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:20:09 --> Utf8 Class Initialized
INFO - 2023-08-11 14:20:09 --> URI Class Initialized
DEBUG - 2023-08-11 14:20:09 --> No URI present. Default controller set.
INFO - 2023-08-11 14:20:09 --> Router Class Initialized
INFO - 2023-08-11 14:20:09 --> Output Class Initialized
INFO - 2023-08-11 14:20:09 --> Security Class Initialized
DEBUG - 2023-08-11 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:20:09 --> Input Class Initialized
INFO - 2023-08-11 14:20:09 --> Language Class Initialized
INFO - 2023-08-11 14:20:09 --> Loader Class Initialized
INFO - 2023-08-11 14:20:09 --> Helper loaded: url_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: file_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: html_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: text_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: form_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: security_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:20:09 --> Database Driver Class Initialized
INFO - 2023-08-11 14:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:20:09 --> Parser Class Initialized
INFO - 2023-08-11 14:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:20:09 --> Pagination Class Initialized
INFO - 2023-08-11 14:20:09 --> Form Validation Class Initialized
INFO - 2023-08-11 14:20:09 --> Controller Class Initialized
INFO - 2023-08-11 14:20:09 --> Model Class Initialized
DEBUG - 2023-08-11 14:20:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 14:20:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:20:09 --> Config Class Initialized
INFO - 2023-08-11 14:20:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:20:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:20:09 --> Utf8 Class Initialized
INFO - 2023-08-11 14:20:09 --> URI Class Initialized
INFO - 2023-08-11 14:20:09 --> Router Class Initialized
INFO - 2023-08-11 14:20:09 --> Output Class Initialized
INFO - 2023-08-11 14:20:09 --> Security Class Initialized
DEBUG - 2023-08-11 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:20:09 --> Input Class Initialized
INFO - 2023-08-11 14:20:09 --> Language Class Initialized
INFO - 2023-08-11 14:20:09 --> Loader Class Initialized
INFO - 2023-08-11 14:20:09 --> Helper loaded: url_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: file_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: html_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: text_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: form_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: security_helper
INFO - 2023-08-11 14:20:09 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:20:09 --> Database Driver Class Initialized
INFO - 2023-08-11 14:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:20:09 --> Parser Class Initialized
INFO - 2023-08-11 14:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:20:09 --> Pagination Class Initialized
INFO - 2023-08-11 14:20:09 --> Form Validation Class Initialized
INFO - 2023-08-11 14:20:09 --> Controller Class Initialized
INFO - 2023-08-11 14:20:09 --> Model Class Initialized
DEBUG - 2023-08-11 14:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 14:20:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 14:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 14:20:09 --> Model Class Initialized
INFO - 2023-08-11 14:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 14:20:09 --> Final output sent to browser
DEBUG - 2023-08-11 14:20:09 --> Total execution time: 0.0399
ERROR - 2023-08-11 14:25:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:25:00 --> Config Class Initialized
INFO - 2023-08-11 14:25:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:25:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:25:00 --> Utf8 Class Initialized
INFO - 2023-08-11 14:25:00 --> URI Class Initialized
DEBUG - 2023-08-11 14:25:00 --> No URI present. Default controller set.
INFO - 2023-08-11 14:25:00 --> Router Class Initialized
INFO - 2023-08-11 14:25:00 --> Output Class Initialized
INFO - 2023-08-11 14:25:00 --> Security Class Initialized
DEBUG - 2023-08-11 14:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:25:00 --> Input Class Initialized
INFO - 2023-08-11 14:25:00 --> Language Class Initialized
INFO - 2023-08-11 14:25:00 --> Loader Class Initialized
INFO - 2023-08-11 14:25:00 --> Helper loaded: url_helper
INFO - 2023-08-11 14:25:00 --> Helper loaded: file_helper
INFO - 2023-08-11 14:25:00 --> Helper loaded: html_helper
INFO - 2023-08-11 14:25:00 --> Helper loaded: text_helper
INFO - 2023-08-11 14:25:00 --> Helper loaded: form_helper
INFO - 2023-08-11 14:25:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:25:00 --> Helper loaded: security_helper
INFO - 2023-08-11 14:25:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:25:00 --> Database Driver Class Initialized
INFO - 2023-08-11 14:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:25:00 --> Parser Class Initialized
INFO - 2023-08-11 14:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:25:00 --> Pagination Class Initialized
INFO - 2023-08-11 14:25:00 --> Form Validation Class Initialized
INFO - 2023-08-11 14:25:00 --> Controller Class Initialized
INFO - 2023-08-11 14:25:00 --> Model Class Initialized
DEBUG - 2023-08-11 14:25:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 14:25:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:25:01 --> Config Class Initialized
INFO - 2023-08-11 14:25:01 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:25:01 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:25:01 --> Utf8 Class Initialized
INFO - 2023-08-11 14:25:01 --> URI Class Initialized
INFO - 2023-08-11 14:25:01 --> Router Class Initialized
INFO - 2023-08-11 14:25:01 --> Output Class Initialized
INFO - 2023-08-11 14:25:01 --> Security Class Initialized
DEBUG - 2023-08-11 14:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:25:01 --> Input Class Initialized
INFO - 2023-08-11 14:25:01 --> Language Class Initialized
INFO - 2023-08-11 14:25:01 --> Loader Class Initialized
INFO - 2023-08-11 14:25:01 --> Helper loaded: url_helper
INFO - 2023-08-11 14:25:01 --> Helper loaded: file_helper
INFO - 2023-08-11 14:25:01 --> Helper loaded: html_helper
INFO - 2023-08-11 14:25:01 --> Helper loaded: text_helper
INFO - 2023-08-11 14:25:01 --> Helper loaded: form_helper
INFO - 2023-08-11 14:25:01 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:25:01 --> Helper loaded: security_helper
INFO - 2023-08-11 14:25:01 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:25:01 --> Database Driver Class Initialized
INFO - 2023-08-11 14:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:25:01 --> Parser Class Initialized
INFO - 2023-08-11 14:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:25:01 --> Pagination Class Initialized
INFO - 2023-08-11 14:25:01 --> Form Validation Class Initialized
INFO - 2023-08-11 14:25:01 --> Controller Class Initialized
INFO - 2023-08-11 14:25:01 --> Model Class Initialized
DEBUG - 2023-08-11 14:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:25:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 14:25:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:25:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 14:25:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 14:25:01 --> Model Class Initialized
INFO - 2023-08-11 14:25:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 14:25:01 --> Final output sent to browser
DEBUG - 2023-08-11 14:25:01 --> Total execution time: 0.0313
ERROR - 2023-08-11 14:25:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:25:12 --> Config Class Initialized
INFO - 2023-08-11 14:25:12 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:25:12 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:25:12 --> Utf8 Class Initialized
INFO - 2023-08-11 14:25:12 --> URI Class Initialized
INFO - 2023-08-11 14:25:12 --> Router Class Initialized
INFO - 2023-08-11 14:25:12 --> Output Class Initialized
INFO - 2023-08-11 14:25:12 --> Security Class Initialized
DEBUG - 2023-08-11 14:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:25:12 --> Input Class Initialized
INFO - 2023-08-11 14:25:12 --> Language Class Initialized
INFO - 2023-08-11 14:25:12 --> Loader Class Initialized
INFO - 2023-08-11 14:25:12 --> Helper loaded: url_helper
INFO - 2023-08-11 14:25:12 --> Helper loaded: file_helper
INFO - 2023-08-11 14:25:12 --> Helper loaded: html_helper
INFO - 2023-08-11 14:25:12 --> Helper loaded: text_helper
INFO - 2023-08-11 14:25:12 --> Helper loaded: form_helper
INFO - 2023-08-11 14:25:12 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:25:12 --> Helper loaded: security_helper
INFO - 2023-08-11 14:25:12 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:25:12 --> Database Driver Class Initialized
INFO - 2023-08-11 14:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:25:12 --> Parser Class Initialized
INFO - 2023-08-11 14:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:25:12 --> Pagination Class Initialized
INFO - 2023-08-11 14:25:12 --> Form Validation Class Initialized
INFO - 2023-08-11 14:25:12 --> Controller Class Initialized
INFO - 2023-08-11 14:25:12 --> Model Class Initialized
DEBUG - 2023-08-11 14:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:25:12 --> Model Class Initialized
INFO - 2023-08-11 14:25:12 --> Final output sent to browser
DEBUG - 2023-08-11 14:25:12 --> Total execution time: 0.0204
ERROR - 2023-08-11 14:25:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:25:13 --> Config Class Initialized
INFO - 2023-08-11 14:25:13 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:25:13 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:25:13 --> Utf8 Class Initialized
INFO - 2023-08-11 14:25:13 --> URI Class Initialized
DEBUG - 2023-08-11 14:25:13 --> No URI present. Default controller set.
INFO - 2023-08-11 14:25:13 --> Router Class Initialized
INFO - 2023-08-11 14:25:13 --> Output Class Initialized
INFO - 2023-08-11 14:25:13 --> Security Class Initialized
DEBUG - 2023-08-11 14:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:25:13 --> Input Class Initialized
INFO - 2023-08-11 14:25:13 --> Language Class Initialized
INFO - 2023-08-11 14:25:13 --> Loader Class Initialized
INFO - 2023-08-11 14:25:13 --> Helper loaded: url_helper
INFO - 2023-08-11 14:25:13 --> Helper loaded: file_helper
INFO - 2023-08-11 14:25:13 --> Helper loaded: html_helper
INFO - 2023-08-11 14:25:13 --> Helper loaded: text_helper
INFO - 2023-08-11 14:25:13 --> Helper loaded: form_helper
INFO - 2023-08-11 14:25:13 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:25:13 --> Helper loaded: security_helper
INFO - 2023-08-11 14:25:13 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:25:13 --> Database Driver Class Initialized
INFO - 2023-08-11 14:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:25:13 --> Parser Class Initialized
INFO - 2023-08-11 14:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:25:13 --> Pagination Class Initialized
INFO - 2023-08-11 14:25:13 --> Form Validation Class Initialized
INFO - 2023-08-11 14:25:13 --> Controller Class Initialized
INFO - 2023-08-11 14:25:13 --> Model Class Initialized
DEBUG - 2023-08-11 14:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:25:13 --> Model Class Initialized
DEBUG - 2023-08-11 14:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:25:13 --> Model Class Initialized
INFO - 2023-08-11 14:25:13 --> Model Class Initialized
INFO - 2023-08-11 14:25:13 --> Model Class Initialized
INFO - 2023-08-11 14:25:13 --> Model Class Initialized
DEBUG - 2023-08-11 14:25:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 14:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:25:13 --> Model Class Initialized
INFO - 2023-08-11 14:25:13 --> Model Class Initialized
INFO - 2023-08-11 14:25:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 14:25:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:25:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 14:25:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 14:25:13 --> Model Class Initialized
INFO - 2023-08-11 14:25:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 14:25:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 14:25:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 14:25:13 --> Final output sent to browser
DEBUG - 2023-08-11 14:25:13 --> Total execution time: 0.0904
ERROR - 2023-08-11 14:25:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:25:23 --> Config Class Initialized
INFO - 2023-08-11 14:25:23 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:25:23 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:25:23 --> Utf8 Class Initialized
INFO - 2023-08-11 14:25:23 --> URI Class Initialized
INFO - 2023-08-11 14:25:23 --> Router Class Initialized
INFO - 2023-08-11 14:25:23 --> Output Class Initialized
INFO - 2023-08-11 14:25:23 --> Security Class Initialized
DEBUG - 2023-08-11 14:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:25:23 --> Input Class Initialized
INFO - 2023-08-11 14:25:23 --> Language Class Initialized
INFO - 2023-08-11 14:25:23 --> Loader Class Initialized
INFO - 2023-08-11 14:25:23 --> Helper loaded: url_helper
INFO - 2023-08-11 14:25:23 --> Helper loaded: file_helper
INFO - 2023-08-11 14:25:23 --> Helper loaded: html_helper
INFO - 2023-08-11 14:25:23 --> Helper loaded: text_helper
INFO - 2023-08-11 14:25:23 --> Helper loaded: form_helper
INFO - 2023-08-11 14:25:23 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:25:23 --> Helper loaded: security_helper
INFO - 2023-08-11 14:25:23 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:25:23 --> Database Driver Class Initialized
INFO - 2023-08-11 14:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:25:23 --> Parser Class Initialized
INFO - 2023-08-11 14:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:25:23 --> Pagination Class Initialized
INFO - 2023-08-11 14:25:23 --> Form Validation Class Initialized
INFO - 2023-08-11 14:25:23 --> Controller Class Initialized
INFO - 2023-08-11 14:25:23 --> Model Class Initialized
INFO - 2023-08-11 14:25:23 --> Model Class Initialized
INFO - 2023-08-11 14:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-11 14:25:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 14:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 14:25:24 --> Model Class Initialized
INFO - 2023-08-11 14:25:24 --> Model Class Initialized
INFO - 2023-08-11 14:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 14:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 14:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 14:25:24 --> Final output sent to browser
DEBUG - 2023-08-11 14:25:24 --> Total execution time: 0.0631
ERROR - 2023-08-11 14:25:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:25:24 --> Config Class Initialized
INFO - 2023-08-11 14:25:24 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:25:24 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:25:24 --> Utf8 Class Initialized
INFO - 2023-08-11 14:25:24 --> URI Class Initialized
INFO - 2023-08-11 14:25:24 --> Router Class Initialized
INFO - 2023-08-11 14:25:24 --> Output Class Initialized
INFO - 2023-08-11 14:25:24 --> Security Class Initialized
DEBUG - 2023-08-11 14:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:25:24 --> Input Class Initialized
INFO - 2023-08-11 14:25:24 --> Language Class Initialized
INFO - 2023-08-11 14:25:24 --> Loader Class Initialized
INFO - 2023-08-11 14:25:24 --> Helper loaded: url_helper
INFO - 2023-08-11 14:25:24 --> Helper loaded: file_helper
INFO - 2023-08-11 14:25:24 --> Helper loaded: html_helper
INFO - 2023-08-11 14:25:24 --> Helper loaded: text_helper
INFO - 2023-08-11 14:25:24 --> Helper loaded: form_helper
INFO - 2023-08-11 14:25:24 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:25:24 --> Helper loaded: security_helper
INFO - 2023-08-11 14:25:24 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:25:24 --> Database Driver Class Initialized
INFO - 2023-08-11 14:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:25:24 --> Parser Class Initialized
INFO - 2023-08-11 14:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:25:24 --> Pagination Class Initialized
INFO - 2023-08-11 14:25:24 --> Form Validation Class Initialized
INFO - 2023-08-11 14:25:24 --> Controller Class Initialized
INFO - 2023-08-11 14:25:24 --> Model Class Initialized
INFO - 2023-08-11 14:25:24 --> Model Class Initialized
INFO - 2023-08-11 14:25:24 --> Final output sent to browser
DEBUG - 2023-08-11 14:25:24 --> Total execution time: 0.0219
ERROR - 2023-08-11 14:25:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:25:57 --> Config Class Initialized
INFO - 2023-08-11 14:25:57 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:25:57 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:25:57 --> Utf8 Class Initialized
INFO - 2023-08-11 14:25:57 --> URI Class Initialized
INFO - 2023-08-11 14:25:57 --> Router Class Initialized
INFO - 2023-08-11 14:25:57 --> Output Class Initialized
INFO - 2023-08-11 14:25:57 --> Security Class Initialized
DEBUG - 2023-08-11 14:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:25:57 --> Input Class Initialized
INFO - 2023-08-11 14:25:57 --> Language Class Initialized
INFO - 2023-08-11 14:25:57 --> Loader Class Initialized
INFO - 2023-08-11 14:25:57 --> Helper loaded: url_helper
INFO - 2023-08-11 14:25:57 --> Helper loaded: file_helper
INFO - 2023-08-11 14:25:57 --> Helper loaded: html_helper
INFO - 2023-08-11 14:25:57 --> Helper loaded: text_helper
INFO - 2023-08-11 14:25:57 --> Helper loaded: form_helper
INFO - 2023-08-11 14:25:57 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:25:57 --> Helper loaded: security_helper
INFO - 2023-08-11 14:25:57 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:25:57 --> Database Driver Class Initialized
INFO - 2023-08-11 14:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:25:57 --> Parser Class Initialized
INFO - 2023-08-11 14:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:25:57 --> Pagination Class Initialized
INFO - 2023-08-11 14:25:57 --> Form Validation Class Initialized
INFO - 2023-08-11 14:25:57 --> Controller Class Initialized
INFO - 2023-08-11 14:25:57 --> Model Class Initialized
INFO - 2023-08-11 14:25:57 --> Model Class Initialized
INFO - 2023-08-11 14:25:57 --> Final output sent to browser
DEBUG - 2023-08-11 14:25:57 --> Total execution time: 0.0248
ERROR - 2023-08-11 14:25:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:25:59 --> Config Class Initialized
INFO - 2023-08-11 14:25:59 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:25:59 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:25:59 --> Utf8 Class Initialized
INFO - 2023-08-11 14:25:59 --> URI Class Initialized
INFO - 2023-08-11 14:25:59 --> Router Class Initialized
INFO - 2023-08-11 14:25:59 --> Output Class Initialized
INFO - 2023-08-11 14:25:59 --> Security Class Initialized
DEBUG - 2023-08-11 14:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:25:59 --> Input Class Initialized
INFO - 2023-08-11 14:25:59 --> Language Class Initialized
INFO - 2023-08-11 14:25:59 --> Loader Class Initialized
INFO - 2023-08-11 14:25:59 --> Helper loaded: url_helper
INFO - 2023-08-11 14:25:59 --> Helper loaded: file_helper
INFO - 2023-08-11 14:25:59 --> Helper loaded: html_helper
INFO - 2023-08-11 14:25:59 --> Helper loaded: text_helper
INFO - 2023-08-11 14:25:59 --> Helper loaded: form_helper
INFO - 2023-08-11 14:25:59 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:25:59 --> Helper loaded: security_helper
INFO - 2023-08-11 14:25:59 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:25:59 --> Database Driver Class Initialized
INFO - 2023-08-11 14:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:25:59 --> Parser Class Initialized
INFO - 2023-08-11 14:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:25:59 --> Pagination Class Initialized
INFO - 2023-08-11 14:25:59 --> Form Validation Class Initialized
INFO - 2023-08-11 14:25:59 --> Controller Class Initialized
INFO - 2023-08-11 14:25:59 --> Model Class Initialized
INFO - 2023-08-11 14:25:59 --> Model Class Initialized
INFO - 2023-08-11 14:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-11 14:25:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 14:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 14:25:59 --> Model Class Initialized
INFO - 2023-08-11 14:25:59 --> Model Class Initialized
INFO - 2023-08-11 14:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 14:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 14:25:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 14:25:59 --> Final output sent to browser
DEBUG - 2023-08-11 14:25:59 --> Total execution time: 0.0620
ERROR - 2023-08-11 14:26:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:26:00 --> Config Class Initialized
INFO - 2023-08-11 14:26:00 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:26:00 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:26:00 --> Utf8 Class Initialized
INFO - 2023-08-11 14:26:00 --> URI Class Initialized
INFO - 2023-08-11 14:26:00 --> Router Class Initialized
INFO - 2023-08-11 14:26:00 --> Output Class Initialized
INFO - 2023-08-11 14:26:00 --> Security Class Initialized
DEBUG - 2023-08-11 14:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:26:00 --> Input Class Initialized
INFO - 2023-08-11 14:26:00 --> Language Class Initialized
INFO - 2023-08-11 14:26:00 --> Loader Class Initialized
INFO - 2023-08-11 14:26:00 --> Helper loaded: url_helper
INFO - 2023-08-11 14:26:00 --> Helper loaded: file_helper
INFO - 2023-08-11 14:26:00 --> Helper loaded: html_helper
INFO - 2023-08-11 14:26:00 --> Helper loaded: text_helper
INFO - 2023-08-11 14:26:00 --> Helper loaded: form_helper
INFO - 2023-08-11 14:26:00 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:26:00 --> Helper loaded: security_helper
INFO - 2023-08-11 14:26:00 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:26:00 --> Database Driver Class Initialized
INFO - 2023-08-11 14:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:26:00 --> Parser Class Initialized
INFO - 2023-08-11 14:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:26:00 --> Pagination Class Initialized
INFO - 2023-08-11 14:26:00 --> Form Validation Class Initialized
INFO - 2023-08-11 14:26:00 --> Controller Class Initialized
INFO - 2023-08-11 14:26:00 --> Model Class Initialized
INFO - 2023-08-11 14:26:00 --> Model Class Initialized
INFO - 2023-08-11 14:26:00 --> Final output sent to browser
DEBUG - 2023-08-11 14:26:00 --> Total execution time: 0.0225
ERROR - 2023-08-11 14:26:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:26:07 --> Config Class Initialized
INFO - 2023-08-11 14:26:07 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:26:07 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:26:07 --> Utf8 Class Initialized
INFO - 2023-08-11 14:26:07 --> URI Class Initialized
DEBUG - 2023-08-11 14:26:07 --> No URI present. Default controller set.
INFO - 2023-08-11 14:26:07 --> Router Class Initialized
INFO - 2023-08-11 14:26:07 --> Output Class Initialized
INFO - 2023-08-11 14:26:07 --> Security Class Initialized
DEBUG - 2023-08-11 14:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:26:07 --> Input Class Initialized
INFO - 2023-08-11 14:26:07 --> Language Class Initialized
INFO - 2023-08-11 14:26:07 --> Loader Class Initialized
INFO - 2023-08-11 14:26:07 --> Helper loaded: url_helper
INFO - 2023-08-11 14:26:07 --> Helper loaded: file_helper
INFO - 2023-08-11 14:26:07 --> Helper loaded: html_helper
INFO - 2023-08-11 14:26:07 --> Helper loaded: text_helper
INFO - 2023-08-11 14:26:07 --> Helper loaded: form_helper
INFO - 2023-08-11 14:26:07 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:26:07 --> Helper loaded: security_helper
INFO - 2023-08-11 14:26:07 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:26:07 --> Database Driver Class Initialized
INFO - 2023-08-11 14:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:26:07 --> Parser Class Initialized
INFO - 2023-08-11 14:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:26:07 --> Pagination Class Initialized
INFO - 2023-08-11 14:26:07 --> Form Validation Class Initialized
INFO - 2023-08-11 14:26:07 --> Controller Class Initialized
INFO - 2023-08-11 14:26:07 --> Model Class Initialized
DEBUG - 2023-08-11 14:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:26:07 --> Model Class Initialized
DEBUG - 2023-08-11 14:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:26:07 --> Model Class Initialized
INFO - 2023-08-11 14:26:07 --> Model Class Initialized
INFO - 2023-08-11 14:26:07 --> Model Class Initialized
INFO - 2023-08-11 14:26:07 --> Model Class Initialized
DEBUG - 2023-08-11 14:26:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 14:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:26:07 --> Model Class Initialized
INFO - 2023-08-11 14:26:07 --> Model Class Initialized
INFO - 2023-08-11 14:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 14:26:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 14:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 14:26:07 --> Model Class Initialized
INFO - 2023-08-11 14:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 14:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 14:26:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 14:26:07 --> Final output sent to browser
DEBUG - 2023-08-11 14:26:07 --> Total execution time: 0.0799
ERROR - 2023-08-11 14:38:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:38:33 --> Config Class Initialized
INFO - 2023-08-11 14:38:33 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:38:33 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:38:33 --> Utf8 Class Initialized
INFO - 2023-08-11 14:38:33 --> URI Class Initialized
DEBUG - 2023-08-11 14:38:33 --> No URI present. Default controller set.
INFO - 2023-08-11 14:38:33 --> Router Class Initialized
INFO - 2023-08-11 14:38:33 --> Output Class Initialized
INFO - 2023-08-11 14:38:33 --> Security Class Initialized
DEBUG - 2023-08-11 14:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:38:33 --> Input Class Initialized
INFO - 2023-08-11 14:38:33 --> Language Class Initialized
INFO - 2023-08-11 14:38:33 --> Loader Class Initialized
INFO - 2023-08-11 14:38:33 --> Helper loaded: url_helper
INFO - 2023-08-11 14:38:33 --> Helper loaded: file_helper
INFO - 2023-08-11 14:38:33 --> Helper loaded: html_helper
INFO - 2023-08-11 14:38:33 --> Helper loaded: text_helper
INFO - 2023-08-11 14:38:33 --> Helper loaded: form_helper
INFO - 2023-08-11 14:38:33 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:38:33 --> Helper loaded: security_helper
INFO - 2023-08-11 14:38:33 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:38:33 --> Database Driver Class Initialized
INFO - 2023-08-11 14:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:38:33 --> Parser Class Initialized
INFO - 2023-08-11 14:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:38:33 --> Pagination Class Initialized
INFO - 2023-08-11 14:38:33 --> Form Validation Class Initialized
INFO - 2023-08-11 14:38:33 --> Controller Class Initialized
INFO - 2023-08-11 14:38:33 --> Model Class Initialized
DEBUG - 2023-08-11 14:38:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-11 14:38:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:38:34 --> Config Class Initialized
INFO - 2023-08-11 14:38:34 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:38:34 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:38:34 --> Utf8 Class Initialized
INFO - 2023-08-11 14:38:34 --> URI Class Initialized
INFO - 2023-08-11 14:38:34 --> Router Class Initialized
INFO - 2023-08-11 14:38:34 --> Output Class Initialized
INFO - 2023-08-11 14:38:34 --> Security Class Initialized
DEBUG - 2023-08-11 14:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:38:34 --> Input Class Initialized
INFO - 2023-08-11 14:38:34 --> Language Class Initialized
INFO - 2023-08-11 14:38:34 --> Loader Class Initialized
INFO - 2023-08-11 14:38:34 --> Helper loaded: url_helper
INFO - 2023-08-11 14:38:34 --> Helper loaded: file_helper
INFO - 2023-08-11 14:38:34 --> Helper loaded: html_helper
INFO - 2023-08-11 14:38:34 --> Helper loaded: text_helper
INFO - 2023-08-11 14:38:34 --> Helper loaded: form_helper
INFO - 2023-08-11 14:38:34 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:38:34 --> Helper loaded: security_helper
INFO - 2023-08-11 14:38:34 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:38:34 --> Database Driver Class Initialized
INFO - 2023-08-11 14:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:38:34 --> Parser Class Initialized
INFO - 2023-08-11 14:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:38:34 --> Pagination Class Initialized
INFO - 2023-08-11 14:38:34 --> Form Validation Class Initialized
INFO - 2023-08-11 14:38:34 --> Controller Class Initialized
INFO - 2023-08-11 14:38:34 --> Model Class Initialized
DEBUG - 2023-08-11 14:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 14:38:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 14:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 14:38:34 --> Model Class Initialized
INFO - 2023-08-11 14:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 14:38:34 --> Final output sent to browser
DEBUG - 2023-08-11 14:38:34 --> Total execution time: 0.0330
ERROR - 2023-08-11 14:38:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:38:48 --> Config Class Initialized
INFO - 2023-08-11 14:38:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:38:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:38:48 --> Utf8 Class Initialized
INFO - 2023-08-11 14:38:48 --> URI Class Initialized
INFO - 2023-08-11 14:38:48 --> Router Class Initialized
INFO - 2023-08-11 14:38:48 --> Output Class Initialized
INFO - 2023-08-11 14:38:48 --> Security Class Initialized
DEBUG - 2023-08-11 14:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:38:48 --> Input Class Initialized
INFO - 2023-08-11 14:38:48 --> Language Class Initialized
INFO - 2023-08-11 14:38:48 --> Loader Class Initialized
INFO - 2023-08-11 14:38:48 --> Helper loaded: url_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: file_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: html_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: text_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: form_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: security_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:38:48 --> Database Driver Class Initialized
INFO - 2023-08-11 14:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:38:48 --> Parser Class Initialized
INFO - 2023-08-11 14:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:38:48 --> Pagination Class Initialized
INFO - 2023-08-11 14:38:48 --> Form Validation Class Initialized
INFO - 2023-08-11 14:38:48 --> Controller Class Initialized
INFO - 2023-08-11 14:38:48 --> Model Class Initialized
DEBUG - 2023-08-11 14:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:38:48 --> Model Class Initialized
INFO - 2023-08-11 14:38:48 --> Final output sent to browser
DEBUG - 2023-08-11 14:38:48 --> Total execution time: 0.0211
ERROR - 2023-08-11 14:38:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:38:48 --> Config Class Initialized
INFO - 2023-08-11 14:38:48 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:38:48 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:38:48 --> Utf8 Class Initialized
INFO - 2023-08-11 14:38:48 --> URI Class Initialized
INFO - 2023-08-11 14:38:48 --> Router Class Initialized
INFO - 2023-08-11 14:38:48 --> Output Class Initialized
INFO - 2023-08-11 14:38:48 --> Security Class Initialized
DEBUG - 2023-08-11 14:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:38:48 --> Input Class Initialized
INFO - 2023-08-11 14:38:48 --> Language Class Initialized
INFO - 2023-08-11 14:38:48 --> Loader Class Initialized
INFO - 2023-08-11 14:38:48 --> Helper loaded: url_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: file_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: html_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: text_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: form_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: security_helper
INFO - 2023-08-11 14:38:48 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:38:48 --> Database Driver Class Initialized
INFO - 2023-08-11 14:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:38:48 --> Parser Class Initialized
INFO - 2023-08-11 14:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:38:48 --> Pagination Class Initialized
INFO - 2023-08-11 14:38:48 --> Form Validation Class Initialized
INFO - 2023-08-11 14:38:48 --> Controller Class Initialized
INFO - 2023-08-11 14:38:48 --> Model Class Initialized
DEBUG - 2023-08-11 14:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:38:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-11 14:38:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:38:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 14:38:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 14:38:48 --> Model Class Initialized
INFO - 2023-08-11 14:38:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 14:38:48 --> Final output sent to browser
DEBUG - 2023-08-11 14:38:48 --> Total execution time: 0.0281
ERROR - 2023-08-11 14:39:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:39:09 --> Config Class Initialized
INFO - 2023-08-11 14:39:09 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:39:09 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:39:09 --> Utf8 Class Initialized
INFO - 2023-08-11 14:39:09 --> URI Class Initialized
INFO - 2023-08-11 14:39:09 --> Router Class Initialized
INFO - 2023-08-11 14:39:09 --> Output Class Initialized
INFO - 2023-08-11 14:39:09 --> Security Class Initialized
DEBUG - 2023-08-11 14:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:39:09 --> Input Class Initialized
INFO - 2023-08-11 14:39:09 --> Language Class Initialized
INFO - 2023-08-11 14:39:09 --> Loader Class Initialized
INFO - 2023-08-11 14:39:09 --> Helper loaded: url_helper
INFO - 2023-08-11 14:39:09 --> Helper loaded: file_helper
INFO - 2023-08-11 14:39:09 --> Helper loaded: html_helper
INFO - 2023-08-11 14:39:09 --> Helper loaded: text_helper
INFO - 2023-08-11 14:39:09 --> Helper loaded: form_helper
INFO - 2023-08-11 14:39:09 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:39:09 --> Helper loaded: security_helper
INFO - 2023-08-11 14:39:09 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:39:09 --> Database Driver Class Initialized
INFO - 2023-08-11 14:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:39:09 --> Parser Class Initialized
INFO - 2023-08-11 14:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:39:09 --> Pagination Class Initialized
INFO - 2023-08-11 14:39:09 --> Form Validation Class Initialized
INFO - 2023-08-11 14:39:09 --> Controller Class Initialized
INFO - 2023-08-11 14:39:09 --> Model Class Initialized
DEBUG - 2023-08-11 14:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:39:09 --> Model Class Initialized
INFO - 2023-08-11 14:39:09 --> Final output sent to browser
DEBUG - 2023-08-11 14:39:09 --> Total execution time: 0.0191
ERROR - 2023-08-11 14:39:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 14:39:10 --> Config Class Initialized
INFO - 2023-08-11 14:39:10 --> Hooks Class Initialized
DEBUG - 2023-08-11 14:39:10 --> UTF-8 Support Enabled
INFO - 2023-08-11 14:39:10 --> Utf8 Class Initialized
INFO - 2023-08-11 14:39:10 --> URI Class Initialized
DEBUG - 2023-08-11 14:39:10 --> No URI present. Default controller set.
INFO - 2023-08-11 14:39:10 --> Router Class Initialized
INFO - 2023-08-11 14:39:10 --> Output Class Initialized
INFO - 2023-08-11 14:39:10 --> Security Class Initialized
DEBUG - 2023-08-11 14:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 14:39:10 --> Input Class Initialized
INFO - 2023-08-11 14:39:10 --> Language Class Initialized
INFO - 2023-08-11 14:39:10 --> Loader Class Initialized
INFO - 2023-08-11 14:39:10 --> Helper loaded: url_helper
INFO - 2023-08-11 14:39:10 --> Helper loaded: file_helper
INFO - 2023-08-11 14:39:10 --> Helper loaded: html_helper
INFO - 2023-08-11 14:39:10 --> Helper loaded: text_helper
INFO - 2023-08-11 14:39:10 --> Helper loaded: form_helper
INFO - 2023-08-11 14:39:10 --> Helper loaded: lang_helper
INFO - 2023-08-11 14:39:10 --> Helper loaded: security_helper
INFO - 2023-08-11 14:39:10 --> Helper loaded: cookie_helper
INFO - 2023-08-11 14:39:10 --> Database Driver Class Initialized
INFO - 2023-08-11 14:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 14:39:10 --> Parser Class Initialized
INFO - 2023-08-11 14:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 14:39:10 --> Pagination Class Initialized
INFO - 2023-08-11 14:39:10 --> Form Validation Class Initialized
INFO - 2023-08-11 14:39:10 --> Controller Class Initialized
INFO - 2023-08-11 14:39:10 --> Model Class Initialized
DEBUG - 2023-08-11 14:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:39:10 --> Model Class Initialized
DEBUG - 2023-08-11 14:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:39:10 --> Model Class Initialized
INFO - 2023-08-11 14:39:10 --> Model Class Initialized
INFO - 2023-08-11 14:39:10 --> Model Class Initialized
INFO - 2023-08-11 14:39:10 --> Model Class Initialized
DEBUG - 2023-08-11 14:39:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-11 14:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:39:10 --> Model Class Initialized
INFO - 2023-08-11 14:39:10 --> Model Class Initialized
INFO - 2023-08-11 14:39:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-11 14:39:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-11 14:39:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-11 14:39:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-11 14:39:10 --> Model Class Initialized
INFO - 2023-08-11 14:39:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-11 14:39:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-11 14:39:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-11 14:39:10 --> Final output sent to browser
DEBUG - 2023-08-11 14:39:10 --> Total execution time: 0.0786
ERROR - 2023-08-11 17:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-11 17:47:44 --> Config Class Initialized
INFO - 2023-08-11 17:47:44 --> Hooks Class Initialized
DEBUG - 2023-08-11 17:47:44 --> UTF-8 Support Enabled
INFO - 2023-08-11 17:47:44 --> Utf8 Class Initialized
INFO - 2023-08-11 17:47:44 --> URI Class Initialized
DEBUG - 2023-08-11 17:47:44 --> No URI present. Default controller set.
INFO - 2023-08-11 17:47:44 --> Router Class Initialized
INFO - 2023-08-11 17:47:44 --> Output Class Initialized
INFO - 2023-08-11 17:47:44 --> Security Class Initialized
DEBUG - 2023-08-11 17:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-11 17:47:44 --> Input Class Initialized
INFO - 2023-08-11 17:47:44 --> Language Class Initialized
INFO - 2023-08-11 17:47:44 --> Loader Class Initialized
INFO - 2023-08-11 17:47:44 --> Helper loaded: url_helper
INFO - 2023-08-11 17:47:44 --> Helper loaded: file_helper
INFO - 2023-08-11 17:47:44 --> Helper loaded: html_helper
INFO - 2023-08-11 17:47:44 --> Helper loaded: text_helper
INFO - 2023-08-11 17:47:44 --> Helper loaded: form_helper
INFO - 2023-08-11 17:47:44 --> Helper loaded: lang_helper
INFO - 2023-08-11 17:47:44 --> Helper loaded: security_helper
INFO - 2023-08-11 17:47:44 --> Helper loaded: cookie_helper
INFO - 2023-08-11 17:47:44 --> Database Driver Class Initialized
INFO - 2023-08-11 17:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-11 17:47:44 --> Parser Class Initialized
INFO - 2023-08-11 17:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-11 17:47:44 --> Pagination Class Initialized
INFO - 2023-08-11 17:47:44 --> Form Validation Class Initialized
INFO - 2023-08-11 17:47:44 --> Controller Class Initialized
INFO - 2023-08-11 17:47:44 --> Model Class Initialized
DEBUG - 2023-08-11 17:47:44 --> Session class already loaded. Second attempt ignored.
