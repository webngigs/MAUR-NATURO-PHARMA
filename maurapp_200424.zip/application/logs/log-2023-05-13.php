<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-13 07:42:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 07:42:58 --> Config Class Initialized
INFO - 2023-05-13 07:42:58 --> Hooks Class Initialized
DEBUG - 2023-05-13 07:42:58 --> UTF-8 Support Enabled
INFO - 2023-05-13 07:42:58 --> Utf8 Class Initialized
INFO - 2023-05-13 07:42:58 --> URI Class Initialized
DEBUG - 2023-05-13 07:42:58 --> No URI present. Default controller set.
INFO - 2023-05-13 07:42:58 --> Router Class Initialized
INFO - 2023-05-13 07:42:58 --> Output Class Initialized
INFO - 2023-05-13 07:42:58 --> Security Class Initialized
DEBUG - 2023-05-13 07:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 07:42:58 --> Input Class Initialized
INFO - 2023-05-13 07:42:58 --> Language Class Initialized
INFO - 2023-05-13 07:42:58 --> Loader Class Initialized
INFO - 2023-05-13 07:42:58 --> Helper loaded: url_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: file_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: html_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: text_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: form_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: lang_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: security_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: cookie_helper
INFO - 2023-05-13 07:42:58 --> Database Driver Class Initialized
INFO - 2023-05-13 07:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 07:42:58 --> Parser Class Initialized
INFO - 2023-05-13 07:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 07:42:58 --> Pagination Class Initialized
INFO - 2023-05-13 07:42:58 --> Form Validation Class Initialized
INFO - 2023-05-13 07:42:58 --> Controller Class Initialized
INFO - 2023-05-13 07:42:58 --> Model Class Initialized
DEBUG - 2023-05-13 07:42:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-13 07:42:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 07:42:58 --> Config Class Initialized
INFO - 2023-05-13 07:42:58 --> Hooks Class Initialized
DEBUG - 2023-05-13 07:42:58 --> UTF-8 Support Enabled
INFO - 2023-05-13 07:42:58 --> Utf8 Class Initialized
INFO - 2023-05-13 07:42:58 --> URI Class Initialized
INFO - 2023-05-13 07:42:58 --> Router Class Initialized
INFO - 2023-05-13 07:42:58 --> Output Class Initialized
INFO - 2023-05-13 07:42:58 --> Security Class Initialized
DEBUG - 2023-05-13 07:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 07:42:58 --> Input Class Initialized
INFO - 2023-05-13 07:42:58 --> Language Class Initialized
INFO - 2023-05-13 07:42:58 --> Loader Class Initialized
INFO - 2023-05-13 07:42:58 --> Helper loaded: url_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: file_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: html_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: text_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: form_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: lang_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: security_helper
INFO - 2023-05-13 07:42:58 --> Helper loaded: cookie_helper
INFO - 2023-05-13 07:42:58 --> Database Driver Class Initialized
INFO - 2023-05-13 07:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 07:42:58 --> Parser Class Initialized
INFO - 2023-05-13 07:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 07:42:58 --> Pagination Class Initialized
INFO - 2023-05-13 07:42:58 --> Form Validation Class Initialized
INFO - 2023-05-13 07:42:58 --> Controller Class Initialized
INFO - 2023-05-13 07:42:58 --> Model Class Initialized
DEBUG - 2023-05-13 07:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-13 07:42:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 07:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 07:42:58 --> Model Class Initialized
INFO - 2023-05-13 07:42:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 07:42:58 --> Final output sent to browser
DEBUG - 2023-05-13 07:42:58 --> Total execution time: 0.0320
ERROR - 2023-05-13 07:43:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 07:43:12 --> Config Class Initialized
INFO - 2023-05-13 07:43:12 --> Hooks Class Initialized
DEBUG - 2023-05-13 07:43:12 --> UTF-8 Support Enabled
INFO - 2023-05-13 07:43:12 --> Utf8 Class Initialized
INFO - 2023-05-13 07:43:12 --> URI Class Initialized
INFO - 2023-05-13 07:43:12 --> Router Class Initialized
INFO - 2023-05-13 07:43:12 --> Output Class Initialized
INFO - 2023-05-13 07:43:12 --> Security Class Initialized
DEBUG - 2023-05-13 07:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 07:43:12 --> Input Class Initialized
INFO - 2023-05-13 07:43:12 --> Language Class Initialized
INFO - 2023-05-13 07:43:12 --> Loader Class Initialized
INFO - 2023-05-13 07:43:12 --> Helper loaded: url_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: file_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: html_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: text_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: form_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: lang_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: security_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: cookie_helper
INFO - 2023-05-13 07:43:12 --> Database Driver Class Initialized
INFO - 2023-05-13 07:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 07:43:12 --> Parser Class Initialized
INFO - 2023-05-13 07:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 07:43:12 --> Pagination Class Initialized
INFO - 2023-05-13 07:43:12 --> Form Validation Class Initialized
INFO - 2023-05-13 07:43:12 --> Controller Class Initialized
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
DEBUG - 2023-05-13 07:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
INFO - 2023-05-13 07:43:12 --> Final output sent to browser
DEBUG - 2023-05-13 07:43:12 --> Total execution time: 0.0205
ERROR - 2023-05-13 07:43:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 07:43:12 --> Config Class Initialized
INFO - 2023-05-13 07:43:12 --> Hooks Class Initialized
DEBUG - 2023-05-13 07:43:12 --> UTF-8 Support Enabled
INFO - 2023-05-13 07:43:12 --> Utf8 Class Initialized
INFO - 2023-05-13 07:43:12 --> URI Class Initialized
DEBUG - 2023-05-13 07:43:12 --> No URI present. Default controller set.
INFO - 2023-05-13 07:43:12 --> Router Class Initialized
INFO - 2023-05-13 07:43:12 --> Output Class Initialized
INFO - 2023-05-13 07:43:12 --> Security Class Initialized
DEBUG - 2023-05-13 07:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 07:43:12 --> Input Class Initialized
INFO - 2023-05-13 07:43:12 --> Language Class Initialized
INFO - 2023-05-13 07:43:12 --> Loader Class Initialized
INFO - 2023-05-13 07:43:12 --> Helper loaded: url_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: file_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: html_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: text_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: form_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: lang_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: security_helper
INFO - 2023-05-13 07:43:12 --> Helper loaded: cookie_helper
INFO - 2023-05-13 07:43:12 --> Database Driver Class Initialized
INFO - 2023-05-13 07:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 07:43:12 --> Parser Class Initialized
INFO - 2023-05-13 07:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 07:43:12 --> Pagination Class Initialized
INFO - 2023-05-13 07:43:12 --> Form Validation Class Initialized
INFO - 2023-05-13 07:43:12 --> Controller Class Initialized
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
DEBUG - 2023-05-13 07:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
DEBUG - 2023-05-13 07:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
DEBUG - 2023-05-13 07:43:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-13 07:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
INFO - 2023-05-13 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-13 07:43:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 07:43:12 --> Model Class Initialized
INFO - 2023-05-13 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-13 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-13 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 07:43:12 --> Final output sent to browser
DEBUG - 2023-05-13 07:43:12 --> Total execution time: 0.0821
ERROR - 2023-05-13 07:43:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 07:43:30 --> Config Class Initialized
INFO - 2023-05-13 07:43:30 --> Hooks Class Initialized
DEBUG - 2023-05-13 07:43:30 --> UTF-8 Support Enabled
INFO - 2023-05-13 07:43:30 --> Utf8 Class Initialized
INFO - 2023-05-13 07:43:30 --> URI Class Initialized
INFO - 2023-05-13 07:43:30 --> Router Class Initialized
INFO - 2023-05-13 07:43:30 --> Output Class Initialized
INFO - 2023-05-13 07:43:30 --> Security Class Initialized
DEBUG - 2023-05-13 07:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 07:43:30 --> Input Class Initialized
INFO - 2023-05-13 07:43:30 --> Language Class Initialized
INFO - 2023-05-13 07:43:30 --> Loader Class Initialized
INFO - 2023-05-13 07:43:30 --> Helper loaded: url_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: file_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: html_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: text_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: form_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: lang_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: security_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: cookie_helper
INFO - 2023-05-13 07:43:30 --> Database Driver Class Initialized
INFO - 2023-05-13 07:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 07:43:30 --> Parser Class Initialized
INFO - 2023-05-13 07:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 07:43:30 --> Pagination Class Initialized
INFO - 2023-05-13 07:43:30 --> Form Validation Class Initialized
INFO - 2023-05-13 07:43:30 --> Controller Class Initialized
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
DEBUG - 2023-05-13 07:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-13 07:43:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 07:43:30 --> Final output sent to browser
DEBUG - 2023-05-13 07:43:30 --> Total execution time: 0.0308
ERROR - 2023-05-13 07:43:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 07:43:30 --> Config Class Initialized
INFO - 2023-05-13 07:43:30 --> Hooks Class Initialized
DEBUG - 2023-05-13 07:43:30 --> UTF-8 Support Enabled
INFO - 2023-05-13 07:43:30 --> Utf8 Class Initialized
INFO - 2023-05-13 07:43:30 --> URI Class Initialized
INFO - 2023-05-13 07:43:30 --> Router Class Initialized
INFO - 2023-05-13 07:43:30 --> Output Class Initialized
INFO - 2023-05-13 07:43:30 --> Security Class Initialized
DEBUG - 2023-05-13 07:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 07:43:30 --> Input Class Initialized
INFO - 2023-05-13 07:43:30 --> Language Class Initialized
INFO - 2023-05-13 07:43:30 --> Loader Class Initialized
INFO - 2023-05-13 07:43:30 --> Helper loaded: url_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: file_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: html_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: text_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: form_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: lang_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: security_helper
INFO - 2023-05-13 07:43:30 --> Helper loaded: cookie_helper
INFO - 2023-05-13 07:43:30 --> Database Driver Class Initialized
INFO - 2023-05-13 07:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 07:43:30 --> Parser Class Initialized
INFO - 2023-05-13 07:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 07:43:30 --> Pagination Class Initialized
INFO - 2023-05-13 07:43:30 --> Form Validation Class Initialized
INFO - 2023-05-13 07:43:30 --> Controller Class Initialized
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
DEBUG - 2023-05-13 07:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
DEBUG - 2023-05-13 07:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
DEBUG - 2023-05-13 07:43:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-13 07:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-13 07:43:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 07:43:30 --> Model Class Initialized
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-13 07:43:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 07:43:30 --> Final output sent to browser
DEBUG - 2023-05-13 07:43:30 --> Total execution time: 0.0748
ERROR - 2023-05-13 10:17:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 10:17:10 --> Config Class Initialized
INFO - 2023-05-13 10:17:10 --> Hooks Class Initialized
DEBUG - 2023-05-13 10:17:10 --> UTF-8 Support Enabled
INFO - 2023-05-13 10:17:10 --> Utf8 Class Initialized
INFO - 2023-05-13 10:17:10 --> URI Class Initialized
DEBUG - 2023-05-13 10:17:10 --> No URI present. Default controller set.
INFO - 2023-05-13 10:17:10 --> Router Class Initialized
INFO - 2023-05-13 10:17:10 --> Output Class Initialized
INFO - 2023-05-13 10:17:10 --> Security Class Initialized
DEBUG - 2023-05-13 10:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 10:17:10 --> Input Class Initialized
INFO - 2023-05-13 10:17:10 --> Language Class Initialized
INFO - 2023-05-13 10:17:10 --> Loader Class Initialized
INFO - 2023-05-13 10:17:10 --> Helper loaded: url_helper
INFO - 2023-05-13 10:17:10 --> Helper loaded: file_helper
INFO - 2023-05-13 10:17:10 --> Helper loaded: html_helper
INFO - 2023-05-13 10:17:10 --> Helper loaded: text_helper
INFO - 2023-05-13 10:17:10 --> Helper loaded: form_helper
INFO - 2023-05-13 10:17:10 --> Helper loaded: lang_helper
INFO - 2023-05-13 10:17:10 --> Helper loaded: security_helper
INFO - 2023-05-13 10:17:10 --> Helper loaded: cookie_helper
INFO - 2023-05-13 10:17:10 --> Database Driver Class Initialized
INFO - 2023-05-13 10:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 10:17:10 --> Parser Class Initialized
INFO - 2023-05-13 10:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 10:17:10 --> Pagination Class Initialized
INFO - 2023-05-13 10:17:10 --> Form Validation Class Initialized
INFO - 2023-05-13 10:17:10 --> Controller Class Initialized
INFO - 2023-05-13 10:17:10 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-13 10:17:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 10:17:11 --> Config Class Initialized
INFO - 2023-05-13 10:17:11 --> Hooks Class Initialized
DEBUG - 2023-05-13 10:17:11 --> UTF-8 Support Enabled
INFO - 2023-05-13 10:17:11 --> Utf8 Class Initialized
INFO - 2023-05-13 10:17:11 --> URI Class Initialized
INFO - 2023-05-13 10:17:11 --> Router Class Initialized
INFO - 2023-05-13 10:17:11 --> Output Class Initialized
INFO - 2023-05-13 10:17:11 --> Security Class Initialized
DEBUG - 2023-05-13 10:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 10:17:11 --> Input Class Initialized
INFO - 2023-05-13 10:17:11 --> Language Class Initialized
INFO - 2023-05-13 10:17:11 --> Loader Class Initialized
INFO - 2023-05-13 10:17:11 --> Helper loaded: url_helper
INFO - 2023-05-13 10:17:11 --> Helper loaded: file_helper
INFO - 2023-05-13 10:17:11 --> Helper loaded: html_helper
INFO - 2023-05-13 10:17:11 --> Helper loaded: text_helper
INFO - 2023-05-13 10:17:11 --> Helper loaded: form_helper
INFO - 2023-05-13 10:17:11 --> Helper loaded: lang_helper
INFO - 2023-05-13 10:17:11 --> Helper loaded: security_helper
INFO - 2023-05-13 10:17:11 --> Helper loaded: cookie_helper
INFO - 2023-05-13 10:17:11 --> Database Driver Class Initialized
INFO - 2023-05-13 10:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 10:17:11 --> Parser Class Initialized
INFO - 2023-05-13 10:17:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 10:17:11 --> Pagination Class Initialized
INFO - 2023-05-13 10:17:11 --> Form Validation Class Initialized
INFO - 2023-05-13 10:17:11 --> Controller Class Initialized
INFO - 2023-05-13 10:17:11 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-13 10:17:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 10:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 10:17:11 --> Model Class Initialized
INFO - 2023-05-13 10:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 10:17:11 --> Final output sent to browser
DEBUG - 2023-05-13 10:17:11 --> Total execution time: 0.0398
ERROR - 2023-05-13 10:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 10:17:25 --> Config Class Initialized
INFO - 2023-05-13 10:17:25 --> Hooks Class Initialized
DEBUG - 2023-05-13 10:17:25 --> UTF-8 Support Enabled
INFO - 2023-05-13 10:17:25 --> Utf8 Class Initialized
INFO - 2023-05-13 10:17:25 --> URI Class Initialized
INFO - 2023-05-13 10:17:25 --> Router Class Initialized
INFO - 2023-05-13 10:17:25 --> Output Class Initialized
INFO - 2023-05-13 10:17:25 --> Security Class Initialized
DEBUG - 2023-05-13 10:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 10:17:25 --> Input Class Initialized
INFO - 2023-05-13 10:17:25 --> Language Class Initialized
INFO - 2023-05-13 10:17:25 --> Loader Class Initialized
INFO - 2023-05-13 10:17:25 --> Helper loaded: url_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: file_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: html_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: text_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: form_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: lang_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: security_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: cookie_helper
INFO - 2023-05-13 10:17:25 --> Database Driver Class Initialized
INFO - 2023-05-13 10:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 10:17:25 --> Parser Class Initialized
INFO - 2023-05-13 10:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 10:17:25 --> Pagination Class Initialized
INFO - 2023-05-13 10:17:25 --> Form Validation Class Initialized
INFO - 2023-05-13 10:17:25 --> Controller Class Initialized
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
INFO - 2023-05-13 10:17:25 --> Final output sent to browser
DEBUG - 2023-05-13 10:17:25 --> Total execution time: 0.0190
ERROR - 2023-05-13 10:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 10:17:25 --> Config Class Initialized
INFO - 2023-05-13 10:17:25 --> Hooks Class Initialized
DEBUG - 2023-05-13 10:17:25 --> UTF-8 Support Enabled
INFO - 2023-05-13 10:17:25 --> Utf8 Class Initialized
INFO - 2023-05-13 10:17:25 --> URI Class Initialized
DEBUG - 2023-05-13 10:17:25 --> No URI present. Default controller set.
INFO - 2023-05-13 10:17:25 --> Router Class Initialized
INFO - 2023-05-13 10:17:25 --> Output Class Initialized
INFO - 2023-05-13 10:17:25 --> Security Class Initialized
DEBUG - 2023-05-13 10:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 10:17:25 --> Input Class Initialized
INFO - 2023-05-13 10:17:25 --> Language Class Initialized
INFO - 2023-05-13 10:17:25 --> Loader Class Initialized
INFO - 2023-05-13 10:17:25 --> Helper loaded: url_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: file_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: html_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: text_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: form_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: lang_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: security_helper
INFO - 2023-05-13 10:17:25 --> Helper loaded: cookie_helper
INFO - 2023-05-13 10:17:25 --> Database Driver Class Initialized
INFO - 2023-05-13 10:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 10:17:25 --> Parser Class Initialized
INFO - 2023-05-13 10:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 10:17:25 --> Pagination Class Initialized
INFO - 2023-05-13 10:17:25 --> Form Validation Class Initialized
INFO - 2023-05-13 10:17:25 --> Controller Class Initialized
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-13 10:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
INFO - 2023-05-13 10:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-13 10:17:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 10:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 10:17:25 --> Model Class Initialized
INFO - 2023-05-13 10:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-13 10:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-13 10:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 10:17:25 --> Final output sent to browser
DEBUG - 2023-05-13 10:17:25 --> Total execution time: 0.0791
ERROR - 2023-05-13 10:17:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 10:17:41 --> Config Class Initialized
INFO - 2023-05-13 10:17:41 --> Hooks Class Initialized
DEBUG - 2023-05-13 10:17:41 --> UTF-8 Support Enabled
INFO - 2023-05-13 10:17:41 --> Utf8 Class Initialized
INFO - 2023-05-13 10:17:41 --> URI Class Initialized
INFO - 2023-05-13 10:17:41 --> Router Class Initialized
INFO - 2023-05-13 10:17:41 --> Output Class Initialized
INFO - 2023-05-13 10:17:41 --> Security Class Initialized
DEBUG - 2023-05-13 10:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 10:17:41 --> Input Class Initialized
INFO - 2023-05-13 10:17:41 --> Language Class Initialized
INFO - 2023-05-13 10:17:41 --> Loader Class Initialized
INFO - 2023-05-13 10:17:41 --> Helper loaded: url_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: file_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: html_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: text_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: form_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: lang_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: security_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: cookie_helper
INFO - 2023-05-13 10:17:41 --> Database Driver Class Initialized
INFO - 2023-05-13 10:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 10:17:41 --> Parser Class Initialized
INFO - 2023-05-13 10:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 10:17:41 --> Pagination Class Initialized
INFO - 2023-05-13 10:17:41 --> Form Validation Class Initialized
INFO - 2023-05-13 10:17:41 --> Controller Class Initialized
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-13 10:17:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 10:17:41 --> Final output sent to browser
DEBUG - 2023-05-13 10:17:41 --> Total execution time: 0.0308
ERROR - 2023-05-13 10:17:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 10:17:41 --> Config Class Initialized
INFO - 2023-05-13 10:17:41 --> Hooks Class Initialized
DEBUG - 2023-05-13 10:17:41 --> UTF-8 Support Enabled
INFO - 2023-05-13 10:17:41 --> Utf8 Class Initialized
INFO - 2023-05-13 10:17:41 --> URI Class Initialized
INFO - 2023-05-13 10:17:41 --> Router Class Initialized
INFO - 2023-05-13 10:17:41 --> Output Class Initialized
INFO - 2023-05-13 10:17:41 --> Security Class Initialized
DEBUG - 2023-05-13 10:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 10:17:41 --> Input Class Initialized
INFO - 2023-05-13 10:17:41 --> Language Class Initialized
INFO - 2023-05-13 10:17:41 --> Loader Class Initialized
INFO - 2023-05-13 10:17:41 --> Helper loaded: url_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: file_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: html_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: text_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: form_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: lang_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: security_helper
INFO - 2023-05-13 10:17:41 --> Helper loaded: cookie_helper
INFO - 2023-05-13 10:17:41 --> Database Driver Class Initialized
INFO - 2023-05-13 10:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 10:17:41 --> Parser Class Initialized
INFO - 2023-05-13 10:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 10:17:41 --> Pagination Class Initialized
INFO - 2023-05-13 10:17:41 --> Form Validation Class Initialized
INFO - 2023-05-13 10:17:41 --> Controller Class Initialized
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
DEBUG - 2023-05-13 10:17:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-13 10:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-13 10:17:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 10:17:41 --> Model Class Initialized
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-13 10:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 10:17:41 --> Final output sent to browser
DEBUG - 2023-05-13 10:17:41 --> Total execution time: 0.0744
ERROR - 2023-05-13 12:40:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 12:40:48 --> Config Class Initialized
INFO - 2023-05-13 12:40:48 --> Hooks Class Initialized
DEBUG - 2023-05-13 12:40:48 --> UTF-8 Support Enabled
INFO - 2023-05-13 12:40:48 --> Utf8 Class Initialized
INFO - 2023-05-13 12:40:48 --> URI Class Initialized
DEBUG - 2023-05-13 12:40:48 --> No URI present. Default controller set.
INFO - 2023-05-13 12:40:48 --> Router Class Initialized
INFO - 2023-05-13 12:40:48 --> Output Class Initialized
INFO - 2023-05-13 12:40:48 --> Security Class Initialized
DEBUG - 2023-05-13 12:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 12:40:48 --> Input Class Initialized
INFO - 2023-05-13 12:40:48 --> Language Class Initialized
INFO - 2023-05-13 12:40:48 --> Loader Class Initialized
INFO - 2023-05-13 12:40:48 --> Helper loaded: url_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: file_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: html_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: text_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: form_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: lang_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: security_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: cookie_helper
INFO - 2023-05-13 12:40:48 --> Database Driver Class Initialized
INFO - 2023-05-13 12:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 12:40:48 --> Parser Class Initialized
INFO - 2023-05-13 12:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 12:40:48 --> Pagination Class Initialized
INFO - 2023-05-13 12:40:48 --> Form Validation Class Initialized
INFO - 2023-05-13 12:40:48 --> Controller Class Initialized
INFO - 2023-05-13 12:40:48 --> Model Class Initialized
DEBUG - 2023-05-13 12:40:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-13 12:40:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 12:40:48 --> Config Class Initialized
INFO - 2023-05-13 12:40:48 --> Hooks Class Initialized
DEBUG - 2023-05-13 12:40:48 --> UTF-8 Support Enabled
INFO - 2023-05-13 12:40:48 --> Utf8 Class Initialized
INFO - 2023-05-13 12:40:48 --> URI Class Initialized
INFO - 2023-05-13 12:40:48 --> Router Class Initialized
INFO - 2023-05-13 12:40:48 --> Output Class Initialized
INFO - 2023-05-13 12:40:48 --> Security Class Initialized
DEBUG - 2023-05-13 12:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 12:40:48 --> Input Class Initialized
INFO - 2023-05-13 12:40:48 --> Language Class Initialized
INFO - 2023-05-13 12:40:48 --> Loader Class Initialized
INFO - 2023-05-13 12:40:48 --> Helper loaded: url_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: file_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: html_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: text_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: form_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: lang_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: security_helper
INFO - 2023-05-13 12:40:48 --> Helper loaded: cookie_helper
INFO - 2023-05-13 12:40:48 --> Database Driver Class Initialized
INFO - 2023-05-13 12:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 12:40:48 --> Parser Class Initialized
INFO - 2023-05-13 12:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 12:40:48 --> Pagination Class Initialized
INFO - 2023-05-13 12:40:48 --> Form Validation Class Initialized
INFO - 2023-05-13 12:40:48 --> Controller Class Initialized
INFO - 2023-05-13 12:40:48 --> Model Class Initialized
DEBUG - 2023-05-13 12:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 12:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-13 12:40:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 12:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 12:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 12:40:48 --> Model Class Initialized
INFO - 2023-05-13 12:40:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 12:40:48 --> Final output sent to browser
DEBUG - 2023-05-13 12:40:48 --> Total execution time: 0.0371
ERROR - 2023-05-13 13:07:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 13:07:50 --> Config Class Initialized
INFO - 2023-05-13 13:07:50 --> Hooks Class Initialized
DEBUG - 2023-05-13 13:07:50 --> UTF-8 Support Enabled
INFO - 2023-05-13 13:07:50 --> Utf8 Class Initialized
INFO - 2023-05-13 13:07:50 --> URI Class Initialized
DEBUG - 2023-05-13 13:07:50 --> No URI present. Default controller set.
INFO - 2023-05-13 13:07:50 --> Router Class Initialized
INFO - 2023-05-13 13:07:50 --> Output Class Initialized
INFO - 2023-05-13 13:07:50 --> Security Class Initialized
DEBUG - 2023-05-13 13:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 13:07:50 --> Input Class Initialized
INFO - 2023-05-13 13:07:50 --> Language Class Initialized
INFO - 2023-05-13 13:07:50 --> Loader Class Initialized
INFO - 2023-05-13 13:07:50 --> Helper loaded: url_helper
INFO - 2023-05-13 13:07:50 --> Helper loaded: file_helper
INFO - 2023-05-13 13:07:50 --> Helper loaded: html_helper
INFO - 2023-05-13 13:07:50 --> Helper loaded: text_helper
INFO - 2023-05-13 13:07:50 --> Helper loaded: form_helper
INFO - 2023-05-13 13:07:50 --> Helper loaded: lang_helper
INFO - 2023-05-13 13:07:50 --> Helper loaded: security_helper
INFO - 2023-05-13 13:07:50 --> Helper loaded: cookie_helper
INFO - 2023-05-13 13:07:50 --> Database Driver Class Initialized
INFO - 2023-05-13 13:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 13:07:51 --> Parser Class Initialized
INFO - 2023-05-13 13:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 13:07:51 --> Pagination Class Initialized
INFO - 2023-05-13 13:07:51 --> Form Validation Class Initialized
INFO - 2023-05-13 13:07:51 --> Controller Class Initialized
INFO - 2023-05-13 13:07:51 --> Model Class Initialized
DEBUG - 2023-05-13 13:07:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-13 13:07:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 13:07:51 --> Config Class Initialized
INFO - 2023-05-13 13:07:51 --> Hooks Class Initialized
DEBUG - 2023-05-13 13:07:51 --> UTF-8 Support Enabled
INFO - 2023-05-13 13:07:51 --> Utf8 Class Initialized
INFO - 2023-05-13 13:07:51 --> URI Class Initialized
INFO - 2023-05-13 13:07:51 --> Router Class Initialized
INFO - 2023-05-13 13:07:51 --> Output Class Initialized
INFO - 2023-05-13 13:07:51 --> Security Class Initialized
DEBUG - 2023-05-13 13:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 13:07:51 --> Input Class Initialized
INFO - 2023-05-13 13:07:51 --> Language Class Initialized
INFO - 2023-05-13 13:07:51 --> Loader Class Initialized
INFO - 2023-05-13 13:07:51 --> Helper loaded: url_helper
INFO - 2023-05-13 13:07:51 --> Helper loaded: file_helper
INFO - 2023-05-13 13:07:51 --> Helper loaded: html_helper
INFO - 2023-05-13 13:07:51 --> Helper loaded: text_helper
INFO - 2023-05-13 13:07:51 --> Helper loaded: form_helper
INFO - 2023-05-13 13:07:51 --> Helper loaded: lang_helper
INFO - 2023-05-13 13:07:51 --> Helper loaded: security_helper
INFO - 2023-05-13 13:07:51 --> Helper loaded: cookie_helper
INFO - 2023-05-13 13:07:51 --> Database Driver Class Initialized
INFO - 2023-05-13 13:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 13:07:51 --> Parser Class Initialized
INFO - 2023-05-13 13:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 13:07:51 --> Pagination Class Initialized
INFO - 2023-05-13 13:07:51 --> Form Validation Class Initialized
INFO - 2023-05-13 13:07:51 --> Controller Class Initialized
INFO - 2023-05-13 13:07:51 --> Model Class Initialized
DEBUG - 2023-05-13 13:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 13:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-13 13:07:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 13:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 13:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 13:07:51 --> Model Class Initialized
INFO - 2023-05-13 13:07:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 13:07:51 --> Final output sent to browser
DEBUG - 2023-05-13 13:07:51 --> Total execution time: 0.0314
ERROR - 2023-05-13 13:08:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 13:08:11 --> Config Class Initialized
INFO - 2023-05-13 13:08:11 --> Hooks Class Initialized
DEBUG - 2023-05-13 13:08:11 --> UTF-8 Support Enabled
INFO - 2023-05-13 13:08:11 --> Utf8 Class Initialized
INFO - 2023-05-13 13:08:11 --> URI Class Initialized
INFO - 2023-05-13 13:08:11 --> Router Class Initialized
INFO - 2023-05-13 13:08:11 --> Output Class Initialized
INFO - 2023-05-13 13:08:11 --> Security Class Initialized
DEBUG - 2023-05-13 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 13:08:11 --> Input Class Initialized
INFO - 2023-05-13 13:08:11 --> Language Class Initialized
INFO - 2023-05-13 13:08:11 --> Loader Class Initialized
INFO - 2023-05-13 13:08:11 --> Helper loaded: url_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: file_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: html_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: text_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: form_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: lang_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: security_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: cookie_helper
INFO - 2023-05-13 13:08:11 --> Database Driver Class Initialized
INFO - 2023-05-13 13:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 13:08:11 --> Parser Class Initialized
INFO - 2023-05-13 13:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 13:08:11 --> Pagination Class Initialized
INFO - 2023-05-13 13:08:11 --> Form Validation Class Initialized
INFO - 2023-05-13 13:08:11 --> Controller Class Initialized
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
DEBUG - 2023-05-13 13:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
INFO - 2023-05-13 13:08:11 --> Final output sent to browser
DEBUG - 2023-05-13 13:08:11 --> Total execution time: 0.0234
ERROR - 2023-05-13 13:08:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-13 13:08:11 --> Config Class Initialized
INFO - 2023-05-13 13:08:11 --> Hooks Class Initialized
DEBUG - 2023-05-13 13:08:11 --> UTF-8 Support Enabled
INFO - 2023-05-13 13:08:11 --> Utf8 Class Initialized
INFO - 2023-05-13 13:08:11 --> URI Class Initialized
DEBUG - 2023-05-13 13:08:11 --> No URI present. Default controller set.
INFO - 2023-05-13 13:08:11 --> Router Class Initialized
INFO - 2023-05-13 13:08:11 --> Output Class Initialized
INFO - 2023-05-13 13:08:11 --> Security Class Initialized
DEBUG - 2023-05-13 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 13:08:11 --> Input Class Initialized
INFO - 2023-05-13 13:08:11 --> Language Class Initialized
INFO - 2023-05-13 13:08:11 --> Loader Class Initialized
INFO - 2023-05-13 13:08:11 --> Helper loaded: url_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: file_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: html_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: text_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: form_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: lang_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: security_helper
INFO - 2023-05-13 13:08:11 --> Helper loaded: cookie_helper
INFO - 2023-05-13 13:08:11 --> Database Driver Class Initialized
INFO - 2023-05-13 13:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-13 13:08:11 --> Parser Class Initialized
INFO - 2023-05-13 13:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-13 13:08:11 --> Pagination Class Initialized
INFO - 2023-05-13 13:08:11 --> Form Validation Class Initialized
INFO - 2023-05-13 13:08:11 --> Controller Class Initialized
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
DEBUG - 2023-05-13 13:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
DEBUG - 2023-05-13 13:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
DEBUG - 2023-05-13 13:08:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-13 13:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
INFO - 2023-05-13 13:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-13 13:08:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-13 13:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-13 13:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-13 13:08:11 --> Model Class Initialized
INFO - 2023-05-13 13:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-13 13:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-13 13:08:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-13 13:08:11 --> Final output sent to browser
DEBUG - 2023-05-13 13:08:11 --> Total execution time: 0.0866
