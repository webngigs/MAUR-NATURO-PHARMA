<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-24 04:25:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:25:15 --> Config Class Initialized
INFO - 2023-07-24 04:25:15 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:25:15 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:25:15 --> Utf8 Class Initialized
INFO - 2023-07-24 04:25:15 --> URI Class Initialized
DEBUG - 2023-07-24 04:25:15 --> No URI present. Default controller set.
INFO - 2023-07-24 04:25:15 --> Router Class Initialized
INFO - 2023-07-24 04:25:15 --> Output Class Initialized
INFO - 2023-07-24 04:25:15 --> Security Class Initialized
DEBUG - 2023-07-24 04:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:25:15 --> Input Class Initialized
INFO - 2023-07-24 04:25:15 --> Language Class Initialized
INFO - 2023-07-24 04:25:15 --> Loader Class Initialized
INFO - 2023-07-24 04:25:15 --> Helper loaded: url_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: file_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: html_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: text_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: form_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: security_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:25:15 --> Database Driver Class Initialized
INFO - 2023-07-24 04:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:25:15 --> Parser Class Initialized
INFO - 2023-07-24 04:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:25:15 --> Pagination Class Initialized
INFO - 2023-07-24 04:25:15 --> Form Validation Class Initialized
INFO - 2023-07-24 04:25:15 --> Controller Class Initialized
INFO - 2023-07-24 04:25:15 --> Model Class Initialized
DEBUG - 2023-07-24 04:25:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-24 04:25:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:25:15 --> Config Class Initialized
INFO - 2023-07-24 04:25:15 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:25:15 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:25:15 --> Utf8 Class Initialized
INFO - 2023-07-24 04:25:15 --> URI Class Initialized
INFO - 2023-07-24 04:25:15 --> Router Class Initialized
INFO - 2023-07-24 04:25:15 --> Output Class Initialized
INFO - 2023-07-24 04:25:15 --> Security Class Initialized
DEBUG - 2023-07-24 04:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:25:15 --> Input Class Initialized
INFO - 2023-07-24 04:25:15 --> Language Class Initialized
INFO - 2023-07-24 04:25:15 --> Loader Class Initialized
INFO - 2023-07-24 04:25:15 --> Helper loaded: url_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: file_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: html_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: text_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: form_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: security_helper
INFO - 2023-07-24 04:25:15 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:25:15 --> Database Driver Class Initialized
INFO - 2023-07-24 04:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:25:15 --> Parser Class Initialized
INFO - 2023-07-24 04:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:25:15 --> Pagination Class Initialized
INFO - 2023-07-24 04:25:15 --> Form Validation Class Initialized
INFO - 2023-07-24 04:25:15 --> Controller Class Initialized
INFO - 2023-07-24 04:25:15 --> Model Class Initialized
DEBUG - 2023-07-24 04:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-24 04:25:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 04:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 04:25:15 --> Model Class Initialized
INFO - 2023-07-24 04:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 04:25:15 --> Final output sent to browser
DEBUG - 2023-07-24 04:25:15 --> Total execution time: 0.0287
ERROR - 2023-07-24 04:25:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:25:46 --> Config Class Initialized
INFO - 2023-07-24 04:25:46 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:25:46 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:25:46 --> Utf8 Class Initialized
INFO - 2023-07-24 04:25:46 --> URI Class Initialized
INFO - 2023-07-24 04:25:46 --> Router Class Initialized
INFO - 2023-07-24 04:25:46 --> Output Class Initialized
INFO - 2023-07-24 04:25:46 --> Security Class Initialized
DEBUG - 2023-07-24 04:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:25:46 --> Input Class Initialized
INFO - 2023-07-24 04:25:46 --> Language Class Initialized
INFO - 2023-07-24 04:25:46 --> Loader Class Initialized
INFO - 2023-07-24 04:25:46 --> Helper loaded: url_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: file_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: html_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: text_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: form_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: security_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:25:46 --> Database Driver Class Initialized
INFO - 2023-07-24 04:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:25:46 --> Parser Class Initialized
INFO - 2023-07-24 04:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:25:46 --> Pagination Class Initialized
INFO - 2023-07-24 04:25:46 --> Form Validation Class Initialized
INFO - 2023-07-24 04:25:46 --> Controller Class Initialized
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
DEBUG - 2023-07-24 04:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
INFO - 2023-07-24 04:25:46 --> Final output sent to browser
DEBUG - 2023-07-24 04:25:46 --> Total execution time: 0.0204
ERROR - 2023-07-24 04:25:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:25:46 --> Config Class Initialized
INFO - 2023-07-24 04:25:46 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:25:46 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:25:46 --> Utf8 Class Initialized
INFO - 2023-07-24 04:25:46 --> URI Class Initialized
DEBUG - 2023-07-24 04:25:46 --> No URI present. Default controller set.
INFO - 2023-07-24 04:25:46 --> Router Class Initialized
INFO - 2023-07-24 04:25:46 --> Output Class Initialized
INFO - 2023-07-24 04:25:46 --> Security Class Initialized
DEBUG - 2023-07-24 04:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:25:46 --> Input Class Initialized
INFO - 2023-07-24 04:25:46 --> Language Class Initialized
INFO - 2023-07-24 04:25:46 --> Loader Class Initialized
INFO - 2023-07-24 04:25:46 --> Helper loaded: url_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: file_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: html_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: text_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: form_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: security_helper
INFO - 2023-07-24 04:25:46 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:25:46 --> Database Driver Class Initialized
INFO - 2023-07-24 04:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:25:46 --> Parser Class Initialized
INFO - 2023-07-24 04:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:25:46 --> Pagination Class Initialized
INFO - 2023-07-24 04:25:46 --> Form Validation Class Initialized
INFO - 2023-07-24 04:25:46 --> Controller Class Initialized
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
DEBUG - 2023-07-24 04:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
DEBUG - 2023-07-24 04:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
DEBUG - 2023-07-24 04:25:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
INFO - 2023-07-24 04:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 04:25:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 04:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 04:25:46 --> Model Class Initialized
INFO - 2023-07-24 04:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 04:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 04:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 04:25:46 --> Final output sent to browser
DEBUG - 2023-07-24 04:25:46 --> Total execution time: 0.0813
ERROR - 2023-07-24 04:25:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:25:58 --> Config Class Initialized
INFO - 2023-07-24 04:25:58 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:25:58 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:25:58 --> Utf8 Class Initialized
INFO - 2023-07-24 04:25:58 --> URI Class Initialized
INFO - 2023-07-24 04:25:58 --> Router Class Initialized
INFO - 2023-07-24 04:25:58 --> Output Class Initialized
INFO - 2023-07-24 04:25:58 --> Security Class Initialized
DEBUG - 2023-07-24 04:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:25:58 --> Input Class Initialized
INFO - 2023-07-24 04:25:58 --> Language Class Initialized
INFO - 2023-07-24 04:25:58 --> Loader Class Initialized
INFO - 2023-07-24 04:25:58 --> Helper loaded: url_helper
INFO - 2023-07-24 04:25:58 --> Helper loaded: file_helper
INFO - 2023-07-24 04:25:58 --> Helper loaded: html_helper
INFO - 2023-07-24 04:25:58 --> Helper loaded: text_helper
INFO - 2023-07-24 04:25:58 --> Helper loaded: form_helper
INFO - 2023-07-24 04:25:58 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:25:58 --> Helper loaded: security_helper
INFO - 2023-07-24 04:25:58 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:25:58 --> Database Driver Class Initialized
INFO - 2023-07-24 04:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:25:58 --> Parser Class Initialized
INFO - 2023-07-24 04:25:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:25:58 --> Pagination Class Initialized
INFO - 2023-07-24 04:25:58 --> Form Validation Class Initialized
INFO - 2023-07-24 04:25:58 --> Controller Class Initialized
INFO - 2023-07-24 04:25:58 --> Model Class Initialized
DEBUG - 2023-07-24 04:25:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:25:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:58 --> Model Class Initialized
DEBUG - 2023-07-24 04:25:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:58 --> Model Class Initialized
INFO - 2023-07-24 04:25:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-07-24 04:25:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:25:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 04:25:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 04:25:58 --> Model Class Initialized
INFO - 2023-07-24 04:25:58 --> Model Class Initialized
INFO - 2023-07-24 04:25:58 --> Model Class Initialized
INFO - 2023-07-24 04:25:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 04:25:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 04:25:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 04:25:58 --> Final output sent to browser
DEBUG - 2023-07-24 04:25:58 --> Total execution time: 0.2113
ERROR - 2023-07-24 04:26:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:11 --> Config Class Initialized
INFO - 2023-07-24 04:26:11 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:11 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:11 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:11 --> URI Class Initialized
INFO - 2023-07-24 04:26:11 --> Router Class Initialized
INFO - 2023-07-24 04:26:11 --> Output Class Initialized
INFO - 2023-07-24 04:26:11 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:11 --> Input Class Initialized
INFO - 2023-07-24 04:26:11 --> Language Class Initialized
INFO - 2023-07-24 04:26:11 --> Loader Class Initialized
INFO - 2023-07-24 04:26:11 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:11 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:11 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:11 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:11 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:11 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:11 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:11 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:11 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:11 --> Parser Class Initialized
INFO - 2023-07-24 04:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:11 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:11 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:11 --> Controller Class Initialized
INFO - 2023-07-24 04:26:11 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:11 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:11 --> Total execution time: 0.0189
ERROR - 2023-07-24 04:26:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:12 --> Config Class Initialized
INFO - 2023-07-24 04:26:12 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:12 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:12 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:12 --> URI Class Initialized
INFO - 2023-07-24 04:26:12 --> Router Class Initialized
INFO - 2023-07-24 04:26:12 --> Output Class Initialized
INFO - 2023-07-24 04:26:12 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:12 --> Input Class Initialized
INFO - 2023-07-24 04:26:12 --> Language Class Initialized
INFO - 2023-07-24 04:26:12 --> Loader Class Initialized
INFO - 2023-07-24 04:26:12 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:12 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:12 --> Parser Class Initialized
INFO - 2023-07-24 04:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:12 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:12 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:12 --> Controller Class Initialized
INFO - 2023-07-24 04:26:12 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:12 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:12 --> Total execution time: 0.0162
ERROR - 2023-07-24 04:26:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:12 --> Config Class Initialized
INFO - 2023-07-24 04:26:12 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:12 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:12 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:12 --> URI Class Initialized
INFO - 2023-07-24 04:26:12 --> Router Class Initialized
INFO - 2023-07-24 04:26:12 --> Output Class Initialized
INFO - 2023-07-24 04:26:12 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:12 --> Input Class Initialized
INFO - 2023-07-24 04:26:12 --> Language Class Initialized
INFO - 2023-07-24 04:26:12 --> Loader Class Initialized
INFO - 2023-07-24 04:26:12 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:12 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:12 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:12 --> Parser Class Initialized
INFO - 2023-07-24 04:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:12 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:12 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:12 --> Controller Class Initialized
INFO - 2023-07-24 04:26:12 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:12 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:12 --> Total execution time: 0.0503
ERROR - 2023-07-24 04:26:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:13 --> Config Class Initialized
INFO - 2023-07-24 04:26:13 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:13 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:13 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:13 --> URI Class Initialized
INFO - 2023-07-24 04:26:13 --> Router Class Initialized
INFO - 2023-07-24 04:26:13 --> Output Class Initialized
INFO - 2023-07-24 04:26:13 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:13 --> Input Class Initialized
INFO - 2023-07-24 04:26:13 --> Language Class Initialized
INFO - 2023-07-24 04:26:13 --> Loader Class Initialized
INFO - 2023-07-24 04:26:13 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:13 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:13 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:13 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:13 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:13 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:13 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:13 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:13 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:13 --> Parser Class Initialized
INFO - 2023-07-24 04:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:13 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:13 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:13 --> Controller Class Initialized
INFO - 2023-07-24 04:26:13 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:13 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:13 --> Total execution time: 0.0386
ERROR - 2023-07-24 04:26:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:14 --> Config Class Initialized
INFO - 2023-07-24 04:26:14 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:14 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:14 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:14 --> URI Class Initialized
INFO - 2023-07-24 04:26:14 --> Router Class Initialized
INFO - 2023-07-24 04:26:14 --> Output Class Initialized
INFO - 2023-07-24 04:26:14 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:14 --> Input Class Initialized
INFO - 2023-07-24 04:26:14 --> Language Class Initialized
INFO - 2023-07-24 04:26:14 --> Loader Class Initialized
INFO - 2023-07-24 04:26:14 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:14 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:14 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:14 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:14 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:14 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:14 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:14 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:14 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:14 --> Parser Class Initialized
INFO - 2023-07-24 04:26:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:14 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:14 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:14 --> Controller Class Initialized
INFO - 2023-07-24 04:26:14 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:14 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:14 --> Total execution time: 0.0154
ERROR - 2023-07-24 04:26:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:18 --> Config Class Initialized
INFO - 2023-07-24 04:26:18 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:18 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:18 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:18 --> URI Class Initialized
INFO - 2023-07-24 04:26:18 --> Router Class Initialized
INFO - 2023-07-24 04:26:18 --> Output Class Initialized
INFO - 2023-07-24 04:26:18 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:18 --> Input Class Initialized
INFO - 2023-07-24 04:26:18 --> Language Class Initialized
INFO - 2023-07-24 04:26:18 --> Loader Class Initialized
INFO - 2023-07-24 04:26:18 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:18 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:18 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:18 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:18 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:18 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:18 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:18 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:18 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:18 --> Parser Class Initialized
INFO - 2023-07-24 04:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:18 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:18 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:18 --> Controller Class Initialized
INFO - 2023-07-24 04:26:18 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:18 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:18 --> Total execution time: 0.0154
ERROR - 2023-07-24 04:26:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:21 --> Config Class Initialized
INFO - 2023-07-24 04:26:21 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:21 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:21 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:21 --> URI Class Initialized
INFO - 2023-07-24 04:26:21 --> Router Class Initialized
INFO - 2023-07-24 04:26:21 --> Output Class Initialized
INFO - 2023-07-24 04:26:21 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:21 --> Input Class Initialized
INFO - 2023-07-24 04:26:21 --> Language Class Initialized
INFO - 2023-07-24 04:26:21 --> Loader Class Initialized
INFO - 2023-07-24 04:26:21 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:21 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:21 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:21 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:21 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:21 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:21 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:21 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:21 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:21 --> Parser Class Initialized
INFO - 2023-07-24 04:26:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:21 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:21 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:21 --> Controller Class Initialized
INFO - 2023-07-24 04:26:21 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:21 --> Total execution time: 0.0140
ERROR - 2023-07-24 04:26:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:39 --> Config Class Initialized
INFO - 2023-07-24 04:26:39 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:39 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:39 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:39 --> URI Class Initialized
INFO - 2023-07-24 04:26:39 --> Router Class Initialized
INFO - 2023-07-24 04:26:39 --> Output Class Initialized
INFO - 2023-07-24 04:26:39 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:39 --> Input Class Initialized
INFO - 2023-07-24 04:26:39 --> Language Class Initialized
INFO - 2023-07-24 04:26:39 --> Loader Class Initialized
INFO - 2023-07-24 04:26:39 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:39 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:39 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:39 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:39 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:39 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:39 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:39 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:39 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:39 --> Parser Class Initialized
INFO - 2023-07-24 04:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:39 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:39 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:39 --> Controller Class Initialized
INFO - 2023-07-24 04:26:39 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:39 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:39 --> Model Class Initialized
INFO - 2023-07-24 04:26:39 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:39 --> Total execution time: 0.0214
ERROR - 2023-07-24 04:26:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:41 --> Config Class Initialized
INFO - 2023-07-24 04:26:41 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:41 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:41 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:41 --> URI Class Initialized
INFO - 2023-07-24 04:26:41 --> Router Class Initialized
INFO - 2023-07-24 04:26:41 --> Output Class Initialized
INFO - 2023-07-24 04:26:41 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:41 --> Input Class Initialized
INFO - 2023-07-24 04:26:41 --> Language Class Initialized
INFO - 2023-07-24 04:26:41 --> Loader Class Initialized
INFO - 2023-07-24 04:26:41 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:41 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:41 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:41 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:41 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:41 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:41 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:41 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:41 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:41 --> Parser Class Initialized
INFO - 2023-07-24 04:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:41 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:41 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:41 --> Controller Class Initialized
INFO - 2023-07-24 04:26:41 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:41 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:41 --> Model Class Initialized
INFO - 2023-07-24 04:26:41 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:41 --> Total execution time: 0.0514
ERROR - 2023-07-24 04:26:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:42 --> Config Class Initialized
INFO - 2023-07-24 04:26:42 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:42 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:42 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:42 --> URI Class Initialized
INFO - 2023-07-24 04:26:42 --> Router Class Initialized
INFO - 2023-07-24 04:26:42 --> Output Class Initialized
INFO - 2023-07-24 04:26:42 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:42 --> Input Class Initialized
INFO - 2023-07-24 04:26:42 --> Language Class Initialized
INFO - 2023-07-24 04:26:42 --> Loader Class Initialized
INFO - 2023-07-24 04:26:42 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:42 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:42 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:42 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:42 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:42 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:42 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:42 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:42 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:42 --> Parser Class Initialized
INFO - 2023-07-24 04:26:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:42 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:42 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:42 --> Controller Class Initialized
INFO - 2023-07-24 04:26:42 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:42 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:42 --> Model Class Initialized
INFO - 2023-07-24 04:26:42 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:42 --> Total execution time: 0.0503
ERROR - 2023-07-24 04:26:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:44 --> Config Class Initialized
INFO - 2023-07-24 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:44 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:44 --> URI Class Initialized
INFO - 2023-07-24 04:26:44 --> Router Class Initialized
INFO - 2023-07-24 04:26:44 --> Output Class Initialized
INFO - 2023-07-24 04:26:44 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:44 --> Input Class Initialized
INFO - 2023-07-24 04:26:44 --> Language Class Initialized
INFO - 2023-07-24 04:26:44 --> Loader Class Initialized
INFO - 2023-07-24 04:26:44 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:44 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:44 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:44 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:44 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:44 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:44 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:44 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:44 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:44 --> Parser Class Initialized
INFO - 2023-07-24 04:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:44 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:44 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:44 --> Controller Class Initialized
INFO - 2023-07-24 04:26:44 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:44 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:44 --> Model Class Initialized
INFO - 2023-07-24 04:26:44 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:44 --> Total execution time: 0.1165
ERROR - 2023-07-24 04:26:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:45 --> Config Class Initialized
INFO - 2023-07-24 04:26:45 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:45 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:45 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:45 --> URI Class Initialized
INFO - 2023-07-24 04:26:45 --> Router Class Initialized
INFO - 2023-07-24 04:26:45 --> Output Class Initialized
INFO - 2023-07-24 04:26:45 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:45 --> Input Class Initialized
INFO - 2023-07-24 04:26:45 --> Language Class Initialized
INFO - 2023-07-24 04:26:45 --> Loader Class Initialized
INFO - 2023-07-24 04:26:45 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:45 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:45 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:45 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:45 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:45 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:45 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:45 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:45 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:45 --> Parser Class Initialized
INFO - 2023-07-24 04:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:45 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:45 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:45 --> Controller Class Initialized
INFO - 2023-07-24 04:26:45 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:45 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:45 --> Model Class Initialized
INFO - 2023-07-24 04:26:45 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:45 --> Total execution time: 0.0973
ERROR - 2023-07-24 04:26:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:26:51 --> Config Class Initialized
INFO - 2023-07-24 04:26:51 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:26:51 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:26:51 --> Utf8 Class Initialized
INFO - 2023-07-24 04:26:51 --> URI Class Initialized
INFO - 2023-07-24 04:26:51 --> Router Class Initialized
INFO - 2023-07-24 04:26:51 --> Output Class Initialized
INFO - 2023-07-24 04:26:51 --> Security Class Initialized
DEBUG - 2023-07-24 04:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:26:51 --> Input Class Initialized
INFO - 2023-07-24 04:26:51 --> Language Class Initialized
INFO - 2023-07-24 04:26:51 --> Loader Class Initialized
INFO - 2023-07-24 04:26:51 --> Helper loaded: url_helper
INFO - 2023-07-24 04:26:51 --> Helper loaded: file_helper
INFO - 2023-07-24 04:26:51 --> Helper loaded: html_helper
INFO - 2023-07-24 04:26:51 --> Helper loaded: text_helper
INFO - 2023-07-24 04:26:51 --> Helper loaded: form_helper
INFO - 2023-07-24 04:26:51 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:26:51 --> Helper loaded: security_helper
INFO - 2023-07-24 04:26:51 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:26:51 --> Database Driver Class Initialized
INFO - 2023-07-24 04:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:26:51 --> Parser Class Initialized
INFO - 2023-07-24 04:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:26:51 --> Pagination Class Initialized
INFO - 2023-07-24 04:26:51 --> Form Validation Class Initialized
INFO - 2023-07-24 04:26:51 --> Controller Class Initialized
INFO - 2023-07-24 04:26:51 --> Model Class Initialized
DEBUG - 2023-07-24 04:26:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:26:51 --> Model Class Initialized
INFO - 2023-07-24 04:26:51 --> Model Class Initialized
INFO - 2023-07-24 04:26:51 --> Final output sent to browser
DEBUG - 2023-07-24 04:26:51 --> Total execution time: 0.0247
ERROR - 2023-07-24 04:29:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:29:25 --> Config Class Initialized
INFO - 2023-07-24 04:29:25 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:29:25 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:29:25 --> Utf8 Class Initialized
INFO - 2023-07-24 04:29:25 --> URI Class Initialized
INFO - 2023-07-24 04:29:25 --> Router Class Initialized
INFO - 2023-07-24 04:29:25 --> Output Class Initialized
INFO - 2023-07-24 04:29:25 --> Security Class Initialized
DEBUG - 2023-07-24 04:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:29:25 --> Input Class Initialized
INFO - 2023-07-24 04:29:25 --> Language Class Initialized
INFO - 2023-07-24 04:29:25 --> Loader Class Initialized
INFO - 2023-07-24 04:29:25 --> Helper loaded: url_helper
INFO - 2023-07-24 04:29:25 --> Helper loaded: file_helper
INFO - 2023-07-24 04:29:25 --> Helper loaded: html_helper
INFO - 2023-07-24 04:29:25 --> Helper loaded: text_helper
INFO - 2023-07-24 04:29:25 --> Helper loaded: form_helper
INFO - 2023-07-24 04:29:25 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:29:25 --> Helper loaded: security_helper
INFO - 2023-07-24 04:29:25 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:29:25 --> Database Driver Class Initialized
INFO - 2023-07-24 04:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:29:25 --> Parser Class Initialized
INFO - 2023-07-24 04:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:29:25 --> Pagination Class Initialized
INFO - 2023-07-24 04:29:25 --> Form Validation Class Initialized
INFO - 2023-07-24 04:29:25 --> Controller Class Initialized
INFO - 2023-07-24 04:29:25 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:29:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:25 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:25 --> Model Class Initialized
INFO - 2023-07-24 04:29:25 --> Final output sent to browser
DEBUG - 2023-07-24 04:29:25 --> Total execution time: 0.0615
ERROR - 2023-07-24 04:29:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:29:27 --> Config Class Initialized
INFO - 2023-07-24 04:29:27 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:29:27 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:29:27 --> Utf8 Class Initialized
INFO - 2023-07-24 04:29:27 --> URI Class Initialized
INFO - 2023-07-24 04:29:27 --> Router Class Initialized
INFO - 2023-07-24 04:29:27 --> Output Class Initialized
INFO - 2023-07-24 04:29:27 --> Security Class Initialized
DEBUG - 2023-07-24 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:29:27 --> Input Class Initialized
INFO - 2023-07-24 04:29:27 --> Language Class Initialized
INFO - 2023-07-24 04:29:27 --> Loader Class Initialized
INFO - 2023-07-24 04:29:27 --> Helper loaded: url_helper
INFO - 2023-07-24 04:29:27 --> Helper loaded: file_helper
INFO - 2023-07-24 04:29:27 --> Helper loaded: html_helper
INFO - 2023-07-24 04:29:27 --> Helper loaded: text_helper
INFO - 2023-07-24 04:29:27 --> Helper loaded: form_helper
INFO - 2023-07-24 04:29:27 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:29:27 --> Helper loaded: security_helper
INFO - 2023-07-24 04:29:27 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:29:27 --> Database Driver Class Initialized
INFO - 2023-07-24 04:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:29:27 --> Parser Class Initialized
INFO - 2023-07-24 04:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:29:27 --> Pagination Class Initialized
INFO - 2023-07-24 04:29:27 --> Form Validation Class Initialized
INFO - 2023-07-24 04:29:27 --> Controller Class Initialized
INFO - 2023-07-24 04:29:27 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:27 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:27 --> Model Class Initialized
INFO - 2023-07-24 04:29:27 --> Final output sent to browser
DEBUG - 2023-07-24 04:29:27 --> Total execution time: 0.0180
ERROR - 2023-07-24 04:29:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:29:28 --> Config Class Initialized
INFO - 2023-07-24 04:29:28 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:29:28 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:29:28 --> Utf8 Class Initialized
INFO - 2023-07-24 04:29:28 --> URI Class Initialized
INFO - 2023-07-24 04:29:28 --> Router Class Initialized
INFO - 2023-07-24 04:29:28 --> Output Class Initialized
INFO - 2023-07-24 04:29:28 --> Security Class Initialized
DEBUG - 2023-07-24 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:29:28 --> Input Class Initialized
INFO - 2023-07-24 04:29:28 --> Language Class Initialized
INFO - 2023-07-24 04:29:28 --> Loader Class Initialized
INFO - 2023-07-24 04:29:28 --> Helper loaded: url_helper
INFO - 2023-07-24 04:29:28 --> Helper loaded: file_helper
INFO - 2023-07-24 04:29:28 --> Helper loaded: html_helper
INFO - 2023-07-24 04:29:28 --> Helper loaded: text_helper
INFO - 2023-07-24 04:29:28 --> Helper loaded: form_helper
INFO - 2023-07-24 04:29:28 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:29:28 --> Helper loaded: security_helper
INFO - 2023-07-24 04:29:28 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:29:28 --> Database Driver Class Initialized
INFO - 2023-07-24 04:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:29:28 --> Parser Class Initialized
INFO - 2023-07-24 04:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:29:28 --> Pagination Class Initialized
INFO - 2023-07-24 04:29:28 --> Form Validation Class Initialized
INFO - 2023-07-24 04:29:28 --> Controller Class Initialized
INFO - 2023-07-24 04:29:28 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:29:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:28 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:28 --> Model Class Initialized
INFO - 2023-07-24 04:29:28 --> Final output sent to browser
DEBUG - 2023-07-24 04:29:28 --> Total execution time: 0.0197
ERROR - 2023-07-24 04:29:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:29:29 --> Config Class Initialized
INFO - 2023-07-24 04:29:29 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:29:29 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:29:29 --> Utf8 Class Initialized
INFO - 2023-07-24 04:29:29 --> URI Class Initialized
INFO - 2023-07-24 04:29:29 --> Router Class Initialized
INFO - 2023-07-24 04:29:29 --> Output Class Initialized
INFO - 2023-07-24 04:29:29 --> Security Class Initialized
DEBUG - 2023-07-24 04:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:29:29 --> Input Class Initialized
INFO - 2023-07-24 04:29:29 --> Language Class Initialized
INFO - 2023-07-24 04:29:29 --> Loader Class Initialized
INFO - 2023-07-24 04:29:29 --> Helper loaded: url_helper
INFO - 2023-07-24 04:29:29 --> Helper loaded: file_helper
INFO - 2023-07-24 04:29:29 --> Helper loaded: html_helper
INFO - 2023-07-24 04:29:29 --> Helper loaded: text_helper
INFO - 2023-07-24 04:29:29 --> Helper loaded: form_helper
INFO - 2023-07-24 04:29:29 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:29:29 --> Helper loaded: security_helper
INFO - 2023-07-24 04:29:29 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:29:29 --> Database Driver Class Initialized
INFO - 2023-07-24 04:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:29:29 --> Parser Class Initialized
INFO - 2023-07-24 04:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:29:29 --> Pagination Class Initialized
INFO - 2023-07-24 04:29:29 --> Form Validation Class Initialized
INFO - 2023-07-24 04:29:29 --> Controller Class Initialized
INFO - 2023-07-24 04:29:29 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:29 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:29 --> Model Class Initialized
INFO - 2023-07-24 04:29:29 --> Final output sent to browser
DEBUG - 2023-07-24 04:29:29 --> Total execution time: 0.0523
ERROR - 2023-07-24 04:29:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:29:35 --> Config Class Initialized
INFO - 2023-07-24 04:29:35 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:29:35 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:29:35 --> Utf8 Class Initialized
INFO - 2023-07-24 04:29:35 --> URI Class Initialized
INFO - 2023-07-24 04:29:35 --> Router Class Initialized
INFO - 2023-07-24 04:29:35 --> Output Class Initialized
INFO - 2023-07-24 04:29:35 --> Security Class Initialized
DEBUG - 2023-07-24 04:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:29:35 --> Input Class Initialized
INFO - 2023-07-24 04:29:35 --> Language Class Initialized
INFO - 2023-07-24 04:29:35 --> Loader Class Initialized
INFO - 2023-07-24 04:29:35 --> Helper loaded: url_helper
INFO - 2023-07-24 04:29:35 --> Helper loaded: file_helper
INFO - 2023-07-24 04:29:35 --> Helper loaded: html_helper
INFO - 2023-07-24 04:29:35 --> Helper loaded: text_helper
INFO - 2023-07-24 04:29:35 --> Helper loaded: form_helper
INFO - 2023-07-24 04:29:35 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:29:35 --> Helper loaded: security_helper
INFO - 2023-07-24 04:29:35 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:29:35 --> Database Driver Class Initialized
INFO - 2023-07-24 04:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:29:36 --> Parser Class Initialized
INFO - 2023-07-24 04:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:29:36 --> Pagination Class Initialized
INFO - 2023-07-24 04:29:36 --> Form Validation Class Initialized
INFO - 2023-07-24 04:29:36 --> Controller Class Initialized
INFO - 2023-07-24 04:29:36 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:29:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:36 --> Model Class Initialized
INFO - 2023-07-24 04:29:36 --> Model Class Initialized
INFO - 2023-07-24 04:29:36 --> Final output sent to browser
DEBUG - 2023-07-24 04:29:36 --> Total execution time: 0.0965
ERROR - 2023-07-24 04:29:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:29:38 --> Config Class Initialized
INFO - 2023-07-24 04:29:38 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:29:38 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:29:38 --> Utf8 Class Initialized
INFO - 2023-07-24 04:29:38 --> URI Class Initialized
INFO - 2023-07-24 04:29:38 --> Router Class Initialized
INFO - 2023-07-24 04:29:38 --> Output Class Initialized
INFO - 2023-07-24 04:29:38 --> Security Class Initialized
DEBUG - 2023-07-24 04:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:29:38 --> Input Class Initialized
INFO - 2023-07-24 04:29:38 --> Language Class Initialized
INFO - 2023-07-24 04:29:38 --> Loader Class Initialized
INFO - 2023-07-24 04:29:38 --> Helper loaded: url_helper
INFO - 2023-07-24 04:29:38 --> Helper loaded: file_helper
INFO - 2023-07-24 04:29:38 --> Helper loaded: html_helper
INFO - 2023-07-24 04:29:38 --> Helper loaded: text_helper
INFO - 2023-07-24 04:29:38 --> Helper loaded: form_helper
INFO - 2023-07-24 04:29:38 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:29:38 --> Helper loaded: security_helper
INFO - 2023-07-24 04:29:38 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:29:38 --> Database Driver Class Initialized
INFO - 2023-07-24 04:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:29:39 --> Parser Class Initialized
INFO - 2023-07-24 04:29:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:29:39 --> Pagination Class Initialized
INFO - 2023-07-24 04:29:39 --> Form Validation Class Initialized
INFO - 2023-07-24 04:29:39 --> Controller Class Initialized
INFO - 2023-07-24 04:29:39 --> Model Class Initialized
DEBUG - 2023-07-24 04:29:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:29:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:29:39 --> Model Class Initialized
INFO - 2023-07-24 04:29:39 --> Final output sent to browser
DEBUG - 2023-07-24 04:29:39 --> Total execution time: 0.0166
ERROR - 2023-07-24 04:32:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:32:57 --> Config Class Initialized
INFO - 2023-07-24 04:32:57 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:32:57 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:32:57 --> Utf8 Class Initialized
INFO - 2023-07-24 04:32:57 --> URI Class Initialized
INFO - 2023-07-24 04:32:57 --> Router Class Initialized
INFO - 2023-07-24 04:32:57 --> Output Class Initialized
INFO - 2023-07-24 04:32:57 --> Security Class Initialized
DEBUG - 2023-07-24 04:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:32:57 --> Input Class Initialized
INFO - 2023-07-24 04:32:57 --> Language Class Initialized
INFO - 2023-07-24 04:32:57 --> Loader Class Initialized
INFO - 2023-07-24 04:32:57 --> Helper loaded: url_helper
INFO - 2023-07-24 04:32:57 --> Helper loaded: file_helper
INFO - 2023-07-24 04:32:57 --> Helper loaded: html_helper
INFO - 2023-07-24 04:32:57 --> Helper loaded: text_helper
INFO - 2023-07-24 04:32:57 --> Helper loaded: form_helper
INFO - 2023-07-24 04:32:57 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:32:57 --> Helper loaded: security_helper
INFO - 2023-07-24 04:32:57 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:32:57 --> Database Driver Class Initialized
INFO - 2023-07-24 04:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:32:57 --> Parser Class Initialized
INFO - 2023-07-24 04:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:32:57 --> Pagination Class Initialized
INFO - 2023-07-24 04:32:57 --> Form Validation Class Initialized
INFO - 2023-07-24 04:32:57 --> Controller Class Initialized
INFO - 2023-07-24 04:32:57 --> Model Class Initialized
DEBUG - 2023-07-24 04:32:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:32:57 --> Model Class Initialized
DEBUG - 2023-07-24 04:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:32:57 --> Model Class Initialized
INFO - 2023-07-24 04:32:57 --> Email Class Initialized
DEBUG - 2023-07-24 04:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:32:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-07-24 04:32:57 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-07-24 04:32:57 --> Language file loaded: language/english/email_lang.php
INFO - 2023-07-24 04:32:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-07-24 04:32:58 --> Final output sent to browser
DEBUG - 2023-07-24 04:32:58 --> Total execution time: 0.4935
ERROR - 2023-07-24 04:32:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:32:58 --> Config Class Initialized
INFO - 2023-07-24 04:32:58 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:32:58 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:32:58 --> Utf8 Class Initialized
INFO - 2023-07-24 04:32:58 --> URI Class Initialized
DEBUG - 2023-07-24 04:32:58 --> No URI present. Default controller set.
INFO - 2023-07-24 04:32:58 --> Router Class Initialized
INFO - 2023-07-24 04:32:58 --> Output Class Initialized
INFO - 2023-07-24 04:32:58 --> Security Class Initialized
DEBUG - 2023-07-24 04:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:32:58 --> Input Class Initialized
INFO - 2023-07-24 04:32:58 --> Language Class Initialized
INFO - 2023-07-24 04:32:58 --> Loader Class Initialized
INFO - 2023-07-24 04:32:58 --> Helper loaded: url_helper
INFO - 2023-07-24 04:32:58 --> Helper loaded: file_helper
INFO - 2023-07-24 04:32:58 --> Helper loaded: html_helper
INFO - 2023-07-24 04:32:58 --> Helper loaded: text_helper
INFO - 2023-07-24 04:32:58 --> Helper loaded: form_helper
INFO - 2023-07-24 04:32:58 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:32:58 --> Helper loaded: security_helper
INFO - 2023-07-24 04:32:58 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:32:58 --> Database Driver Class Initialized
INFO - 2023-07-24 04:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:32:58 --> Parser Class Initialized
INFO - 2023-07-24 04:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:32:58 --> Pagination Class Initialized
INFO - 2023-07-24 04:32:59 --> Form Validation Class Initialized
INFO - 2023-07-24 04:32:59 --> Controller Class Initialized
INFO - 2023-07-24 04:32:59 --> Model Class Initialized
DEBUG - 2023-07-24 04:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:32:59 --> Model Class Initialized
DEBUG - 2023-07-24 04:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:32:59 --> Model Class Initialized
INFO - 2023-07-24 04:32:59 --> Model Class Initialized
INFO - 2023-07-24 04:32:59 --> Model Class Initialized
INFO - 2023-07-24 04:32:59 --> Model Class Initialized
DEBUG - 2023-07-24 04:32:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:32:59 --> Model Class Initialized
INFO - 2023-07-24 04:32:59 --> Model Class Initialized
INFO - 2023-07-24 04:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 04:32:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 04:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 04:32:59 --> Model Class Initialized
INFO - 2023-07-24 04:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 04:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 04:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 04:32:59 --> Final output sent to browser
DEBUG - 2023-07-24 04:32:59 --> Total execution time: 0.0863
ERROR - 2023-07-24 04:33:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:33:34 --> Config Class Initialized
INFO - 2023-07-24 04:33:34 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:33:34 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:33:34 --> Utf8 Class Initialized
INFO - 2023-07-24 04:33:34 --> URI Class Initialized
INFO - 2023-07-24 04:33:34 --> Router Class Initialized
INFO - 2023-07-24 04:33:34 --> Output Class Initialized
INFO - 2023-07-24 04:33:34 --> Security Class Initialized
DEBUG - 2023-07-24 04:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:33:34 --> Input Class Initialized
INFO - 2023-07-24 04:33:34 --> Language Class Initialized
INFO - 2023-07-24 04:33:34 --> Loader Class Initialized
INFO - 2023-07-24 04:33:34 --> Helper loaded: url_helper
INFO - 2023-07-24 04:33:34 --> Helper loaded: file_helper
INFO - 2023-07-24 04:33:34 --> Helper loaded: html_helper
INFO - 2023-07-24 04:33:34 --> Helper loaded: text_helper
INFO - 2023-07-24 04:33:34 --> Helper loaded: form_helper
INFO - 2023-07-24 04:33:34 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:33:34 --> Helper loaded: security_helper
INFO - 2023-07-24 04:33:34 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:33:34 --> Database Driver Class Initialized
INFO - 2023-07-24 04:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:33:34 --> Parser Class Initialized
INFO - 2023-07-24 04:33:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:33:34 --> Pagination Class Initialized
INFO - 2023-07-24 04:33:34 --> Form Validation Class Initialized
INFO - 2023-07-24 04:33:34 --> Controller Class Initialized
DEBUG - 2023-07-24 04:33:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:33:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:34 --> Model Class Initialized
DEBUG - 2023-07-24 04:33:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:34 --> Model Class Initialized
DEBUG - 2023-07-24 04:33:34 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:34 --> Model Class Initialized
INFO - 2023-07-24 04:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-24 04:33:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 04:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 04:33:34 --> Model Class Initialized
INFO - 2023-07-24 04:33:34 --> Model Class Initialized
INFO - 2023-07-24 04:33:34 --> Model Class Initialized
INFO - 2023-07-24 04:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 04:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 04:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 04:33:34 --> Final output sent to browser
DEBUG - 2023-07-24 04:33:34 --> Total execution time: 0.0725
ERROR - 2023-07-24 04:33:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:33:37 --> Config Class Initialized
INFO - 2023-07-24 04:33:37 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:33:37 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:33:37 --> Utf8 Class Initialized
INFO - 2023-07-24 04:33:37 --> URI Class Initialized
INFO - 2023-07-24 04:33:37 --> Router Class Initialized
INFO - 2023-07-24 04:33:37 --> Output Class Initialized
INFO - 2023-07-24 04:33:37 --> Security Class Initialized
DEBUG - 2023-07-24 04:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:33:37 --> Input Class Initialized
INFO - 2023-07-24 04:33:37 --> Language Class Initialized
INFO - 2023-07-24 04:33:37 --> Loader Class Initialized
INFO - 2023-07-24 04:33:37 --> Helper loaded: url_helper
INFO - 2023-07-24 04:33:37 --> Helper loaded: file_helper
INFO - 2023-07-24 04:33:37 --> Helper loaded: html_helper
INFO - 2023-07-24 04:33:37 --> Helper loaded: text_helper
INFO - 2023-07-24 04:33:37 --> Helper loaded: form_helper
INFO - 2023-07-24 04:33:37 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:33:37 --> Helper loaded: security_helper
INFO - 2023-07-24 04:33:37 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:33:37 --> Database Driver Class Initialized
INFO - 2023-07-24 04:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:33:37 --> Parser Class Initialized
INFO - 2023-07-24 04:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:33:37 --> Pagination Class Initialized
INFO - 2023-07-24 04:33:37 --> Form Validation Class Initialized
INFO - 2023-07-24 04:33:37 --> Controller Class Initialized
DEBUG - 2023-07-24 04:33:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:37 --> Model Class Initialized
DEBUG - 2023-07-24 04:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:37 --> Model Class Initialized
INFO - 2023-07-24 04:33:37 --> Final output sent to browser
DEBUG - 2023-07-24 04:33:37 --> Total execution time: 0.0223
ERROR - 2023-07-24 04:33:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:33:50 --> Config Class Initialized
INFO - 2023-07-24 04:33:50 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:33:50 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:33:50 --> Utf8 Class Initialized
INFO - 2023-07-24 04:33:50 --> URI Class Initialized
INFO - 2023-07-24 04:33:50 --> Router Class Initialized
INFO - 2023-07-24 04:33:50 --> Output Class Initialized
INFO - 2023-07-24 04:33:50 --> Security Class Initialized
DEBUG - 2023-07-24 04:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:33:50 --> Input Class Initialized
INFO - 2023-07-24 04:33:50 --> Language Class Initialized
INFO - 2023-07-24 04:33:50 --> Loader Class Initialized
INFO - 2023-07-24 04:33:50 --> Helper loaded: url_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: file_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: html_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: text_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: form_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: security_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:33:50 --> Database Driver Class Initialized
INFO - 2023-07-24 04:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:33:50 --> Parser Class Initialized
INFO - 2023-07-24 04:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:33:50 --> Pagination Class Initialized
INFO - 2023-07-24 04:33:50 --> Form Validation Class Initialized
INFO - 2023-07-24 04:33:50 --> Controller Class Initialized
DEBUG - 2023-07-24 04:33:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:33:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
DEBUG - 2023-07-24 04:33:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-24 04:33:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 04:33:50 --> Final output sent to browser
DEBUG - 2023-07-24 04:33:50 --> Total execution time: 0.0806
ERROR - 2023-07-24 04:33:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:33:50 --> Config Class Initialized
INFO - 2023-07-24 04:33:50 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:33:50 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:33:50 --> Utf8 Class Initialized
INFO - 2023-07-24 04:33:50 --> URI Class Initialized
INFO - 2023-07-24 04:33:50 --> Router Class Initialized
INFO - 2023-07-24 04:33:50 --> Output Class Initialized
INFO - 2023-07-24 04:33:50 --> Security Class Initialized
DEBUG - 2023-07-24 04:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:33:50 --> Input Class Initialized
INFO - 2023-07-24 04:33:50 --> Language Class Initialized
INFO - 2023-07-24 04:33:50 --> Loader Class Initialized
INFO - 2023-07-24 04:33:50 --> Helper loaded: url_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: file_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: html_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: text_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: form_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: security_helper
INFO - 2023-07-24 04:33:50 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:33:50 --> Database Driver Class Initialized
INFO - 2023-07-24 04:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:33:50 --> Parser Class Initialized
INFO - 2023-07-24 04:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:33:50 --> Pagination Class Initialized
INFO - 2023-07-24 04:33:50 --> Form Validation Class Initialized
INFO - 2023-07-24 04:33:50 --> Controller Class Initialized
DEBUG - 2023-07-24 04:33:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:33:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
DEBUG - 2023-07-24 04:33:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-24 04:33:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> Model Class Initialized
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 04:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 04:33:50 --> Final output sent to browser
DEBUG - 2023-07-24 04:33:50 --> Total execution time: 0.0703
ERROR - 2023-07-24 04:34:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:34:09 --> Config Class Initialized
INFO - 2023-07-24 04:34:09 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:34:09 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:34:09 --> Utf8 Class Initialized
INFO - 2023-07-24 04:34:09 --> URI Class Initialized
INFO - 2023-07-24 04:34:09 --> Router Class Initialized
INFO - 2023-07-24 04:34:09 --> Output Class Initialized
INFO - 2023-07-24 04:34:09 --> Security Class Initialized
DEBUG - 2023-07-24 04:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:34:09 --> Input Class Initialized
INFO - 2023-07-24 04:34:09 --> Language Class Initialized
INFO - 2023-07-24 04:34:09 --> Loader Class Initialized
INFO - 2023-07-24 04:34:09 --> Helper loaded: url_helper
INFO - 2023-07-24 04:34:09 --> Helper loaded: file_helper
INFO - 2023-07-24 04:34:09 --> Helper loaded: html_helper
INFO - 2023-07-24 04:34:09 --> Helper loaded: text_helper
INFO - 2023-07-24 04:34:09 --> Helper loaded: form_helper
INFO - 2023-07-24 04:34:09 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:34:09 --> Helper loaded: security_helper
INFO - 2023-07-24 04:34:09 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:34:09 --> Database Driver Class Initialized
INFO - 2023-07-24 04:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:34:09 --> Parser Class Initialized
INFO - 2023-07-24 04:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:34:09 --> Pagination Class Initialized
INFO - 2023-07-24 04:34:09 --> Form Validation Class Initialized
INFO - 2023-07-24 04:34:09 --> Controller Class Initialized
DEBUG - 2023-07-24 04:34:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:34:09 --> Model Class Initialized
DEBUG - 2023-07-24 04:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:34:09 --> Model Class Initialized
DEBUG - 2023-07-24 04:34:09 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:34:09 --> Model Class Initialized
INFO - 2023-07-24 04:34:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-24 04:34:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:34:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 04:34:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 04:34:09 --> Model Class Initialized
INFO - 2023-07-24 04:34:09 --> Model Class Initialized
INFO - 2023-07-24 04:34:09 --> Model Class Initialized
INFO - 2023-07-24 04:34:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 04:34:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 04:34:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 04:34:09 --> Final output sent to browser
DEBUG - 2023-07-24 04:34:09 --> Total execution time: 0.0776
ERROR - 2023-07-24 04:34:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 04:34:10 --> Config Class Initialized
INFO - 2023-07-24 04:34:10 --> Hooks Class Initialized
DEBUG - 2023-07-24 04:34:10 --> UTF-8 Support Enabled
INFO - 2023-07-24 04:34:10 --> Utf8 Class Initialized
INFO - 2023-07-24 04:34:10 --> URI Class Initialized
INFO - 2023-07-24 04:34:10 --> Router Class Initialized
INFO - 2023-07-24 04:34:10 --> Output Class Initialized
INFO - 2023-07-24 04:34:10 --> Security Class Initialized
DEBUG - 2023-07-24 04:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 04:34:10 --> Input Class Initialized
INFO - 2023-07-24 04:34:10 --> Language Class Initialized
INFO - 2023-07-24 04:34:10 --> Loader Class Initialized
INFO - 2023-07-24 04:34:10 --> Helper loaded: url_helper
INFO - 2023-07-24 04:34:10 --> Helper loaded: file_helper
INFO - 2023-07-24 04:34:10 --> Helper loaded: html_helper
INFO - 2023-07-24 04:34:10 --> Helper loaded: text_helper
INFO - 2023-07-24 04:34:10 --> Helper loaded: form_helper
INFO - 2023-07-24 04:34:10 --> Helper loaded: lang_helper
INFO - 2023-07-24 04:34:10 --> Helper loaded: security_helper
INFO - 2023-07-24 04:34:10 --> Helper loaded: cookie_helper
INFO - 2023-07-24 04:34:10 --> Database Driver Class Initialized
INFO - 2023-07-24 04:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 04:34:10 --> Parser Class Initialized
INFO - 2023-07-24 04:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 04:34:10 --> Pagination Class Initialized
INFO - 2023-07-24 04:34:10 --> Form Validation Class Initialized
INFO - 2023-07-24 04:34:10 --> Controller Class Initialized
DEBUG - 2023-07-24 04:34:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 04:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:34:10 --> Model Class Initialized
DEBUG - 2023-07-24 04:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 04:34:10 --> Model Class Initialized
INFO - 2023-07-24 04:34:10 --> Final output sent to browser
DEBUG - 2023-07-24 04:34:10 --> Total execution time: 0.0203
ERROR - 2023-07-24 07:16:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 07:16:22 --> Config Class Initialized
INFO - 2023-07-24 07:16:22 --> Hooks Class Initialized
DEBUG - 2023-07-24 07:16:22 --> UTF-8 Support Enabled
INFO - 2023-07-24 07:16:22 --> Utf8 Class Initialized
INFO - 2023-07-24 07:16:22 --> URI Class Initialized
DEBUG - 2023-07-24 07:16:22 --> No URI present. Default controller set.
INFO - 2023-07-24 07:16:22 --> Router Class Initialized
INFO - 2023-07-24 07:16:22 --> Output Class Initialized
INFO - 2023-07-24 07:16:22 --> Security Class Initialized
DEBUG - 2023-07-24 07:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 07:16:22 --> Input Class Initialized
INFO - 2023-07-24 07:16:22 --> Language Class Initialized
INFO - 2023-07-24 07:16:22 --> Loader Class Initialized
INFO - 2023-07-24 07:16:22 --> Helper loaded: url_helper
INFO - 2023-07-24 07:16:22 --> Helper loaded: file_helper
INFO - 2023-07-24 07:16:22 --> Helper loaded: html_helper
INFO - 2023-07-24 07:16:22 --> Helper loaded: text_helper
INFO - 2023-07-24 07:16:22 --> Helper loaded: form_helper
INFO - 2023-07-24 07:16:22 --> Helper loaded: lang_helper
INFO - 2023-07-24 07:16:22 --> Helper loaded: security_helper
INFO - 2023-07-24 07:16:22 --> Helper loaded: cookie_helper
INFO - 2023-07-24 07:16:22 --> Database Driver Class Initialized
INFO - 2023-07-24 07:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 07:16:22 --> Parser Class Initialized
INFO - 2023-07-24 07:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 07:16:22 --> Pagination Class Initialized
INFO - 2023-07-24 07:16:22 --> Form Validation Class Initialized
INFO - 2023-07-24 07:16:22 --> Controller Class Initialized
INFO - 2023-07-24 07:16:22 --> Model Class Initialized
DEBUG - 2023-07-24 07:16:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-24 07:19:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 07:19:35 --> Config Class Initialized
INFO - 2023-07-24 07:19:35 --> Hooks Class Initialized
DEBUG - 2023-07-24 07:19:35 --> UTF-8 Support Enabled
INFO - 2023-07-24 07:19:35 --> Utf8 Class Initialized
INFO - 2023-07-24 07:19:35 --> URI Class Initialized
DEBUG - 2023-07-24 07:19:35 --> No URI present. Default controller set.
INFO - 2023-07-24 07:19:35 --> Router Class Initialized
INFO - 2023-07-24 07:19:35 --> Output Class Initialized
INFO - 2023-07-24 07:19:35 --> Security Class Initialized
DEBUG - 2023-07-24 07:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 07:19:35 --> Input Class Initialized
INFO - 2023-07-24 07:19:35 --> Language Class Initialized
INFO - 2023-07-24 07:19:35 --> Loader Class Initialized
INFO - 2023-07-24 07:19:35 --> Helper loaded: url_helper
INFO - 2023-07-24 07:19:35 --> Helper loaded: file_helper
INFO - 2023-07-24 07:19:35 --> Helper loaded: html_helper
INFO - 2023-07-24 07:19:35 --> Helper loaded: text_helper
INFO - 2023-07-24 07:19:35 --> Helper loaded: form_helper
INFO - 2023-07-24 07:19:35 --> Helper loaded: lang_helper
INFO - 2023-07-24 07:19:35 --> Helper loaded: security_helper
INFO - 2023-07-24 07:19:35 --> Helper loaded: cookie_helper
INFO - 2023-07-24 07:19:35 --> Database Driver Class Initialized
INFO - 2023-07-24 07:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 07:19:35 --> Parser Class Initialized
INFO - 2023-07-24 07:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 07:19:35 --> Pagination Class Initialized
INFO - 2023-07-24 07:19:35 --> Form Validation Class Initialized
INFO - 2023-07-24 07:19:35 --> Controller Class Initialized
INFO - 2023-07-24 07:19:35 --> Model Class Initialized
DEBUG - 2023-07-24 07:19:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-24 08:37:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 08:37:15 --> Config Class Initialized
INFO - 2023-07-24 08:37:15 --> Hooks Class Initialized
DEBUG - 2023-07-24 08:37:15 --> UTF-8 Support Enabled
INFO - 2023-07-24 08:37:15 --> Utf8 Class Initialized
INFO - 2023-07-24 08:37:15 --> URI Class Initialized
DEBUG - 2023-07-24 08:37:15 --> No URI present. Default controller set.
INFO - 2023-07-24 08:37:15 --> Router Class Initialized
INFO - 2023-07-24 08:37:15 --> Output Class Initialized
INFO - 2023-07-24 08:37:15 --> Security Class Initialized
DEBUG - 2023-07-24 08:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 08:37:15 --> Input Class Initialized
INFO - 2023-07-24 08:37:15 --> Language Class Initialized
INFO - 2023-07-24 08:37:15 --> Loader Class Initialized
INFO - 2023-07-24 08:37:15 --> Helper loaded: url_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: file_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: html_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: text_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: form_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: lang_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: security_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: cookie_helper
INFO - 2023-07-24 08:37:15 --> Database Driver Class Initialized
INFO - 2023-07-24 08:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 08:37:15 --> Parser Class Initialized
INFO - 2023-07-24 08:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 08:37:15 --> Pagination Class Initialized
INFO - 2023-07-24 08:37:15 --> Form Validation Class Initialized
INFO - 2023-07-24 08:37:15 --> Controller Class Initialized
INFO - 2023-07-24 08:37:15 --> Model Class Initialized
DEBUG - 2023-07-24 08:37:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-24 08:37:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 08:37:15 --> Config Class Initialized
INFO - 2023-07-24 08:37:15 --> Hooks Class Initialized
DEBUG - 2023-07-24 08:37:15 --> UTF-8 Support Enabled
INFO - 2023-07-24 08:37:15 --> Utf8 Class Initialized
INFO - 2023-07-24 08:37:15 --> URI Class Initialized
INFO - 2023-07-24 08:37:15 --> Router Class Initialized
INFO - 2023-07-24 08:37:15 --> Output Class Initialized
INFO - 2023-07-24 08:37:15 --> Security Class Initialized
DEBUG - 2023-07-24 08:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 08:37:15 --> Input Class Initialized
INFO - 2023-07-24 08:37:15 --> Language Class Initialized
INFO - 2023-07-24 08:37:15 --> Loader Class Initialized
INFO - 2023-07-24 08:37:15 --> Helper loaded: url_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: file_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: html_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: text_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: form_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: lang_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: security_helper
INFO - 2023-07-24 08:37:15 --> Helper loaded: cookie_helper
INFO - 2023-07-24 08:37:15 --> Database Driver Class Initialized
INFO - 2023-07-24 08:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 08:37:15 --> Parser Class Initialized
INFO - 2023-07-24 08:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 08:37:15 --> Pagination Class Initialized
INFO - 2023-07-24 08:37:15 --> Form Validation Class Initialized
INFO - 2023-07-24 08:37:15 --> Controller Class Initialized
INFO - 2023-07-24 08:37:15 --> Model Class Initialized
DEBUG - 2023-07-24 08:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-24 08:37:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 08:37:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 08:37:15 --> Model Class Initialized
INFO - 2023-07-24 08:37:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 08:37:15 --> Final output sent to browser
DEBUG - 2023-07-24 08:37:15 --> Total execution time: 0.0303
ERROR - 2023-07-24 08:37:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 08:37:39 --> Config Class Initialized
INFO - 2023-07-24 08:37:39 --> Hooks Class Initialized
DEBUG - 2023-07-24 08:37:39 --> UTF-8 Support Enabled
INFO - 2023-07-24 08:37:39 --> Utf8 Class Initialized
INFO - 2023-07-24 08:37:39 --> URI Class Initialized
INFO - 2023-07-24 08:37:39 --> Router Class Initialized
INFO - 2023-07-24 08:37:39 --> Output Class Initialized
INFO - 2023-07-24 08:37:39 --> Security Class Initialized
DEBUG - 2023-07-24 08:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 08:37:39 --> Input Class Initialized
INFO - 2023-07-24 08:37:39 --> Language Class Initialized
INFO - 2023-07-24 08:37:39 --> Loader Class Initialized
INFO - 2023-07-24 08:37:39 --> Helper loaded: url_helper
INFO - 2023-07-24 08:37:39 --> Helper loaded: file_helper
INFO - 2023-07-24 08:37:39 --> Helper loaded: html_helper
INFO - 2023-07-24 08:37:39 --> Helper loaded: text_helper
INFO - 2023-07-24 08:37:39 --> Helper loaded: form_helper
INFO - 2023-07-24 08:37:39 --> Helper loaded: lang_helper
INFO - 2023-07-24 08:37:39 --> Helper loaded: security_helper
INFO - 2023-07-24 08:37:39 --> Helper loaded: cookie_helper
INFO - 2023-07-24 08:37:39 --> Database Driver Class Initialized
INFO - 2023-07-24 08:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 08:37:39 --> Parser Class Initialized
INFO - 2023-07-24 08:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 08:37:39 --> Pagination Class Initialized
INFO - 2023-07-24 08:37:39 --> Form Validation Class Initialized
INFO - 2023-07-24 08:37:39 --> Controller Class Initialized
INFO - 2023-07-24 08:37:39 --> Model Class Initialized
DEBUG - 2023-07-24 08:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:39 --> Model Class Initialized
INFO - 2023-07-24 08:37:39 --> Final output sent to browser
DEBUG - 2023-07-24 08:37:39 --> Total execution time: 0.0191
ERROR - 2023-07-24 08:37:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 08:37:40 --> Config Class Initialized
INFO - 2023-07-24 08:37:40 --> Hooks Class Initialized
DEBUG - 2023-07-24 08:37:40 --> UTF-8 Support Enabled
INFO - 2023-07-24 08:37:40 --> Utf8 Class Initialized
INFO - 2023-07-24 08:37:40 --> URI Class Initialized
DEBUG - 2023-07-24 08:37:40 --> No URI present. Default controller set.
INFO - 2023-07-24 08:37:40 --> Router Class Initialized
INFO - 2023-07-24 08:37:40 --> Output Class Initialized
INFO - 2023-07-24 08:37:40 --> Security Class Initialized
DEBUG - 2023-07-24 08:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 08:37:40 --> Input Class Initialized
INFO - 2023-07-24 08:37:40 --> Language Class Initialized
INFO - 2023-07-24 08:37:40 --> Loader Class Initialized
INFO - 2023-07-24 08:37:40 --> Helper loaded: url_helper
INFO - 2023-07-24 08:37:40 --> Helper loaded: file_helper
INFO - 2023-07-24 08:37:40 --> Helper loaded: html_helper
INFO - 2023-07-24 08:37:40 --> Helper loaded: text_helper
INFO - 2023-07-24 08:37:40 --> Helper loaded: form_helper
INFO - 2023-07-24 08:37:40 --> Helper loaded: lang_helper
INFO - 2023-07-24 08:37:40 --> Helper loaded: security_helper
INFO - 2023-07-24 08:37:40 --> Helper loaded: cookie_helper
INFO - 2023-07-24 08:37:40 --> Database Driver Class Initialized
INFO - 2023-07-24 08:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 08:37:40 --> Parser Class Initialized
INFO - 2023-07-24 08:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 08:37:40 --> Pagination Class Initialized
INFO - 2023-07-24 08:37:40 --> Form Validation Class Initialized
INFO - 2023-07-24 08:37:40 --> Controller Class Initialized
INFO - 2023-07-24 08:37:40 --> Model Class Initialized
DEBUG - 2023-07-24 08:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:40 --> Model Class Initialized
DEBUG - 2023-07-24 08:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:40 --> Model Class Initialized
INFO - 2023-07-24 08:37:40 --> Model Class Initialized
INFO - 2023-07-24 08:37:40 --> Model Class Initialized
INFO - 2023-07-24 08:37:40 --> Model Class Initialized
DEBUG - 2023-07-24 08:37:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 08:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:40 --> Model Class Initialized
INFO - 2023-07-24 08:37:40 --> Model Class Initialized
INFO - 2023-07-24 08:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 08:37:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 08:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 08:37:40 --> Model Class Initialized
INFO - 2023-07-24 08:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 08:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 08:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 08:37:40 --> Final output sent to browser
DEBUG - 2023-07-24 08:37:40 --> Total execution time: 0.0837
ERROR - 2023-07-24 08:37:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 08:37:48 --> Config Class Initialized
INFO - 2023-07-24 08:37:48 --> Hooks Class Initialized
DEBUG - 2023-07-24 08:37:48 --> UTF-8 Support Enabled
INFO - 2023-07-24 08:37:48 --> Utf8 Class Initialized
INFO - 2023-07-24 08:37:48 --> URI Class Initialized
INFO - 2023-07-24 08:37:48 --> Router Class Initialized
INFO - 2023-07-24 08:37:48 --> Output Class Initialized
INFO - 2023-07-24 08:37:48 --> Security Class Initialized
DEBUG - 2023-07-24 08:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 08:37:48 --> Input Class Initialized
INFO - 2023-07-24 08:37:48 --> Language Class Initialized
INFO - 2023-07-24 08:37:48 --> Loader Class Initialized
INFO - 2023-07-24 08:37:48 --> Helper loaded: url_helper
INFO - 2023-07-24 08:37:48 --> Helper loaded: file_helper
INFO - 2023-07-24 08:37:48 --> Helper loaded: html_helper
INFO - 2023-07-24 08:37:48 --> Helper loaded: text_helper
INFO - 2023-07-24 08:37:48 --> Helper loaded: form_helper
INFO - 2023-07-24 08:37:48 --> Helper loaded: lang_helper
INFO - 2023-07-24 08:37:48 --> Helper loaded: security_helper
INFO - 2023-07-24 08:37:48 --> Helper loaded: cookie_helper
INFO - 2023-07-24 08:37:48 --> Database Driver Class Initialized
INFO - 2023-07-24 08:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 08:37:48 --> Parser Class Initialized
INFO - 2023-07-24 08:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 08:37:48 --> Pagination Class Initialized
INFO - 2023-07-24 08:37:48 --> Form Validation Class Initialized
INFO - 2023-07-24 08:37:48 --> Controller Class Initialized
INFO - 2023-07-24 08:37:48 --> Model Class Initialized
DEBUG - 2023-07-24 08:37:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 08:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:48 --> Model Class Initialized
INFO - 2023-07-24 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-24 08:37:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 08:37:48 --> Model Class Initialized
INFO - 2023-07-24 08:37:48 --> Model Class Initialized
INFO - 2023-07-24 08:37:48 --> Model Class Initialized
INFO - 2023-07-24 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 08:37:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 08:37:48 --> Final output sent to browser
DEBUG - 2023-07-24 08:37:48 --> Total execution time: 0.0645
ERROR - 2023-07-24 08:37:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 08:37:49 --> Config Class Initialized
INFO - 2023-07-24 08:37:49 --> Hooks Class Initialized
DEBUG - 2023-07-24 08:37:49 --> UTF-8 Support Enabled
INFO - 2023-07-24 08:37:49 --> Utf8 Class Initialized
INFO - 2023-07-24 08:37:49 --> URI Class Initialized
INFO - 2023-07-24 08:37:49 --> Router Class Initialized
INFO - 2023-07-24 08:37:49 --> Output Class Initialized
INFO - 2023-07-24 08:37:49 --> Security Class Initialized
DEBUG - 2023-07-24 08:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 08:37:49 --> Input Class Initialized
INFO - 2023-07-24 08:37:49 --> Language Class Initialized
INFO - 2023-07-24 08:37:49 --> Loader Class Initialized
INFO - 2023-07-24 08:37:49 --> Helper loaded: url_helper
INFO - 2023-07-24 08:37:49 --> Helper loaded: file_helper
INFO - 2023-07-24 08:37:49 --> Helper loaded: html_helper
INFO - 2023-07-24 08:37:49 --> Helper loaded: text_helper
INFO - 2023-07-24 08:37:49 --> Helper loaded: form_helper
INFO - 2023-07-24 08:37:49 --> Helper loaded: lang_helper
INFO - 2023-07-24 08:37:49 --> Helper loaded: security_helper
INFO - 2023-07-24 08:37:49 --> Helper loaded: cookie_helper
INFO - 2023-07-24 08:37:49 --> Database Driver Class Initialized
INFO - 2023-07-24 08:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 08:37:49 --> Parser Class Initialized
INFO - 2023-07-24 08:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 08:37:49 --> Pagination Class Initialized
INFO - 2023-07-24 08:37:49 --> Form Validation Class Initialized
INFO - 2023-07-24 08:37:49 --> Controller Class Initialized
INFO - 2023-07-24 08:37:49 --> Model Class Initialized
DEBUG - 2023-07-24 08:37:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 08:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:49 --> Model Class Initialized
INFO - 2023-07-24 08:37:49 --> Final output sent to browser
DEBUG - 2023-07-24 08:37:49 --> Total execution time: 0.0248
ERROR - 2023-07-24 08:37:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 08:37:58 --> Config Class Initialized
INFO - 2023-07-24 08:37:58 --> Hooks Class Initialized
DEBUG - 2023-07-24 08:37:58 --> UTF-8 Support Enabled
INFO - 2023-07-24 08:37:58 --> Utf8 Class Initialized
INFO - 2023-07-24 08:37:58 --> URI Class Initialized
INFO - 2023-07-24 08:37:58 --> Router Class Initialized
INFO - 2023-07-24 08:37:58 --> Output Class Initialized
INFO - 2023-07-24 08:37:58 --> Security Class Initialized
DEBUG - 2023-07-24 08:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 08:37:58 --> Input Class Initialized
INFO - 2023-07-24 08:37:58 --> Language Class Initialized
INFO - 2023-07-24 08:37:58 --> Loader Class Initialized
INFO - 2023-07-24 08:37:58 --> Helper loaded: url_helper
INFO - 2023-07-24 08:37:58 --> Helper loaded: file_helper
INFO - 2023-07-24 08:37:58 --> Helper loaded: html_helper
INFO - 2023-07-24 08:37:58 --> Helper loaded: text_helper
INFO - 2023-07-24 08:37:58 --> Helper loaded: form_helper
INFO - 2023-07-24 08:37:58 --> Helper loaded: lang_helper
INFO - 2023-07-24 08:37:58 --> Helper loaded: security_helper
INFO - 2023-07-24 08:37:58 --> Helper loaded: cookie_helper
INFO - 2023-07-24 08:37:58 --> Database Driver Class Initialized
INFO - 2023-07-24 08:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 08:37:58 --> Parser Class Initialized
INFO - 2023-07-24 08:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 08:37:58 --> Pagination Class Initialized
INFO - 2023-07-24 08:37:58 --> Form Validation Class Initialized
INFO - 2023-07-24 08:37:58 --> Controller Class Initialized
INFO - 2023-07-24 08:37:58 --> Model Class Initialized
DEBUG - 2023-07-24 08:37:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 08:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 08:37:58 --> Model Class Initialized
INFO - 2023-07-24 08:37:58 --> Final output sent to browser
DEBUG - 2023-07-24 08:37:58 --> Total execution time: 0.0240
ERROR - 2023-07-24 12:35:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:35:54 --> Config Class Initialized
INFO - 2023-07-24 12:35:54 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:35:54 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:35:54 --> Utf8 Class Initialized
INFO - 2023-07-24 12:35:54 --> URI Class Initialized
DEBUG - 2023-07-24 12:35:54 --> No URI present. Default controller set.
INFO - 2023-07-24 12:35:54 --> Router Class Initialized
INFO - 2023-07-24 12:35:54 --> Output Class Initialized
INFO - 2023-07-24 12:35:54 --> Security Class Initialized
DEBUG - 2023-07-24 12:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:35:54 --> Input Class Initialized
INFO - 2023-07-24 12:35:54 --> Language Class Initialized
INFO - 2023-07-24 12:35:54 --> Loader Class Initialized
INFO - 2023-07-24 12:35:54 --> Helper loaded: url_helper
INFO - 2023-07-24 12:35:54 --> Helper loaded: file_helper
INFO - 2023-07-24 12:35:54 --> Helper loaded: html_helper
INFO - 2023-07-24 12:35:54 --> Helper loaded: text_helper
INFO - 2023-07-24 12:35:54 --> Helper loaded: form_helper
INFO - 2023-07-24 12:35:54 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:35:54 --> Helper loaded: security_helper
INFO - 2023-07-24 12:35:54 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:35:54 --> Database Driver Class Initialized
INFO - 2023-07-24 12:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:35:54 --> Parser Class Initialized
INFO - 2023-07-24 12:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:35:54 --> Pagination Class Initialized
INFO - 2023-07-24 12:35:54 --> Form Validation Class Initialized
INFO - 2023-07-24 12:35:54 --> Controller Class Initialized
INFO - 2023-07-24 12:35:54 --> Model Class Initialized
DEBUG - 2023-07-24 12:35:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-24 12:35:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:35:55 --> Config Class Initialized
INFO - 2023-07-24 12:35:55 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:35:55 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:35:55 --> Utf8 Class Initialized
INFO - 2023-07-24 12:35:55 --> URI Class Initialized
INFO - 2023-07-24 12:35:55 --> Router Class Initialized
INFO - 2023-07-24 12:35:55 --> Output Class Initialized
INFO - 2023-07-24 12:35:55 --> Security Class Initialized
DEBUG - 2023-07-24 12:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:35:55 --> Input Class Initialized
INFO - 2023-07-24 12:35:55 --> Language Class Initialized
INFO - 2023-07-24 12:35:55 --> Loader Class Initialized
INFO - 2023-07-24 12:35:55 --> Helper loaded: url_helper
INFO - 2023-07-24 12:35:55 --> Helper loaded: file_helper
INFO - 2023-07-24 12:35:55 --> Helper loaded: html_helper
INFO - 2023-07-24 12:35:55 --> Helper loaded: text_helper
INFO - 2023-07-24 12:35:55 --> Helper loaded: form_helper
INFO - 2023-07-24 12:35:55 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:35:55 --> Helper loaded: security_helper
INFO - 2023-07-24 12:35:55 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:35:55 --> Database Driver Class Initialized
INFO - 2023-07-24 12:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:35:55 --> Parser Class Initialized
INFO - 2023-07-24 12:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:35:55 --> Pagination Class Initialized
INFO - 2023-07-24 12:35:55 --> Form Validation Class Initialized
INFO - 2023-07-24 12:35:55 --> Controller Class Initialized
INFO - 2023-07-24 12:35:55 --> Model Class Initialized
DEBUG - 2023-07-24 12:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-24 12:35:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:35:55 --> Model Class Initialized
INFO - 2023-07-24 12:35:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:35:55 --> Final output sent to browser
DEBUG - 2023-07-24 12:35:55 --> Total execution time: 0.0369
ERROR - 2023-07-24 12:42:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:42:18 --> Config Class Initialized
INFO - 2023-07-24 12:42:18 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:42:18 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:42:18 --> Utf8 Class Initialized
INFO - 2023-07-24 12:42:18 --> URI Class Initialized
INFO - 2023-07-24 12:42:18 --> Router Class Initialized
INFO - 2023-07-24 12:42:18 --> Output Class Initialized
INFO - 2023-07-24 12:42:18 --> Security Class Initialized
DEBUG - 2023-07-24 12:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:42:18 --> Input Class Initialized
INFO - 2023-07-24 12:42:18 --> Language Class Initialized
INFO - 2023-07-24 12:42:18 --> Loader Class Initialized
INFO - 2023-07-24 12:42:18 --> Helper loaded: url_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: file_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: html_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: text_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: form_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: security_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:42:18 --> Database Driver Class Initialized
INFO - 2023-07-24 12:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:42:18 --> Parser Class Initialized
INFO - 2023-07-24 12:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:42:18 --> Pagination Class Initialized
INFO - 2023-07-24 12:42:18 --> Form Validation Class Initialized
INFO - 2023-07-24 12:42:18 --> Controller Class Initialized
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
DEBUG - 2023-07-24 12:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
INFO - 2023-07-24 12:42:18 --> Final output sent to browser
DEBUG - 2023-07-24 12:42:18 --> Total execution time: 0.0235
ERROR - 2023-07-24 12:42:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:42:18 --> Config Class Initialized
INFO - 2023-07-24 12:42:18 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:42:18 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:42:18 --> Utf8 Class Initialized
INFO - 2023-07-24 12:42:18 --> URI Class Initialized
DEBUG - 2023-07-24 12:42:18 --> No URI present. Default controller set.
INFO - 2023-07-24 12:42:18 --> Router Class Initialized
INFO - 2023-07-24 12:42:18 --> Output Class Initialized
INFO - 2023-07-24 12:42:18 --> Security Class Initialized
DEBUG - 2023-07-24 12:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:42:18 --> Input Class Initialized
INFO - 2023-07-24 12:42:18 --> Language Class Initialized
INFO - 2023-07-24 12:42:18 --> Loader Class Initialized
INFO - 2023-07-24 12:42:18 --> Helper loaded: url_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: file_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: html_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: text_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: form_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: security_helper
INFO - 2023-07-24 12:42:18 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:42:18 --> Database Driver Class Initialized
INFO - 2023-07-24 12:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:42:18 --> Parser Class Initialized
INFO - 2023-07-24 12:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:42:18 --> Pagination Class Initialized
INFO - 2023-07-24 12:42:18 --> Form Validation Class Initialized
INFO - 2023-07-24 12:42:18 --> Controller Class Initialized
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
DEBUG - 2023-07-24 12:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
DEBUG - 2023-07-24 12:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
DEBUG - 2023-07-24 12:42:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
INFO - 2023-07-24 12:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 12:42:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:42:18 --> Model Class Initialized
INFO - 2023-07-24 12:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:42:18 --> Final output sent to browser
DEBUG - 2023-07-24 12:42:18 --> Total execution time: 0.1994
ERROR - 2023-07-24 12:42:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:42:19 --> Config Class Initialized
INFO - 2023-07-24 12:42:20 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:42:20 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:42:20 --> Utf8 Class Initialized
INFO - 2023-07-24 12:42:20 --> URI Class Initialized
INFO - 2023-07-24 12:42:20 --> Router Class Initialized
INFO - 2023-07-24 12:42:20 --> Output Class Initialized
INFO - 2023-07-24 12:42:20 --> Security Class Initialized
DEBUG - 2023-07-24 12:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:42:20 --> Input Class Initialized
INFO - 2023-07-24 12:42:20 --> Language Class Initialized
INFO - 2023-07-24 12:42:20 --> Loader Class Initialized
INFO - 2023-07-24 12:42:20 --> Helper loaded: url_helper
INFO - 2023-07-24 12:42:20 --> Helper loaded: file_helper
INFO - 2023-07-24 12:42:20 --> Helper loaded: html_helper
INFO - 2023-07-24 12:42:20 --> Helper loaded: text_helper
INFO - 2023-07-24 12:42:20 --> Helper loaded: form_helper
INFO - 2023-07-24 12:42:20 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:42:20 --> Helper loaded: security_helper
INFO - 2023-07-24 12:42:20 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:42:20 --> Database Driver Class Initialized
INFO - 2023-07-24 12:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:42:20 --> Parser Class Initialized
INFO - 2023-07-24 12:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:42:20 --> Pagination Class Initialized
INFO - 2023-07-24 12:42:20 --> Form Validation Class Initialized
INFO - 2023-07-24 12:42:20 --> Controller Class Initialized
DEBUG - 2023-07-24 12:42:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:20 --> Model Class Initialized
INFO - 2023-07-24 12:42:20 --> Final output sent to browser
DEBUG - 2023-07-24 12:42:20 --> Total execution time: 0.0144
ERROR - 2023-07-24 12:42:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:42:36 --> Config Class Initialized
INFO - 2023-07-24 12:42:36 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:42:36 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:42:36 --> Utf8 Class Initialized
INFO - 2023-07-24 12:42:36 --> URI Class Initialized
DEBUG - 2023-07-24 12:42:36 --> No URI present. Default controller set.
INFO - 2023-07-24 12:42:36 --> Router Class Initialized
INFO - 2023-07-24 12:42:36 --> Output Class Initialized
INFO - 2023-07-24 12:42:36 --> Security Class Initialized
DEBUG - 2023-07-24 12:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:42:36 --> Input Class Initialized
INFO - 2023-07-24 12:42:36 --> Language Class Initialized
INFO - 2023-07-24 12:42:36 --> Loader Class Initialized
INFO - 2023-07-24 12:42:36 --> Helper loaded: url_helper
INFO - 2023-07-24 12:42:36 --> Helper loaded: file_helper
INFO - 2023-07-24 12:42:36 --> Helper loaded: html_helper
INFO - 2023-07-24 12:42:36 --> Helper loaded: text_helper
INFO - 2023-07-24 12:42:36 --> Helper loaded: form_helper
INFO - 2023-07-24 12:42:36 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:42:36 --> Helper loaded: security_helper
INFO - 2023-07-24 12:42:36 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:42:36 --> Database Driver Class Initialized
INFO - 2023-07-24 12:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:42:36 --> Parser Class Initialized
INFO - 2023-07-24 12:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:42:36 --> Pagination Class Initialized
INFO - 2023-07-24 12:42:36 --> Form Validation Class Initialized
INFO - 2023-07-24 12:42:36 --> Controller Class Initialized
INFO - 2023-07-24 12:42:36 --> Model Class Initialized
DEBUG - 2023-07-24 12:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:36 --> Model Class Initialized
DEBUG - 2023-07-24 12:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:36 --> Model Class Initialized
INFO - 2023-07-24 12:42:36 --> Model Class Initialized
INFO - 2023-07-24 12:42:36 --> Model Class Initialized
INFO - 2023-07-24 12:42:36 --> Model Class Initialized
DEBUG - 2023-07-24 12:42:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:36 --> Model Class Initialized
INFO - 2023-07-24 12:42:36 --> Model Class Initialized
INFO - 2023-07-24 12:42:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 12:42:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:42:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:42:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:42:36 --> Model Class Initialized
INFO - 2023-07-24 12:42:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:42:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:42:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:42:37 --> Final output sent to browser
DEBUG - 2023-07-24 12:42:37 --> Total execution time: 0.1904
ERROR - 2023-07-24 12:44:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:44:16 --> Config Class Initialized
INFO - 2023-07-24 12:44:16 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:44:16 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:44:16 --> Utf8 Class Initialized
INFO - 2023-07-24 12:44:16 --> URI Class Initialized
INFO - 2023-07-24 12:44:16 --> Router Class Initialized
INFO - 2023-07-24 12:44:16 --> Output Class Initialized
INFO - 2023-07-24 12:44:16 --> Security Class Initialized
DEBUG - 2023-07-24 12:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:44:16 --> Input Class Initialized
INFO - 2023-07-24 12:44:16 --> Language Class Initialized
INFO - 2023-07-24 12:44:16 --> Loader Class Initialized
INFO - 2023-07-24 12:44:16 --> Helper loaded: url_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: file_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: html_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: text_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: form_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: security_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:44:16 --> Database Driver Class Initialized
INFO - 2023-07-24 12:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:44:16 --> Parser Class Initialized
INFO - 2023-07-24 12:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:44:16 --> Pagination Class Initialized
INFO - 2023-07-24 12:44:16 --> Form Validation Class Initialized
INFO - 2023-07-24 12:44:16 --> Controller Class Initialized
INFO - 2023-07-24 12:44:16 --> Model Class Initialized
DEBUG - 2023-07-24 12:44:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:44:16 --> Model Class Initialized
DEBUG - 2023-07-24 12:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:44:16 --> Model Class Initialized
INFO - 2023-07-24 12:44:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-24 12:44:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:44:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:44:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:44:16 --> Model Class Initialized
INFO - 2023-07-24 12:44:16 --> Model Class Initialized
INFO - 2023-07-24 12:44:16 --> Model Class Initialized
INFO - 2023-07-24 12:44:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:44:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:44:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:44:16 --> Final output sent to browser
DEBUG - 2023-07-24 12:44:16 --> Total execution time: 0.1559
ERROR - 2023-07-24 12:44:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:44:16 --> Config Class Initialized
INFO - 2023-07-24 12:44:16 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:44:16 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:44:16 --> Utf8 Class Initialized
INFO - 2023-07-24 12:44:16 --> URI Class Initialized
INFO - 2023-07-24 12:44:16 --> Router Class Initialized
INFO - 2023-07-24 12:44:16 --> Output Class Initialized
INFO - 2023-07-24 12:44:16 --> Security Class Initialized
DEBUG - 2023-07-24 12:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:44:16 --> Input Class Initialized
INFO - 2023-07-24 12:44:16 --> Language Class Initialized
INFO - 2023-07-24 12:44:16 --> Loader Class Initialized
INFO - 2023-07-24 12:44:16 --> Helper loaded: url_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: file_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: html_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: text_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: form_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: security_helper
INFO - 2023-07-24 12:44:16 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:44:16 --> Database Driver Class Initialized
INFO - 2023-07-24 12:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:44:16 --> Parser Class Initialized
INFO - 2023-07-24 12:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:44:16 --> Pagination Class Initialized
INFO - 2023-07-24 12:44:16 --> Form Validation Class Initialized
INFO - 2023-07-24 12:44:16 --> Controller Class Initialized
INFO - 2023-07-24 12:44:16 --> Model Class Initialized
DEBUG - 2023-07-24 12:44:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:44:16 --> Model Class Initialized
DEBUG - 2023-07-24 12:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:44:16 --> Model Class Initialized
INFO - 2023-07-24 12:44:16 --> Final output sent to browser
DEBUG - 2023-07-24 12:44:16 --> Total execution time: 0.0502
ERROR - 2023-07-24 12:44:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:44:21 --> Config Class Initialized
INFO - 2023-07-24 12:44:21 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:44:21 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:44:21 --> Utf8 Class Initialized
INFO - 2023-07-24 12:44:21 --> URI Class Initialized
INFO - 2023-07-24 12:44:21 --> Router Class Initialized
INFO - 2023-07-24 12:44:21 --> Output Class Initialized
INFO - 2023-07-24 12:44:21 --> Security Class Initialized
DEBUG - 2023-07-24 12:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:44:21 --> Input Class Initialized
INFO - 2023-07-24 12:44:21 --> Language Class Initialized
INFO - 2023-07-24 12:44:21 --> Loader Class Initialized
INFO - 2023-07-24 12:44:21 --> Helper loaded: url_helper
INFO - 2023-07-24 12:44:21 --> Helper loaded: file_helper
INFO - 2023-07-24 12:44:21 --> Helper loaded: html_helper
INFO - 2023-07-24 12:44:21 --> Helper loaded: text_helper
INFO - 2023-07-24 12:44:21 --> Helper loaded: form_helper
INFO - 2023-07-24 12:44:21 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:44:21 --> Helper loaded: security_helper
INFO - 2023-07-24 12:44:21 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:44:21 --> Database Driver Class Initialized
INFO - 2023-07-24 12:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:44:21 --> Parser Class Initialized
INFO - 2023-07-24 12:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:44:21 --> Pagination Class Initialized
INFO - 2023-07-24 12:44:21 --> Form Validation Class Initialized
INFO - 2023-07-24 12:44:21 --> Controller Class Initialized
INFO - 2023-07-24 12:44:21 --> Model Class Initialized
DEBUG - 2023-07-24 12:44:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:44:21 --> Model Class Initialized
DEBUG - 2023-07-24 12:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:44:21 --> Model Class Initialized
INFO - 2023-07-24 12:44:21 --> Final output sent to browser
DEBUG - 2023-07-24 12:44:21 --> Total execution time: 0.0696
ERROR - 2023-07-24 12:47:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:47:18 --> Config Class Initialized
INFO - 2023-07-24 12:47:18 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:47:18 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:47:18 --> Utf8 Class Initialized
INFO - 2023-07-24 12:47:18 --> URI Class Initialized
DEBUG - 2023-07-24 12:47:18 --> No URI present. Default controller set.
INFO - 2023-07-24 12:47:18 --> Router Class Initialized
INFO - 2023-07-24 12:47:18 --> Output Class Initialized
INFO - 2023-07-24 12:47:18 --> Security Class Initialized
DEBUG - 2023-07-24 12:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:47:18 --> Input Class Initialized
INFO - 2023-07-24 12:47:18 --> Language Class Initialized
INFO - 2023-07-24 12:47:18 --> Loader Class Initialized
INFO - 2023-07-24 12:47:18 --> Helper loaded: url_helper
INFO - 2023-07-24 12:47:18 --> Helper loaded: file_helper
INFO - 2023-07-24 12:47:18 --> Helper loaded: html_helper
INFO - 2023-07-24 12:47:18 --> Helper loaded: text_helper
INFO - 2023-07-24 12:47:18 --> Helper loaded: form_helper
INFO - 2023-07-24 12:47:18 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:47:18 --> Helper loaded: security_helper
INFO - 2023-07-24 12:47:18 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:47:18 --> Database Driver Class Initialized
INFO - 2023-07-24 12:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:47:18 --> Parser Class Initialized
INFO - 2023-07-24 12:47:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:47:18 --> Pagination Class Initialized
INFO - 2023-07-24 12:47:18 --> Form Validation Class Initialized
INFO - 2023-07-24 12:47:18 --> Controller Class Initialized
INFO - 2023-07-24 12:47:18 --> Model Class Initialized
DEBUG - 2023-07-24 12:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:47:18 --> Model Class Initialized
DEBUG - 2023-07-24 12:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:47:18 --> Model Class Initialized
INFO - 2023-07-24 12:47:18 --> Model Class Initialized
INFO - 2023-07-24 12:47:18 --> Model Class Initialized
INFO - 2023-07-24 12:47:18 --> Model Class Initialized
DEBUG - 2023-07-24 12:47:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:47:18 --> Model Class Initialized
INFO - 2023-07-24 12:47:18 --> Model Class Initialized
INFO - 2023-07-24 12:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 12:47:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:47:18 --> Model Class Initialized
INFO - 2023-07-24 12:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:47:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:47:18 --> Final output sent to browser
DEBUG - 2023-07-24 12:47:18 --> Total execution time: 0.1801
ERROR - 2023-07-24 12:47:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:47:30 --> Config Class Initialized
INFO - 2023-07-24 12:47:30 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:47:30 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:47:30 --> Utf8 Class Initialized
INFO - 2023-07-24 12:47:30 --> URI Class Initialized
INFO - 2023-07-24 12:47:30 --> Router Class Initialized
INFO - 2023-07-24 12:47:30 --> Output Class Initialized
INFO - 2023-07-24 12:47:30 --> Security Class Initialized
DEBUG - 2023-07-24 12:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:47:30 --> Input Class Initialized
INFO - 2023-07-24 12:47:30 --> Language Class Initialized
INFO - 2023-07-24 12:47:30 --> Loader Class Initialized
INFO - 2023-07-24 12:47:30 --> Helper loaded: url_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: file_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: html_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: text_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: form_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: security_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:47:30 --> Database Driver Class Initialized
INFO - 2023-07-24 12:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:47:30 --> Parser Class Initialized
INFO - 2023-07-24 12:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:47:30 --> Pagination Class Initialized
INFO - 2023-07-24 12:47:30 --> Form Validation Class Initialized
INFO - 2023-07-24 12:47:30 --> Controller Class Initialized
INFO - 2023-07-24 12:47:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:47:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:47:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:47:30 --> Model Class Initialized
INFO - 2023-07-24 12:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-24 12:47:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:47:30 --> Model Class Initialized
INFO - 2023-07-24 12:47:30 --> Model Class Initialized
INFO - 2023-07-24 12:47:30 --> Model Class Initialized
INFO - 2023-07-24 12:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:47:30 --> Final output sent to browser
DEBUG - 2023-07-24 12:47:30 --> Total execution time: 0.1447
ERROR - 2023-07-24 12:47:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:47:30 --> Config Class Initialized
INFO - 2023-07-24 12:47:30 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:47:30 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:47:30 --> Utf8 Class Initialized
INFO - 2023-07-24 12:47:30 --> URI Class Initialized
INFO - 2023-07-24 12:47:30 --> Router Class Initialized
INFO - 2023-07-24 12:47:30 --> Output Class Initialized
INFO - 2023-07-24 12:47:30 --> Security Class Initialized
DEBUG - 2023-07-24 12:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:47:30 --> Input Class Initialized
INFO - 2023-07-24 12:47:30 --> Language Class Initialized
INFO - 2023-07-24 12:47:30 --> Loader Class Initialized
INFO - 2023-07-24 12:47:30 --> Helper loaded: url_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: file_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: html_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: text_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: form_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: security_helper
INFO - 2023-07-24 12:47:30 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:47:30 --> Database Driver Class Initialized
INFO - 2023-07-24 12:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:47:30 --> Parser Class Initialized
INFO - 2023-07-24 12:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:47:30 --> Pagination Class Initialized
INFO - 2023-07-24 12:47:30 --> Form Validation Class Initialized
INFO - 2023-07-24 12:47:30 --> Controller Class Initialized
INFO - 2023-07-24 12:47:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:47:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:47:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:47:30 --> Model Class Initialized
INFO - 2023-07-24 12:47:30 --> Final output sent to browser
DEBUG - 2023-07-24 12:47:30 --> Total execution time: 0.0513
ERROR - 2023-07-24 12:48:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:48:07 --> Config Class Initialized
INFO - 2023-07-24 12:48:07 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:48:07 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:48:07 --> Utf8 Class Initialized
INFO - 2023-07-24 12:48:07 --> URI Class Initialized
DEBUG - 2023-07-24 12:48:07 --> No URI present. Default controller set.
INFO - 2023-07-24 12:48:07 --> Router Class Initialized
INFO - 2023-07-24 12:48:07 --> Output Class Initialized
INFO - 2023-07-24 12:48:07 --> Security Class Initialized
DEBUG - 2023-07-24 12:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:48:07 --> Input Class Initialized
INFO - 2023-07-24 12:48:07 --> Language Class Initialized
INFO - 2023-07-24 12:48:07 --> Loader Class Initialized
INFO - 2023-07-24 12:48:07 --> Helper loaded: url_helper
INFO - 2023-07-24 12:48:07 --> Helper loaded: file_helper
INFO - 2023-07-24 12:48:07 --> Helper loaded: html_helper
INFO - 2023-07-24 12:48:07 --> Helper loaded: text_helper
INFO - 2023-07-24 12:48:07 --> Helper loaded: form_helper
INFO - 2023-07-24 12:48:07 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:48:07 --> Helper loaded: security_helper
INFO - 2023-07-24 12:48:07 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:48:07 --> Database Driver Class Initialized
INFO - 2023-07-24 12:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:48:07 --> Parser Class Initialized
INFO - 2023-07-24 12:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:48:07 --> Pagination Class Initialized
INFO - 2023-07-24 12:48:07 --> Form Validation Class Initialized
INFO - 2023-07-24 12:48:07 --> Controller Class Initialized
INFO - 2023-07-24 12:48:07 --> Model Class Initialized
DEBUG - 2023-07-24 12:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:07 --> Model Class Initialized
DEBUG - 2023-07-24 12:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:07 --> Model Class Initialized
INFO - 2023-07-24 12:48:07 --> Model Class Initialized
INFO - 2023-07-24 12:48:07 --> Model Class Initialized
INFO - 2023-07-24 12:48:07 --> Model Class Initialized
DEBUG - 2023-07-24 12:48:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:07 --> Model Class Initialized
INFO - 2023-07-24 12:48:07 --> Model Class Initialized
INFO - 2023-07-24 12:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 12:48:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:48:07 --> Model Class Initialized
INFO - 2023-07-24 12:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:48:08 --> Final output sent to browser
DEBUG - 2023-07-24 12:48:08 --> Total execution time: 0.2085
ERROR - 2023-07-24 12:48:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:48:25 --> Config Class Initialized
INFO - 2023-07-24 12:48:25 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:48:25 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:48:25 --> Utf8 Class Initialized
INFO - 2023-07-24 12:48:25 --> URI Class Initialized
INFO - 2023-07-24 12:48:25 --> Router Class Initialized
INFO - 2023-07-24 12:48:25 --> Output Class Initialized
INFO - 2023-07-24 12:48:25 --> Security Class Initialized
DEBUG - 2023-07-24 12:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:48:25 --> Input Class Initialized
INFO - 2023-07-24 12:48:25 --> Language Class Initialized
INFO - 2023-07-24 12:48:25 --> Loader Class Initialized
INFO - 2023-07-24 12:48:25 --> Helper loaded: url_helper
INFO - 2023-07-24 12:48:25 --> Helper loaded: file_helper
INFO - 2023-07-24 12:48:25 --> Helper loaded: html_helper
INFO - 2023-07-24 12:48:25 --> Helper loaded: text_helper
INFO - 2023-07-24 12:48:25 --> Helper loaded: form_helper
INFO - 2023-07-24 12:48:25 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:48:25 --> Helper loaded: security_helper
INFO - 2023-07-24 12:48:25 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:48:25 --> Database Driver Class Initialized
INFO - 2023-07-24 12:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:48:25 --> Parser Class Initialized
INFO - 2023-07-24 12:48:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:48:25 --> Pagination Class Initialized
INFO - 2023-07-24 12:48:25 --> Form Validation Class Initialized
INFO - 2023-07-24 12:48:25 --> Controller Class Initialized
DEBUG - 2023-07-24 12:48:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:25 --> Model Class Initialized
DEBUG - 2023-07-24 12:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:25 --> Model Class Initialized
DEBUG - 2023-07-24 12:48:25 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:25 --> Model Class Initialized
INFO - 2023-07-24 12:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-24 12:48:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:48:25 --> Model Class Initialized
INFO - 2023-07-24 12:48:25 --> Model Class Initialized
INFO - 2023-07-24 12:48:25 --> Model Class Initialized
INFO - 2023-07-24 12:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:48:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:48:25 --> Final output sent to browser
DEBUG - 2023-07-24 12:48:25 --> Total execution time: 0.1558
ERROR - 2023-07-24 12:48:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:48:26 --> Config Class Initialized
INFO - 2023-07-24 12:48:26 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:48:26 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:48:26 --> Utf8 Class Initialized
INFO - 2023-07-24 12:48:26 --> URI Class Initialized
INFO - 2023-07-24 12:48:26 --> Router Class Initialized
INFO - 2023-07-24 12:48:26 --> Output Class Initialized
INFO - 2023-07-24 12:48:26 --> Security Class Initialized
DEBUG - 2023-07-24 12:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:48:26 --> Input Class Initialized
INFO - 2023-07-24 12:48:26 --> Language Class Initialized
INFO - 2023-07-24 12:48:26 --> Loader Class Initialized
INFO - 2023-07-24 12:48:26 --> Helper loaded: url_helper
INFO - 2023-07-24 12:48:26 --> Helper loaded: file_helper
INFO - 2023-07-24 12:48:26 --> Helper loaded: html_helper
INFO - 2023-07-24 12:48:26 --> Helper loaded: text_helper
INFO - 2023-07-24 12:48:26 --> Helper loaded: form_helper
INFO - 2023-07-24 12:48:26 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:48:26 --> Helper loaded: security_helper
INFO - 2023-07-24 12:48:26 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:48:26 --> Database Driver Class Initialized
INFO - 2023-07-24 12:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:48:26 --> Parser Class Initialized
INFO - 2023-07-24 12:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:48:26 --> Pagination Class Initialized
INFO - 2023-07-24 12:48:26 --> Form Validation Class Initialized
INFO - 2023-07-24 12:48:26 --> Controller Class Initialized
DEBUG - 2023-07-24 12:48:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:26 --> Model Class Initialized
DEBUG - 2023-07-24 12:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:26 --> Model Class Initialized
INFO - 2023-07-24 12:48:26 --> Final output sent to browser
DEBUG - 2023-07-24 12:48:26 --> Total execution time: 0.0320
ERROR - 2023-07-24 12:48:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:48:30 --> Config Class Initialized
INFO - 2023-07-24 12:48:30 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:48:30 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:48:30 --> Utf8 Class Initialized
INFO - 2023-07-24 12:48:30 --> URI Class Initialized
INFO - 2023-07-24 12:48:30 --> Router Class Initialized
INFO - 2023-07-24 12:48:30 --> Output Class Initialized
INFO - 2023-07-24 12:48:30 --> Security Class Initialized
DEBUG - 2023-07-24 12:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:48:30 --> Input Class Initialized
INFO - 2023-07-24 12:48:30 --> Language Class Initialized
INFO - 2023-07-24 12:48:30 --> Loader Class Initialized
INFO - 2023-07-24 12:48:30 --> Helper loaded: url_helper
INFO - 2023-07-24 12:48:30 --> Helper loaded: file_helper
INFO - 2023-07-24 12:48:30 --> Helper loaded: html_helper
INFO - 2023-07-24 12:48:30 --> Helper loaded: text_helper
INFO - 2023-07-24 12:48:30 --> Helper loaded: form_helper
INFO - 2023-07-24 12:48:30 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:48:30 --> Helper loaded: security_helper
INFO - 2023-07-24 12:48:30 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:48:30 --> Database Driver Class Initialized
INFO - 2023-07-24 12:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:48:30 --> Parser Class Initialized
INFO - 2023-07-24 12:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:48:30 --> Pagination Class Initialized
INFO - 2023-07-24 12:48:30 --> Form Validation Class Initialized
INFO - 2023-07-24 12:48:30 --> Controller Class Initialized
DEBUG - 2023-07-24 12:48:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:48:30 --> Model Class Initialized
INFO - 2023-07-24 12:48:30 --> Final output sent to browser
DEBUG - 2023-07-24 12:48:30 --> Total execution time: 0.1374
ERROR - 2023-07-24 12:50:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:50:07 --> Config Class Initialized
INFO - 2023-07-24 12:50:07 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:50:07 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:50:07 --> Utf8 Class Initialized
INFO - 2023-07-24 12:50:07 --> URI Class Initialized
INFO - 2023-07-24 12:50:07 --> Router Class Initialized
INFO - 2023-07-24 12:50:07 --> Output Class Initialized
INFO - 2023-07-24 12:50:07 --> Security Class Initialized
DEBUG - 2023-07-24 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:50:07 --> Input Class Initialized
INFO - 2023-07-24 12:50:07 --> Language Class Initialized
INFO - 2023-07-24 12:50:07 --> Loader Class Initialized
INFO - 2023-07-24 12:50:07 --> Helper loaded: url_helper
INFO - 2023-07-24 12:50:07 --> Helper loaded: file_helper
INFO - 2023-07-24 12:50:07 --> Helper loaded: html_helper
INFO - 2023-07-24 12:50:07 --> Helper loaded: text_helper
INFO - 2023-07-24 12:50:07 --> Helper loaded: form_helper
INFO - 2023-07-24 12:50:07 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:50:07 --> Helper loaded: security_helper
INFO - 2023-07-24 12:50:07 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:50:07 --> Database Driver Class Initialized
INFO - 2023-07-24 12:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:50:07 --> Parser Class Initialized
INFO - 2023-07-24 12:50:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:50:07 --> Pagination Class Initialized
INFO - 2023-07-24 12:50:07 --> Form Validation Class Initialized
INFO - 2023-07-24 12:50:07 --> Controller Class Initialized
DEBUG - 2023-07-24 12:50:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:50:07 --> Model Class Initialized
DEBUG - 2023-07-24 12:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:50:07 --> Model Class Initialized
INFO - 2023-07-24 12:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-24 12:50:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:50:07 --> Model Class Initialized
INFO - 2023-07-24 12:50:07 --> Model Class Initialized
INFO - 2023-07-24 12:50:07 --> Model Class Initialized
INFO - 2023-07-24 12:50:07 --> Model Class Initialized
INFO - 2023-07-24 12:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:50:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:50:07 --> Final output sent to browser
DEBUG - 2023-07-24 12:50:07 --> Total execution time: 0.1553
ERROR - 2023-07-24 12:52:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:52:08 --> Config Class Initialized
INFO - 2023-07-24 12:52:08 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:52:08 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:52:08 --> Utf8 Class Initialized
INFO - 2023-07-24 12:52:08 --> URI Class Initialized
DEBUG - 2023-07-24 12:52:08 --> No URI present. Default controller set.
INFO - 2023-07-24 12:52:08 --> Router Class Initialized
INFO - 2023-07-24 12:52:08 --> Output Class Initialized
INFO - 2023-07-24 12:52:08 --> Security Class Initialized
DEBUG - 2023-07-24 12:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:52:08 --> Input Class Initialized
INFO - 2023-07-24 12:52:08 --> Language Class Initialized
INFO - 2023-07-24 12:52:08 --> Loader Class Initialized
INFO - 2023-07-24 12:52:08 --> Helper loaded: url_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: file_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: html_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: text_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: form_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: security_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:52:08 --> Database Driver Class Initialized
INFO - 2023-07-24 12:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:52:08 --> Parser Class Initialized
INFO - 2023-07-24 12:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:52:08 --> Pagination Class Initialized
INFO - 2023-07-24 12:52:08 --> Form Validation Class Initialized
INFO - 2023-07-24 12:52:08 --> Controller Class Initialized
INFO - 2023-07-24 12:52:08 --> Model Class Initialized
DEBUG - 2023-07-24 12:52:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-24 12:52:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:52:08 --> Config Class Initialized
INFO - 2023-07-24 12:52:08 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:52:08 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:52:08 --> Utf8 Class Initialized
INFO - 2023-07-24 12:52:08 --> URI Class Initialized
INFO - 2023-07-24 12:52:08 --> Router Class Initialized
INFO - 2023-07-24 12:52:08 --> Output Class Initialized
INFO - 2023-07-24 12:52:08 --> Security Class Initialized
DEBUG - 2023-07-24 12:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:52:08 --> Input Class Initialized
INFO - 2023-07-24 12:52:08 --> Language Class Initialized
INFO - 2023-07-24 12:52:08 --> Loader Class Initialized
INFO - 2023-07-24 12:52:08 --> Helper loaded: url_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: file_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: html_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: text_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: form_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: security_helper
INFO - 2023-07-24 12:52:08 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:52:08 --> Database Driver Class Initialized
INFO - 2023-07-24 12:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:52:08 --> Parser Class Initialized
INFO - 2023-07-24 12:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:52:08 --> Pagination Class Initialized
INFO - 2023-07-24 12:52:08 --> Form Validation Class Initialized
INFO - 2023-07-24 12:52:08 --> Controller Class Initialized
INFO - 2023-07-24 12:52:08 --> Model Class Initialized
DEBUG - 2023-07-24 12:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-24 12:52:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:52:08 --> Model Class Initialized
INFO - 2023-07-24 12:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:52:08 --> Final output sent to browser
DEBUG - 2023-07-24 12:52:08 --> Total execution time: 0.0307
ERROR - 2023-07-24 12:52:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:52:30 --> Config Class Initialized
INFO - 2023-07-24 12:52:30 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:52:30 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:52:30 --> Utf8 Class Initialized
INFO - 2023-07-24 12:52:30 --> URI Class Initialized
INFO - 2023-07-24 12:52:30 --> Router Class Initialized
INFO - 2023-07-24 12:52:30 --> Output Class Initialized
INFO - 2023-07-24 12:52:30 --> Security Class Initialized
DEBUG - 2023-07-24 12:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:52:30 --> Input Class Initialized
INFO - 2023-07-24 12:52:30 --> Language Class Initialized
INFO - 2023-07-24 12:52:30 --> Loader Class Initialized
INFO - 2023-07-24 12:52:30 --> Helper loaded: url_helper
INFO - 2023-07-24 12:52:30 --> Helper loaded: file_helper
INFO - 2023-07-24 12:52:30 --> Helper loaded: html_helper
INFO - 2023-07-24 12:52:30 --> Helper loaded: text_helper
INFO - 2023-07-24 12:52:30 --> Helper loaded: form_helper
INFO - 2023-07-24 12:52:30 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:52:30 --> Helper loaded: security_helper
INFO - 2023-07-24 12:52:30 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:52:30 --> Database Driver Class Initialized
INFO - 2023-07-24 12:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:52:30 --> Parser Class Initialized
INFO - 2023-07-24 12:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:52:30 --> Pagination Class Initialized
INFO - 2023-07-24 12:52:30 --> Form Validation Class Initialized
INFO - 2023-07-24 12:52:30 --> Controller Class Initialized
INFO - 2023-07-24 12:52:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:52:30 --> Model Class Initialized
INFO - 2023-07-24 12:52:30 --> Final output sent to browser
DEBUG - 2023-07-24 12:52:30 --> Total execution time: 0.0187
ERROR - 2023-07-24 12:52:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:52:31 --> Config Class Initialized
INFO - 2023-07-24 12:52:31 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:52:31 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:52:31 --> Utf8 Class Initialized
INFO - 2023-07-24 12:52:31 --> URI Class Initialized
INFO - 2023-07-24 12:52:31 --> Router Class Initialized
INFO - 2023-07-24 12:52:31 --> Output Class Initialized
INFO - 2023-07-24 12:52:31 --> Security Class Initialized
DEBUG - 2023-07-24 12:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:52:31 --> Input Class Initialized
INFO - 2023-07-24 12:52:31 --> Language Class Initialized
INFO - 2023-07-24 12:52:31 --> Loader Class Initialized
INFO - 2023-07-24 12:52:31 --> Helper loaded: url_helper
INFO - 2023-07-24 12:52:31 --> Helper loaded: file_helper
INFO - 2023-07-24 12:52:31 --> Helper loaded: html_helper
INFO - 2023-07-24 12:52:31 --> Helper loaded: text_helper
INFO - 2023-07-24 12:52:31 --> Helper loaded: form_helper
INFO - 2023-07-24 12:52:31 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:52:31 --> Helper loaded: security_helper
INFO - 2023-07-24 12:52:31 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:52:31 --> Database Driver Class Initialized
INFO - 2023-07-24 12:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:52:31 --> Parser Class Initialized
INFO - 2023-07-24 12:52:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:52:31 --> Pagination Class Initialized
INFO - 2023-07-24 12:52:31 --> Form Validation Class Initialized
INFO - 2023-07-24 12:52:31 --> Controller Class Initialized
INFO - 2023-07-24 12:52:31 --> Model Class Initialized
DEBUG - 2023-07-24 12:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-24 12:52:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:52:31 --> Model Class Initialized
INFO - 2023-07-24 12:52:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:52:31 --> Final output sent to browser
DEBUG - 2023-07-24 12:52:31 --> Total execution time: 0.0291
ERROR - 2023-07-24 12:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:52:56 --> Config Class Initialized
INFO - 2023-07-24 12:52:56 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:52:56 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:52:56 --> Utf8 Class Initialized
INFO - 2023-07-24 12:52:56 --> URI Class Initialized
INFO - 2023-07-24 12:52:56 --> Router Class Initialized
INFO - 2023-07-24 12:52:56 --> Output Class Initialized
INFO - 2023-07-24 12:52:56 --> Security Class Initialized
DEBUG - 2023-07-24 12:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:52:56 --> Input Class Initialized
INFO - 2023-07-24 12:52:56 --> Language Class Initialized
INFO - 2023-07-24 12:52:56 --> Loader Class Initialized
INFO - 2023-07-24 12:52:56 --> Helper loaded: url_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: file_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: html_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: text_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: form_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: security_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:52:56 --> Database Driver Class Initialized
INFO - 2023-07-24 12:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:52:56 --> Parser Class Initialized
INFO - 2023-07-24 12:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:52:56 --> Pagination Class Initialized
INFO - 2023-07-24 12:52:56 --> Form Validation Class Initialized
INFO - 2023-07-24 12:52:56 --> Controller Class Initialized
INFO - 2023-07-24 12:52:56 --> Model Class Initialized
DEBUG - 2023-07-24 12:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:52:56 --> Model Class Initialized
INFO - 2023-07-24 12:52:56 --> Final output sent to browser
DEBUG - 2023-07-24 12:52:56 --> Total execution time: 0.0185
ERROR - 2023-07-24 12:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:52:56 --> Config Class Initialized
INFO - 2023-07-24 12:52:56 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:52:56 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:52:56 --> Utf8 Class Initialized
INFO - 2023-07-24 12:52:56 --> URI Class Initialized
INFO - 2023-07-24 12:52:56 --> Router Class Initialized
INFO - 2023-07-24 12:52:56 --> Output Class Initialized
INFO - 2023-07-24 12:52:56 --> Security Class Initialized
DEBUG - 2023-07-24 12:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:52:56 --> Input Class Initialized
INFO - 2023-07-24 12:52:56 --> Language Class Initialized
INFO - 2023-07-24 12:52:56 --> Loader Class Initialized
INFO - 2023-07-24 12:52:56 --> Helper loaded: url_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: file_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: html_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: text_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: form_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: security_helper
INFO - 2023-07-24 12:52:56 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:52:56 --> Database Driver Class Initialized
INFO - 2023-07-24 12:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:52:56 --> Parser Class Initialized
INFO - 2023-07-24 12:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:52:56 --> Pagination Class Initialized
INFO - 2023-07-24 12:52:56 --> Form Validation Class Initialized
INFO - 2023-07-24 12:52:56 --> Controller Class Initialized
INFO - 2023-07-24 12:52:56 --> Model Class Initialized
DEBUG - 2023-07-24 12:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:52:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-24 12:52:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:52:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:52:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:52:57 --> Model Class Initialized
INFO - 2023-07-24 12:52:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:52:57 --> Final output sent to browser
DEBUG - 2023-07-24 12:52:57 --> Total execution time: 0.0321
ERROR - 2023-07-24 12:53:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:53:46 --> Config Class Initialized
INFO - 2023-07-24 12:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:53:46 --> Utf8 Class Initialized
INFO - 2023-07-24 12:53:46 --> URI Class Initialized
INFO - 2023-07-24 12:53:46 --> Router Class Initialized
INFO - 2023-07-24 12:53:46 --> Output Class Initialized
INFO - 2023-07-24 12:53:46 --> Security Class Initialized
DEBUG - 2023-07-24 12:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:53:46 --> Input Class Initialized
INFO - 2023-07-24 12:53:46 --> Language Class Initialized
INFO - 2023-07-24 12:53:46 --> Loader Class Initialized
INFO - 2023-07-24 12:53:46 --> Helper loaded: url_helper
INFO - 2023-07-24 12:53:46 --> Helper loaded: file_helper
INFO - 2023-07-24 12:53:46 --> Helper loaded: html_helper
INFO - 2023-07-24 12:53:46 --> Helper loaded: text_helper
INFO - 2023-07-24 12:53:46 --> Helper loaded: form_helper
INFO - 2023-07-24 12:53:46 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:53:46 --> Helper loaded: security_helper
INFO - 2023-07-24 12:53:46 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:53:46 --> Database Driver Class Initialized
INFO - 2023-07-24 12:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:53:46 --> Parser Class Initialized
INFO - 2023-07-24 12:53:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:53:46 --> Pagination Class Initialized
INFO - 2023-07-24 12:53:46 --> Form Validation Class Initialized
INFO - 2023-07-24 12:53:47 --> Controller Class Initialized
DEBUG - 2023-07-24 12:53:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:53:47 --> Model Class Initialized
DEBUG - 2023-07-24 12:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:53:47 --> Model Class Initialized
DEBUG - 2023-07-24 12:53:47 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:53:47 --> Model Class Initialized
INFO - 2023-07-24 12:53:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-24 12:53:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:53:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:53:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:53:47 --> Model Class Initialized
INFO - 2023-07-24 12:53:47 --> Model Class Initialized
INFO - 2023-07-24 12:53:47 --> Model Class Initialized
INFO - 2023-07-24 12:53:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:53:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:53:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:53:47 --> Final output sent to browser
DEBUG - 2023-07-24 12:53:47 --> Total execution time: 0.1577
ERROR - 2023-07-24 12:53:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:53:47 --> Config Class Initialized
INFO - 2023-07-24 12:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:53:47 --> Utf8 Class Initialized
INFO - 2023-07-24 12:53:47 --> URI Class Initialized
INFO - 2023-07-24 12:53:47 --> Router Class Initialized
INFO - 2023-07-24 12:53:47 --> Output Class Initialized
INFO - 2023-07-24 12:53:47 --> Security Class Initialized
DEBUG - 2023-07-24 12:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:53:47 --> Input Class Initialized
INFO - 2023-07-24 12:53:47 --> Language Class Initialized
INFO - 2023-07-24 12:53:47 --> Loader Class Initialized
INFO - 2023-07-24 12:53:47 --> Helper loaded: url_helper
INFO - 2023-07-24 12:53:47 --> Helper loaded: file_helper
INFO - 2023-07-24 12:53:47 --> Helper loaded: html_helper
INFO - 2023-07-24 12:53:47 --> Helper loaded: text_helper
INFO - 2023-07-24 12:53:47 --> Helper loaded: form_helper
INFO - 2023-07-24 12:53:47 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:53:47 --> Helper loaded: security_helper
INFO - 2023-07-24 12:53:47 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:53:47 --> Database Driver Class Initialized
INFO - 2023-07-24 12:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:53:47 --> Parser Class Initialized
INFO - 2023-07-24 12:53:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:53:47 --> Pagination Class Initialized
INFO - 2023-07-24 12:53:47 --> Form Validation Class Initialized
INFO - 2023-07-24 12:53:47 --> Controller Class Initialized
DEBUG - 2023-07-24 12:53:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:53:47 --> Model Class Initialized
DEBUG - 2023-07-24 12:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:53:47 --> Model Class Initialized
INFO - 2023-07-24 12:53:47 --> Final output sent to browser
DEBUG - 2023-07-24 12:53:47 --> Total execution time: 0.0311
ERROR - 2023-07-24 12:53:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:53:51 --> Config Class Initialized
INFO - 2023-07-24 12:53:51 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:53:51 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:53:51 --> Utf8 Class Initialized
INFO - 2023-07-24 12:53:51 --> URI Class Initialized
INFO - 2023-07-24 12:53:51 --> Router Class Initialized
INFO - 2023-07-24 12:53:51 --> Output Class Initialized
INFO - 2023-07-24 12:53:51 --> Security Class Initialized
DEBUG - 2023-07-24 12:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:53:51 --> Input Class Initialized
INFO - 2023-07-24 12:53:51 --> Language Class Initialized
INFO - 2023-07-24 12:53:51 --> Loader Class Initialized
INFO - 2023-07-24 12:53:51 --> Helper loaded: url_helper
INFO - 2023-07-24 12:53:51 --> Helper loaded: file_helper
INFO - 2023-07-24 12:53:51 --> Helper loaded: html_helper
INFO - 2023-07-24 12:53:51 --> Helper loaded: text_helper
INFO - 2023-07-24 12:53:51 --> Helper loaded: form_helper
INFO - 2023-07-24 12:53:51 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:53:51 --> Helper loaded: security_helper
INFO - 2023-07-24 12:53:51 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:53:51 --> Database Driver Class Initialized
INFO - 2023-07-24 12:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:53:51 --> Parser Class Initialized
INFO - 2023-07-24 12:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:53:51 --> Pagination Class Initialized
INFO - 2023-07-24 12:53:51 --> Form Validation Class Initialized
INFO - 2023-07-24 12:53:51 --> Controller Class Initialized
DEBUG - 2023-07-24 12:53:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:53:51 --> Model Class Initialized
DEBUG - 2023-07-24 12:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:53:51 --> Model Class Initialized
INFO - 2023-07-24 12:53:51 --> Final output sent to browser
DEBUG - 2023-07-24 12:53:51 --> Total execution time: 0.1406
ERROR - 2023-07-24 12:54:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:54:32 --> Config Class Initialized
INFO - 2023-07-24 12:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:54:32 --> Utf8 Class Initialized
INFO - 2023-07-24 12:54:32 --> URI Class Initialized
INFO - 2023-07-24 12:54:32 --> Router Class Initialized
INFO - 2023-07-24 12:54:32 --> Output Class Initialized
INFO - 2023-07-24 12:54:32 --> Security Class Initialized
DEBUG - 2023-07-24 12:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:54:32 --> Input Class Initialized
INFO - 2023-07-24 12:54:32 --> Language Class Initialized
INFO - 2023-07-24 12:54:32 --> Loader Class Initialized
INFO - 2023-07-24 12:54:32 --> Helper loaded: url_helper
INFO - 2023-07-24 12:54:32 --> Helper loaded: file_helper
INFO - 2023-07-24 12:54:32 --> Helper loaded: html_helper
INFO - 2023-07-24 12:54:32 --> Helper loaded: text_helper
INFO - 2023-07-24 12:54:32 --> Helper loaded: form_helper
INFO - 2023-07-24 12:54:32 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:54:32 --> Helper loaded: security_helper
INFO - 2023-07-24 12:54:32 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:54:32 --> Database Driver Class Initialized
INFO - 2023-07-24 12:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:54:32 --> Parser Class Initialized
INFO - 2023-07-24 12:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:54:32 --> Pagination Class Initialized
INFO - 2023-07-24 12:54:32 --> Form Validation Class Initialized
INFO - 2023-07-24 12:54:32 --> Controller Class Initialized
DEBUG - 2023-07-24 12:54:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:32 --> Model Class Initialized
DEBUG - 2023-07-24 12:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:32 --> Model Class Initialized
INFO - 2023-07-24 12:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-24 12:54:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:54:32 --> Model Class Initialized
INFO - 2023-07-24 12:54:32 --> Model Class Initialized
INFO - 2023-07-24 12:54:32 --> Model Class Initialized
INFO - 2023-07-24 12:54:32 --> Model Class Initialized
INFO - 2023-07-24 12:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:54:32 --> Final output sent to browser
DEBUG - 2023-07-24 12:54:32 --> Total execution time: 0.1537
ERROR - 2023-07-24 12:54:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:54:41 --> Config Class Initialized
INFO - 2023-07-24 12:54:41 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:54:41 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:54:41 --> Utf8 Class Initialized
INFO - 2023-07-24 12:54:41 --> URI Class Initialized
INFO - 2023-07-24 12:54:41 --> Router Class Initialized
INFO - 2023-07-24 12:54:41 --> Output Class Initialized
INFO - 2023-07-24 12:54:41 --> Security Class Initialized
DEBUG - 2023-07-24 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:54:41 --> Input Class Initialized
INFO - 2023-07-24 12:54:41 --> Language Class Initialized
INFO - 2023-07-24 12:54:41 --> Loader Class Initialized
INFO - 2023-07-24 12:54:41 --> Helper loaded: url_helper
INFO - 2023-07-24 12:54:41 --> Helper loaded: file_helper
INFO - 2023-07-24 12:54:41 --> Helper loaded: html_helper
INFO - 2023-07-24 12:54:41 --> Helper loaded: text_helper
INFO - 2023-07-24 12:54:41 --> Helper loaded: form_helper
INFO - 2023-07-24 12:54:41 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:54:41 --> Helper loaded: security_helper
INFO - 2023-07-24 12:54:41 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:54:41 --> Database Driver Class Initialized
INFO - 2023-07-24 12:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:54:41 --> Parser Class Initialized
INFO - 2023-07-24 12:54:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:54:41 --> Pagination Class Initialized
INFO - 2023-07-24 12:54:41 --> Form Validation Class Initialized
INFO - 2023-07-24 12:54:41 --> Controller Class Initialized
DEBUG - 2023-07-24 12:54:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:41 --> Model Class Initialized
DEBUG - 2023-07-24 12:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:41 --> Model Class Initialized
DEBUG - 2023-07-24 12:54:41 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:41 --> Model Class Initialized
INFO - 2023-07-24 12:54:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-24 12:54:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:54:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:54:41 --> Model Class Initialized
INFO - 2023-07-24 12:54:41 --> Model Class Initialized
INFO - 2023-07-24 12:54:41 --> Model Class Initialized
INFO - 2023-07-24 12:54:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:54:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:54:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:54:41 --> Final output sent to browser
DEBUG - 2023-07-24 12:54:41 --> Total execution time: 0.1424
ERROR - 2023-07-24 12:54:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:54:42 --> Config Class Initialized
INFO - 2023-07-24 12:54:42 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:54:42 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:54:42 --> Utf8 Class Initialized
INFO - 2023-07-24 12:54:42 --> URI Class Initialized
INFO - 2023-07-24 12:54:42 --> Router Class Initialized
INFO - 2023-07-24 12:54:42 --> Output Class Initialized
INFO - 2023-07-24 12:54:42 --> Security Class Initialized
DEBUG - 2023-07-24 12:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:54:42 --> Input Class Initialized
INFO - 2023-07-24 12:54:42 --> Language Class Initialized
INFO - 2023-07-24 12:54:42 --> Loader Class Initialized
INFO - 2023-07-24 12:54:42 --> Helper loaded: url_helper
INFO - 2023-07-24 12:54:42 --> Helper loaded: file_helper
INFO - 2023-07-24 12:54:42 --> Helper loaded: html_helper
INFO - 2023-07-24 12:54:42 --> Helper loaded: text_helper
INFO - 2023-07-24 12:54:42 --> Helper loaded: form_helper
INFO - 2023-07-24 12:54:42 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:54:42 --> Helper loaded: security_helper
INFO - 2023-07-24 12:54:42 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:54:42 --> Database Driver Class Initialized
INFO - 2023-07-24 12:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:54:42 --> Parser Class Initialized
INFO - 2023-07-24 12:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:54:42 --> Pagination Class Initialized
INFO - 2023-07-24 12:54:42 --> Form Validation Class Initialized
INFO - 2023-07-24 12:54:42 --> Controller Class Initialized
DEBUG - 2023-07-24 12:54:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:42 --> Model Class Initialized
DEBUG - 2023-07-24 12:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:42 --> Model Class Initialized
INFO - 2023-07-24 12:54:42 --> Final output sent to browser
DEBUG - 2023-07-24 12:54:42 --> Total execution time: 0.0321
ERROR - 2023-07-24 12:54:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:54:45 --> Config Class Initialized
INFO - 2023-07-24 12:54:45 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:54:45 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:54:45 --> Utf8 Class Initialized
INFO - 2023-07-24 12:54:45 --> URI Class Initialized
INFO - 2023-07-24 12:54:45 --> Router Class Initialized
INFO - 2023-07-24 12:54:45 --> Output Class Initialized
INFO - 2023-07-24 12:54:45 --> Security Class Initialized
DEBUG - 2023-07-24 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:54:45 --> Input Class Initialized
INFO - 2023-07-24 12:54:45 --> Language Class Initialized
INFO - 2023-07-24 12:54:45 --> Loader Class Initialized
INFO - 2023-07-24 12:54:45 --> Helper loaded: url_helper
INFO - 2023-07-24 12:54:45 --> Helper loaded: file_helper
INFO - 2023-07-24 12:54:45 --> Helper loaded: html_helper
INFO - 2023-07-24 12:54:45 --> Helper loaded: text_helper
INFO - 2023-07-24 12:54:45 --> Helper loaded: form_helper
INFO - 2023-07-24 12:54:45 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:54:45 --> Helper loaded: security_helper
INFO - 2023-07-24 12:54:45 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:54:45 --> Database Driver Class Initialized
INFO - 2023-07-24 12:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:54:45 --> Parser Class Initialized
INFO - 2023-07-24 12:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:54:45 --> Pagination Class Initialized
INFO - 2023-07-24 12:54:45 --> Form Validation Class Initialized
INFO - 2023-07-24 12:54:45 --> Controller Class Initialized
DEBUG - 2023-07-24 12:54:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:45 --> Model Class Initialized
DEBUG - 2023-07-24 12:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:54:45 --> Model Class Initialized
INFO - 2023-07-24 12:54:46 --> Final output sent to browser
DEBUG - 2023-07-24 12:54:46 --> Total execution time: 0.1311
ERROR - 2023-07-24 12:55:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:55:18 --> Config Class Initialized
INFO - 2023-07-24 12:55:18 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:55:18 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:55:18 --> Utf8 Class Initialized
INFO - 2023-07-24 12:55:18 --> URI Class Initialized
INFO - 2023-07-24 12:55:18 --> Router Class Initialized
INFO - 2023-07-24 12:55:18 --> Output Class Initialized
INFO - 2023-07-24 12:55:18 --> Security Class Initialized
DEBUG - 2023-07-24 12:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:55:18 --> Input Class Initialized
INFO - 2023-07-24 12:55:18 --> Language Class Initialized
INFO - 2023-07-24 12:55:18 --> Loader Class Initialized
INFO - 2023-07-24 12:55:18 --> Helper loaded: url_helper
INFO - 2023-07-24 12:55:18 --> Helper loaded: file_helper
INFO - 2023-07-24 12:55:18 --> Helper loaded: html_helper
INFO - 2023-07-24 12:55:18 --> Helper loaded: text_helper
INFO - 2023-07-24 12:55:18 --> Helper loaded: form_helper
INFO - 2023-07-24 12:55:18 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:55:18 --> Helper loaded: security_helper
INFO - 2023-07-24 12:55:18 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:55:18 --> Database Driver Class Initialized
INFO - 2023-07-24 12:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:55:18 --> Parser Class Initialized
INFO - 2023-07-24 12:55:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:55:18 --> Pagination Class Initialized
INFO - 2023-07-24 12:55:18 --> Form Validation Class Initialized
INFO - 2023-07-24 12:55:18 --> Controller Class Initialized
DEBUG - 2023-07-24 12:55:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:18 --> Model Class Initialized
DEBUG - 2023-07-24 12:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:18 --> Model Class Initialized
INFO - 2023-07-24 12:55:18 --> Final output sent to browser
DEBUG - 2023-07-24 12:55:18 --> Total execution time: 0.0197
ERROR - 2023-07-24 12:55:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:55:23 --> Config Class Initialized
INFO - 2023-07-24 12:55:23 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:55:23 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:55:23 --> Utf8 Class Initialized
INFO - 2023-07-24 12:55:23 --> URI Class Initialized
INFO - 2023-07-24 12:55:23 --> Router Class Initialized
INFO - 2023-07-24 12:55:23 --> Output Class Initialized
INFO - 2023-07-24 12:55:23 --> Security Class Initialized
DEBUG - 2023-07-24 12:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:55:23 --> Input Class Initialized
INFO - 2023-07-24 12:55:23 --> Language Class Initialized
INFO - 2023-07-24 12:55:23 --> Loader Class Initialized
INFO - 2023-07-24 12:55:23 --> Helper loaded: url_helper
INFO - 2023-07-24 12:55:23 --> Helper loaded: file_helper
INFO - 2023-07-24 12:55:23 --> Helper loaded: html_helper
INFO - 2023-07-24 12:55:23 --> Helper loaded: text_helper
INFO - 2023-07-24 12:55:23 --> Helper loaded: form_helper
INFO - 2023-07-24 12:55:23 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:55:23 --> Helper loaded: security_helper
INFO - 2023-07-24 12:55:23 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:55:23 --> Database Driver Class Initialized
INFO - 2023-07-24 12:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:55:23 --> Parser Class Initialized
INFO - 2023-07-24 12:55:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:55:23 --> Pagination Class Initialized
INFO - 2023-07-24 12:55:23 --> Form Validation Class Initialized
INFO - 2023-07-24 12:55:23 --> Controller Class Initialized
DEBUG - 2023-07-24 12:55:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:23 --> Model Class Initialized
DEBUG - 2023-07-24 12:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:23 --> Model Class Initialized
INFO - 2023-07-24 12:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-24 12:55:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:55:23 --> Model Class Initialized
INFO - 2023-07-24 12:55:23 --> Model Class Initialized
INFO - 2023-07-24 12:55:23 --> Model Class Initialized
INFO - 2023-07-24 12:55:23 --> Model Class Initialized
INFO - 2023-07-24 12:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:55:23 --> Final output sent to browser
DEBUG - 2023-07-24 12:55:23 --> Total execution time: 0.1598
ERROR - 2023-07-24 12:55:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:55:43 --> Config Class Initialized
INFO - 2023-07-24 12:55:43 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:55:43 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:55:43 --> Utf8 Class Initialized
INFO - 2023-07-24 12:55:43 --> URI Class Initialized
INFO - 2023-07-24 12:55:43 --> Router Class Initialized
INFO - 2023-07-24 12:55:43 --> Output Class Initialized
INFO - 2023-07-24 12:55:43 --> Security Class Initialized
DEBUG - 2023-07-24 12:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:55:43 --> Input Class Initialized
INFO - 2023-07-24 12:55:43 --> Language Class Initialized
INFO - 2023-07-24 12:55:43 --> Loader Class Initialized
INFO - 2023-07-24 12:55:43 --> Helper loaded: url_helper
INFO - 2023-07-24 12:55:43 --> Helper loaded: file_helper
INFO - 2023-07-24 12:55:43 --> Helper loaded: html_helper
INFO - 2023-07-24 12:55:43 --> Helper loaded: text_helper
INFO - 2023-07-24 12:55:43 --> Helper loaded: form_helper
INFO - 2023-07-24 12:55:43 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:55:43 --> Helper loaded: security_helper
INFO - 2023-07-24 12:55:43 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:55:43 --> Database Driver Class Initialized
INFO - 2023-07-24 12:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:55:43 --> Parser Class Initialized
INFO - 2023-07-24 12:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:55:43 --> Pagination Class Initialized
INFO - 2023-07-24 12:55:43 --> Form Validation Class Initialized
INFO - 2023-07-24 12:55:43 --> Controller Class Initialized
DEBUG - 2023-07-24 12:55:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:43 --> Model Class Initialized
DEBUG - 2023-07-24 12:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:43 --> Model Class Initialized
DEBUG - 2023-07-24 12:55:43 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:43 --> Model Class Initialized
INFO - 2023-07-24 12:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-24 12:55:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:55:43 --> Model Class Initialized
INFO - 2023-07-24 12:55:43 --> Model Class Initialized
INFO - 2023-07-24 12:55:43 --> Model Class Initialized
INFO - 2023-07-24 12:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:55:43 --> Final output sent to browser
DEBUG - 2023-07-24 12:55:43 --> Total execution time: 0.1647
ERROR - 2023-07-24 12:55:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:55:44 --> Config Class Initialized
INFO - 2023-07-24 12:55:44 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:55:44 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:55:44 --> Utf8 Class Initialized
INFO - 2023-07-24 12:55:44 --> URI Class Initialized
INFO - 2023-07-24 12:55:44 --> Router Class Initialized
INFO - 2023-07-24 12:55:44 --> Output Class Initialized
INFO - 2023-07-24 12:55:44 --> Security Class Initialized
DEBUG - 2023-07-24 12:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:55:44 --> Input Class Initialized
INFO - 2023-07-24 12:55:44 --> Language Class Initialized
INFO - 2023-07-24 12:55:44 --> Loader Class Initialized
INFO - 2023-07-24 12:55:44 --> Helper loaded: url_helper
INFO - 2023-07-24 12:55:44 --> Helper loaded: file_helper
INFO - 2023-07-24 12:55:44 --> Helper loaded: html_helper
INFO - 2023-07-24 12:55:44 --> Helper loaded: text_helper
INFO - 2023-07-24 12:55:44 --> Helper loaded: form_helper
INFO - 2023-07-24 12:55:44 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:55:44 --> Helper loaded: security_helper
INFO - 2023-07-24 12:55:44 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:55:44 --> Database Driver Class Initialized
INFO - 2023-07-24 12:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:55:44 --> Parser Class Initialized
INFO - 2023-07-24 12:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:55:44 --> Pagination Class Initialized
INFO - 2023-07-24 12:55:44 --> Form Validation Class Initialized
INFO - 2023-07-24 12:55:44 --> Controller Class Initialized
DEBUG - 2023-07-24 12:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:44 --> Model Class Initialized
DEBUG - 2023-07-24 12:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:44 --> Model Class Initialized
INFO - 2023-07-24 12:55:44 --> Final output sent to browser
DEBUG - 2023-07-24 12:55:44 --> Total execution time: 0.0297
ERROR - 2023-07-24 12:55:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:55:47 --> Config Class Initialized
INFO - 2023-07-24 12:55:47 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:55:47 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:55:47 --> Utf8 Class Initialized
INFO - 2023-07-24 12:55:47 --> URI Class Initialized
INFO - 2023-07-24 12:55:47 --> Router Class Initialized
INFO - 2023-07-24 12:55:47 --> Output Class Initialized
INFO - 2023-07-24 12:55:47 --> Security Class Initialized
DEBUG - 2023-07-24 12:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:55:47 --> Input Class Initialized
INFO - 2023-07-24 12:55:47 --> Language Class Initialized
INFO - 2023-07-24 12:55:47 --> Loader Class Initialized
INFO - 2023-07-24 12:55:47 --> Helper loaded: url_helper
INFO - 2023-07-24 12:55:47 --> Helper loaded: file_helper
INFO - 2023-07-24 12:55:47 --> Helper loaded: html_helper
INFO - 2023-07-24 12:55:47 --> Helper loaded: text_helper
INFO - 2023-07-24 12:55:47 --> Helper loaded: form_helper
INFO - 2023-07-24 12:55:47 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:55:47 --> Helper loaded: security_helper
INFO - 2023-07-24 12:55:47 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:55:47 --> Database Driver Class Initialized
INFO - 2023-07-24 12:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:55:47 --> Parser Class Initialized
INFO - 2023-07-24 12:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:55:47 --> Pagination Class Initialized
INFO - 2023-07-24 12:55:47 --> Form Validation Class Initialized
INFO - 2023-07-24 12:55:47 --> Controller Class Initialized
DEBUG - 2023-07-24 12:55:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:47 --> Model Class Initialized
DEBUG - 2023-07-24 12:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:55:47 --> Model Class Initialized
INFO - 2023-07-24 12:55:47 --> Final output sent to browser
DEBUG - 2023-07-24 12:55:47 --> Total execution time: 0.1436
ERROR - 2023-07-24 12:56:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:56:27 --> Config Class Initialized
INFO - 2023-07-24 12:56:27 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:56:27 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:56:27 --> Utf8 Class Initialized
INFO - 2023-07-24 12:56:27 --> URI Class Initialized
INFO - 2023-07-24 12:56:27 --> Router Class Initialized
INFO - 2023-07-24 12:56:27 --> Output Class Initialized
INFO - 2023-07-24 12:56:27 --> Security Class Initialized
DEBUG - 2023-07-24 12:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:56:27 --> Input Class Initialized
INFO - 2023-07-24 12:56:27 --> Language Class Initialized
INFO - 2023-07-24 12:56:27 --> Loader Class Initialized
INFO - 2023-07-24 12:56:27 --> Helper loaded: url_helper
INFO - 2023-07-24 12:56:27 --> Helper loaded: file_helper
INFO - 2023-07-24 12:56:27 --> Helper loaded: html_helper
INFO - 2023-07-24 12:56:27 --> Helper loaded: text_helper
INFO - 2023-07-24 12:56:27 --> Helper loaded: form_helper
INFO - 2023-07-24 12:56:27 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:56:27 --> Helper loaded: security_helper
INFO - 2023-07-24 12:56:27 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:56:27 --> Database Driver Class Initialized
INFO - 2023-07-24 12:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:56:27 --> Parser Class Initialized
INFO - 2023-07-24 12:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:56:27 --> Pagination Class Initialized
INFO - 2023-07-24 12:56:27 --> Form Validation Class Initialized
INFO - 2023-07-24 12:56:27 --> Controller Class Initialized
DEBUG - 2023-07-24 12:56:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:27 --> Model Class Initialized
DEBUG - 2023-07-24 12:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:27 --> Model Class Initialized
INFO - 2023-07-24 12:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-24 12:56:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:56:27 --> Model Class Initialized
INFO - 2023-07-24 12:56:27 --> Model Class Initialized
INFO - 2023-07-24 12:56:27 --> Model Class Initialized
INFO - 2023-07-24 12:56:27 --> Model Class Initialized
INFO - 2023-07-24 12:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:56:27 --> Final output sent to browser
DEBUG - 2023-07-24 12:56:27 --> Total execution time: 0.1621
ERROR - 2023-07-24 12:56:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:56:32 --> Config Class Initialized
INFO - 2023-07-24 12:56:32 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:56:32 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:56:32 --> Utf8 Class Initialized
INFO - 2023-07-24 12:56:32 --> URI Class Initialized
INFO - 2023-07-24 12:56:32 --> Router Class Initialized
INFO - 2023-07-24 12:56:32 --> Output Class Initialized
INFO - 2023-07-24 12:56:32 --> Security Class Initialized
DEBUG - 2023-07-24 12:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:56:32 --> Input Class Initialized
INFO - 2023-07-24 12:56:32 --> Language Class Initialized
INFO - 2023-07-24 12:56:32 --> Loader Class Initialized
INFO - 2023-07-24 12:56:32 --> Helper loaded: url_helper
INFO - 2023-07-24 12:56:32 --> Helper loaded: file_helper
INFO - 2023-07-24 12:56:32 --> Helper loaded: html_helper
INFO - 2023-07-24 12:56:32 --> Helper loaded: text_helper
INFO - 2023-07-24 12:56:32 --> Helper loaded: form_helper
INFO - 2023-07-24 12:56:32 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:56:32 --> Helper loaded: security_helper
INFO - 2023-07-24 12:56:32 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:56:32 --> Database Driver Class Initialized
INFO - 2023-07-24 12:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:56:32 --> Parser Class Initialized
INFO - 2023-07-24 12:56:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:56:32 --> Pagination Class Initialized
INFO - 2023-07-24 12:56:32 --> Form Validation Class Initialized
INFO - 2023-07-24 12:56:32 --> Controller Class Initialized
DEBUG - 2023-07-24 12:56:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:32 --> Model Class Initialized
DEBUG - 2023-07-24 12:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:32 --> Model Class Initialized
DEBUG - 2023-07-24 12:56:32 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:32 --> Model Class Initialized
INFO - 2023-07-24 12:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-24 12:56:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:56:32 --> Model Class Initialized
INFO - 2023-07-24 12:56:32 --> Model Class Initialized
INFO - 2023-07-24 12:56:32 --> Model Class Initialized
INFO - 2023-07-24 12:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:56:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:56:32 --> Final output sent to browser
DEBUG - 2023-07-24 12:56:32 --> Total execution time: 0.1585
ERROR - 2023-07-24 12:56:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:56:33 --> Config Class Initialized
INFO - 2023-07-24 12:56:33 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:56:33 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:56:33 --> Utf8 Class Initialized
INFO - 2023-07-24 12:56:33 --> URI Class Initialized
INFO - 2023-07-24 12:56:33 --> Router Class Initialized
INFO - 2023-07-24 12:56:33 --> Output Class Initialized
INFO - 2023-07-24 12:56:33 --> Security Class Initialized
DEBUG - 2023-07-24 12:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:56:33 --> Input Class Initialized
INFO - 2023-07-24 12:56:33 --> Language Class Initialized
INFO - 2023-07-24 12:56:33 --> Loader Class Initialized
INFO - 2023-07-24 12:56:33 --> Helper loaded: url_helper
INFO - 2023-07-24 12:56:33 --> Helper loaded: file_helper
INFO - 2023-07-24 12:56:33 --> Helper loaded: html_helper
INFO - 2023-07-24 12:56:33 --> Helper loaded: text_helper
INFO - 2023-07-24 12:56:33 --> Helper loaded: form_helper
INFO - 2023-07-24 12:56:33 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:56:33 --> Helper loaded: security_helper
INFO - 2023-07-24 12:56:33 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:56:33 --> Database Driver Class Initialized
INFO - 2023-07-24 12:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:56:33 --> Parser Class Initialized
INFO - 2023-07-24 12:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:56:33 --> Pagination Class Initialized
INFO - 2023-07-24 12:56:33 --> Form Validation Class Initialized
INFO - 2023-07-24 12:56:33 --> Controller Class Initialized
DEBUG - 2023-07-24 12:56:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:33 --> Model Class Initialized
DEBUG - 2023-07-24 12:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:33 --> Model Class Initialized
INFO - 2023-07-24 12:56:33 --> Final output sent to browser
DEBUG - 2023-07-24 12:56:33 --> Total execution time: 0.0553
ERROR - 2023-07-24 12:56:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:56:35 --> Config Class Initialized
INFO - 2023-07-24 12:56:35 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:56:35 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:56:35 --> Utf8 Class Initialized
INFO - 2023-07-24 12:56:35 --> URI Class Initialized
INFO - 2023-07-24 12:56:35 --> Router Class Initialized
INFO - 2023-07-24 12:56:35 --> Output Class Initialized
INFO - 2023-07-24 12:56:35 --> Security Class Initialized
DEBUG - 2023-07-24 12:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:56:35 --> Input Class Initialized
INFO - 2023-07-24 12:56:35 --> Language Class Initialized
INFO - 2023-07-24 12:56:35 --> Loader Class Initialized
INFO - 2023-07-24 12:56:35 --> Helper loaded: url_helper
INFO - 2023-07-24 12:56:35 --> Helper loaded: file_helper
INFO - 2023-07-24 12:56:35 --> Helper loaded: html_helper
INFO - 2023-07-24 12:56:35 --> Helper loaded: text_helper
INFO - 2023-07-24 12:56:35 --> Helper loaded: form_helper
INFO - 2023-07-24 12:56:35 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:56:35 --> Helper loaded: security_helper
INFO - 2023-07-24 12:56:35 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:56:35 --> Database Driver Class Initialized
INFO - 2023-07-24 12:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:56:35 --> Parser Class Initialized
INFO - 2023-07-24 12:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:56:35 --> Pagination Class Initialized
INFO - 2023-07-24 12:56:35 --> Form Validation Class Initialized
INFO - 2023-07-24 12:56:35 --> Controller Class Initialized
DEBUG - 2023-07-24 12:56:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:35 --> Model Class Initialized
DEBUG - 2023-07-24 12:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:56:35 --> Model Class Initialized
INFO - 2023-07-24 12:56:36 --> Final output sent to browser
DEBUG - 2023-07-24 12:56:36 --> Total execution time: 0.1363
ERROR - 2023-07-24 12:58:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:58:13 --> Config Class Initialized
INFO - 2023-07-24 12:58:13 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:58:13 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:58:13 --> Utf8 Class Initialized
INFO - 2023-07-24 12:58:13 --> URI Class Initialized
INFO - 2023-07-24 12:58:13 --> Router Class Initialized
INFO - 2023-07-24 12:58:13 --> Output Class Initialized
INFO - 2023-07-24 12:58:13 --> Security Class Initialized
DEBUG - 2023-07-24 12:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:58:13 --> Input Class Initialized
INFO - 2023-07-24 12:58:13 --> Language Class Initialized
INFO - 2023-07-24 12:58:13 --> Loader Class Initialized
INFO - 2023-07-24 12:58:13 --> Helper loaded: url_helper
INFO - 2023-07-24 12:58:13 --> Helper loaded: file_helper
INFO - 2023-07-24 12:58:13 --> Helper loaded: html_helper
INFO - 2023-07-24 12:58:13 --> Helper loaded: text_helper
INFO - 2023-07-24 12:58:13 --> Helper loaded: form_helper
INFO - 2023-07-24 12:58:13 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:58:13 --> Helper loaded: security_helper
INFO - 2023-07-24 12:58:13 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:58:13 --> Database Driver Class Initialized
INFO - 2023-07-24 12:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:58:13 --> Parser Class Initialized
INFO - 2023-07-24 12:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:58:13 --> Pagination Class Initialized
INFO - 2023-07-24 12:58:13 --> Form Validation Class Initialized
INFO - 2023-07-24 12:58:13 --> Controller Class Initialized
DEBUG - 2023-07-24 12:58:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:13 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:13 --> Model Class Initialized
INFO - 2023-07-24 12:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-07-24 12:58:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:58:13 --> Model Class Initialized
INFO - 2023-07-24 12:58:13 --> Model Class Initialized
INFO - 2023-07-24 12:58:13 --> Model Class Initialized
INFO - 2023-07-24 12:58:13 --> Model Class Initialized
INFO - 2023-07-24 12:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:58:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:58:13 --> Final output sent to browser
DEBUG - 2023-07-24 12:58:13 --> Total execution time: 0.1763
ERROR - 2023-07-24 12:58:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:58:33 --> Config Class Initialized
INFO - 2023-07-24 12:58:33 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:58:33 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:58:33 --> Utf8 Class Initialized
INFO - 2023-07-24 12:58:33 --> URI Class Initialized
INFO - 2023-07-24 12:58:33 --> Router Class Initialized
INFO - 2023-07-24 12:58:33 --> Output Class Initialized
INFO - 2023-07-24 12:58:33 --> Security Class Initialized
DEBUG - 2023-07-24 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:58:33 --> Input Class Initialized
INFO - 2023-07-24 12:58:33 --> Language Class Initialized
INFO - 2023-07-24 12:58:33 --> Loader Class Initialized
INFO - 2023-07-24 12:58:33 --> Helper loaded: url_helper
INFO - 2023-07-24 12:58:33 --> Helper loaded: file_helper
INFO - 2023-07-24 12:58:33 --> Helper loaded: html_helper
INFO - 2023-07-24 12:58:33 --> Helper loaded: text_helper
INFO - 2023-07-24 12:58:33 --> Helper loaded: form_helper
INFO - 2023-07-24 12:58:33 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:58:33 --> Helper loaded: security_helper
INFO - 2023-07-24 12:58:33 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:58:33 --> Database Driver Class Initialized
INFO - 2023-07-24 12:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:58:33 --> Parser Class Initialized
INFO - 2023-07-24 12:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:58:33 --> Pagination Class Initialized
INFO - 2023-07-24 12:58:33 --> Form Validation Class Initialized
INFO - 2023-07-24 12:58:33 --> Controller Class Initialized
INFO - 2023-07-24 12:58:33 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:33 --> Model Class Initialized
INFO - 2023-07-24 12:58:33 --> Final output sent to browser
DEBUG - 2023-07-24 12:58:33 --> Total execution time: 0.0198
ERROR - 2023-07-24 12:58:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:58:34 --> Config Class Initialized
INFO - 2023-07-24 12:58:34 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:58:34 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:58:34 --> Utf8 Class Initialized
INFO - 2023-07-24 12:58:34 --> URI Class Initialized
DEBUG - 2023-07-24 12:58:34 --> No URI present. Default controller set.
INFO - 2023-07-24 12:58:34 --> Router Class Initialized
INFO - 2023-07-24 12:58:34 --> Output Class Initialized
INFO - 2023-07-24 12:58:34 --> Security Class Initialized
DEBUG - 2023-07-24 12:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:58:34 --> Input Class Initialized
INFO - 2023-07-24 12:58:34 --> Language Class Initialized
INFO - 2023-07-24 12:58:34 --> Loader Class Initialized
INFO - 2023-07-24 12:58:34 --> Helper loaded: url_helper
INFO - 2023-07-24 12:58:34 --> Helper loaded: file_helper
INFO - 2023-07-24 12:58:34 --> Helper loaded: html_helper
INFO - 2023-07-24 12:58:34 --> Helper loaded: text_helper
INFO - 2023-07-24 12:58:34 --> Helper loaded: form_helper
INFO - 2023-07-24 12:58:34 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:58:34 --> Helper loaded: security_helper
INFO - 2023-07-24 12:58:34 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:58:34 --> Database Driver Class Initialized
INFO - 2023-07-24 12:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:58:34 --> Parser Class Initialized
INFO - 2023-07-24 12:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:58:34 --> Pagination Class Initialized
INFO - 2023-07-24 12:58:34 --> Form Validation Class Initialized
INFO - 2023-07-24 12:58:34 --> Controller Class Initialized
INFO - 2023-07-24 12:58:34 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:34 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:34 --> Model Class Initialized
INFO - 2023-07-24 12:58:34 --> Model Class Initialized
INFO - 2023-07-24 12:58:34 --> Model Class Initialized
INFO - 2023-07-24 12:58:34 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:34 --> Model Class Initialized
INFO - 2023-07-24 12:58:34 --> Model Class Initialized
INFO - 2023-07-24 12:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 12:58:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:58:34 --> Model Class Initialized
INFO - 2023-07-24 12:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:58:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:58:34 --> Final output sent to browser
DEBUG - 2023-07-24 12:58:34 --> Total execution time: 0.0820
ERROR - 2023-07-24 12:58:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:58:46 --> Config Class Initialized
INFO - 2023-07-24 12:58:46 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:58:46 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:58:46 --> Utf8 Class Initialized
INFO - 2023-07-24 12:58:46 --> URI Class Initialized
INFO - 2023-07-24 12:58:46 --> Router Class Initialized
INFO - 2023-07-24 12:58:46 --> Output Class Initialized
INFO - 2023-07-24 12:58:46 --> Security Class Initialized
DEBUG - 2023-07-24 12:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:58:46 --> Input Class Initialized
INFO - 2023-07-24 12:58:46 --> Language Class Initialized
INFO - 2023-07-24 12:58:46 --> Loader Class Initialized
INFO - 2023-07-24 12:58:46 --> Helper loaded: url_helper
INFO - 2023-07-24 12:58:46 --> Helper loaded: file_helper
INFO - 2023-07-24 12:58:46 --> Helper loaded: html_helper
INFO - 2023-07-24 12:58:46 --> Helper loaded: text_helper
INFO - 2023-07-24 12:58:46 --> Helper loaded: form_helper
INFO - 2023-07-24 12:58:46 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:58:46 --> Helper loaded: security_helper
INFO - 2023-07-24 12:58:46 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:58:46 --> Database Driver Class Initialized
INFO - 2023-07-24 12:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:58:46 --> Parser Class Initialized
INFO - 2023-07-24 12:58:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:58:46 --> Pagination Class Initialized
INFO - 2023-07-24 12:58:46 --> Form Validation Class Initialized
INFO - 2023-07-24 12:58:46 --> Controller Class Initialized
INFO - 2023-07-24 12:58:46 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:46 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:46 --> Model Class Initialized
INFO - 2023-07-24 12:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 12:58:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:58:46 --> Model Class Initialized
INFO - 2023-07-24 12:58:46 --> Model Class Initialized
INFO - 2023-07-24 12:58:46 --> Model Class Initialized
INFO - 2023-07-24 12:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:58:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:58:46 --> Final output sent to browser
DEBUG - 2023-07-24 12:58:46 --> Total execution time: 0.0720
ERROR - 2023-07-24 12:58:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:58:47 --> Config Class Initialized
INFO - 2023-07-24 12:58:47 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:58:47 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:58:47 --> Utf8 Class Initialized
INFO - 2023-07-24 12:58:47 --> URI Class Initialized
INFO - 2023-07-24 12:58:47 --> Router Class Initialized
INFO - 2023-07-24 12:58:47 --> Output Class Initialized
INFO - 2023-07-24 12:58:47 --> Security Class Initialized
DEBUG - 2023-07-24 12:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:58:47 --> Input Class Initialized
INFO - 2023-07-24 12:58:47 --> Language Class Initialized
INFO - 2023-07-24 12:58:47 --> Loader Class Initialized
INFO - 2023-07-24 12:58:47 --> Helper loaded: url_helper
INFO - 2023-07-24 12:58:47 --> Helper loaded: file_helper
INFO - 2023-07-24 12:58:47 --> Helper loaded: html_helper
INFO - 2023-07-24 12:58:47 --> Helper loaded: text_helper
INFO - 2023-07-24 12:58:47 --> Helper loaded: form_helper
INFO - 2023-07-24 12:58:47 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:58:47 --> Helper loaded: security_helper
INFO - 2023-07-24 12:58:47 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:58:47 --> Database Driver Class Initialized
INFO - 2023-07-24 12:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:58:47 --> Parser Class Initialized
INFO - 2023-07-24 12:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:58:47 --> Pagination Class Initialized
INFO - 2023-07-24 12:58:47 --> Form Validation Class Initialized
INFO - 2023-07-24 12:58:47 --> Controller Class Initialized
INFO - 2023-07-24 12:58:47 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:47 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:47 --> Model Class Initialized
INFO - 2023-07-24 12:58:47 --> Final output sent to browser
DEBUG - 2023-07-24 12:58:47 --> Total execution time: 0.0265
ERROR - 2023-07-24 12:58:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:58:54 --> Config Class Initialized
INFO - 2023-07-24 12:58:54 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:58:54 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:58:54 --> Utf8 Class Initialized
INFO - 2023-07-24 12:58:54 --> URI Class Initialized
INFO - 2023-07-24 12:58:54 --> Router Class Initialized
INFO - 2023-07-24 12:58:54 --> Output Class Initialized
INFO - 2023-07-24 12:58:54 --> Security Class Initialized
DEBUG - 2023-07-24 12:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:58:54 --> Input Class Initialized
INFO - 2023-07-24 12:58:54 --> Language Class Initialized
INFO - 2023-07-24 12:58:54 --> Loader Class Initialized
INFO - 2023-07-24 12:58:54 --> Helper loaded: url_helper
INFO - 2023-07-24 12:58:54 --> Helper loaded: file_helper
INFO - 2023-07-24 12:58:54 --> Helper loaded: html_helper
INFO - 2023-07-24 12:58:54 --> Helper loaded: text_helper
INFO - 2023-07-24 12:58:54 --> Helper loaded: form_helper
INFO - 2023-07-24 12:58:54 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:58:54 --> Helper loaded: security_helper
INFO - 2023-07-24 12:58:54 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:58:54 --> Database Driver Class Initialized
INFO - 2023-07-24 12:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:58:54 --> Parser Class Initialized
INFO - 2023-07-24 12:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:58:54 --> Pagination Class Initialized
INFO - 2023-07-24 12:58:54 --> Form Validation Class Initialized
INFO - 2023-07-24 12:58:54 --> Controller Class Initialized
INFO - 2023-07-24 12:58:54 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:54 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:54 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-24 12:58:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:58:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:58:54 --> Model Class Initialized
INFO - 2023-07-24 12:58:54 --> Model Class Initialized
INFO - 2023-07-24 12:58:54 --> Model Class Initialized
INFO - 2023-07-24 12:58:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:58:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:58:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:58:54 --> Final output sent to browser
DEBUG - 2023-07-24 12:58:54 --> Total execution time: 0.0766
ERROR - 2023-07-24 12:58:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:58:58 --> Config Class Initialized
INFO - 2023-07-24 12:58:58 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:58:58 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:58:58 --> Utf8 Class Initialized
INFO - 2023-07-24 12:58:58 --> URI Class Initialized
INFO - 2023-07-24 12:58:58 --> Router Class Initialized
INFO - 2023-07-24 12:58:58 --> Output Class Initialized
INFO - 2023-07-24 12:58:58 --> Security Class Initialized
DEBUG - 2023-07-24 12:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:58:58 --> Input Class Initialized
INFO - 2023-07-24 12:58:58 --> Language Class Initialized
INFO - 2023-07-24 12:58:58 --> Loader Class Initialized
INFO - 2023-07-24 12:58:58 --> Helper loaded: url_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: file_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: html_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: text_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: form_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: security_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:58:58 --> Database Driver Class Initialized
INFO - 2023-07-24 12:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:58:58 --> Parser Class Initialized
INFO - 2023-07-24 12:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:58:58 --> Pagination Class Initialized
INFO - 2023-07-24 12:58:58 --> Form Validation Class Initialized
INFO - 2023-07-24 12:58:58 --> Controller Class Initialized
INFO - 2023-07-24 12:58:58 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:58 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:58 --> Model Class Initialized
INFO - 2023-07-24 12:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 12:58:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:58:58 --> Model Class Initialized
INFO - 2023-07-24 12:58:58 --> Model Class Initialized
INFO - 2023-07-24 12:58:58 --> Model Class Initialized
INFO - 2023-07-24 12:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:58:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:58:58 --> Final output sent to browser
DEBUG - 2023-07-24 12:58:58 --> Total execution time: 0.0843
ERROR - 2023-07-24 12:58:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:58:58 --> Config Class Initialized
INFO - 2023-07-24 12:58:58 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:58:58 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:58:58 --> Utf8 Class Initialized
INFO - 2023-07-24 12:58:58 --> URI Class Initialized
INFO - 2023-07-24 12:58:58 --> Router Class Initialized
INFO - 2023-07-24 12:58:58 --> Output Class Initialized
INFO - 2023-07-24 12:58:58 --> Security Class Initialized
DEBUG - 2023-07-24 12:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:58:58 --> Input Class Initialized
INFO - 2023-07-24 12:58:58 --> Language Class Initialized
INFO - 2023-07-24 12:58:58 --> Loader Class Initialized
INFO - 2023-07-24 12:58:58 --> Helper loaded: url_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: file_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: html_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: text_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: form_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: security_helper
INFO - 2023-07-24 12:58:58 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:58:58 --> Database Driver Class Initialized
INFO - 2023-07-24 12:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:58:58 --> Parser Class Initialized
INFO - 2023-07-24 12:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:58:58 --> Pagination Class Initialized
INFO - 2023-07-24 12:58:58 --> Form Validation Class Initialized
INFO - 2023-07-24 12:58:58 --> Controller Class Initialized
INFO - 2023-07-24 12:58:58 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:58 --> Model Class Initialized
DEBUG - 2023-07-24 12:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:58:58 --> Model Class Initialized
INFO - 2023-07-24 12:58:58 --> Final output sent to browser
DEBUG - 2023-07-24 12:58:58 --> Total execution time: 0.0263
ERROR - 2023-07-24 12:59:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:59:25 --> Config Class Initialized
INFO - 2023-07-24 12:59:25 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:59:25 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:59:25 --> Utf8 Class Initialized
INFO - 2023-07-24 12:59:25 --> URI Class Initialized
INFO - 2023-07-24 12:59:25 --> Router Class Initialized
INFO - 2023-07-24 12:59:25 --> Output Class Initialized
INFO - 2023-07-24 12:59:25 --> Security Class Initialized
DEBUG - 2023-07-24 12:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:59:25 --> Input Class Initialized
INFO - 2023-07-24 12:59:25 --> Language Class Initialized
INFO - 2023-07-24 12:59:25 --> Loader Class Initialized
INFO - 2023-07-24 12:59:25 --> Helper loaded: url_helper
INFO - 2023-07-24 12:59:25 --> Helper loaded: file_helper
INFO - 2023-07-24 12:59:25 --> Helper loaded: html_helper
INFO - 2023-07-24 12:59:25 --> Helper loaded: text_helper
INFO - 2023-07-24 12:59:25 --> Helper loaded: form_helper
INFO - 2023-07-24 12:59:25 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:59:25 --> Helper loaded: security_helper
INFO - 2023-07-24 12:59:25 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:59:25 --> Database Driver Class Initialized
INFO - 2023-07-24 12:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:59:25 --> Parser Class Initialized
INFO - 2023-07-24 12:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:59:25 --> Pagination Class Initialized
INFO - 2023-07-24 12:59:25 --> Form Validation Class Initialized
INFO - 2023-07-24 12:59:25 --> Controller Class Initialized
INFO - 2023-07-24 12:59:25 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:25 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-07-24 12:59:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 12:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 12:59:25 --> Model Class Initialized
INFO - 2023-07-24 12:59:25 --> Model Class Initialized
INFO - 2023-07-24 12:59:25 --> Model Class Initialized
INFO - 2023-07-24 12:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 12:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 12:59:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 12:59:25 --> Final output sent to browser
DEBUG - 2023-07-24 12:59:25 --> Total execution time: 0.0694
ERROR - 2023-07-24 12:59:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:59:29 --> Config Class Initialized
INFO - 2023-07-24 12:59:29 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:59:29 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:59:29 --> Utf8 Class Initialized
INFO - 2023-07-24 12:59:29 --> URI Class Initialized
INFO - 2023-07-24 12:59:29 --> Router Class Initialized
INFO - 2023-07-24 12:59:29 --> Output Class Initialized
INFO - 2023-07-24 12:59:29 --> Security Class Initialized
DEBUG - 2023-07-24 12:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:59:29 --> Input Class Initialized
INFO - 2023-07-24 12:59:29 --> Language Class Initialized
INFO - 2023-07-24 12:59:29 --> Loader Class Initialized
INFO - 2023-07-24 12:59:29 --> Helper loaded: url_helper
INFO - 2023-07-24 12:59:29 --> Helper loaded: file_helper
INFO - 2023-07-24 12:59:29 --> Helper loaded: html_helper
INFO - 2023-07-24 12:59:29 --> Helper loaded: text_helper
INFO - 2023-07-24 12:59:29 --> Helper loaded: form_helper
INFO - 2023-07-24 12:59:29 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:59:29 --> Helper loaded: security_helper
INFO - 2023-07-24 12:59:29 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:59:29 --> Database Driver Class Initialized
INFO - 2023-07-24 12:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:59:29 --> Parser Class Initialized
INFO - 2023-07-24 12:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:59:29 --> Pagination Class Initialized
INFO - 2023-07-24 12:59:29 --> Form Validation Class Initialized
INFO - 2023-07-24 12:59:29 --> Controller Class Initialized
INFO - 2023-07-24 12:59:29 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:29 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:29 --> Model Class Initialized
INFO - 2023-07-24 12:59:29 --> Final output sent to browser
DEBUG - 2023-07-24 12:59:29 --> Total execution time: 0.0189
ERROR - 2023-07-24 12:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:59:30 --> Config Class Initialized
INFO - 2023-07-24 12:59:30 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:59:30 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:59:30 --> Utf8 Class Initialized
INFO - 2023-07-24 12:59:30 --> URI Class Initialized
INFO - 2023-07-24 12:59:30 --> Router Class Initialized
INFO - 2023-07-24 12:59:30 --> Output Class Initialized
INFO - 2023-07-24 12:59:30 --> Security Class Initialized
DEBUG - 2023-07-24 12:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:59:30 --> Input Class Initialized
INFO - 2023-07-24 12:59:30 --> Language Class Initialized
INFO - 2023-07-24 12:59:30 --> Loader Class Initialized
INFO - 2023-07-24 12:59:30 --> Helper loaded: url_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: file_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: html_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: text_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: form_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: security_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:59:30 --> Database Driver Class Initialized
INFO - 2023-07-24 12:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:59:30 --> Parser Class Initialized
INFO - 2023-07-24 12:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:59:30 --> Pagination Class Initialized
INFO - 2023-07-24 12:59:30 --> Form Validation Class Initialized
INFO - 2023-07-24 12:59:30 --> Controller Class Initialized
INFO - 2023-07-24 12:59:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:30 --> Model Class Initialized
INFO - 2023-07-24 12:59:30 --> Final output sent to browser
DEBUG - 2023-07-24 12:59:30 --> Total execution time: 0.0182
ERROR - 2023-07-24 12:59:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:59:30 --> Config Class Initialized
INFO - 2023-07-24 12:59:30 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:59:30 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:59:30 --> Utf8 Class Initialized
INFO - 2023-07-24 12:59:30 --> URI Class Initialized
INFO - 2023-07-24 12:59:30 --> Router Class Initialized
INFO - 2023-07-24 12:59:30 --> Output Class Initialized
INFO - 2023-07-24 12:59:30 --> Security Class Initialized
DEBUG - 2023-07-24 12:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:59:30 --> Input Class Initialized
INFO - 2023-07-24 12:59:30 --> Language Class Initialized
INFO - 2023-07-24 12:59:30 --> Loader Class Initialized
INFO - 2023-07-24 12:59:30 --> Helper loaded: url_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: file_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: html_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: text_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: form_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: security_helper
INFO - 2023-07-24 12:59:30 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:59:30 --> Database Driver Class Initialized
INFO - 2023-07-24 12:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:59:30 --> Parser Class Initialized
INFO - 2023-07-24 12:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:59:30 --> Pagination Class Initialized
INFO - 2023-07-24 12:59:30 --> Form Validation Class Initialized
INFO - 2023-07-24 12:59:30 --> Controller Class Initialized
INFO - 2023-07-24 12:59:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:30 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:30 --> Model Class Initialized
INFO - 2023-07-24 12:59:30 --> Final output sent to browser
DEBUG - 2023-07-24 12:59:30 --> Total execution time: 0.0215
ERROR - 2023-07-24 12:59:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:59:31 --> Config Class Initialized
INFO - 2023-07-24 12:59:31 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:59:31 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:59:31 --> Utf8 Class Initialized
INFO - 2023-07-24 12:59:31 --> URI Class Initialized
INFO - 2023-07-24 12:59:31 --> Router Class Initialized
INFO - 2023-07-24 12:59:31 --> Output Class Initialized
INFO - 2023-07-24 12:59:31 --> Security Class Initialized
DEBUG - 2023-07-24 12:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:59:31 --> Input Class Initialized
INFO - 2023-07-24 12:59:31 --> Language Class Initialized
INFO - 2023-07-24 12:59:31 --> Loader Class Initialized
INFO - 2023-07-24 12:59:31 --> Helper loaded: url_helper
INFO - 2023-07-24 12:59:31 --> Helper loaded: file_helper
INFO - 2023-07-24 12:59:31 --> Helper loaded: html_helper
INFO - 2023-07-24 12:59:31 --> Helper loaded: text_helper
INFO - 2023-07-24 12:59:31 --> Helper loaded: form_helper
INFO - 2023-07-24 12:59:31 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:59:31 --> Helper loaded: security_helper
INFO - 2023-07-24 12:59:31 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:59:31 --> Database Driver Class Initialized
INFO - 2023-07-24 12:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:59:31 --> Parser Class Initialized
INFO - 2023-07-24 12:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:59:31 --> Pagination Class Initialized
INFO - 2023-07-24 12:59:31 --> Form Validation Class Initialized
INFO - 2023-07-24 12:59:31 --> Controller Class Initialized
INFO - 2023-07-24 12:59:31 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:31 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:31 --> Model Class Initialized
INFO - 2023-07-24 12:59:31 --> Final output sent to browser
DEBUG - 2023-07-24 12:59:31 --> Total execution time: 0.0201
ERROR - 2023-07-24 12:59:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 12:59:34 --> Config Class Initialized
INFO - 2023-07-24 12:59:34 --> Hooks Class Initialized
DEBUG - 2023-07-24 12:59:34 --> UTF-8 Support Enabled
INFO - 2023-07-24 12:59:34 --> Utf8 Class Initialized
INFO - 2023-07-24 12:59:34 --> URI Class Initialized
INFO - 2023-07-24 12:59:34 --> Router Class Initialized
INFO - 2023-07-24 12:59:34 --> Output Class Initialized
INFO - 2023-07-24 12:59:34 --> Security Class Initialized
DEBUG - 2023-07-24 12:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 12:59:34 --> Input Class Initialized
INFO - 2023-07-24 12:59:34 --> Language Class Initialized
INFO - 2023-07-24 12:59:34 --> Loader Class Initialized
INFO - 2023-07-24 12:59:34 --> Helper loaded: url_helper
INFO - 2023-07-24 12:59:34 --> Helper loaded: file_helper
INFO - 2023-07-24 12:59:34 --> Helper loaded: html_helper
INFO - 2023-07-24 12:59:34 --> Helper loaded: text_helper
INFO - 2023-07-24 12:59:34 --> Helper loaded: form_helper
INFO - 2023-07-24 12:59:34 --> Helper loaded: lang_helper
INFO - 2023-07-24 12:59:34 --> Helper loaded: security_helper
INFO - 2023-07-24 12:59:34 --> Helper loaded: cookie_helper
INFO - 2023-07-24 12:59:34 --> Database Driver Class Initialized
INFO - 2023-07-24 12:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 12:59:34 --> Parser Class Initialized
INFO - 2023-07-24 12:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 12:59:34 --> Pagination Class Initialized
INFO - 2023-07-24 12:59:34 --> Form Validation Class Initialized
INFO - 2023-07-24 12:59:34 --> Controller Class Initialized
INFO - 2023-07-24 12:59:34 --> Model Class Initialized
DEBUG - 2023-07-24 12:59:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 12:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 12:59:34 --> Model Class Initialized
INFO - 2023-07-24 12:59:34 --> Model Class Initialized
INFO - 2023-07-24 12:59:34 --> Final output sent to browser
DEBUG - 2023-07-24 12:59:34 --> Total execution time: 0.0208
ERROR - 2023-07-24 13:03:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:31 --> Config Class Initialized
INFO - 2023-07-24 13:03:31 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:31 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:31 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:31 --> URI Class Initialized
INFO - 2023-07-24 13:03:31 --> Router Class Initialized
INFO - 2023-07-24 13:03:31 --> Output Class Initialized
INFO - 2023-07-24 13:03:31 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:31 --> Input Class Initialized
INFO - 2023-07-24 13:03:31 --> Language Class Initialized
INFO - 2023-07-24 13:03:31 --> Loader Class Initialized
INFO - 2023-07-24 13:03:31 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:31 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:31 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:31 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:31 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:31 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:31 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:31 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:31 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:31 --> Parser Class Initialized
INFO - 2023-07-24 13:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:31 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:31 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:31 --> Controller Class Initialized
INFO - 2023-07-24 13:03:31 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:31 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:31 --> Model Class Initialized
INFO - 2023-07-24 13:03:31 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:31 --> Total execution time: 0.0222
ERROR - 2023-07-24 13:03:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:32 --> Config Class Initialized
INFO - 2023-07-24 13:03:32 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:32 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:32 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:32 --> URI Class Initialized
INFO - 2023-07-24 13:03:32 --> Router Class Initialized
INFO - 2023-07-24 13:03:32 --> Output Class Initialized
INFO - 2023-07-24 13:03:32 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:32 --> Input Class Initialized
INFO - 2023-07-24 13:03:32 --> Language Class Initialized
INFO - 2023-07-24 13:03:32 --> Loader Class Initialized
INFO - 2023-07-24 13:03:32 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:32 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:32 --> Parser Class Initialized
INFO - 2023-07-24 13:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:32 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:32 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:32 --> Controller Class Initialized
INFO - 2023-07-24 13:03:32 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:32 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:32 --> Model Class Initialized
INFO - 2023-07-24 13:03:32 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:32 --> Total execution time: 0.0224
ERROR - 2023-07-24 13:03:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:32 --> Config Class Initialized
INFO - 2023-07-24 13:03:32 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:32 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:32 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:32 --> URI Class Initialized
INFO - 2023-07-24 13:03:32 --> Router Class Initialized
INFO - 2023-07-24 13:03:32 --> Output Class Initialized
INFO - 2023-07-24 13:03:32 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:32 --> Input Class Initialized
INFO - 2023-07-24 13:03:32 --> Language Class Initialized
INFO - 2023-07-24 13:03:32 --> Loader Class Initialized
INFO - 2023-07-24 13:03:32 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:32 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:32 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:32 --> Parser Class Initialized
INFO - 2023-07-24 13:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:32 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:32 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:32 --> Controller Class Initialized
INFO - 2023-07-24 13:03:32 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:32 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:32 --> Model Class Initialized
INFO - 2023-07-24 13:03:32 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:32 --> Total execution time: 0.0212
ERROR - 2023-07-24 13:03:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:36 --> Config Class Initialized
INFO - 2023-07-24 13:03:36 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:36 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:36 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:36 --> URI Class Initialized
INFO - 2023-07-24 13:03:36 --> Router Class Initialized
INFO - 2023-07-24 13:03:36 --> Output Class Initialized
INFO - 2023-07-24 13:03:36 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:36 --> Input Class Initialized
INFO - 2023-07-24 13:03:36 --> Language Class Initialized
INFO - 2023-07-24 13:03:36 --> Loader Class Initialized
INFO - 2023-07-24 13:03:36 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:36 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:36 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:36 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:36 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:36 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:36 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:36 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:36 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:36 --> Parser Class Initialized
INFO - 2023-07-24 13:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:36 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:36 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:36 --> Controller Class Initialized
INFO - 2023-07-24 13:03:36 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:36 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:36 --> Model Class Initialized
INFO - 2023-07-24 13:03:36 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:36 --> Total execution time: 0.0177
ERROR - 2023-07-24 13:03:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:38 --> Config Class Initialized
INFO - 2023-07-24 13:03:38 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:38 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:38 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:38 --> URI Class Initialized
INFO - 2023-07-24 13:03:38 --> Router Class Initialized
INFO - 2023-07-24 13:03:38 --> Output Class Initialized
INFO - 2023-07-24 13:03:38 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:38 --> Input Class Initialized
INFO - 2023-07-24 13:03:38 --> Language Class Initialized
INFO - 2023-07-24 13:03:38 --> Loader Class Initialized
INFO - 2023-07-24 13:03:38 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:38 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:38 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:38 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:38 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:38 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:38 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:38 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:38 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:38 --> Parser Class Initialized
INFO - 2023-07-24 13:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:38 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:38 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:38 --> Controller Class Initialized
INFO - 2023-07-24 13:03:38 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:38 --> Model Class Initialized
INFO - 2023-07-24 13:03:38 --> Model Class Initialized
INFO - 2023-07-24 13:03:38 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:38 --> Total execution time: 0.0206
ERROR - 2023-07-24 13:03:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:46 --> Config Class Initialized
INFO - 2023-07-24 13:03:46 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:46 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:46 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:46 --> URI Class Initialized
INFO - 2023-07-24 13:03:46 --> Router Class Initialized
INFO - 2023-07-24 13:03:46 --> Output Class Initialized
INFO - 2023-07-24 13:03:46 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:46 --> Input Class Initialized
INFO - 2023-07-24 13:03:46 --> Language Class Initialized
INFO - 2023-07-24 13:03:46 --> Loader Class Initialized
INFO - 2023-07-24 13:03:46 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:46 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:46 --> Parser Class Initialized
INFO - 2023-07-24 13:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:46 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:46 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:46 --> Controller Class Initialized
INFO - 2023-07-24 13:03:46 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:46 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:46 --> Model Class Initialized
INFO - 2023-07-24 13:03:46 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:46 --> Total execution time: 0.0177
ERROR - 2023-07-24 13:03:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:46 --> Config Class Initialized
INFO - 2023-07-24 13:03:46 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:46 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:46 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:46 --> URI Class Initialized
INFO - 2023-07-24 13:03:46 --> Router Class Initialized
INFO - 2023-07-24 13:03:46 --> Output Class Initialized
INFO - 2023-07-24 13:03:46 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:46 --> Input Class Initialized
INFO - 2023-07-24 13:03:46 --> Language Class Initialized
INFO - 2023-07-24 13:03:46 --> Loader Class Initialized
INFO - 2023-07-24 13:03:46 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:46 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:46 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:46 --> Parser Class Initialized
INFO - 2023-07-24 13:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:46 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:46 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:46 --> Controller Class Initialized
INFO - 2023-07-24 13:03:46 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:46 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:46 --> Model Class Initialized
INFO - 2023-07-24 13:03:46 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:46 --> Total execution time: 0.0174
ERROR - 2023-07-24 13:03:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:47 --> Config Class Initialized
INFO - 2023-07-24 13:03:47 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:47 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:47 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:47 --> URI Class Initialized
INFO - 2023-07-24 13:03:47 --> Router Class Initialized
INFO - 2023-07-24 13:03:47 --> Output Class Initialized
INFO - 2023-07-24 13:03:47 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:47 --> Input Class Initialized
INFO - 2023-07-24 13:03:47 --> Language Class Initialized
INFO - 2023-07-24 13:03:47 --> Loader Class Initialized
INFO - 2023-07-24 13:03:47 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:47 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:47 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:47 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:47 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:47 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:47 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:47 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:47 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:47 --> Parser Class Initialized
INFO - 2023-07-24 13:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:47 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:47 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:47 --> Controller Class Initialized
INFO - 2023-07-24 13:03:47 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:47 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:47 --> Model Class Initialized
INFO - 2023-07-24 13:03:47 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:47 --> Total execution time: 0.0187
ERROR - 2023-07-24 13:03:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:48 --> Config Class Initialized
INFO - 2023-07-24 13:03:48 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:48 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:48 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:48 --> URI Class Initialized
INFO - 2023-07-24 13:03:48 --> Router Class Initialized
INFO - 2023-07-24 13:03:48 --> Output Class Initialized
INFO - 2023-07-24 13:03:48 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:48 --> Input Class Initialized
INFO - 2023-07-24 13:03:48 --> Language Class Initialized
INFO - 2023-07-24 13:03:48 --> Loader Class Initialized
INFO - 2023-07-24 13:03:48 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:48 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:48 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:49 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:49 --> Parser Class Initialized
INFO - 2023-07-24 13:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:49 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:49 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:49 --> Controller Class Initialized
INFO - 2023-07-24 13:03:49 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:49 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:49 --> Model Class Initialized
INFO - 2023-07-24 13:03:49 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:49 --> Total execution time: 0.0183
ERROR - 2023-07-24 13:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:49 --> Config Class Initialized
INFO - 2023-07-24 13:03:49 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:49 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:49 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:49 --> URI Class Initialized
INFO - 2023-07-24 13:03:49 --> Router Class Initialized
INFO - 2023-07-24 13:03:49 --> Output Class Initialized
INFO - 2023-07-24 13:03:49 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:49 --> Input Class Initialized
INFO - 2023-07-24 13:03:49 --> Language Class Initialized
INFO - 2023-07-24 13:03:49 --> Loader Class Initialized
INFO - 2023-07-24 13:03:49 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:49 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:49 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:49 --> Parser Class Initialized
INFO - 2023-07-24 13:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:49 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:49 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:49 --> Controller Class Initialized
INFO - 2023-07-24 13:03:49 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:49 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:49 --> Model Class Initialized
INFO - 2023-07-24 13:03:49 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:49 --> Total execution time: 0.0173
ERROR - 2023-07-24 13:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:03:57 --> Config Class Initialized
INFO - 2023-07-24 13:03:57 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:03:57 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:03:57 --> Utf8 Class Initialized
INFO - 2023-07-24 13:03:57 --> URI Class Initialized
INFO - 2023-07-24 13:03:57 --> Router Class Initialized
INFO - 2023-07-24 13:03:57 --> Output Class Initialized
INFO - 2023-07-24 13:03:57 --> Security Class Initialized
DEBUG - 2023-07-24 13:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:03:57 --> Input Class Initialized
INFO - 2023-07-24 13:03:57 --> Language Class Initialized
INFO - 2023-07-24 13:03:57 --> Loader Class Initialized
INFO - 2023-07-24 13:03:57 --> Helper loaded: url_helper
INFO - 2023-07-24 13:03:57 --> Helper loaded: file_helper
INFO - 2023-07-24 13:03:57 --> Helper loaded: html_helper
INFO - 2023-07-24 13:03:57 --> Helper loaded: text_helper
INFO - 2023-07-24 13:03:57 --> Helper loaded: form_helper
INFO - 2023-07-24 13:03:57 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:03:57 --> Helper loaded: security_helper
INFO - 2023-07-24 13:03:57 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:03:57 --> Database Driver Class Initialized
INFO - 2023-07-24 13:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:03:57 --> Parser Class Initialized
INFO - 2023-07-24 13:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:03:57 --> Pagination Class Initialized
INFO - 2023-07-24 13:03:57 --> Form Validation Class Initialized
INFO - 2023-07-24 13:03:57 --> Controller Class Initialized
INFO - 2023-07-24 13:03:57 --> Model Class Initialized
DEBUG - 2023-07-24 13:03:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:03:57 --> Model Class Initialized
INFO - 2023-07-24 13:03:57 --> Model Class Initialized
INFO - 2023-07-24 13:03:57 --> Final output sent to browser
DEBUG - 2023-07-24 13:03:57 --> Total execution time: 0.0186
ERROR - 2023-07-24 13:04:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:04:54 --> Config Class Initialized
INFO - 2023-07-24 13:04:54 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:04:54 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:04:54 --> Utf8 Class Initialized
INFO - 2023-07-24 13:04:54 --> URI Class Initialized
INFO - 2023-07-24 13:04:54 --> Router Class Initialized
INFO - 2023-07-24 13:04:54 --> Output Class Initialized
INFO - 2023-07-24 13:04:54 --> Security Class Initialized
DEBUG - 2023-07-24 13:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:04:54 --> Input Class Initialized
INFO - 2023-07-24 13:04:54 --> Language Class Initialized
INFO - 2023-07-24 13:04:54 --> Loader Class Initialized
INFO - 2023-07-24 13:04:54 --> Helper loaded: url_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: file_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: html_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: text_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: form_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: security_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:04:54 --> Database Driver Class Initialized
INFO - 2023-07-24 13:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:04:54 --> Parser Class Initialized
INFO - 2023-07-24 13:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:04:54 --> Pagination Class Initialized
INFO - 2023-07-24 13:04:54 --> Form Validation Class Initialized
INFO - 2023-07-24 13:04:54 --> Controller Class Initialized
INFO - 2023-07-24 13:04:54 --> Model Class Initialized
DEBUG - 2023-07-24 13:04:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:04:54 --> Model Class Initialized
DEBUG - 2023-07-24 13:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:04:54 --> Model Class Initialized
INFO - 2023-07-24 13:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-24 13:04:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:04:54 --> Model Class Initialized
INFO - 2023-07-24 13:04:54 --> Model Class Initialized
INFO - 2023-07-24 13:04:54 --> Model Class Initialized
INFO - 2023-07-24 13:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:04:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:04:54 --> Final output sent to browser
DEBUG - 2023-07-24 13:04:54 --> Total execution time: 0.0911
ERROR - 2023-07-24 13:04:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:04:54 --> Config Class Initialized
INFO - 2023-07-24 13:04:54 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:04:54 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:04:54 --> Utf8 Class Initialized
INFO - 2023-07-24 13:04:54 --> URI Class Initialized
INFO - 2023-07-24 13:04:54 --> Router Class Initialized
INFO - 2023-07-24 13:04:54 --> Output Class Initialized
INFO - 2023-07-24 13:04:54 --> Security Class Initialized
DEBUG - 2023-07-24 13:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:04:54 --> Input Class Initialized
INFO - 2023-07-24 13:04:54 --> Language Class Initialized
INFO - 2023-07-24 13:04:54 --> Loader Class Initialized
INFO - 2023-07-24 13:04:54 --> Helper loaded: url_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: file_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: html_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: text_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: form_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: security_helper
INFO - 2023-07-24 13:04:54 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:04:54 --> Database Driver Class Initialized
INFO - 2023-07-24 13:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:04:54 --> Parser Class Initialized
INFO - 2023-07-24 13:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:04:54 --> Pagination Class Initialized
INFO - 2023-07-24 13:04:54 --> Form Validation Class Initialized
INFO - 2023-07-24 13:04:54 --> Controller Class Initialized
INFO - 2023-07-24 13:04:54 --> Model Class Initialized
DEBUG - 2023-07-24 13:04:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:04:54 --> Model Class Initialized
DEBUG - 2023-07-24 13:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:04:54 --> Model Class Initialized
INFO - 2023-07-24 13:04:54 --> Final output sent to browser
DEBUG - 2023-07-24 13:04:54 --> Total execution time: 0.0228
ERROR - 2023-07-24 13:05:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:05:02 --> Config Class Initialized
INFO - 2023-07-24 13:05:02 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:05:02 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:05:02 --> Utf8 Class Initialized
INFO - 2023-07-24 13:05:02 --> URI Class Initialized
INFO - 2023-07-24 13:05:02 --> Router Class Initialized
INFO - 2023-07-24 13:05:02 --> Output Class Initialized
INFO - 2023-07-24 13:05:02 --> Security Class Initialized
DEBUG - 2023-07-24 13:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:05:02 --> Input Class Initialized
INFO - 2023-07-24 13:05:02 --> Language Class Initialized
INFO - 2023-07-24 13:05:02 --> Loader Class Initialized
INFO - 2023-07-24 13:05:02 --> Helper loaded: url_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: file_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: html_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: text_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: form_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: security_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:05:02 --> Database Driver Class Initialized
INFO - 2023-07-24 13:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:05:02 --> Parser Class Initialized
INFO - 2023-07-24 13:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:05:02 --> Pagination Class Initialized
INFO - 2023-07-24 13:05:02 --> Form Validation Class Initialized
INFO - 2023-07-24 13:05:02 --> Controller Class Initialized
INFO - 2023-07-24 13:05:02 --> Model Class Initialized
DEBUG - 2023-07-24 13:05:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:05:02 --> Model Class Initialized
DEBUG - 2023-07-24 13:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:05:02 --> Model Class Initialized
INFO - 2023-07-24 13:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 13:05:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:05:02 --> Model Class Initialized
INFO - 2023-07-24 13:05:02 --> Model Class Initialized
INFO - 2023-07-24 13:05:02 --> Model Class Initialized
INFO - 2023-07-24 13:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:05:02 --> Final output sent to browser
DEBUG - 2023-07-24 13:05:02 --> Total execution time: 0.0849
ERROR - 2023-07-24 13:05:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:05:02 --> Config Class Initialized
INFO - 2023-07-24 13:05:02 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:05:02 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:05:02 --> Utf8 Class Initialized
INFO - 2023-07-24 13:05:02 --> URI Class Initialized
INFO - 2023-07-24 13:05:02 --> Router Class Initialized
INFO - 2023-07-24 13:05:02 --> Output Class Initialized
INFO - 2023-07-24 13:05:02 --> Security Class Initialized
DEBUG - 2023-07-24 13:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:05:02 --> Input Class Initialized
INFO - 2023-07-24 13:05:02 --> Language Class Initialized
INFO - 2023-07-24 13:05:02 --> Loader Class Initialized
INFO - 2023-07-24 13:05:02 --> Helper loaded: url_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: file_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: html_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: text_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: form_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: security_helper
INFO - 2023-07-24 13:05:02 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:05:02 --> Database Driver Class Initialized
INFO - 2023-07-24 13:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:05:02 --> Parser Class Initialized
INFO - 2023-07-24 13:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:05:02 --> Pagination Class Initialized
INFO - 2023-07-24 13:05:02 --> Form Validation Class Initialized
INFO - 2023-07-24 13:05:02 --> Controller Class Initialized
INFO - 2023-07-24 13:05:02 --> Model Class Initialized
DEBUG - 2023-07-24 13:05:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:05:02 --> Model Class Initialized
DEBUG - 2023-07-24 13:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:05:02 --> Model Class Initialized
INFO - 2023-07-24 13:05:02 --> Final output sent to browser
DEBUG - 2023-07-24 13:05:02 --> Total execution time: 0.0285
ERROR - 2023-07-24 13:05:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:05:06 --> Config Class Initialized
INFO - 2023-07-24 13:05:06 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:05:06 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:05:06 --> Utf8 Class Initialized
INFO - 2023-07-24 13:05:06 --> URI Class Initialized
INFO - 2023-07-24 13:05:06 --> Router Class Initialized
INFO - 2023-07-24 13:05:06 --> Output Class Initialized
INFO - 2023-07-24 13:05:06 --> Security Class Initialized
DEBUG - 2023-07-24 13:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:05:06 --> Input Class Initialized
INFO - 2023-07-24 13:05:06 --> Language Class Initialized
INFO - 2023-07-24 13:05:06 --> Loader Class Initialized
INFO - 2023-07-24 13:05:06 --> Helper loaded: url_helper
INFO - 2023-07-24 13:05:06 --> Helper loaded: file_helper
INFO - 2023-07-24 13:05:06 --> Helper loaded: html_helper
INFO - 2023-07-24 13:05:06 --> Helper loaded: text_helper
INFO - 2023-07-24 13:05:06 --> Helper loaded: form_helper
INFO - 2023-07-24 13:05:06 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:05:06 --> Helper loaded: security_helper
INFO - 2023-07-24 13:05:06 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:05:06 --> Database Driver Class Initialized
INFO - 2023-07-24 13:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:05:06 --> Parser Class Initialized
INFO - 2023-07-24 13:05:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:05:06 --> Pagination Class Initialized
INFO - 2023-07-24 13:05:06 --> Form Validation Class Initialized
INFO - 2023-07-24 13:05:06 --> Controller Class Initialized
INFO - 2023-07-24 13:05:06 --> Model Class Initialized
DEBUG - 2023-07-24 13:05:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:05:06 --> Model Class Initialized
DEBUG - 2023-07-24 13:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:05:06 --> Model Class Initialized
DEBUG - 2023-07-24 13:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-24 13:05:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:05:06 --> Model Class Initialized
INFO - 2023-07-24 13:05:06 --> Model Class Initialized
INFO - 2023-07-24 13:05:06 --> Model Class Initialized
INFO - 2023-07-24 13:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:05:06 --> Final output sent to browser
DEBUG - 2023-07-24 13:05:06 --> Total execution time: 0.0827
ERROR - 2023-07-24 13:06:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:06:00 --> Config Class Initialized
INFO - 2023-07-24 13:06:00 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:06:00 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:06:00 --> Utf8 Class Initialized
INFO - 2023-07-24 13:06:00 --> URI Class Initialized
DEBUG - 2023-07-24 13:06:00 --> No URI present. Default controller set.
INFO - 2023-07-24 13:06:00 --> Router Class Initialized
INFO - 2023-07-24 13:06:00 --> Output Class Initialized
INFO - 2023-07-24 13:06:00 --> Security Class Initialized
DEBUG - 2023-07-24 13:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:06:00 --> Input Class Initialized
INFO - 2023-07-24 13:06:00 --> Language Class Initialized
INFO - 2023-07-24 13:06:00 --> Loader Class Initialized
INFO - 2023-07-24 13:06:00 --> Helper loaded: url_helper
INFO - 2023-07-24 13:06:00 --> Helper loaded: file_helper
INFO - 2023-07-24 13:06:00 --> Helper loaded: html_helper
INFO - 2023-07-24 13:06:00 --> Helper loaded: text_helper
INFO - 2023-07-24 13:06:00 --> Helper loaded: form_helper
INFO - 2023-07-24 13:06:00 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:06:00 --> Helper loaded: security_helper
INFO - 2023-07-24 13:06:00 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:06:00 --> Database Driver Class Initialized
INFO - 2023-07-24 13:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:06:00 --> Parser Class Initialized
INFO - 2023-07-24 13:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:06:00 --> Pagination Class Initialized
INFO - 2023-07-24 13:06:00 --> Form Validation Class Initialized
INFO - 2023-07-24 13:06:00 --> Controller Class Initialized
INFO - 2023-07-24 13:06:00 --> Model Class Initialized
DEBUG - 2023-07-24 13:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:06:00 --> Model Class Initialized
DEBUG - 2023-07-24 13:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:06:00 --> Model Class Initialized
INFO - 2023-07-24 13:06:00 --> Model Class Initialized
INFO - 2023-07-24 13:06:00 --> Model Class Initialized
INFO - 2023-07-24 13:06:00 --> Model Class Initialized
DEBUG - 2023-07-24 13:06:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:06:00 --> Model Class Initialized
INFO - 2023-07-24 13:06:00 --> Model Class Initialized
INFO - 2023-07-24 13:06:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 13:06:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:06:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:06:01 --> Model Class Initialized
INFO - 2023-07-24 13:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:06:01 --> Final output sent to browser
DEBUG - 2023-07-24 13:06:01 --> Total execution time: 0.0756
ERROR - 2023-07-24 13:08:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:08:10 --> Config Class Initialized
INFO - 2023-07-24 13:08:10 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:08:10 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:08:10 --> Utf8 Class Initialized
INFO - 2023-07-24 13:08:10 --> URI Class Initialized
INFO - 2023-07-24 13:08:10 --> Router Class Initialized
INFO - 2023-07-24 13:08:10 --> Output Class Initialized
INFO - 2023-07-24 13:08:10 --> Security Class Initialized
DEBUG - 2023-07-24 13:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:08:10 --> Input Class Initialized
INFO - 2023-07-24 13:08:10 --> Language Class Initialized
INFO - 2023-07-24 13:08:10 --> Loader Class Initialized
INFO - 2023-07-24 13:08:10 --> Helper loaded: url_helper
INFO - 2023-07-24 13:08:10 --> Helper loaded: file_helper
INFO - 2023-07-24 13:08:10 --> Helper loaded: html_helper
INFO - 2023-07-24 13:08:10 --> Helper loaded: text_helper
INFO - 2023-07-24 13:08:10 --> Helper loaded: form_helper
INFO - 2023-07-24 13:08:10 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:08:10 --> Helper loaded: security_helper
INFO - 2023-07-24 13:08:10 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:08:10 --> Database Driver Class Initialized
INFO - 2023-07-24 13:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:08:10 --> Parser Class Initialized
INFO - 2023-07-24 13:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:08:10 --> Pagination Class Initialized
INFO - 2023-07-24 13:08:10 --> Form Validation Class Initialized
INFO - 2023-07-24 13:08:10 --> Controller Class Initialized
INFO - 2023-07-24 13:08:10 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:10 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:10 --> Model Class Initialized
INFO - 2023-07-24 13:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 13:08:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:08:10 --> Model Class Initialized
INFO - 2023-07-24 13:08:10 --> Model Class Initialized
INFO - 2023-07-24 13:08:10 --> Model Class Initialized
INFO - 2023-07-24 13:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:08:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:08:10 --> Final output sent to browser
DEBUG - 2023-07-24 13:08:10 --> Total execution time: 0.0823
ERROR - 2023-07-24 13:08:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:08:11 --> Config Class Initialized
INFO - 2023-07-24 13:08:11 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:08:11 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:08:11 --> Utf8 Class Initialized
INFO - 2023-07-24 13:08:11 --> URI Class Initialized
INFO - 2023-07-24 13:08:11 --> Router Class Initialized
INFO - 2023-07-24 13:08:11 --> Output Class Initialized
INFO - 2023-07-24 13:08:11 --> Security Class Initialized
DEBUG - 2023-07-24 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:08:11 --> Input Class Initialized
INFO - 2023-07-24 13:08:11 --> Language Class Initialized
INFO - 2023-07-24 13:08:11 --> Loader Class Initialized
INFO - 2023-07-24 13:08:11 --> Helper loaded: url_helper
INFO - 2023-07-24 13:08:11 --> Helper loaded: file_helper
INFO - 2023-07-24 13:08:11 --> Helper loaded: html_helper
INFO - 2023-07-24 13:08:11 --> Helper loaded: text_helper
INFO - 2023-07-24 13:08:11 --> Helper loaded: form_helper
INFO - 2023-07-24 13:08:11 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:08:11 --> Helper loaded: security_helper
INFO - 2023-07-24 13:08:11 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:08:11 --> Database Driver Class Initialized
INFO - 2023-07-24 13:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:08:11 --> Parser Class Initialized
INFO - 2023-07-24 13:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:08:11 --> Pagination Class Initialized
INFO - 2023-07-24 13:08:11 --> Form Validation Class Initialized
INFO - 2023-07-24 13:08:11 --> Controller Class Initialized
INFO - 2023-07-24 13:08:11 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:11 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:11 --> Model Class Initialized
INFO - 2023-07-24 13:08:11 --> Final output sent to browser
DEBUG - 2023-07-24 13:08:11 --> Total execution time: 0.0267
ERROR - 2023-07-24 13:08:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:08:30 --> Config Class Initialized
INFO - 2023-07-24 13:08:30 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:08:30 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:08:30 --> Utf8 Class Initialized
INFO - 2023-07-24 13:08:30 --> URI Class Initialized
INFO - 2023-07-24 13:08:30 --> Router Class Initialized
INFO - 2023-07-24 13:08:30 --> Output Class Initialized
INFO - 2023-07-24 13:08:30 --> Security Class Initialized
DEBUG - 2023-07-24 13:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:08:30 --> Input Class Initialized
INFO - 2023-07-24 13:08:30 --> Language Class Initialized
INFO - 2023-07-24 13:08:30 --> Loader Class Initialized
INFO - 2023-07-24 13:08:30 --> Helper loaded: url_helper
INFO - 2023-07-24 13:08:30 --> Helper loaded: file_helper
INFO - 2023-07-24 13:08:30 --> Helper loaded: html_helper
INFO - 2023-07-24 13:08:30 --> Helper loaded: text_helper
INFO - 2023-07-24 13:08:30 --> Helper loaded: form_helper
INFO - 2023-07-24 13:08:30 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:08:30 --> Helper loaded: security_helper
INFO - 2023-07-24 13:08:30 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:08:30 --> Database Driver Class Initialized
INFO - 2023-07-24 13:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:08:30 --> Parser Class Initialized
INFO - 2023-07-24 13:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:08:30 --> Pagination Class Initialized
INFO - 2023-07-24 13:08:30 --> Form Validation Class Initialized
INFO - 2023-07-24 13:08:30 --> Controller Class Initialized
INFO - 2023-07-24 13:08:30 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:30 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:30 --> Model Class Initialized
INFO - 2023-07-24 13:08:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 13:08:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:08:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:08:30 --> Model Class Initialized
INFO - 2023-07-24 13:08:30 --> Model Class Initialized
INFO - 2023-07-24 13:08:30 --> Model Class Initialized
INFO - 2023-07-24 13:08:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:08:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:08:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:08:30 --> Final output sent to browser
DEBUG - 2023-07-24 13:08:30 --> Total execution time: 0.0730
ERROR - 2023-07-24 13:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:08:31 --> Config Class Initialized
INFO - 2023-07-24 13:08:31 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:08:31 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:08:31 --> Utf8 Class Initialized
INFO - 2023-07-24 13:08:31 --> URI Class Initialized
INFO - 2023-07-24 13:08:31 --> Router Class Initialized
INFO - 2023-07-24 13:08:31 --> Output Class Initialized
INFO - 2023-07-24 13:08:31 --> Security Class Initialized
DEBUG - 2023-07-24 13:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:08:31 --> Input Class Initialized
INFO - 2023-07-24 13:08:31 --> Language Class Initialized
INFO - 2023-07-24 13:08:31 --> Loader Class Initialized
INFO - 2023-07-24 13:08:31 --> Helper loaded: url_helper
INFO - 2023-07-24 13:08:31 --> Helper loaded: file_helper
INFO - 2023-07-24 13:08:31 --> Helper loaded: html_helper
INFO - 2023-07-24 13:08:31 --> Helper loaded: text_helper
INFO - 2023-07-24 13:08:31 --> Helper loaded: form_helper
INFO - 2023-07-24 13:08:31 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:08:31 --> Helper loaded: security_helper
INFO - 2023-07-24 13:08:31 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:08:31 --> Database Driver Class Initialized
INFO - 2023-07-24 13:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:08:31 --> Parser Class Initialized
INFO - 2023-07-24 13:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:08:31 --> Pagination Class Initialized
INFO - 2023-07-24 13:08:31 --> Form Validation Class Initialized
INFO - 2023-07-24 13:08:31 --> Controller Class Initialized
INFO - 2023-07-24 13:08:31 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:31 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:31 --> Model Class Initialized
INFO - 2023-07-24 13:08:31 --> Final output sent to browser
DEBUG - 2023-07-24 13:08:31 --> Total execution time: 0.0267
ERROR - 2023-07-24 13:08:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:08:35 --> Config Class Initialized
INFO - 2023-07-24 13:08:35 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:08:35 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:08:35 --> Utf8 Class Initialized
INFO - 2023-07-24 13:08:35 --> URI Class Initialized
INFO - 2023-07-24 13:08:35 --> Router Class Initialized
INFO - 2023-07-24 13:08:35 --> Output Class Initialized
INFO - 2023-07-24 13:08:35 --> Security Class Initialized
DEBUG - 2023-07-24 13:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:08:35 --> Input Class Initialized
INFO - 2023-07-24 13:08:35 --> Language Class Initialized
INFO - 2023-07-24 13:08:35 --> Loader Class Initialized
INFO - 2023-07-24 13:08:35 --> Helper loaded: url_helper
INFO - 2023-07-24 13:08:35 --> Helper loaded: file_helper
INFO - 2023-07-24 13:08:35 --> Helper loaded: html_helper
INFO - 2023-07-24 13:08:35 --> Helper loaded: text_helper
INFO - 2023-07-24 13:08:35 --> Helper loaded: form_helper
INFO - 2023-07-24 13:08:35 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:08:35 --> Helper loaded: security_helper
INFO - 2023-07-24 13:08:35 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:08:35 --> Database Driver Class Initialized
INFO - 2023-07-24 13:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:08:35 --> Parser Class Initialized
INFO - 2023-07-24 13:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:08:35 --> Pagination Class Initialized
INFO - 2023-07-24 13:08:35 --> Form Validation Class Initialized
INFO - 2023-07-24 13:08:35 --> Controller Class Initialized
INFO - 2023-07-24 13:08:35 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:35 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:35 --> Model Class Initialized
INFO - 2023-07-24 13:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 13:08:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:08:35 --> Model Class Initialized
INFO - 2023-07-24 13:08:35 --> Model Class Initialized
INFO - 2023-07-24 13:08:35 --> Model Class Initialized
INFO - 2023-07-24 13:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:08:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:08:35 --> Final output sent to browser
DEBUG - 2023-07-24 13:08:35 --> Total execution time: 0.0774
ERROR - 2023-07-24 13:08:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:08:36 --> Config Class Initialized
INFO - 2023-07-24 13:08:36 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:08:36 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:08:36 --> Utf8 Class Initialized
INFO - 2023-07-24 13:08:36 --> URI Class Initialized
INFO - 2023-07-24 13:08:36 --> Router Class Initialized
INFO - 2023-07-24 13:08:36 --> Output Class Initialized
INFO - 2023-07-24 13:08:36 --> Security Class Initialized
DEBUG - 2023-07-24 13:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:08:36 --> Input Class Initialized
INFO - 2023-07-24 13:08:36 --> Language Class Initialized
INFO - 2023-07-24 13:08:36 --> Loader Class Initialized
INFO - 2023-07-24 13:08:36 --> Helper loaded: url_helper
INFO - 2023-07-24 13:08:36 --> Helper loaded: file_helper
INFO - 2023-07-24 13:08:36 --> Helper loaded: html_helper
INFO - 2023-07-24 13:08:36 --> Helper loaded: text_helper
INFO - 2023-07-24 13:08:36 --> Helper loaded: form_helper
INFO - 2023-07-24 13:08:36 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:08:36 --> Helper loaded: security_helper
INFO - 2023-07-24 13:08:36 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:08:36 --> Database Driver Class Initialized
INFO - 2023-07-24 13:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:08:36 --> Parser Class Initialized
INFO - 2023-07-24 13:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:08:36 --> Pagination Class Initialized
INFO - 2023-07-24 13:08:36 --> Form Validation Class Initialized
INFO - 2023-07-24 13:08:36 --> Controller Class Initialized
INFO - 2023-07-24 13:08:36 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:36 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:36 --> Model Class Initialized
INFO - 2023-07-24 13:08:36 --> Final output sent to browser
DEBUG - 2023-07-24 13:08:36 --> Total execution time: 0.0234
ERROR - 2023-07-24 13:08:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:08:42 --> Config Class Initialized
INFO - 2023-07-24 13:08:42 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:08:42 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:08:42 --> Utf8 Class Initialized
INFO - 2023-07-24 13:08:42 --> URI Class Initialized
INFO - 2023-07-24 13:08:42 --> Router Class Initialized
INFO - 2023-07-24 13:08:42 --> Output Class Initialized
INFO - 2023-07-24 13:08:42 --> Security Class Initialized
DEBUG - 2023-07-24 13:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:08:42 --> Input Class Initialized
INFO - 2023-07-24 13:08:42 --> Language Class Initialized
INFO - 2023-07-24 13:08:42 --> Loader Class Initialized
INFO - 2023-07-24 13:08:42 --> Helper loaded: url_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: file_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: html_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: text_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: form_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: security_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:08:42 --> Database Driver Class Initialized
INFO - 2023-07-24 13:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:08:42 --> Parser Class Initialized
INFO - 2023-07-24 13:08:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:08:42 --> Pagination Class Initialized
INFO - 2023-07-24 13:08:42 --> Form Validation Class Initialized
INFO - 2023-07-24 13:08:42 --> Controller Class Initialized
INFO - 2023-07-24 13:08:42 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:42 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:42 --> Model Class Initialized
INFO - 2023-07-24 13:08:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 13:08:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:08:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:08:42 --> Model Class Initialized
INFO - 2023-07-24 13:08:42 --> Model Class Initialized
INFO - 2023-07-24 13:08:42 --> Model Class Initialized
INFO - 2023-07-24 13:08:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:08:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:08:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:08:42 --> Final output sent to browser
DEBUG - 2023-07-24 13:08:42 --> Total execution time: 0.0674
ERROR - 2023-07-24 13:08:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:08:42 --> Config Class Initialized
INFO - 2023-07-24 13:08:42 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:08:42 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:08:42 --> Utf8 Class Initialized
INFO - 2023-07-24 13:08:42 --> URI Class Initialized
INFO - 2023-07-24 13:08:42 --> Router Class Initialized
INFO - 2023-07-24 13:08:42 --> Output Class Initialized
INFO - 2023-07-24 13:08:42 --> Security Class Initialized
DEBUG - 2023-07-24 13:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:08:42 --> Input Class Initialized
INFO - 2023-07-24 13:08:42 --> Language Class Initialized
INFO - 2023-07-24 13:08:42 --> Loader Class Initialized
INFO - 2023-07-24 13:08:42 --> Helper loaded: url_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: file_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: html_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: text_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: form_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: security_helper
INFO - 2023-07-24 13:08:42 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:08:42 --> Database Driver Class Initialized
INFO - 2023-07-24 13:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:08:42 --> Parser Class Initialized
INFO - 2023-07-24 13:08:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:08:42 --> Pagination Class Initialized
INFO - 2023-07-24 13:08:42 --> Form Validation Class Initialized
INFO - 2023-07-24 13:08:42 --> Controller Class Initialized
INFO - 2023-07-24 13:08:42 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:42 --> Model Class Initialized
DEBUG - 2023-07-24 13:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:08:42 --> Model Class Initialized
INFO - 2023-07-24 13:08:42 --> Final output sent to browser
DEBUG - 2023-07-24 13:08:42 --> Total execution time: 0.0238
ERROR - 2023-07-24 13:09:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:09:22 --> Config Class Initialized
INFO - 2023-07-24 13:09:22 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:09:22 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:09:22 --> Utf8 Class Initialized
INFO - 2023-07-24 13:09:22 --> URI Class Initialized
INFO - 2023-07-24 13:09:22 --> Router Class Initialized
INFO - 2023-07-24 13:09:22 --> Output Class Initialized
INFO - 2023-07-24 13:09:22 --> Security Class Initialized
DEBUG - 2023-07-24 13:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:09:22 --> Input Class Initialized
INFO - 2023-07-24 13:09:22 --> Language Class Initialized
INFO - 2023-07-24 13:09:22 --> Loader Class Initialized
INFO - 2023-07-24 13:09:22 --> Helper loaded: url_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: file_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: html_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: text_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: form_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: security_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:09:22 --> Database Driver Class Initialized
INFO - 2023-07-24 13:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:09:22 --> Parser Class Initialized
INFO - 2023-07-24 13:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:09:22 --> Pagination Class Initialized
INFO - 2023-07-24 13:09:22 --> Form Validation Class Initialized
INFO - 2023-07-24 13:09:22 --> Controller Class Initialized
INFO - 2023-07-24 13:09:22 --> Model Class Initialized
DEBUG - 2023-07-24 13:09:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:09:22 --> Model Class Initialized
DEBUG - 2023-07-24 13:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:09:22 --> Model Class Initialized
INFO - 2023-07-24 13:09:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 13:09:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:09:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:09:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:09:22 --> Model Class Initialized
INFO - 2023-07-24 13:09:22 --> Model Class Initialized
INFO - 2023-07-24 13:09:22 --> Model Class Initialized
INFO - 2023-07-24 13:09:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:09:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:09:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:09:22 --> Final output sent to browser
DEBUG - 2023-07-24 13:09:22 --> Total execution time: 0.0702
ERROR - 2023-07-24 13:09:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:09:22 --> Config Class Initialized
INFO - 2023-07-24 13:09:22 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:09:22 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:09:22 --> Utf8 Class Initialized
INFO - 2023-07-24 13:09:22 --> URI Class Initialized
INFO - 2023-07-24 13:09:22 --> Router Class Initialized
INFO - 2023-07-24 13:09:22 --> Output Class Initialized
INFO - 2023-07-24 13:09:22 --> Security Class Initialized
DEBUG - 2023-07-24 13:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:09:22 --> Input Class Initialized
INFO - 2023-07-24 13:09:22 --> Language Class Initialized
INFO - 2023-07-24 13:09:22 --> Loader Class Initialized
INFO - 2023-07-24 13:09:22 --> Helper loaded: url_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: file_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: html_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: text_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: form_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: security_helper
INFO - 2023-07-24 13:09:22 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:09:22 --> Database Driver Class Initialized
INFO - 2023-07-24 13:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:09:22 --> Parser Class Initialized
INFO - 2023-07-24 13:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:09:22 --> Pagination Class Initialized
INFO - 2023-07-24 13:09:22 --> Form Validation Class Initialized
INFO - 2023-07-24 13:09:22 --> Controller Class Initialized
INFO - 2023-07-24 13:09:22 --> Model Class Initialized
DEBUG - 2023-07-24 13:09:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:09:22 --> Model Class Initialized
DEBUG - 2023-07-24 13:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:09:22 --> Model Class Initialized
INFO - 2023-07-24 13:09:22 --> Final output sent to browser
DEBUG - 2023-07-24 13:09:22 --> Total execution time: 0.0229
ERROR - 2023-07-24 13:10:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:10:48 --> Config Class Initialized
INFO - 2023-07-24 13:10:48 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:10:48 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:10:48 --> Utf8 Class Initialized
INFO - 2023-07-24 13:10:48 --> URI Class Initialized
DEBUG - 2023-07-24 13:10:48 --> No URI present. Default controller set.
INFO - 2023-07-24 13:10:48 --> Router Class Initialized
INFO - 2023-07-24 13:10:48 --> Output Class Initialized
INFO - 2023-07-24 13:10:48 --> Security Class Initialized
DEBUG - 2023-07-24 13:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:10:48 --> Input Class Initialized
INFO - 2023-07-24 13:10:48 --> Language Class Initialized
INFO - 2023-07-24 13:10:48 --> Loader Class Initialized
INFO - 2023-07-24 13:10:48 --> Helper loaded: url_helper
INFO - 2023-07-24 13:10:48 --> Helper loaded: file_helper
INFO - 2023-07-24 13:10:48 --> Helper loaded: html_helper
INFO - 2023-07-24 13:10:48 --> Helper loaded: text_helper
INFO - 2023-07-24 13:10:48 --> Helper loaded: form_helper
INFO - 2023-07-24 13:10:48 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:10:48 --> Helper loaded: security_helper
INFO - 2023-07-24 13:10:48 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:10:48 --> Database Driver Class Initialized
INFO - 2023-07-24 13:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:10:48 --> Parser Class Initialized
INFO - 2023-07-24 13:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:10:48 --> Pagination Class Initialized
INFO - 2023-07-24 13:10:48 --> Form Validation Class Initialized
INFO - 2023-07-24 13:10:48 --> Controller Class Initialized
INFO - 2023-07-24 13:10:48 --> Model Class Initialized
DEBUG - 2023-07-24 13:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:10:48 --> Model Class Initialized
DEBUG - 2023-07-24 13:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:10:48 --> Model Class Initialized
INFO - 2023-07-24 13:10:48 --> Model Class Initialized
INFO - 2023-07-24 13:10:48 --> Model Class Initialized
INFO - 2023-07-24 13:10:48 --> Model Class Initialized
DEBUG - 2023-07-24 13:10:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:10:48 --> Model Class Initialized
INFO - 2023-07-24 13:10:48 --> Model Class Initialized
INFO - 2023-07-24 13:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 13:10:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:10:48 --> Model Class Initialized
INFO - 2023-07-24 13:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:10:48 --> Final output sent to browser
DEBUG - 2023-07-24 13:10:48 --> Total execution time: 0.0728
ERROR - 2023-07-24 13:11:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:11:02 --> Config Class Initialized
INFO - 2023-07-24 13:11:02 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:11:02 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:11:02 --> Utf8 Class Initialized
INFO - 2023-07-24 13:11:02 --> URI Class Initialized
INFO - 2023-07-24 13:11:02 --> Router Class Initialized
INFO - 2023-07-24 13:11:02 --> Output Class Initialized
INFO - 2023-07-24 13:11:02 --> Security Class Initialized
DEBUG - 2023-07-24 13:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:11:02 --> Input Class Initialized
INFO - 2023-07-24 13:11:02 --> Language Class Initialized
INFO - 2023-07-24 13:11:02 --> Loader Class Initialized
INFO - 2023-07-24 13:11:02 --> Helper loaded: url_helper
INFO - 2023-07-24 13:11:02 --> Helper loaded: file_helper
INFO - 2023-07-24 13:11:02 --> Helper loaded: html_helper
INFO - 2023-07-24 13:11:02 --> Helper loaded: text_helper
INFO - 2023-07-24 13:11:02 --> Helper loaded: form_helper
INFO - 2023-07-24 13:11:02 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:11:02 --> Helper loaded: security_helper
INFO - 2023-07-24 13:11:02 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:11:02 --> Database Driver Class Initialized
INFO - 2023-07-24 13:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:11:02 --> Parser Class Initialized
INFO - 2023-07-24 13:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:11:02 --> Pagination Class Initialized
INFO - 2023-07-24 13:11:02 --> Form Validation Class Initialized
INFO - 2023-07-24 13:11:02 --> Controller Class Initialized
INFO - 2023-07-24 13:11:02 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:02 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-07-24 13:11:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:11:02 --> Model Class Initialized
INFO - 2023-07-24 13:11:02 --> Model Class Initialized
INFO - 2023-07-24 13:11:02 --> Model Class Initialized
INFO - 2023-07-24 13:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:11:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:11:02 --> Final output sent to browser
DEBUG - 2023-07-24 13:11:02 --> Total execution time: 0.0711
ERROR - 2023-07-24 13:11:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:11:19 --> Config Class Initialized
INFO - 2023-07-24 13:11:19 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:11:19 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:11:19 --> Utf8 Class Initialized
INFO - 2023-07-24 13:11:19 --> URI Class Initialized
INFO - 2023-07-24 13:11:19 --> Router Class Initialized
INFO - 2023-07-24 13:11:19 --> Output Class Initialized
INFO - 2023-07-24 13:11:19 --> Security Class Initialized
DEBUG - 2023-07-24 13:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:11:19 --> Input Class Initialized
INFO - 2023-07-24 13:11:19 --> Language Class Initialized
INFO - 2023-07-24 13:11:19 --> Loader Class Initialized
INFO - 2023-07-24 13:11:19 --> Helper loaded: url_helper
INFO - 2023-07-24 13:11:19 --> Helper loaded: file_helper
INFO - 2023-07-24 13:11:19 --> Helper loaded: html_helper
INFO - 2023-07-24 13:11:19 --> Helper loaded: text_helper
INFO - 2023-07-24 13:11:19 --> Helper loaded: form_helper
INFO - 2023-07-24 13:11:19 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:11:19 --> Helper loaded: security_helper
INFO - 2023-07-24 13:11:19 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:11:19 --> Database Driver Class Initialized
INFO - 2023-07-24 13:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:11:19 --> Parser Class Initialized
INFO - 2023-07-24 13:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:11:19 --> Pagination Class Initialized
INFO - 2023-07-24 13:11:19 --> Form Validation Class Initialized
INFO - 2023-07-24 13:11:19 --> Controller Class Initialized
INFO - 2023-07-24 13:11:19 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:19 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:19 --> Model Class Initialized
INFO - 2023-07-24 13:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-24 13:11:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:11:19 --> Model Class Initialized
INFO - 2023-07-24 13:11:19 --> Model Class Initialized
INFO - 2023-07-24 13:11:19 --> Model Class Initialized
INFO - 2023-07-24 13:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:11:19 --> Final output sent to browser
DEBUG - 2023-07-24 13:11:19 --> Total execution time: 0.0654
ERROR - 2023-07-24 13:11:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:11:20 --> Config Class Initialized
INFO - 2023-07-24 13:11:20 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:11:20 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:11:20 --> Utf8 Class Initialized
INFO - 2023-07-24 13:11:20 --> URI Class Initialized
INFO - 2023-07-24 13:11:20 --> Router Class Initialized
INFO - 2023-07-24 13:11:20 --> Output Class Initialized
INFO - 2023-07-24 13:11:20 --> Security Class Initialized
DEBUG - 2023-07-24 13:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:11:20 --> Input Class Initialized
INFO - 2023-07-24 13:11:20 --> Language Class Initialized
INFO - 2023-07-24 13:11:20 --> Loader Class Initialized
INFO - 2023-07-24 13:11:20 --> Helper loaded: url_helper
INFO - 2023-07-24 13:11:20 --> Helper loaded: file_helper
INFO - 2023-07-24 13:11:20 --> Helper loaded: html_helper
INFO - 2023-07-24 13:11:20 --> Helper loaded: text_helper
INFO - 2023-07-24 13:11:20 --> Helper loaded: form_helper
INFO - 2023-07-24 13:11:20 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:11:20 --> Helper loaded: security_helper
INFO - 2023-07-24 13:11:20 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:11:20 --> Database Driver Class Initialized
INFO - 2023-07-24 13:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:11:20 --> Parser Class Initialized
INFO - 2023-07-24 13:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:11:20 --> Pagination Class Initialized
INFO - 2023-07-24 13:11:20 --> Form Validation Class Initialized
INFO - 2023-07-24 13:11:20 --> Controller Class Initialized
INFO - 2023-07-24 13:11:20 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:20 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:20 --> Model Class Initialized
INFO - 2023-07-24 13:11:20 --> Final output sent to browser
DEBUG - 2023-07-24 13:11:20 --> Total execution time: 0.0192
ERROR - 2023-07-24 13:11:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:11:23 --> Config Class Initialized
INFO - 2023-07-24 13:11:23 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:11:23 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:11:23 --> Utf8 Class Initialized
INFO - 2023-07-24 13:11:23 --> URI Class Initialized
INFO - 2023-07-24 13:11:23 --> Router Class Initialized
INFO - 2023-07-24 13:11:23 --> Output Class Initialized
INFO - 2023-07-24 13:11:23 --> Security Class Initialized
DEBUG - 2023-07-24 13:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:11:23 --> Input Class Initialized
INFO - 2023-07-24 13:11:23 --> Language Class Initialized
INFO - 2023-07-24 13:11:23 --> Loader Class Initialized
INFO - 2023-07-24 13:11:23 --> Helper loaded: url_helper
INFO - 2023-07-24 13:11:23 --> Helper loaded: file_helper
INFO - 2023-07-24 13:11:23 --> Helper loaded: html_helper
INFO - 2023-07-24 13:11:23 --> Helper loaded: text_helper
INFO - 2023-07-24 13:11:23 --> Helper loaded: form_helper
INFO - 2023-07-24 13:11:23 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:11:23 --> Helper loaded: security_helper
INFO - 2023-07-24 13:11:23 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:11:23 --> Database Driver Class Initialized
INFO - 2023-07-24 13:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:11:23 --> Parser Class Initialized
INFO - 2023-07-24 13:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:11:23 --> Pagination Class Initialized
INFO - 2023-07-24 13:11:23 --> Form Validation Class Initialized
INFO - 2023-07-24 13:11:23 --> Controller Class Initialized
INFO - 2023-07-24 13:11:23 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:23 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:23 --> Model Class Initialized
INFO - 2023-07-24 13:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 13:11:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:11:23 --> Model Class Initialized
INFO - 2023-07-24 13:11:23 --> Model Class Initialized
INFO - 2023-07-24 13:11:23 --> Model Class Initialized
INFO - 2023-07-24 13:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:11:23 --> Final output sent to browser
DEBUG - 2023-07-24 13:11:23 --> Total execution time: 0.0650
ERROR - 2023-07-24 13:11:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:11:24 --> Config Class Initialized
INFO - 2023-07-24 13:11:24 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:11:24 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:11:24 --> Utf8 Class Initialized
INFO - 2023-07-24 13:11:24 --> URI Class Initialized
INFO - 2023-07-24 13:11:24 --> Router Class Initialized
INFO - 2023-07-24 13:11:24 --> Output Class Initialized
INFO - 2023-07-24 13:11:24 --> Security Class Initialized
DEBUG - 2023-07-24 13:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:11:24 --> Input Class Initialized
INFO - 2023-07-24 13:11:24 --> Language Class Initialized
INFO - 2023-07-24 13:11:24 --> Loader Class Initialized
INFO - 2023-07-24 13:11:24 --> Helper loaded: url_helper
INFO - 2023-07-24 13:11:24 --> Helper loaded: file_helper
INFO - 2023-07-24 13:11:24 --> Helper loaded: html_helper
INFO - 2023-07-24 13:11:24 --> Helper loaded: text_helper
INFO - 2023-07-24 13:11:24 --> Helper loaded: form_helper
INFO - 2023-07-24 13:11:24 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:11:24 --> Helper loaded: security_helper
INFO - 2023-07-24 13:11:24 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:11:24 --> Database Driver Class Initialized
INFO - 2023-07-24 13:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:11:24 --> Parser Class Initialized
INFO - 2023-07-24 13:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:11:24 --> Pagination Class Initialized
INFO - 2023-07-24 13:11:24 --> Form Validation Class Initialized
INFO - 2023-07-24 13:11:24 --> Controller Class Initialized
INFO - 2023-07-24 13:11:24 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:24 --> Model Class Initialized
DEBUG - 2023-07-24 13:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:11:24 --> Model Class Initialized
INFO - 2023-07-24 13:11:24 --> Final output sent to browser
DEBUG - 2023-07-24 13:11:24 --> Total execution time: 0.0229
ERROR - 2023-07-24 13:17:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:17:52 --> Config Class Initialized
INFO - 2023-07-24 13:17:52 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:17:52 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:17:52 --> Utf8 Class Initialized
INFO - 2023-07-24 13:17:52 --> URI Class Initialized
INFO - 2023-07-24 13:17:52 --> Router Class Initialized
INFO - 2023-07-24 13:17:52 --> Output Class Initialized
INFO - 2023-07-24 13:17:52 --> Security Class Initialized
DEBUG - 2023-07-24 13:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:17:52 --> Input Class Initialized
INFO - 2023-07-24 13:17:52 --> Language Class Initialized
INFO - 2023-07-24 13:17:52 --> Loader Class Initialized
INFO - 2023-07-24 13:17:52 --> Helper loaded: url_helper
INFO - 2023-07-24 13:17:52 --> Helper loaded: file_helper
INFO - 2023-07-24 13:17:52 --> Helper loaded: html_helper
INFO - 2023-07-24 13:17:52 --> Helper loaded: text_helper
INFO - 2023-07-24 13:17:52 --> Helper loaded: form_helper
INFO - 2023-07-24 13:17:52 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:17:52 --> Helper loaded: security_helper
INFO - 2023-07-24 13:17:52 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:17:52 --> Database Driver Class Initialized
INFO - 2023-07-24 13:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:17:52 --> Parser Class Initialized
INFO - 2023-07-24 13:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:17:52 --> Pagination Class Initialized
INFO - 2023-07-24 13:17:52 --> Form Validation Class Initialized
INFO - 2023-07-24 13:17:52 --> Controller Class Initialized
DEBUG - 2023-07-24 13:17:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:17:52 --> Model Class Initialized
DEBUG - 2023-07-24 13:17:52 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:17:52 --> Model Class Initialized
DEBUG - 2023-07-24 13:17:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:17:52 --> Model Class Initialized
DEBUG - 2023-07-24 13:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:17:52 --> Model Class Initialized
INFO - 2023-07-24 13:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-07-24 13:17:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:17:52 --> Model Class Initialized
INFO - 2023-07-24 13:17:52 --> Model Class Initialized
INFO - 2023-07-24 13:17:52 --> Model Class Initialized
INFO - 2023-07-24 13:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:17:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:17:52 --> Final output sent to browser
DEBUG - 2023-07-24 13:17:52 --> Total execution time: 0.0624
ERROR - 2023-07-24 13:17:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:17:53 --> Config Class Initialized
INFO - 2023-07-24 13:17:53 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:17:53 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:17:53 --> Utf8 Class Initialized
INFO - 2023-07-24 13:17:53 --> URI Class Initialized
INFO - 2023-07-24 13:17:53 --> Router Class Initialized
INFO - 2023-07-24 13:17:53 --> Output Class Initialized
INFO - 2023-07-24 13:17:53 --> Security Class Initialized
DEBUG - 2023-07-24 13:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:17:53 --> Input Class Initialized
INFO - 2023-07-24 13:17:53 --> Language Class Initialized
INFO - 2023-07-24 13:17:53 --> Loader Class Initialized
INFO - 2023-07-24 13:17:53 --> Helper loaded: url_helper
INFO - 2023-07-24 13:17:53 --> Helper loaded: file_helper
INFO - 2023-07-24 13:17:53 --> Helper loaded: html_helper
INFO - 2023-07-24 13:17:53 --> Helper loaded: text_helper
INFO - 2023-07-24 13:17:53 --> Helper loaded: form_helper
INFO - 2023-07-24 13:17:53 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:17:53 --> Helper loaded: security_helper
INFO - 2023-07-24 13:17:53 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:17:53 --> Database Driver Class Initialized
INFO - 2023-07-24 13:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:17:53 --> Parser Class Initialized
INFO - 2023-07-24 13:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:17:53 --> Pagination Class Initialized
INFO - 2023-07-24 13:17:53 --> Form Validation Class Initialized
INFO - 2023-07-24 13:17:53 --> Controller Class Initialized
DEBUG - 2023-07-24 13:17:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:17:53 --> Model Class Initialized
INFO - 2023-07-24 13:17:53 --> Final output sent to browser
DEBUG - 2023-07-24 13:17:53 --> Total execution time: 0.0164
ERROR - 2023-07-24 13:18:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:18:47 --> Config Class Initialized
INFO - 2023-07-24 13:18:47 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:18:47 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:18:47 --> Utf8 Class Initialized
INFO - 2023-07-24 13:18:47 --> URI Class Initialized
DEBUG - 2023-07-24 13:18:47 --> No URI present. Default controller set.
INFO - 2023-07-24 13:18:47 --> Router Class Initialized
INFO - 2023-07-24 13:18:47 --> Output Class Initialized
INFO - 2023-07-24 13:18:47 --> Security Class Initialized
DEBUG - 2023-07-24 13:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:18:47 --> Input Class Initialized
INFO - 2023-07-24 13:18:47 --> Language Class Initialized
INFO - 2023-07-24 13:18:47 --> Loader Class Initialized
INFO - 2023-07-24 13:18:47 --> Helper loaded: url_helper
INFO - 2023-07-24 13:18:47 --> Helper loaded: file_helper
INFO - 2023-07-24 13:18:47 --> Helper loaded: html_helper
INFO - 2023-07-24 13:18:47 --> Helper loaded: text_helper
INFO - 2023-07-24 13:18:47 --> Helper loaded: form_helper
INFO - 2023-07-24 13:18:47 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:18:47 --> Helper loaded: security_helper
INFO - 2023-07-24 13:18:47 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:18:47 --> Database Driver Class Initialized
INFO - 2023-07-24 13:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:18:47 --> Parser Class Initialized
INFO - 2023-07-24 13:18:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:18:47 --> Pagination Class Initialized
INFO - 2023-07-24 13:18:47 --> Form Validation Class Initialized
INFO - 2023-07-24 13:18:47 --> Controller Class Initialized
INFO - 2023-07-24 13:18:47 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:47 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:47 --> Model Class Initialized
INFO - 2023-07-24 13:18:47 --> Model Class Initialized
INFO - 2023-07-24 13:18:47 --> Model Class Initialized
INFO - 2023-07-24 13:18:47 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:47 --> Model Class Initialized
INFO - 2023-07-24 13:18:47 --> Model Class Initialized
INFO - 2023-07-24 13:18:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 13:18:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:18:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:18:47 --> Model Class Initialized
INFO - 2023-07-24 13:18:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:18:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:18:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:18:47 --> Final output sent to browser
DEBUG - 2023-07-24 13:18:47 --> Total execution time: 0.0752
ERROR - 2023-07-24 13:18:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:18:51 --> Config Class Initialized
INFO - 2023-07-24 13:18:51 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:18:51 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:18:51 --> Utf8 Class Initialized
INFO - 2023-07-24 13:18:51 --> URI Class Initialized
INFO - 2023-07-24 13:18:51 --> Router Class Initialized
INFO - 2023-07-24 13:18:51 --> Output Class Initialized
INFO - 2023-07-24 13:18:51 --> Security Class Initialized
DEBUG - 2023-07-24 13:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:18:51 --> Input Class Initialized
INFO - 2023-07-24 13:18:51 --> Language Class Initialized
INFO - 2023-07-24 13:18:51 --> Loader Class Initialized
INFO - 2023-07-24 13:18:51 --> Helper loaded: url_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: file_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: html_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: text_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: form_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: security_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:18:51 --> Database Driver Class Initialized
INFO - 2023-07-24 13:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:18:51 --> Parser Class Initialized
INFO - 2023-07-24 13:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:18:51 --> Pagination Class Initialized
INFO - 2023-07-24 13:18:51 --> Form Validation Class Initialized
INFO - 2023-07-24 13:18:51 --> Controller Class Initialized
INFO - 2023-07-24 13:18:51 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:51 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:51 --> Model Class Initialized
INFO - 2023-07-24 13:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 13:18:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:18:51 --> Model Class Initialized
INFO - 2023-07-24 13:18:51 --> Model Class Initialized
INFO - 2023-07-24 13:18:51 --> Model Class Initialized
INFO - 2023-07-24 13:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:18:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:18:51 --> Final output sent to browser
DEBUG - 2023-07-24 13:18:51 --> Total execution time: 0.0650
ERROR - 2023-07-24 13:18:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:18:51 --> Config Class Initialized
INFO - 2023-07-24 13:18:51 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:18:51 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:18:51 --> Utf8 Class Initialized
INFO - 2023-07-24 13:18:51 --> URI Class Initialized
INFO - 2023-07-24 13:18:51 --> Router Class Initialized
INFO - 2023-07-24 13:18:51 --> Output Class Initialized
INFO - 2023-07-24 13:18:51 --> Security Class Initialized
DEBUG - 2023-07-24 13:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:18:51 --> Input Class Initialized
INFO - 2023-07-24 13:18:51 --> Language Class Initialized
INFO - 2023-07-24 13:18:51 --> Loader Class Initialized
INFO - 2023-07-24 13:18:51 --> Helper loaded: url_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: file_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: html_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: text_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: form_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: security_helper
INFO - 2023-07-24 13:18:51 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:18:51 --> Database Driver Class Initialized
INFO - 2023-07-24 13:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:18:51 --> Parser Class Initialized
INFO - 2023-07-24 13:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:18:51 --> Pagination Class Initialized
INFO - 2023-07-24 13:18:51 --> Form Validation Class Initialized
INFO - 2023-07-24 13:18:51 --> Controller Class Initialized
INFO - 2023-07-24 13:18:51 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:51 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:51 --> Model Class Initialized
INFO - 2023-07-24 13:18:51 --> Final output sent to browser
DEBUG - 2023-07-24 13:18:51 --> Total execution time: 0.0224
ERROR - 2023-07-24 13:18:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:18:54 --> Config Class Initialized
INFO - 2023-07-24 13:18:54 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:18:54 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:18:54 --> Utf8 Class Initialized
INFO - 2023-07-24 13:18:54 --> URI Class Initialized
INFO - 2023-07-24 13:18:54 --> Router Class Initialized
INFO - 2023-07-24 13:18:54 --> Output Class Initialized
INFO - 2023-07-24 13:18:54 --> Security Class Initialized
DEBUG - 2023-07-24 13:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:18:54 --> Input Class Initialized
INFO - 2023-07-24 13:18:54 --> Language Class Initialized
INFO - 2023-07-24 13:18:54 --> Loader Class Initialized
INFO - 2023-07-24 13:18:54 --> Helper loaded: url_helper
INFO - 2023-07-24 13:18:54 --> Helper loaded: file_helper
INFO - 2023-07-24 13:18:54 --> Helper loaded: html_helper
INFO - 2023-07-24 13:18:54 --> Helper loaded: text_helper
INFO - 2023-07-24 13:18:54 --> Helper loaded: form_helper
INFO - 2023-07-24 13:18:54 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:18:54 --> Helper loaded: security_helper
INFO - 2023-07-24 13:18:54 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:18:54 --> Database Driver Class Initialized
INFO - 2023-07-24 13:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:18:54 --> Parser Class Initialized
INFO - 2023-07-24 13:18:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:18:54 --> Pagination Class Initialized
INFO - 2023-07-24 13:18:54 --> Form Validation Class Initialized
INFO - 2023-07-24 13:18:54 --> Controller Class Initialized
INFO - 2023-07-24 13:18:54 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:54 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:54 --> Model Class Initialized
DEBUG - 2023-07-24 13:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-24 13:18:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:18:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:18:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:18:54 --> Model Class Initialized
INFO - 2023-07-24 13:18:54 --> Model Class Initialized
INFO - 2023-07-24 13:18:54 --> Model Class Initialized
INFO - 2023-07-24 13:18:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:18:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:18:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:18:54 --> Final output sent to browser
DEBUG - 2023-07-24 13:18:54 --> Total execution time: 0.0726
ERROR - 2023-07-24 13:23:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:23:58 --> Config Class Initialized
INFO - 2023-07-24 13:23:58 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:23:58 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:23:58 --> Utf8 Class Initialized
INFO - 2023-07-24 13:23:58 --> URI Class Initialized
DEBUG - 2023-07-24 13:23:58 --> No URI present. Default controller set.
INFO - 2023-07-24 13:23:58 --> Router Class Initialized
INFO - 2023-07-24 13:23:58 --> Output Class Initialized
INFO - 2023-07-24 13:23:58 --> Security Class Initialized
DEBUG - 2023-07-24 13:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:23:58 --> Input Class Initialized
INFO - 2023-07-24 13:23:58 --> Language Class Initialized
INFO - 2023-07-24 13:23:58 --> Loader Class Initialized
INFO - 2023-07-24 13:23:58 --> Helper loaded: url_helper
INFO - 2023-07-24 13:23:58 --> Helper loaded: file_helper
INFO - 2023-07-24 13:23:58 --> Helper loaded: html_helper
INFO - 2023-07-24 13:23:58 --> Helper loaded: text_helper
INFO - 2023-07-24 13:23:58 --> Helper loaded: form_helper
INFO - 2023-07-24 13:23:58 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:23:58 --> Helper loaded: security_helper
INFO - 2023-07-24 13:23:58 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:23:58 --> Database Driver Class Initialized
INFO - 2023-07-24 13:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:23:58 --> Parser Class Initialized
INFO - 2023-07-24 13:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:23:58 --> Pagination Class Initialized
INFO - 2023-07-24 13:23:58 --> Form Validation Class Initialized
INFO - 2023-07-24 13:23:58 --> Controller Class Initialized
INFO - 2023-07-24 13:23:58 --> Model Class Initialized
DEBUG - 2023-07-24 13:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:23:58 --> Model Class Initialized
DEBUG - 2023-07-24 13:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:23:58 --> Model Class Initialized
INFO - 2023-07-24 13:23:58 --> Model Class Initialized
INFO - 2023-07-24 13:23:58 --> Model Class Initialized
INFO - 2023-07-24 13:23:58 --> Model Class Initialized
DEBUG - 2023-07-24 13:23:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:23:58 --> Model Class Initialized
INFO - 2023-07-24 13:23:58 --> Model Class Initialized
INFO - 2023-07-24 13:23:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 13:23:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:23:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:23:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:23:58 --> Model Class Initialized
INFO - 2023-07-24 13:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:23:59 --> Final output sent to browser
DEBUG - 2023-07-24 13:23:59 --> Total execution time: 0.2005
ERROR - 2023-07-24 13:24:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:24:13 --> Config Class Initialized
INFO - 2023-07-24 13:24:13 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:24:13 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:24:13 --> Utf8 Class Initialized
INFO - 2023-07-24 13:24:13 --> URI Class Initialized
DEBUG - 2023-07-24 13:24:13 --> No URI present. Default controller set.
INFO - 2023-07-24 13:24:13 --> Router Class Initialized
INFO - 2023-07-24 13:24:13 --> Output Class Initialized
INFO - 2023-07-24 13:24:13 --> Security Class Initialized
DEBUG - 2023-07-24 13:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:24:13 --> Input Class Initialized
INFO - 2023-07-24 13:24:13 --> Language Class Initialized
INFO - 2023-07-24 13:24:13 --> Loader Class Initialized
INFO - 2023-07-24 13:24:13 --> Helper loaded: url_helper
INFO - 2023-07-24 13:24:13 --> Helper loaded: file_helper
INFO - 2023-07-24 13:24:13 --> Helper loaded: html_helper
INFO - 2023-07-24 13:24:13 --> Helper loaded: text_helper
INFO - 2023-07-24 13:24:13 --> Helper loaded: form_helper
INFO - 2023-07-24 13:24:13 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:24:13 --> Helper loaded: security_helper
INFO - 2023-07-24 13:24:13 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:24:13 --> Database Driver Class Initialized
INFO - 2023-07-24 13:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:24:13 --> Parser Class Initialized
INFO - 2023-07-24 13:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:24:13 --> Pagination Class Initialized
INFO - 2023-07-24 13:24:13 --> Form Validation Class Initialized
INFO - 2023-07-24 13:24:13 --> Controller Class Initialized
INFO - 2023-07-24 13:24:13 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:13 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:13 --> Model Class Initialized
INFO - 2023-07-24 13:24:13 --> Model Class Initialized
INFO - 2023-07-24 13:24:13 --> Model Class Initialized
INFO - 2023-07-24 13:24:13 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:13 --> Model Class Initialized
INFO - 2023-07-24 13:24:13 --> Model Class Initialized
INFO - 2023-07-24 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 13:24:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:24:13 --> Model Class Initialized
INFO - 2023-07-24 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:24:13 --> Final output sent to browser
DEBUG - 2023-07-24 13:24:13 --> Total execution time: 0.2040
ERROR - 2023-07-24 13:24:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:24:18 --> Config Class Initialized
INFO - 2023-07-24 13:24:18 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:24:18 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:24:18 --> Utf8 Class Initialized
INFO - 2023-07-24 13:24:18 --> URI Class Initialized
INFO - 2023-07-24 13:24:18 --> Router Class Initialized
INFO - 2023-07-24 13:24:18 --> Output Class Initialized
INFO - 2023-07-24 13:24:18 --> Security Class Initialized
DEBUG - 2023-07-24 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:24:18 --> Input Class Initialized
INFO - 2023-07-24 13:24:18 --> Language Class Initialized
INFO - 2023-07-24 13:24:18 --> Loader Class Initialized
INFO - 2023-07-24 13:24:18 --> Helper loaded: url_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: file_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: html_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: text_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: form_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: security_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:24:18 --> Database Driver Class Initialized
INFO - 2023-07-24 13:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:24:18 --> Parser Class Initialized
INFO - 2023-07-24 13:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:24:18 --> Pagination Class Initialized
INFO - 2023-07-24 13:24:18 --> Form Validation Class Initialized
INFO - 2023-07-24 13:24:18 --> Controller Class Initialized
INFO - 2023-07-24 13:24:18 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:18 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:18 --> Model Class Initialized
INFO - 2023-07-24 13:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 13:24:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:24:18 --> Model Class Initialized
INFO - 2023-07-24 13:24:18 --> Model Class Initialized
INFO - 2023-07-24 13:24:18 --> Model Class Initialized
INFO - 2023-07-24 13:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:24:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:24:18 --> Final output sent to browser
DEBUG - 2023-07-24 13:24:18 --> Total execution time: 0.1406
ERROR - 2023-07-24 13:24:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:24:18 --> Config Class Initialized
INFO - 2023-07-24 13:24:18 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:24:18 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:24:18 --> Utf8 Class Initialized
INFO - 2023-07-24 13:24:18 --> URI Class Initialized
INFO - 2023-07-24 13:24:18 --> Router Class Initialized
INFO - 2023-07-24 13:24:18 --> Output Class Initialized
INFO - 2023-07-24 13:24:18 --> Security Class Initialized
DEBUG - 2023-07-24 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:24:18 --> Input Class Initialized
INFO - 2023-07-24 13:24:18 --> Language Class Initialized
INFO - 2023-07-24 13:24:18 --> Loader Class Initialized
INFO - 2023-07-24 13:24:18 --> Helper loaded: url_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: file_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: html_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: text_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: form_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: security_helper
INFO - 2023-07-24 13:24:18 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:24:18 --> Database Driver Class Initialized
INFO - 2023-07-24 13:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:24:18 --> Parser Class Initialized
INFO - 2023-07-24 13:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:24:18 --> Pagination Class Initialized
INFO - 2023-07-24 13:24:18 --> Form Validation Class Initialized
INFO - 2023-07-24 13:24:18 --> Controller Class Initialized
INFO - 2023-07-24 13:24:18 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:18 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:18 --> Model Class Initialized
INFO - 2023-07-24 13:24:18 --> Final output sent to browser
DEBUG - 2023-07-24 13:24:18 --> Total execution time: 0.0580
ERROR - 2023-07-24 13:24:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:24:25 --> Config Class Initialized
INFO - 2023-07-24 13:24:25 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:24:25 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:24:25 --> Utf8 Class Initialized
INFO - 2023-07-24 13:24:25 --> URI Class Initialized
INFO - 2023-07-24 13:24:25 --> Router Class Initialized
INFO - 2023-07-24 13:24:25 --> Output Class Initialized
INFO - 2023-07-24 13:24:25 --> Security Class Initialized
DEBUG - 2023-07-24 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:24:25 --> Input Class Initialized
INFO - 2023-07-24 13:24:25 --> Language Class Initialized
INFO - 2023-07-24 13:24:25 --> Loader Class Initialized
INFO - 2023-07-24 13:24:25 --> Helper loaded: url_helper
INFO - 2023-07-24 13:24:25 --> Helper loaded: file_helper
INFO - 2023-07-24 13:24:25 --> Helper loaded: html_helper
INFO - 2023-07-24 13:24:25 --> Helper loaded: text_helper
INFO - 2023-07-24 13:24:25 --> Helper loaded: form_helper
INFO - 2023-07-24 13:24:25 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:24:25 --> Helper loaded: security_helper
INFO - 2023-07-24 13:24:25 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:24:25 --> Database Driver Class Initialized
INFO - 2023-07-24 13:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:24:25 --> Parser Class Initialized
INFO - 2023-07-24 13:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:24:25 --> Pagination Class Initialized
INFO - 2023-07-24 13:24:25 --> Form Validation Class Initialized
INFO - 2023-07-24 13:24:25 --> Controller Class Initialized
INFO - 2023-07-24 13:24:25 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:25 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:25 --> Model Class Initialized
INFO - 2023-07-24 13:24:25 --> Final output sent to browser
DEBUG - 2023-07-24 13:24:25 --> Total execution time: 0.3946
ERROR - 2023-07-24 13:24:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:24:34 --> Config Class Initialized
INFO - 2023-07-24 13:24:34 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:24:34 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:24:34 --> Utf8 Class Initialized
INFO - 2023-07-24 13:24:34 --> URI Class Initialized
DEBUG - 2023-07-24 13:24:34 --> No URI present. Default controller set.
INFO - 2023-07-24 13:24:34 --> Router Class Initialized
INFO - 2023-07-24 13:24:34 --> Output Class Initialized
INFO - 2023-07-24 13:24:34 --> Security Class Initialized
DEBUG - 2023-07-24 13:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:24:34 --> Input Class Initialized
INFO - 2023-07-24 13:24:34 --> Language Class Initialized
INFO - 2023-07-24 13:24:34 --> Loader Class Initialized
INFO - 2023-07-24 13:24:34 --> Helper loaded: url_helper
INFO - 2023-07-24 13:24:34 --> Helper loaded: file_helper
INFO - 2023-07-24 13:24:34 --> Helper loaded: html_helper
INFO - 2023-07-24 13:24:34 --> Helper loaded: text_helper
INFO - 2023-07-24 13:24:34 --> Helper loaded: form_helper
INFO - 2023-07-24 13:24:34 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:24:34 --> Helper loaded: security_helper
INFO - 2023-07-24 13:24:34 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:24:34 --> Database Driver Class Initialized
INFO - 2023-07-24 13:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:24:34 --> Parser Class Initialized
INFO - 2023-07-24 13:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:24:34 --> Pagination Class Initialized
INFO - 2023-07-24 13:24:34 --> Form Validation Class Initialized
INFO - 2023-07-24 13:24:34 --> Controller Class Initialized
INFO - 2023-07-24 13:24:34 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:34 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:34 --> Model Class Initialized
INFO - 2023-07-24 13:24:34 --> Model Class Initialized
INFO - 2023-07-24 13:24:34 --> Model Class Initialized
INFO - 2023-07-24 13:24:34 --> Model Class Initialized
DEBUG - 2023-07-24 13:24:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:34 --> Model Class Initialized
INFO - 2023-07-24 13:24:34 --> Model Class Initialized
INFO - 2023-07-24 13:24:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 13:24:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:24:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:24:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:24:34 --> Model Class Initialized
INFO - 2023-07-24 13:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:24:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:24:35 --> Final output sent to browser
DEBUG - 2023-07-24 13:24:35 --> Total execution time: 0.2060
ERROR - 2023-07-24 13:25:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:25:12 --> Config Class Initialized
INFO - 2023-07-24 13:25:12 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:25:12 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:25:12 --> Utf8 Class Initialized
INFO - 2023-07-24 13:25:12 --> URI Class Initialized
INFO - 2023-07-24 13:25:12 --> Router Class Initialized
INFO - 2023-07-24 13:25:12 --> Output Class Initialized
INFO - 2023-07-24 13:25:12 --> Security Class Initialized
DEBUG - 2023-07-24 13:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:25:12 --> Input Class Initialized
INFO - 2023-07-24 13:25:12 --> Language Class Initialized
INFO - 2023-07-24 13:25:12 --> Loader Class Initialized
INFO - 2023-07-24 13:25:12 --> Helper loaded: url_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: file_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: html_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: text_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: form_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: security_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:25:12 --> Database Driver Class Initialized
INFO - 2023-07-24 13:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:25:12 --> Parser Class Initialized
INFO - 2023-07-24 13:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:25:12 --> Pagination Class Initialized
INFO - 2023-07-24 13:25:12 --> Form Validation Class Initialized
INFO - 2023-07-24 13:25:12 --> Controller Class Initialized
INFO - 2023-07-24 13:25:12 --> Model Class Initialized
DEBUG - 2023-07-24 13:25:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:25:12 --> Model Class Initialized
DEBUG - 2023-07-24 13:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:25:12 --> Model Class Initialized
INFO - 2023-07-24 13:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-24 13:25:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 13:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 13:25:12 --> Model Class Initialized
INFO - 2023-07-24 13:25:12 --> Model Class Initialized
INFO - 2023-07-24 13:25:12 --> Model Class Initialized
INFO - 2023-07-24 13:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 13:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 13:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 13:25:12 --> Final output sent to browser
DEBUG - 2023-07-24 13:25:12 --> Total execution time: 0.1334
ERROR - 2023-07-24 13:25:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:25:12 --> Config Class Initialized
INFO - 2023-07-24 13:25:12 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:25:12 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:25:12 --> Utf8 Class Initialized
INFO - 2023-07-24 13:25:12 --> URI Class Initialized
INFO - 2023-07-24 13:25:12 --> Router Class Initialized
INFO - 2023-07-24 13:25:12 --> Output Class Initialized
INFO - 2023-07-24 13:25:12 --> Security Class Initialized
DEBUG - 2023-07-24 13:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:25:12 --> Input Class Initialized
INFO - 2023-07-24 13:25:12 --> Language Class Initialized
INFO - 2023-07-24 13:25:12 --> Loader Class Initialized
INFO - 2023-07-24 13:25:12 --> Helper loaded: url_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: file_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: html_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: text_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: form_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: security_helper
INFO - 2023-07-24 13:25:12 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:25:12 --> Database Driver Class Initialized
INFO - 2023-07-24 13:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:25:12 --> Parser Class Initialized
INFO - 2023-07-24 13:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:25:12 --> Pagination Class Initialized
INFO - 2023-07-24 13:25:12 --> Form Validation Class Initialized
INFO - 2023-07-24 13:25:12 --> Controller Class Initialized
INFO - 2023-07-24 13:25:12 --> Model Class Initialized
DEBUG - 2023-07-24 13:25:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:25:12 --> Model Class Initialized
DEBUG - 2023-07-24 13:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:25:12 --> Model Class Initialized
INFO - 2023-07-24 13:25:12 --> Final output sent to browser
DEBUG - 2023-07-24 13:25:12 --> Total execution time: 0.0456
ERROR - 2023-07-24 13:25:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 13:25:18 --> Config Class Initialized
INFO - 2023-07-24 13:25:18 --> Hooks Class Initialized
DEBUG - 2023-07-24 13:25:18 --> UTF-8 Support Enabled
INFO - 2023-07-24 13:25:18 --> Utf8 Class Initialized
INFO - 2023-07-24 13:25:18 --> URI Class Initialized
INFO - 2023-07-24 13:25:18 --> Router Class Initialized
INFO - 2023-07-24 13:25:18 --> Output Class Initialized
INFO - 2023-07-24 13:25:18 --> Security Class Initialized
DEBUG - 2023-07-24 13:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 13:25:18 --> Input Class Initialized
INFO - 2023-07-24 13:25:18 --> Language Class Initialized
INFO - 2023-07-24 13:25:18 --> Loader Class Initialized
INFO - 2023-07-24 13:25:18 --> Helper loaded: url_helper
INFO - 2023-07-24 13:25:18 --> Helper loaded: file_helper
INFO - 2023-07-24 13:25:18 --> Helper loaded: html_helper
INFO - 2023-07-24 13:25:18 --> Helper loaded: text_helper
INFO - 2023-07-24 13:25:18 --> Helper loaded: form_helper
INFO - 2023-07-24 13:25:18 --> Helper loaded: lang_helper
INFO - 2023-07-24 13:25:18 --> Helper loaded: security_helper
INFO - 2023-07-24 13:25:18 --> Helper loaded: cookie_helper
INFO - 2023-07-24 13:25:18 --> Database Driver Class Initialized
INFO - 2023-07-24 13:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 13:25:18 --> Parser Class Initialized
INFO - 2023-07-24 13:25:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 13:25:18 --> Pagination Class Initialized
INFO - 2023-07-24 13:25:18 --> Form Validation Class Initialized
INFO - 2023-07-24 13:25:18 --> Controller Class Initialized
INFO - 2023-07-24 13:25:18 --> Model Class Initialized
DEBUG - 2023-07-24 13:25:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 13:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:25:18 --> Model Class Initialized
DEBUG - 2023-07-24 13:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 13:25:18 --> Model Class Initialized
INFO - 2023-07-24 13:25:18 --> Final output sent to browser
DEBUG - 2023-07-24 13:25:18 --> Total execution time: 0.0663
ERROR - 2023-07-24 14:21:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:21:10 --> Config Class Initialized
INFO - 2023-07-24 14:21:10 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:21:10 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:21:10 --> Utf8 Class Initialized
INFO - 2023-07-24 14:21:10 --> URI Class Initialized
INFO - 2023-07-24 14:21:10 --> Router Class Initialized
INFO - 2023-07-24 14:21:10 --> Output Class Initialized
INFO - 2023-07-24 14:21:10 --> Security Class Initialized
DEBUG - 2023-07-24 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:21:10 --> Input Class Initialized
INFO - 2023-07-24 14:21:10 --> Language Class Initialized
INFO - 2023-07-24 14:21:10 --> Loader Class Initialized
INFO - 2023-07-24 14:21:10 --> Helper loaded: url_helper
INFO - 2023-07-24 14:21:10 --> Helper loaded: file_helper
INFO - 2023-07-24 14:21:10 --> Helper loaded: html_helper
INFO - 2023-07-24 14:21:10 --> Helper loaded: text_helper
INFO - 2023-07-24 14:21:10 --> Helper loaded: form_helper
INFO - 2023-07-24 14:21:10 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:21:10 --> Helper loaded: security_helper
INFO - 2023-07-24 14:21:10 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:21:10 --> Database Driver Class Initialized
INFO - 2023-07-24 14:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:21:10 --> Parser Class Initialized
INFO - 2023-07-24 14:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:21:10 --> Pagination Class Initialized
INFO - 2023-07-24 14:21:10 --> Form Validation Class Initialized
INFO - 2023-07-24 14:21:10 --> Controller Class Initialized
INFO - 2023-07-24 14:21:10 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:10 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:10 --> Model Class Initialized
INFO - 2023-07-24 14:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-24 14:21:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:21:10 --> Model Class Initialized
INFO - 2023-07-24 14:21:10 --> Model Class Initialized
INFO - 2023-07-24 14:21:10 --> Model Class Initialized
INFO - 2023-07-24 14:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:21:10 --> Final output sent to browser
DEBUG - 2023-07-24 14:21:10 --> Total execution time: 0.1381
ERROR - 2023-07-24 14:21:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:21:11 --> Config Class Initialized
INFO - 2023-07-24 14:21:11 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:21:11 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:21:11 --> Utf8 Class Initialized
INFO - 2023-07-24 14:21:11 --> URI Class Initialized
INFO - 2023-07-24 14:21:11 --> Router Class Initialized
INFO - 2023-07-24 14:21:11 --> Output Class Initialized
INFO - 2023-07-24 14:21:11 --> Security Class Initialized
DEBUG - 2023-07-24 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:21:11 --> Input Class Initialized
INFO - 2023-07-24 14:21:11 --> Language Class Initialized
INFO - 2023-07-24 14:21:11 --> Loader Class Initialized
INFO - 2023-07-24 14:21:11 --> Helper loaded: url_helper
INFO - 2023-07-24 14:21:11 --> Helper loaded: file_helper
INFO - 2023-07-24 14:21:11 --> Helper loaded: html_helper
INFO - 2023-07-24 14:21:11 --> Helper loaded: text_helper
INFO - 2023-07-24 14:21:11 --> Helper loaded: form_helper
INFO - 2023-07-24 14:21:11 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:21:11 --> Helper loaded: security_helper
INFO - 2023-07-24 14:21:11 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:21:11 --> Database Driver Class Initialized
INFO - 2023-07-24 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:21:11 --> Parser Class Initialized
INFO - 2023-07-24 14:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:21:11 --> Pagination Class Initialized
INFO - 2023-07-24 14:21:11 --> Form Validation Class Initialized
INFO - 2023-07-24 14:21:11 --> Controller Class Initialized
INFO - 2023-07-24 14:21:11 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:11 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:11 --> Model Class Initialized
INFO - 2023-07-24 14:21:11 --> Final output sent to browser
DEBUG - 2023-07-24 14:21:11 --> Total execution time: 0.0455
ERROR - 2023-07-24 14:21:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:21:15 --> Config Class Initialized
INFO - 2023-07-24 14:21:15 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:21:15 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:21:15 --> Utf8 Class Initialized
INFO - 2023-07-24 14:21:15 --> URI Class Initialized
INFO - 2023-07-24 14:21:15 --> Router Class Initialized
INFO - 2023-07-24 14:21:15 --> Output Class Initialized
INFO - 2023-07-24 14:21:15 --> Security Class Initialized
DEBUG - 2023-07-24 14:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:21:15 --> Input Class Initialized
INFO - 2023-07-24 14:21:15 --> Language Class Initialized
INFO - 2023-07-24 14:21:15 --> Loader Class Initialized
INFO - 2023-07-24 14:21:15 --> Helper loaded: url_helper
INFO - 2023-07-24 14:21:15 --> Helper loaded: file_helper
INFO - 2023-07-24 14:21:15 --> Helper loaded: html_helper
INFO - 2023-07-24 14:21:15 --> Helper loaded: text_helper
INFO - 2023-07-24 14:21:15 --> Helper loaded: form_helper
INFO - 2023-07-24 14:21:15 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:21:15 --> Helper loaded: security_helper
INFO - 2023-07-24 14:21:15 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:21:15 --> Database Driver Class Initialized
INFO - 2023-07-24 14:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:21:15 --> Parser Class Initialized
INFO - 2023-07-24 14:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:21:15 --> Pagination Class Initialized
INFO - 2023-07-24 14:21:15 --> Form Validation Class Initialized
INFO - 2023-07-24 14:21:15 --> Controller Class Initialized
INFO - 2023-07-24 14:21:15 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:15 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:15 --> Model Class Initialized
INFO - 2023-07-24 14:21:15 --> Final output sent to browser
DEBUG - 2023-07-24 14:21:15 --> Total execution time: 0.0691
ERROR - 2023-07-24 14:21:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:21:22 --> Config Class Initialized
INFO - 2023-07-24 14:21:22 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:21:22 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:21:22 --> Utf8 Class Initialized
INFO - 2023-07-24 14:21:22 --> URI Class Initialized
INFO - 2023-07-24 14:21:22 --> Router Class Initialized
INFO - 2023-07-24 14:21:22 --> Output Class Initialized
INFO - 2023-07-24 14:21:22 --> Security Class Initialized
DEBUG - 2023-07-24 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:21:22 --> Input Class Initialized
INFO - 2023-07-24 14:21:22 --> Language Class Initialized
INFO - 2023-07-24 14:21:22 --> Loader Class Initialized
INFO - 2023-07-24 14:21:22 --> Helper loaded: url_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: file_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: html_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: text_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: form_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: security_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:21:22 --> Database Driver Class Initialized
INFO - 2023-07-24 14:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:21:22 --> Parser Class Initialized
INFO - 2023-07-24 14:21:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:21:22 --> Pagination Class Initialized
INFO - 2023-07-24 14:21:22 --> Form Validation Class Initialized
INFO - 2023-07-24 14:21:22 --> Controller Class Initialized
INFO - 2023-07-24 14:21:22 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:22 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:22 --> Model Class Initialized
INFO - 2023-07-24 14:21:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 14:21:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:21:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:21:22 --> Model Class Initialized
INFO - 2023-07-24 14:21:22 --> Model Class Initialized
INFO - 2023-07-24 14:21:22 --> Model Class Initialized
INFO - 2023-07-24 14:21:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:21:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:21:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:21:22 --> Final output sent to browser
DEBUG - 2023-07-24 14:21:22 --> Total execution time: 0.1670
ERROR - 2023-07-24 14:21:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:21:22 --> Config Class Initialized
INFO - 2023-07-24 14:21:22 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:21:22 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:21:22 --> Utf8 Class Initialized
INFO - 2023-07-24 14:21:22 --> URI Class Initialized
INFO - 2023-07-24 14:21:22 --> Router Class Initialized
INFO - 2023-07-24 14:21:22 --> Output Class Initialized
INFO - 2023-07-24 14:21:22 --> Security Class Initialized
DEBUG - 2023-07-24 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:21:22 --> Input Class Initialized
INFO - 2023-07-24 14:21:22 --> Language Class Initialized
INFO - 2023-07-24 14:21:22 --> Loader Class Initialized
INFO - 2023-07-24 14:21:22 --> Helper loaded: url_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: file_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: html_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: text_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: form_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: security_helper
INFO - 2023-07-24 14:21:22 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:21:22 --> Database Driver Class Initialized
INFO - 2023-07-24 14:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:21:22 --> Parser Class Initialized
INFO - 2023-07-24 14:21:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:21:22 --> Pagination Class Initialized
INFO - 2023-07-24 14:21:22 --> Form Validation Class Initialized
INFO - 2023-07-24 14:21:22 --> Controller Class Initialized
INFO - 2023-07-24 14:21:22 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:22 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:22 --> Model Class Initialized
INFO - 2023-07-24 14:21:22 --> Final output sent to browser
DEBUG - 2023-07-24 14:21:22 --> Total execution time: 0.0678
ERROR - 2023-07-24 14:21:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:21:25 --> Config Class Initialized
INFO - 2023-07-24 14:21:25 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:21:25 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:21:25 --> Utf8 Class Initialized
INFO - 2023-07-24 14:21:25 --> URI Class Initialized
INFO - 2023-07-24 14:21:25 --> Router Class Initialized
INFO - 2023-07-24 14:21:25 --> Output Class Initialized
INFO - 2023-07-24 14:21:25 --> Security Class Initialized
DEBUG - 2023-07-24 14:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:21:25 --> Input Class Initialized
INFO - 2023-07-24 14:21:25 --> Language Class Initialized
INFO - 2023-07-24 14:21:25 --> Loader Class Initialized
INFO - 2023-07-24 14:21:25 --> Helper loaded: url_helper
INFO - 2023-07-24 14:21:25 --> Helper loaded: file_helper
INFO - 2023-07-24 14:21:25 --> Helper loaded: html_helper
INFO - 2023-07-24 14:21:25 --> Helper loaded: text_helper
INFO - 2023-07-24 14:21:25 --> Helper loaded: form_helper
INFO - 2023-07-24 14:21:25 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:21:25 --> Helper loaded: security_helper
INFO - 2023-07-24 14:21:25 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:21:25 --> Database Driver Class Initialized
INFO - 2023-07-24 14:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:21:25 --> Parser Class Initialized
INFO - 2023-07-24 14:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:21:25 --> Pagination Class Initialized
INFO - 2023-07-24 14:21:25 --> Form Validation Class Initialized
INFO - 2023-07-24 14:21:25 --> Controller Class Initialized
INFO - 2023-07-24 14:21:25 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:25 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:25 --> Model Class Initialized
INFO - 2023-07-24 14:21:25 --> Final output sent to browser
DEBUG - 2023-07-24 14:21:25 --> Total execution time: 0.3821
ERROR - 2023-07-24 14:21:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:21:35 --> Config Class Initialized
INFO - 2023-07-24 14:21:35 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:21:35 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:21:35 --> Utf8 Class Initialized
INFO - 2023-07-24 14:21:35 --> URI Class Initialized
DEBUG - 2023-07-24 14:21:35 --> No URI present. Default controller set.
INFO - 2023-07-24 14:21:35 --> Router Class Initialized
INFO - 2023-07-24 14:21:35 --> Output Class Initialized
INFO - 2023-07-24 14:21:35 --> Security Class Initialized
DEBUG - 2023-07-24 14:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:21:35 --> Input Class Initialized
INFO - 2023-07-24 14:21:35 --> Language Class Initialized
INFO - 2023-07-24 14:21:35 --> Loader Class Initialized
INFO - 2023-07-24 14:21:35 --> Helper loaded: url_helper
INFO - 2023-07-24 14:21:35 --> Helper loaded: file_helper
INFO - 2023-07-24 14:21:35 --> Helper loaded: html_helper
INFO - 2023-07-24 14:21:35 --> Helper loaded: text_helper
INFO - 2023-07-24 14:21:35 --> Helper loaded: form_helper
INFO - 2023-07-24 14:21:35 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:21:35 --> Helper loaded: security_helper
INFO - 2023-07-24 14:21:35 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:21:35 --> Database Driver Class Initialized
INFO - 2023-07-24 14:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:21:35 --> Parser Class Initialized
INFO - 2023-07-24 14:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:21:35 --> Pagination Class Initialized
INFO - 2023-07-24 14:21:35 --> Form Validation Class Initialized
INFO - 2023-07-24 14:21:35 --> Controller Class Initialized
INFO - 2023-07-24 14:21:35 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:35 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:35 --> Model Class Initialized
INFO - 2023-07-24 14:21:35 --> Model Class Initialized
INFO - 2023-07-24 14:21:35 --> Model Class Initialized
INFO - 2023-07-24 14:21:35 --> Model Class Initialized
DEBUG - 2023-07-24 14:21:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:35 --> Model Class Initialized
INFO - 2023-07-24 14:21:35 --> Model Class Initialized
INFO - 2023-07-24 14:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 14:21:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:21:35 --> Model Class Initialized
INFO - 2023-07-24 14:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:21:35 --> Final output sent to browser
DEBUG - 2023-07-24 14:21:35 --> Total execution time: 0.1814
ERROR - 2023-07-24 14:22:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:22:15 --> Config Class Initialized
INFO - 2023-07-24 14:22:15 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:22:15 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:22:15 --> Utf8 Class Initialized
INFO - 2023-07-24 14:22:15 --> URI Class Initialized
INFO - 2023-07-24 14:22:15 --> Router Class Initialized
INFO - 2023-07-24 14:22:15 --> Output Class Initialized
INFO - 2023-07-24 14:22:15 --> Security Class Initialized
DEBUG - 2023-07-24 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:22:15 --> Input Class Initialized
INFO - 2023-07-24 14:22:15 --> Language Class Initialized
INFO - 2023-07-24 14:22:15 --> Loader Class Initialized
INFO - 2023-07-24 14:22:15 --> Helper loaded: url_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: file_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: html_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: text_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: form_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: security_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:22:15 --> Database Driver Class Initialized
INFO - 2023-07-24 14:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:22:15 --> Parser Class Initialized
INFO - 2023-07-24 14:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:22:15 --> Pagination Class Initialized
INFO - 2023-07-24 14:22:15 --> Form Validation Class Initialized
INFO - 2023-07-24 14:22:15 --> Controller Class Initialized
INFO - 2023-07-24 14:22:15 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:15 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:15 --> Model Class Initialized
INFO - 2023-07-24 14:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 14:22:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:22:15 --> Model Class Initialized
INFO - 2023-07-24 14:22:15 --> Model Class Initialized
INFO - 2023-07-24 14:22:15 --> Model Class Initialized
INFO - 2023-07-24 14:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:22:15 --> Final output sent to browser
DEBUG - 2023-07-24 14:22:15 --> Total execution time: 0.1377
ERROR - 2023-07-24 14:22:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:22:15 --> Config Class Initialized
INFO - 2023-07-24 14:22:15 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:22:15 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:22:15 --> Utf8 Class Initialized
INFO - 2023-07-24 14:22:15 --> URI Class Initialized
INFO - 2023-07-24 14:22:15 --> Router Class Initialized
INFO - 2023-07-24 14:22:15 --> Output Class Initialized
INFO - 2023-07-24 14:22:15 --> Security Class Initialized
DEBUG - 2023-07-24 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:22:15 --> Input Class Initialized
INFO - 2023-07-24 14:22:15 --> Language Class Initialized
INFO - 2023-07-24 14:22:15 --> Loader Class Initialized
INFO - 2023-07-24 14:22:15 --> Helper loaded: url_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: file_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: html_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: text_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: form_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: security_helper
INFO - 2023-07-24 14:22:15 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:22:15 --> Database Driver Class Initialized
INFO - 2023-07-24 14:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:22:15 --> Parser Class Initialized
INFO - 2023-07-24 14:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:22:15 --> Pagination Class Initialized
INFO - 2023-07-24 14:22:15 --> Form Validation Class Initialized
INFO - 2023-07-24 14:22:15 --> Controller Class Initialized
INFO - 2023-07-24 14:22:15 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:15 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:15 --> Model Class Initialized
INFO - 2023-07-24 14:22:15 --> Final output sent to browser
DEBUG - 2023-07-24 14:22:15 --> Total execution time: 0.0598
ERROR - 2023-07-24 14:22:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:22:26 --> Config Class Initialized
INFO - 2023-07-24 14:22:26 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:22:26 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:22:26 --> Utf8 Class Initialized
INFO - 2023-07-24 14:22:26 --> URI Class Initialized
DEBUG - 2023-07-24 14:22:26 --> No URI present. Default controller set.
INFO - 2023-07-24 14:22:26 --> Router Class Initialized
INFO - 2023-07-24 14:22:26 --> Output Class Initialized
INFO - 2023-07-24 14:22:26 --> Security Class Initialized
DEBUG - 2023-07-24 14:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:22:26 --> Input Class Initialized
INFO - 2023-07-24 14:22:26 --> Language Class Initialized
INFO - 2023-07-24 14:22:26 --> Loader Class Initialized
INFO - 2023-07-24 14:22:26 --> Helper loaded: url_helper
INFO - 2023-07-24 14:22:26 --> Helper loaded: file_helper
INFO - 2023-07-24 14:22:26 --> Helper loaded: html_helper
INFO - 2023-07-24 14:22:26 --> Helper loaded: text_helper
INFO - 2023-07-24 14:22:26 --> Helper loaded: form_helper
INFO - 2023-07-24 14:22:26 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:22:26 --> Helper loaded: security_helper
INFO - 2023-07-24 14:22:26 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:22:26 --> Database Driver Class Initialized
INFO - 2023-07-24 14:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:22:26 --> Parser Class Initialized
INFO - 2023-07-24 14:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:22:26 --> Pagination Class Initialized
INFO - 2023-07-24 14:22:26 --> Form Validation Class Initialized
INFO - 2023-07-24 14:22:26 --> Controller Class Initialized
INFO - 2023-07-24 14:22:26 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:26 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:26 --> Model Class Initialized
INFO - 2023-07-24 14:22:26 --> Model Class Initialized
INFO - 2023-07-24 14:22:26 --> Model Class Initialized
INFO - 2023-07-24 14:22:26 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:26 --> Model Class Initialized
INFO - 2023-07-24 14:22:26 --> Model Class Initialized
INFO - 2023-07-24 14:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 14:22:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:22:26 --> Model Class Initialized
INFO - 2023-07-24 14:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:22:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:22:26 --> Final output sent to browser
DEBUG - 2023-07-24 14:22:26 --> Total execution time: 0.1740
ERROR - 2023-07-24 14:22:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:22:50 --> Config Class Initialized
INFO - 2023-07-24 14:22:50 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:22:50 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:22:50 --> Utf8 Class Initialized
INFO - 2023-07-24 14:22:50 --> URI Class Initialized
INFO - 2023-07-24 14:22:50 --> Router Class Initialized
INFO - 2023-07-24 14:22:50 --> Output Class Initialized
INFO - 2023-07-24 14:22:50 --> Security Class Initialized
DEBUG - 2023-07-24 14:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:22:50 --> Input Class Initialized
INFO - 2023-07-24 14:22:50 --> Language Class Initialized
INFO - 2023-07-24 14:22:50 --> Loader Class Initialized
INFO - 2023-07-24 14:22:50 --> Helper loaded: url_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: file_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: html_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: text_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: form_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: security_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:22:50 --> Database Driver Class Initialized
INFO - 2023-07-24 14:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:22:50 --> Parser Class Initialized
INFO - 2023-07-24 14:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:22:50 --> Pagination Class Initialized
INFO - 2023-07-24 14:22:50 --> Form Validation Class Initialized
INFO - 2023-07-24 14:22:50 --> Controller Class Initialized
INFO - 2023-07-24 14:22:50 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:50 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:50 --> Model Class Initialized
INFO - 2023-07-24 14:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-24 14:22:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:22:50 --> Model Class Initialized
INFO - 2023-07-24 14:22:50 --> Model Class Initialized
INFO - 2023-07-24 14:22:50 --> Model Class Initialized
INFO - 2023-07-24 14:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:22:50 --> Final output sent to browser
DEBUG - 2023-07-24 14:22:50 --> Total execution time: 0.1413
ERROR - 2023-07-24 14:22:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:22:50 --> Config Class Initialized
INFO - 2023-07-24 14:22:50 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:22:50 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:22:50 --> Utf8 Class Initialized
INFO - 2023-07-24 14:22:50 --> URI Class Initialized
INFO - 2023-07-24 14:22:50 --> Router Class Initialized
INFO - 2023-07-24 14:22:50 --> Output Class Initialized
INFO - 2023-07-24 14:22:50 --> Security Class Initialized
DEBUG - 2023-07-24 14:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:22:50 --> Input Class Initialized
INFO - 2023-07-24 14:22:50 --> Language Class Initialized
INFO - 2023-07-24 14:22:50 --> Loader Class Initialized
INFO - 2023-07-24 14:22:50 --> Helper loaded: url_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: file_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: html_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: text_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: form_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: security_helper
INFO - 2023-07-24 14:22:50 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:22:50 --> Database Driver Class Initialized
INFO - 2023-07-24 14:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:22:50 --> Parser Class Initialized
INFO - 2023-07-24 14:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:22:50 --> Pagination Class Initialized
INFO - 2023-07-24 14:22:50 --> Form Validation Class Initialized
INFO - 2023-07-24 14:22:50 --> Controller Class Initialized
INFO - 2023-07-24 14:22:50 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:50 --> Model Class Initialized
DEBUG - 2023-07-24 14:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:22:50 --> Model Class Initialized
INFO - 2023-07-24 14:22:50 --> Final output sent to browser
DEBUG - 2023-07-24 14:22:50 --> Total execution time: 0.0457
ERROR - 2023-07-24 14:23:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:23:44 --> Config Class Initialized
INFO - 2023-07-24 14:23:44 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:23:44 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:23:44 --> Utf8 Class Initialized
INFO - 2023-07-24 14:23:44 --> URI Class Initialized
DEBUG - 2023-07-24 14:23:44 --> No URI present. Default controller set.
INFO - 2023-07-24 14:23:44 --> Router Class Initialized
INFO - 2023-07-24 14:23:44 --> Output Class Initialized
INFO - 2023-07-24 14:23:44 --> Security Class Initialized
DEBUG - 2023-07-24 14:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:23:44 --> Input Class Initialized
INFO - 2023-07-24 14:23:44 --> Language Class Initialized
INFO - 2023-07-24 14:23:44 --> Loader Class Initialized
INFO - 2023-07-24 14:23:44 --> Helper loaded: url_helper
INFO - 2023-07-24 14:23:44 --> Helper loaded: file_helper
INFO - 2023-07-24 14:23:44 --> Helper loaded: html_helper
INFO - 2023-07-24 14:23:44 --> Helper loaded: text_helper
INFO - 2023-07-24 14:23:44 --> Helper loaded: form_helper
INFO - 2023-07-24 14:23:44 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:23:44 --> Helper loaded: security_helper
INFO - 2023-07-24 14:23:44 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:23:44 --> Database Driver Class Initialized
INFO - 2023-07-24 14:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:23:44 --> Parser Class Initialized
INFO - 2023-07-24 14:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:23:44 --> Pagination Class Initialized
INFO - 2023-07-24 14:23:44 --> Form Validation Class Initialized
INFO - 2023-07-24 14:23:44 --> Controller Class Initialized
INFO - 2023-07-24 14:23:44 --> Model Class Initialized
DEBUG - 2023-07-24 14:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:23:44 --> Model Class Initialized
DEBUG - 2023-07-24 14:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:23:44 --> Model Class Initialized
INFO - 2023-07-24 14:23:44 --> Model Class Initialized
INFO - 2023-07-24 14:23:44 --> Model Class Initialized
INFO - 2023-07-24 14:23:44 --> Model Class Initialized
DEBUG - 2023-07-24 14:23:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:23:44 --> Model Class Initialized
INFO - 2023-07-24 14:23:44 --> Model Class Initialized
INFO - 2023-07-24 14:23:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 14:23:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:23:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:23:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:23:44 --> Model Class Initialized
INFO - 2023-07-24 14:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:23:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:23:45 --> Final output sent to browser
DEBUG - 2023-07-24 14:23:45 --> Total execution time: 0.1895
ERROR - 2023-07-24 14:25:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:25:20 --> Config Class Initialized
INFO - 2023-07-24 14:25:20 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:25:20 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:25:20 --> Utf8 Class Initialized
INFO - 2023-07-24 14:25:20 --> URI Class Initialized
INFO - 2023-07-24 14:25:20 --> Router Class Initialized
INFO - 2023-07-24 14:25:20 --> Output Class Initialized
INFO - 2023-07-24 14:25:20 --> Security Class Initialized
DEBUG - 2023-07-24 14:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:25:20 --> Input Class Initialized
INFO - 2023-07-24 14:25:20 --> Language Class Initialized
INFO - 2023-07-24 14:25:20 --> Loader Class Initialized
INFO - 2023-07-24 14:25:20 --> Helper loaded: url_helper
INFO - 2023-07-24 14:25:20 --> Helper loaded: file_helper
INFO - 2023-07-24 14:25:20 --> Helper loaded: html_helper
INFO - 2023-07-24 14:25:20 --> Helper loaded: text_helper
INFO - 2023-07-24 14:25:20 --> Helper loaded: form_helper
INFO - 2023-07-24 14:25:20 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:25:20 --> Helper loaded: security_helper
INFO - 2023-07-24 14:25:20 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:25:20 --> Database Driver Class Initialized
INFO - 2023-07-24 14:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:25:20 --> Parser Class Initialized
INFO - 2023-07-24 14:25:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:25:20 --> Pagination Class Initialized
INFO - 2023-07-24 14:25:20 --> Form Validation Class Initialized
INFO - 2023-07-24 14:25:20 --> Controller Class Initialized
INFO - 2023-07-24 14:25:20 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:20 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:20 --> Model Class Initialized
INFO - 2023-07-24 14:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 14:25:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:25:20 --> Model Class Initialized
INFO - 2023-07-24 14:25:20 --> Model Class Initialized
INFO - 2023-07-24 14:25:20 --> Model Class Initialized
INFO - 2023-07-24 14:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:25:20 --> Final output sent to browser
DEBUG - 2023-07-24 14:25:20 --> Total execution time: 0.1387
ERROR - 2023-07-24 14:25:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:25:21 --> Config Class Initialized
INFO - 2023-07-24 14:25:21 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:25:21 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:25:21 --> Utf8 Class Initialized
INFO - 2023-07-24 14:25:21 --> URI Class Initialized
INFO - 2023-07-24 14:25:21 --> Router Class Initialized
INFO - 2023-07-24 14:25:21 --> Output Class Initialized
INFO - 2023-07-24 14:25:21 --> Security Class Initialized
DEBUG - 2023-07-24 14:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:25:21 --> Input Class Initialized
INFO - 2023-07-24 14:25:21 --> Language Class Initialized
INFO - 2023-07-24 14:25:21 --> Loader Class Initialized
INFO - 2023-07-24 14:25:21 --> Helper loaded: url_helper
INFO - 2023-07-24 14:25:21 --> Helper loaded: file_helper
INFO - 2023-07-24 14:25:21 --> Helper loaded: html_helper
INFO - 2023-07-24 14:25:21 --> Helper loaded: text_helper
INFO - 2023-07-24 14:25:21 --> Helper loaded: form_helper
INFO - 2023-07-24 14:25:21 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:25:21 --> Helper loaded: security_helper
INFO - 2023-07-24 14:25:21 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:25:21 --> Database Driver Class Initialized
INFO - 2023-07-24 14:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:25:21 --> Parser Class Initialized
INFO - 2023-07-24 14:25:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:25:21 --> Pagination Class Initialized
INFO - 2023-07-24 14:25:21 --> Form Validation Class Initialized
INFO - 2023-07-24 14:25:21 --> Controller Class Initialized
INFO - 2023-07-24 14:25:21 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:25:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:22 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:22 --> Model Class Initialized
INFO - 2023-07-24 14:25:22 --> Final output sent to browser
DEBUG - 2023-07-24 14:25:22 --> Total execution time: 0.0556
ERROR - 2023-07-24 14:25:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:25:26 --> Config Class Initialized
INFO - 2023-07-24 14:25:26 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:25:26 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:25:26 --> Utf8 Class Initialized
INFO - 2023-07-24 14:25:26 --> URI Class Initialized
INFO - 2023-07-24 14:25:26 --> Router Class Initialized
INFO - 2023-07-24 14:25:26 --> Output Class Initialized
INFO - 2023-07-24 14:25:26 --> Security Class Initialized
DEBUG - 2023-07-24 14:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:25:26 --> Input Class Initialized
INFO - 2023-07-24 14:25:26 --> Language Class Initialized
INFO - 2023-07-24 14:25:26 --> Loader Class Initialized
INFO - 2023-07-24 14:25:26 --> Helper loaded: url_helper
INFO - 2023-07-24 14:25:26 --> Helper loaded: file_helper
INFO - 2023-07-24 14:25:26 --> Helper loaded: html_helper
INFO - 2023-07-24 14:25:26 --> Helper loaded: text_helper
INFO - 2023-07-24 14:25:26 --> Helper loaded: form_helper
INFO - 2023-07-24 14:25:26 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:25:26 --> Helper loaded: security_helper
INFO - 2023-07-24 14:25:26 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:25:26 --> Database Driver Class Initialized
INFO - 2023-07-24 14:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:25:26 --> Parser Class Initialized
INFO - 2023-07-24 14:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:25:26 --> Pagination Class Initialized
INFO - 2023-07-24 14:25:26 --> Form Validation Class Initialized
INFO - 2023-07-24 14:25:26 --> Controller Class Initialized
INFO - 2023-07-24 14:25:26 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:26 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:26 --> Model Class Initialized
INFO - 2023-07-24 14:25:26 --> Final output sent to browser
DEBUG - 2023-07-24 14:25:26 --> Total execution time: 0.3481
ERROR - 2023-07-24 14:25:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:25:32 --> Config Class Initialized
INFO - 2023-07-24 14:25:32 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:25:32 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:25:32 --> Utf8 Class Initialized
INFO - 2023-07-24 14:25:32 --> URI Class Initialized
INFO - 2023-07-24 14:25:32 --> Router Class Initialized
INFO - 2023-07-24 14:25:32 --> Output Class Initialized
INFO - 2023-07-24 14:25:32 --> Security Class Initialized
DEBUG - 2023-07-24 14:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:25:32 --> Input Class Initialized
INFO - 2023-07-24 14:25:32 --> Language Class Initialized
INFO - 2023-07-24 14:25:32 --> Loader Class Initialized
INFO - 2023-07-24 14:25:32 --> Helper loaded: url_helper
INFO - 2023-07-24 14:25:32 --> Helper loaded: file_helper
INFO - 2023-07-24 14:25:32 --> Helper loaded: html_helper
INFO - 2023-07-24 14:25:32 --> Helper loaded: text_helper
INFO - 2023-07-24 14:25:32 --> Helper loaded: form_helper
INFO - 2023-07-24 14:25:32 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:25:32 --> Helper loaded: security_helper
INFO - 2023-07-24 14:25:32 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:25:32 --> Database Driver Class Initialized
INFO - 2023-07-24 14:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:25:32 --> Parser Class Initialized
INFO - 2023-07-24 14:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:25:32 --> Pagination Class Initialized
INFO - 2023-07-24 14:25:32 --> Form Validation Class Initialized
INFO - 2023-07-24 14:25:32 --> Controller Class Initialized
INFO - 2023-07-24 14:25:32 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:32 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:32 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-24 14:25:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:25:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:25:32 --> Model Class Initialized
INFO - 2023-07-24 14:25:32 --> Model Class Initialized
INFO - 2023-07-24 14:25:32 --> Model Class Initialized
INFO - 2023-07-24 14:25:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:25:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:25:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:25:32 --> Final output sent to browser
DEBUG - 2023-07-24 14:25:32 --> Total execution time: 0.1288
ERROR - 2023-07-24 14:25:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:25:41 --> Config Class Initialized
INFO - 2023-07-24 14:25:41 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:25:41 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:25:41 --> Utf8 Class Initialized
INFO - 2023-07-24 14:25:41 --> URI Class Initialized
INFO - 2023-07-24 14:25:41 --> Router Class Initialized
INFO - 2023-07-24 14:25:41 --> Output Class Initialized
INFO - 2023-07-24 14:25:41 --> Security Class Initialized
DEBUG - 2023-07-24 14:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:25:41 --> Input Class Initialized
INFO - 2023-07-24 14:25:41 --> Language Class Initialized
INFO - 2023-07-24 14:25:41 --> Loader Class Initialized
INFO - 2023-07-24 14:25:41 --> Helper loaded: url_helper
INFO - 2023-07-24 14:25:41 --> Helper loaded: file_helper
INFO - 2023-07-24 14:25:41 --> Helper loaded: html_helper
INFO - 2023-07-24 14:25:41 --> Helper loaded: text_helper
INFO - 2023-07-24 14:25:41 --> Helper loaded: form_helper
INFO - 2023-07-24 14:25:41 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:25:41 --> Helper loaded: security_helper
INFO - 2023-07-24 14:25:41 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:25:41 --> Database Driver Class Initialized
INFO - 2023-07-24 14:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:25:41 --> Parser Class Initialized
INFO - 2023-07-24 14:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:25:41 --> Pagination Class Initialized
INFO - 2023-07-24 14:25:41 --> Form Validation Class Initialized
INFO - 2023-07-24 14:25:41 --> Controller Class Initialized
INFO - 2023-07-24 14:25:41 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:41 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:41 --> Model Class Initialized
INFO - 2023-07-24 14:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-24 14:25:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:25:41 --> Model Class Initialized
INFO - 2023-07-24 14:25:41 --> Model Class Initialized
INFO - 2023-07-24 14:25:41 --> Model Class Initialized
INFO - 2023-07-24 14:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:25:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:25:41 --> Final output sent to browser
DEBUG - 2023-07-24 14:25:41 --> Total execution time: 0.1421
ERROR - 2023-07-24 14:25:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:25:42 --> Config Class Initialized
INFO - 2023-07-24 14:25:42 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:25:42 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:25:42 --> Utf8 Class Initialized
INFO - 2023-07-24 14:25:42 --> URI Class Initialized
INFO - 2023-07-24 14:25:42 --> Router Class Initialized
INFO - 2023-07-24 14:25:42 --> Output Class Initialized
INFO - 2023-07-24 14:25:42 --> Security Class Initialized
DEBUG - 2023-07-24 14:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:25:42 --> Input Class Initialized
INFO - 2023-07-24 14:25:42 --> Language Class Initialized
INFO - 2023-07-24 14:25:42 --> Loader Class Initialized
INFO - 2023-07-24 14:25:42 --> Helper loaded: url_helper
INFO - 2023-07-24 14:25:42 --> Helper loaded: file_helper
INFO - 2023-07-24 14:25:42 --> Helper loaded: html_helper
INFO - 2023-07-24 14:25:42 --> Helper loaded: text_helper
INFO - 2023-07-24 14:25:42 --> Helper loaded: form_helper
INFO - 2023-07-24 14:25:42 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:25:42 --> Helper loaded: security_helper
INFO - 2023-07-24 14:25:42 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:25:42 --> Database Driver Class Initialized
INFO - 2023-07-24 14:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:25:42 --> Parser Class Initialized
INFO - 2023-07-24 14:25:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:25:42 --> Pagination Class Initialized
INFO - 2023-07-24 14:25:42 --> Form Validation Class Initialized
INFO - 2023-07-24 14:25:42 --> Controller Class Initialized
INFO - 2023-07-24 14:25:42 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:25:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:42 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:42 --> Model Class Initialized
INFO - 2023-07-24 14:25:42 --> Final output sent to browser
DEBUG - 2023-07-24 14:25:42 --> Total execution time: 0.0573
ERROR - 2023-07-24 14:25:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:25:46 --> Config Class Initialized
INFO - 2023-07-24 14:25:46 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:25:46 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:25:46 --> Utf8 Class Initialized
INFO - 2023-07-24 14:25:46 --> URI Class Initialized
INFO - 2023-07-24 14:25:46 --> Router Class Initialized
INFO - 2023-07-24 14:25:46 --> Output Class Initialized
INFO - 2023-07-24 14:25:46 --> Security Class Initialized
DEBUG - 2023-07-24 14:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:25:46 --> Input Class Initialized
INFO - 2023-07-24 14:25:46 --> Language Class Initialized
INFO - 2023-07-24 14:25:46 --> Loader Class Initialized
INFO - 2023-07-24 14:25:46 --> Helper loaded: url_helper
INFO - 2023-07-24 14:25:46 --> Helper loaded: file_helper
INFO - 2023-07-24 14:25:46 --> Helper loaded: html_helper
INFO - 2023-07-24 14:25:46 --> Helper loaded: text_helper
INFO - 2023-07-24 14:25:46 --> Helper loaded: form_helper
INFO - 2023-07-24 14:25:46 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:25:46 --> Helper loaded: security_helper
INFO - 2023-07-24 14:25:46 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:25:46 --> Database Driver Class Initialized
INFO - 2023-07-24 14:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:25:46 --> Parser Class Initialized
INFO - 2023-07-24 14:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:25:46 --> Pagination Class Initialized
INFO - 2023-07-24 14:25:46 --> Form Validation Class Initialized
INFO - 2023-07-24 14:25:46 --> Controller Class Initialized
INFO - 2023-07-24 14:25:46 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:46 --> Model Class Initialized
DEBUG - 2023-07-24 14:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:25:46 --> Model Class Initialized
INFO - 2023-07-24 14:25:46 --> Final output sent to browser
DEBUG - 2023-07-24 14:25:46 --> Total execution time: 0.4198
ERROR - 2023-07-24 14:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 14:26:01 --> Config Class Initialized
INFO - 2023-07-24 14:26:01 --> Hooks Class Initialized
DEBUG - 2023-07-24 14:26:01 --> UTF-8 Support Enabled
INFO - 2023-07-24 14:26:01 --> Utf8 Class Initialized
INFO - 2023-07-24 14:26:01 --> URI Class Initialized
DEBUG - 2023-07-24 14:26:01 --> No URI present. Default controller set.
INFO - 2023-07-24 14:26:01 --> Router Class Initialized
INFO - 2023-07-24 14:26:01 --> Output Class Initialized
INFO - 2023-07-24 14:26:01 --> Security Class Initialized
DEBUG - 2023-07-24 14:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 14:26:01 --> Input Class Initialized
INFO - 2023-07-24 14:26:01 --> Language Class Initialized
INFO - 2023-07-24 14:26:01 --> Loader Class Initialized
INFO - 2023-07-24 14:26:01 --> Helper loaded: url_helper
INFO - 2023-07-24 14:26:01 --> Helper loaded: file_helper
INFO - 2023-07-24 14:26:01 --> Helper loaded: html_helper
INFO - 2023-07-24 14:26:01 --> Helper loaded: text_helper
INFO - 2023-07-24 14:26:01 --> Helper loaded: form_helper
INFO - 2023-07-24 14:26:01 --> Helper loaded: lang_helper
INFO - 2023-07-24 14:26:01 --> Helper loaded: security_helper
INFO - 2023-07-24 14:26:01 --> Helper loaded: cookie_helper
INFO - 2023-07-24 14:26:01 --> Database Driver Class Initialized
INFO - 2023-07-24 14:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 14:26:01 --> Parser Class Initialized
INFO - 2023-07-24 14:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 14:26:01 --> Pagination Class Initialized
INFO - 2023-07-24 14:26:01 --> Form Validation Class Initialized
INFO - 2023-07-24 14:26:01 --> Controller Class Initialized
INFO - 2023-07-24 14:26:01 --> Model Class Initialized
DEBUG - 2023-07-24 14:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:26:01 --> Model Class Initialized
DEBUG - 2023-07-24 14:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:26:01 --> Model Class Initialized
INFO - 2023-07-24 14:26:01 --> Model Class Initialized
INFO - 2023-07-24 14:26:01 --> Model Class Initialized
INFO - 2023-07-24 14:26:01 --> Model Class Initialized
DEBUG - 2023-07-24 14:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 14:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:26:01 --> Model Class Initialized
INFO - 2023-07-24 14:26:01 --> Model Class Initialized
INFO - 2023-07-24 14:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 14:26:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 14:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 14:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 14:26:01 --> Model Class Initialized
INFO - 2023-07-24 14:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 14:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 14:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 14:26:01 --> Final output sent to browser
DEBUG - 2023-07-24 14:26:01 --> Total execution time: 0.1914
ERROR - 2023-07-24 15:00:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:00:33 --> Config Class Initialized
INFO - 2023-07-24 15:00:33 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:00:33 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:00:33 --> Utf8 Class Initialized
INFO - 2023-07-24 15:00:33 --> URI Class Initialized
DEBUG - 2023-07-24 15:00:33 --> No URI present. Default controller set.
INFO - 2023-07-24 15:00:33 --> Router Class Initialized
INFO - 2023-07-24 15:00:33 --> Output Class Initialized
INFO - 2023-07-24 15:00:33 --> Security Class Initialized
DEBUG - 2023-07-24 15:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:00:33 --> Input Class Initialized
INFO - 2023-07-24 15:00:33 --> Language Class Initialized
INFO - 2023-07-24 15:00:33 --> Loader Class Initialized
INFO - 2023-07-24 15:00:33 --> Helper loaded: url_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: file_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: html_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: text_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: form_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: security_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:00:33 --> Database Driver Class Initialized
INFO - 2023-07-24 15:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:00:33 --> Parser Class Initialized
INFO - 2023-07-24 15:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:00:33 --> Pagination Class Initialized
INFO - 2023-07-24 15:00:33 --> Form Validation Class Initialized
INFO - 2023-07-24 15:00:33 --> Controller Class Initialized
INFO - 2023-07-24 15:00:33 --> Model Class Initialized
DEBUG - 2023-07-24 15:00:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-24 15:00:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:00:33 --> Config Class Initialized
INFO - 2023-07-24 15:00:33 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:00:33 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:00:33 --> Utf8 Class Initialized
INFO - 2023-07-24 15:00:33 --> URI Class Initialized
INFO - 2023-07-24 15:00:33 --> Router Class Initialized
INFO - 2023-07-24 15:00:33 --> Output Class Initialized
INFO - 2023-07-24 15:00:33 --> Security Class Initialized
DEBUG - 2023-07-24 15:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:00:33 --> Input Class Initialized
INFO - 2023-07-24 15:00:33 --> Language Class Initialized
INFO - 2023-07-24 15:00:33 --> Loader Class Initialized
INFO - 2023-07-24 15:00:33 --> Helper loaded: url_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: file_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: html_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: text_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: form_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: security_helper
INFO - 2023-07-24 15:00:33 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:00:33 --> Database Driver Class Initialized
INFO - 2023-07-24 15:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:00:33 --> Parser Class Initialized
INFO - 2023-07-24 15:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:00:33 --> Pagination Class Initialized
INFO - 2023-07-24 15:00:33 --> Form Validation Class Initialized
INFO - 2023-07-24 15:00:33 --> Controller Class Initialized
INFO - 2023-07-24 15:00:33 --> Model Class Initialized
DEBUG - 2023-07-24 15:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-24 15:00:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:00:33 --> Model Class Initialized
INFO - 2023-07-24 15:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:00:33 --> Final output sent to browser
DEBUG - 2023-07-24 15:00:33 --> Total execution time: 0.0302
ERROR - 2023-07-24 15:00:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:00:54 --> Config Class Initialized
INFO - 2023-07-24 15:00:54 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:00:54 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:00:54 --> Utf8 Class Initialized
INFO - 2023-07-24 15:00:54 --> URI Class Initialized
INFO - 2023-07-24 15:00:54 --> Router Class Initialized
INFO - 2023-07-24 15:00:54 --> Output Class Initialized
INFO - 2023-07-24 15:00:54 --> Security Class Initialized
DEBUG - 2023-07-24 15:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:00:54 --> Input Class Initialized
INFO - 2023-07-24 15:00:54 --> Language Class Initialized
INFO - 2023-07-24 15:00:54 --> Loader Class Initialized
INFO - 2023-07-24 15:00:54 --> Helper loaded: url_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: file_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: html_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: text_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: form_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: security_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:00:54 --> Database Driver Class Initialized
INFO - 2023-07-24 15:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:00:54 --> Parser Class Initialized
INFO - 2023-07-24 15:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:00:54 --> Pagination Class Initialized
INFO - 2023-07-24 15:00:54 --> Form Validation Class Initialized
INFO - 2023-07-24 15:00:54 --> Controller Class Initialized
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
DEBUG - 2023-07-24 15:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
INFO - 2023-07-24 15:00:54 --> Final output sent to browser
DEBUG - 2023-07-24 15:00:54 --> Total execution time: 0.0198
ERROR - 2023-07-24 15:00:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:00:54 --> Config Class Initialized
INFO - 2023-07-24 15:00:54 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:00:54 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:00:54 --> Utf8 Class Initialized
INFO - 2023-07-24 15:00:54 --> URI Class Initialized
DEBUG - 2023-07-24 15:00:54 --> No URI present. Default controller set.
INFO - 2023-07-24 15:00:54 --> Router Class Initialized
INFO - 2023-07-24 15:00:54 --> Output Class Initialized
INFO - 2023-07-24 15:00:54 --> Security Class Initialized
DEBUG - 2023-07-24 15:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:00:54 --> Input Class Initialized
INFO - 2023-07-24 15:00:54 --> Language Class Initialized
INFO - 2023-07-24 15:00:54 --> Loader Class Initialized
INFO - 2023-07-24 15:00:54 --> Helper loaded: url_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: file_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: html_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: text_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: form_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: security_helper
INFO - 2023-07-24 15:00:54 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:00:54 --> Database Driver Class Initialized
INFO - 2023-07-24 15:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:00:54 --> Parser Class Initialized
INFO - 2023-07-24 15:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:00:54 --> Pagination Class Initialized
INFO - 2023-07-24 15:00:54 --> Form Validation Class Initialized
INFO - 2023-07-24 15:00:54 --> Controller Class Initialized
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
DEBUG - 2023-07-24 15:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
DEBUG - 2023-07-24 15:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
DEBUG - 2023-07-24 15:00:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 15:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
INFO - 2023-07-24 15:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 15:00:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:00:54 --> Model Class Initialized
INFO - 2023-07-24 15:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 15:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 15:00:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:00:54 --> Final output sent to browser
DEBUG - 2023-07-24 15:00:54 --> Total execution time: 0.0724
ERROR - 2023-07-24 15:01:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:01:11 --> Config Class Initialized
INFO - 2023-07-24 15:01:11 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:01:11 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:01:11 --> Utf8 Class Initialized
INFO - 2023-07-24 15:01:11 --> URI Class Initialized
INFO - 2023-07-24 15:01:11 --> Router Class Initialized
INFO - 2023-07-24 15:01:11 --> Output Class Initialized
INFO - 2023-07-24 15:01:11 --> Security Class Initialized
DEBUG - 2023-07-24 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:01:11 --> Input Class Initialized
INFO - 2023-07-24 15:01:11 --> Language Class Initialized
INFO - 2023-07-24 15:01:11 --> Loader Class Initialized
INFO - 2023-07-24 15:01:11 --> Helper loaded: url_helper
INFO - 2023-07-24 15:01:11 --> Helper loaded: file_helper
INFO - 2023-07-24 15:01:11 --> Helper loaded: html_helper
INFO - 2023-07-24 15:01:11 --> Helper loaded: text_helper
INFO - 2023-07-24 15:01:11 --> Helper loaded: form_helper
INFO - 2023-07-24 15:01:11 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:01:11 --> Helper loaded: security_helper
INFO - 2023-07-24 15:01:11 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:01:11 --> Database Driver Class Initialized
INFO - 2023-07-24 15:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:01:11 --> Parser Class Initialized
INFO - 2023-07-24 15:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:01:11 --> Pagination Class Initialized
INFO - 2023-07-24 15:01:11 --> Form Validation Class Initialized
INFO - 2023-07-24 15:01:11 --> Controller Class Initialized
INFO - 2023-07-24 15:01:11 --> Model Class Initialized
DEBUG - 2023-07-24 15:01:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 15:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:11 --> Model Class Initialized
DEBUG - 2023-07-24 15:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-07-24 15:01:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:01:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:01:11 --> Model Class Initialized
INFO - 2023-07-24 15:01:11 --> Model Class Initialized
INFO - 2023-07-24 15:01:11 --> Model Class Initialized
INFO - 2023-07-24 15:01:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 15:01:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 15:01:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:01:11 --> Final output sent to browser
DEBUG - 2023-07-24 15:01:11 --> Total execution time: 0.0724
ERROR - 2023-07-24 15:01:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:01:37 --> Config Class Initialized
INFO - 2023-07-24 15:01:37 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:01:37 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:01:37 --> Utf8 Class Initialized
INFO - 2023-07-24 15:01:37 --> URI Class Initialized
INFO - 2023-07-24 15:01:37 --> Router Class Initialized
INFO - 2023-07-24 15:01:37 --> Output Class Initialized
INFO - 2023-07-24 15:01:37 --> Security Class Initialized
DEBUG - 2023-07-24 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:01:37 --> Input Class Initialized
INFO - 2023-07-24 15:01:37 --> Language Class Initialized
INFO - 2023-07-24 15:01:37 --> Loader Class Initialized
INFO - 2023-07-24 15:01:37 --> Helper loaded: url_helper
INFO - 2023-07-24 15:01:37 --> Helper loaded: file_helper
INFO - 2023-07-24 15:01:37 --> Helper loaded: html_helper
INFO - 2023-07-24 15:01:37 --> Helper loaded: text_helper
INFO - 2023-07-24 15:01:37 --> Helper loaded: form_helper
INFO - 2023-07-24 15:01:37 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:01:37 --> Helper loaded: security_helper
INFO - 2023-07-24 15:01:37 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:01:37 --> Database Driver Class Initialized
INFO - 2023-07-24 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:01:37 --> Parser Class Initialized
INFO - 2023-07-24 15:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:01:37 --> Pagination Class Initialized
INFO - 2023-07-24 15:01:37 --> Form Validation Class Initialized
INFO - 2023-07-24 15:01:37 --> Controller Class Initialized
INFO - 2023-07-24 15:01:37 --> Model Class Initialized
DEBUG - 2023-07-24 15:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-24 15:01:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:01:37 --> Model Class Initialized
INFO - 2023-07-24 15:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:01:37 --> Final output sent to browser
DEBUG - 2023-07-24 15:01:37 --> Total execution time: 0.0329
ERROR - 2023-07-24 15:01:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:01:38 --> Config Class Initialized
INFO - 2023-07-24 15:01:38 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:01:38 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:01:38 --> Utf8 Class Initialized
INFO - 2023-07-24 15:01:38 --> URI Class Initialized
INFO - 2023-07-24 15:01:38 --> Router Class Initialized
INFO - 2023-07-24 15:01:38 --> Output Class Initialized
INFO - 2023-07-24 15:01:38 --> Security Class Initialized
DEBUG - 2023-07-24 15:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:01:38 --> Input Class Initialized
INFO - 2023-07-24 15:01:38 --> Language Class Initialized
INFO - 2023-07-24 15:01:38 --> Loader Class Initialized
INFO - 2023-07-24 15:01:38 --> Helper loaded: url_helper
INFO - 2023-07-24 15:01:38 --> Helper loaded: file_helper
INFO - 2023-07-24 15:01:38 --> Helper loaded: html_helper
INFO - 2023-07-24 15:01:38 --> Helper loaded: text_helper
INFO - 2023-07-24 15:01:38 --> Helper loaded: form_helper
INFO - 2023-07-24 15:01:38 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:01:38 --> Helper loaded: security_helper
INFO - 2023-07-24 15:01:38 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:01:38 --> Database Driver Class Initialized
INFO - 2023-07-24 15:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:01:38 --> Parser Class Initialized
INFO - 2023-07-24 15:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:01:38 --> Pagination Class Initialized
INFO - 2023-07-24 15:01:38 --> Form Validation Class Initialized
INFO - 2023-07-24 15:01:38 --> Controller Class Initialized
INFO - 2023-07-24 15:01:38 --> Model Class Initialized
DEBUG - 2023-07-24 15:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:38 --> Model Class Initialized
DEBUG - 2023-07-24 15:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:38 --> Model Class Initialized
INFO - 2023-07-24 15:01:38 --> Model Class Initialized
INFO - 2023-07-24 15:01:38 --> Model Class Initialized
INFO - 2023-07-24 15:01:38 --> Model Class Initialized
DEBUG - 2023-07-24 15:01:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 15:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:38 --> Model Class Initialized
INFO - 2023-07-24 15:01:38 --> Model Class Initialized
INFO - 2023-07-24 15:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 15:01:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:01:38 --> Model Class Initialized
INFO - 2023-07-24 15:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 15:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 15:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:01:38 --> Final output sent to browser
DEBUG - 2023-07-24 15:01:38 --> Total execution time: 0.0714
ERROR - 2023-07-24 15:01:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:01:52 --> Config Class Initialized
INFO - 2023-07-24 15:01:52 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:01:52 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:01:52 --> Utf8 Class Initialized
INFO - 2023-07-24 15:01:52 --> URI Class Initialized
INFO - 2023-07-24 15:01:52 --> Router Class Initialized
INFO - 2023-07-24 15:01:52 --> Output Class Initialized
INFO - 2023-07-24 15:01:52 --> Security Class Initialized
DEBUG - 2023-07-24 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:01:52 --> Input Class Initialized
INFO - 2023-07-24 15:01:52 --> Language Class Initialized
INFO - 2023-07-24 15:01:52 --> Loader Class Initialized
INFO - 2023-07-24 15:01:52 --> Helper loaded: url_helper
INFO - 2023-07-24 15:01:52 --> Helper loaded: file_helper
INFO - 2023-07-24 15:01:52 --> Helper loaded: html_helper
INFO - 2023-07-24 15:01:52 --> Helper loaded: text_helper
INFO - 2023-07-24 15:01:52 --> Helper loaded: form_helper
INFO - 2023-07-24 15:01:52 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:01:52 --> Helper loaded: security_helper
INFO - 2023-07-24 15:01:52 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:01:52 --> Database Driver Class Initialized
INFO - 2023-07-24 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:01:52 --> Parser Class Initialized
INFO - 2023-07-24 15:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:01:52 --> Pagination Class Initialized
INFO - 2023-07-24 15:01:52 --> Form Validation Class Initialized
INFO - 2023-07-24 15:01:52 --> Controller Class Initialized
INFO - 2023-07-24 15:01:52 --> Model Class Initialized
INFO - 2023-07-24 15:01:52 --> Model Class Initialized
INFO - 2023-07-24 15:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-24 15:01:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:01:52 --> Model Class Initialized
INFO - 2023-07-24 15:01:52 --> Model Class Initialized
INFO - 2023-07-24 15:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 15:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 15:01:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:01:52 --> Final output sent to browser
DEBUG - 2023-07-24 15:01:52 --> Total execution time: 0.0587
ERROR - 2023-07-24 15:01:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:01:54 --> Config Class Initialized
INFO - 2023-07-24 15:01:54 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:01:54 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:01:54 --> Utf8 Class Initialized
INFO - 2023-07-24 15:01:54 --> URI Class Initialized
INFO - 2023-07-24 15:01:54 --> Router Class Initialized
INFO - 2023-07-24 15:01:54 --> Output Class Initialized
INFO - 2023-07-24 15:01:54 --> Security Class Initialized
DEBUG - 2023-07-24 15:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:01:54 --> Input Class Initialized
INFO - 2023-07-24 15:01:54 --> Language Class Initialized
INFO - 2023-07-24 15:01:54 --> Loader Class Initialized
INFO - 2023-07-24 15:01:54 --> Helper loaded: url_helper
INFO - 2023-07-24 15:01:54 --> Helper loaded: file_helper
INFO - 2023-07-24 15:01:54 --> Helper loaded: html_helper
INFO - 2023-07-24 15:01:54 --> Helper loaded: text_helper
INFO - 2023-07-24 15:01:54 --> Helper loaded: form_helper
INFO - 2023-07-24 15:01:54 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:01:54 --> Helper loaded: security_helper
INFO - 2023-07-24 15:01:54 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:01:54 --> Database Driver Class Initialized
INFO - 2023-07-24 15:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:01:54 --> Parser Class Initialized
INFO - 2023-07-24 15:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:01:54 --> Pagination Class Initialized
INFO - 2023-07-24 15:01:54 --> Form Validation Class Initialized
INFO - 2023-07-24 15:01:54 --> Controller Class Initialized
INFO - 2023-07-24 15:01:54 --> Model Class Initialized
INFO - 2023-07-24 15:01:54 --> Model Class Initialized
INFO - 2023-07-24 15:01:54 --> Final output sent to browser
DEBUG - 2023-07-24 15:01:54 --> Total execution time: 0.0193
ERROR - 2023-07-24 15:02:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:02:37 --> Config Class Initialized
INFO - 2023-07-24 15:02:37 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:02:37 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:02:37 --> Utf8 Class Initialized
INFO - 2023-07-24 15:02:37 --> URI Class Initialized
INFO - 2023-07-24 15:02:37 --> Router Class Initialized
INFO - 2023-07-24 15:02:37 --> Output Class Initialized
INFO - 2023-07-24 15:02:37 --> Security Class Initialized
DEBUG - 2023-07-24 15:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:02:37 --> Input Class Initialized
INFO - 2023-07-24 15:02:37 --> Language Class Initialized
INFO - 2023-07-24 15:02:37 --> Loader Class Initialized
INFO - 2023-07-24 15:02:37 --> Helper loaded: url_helper
INFO - 2023-07-24 15:02:37 --> Helper loaded: file_helper
INFO - 2023-07-24 15:02:37 --> Helper loaded: html_helper
INFO - 2023-07-24 15:02:37 --> Helper loaded: text_helper
INFO - 2023-07-24 15:02:37 --> Helper loaded: form_helper
INFO - 2023-07-24 15:02:37 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:02:37 --> Helper loaded: security_helper
INFO - 2023-07-24 15:02:37 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:02:37 --> Database Driver Class Initialized
INFO - 2023-07-24 15:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:02:37 --> Parser Class Initialized
INFO - 2023-07-24 15:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:02:37 --> Pagination Class Initialized
INFO - 2023-07-24 15:02:37 --> Form Validation Class Initialized
INFO - 2023-07-24 15:02:37 --> Controller Class Initialized
INFO - 2023-07-24 15:02:37 --> Model Class Initialized
INFO - 2023-07-24 15:02:37 --> Model Class Initialized
INFO - 2023-07-24 15:02:37 --> Final output sent to browser
DEBUG - 2023-07-24 15:02:37 --> Total execution time: 0.0214
ERROR - 2023-07-24 15:02:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:02:55 --> Config Class Initialized
INFO - 2023-07-24 15:02:55 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:02:55 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:02:55 --> Utf8 Class Initialized
INFO - 2023-07-24 15:02:55 --> URI Class Initialized
INFO - 2023-07-24 15:02:55 --> Router Class Initialized
INFO - 2023-07-24 15:02:55 --> Output Class Initialized
INFO - 2023-07-24 15:02:55 --> Security Class Initialized
DEBUG - 2023-07-24 15:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:02:55 --> Input Class Initialized
INFO - 2023-07-24 15:02:55 --> Language Class Initialized
INFO - 2023-07-24 15:02:55 --> Loader Class Initialized
INFO - 2023-07-24 15:02:55 --> Helper loaded: url_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: file_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: html_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: text_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: form_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: security_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:02:55 --> Database Driver Class Initialized
INFO - 2023-07-24 15:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:02:55 --> Parser Class Initialized
INFO - 2023-07-24 15:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:02:55 --> Pagination Class Initialized
INFO - 2023-07-24 15:02:55 --> Form Validation Class Initialized
INFO - 2023-07-24 15:02:55 --> Controller Class Initialized
INFO - 2023-07-24 15:02:55 --> Model Class Initialized
INFO - 2023-07-24 15:02:55 --> Model Class Initialized
INFO - 2023-07-24 15:02:55 --> Final output sent to browser
DEBUG - 2023-07-24 15:02:55 --> Total execution time: 0.0197
ERROR - 2023-07-24 15:02:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:02:55 --> Config Class Initialized
INFO - 2023-07-24 15:02:55 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:02:55 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:02:55 --> Utf8 Class Initialized
INFO - 2023-07-24 15:02:55 --> URI Class Initialized
INFO - 2023-07-24 15:02:55 --> Router Class Initialized
INFO - 2023-07-24 15:02:55 --> Output Class Initialized
INFO - 2023-07-24 15:02:55 --> Security Class Initialized
DEBUG - 2023-07-24 15:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:02:55 --> Input Class Initialized
INFO - 2023-07-24 15:02:55 --> Language Class Initialized
INFO - 2023-07-24 15:02:55 --> Loader Class Initialized
INFO - 2023-07-24 15:02:55 --> Helper loaded: url_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: file_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: html_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: text_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: form_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: security_helper
INFO - 2023-07-24 15:02:55 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:02:55 --> Database Driver Class Initialized
INFO - 2023-07-24 15:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:02:55 --> Parser Class Initialized
INFO - 2023-07-24 15:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:02:55 --> Pagination Class Initialized
INFO - 2023-07-24 15:02:55 --> Form Validation Class Initialized
INFO - 2023-07-24 15:02:55 --> Controller Class Initialized
INFO - 2023-07-24 15:02:55 --> Model Class Initialized
INFO - 2023-07-24 15:02:55 --> Model Class Initialized
INFO - 2023-07-24 15:02:55 --> Final output sent to browser
DEBUG - 2023-07-24 15:02:55 --> Total execution time: 0.0177
ERROR - 2023-07-24 15:02:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:02:56 --> Config Class Initialized
INFO - 2023-07-24 15:02:56 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:02:56 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:02:56 --> Utf8 Class Initialized
INFO - 2023-07-24 15:02:56 --> URI Class Initialized
INFO - 2023-07-24 15:02:56 --> Router Class Initialized
INFO - 2023-07-24 15:02:56 --> Output Class Initialized
INFO - 2023-07-24 15:02:56 --> Security Class Initialized
DEBUG - 2023-07-24 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:02:56 --> Input Class Initialized
INFO - 2023-07-24 15:02:56 --> Language Class Initialized
INFO - 2023-07-24 15:02:56 --> Loader Class Initialized
INFO - 2023-07-24 15:02:56 --> Helper loaded: url_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: file_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: html_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: text_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: form_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: security_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:02:56 --> Database Driver Class Initialized
INFO - 2023-07-24 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:02:56 --> Parser Class Initialized
INFO - 2023-07-24 15:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:02:56 --> Pagination Class Initialized
INFO - 2023-07-24 15:02:56 --> Form Validation Class Initialized
INFO - 2023-07-24 15:02:56 --> Controller Class Initialized
INFO - 2023-07-24 15:02:56 --> Model Class Initialized
INFO - 2023-07-24 15:02:56 --> Model Class Initialized
INFO - 2023-07-24 15:02:56 --> Final output sent to browser
DEBUG - 2023-07-24 15:02:56 --> Total execution time: 0.0187
ERROR - 2023-07-24 15:02:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:02:56 --> Config Class Initialized
INFO - 2023-07-24 15:02:56 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:02:56 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:02:56 --> Utf8 Class Initialized
INFO - 2023-07-24 15:02:56 --> URI Class Initialized
INFO - 2023-07-24 15:02:56 --> Router Class Initialized
INFO - 2023-07-24 15:02:56 --> Output Class Initialized
INFO - 2023-07-24 15:02:56 --> Security Class Initialized
DEBUG - 2023-07-24 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:02:56 --> Input Class Initialized
INFO - 2023-07-24 15:02:56 --> Language Class Initialized
INFO - 2023-07-24 15:02:56 --> Loader Class Initialized
INFO - 2023-07-24 15:02:56 --> Helper loaded: url_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: file_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: html_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: text_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: form_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: security_helper
INFO - 2023-07-24 15:02:56 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:02:56 --> Database Driver Class Initialized
INFO - 2023-07-24 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:02:56 --> Parser Class Initialized
INFO - 2023-07-24 15:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:02:56 --> Pagination Class Initialized
INFO - 2023-07-24 15:02:56 --> Form Validation Class Initialized
INFO - 2023-07-24 15:02:56 --> Controller Class Initialized
INFO - 2023-07-24 15:02:56 --> Model Class Initialized
INFO - 2023-07-24 15:02:56 --> Model Class Initialized
INFO - 2023-07-24 15:02:56 --> Final output sent to browser
DEBUG - 2023-07-24 15:02:56 --> Total execution time: 0.0181
ERROR - 2023-07-24 15:03:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:00 --> Config Class Initialized
INFO - 2023-07-24 15:03:00 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:00 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:00 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:00 --> URI Class Initialized
INFO - 2023-07-24 15:03:00 --> Router Class Initialized
INFO - 2023-07-24 15:03:00 --> Output Class Initialized
INFO - 2023-07-24 15:03:00 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:00 --> Input Class Initialized
INFO - 2023-07-24 15:03:00 --> Language Class Initialized
INFO - 2023-07-24 15:03:00 --> Loader Class Initialized
INFO - 2023-07-24 15:03:00 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:00 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:00 --> Parser Class Initialized
INFO - 2023-07-24 15:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:00 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:00 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:00 --> Controller Class Initialized
INFO - 2023-07-24 15:03:00 --> Model Class Initialized
INFO - 2023-07-24 15:03:00 --> Model Class Initialized
INFO - 2023-07-24 15:03:00 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:00 --> Total execution time: 0.0173
ERROR - 2023-07-24 15:03:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:00 --> Config Class Initialized
INFO - 2023-07-24 15:03:00 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:00 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:00 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:00 --> URI Class Initialized
INFO - 2023-07-24 15:03:00 --> Router Class Initialized
INFO - 2023-07-24 15:03:00 --> Output Class Initialized
INFO - 2023-07-24 15:03:00 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:00 --> Input Class Initialized
INFO - 2023-07-24 15:03:00 --> Language Class Initialized
INFO - 2023-07-24 15:03:00 --> Loader Class Initialized
INFO - 2023-07-24 15:03:00 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:00 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:00 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:00 --> Parser Class Initialized
INFO - 2023-07-24 15:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:00 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:00 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:00 --> Controller Class Initialized
INFO - 2023-07-24 15:03:00 --> Model Class Initialized
INFO - 2023-07-24 15:03:00 --> Model Class Initialized
INFO - 2023-07-24 15:03:00 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:00 --> Total execution time: 0.0168
ERROR - 2023-07-24 15:03:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:03 --> Config Class Initialized
INFO - 2023-07-24 15:03:03 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:03 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:03 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:03 --> URI Class Initialized
INFO - 2023-07-24 15:03:03 --> Router Class Initialized
INFO - 2023-07-24 15:03:03 --> Output Class Initialized
INFO - 2023-07-24 15:03:03 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:03 --> Input Class Initialized
INFO - 2023-07-24 15:03:03 --> Language Class Initialized
INFO - 2023-07-24 15:03:03 --> Loader Class Initialized
INFO - 2023-07-24 15:03:03 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:03 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:03 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:03 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:03 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:03 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:03 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:03 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:03 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:03 --> Parser Class Initialized
INFO - 2023-07-24 15:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:03 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:03 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:03 --> Controller Class Initialized
INFO - 2023-07-24 15:03:03 --> Model Class Initialized
INFO - 2023-07-24 15:03:03 --> Model Class Initialized
INFO - 2023-07-24 15:03:03 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:03 --> Total execution time: 0.0172
ERROR - 2023-07-24 15:03:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:04 --> Config Class Initialized
INFO - 2023-07-24 15:03:04 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:04 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:04 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:04 --> URI Class Initialized
INFO - 2023-07-24 15:03:04 --> Router Class Initialized
INFO - 2023-07-24 15:03:04 --> Output Class Initialized
INFO - 2023-07-24 15:03:04 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:04 --> Input Class Initialized
INFO - 2023-07-24 15:03:04 --> Language Class Initialized
INFO - 2023-07-24 15:03:04 --> Loader Class Initialized
INFO - 2023-07-24 15:03:04 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:04 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:04 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:04 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:04 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:04 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:04 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:04 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:04 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:04 --> Parser Class Initialized
INFO - 2023-07-24 15:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:04 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:04 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:04 --> Controller Class Initialized
INFO - 2023-07-24 15:03:04 --> Model Class Initialized
INFO - 2023-07-24 15:03:04 --> Model Class Initialized
INFO - 2023-07-24 15:03:04 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:04 --> Total execution time: 0.0216
ERROR - 2023-07-24 15:03:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:05 --> Config Class Initialized
INFO - 2023-07-24 15:03:05 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:05 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:05 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:05 --> URI Class Initialized
INFO - 2023-07-24 15:03:05 --> Router Class Initialized
INFO - 2023-07-24 15:03:05 --> Output Class Initialized
INFO - 2023-07-24 15:03:05 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:05 --> Input Class Initialized
INFO - 2023-07-24 15:03:05 --> Language Class Initialized
INFO - 2023-07-24 15:03:05 --> Loader Class Initialized
INFO - 2023-07-24 15:03:05 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:05 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:05 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:05 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:05 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:05 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:05 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:05 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:05 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:05 --> Parser Class Initialized
INFO - 2023-07-24 15:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:05 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:05 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:05 --> Controller Class Initialized
INFO - 2023-07-24 15:03:05 --> Model Class Initialized
INFO - 2023-07-24 15:03:05 --> Model Class Initialized
INFO - 2023-07-24 15:03:05 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:05 --> Total execution time: 0.0214
ERROR - 2023-07-24 15:03:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:05 --> Config Class Initialized
INFO - 2023-07-24 15:03:05 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:06 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:06 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:06 --> URI Class Initialized
INFO - 2023-07-24 15:03:06 --> Router Class Initialized
INFO - 2023-07-24 15:03:06 --> Output Class Initialized
INFO - 2023-07-24 15:03:06 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:06 --> Input Class Initialized
INFO - 2023-07-24 15:03:06 --> Language Class Initialized
INFO - 2023-07-24 15:03:06 --> Loader Class Initialized
INFO - 2023-07-24 15:03:06 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:06 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:06 --> Parser Class Initialized
INFO - 2023-07-24 15:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:06 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:06 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:06 --> Controller Class Initialized
INFO - 2023-07-24 15:03:06 --> Model Class Initialized
INFO - 2023-07-24 15:03:06 --> Model Class Initialized
INFO - 2023-07-24 15:03:06 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:06 --> Total execution time: 0.0186
ERROR - 2023-07-24 15:03:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:06 --> Config Class Initialized
INFO - 2023-07-24 15:03:06 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:06 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:06 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:06 --> URI Class Initialized
INFO - 2023-07-24 15:03:06 --> Router Class Initialized
INFO - 2023-07-24 15:03:06 --> Output Class Initialized
INFO - 2023-07-24 15:03:06 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:06 --> Input Class Initialized
INFO - 2023-07-24 15:03:06 --> Language Class Initialized
INFO - 2023-07-24 15:03:06 --> Loader Class Initialized
INFO - 2023-07-24 15:03:06 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:06 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:06 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:06 --> Parser Class Initialized
INFO - 2023-07-24 15:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:06 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:06 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:06 --> Controller Class Initialized
INFO - 2023-07-24 15:03:06 --> Model Class Initialized
INFO - 2023-07-24 15:03:06 --> Model Class Initialized
INFO - 2023-07-24 15:03:06 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:06 --> Total execution time: 0.0191
ERROR - 2023-07-24 15:03:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:13 --> Config Class Initialized
INFO - 2023-07-24 15:03:13 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:13 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:13 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:13 --> URI Class Initialized
INFO - 2023-07-24 15:03:13 --> Router Class Initialized
INFO - 2023-07-24 15:03:13 --> Output Class Initialized
INFO - 2023-07-24 15:03:13 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:13 --> Input Class Initialized
INFO - 2023-07-24 15:03:13 --> Language Class Initialized
INFO - 2023-07-24 15:03:13 --> Loader Class Initialized
INFO - 2023-07-24 15:03:13 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:13 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:13 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:13 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:13 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:13 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:13 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:13 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:13 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:13 --> Parser Class Initialized
INFO - 2023-07-24 15:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:13 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:13 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:13 --> Controller Class Initialized
INFO - 2023-07-24 15:03:13 --> Model Class Initialized
INFO - 2023-07-24 15:03:13 --> Model Class Initialized
INFO - 2023-07-24 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-07-24 15:03:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:03:13 --> Model Class Initialized
INFO - 2023-07-24 15:03:13 --> Model Class Initialized
INFO - 2023-07-24 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 15:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:03:13 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:13 --> Total execution time: 0.0608
ERROR - 2023-07-24 15:03:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:16 --> Config Class Initialized
INFO - 2023-07-24 15:03:16 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:16 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:16 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:16 --> URI Class Initialized
INFO - 2023-07-24 15:03:16 --> Router Class Initialized
INFO - 2023-07-24 15:03:16 --> Output Class Initialized
INFO - 2023-07-24 15:03:16 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:16 --> Input Class Initialized
INFO - 2023-07-24 15:03:16 --> Language Class Initialized
INFO - 2023-07-24 15:03:16 --> Loader Class Initialized
INFO - 2023-07-24 15:03:16 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:16 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:16 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:16 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:16 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:16 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:16 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:16 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:16 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:16 --> Parser Class Initialized
INFO - 2023-07-24 15:03:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:16 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:16 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:16 --> Controller Class Initialized
INFO - 2023-07-24 15:03:16 --> Model Class Initialized
INFO - 2023-07-24 15:03:16 --> Model Class Initialized
INFO - 2023-07-24 15:03:16 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:16 --> Total execution time: 0.0332
ERROR - 2023-07-24 15:03:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:45 --> Config Class Initialized
INFO - 2023-07-24 15:03:45 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:45 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:45 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:45 --> URI Class Initialized
INFO - 2023-07-24 15:03:45 --> Router Class Initialized
INFO - 2023-07-24 15:03:45 --> Output Class Initialized
INFO - 2023-07-24 15:03:45 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:45 --> Input Class Initialized
INFO - 2023-07-24 15:03:45 --> Language Class Initialized
INFO - 2023-07-24 15:03:45 --> Loader Class Initialized
INFO - 2023-07-24 15:03:45 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:45 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:45 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:45 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:45 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:45 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:45 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:45 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:45 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:45 --> Parser Class Initialized
INFO - 2023-07-24 15:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:45 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:45 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:45 --> Controller Class Initialized
INFO - 2023-07-24 15:03:45 --> Model Class Initialized
INFO - 2023-07-24 15:03:45 --> Model Class Initialized
INFO - 2023-07-24 15:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-24 15:03:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:03:45 --> Model Class Initialized
INFO - 2023-07-24 15:03:45 --> Model Class Initialized
INFO - 2023-07-24 15:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 15:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 15:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:03:45 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:45 --> Total execution time: 0.0589
ERROR - 2023-07-24 15:03:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:46 --> Config Class Initialized
INFO - 2023-07-24 15:03:46 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:46 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:46 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:46 --> URI Class Initialized
INFO - 2023-07-24 15:03:46 --> Router Class Initialized
INFO - 2023-07-24 15:03:46 --> Output Class Initialized
INFO - 2023-07-24 15:03:46 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:46 --> Input Class Initialized
INFO - 2023-07-24 15:03:46 --> Language Class Initialized
INFO - 2023-07-24 15:03:46 --> Loader Class Initialized
INFO - 2023-07-24 15:03:46 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:46 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:46 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:46 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:46 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:46 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:46 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:46 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:46 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:46 --> Parser Class Initialized
INFO - 2023-07-24 15:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:46 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:46 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:46 --> Controller Class Initialized
INFO - 2023-07-24 15:03:46 --> Model Class Initialized
INFO - 2023-07-24 15:03:46 --> Model Class Initialized
INFO - 2023-07-24 15:03:46 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:46 --> Total execution time: 0.0197
ERROR - 2023-07-24 15:03:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:52 --> Config Class Initialized
INFO - 2023-07-24 15:03:52 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:52 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:52 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:52 --> URI Class Initialized
INFO - 2023-07-24 15:03:52 --> Router Class Initialized
INFO - 2023-07-24 15:03:52 --> Output Class Initialized
INFO - 2023-07-24 15:03:52 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:52 --> Input Class Initialized
INFO - 2023-07-24 15:03:52 --> Language Class Initialized
INFO - 2023-07-24 15:03:52 --> Loader Class Initialized
INFO - 2023-07-24 15:03:52 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:52 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:52 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:52 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:52 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:52 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:52 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:52 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:52 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:52 --> Parser Class Initialized
INFO - 2023-07-24 15:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:52 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:52 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:52 --> Controller Class Initialized
INFO - 2023-07-24 15:03:52 --> Model Class Initialized
INFO - 2023-07-24 15:03:52 --> Model Class Initialized
INFO - 2023-07-24 15:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-07-24 15:03:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:03:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:03:52 --> Model Class Initialized
INFO - 2023-07-24 15:03:52 --> Model Class Initialized
INFO - 2023-07-24 15:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 15:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 15:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:03:53 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:53 --> Total execution time: 0.0569
ERROR - 2023-07-24 15:03:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:54 --> Config Class Initialized
INFO - 2023-07-24 15:03:54 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:54 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:54 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:54 --> URI Class Initialized
INFO - 2023-07-24 15:03:54 --> Router Class Initialized
INFO - 2023-07-24 15:03:54 --> Output Class Initialized
INFO - 2023-07-24 15:03:54 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:54 --> Input Class Initialized
INFO - 2023-07-24 15:03:54 --> Language Class Initialized
INFO - 2023-07-24 15:03:54 --> Loader Class Initialized
INFO - 2023-07-24 15:03:54 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:54 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:54 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:54 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:54 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:54 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:54 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:54 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:54 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:54 --> Parser Class Initialized
INFO - 2023-07-24 15:03:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:54 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:54 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:54 --> Controller Class Initialized
INFO - 2023-07-24 15:03:54 --> Model Class Initialized
INFO - 2023-07-24 15:03:54 --> Model Class Initialized
INFO - 2023-07-24 15:03:54 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:54 --> Total execution time: 0.0326
ERROR - 2023-07-24 15:03:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:56 --> Config Class Initialized
INFO - 2023-07-24 15:03:56 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:56 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:56 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:56 --> URI Class Initialized
INFO - 2023-07-24 15:03:56 --> Router Class Initialized
INFO - 2023-07-24 15:03:56 --> Output Class Initialized
INFO - 2023-07-24 15:03:56 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:56 --> Input Class Initialized
INFO - 2023-07-24 15:03:56 --> Language Class Initialized
INFO - 2023-07-24 15:03:56 --> Loader Class Initialized
INFO - 2023-07-24 15:03:56 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:56 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:56 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:56 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:56 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:56 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:56 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:56 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:56 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:56 --> Parser Class Initialized
INFO - 2023-07-24 15:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:56 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:56 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:56 --> Controller Class Initialized
INFO - 2023-07-24 15:03:56 --> Model Class Initialized
INFO - 2023-07-24 15:03:56 --> Model Class Initialized
INFO - 2023-07-24 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-24 15:03:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:03:56 --> Model Class Initialized
INFO - 2023-07-24 15:03:56 --> Model Class Initialized
INFO - 2023-07-24 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 15:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:03:56 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:56 --> Total execution time: 0.0632
ERROR - 2023-07-24 15:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:57 --> Config Class Initialized
INFO - 2023-07-24 15:03:57 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:57 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:57 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:57 --> URI Class Initialized
INFO - 2023-07-24 15:03:57 --> Router Class Initialized
INFO - 2023-07-24 15:03:57 --> Output Class Initialized
INFO - 2023-07-24 15:03:57 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:57 --> Input Class Initialized
INFO - 2023-07-24 15:03:57 --> Language Class Initialized
INFO - 2023-07-24 15:03:57 --> Loader Class Initialized
INFO - 2023-07-24 15:03:57 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:57 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:57 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:57 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:57 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:57 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:57 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:57 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:57 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:57 --> Parser Class Initialized
INFO - 2023-07-24 15:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:57 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:57 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:57 --> Controller Class Initialized
INFO - 2023-07-24 15:03:57 --> Model Class Initialized
INFO - 2023-07-24 15:03:57 --> Model Class Initialized
INFO - 2023-07-24 15:03:57 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:57 --> Total execution time: 0.0181
ERROR - 2023-07-24 15:03:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:03:58 --> Config Class Initialized
INFO - 2023-07-24 15:03:58 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:03:58 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:03:58 --> Utf8 Class Initialized
INFO - 2023-07-24 15:03:58 --> URI Class Initialized
INFO - 2023-07-24 15:03:58 --> Router Class Initialized
INFO - 2023-07-24 15:03:58 --> Output Class Initialized
INFO - 2023-07-24 15:03:58 --> Security Class Initialized
DEBUG - 2023-07-24 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:03:58 --> Input Class Initialized
INFO - 2023-07-24 15:03:58 --> Language Class Initialized
INFO - 2023-07-24 15:03:58 --> Loader Class Initialized
INFO - 2023-07-24 15:03:58 --> Helper loaded: url_helper
INFO - 2023-07-24 15:03:58 --> Helper loaded: file_helper
INFO - 2023-07-24 15:03:58 --> Helper loaded: html_helper
INFO - 2023-07-24 15:03:58 --> Helper loaded: text_helper
INFO - 2023-07-24 15:03:58 --> Helper loaded: form_helper
INFO - 2023-07-24 15:03:58 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:03:58 --> Helper loaded: security_helper
INFO - 2023-07-24 15:03:58 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:03:58 --> Database Driver Class Initialized
INFO - 2023-07-24 15:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:03:58 --> Parser Class Initialized
INFO - 2023-07-24 15:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:03:58 --> Pagination Class Initialized
INFO - 2023-07-24 15:03:58 --> Form Validation Class Initialized
INFO - 2023-07-24 15:03:58 --> Controller Class Initialized
INFO - 2023-07-24 15:03:58 --> Model Class Initialized
DEBUG - 2023-07-24 15:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:03:58 --> Model Class Initialized
DEBUG - 2023-07-24 15:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:03:58 --> Model Class Initialized
INFO - 2023-07-24 15:03:58 --> Model Class Initialized
INFO - 2023-07-24 15:03:58 --> Model Class Initialized
INFO - 2023-07-24 15:03:58 --> Model Class Initialized
DEBUG - 2023-07-24 15:03:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-24 15:03:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:03:58 --> Model Class Initialized
INFO - 2023-07-24 15:03:58 --> Model Class Initialized
INFO - 2023-07-24 15:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-24 15:03:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:03:58 --> Model Class Initialized
INFO - 2023-07-24 15:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-24 15:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-24 15:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:03:58 --> Final output sent to browser
DEBUG - 2023-07-24 15:03:58 --> Total execution time: 0.0685
ERROR - 2023-07-24 15:50:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:50:43 --> Config Class Initialized
INFO - 2023-07-24 15:50:43 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:50:43 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:50:43 --> Utf8 Class Initialized
INFO - 2023-07-24 15:50:43 --> URI Class Initialized
DEBUG - 2023-07-24 15:50:43 --> No URI present. Default controller set.
INFO - 2023-07-24 15:50:43 --> Router Class Initialized
INFO - 2023-07-24 15:50:43 --> Output Class Initialized
INFO - 2023-07-24 15:50:43 --> Security Class Initialized
DEBUG - 2023-07-24 15:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:50:43 --> Input Class Initialized
INFO - 2023-07-24 15:50:43 --> Language Class Initialized
INFO - 2023-07-24 15:50:43 --> Loader Class Initialized
INFO - 2023-07-24 15:50:43 --> Helper loaded: url_helper
INFO - 2023-07-24 15:50:43 --> Helper loaded: file_helper
INFO - 2023-07-24 15:50:43 --> Helper loaded: html_helper
INFO - 2023-07-24 15:50:43 --> Helper loaded: text_helper
INFO - 2023-07-24 15:50:43 --> Helper loaded: form_helper
INFO - 2023-07-24 15:50:43 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:50:43 --> Helper loaded: security_helper
INFO - 2023-07-24 15:50:43 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:50:43 --> Database Driver Class Initialized
INFO - 2023-07-24 15:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:50:43 --> Parser Class Initialized
INFO - 2023-07-24 15:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:50:43 --> Pagination Class Initialized
INFO - 2023-07-24 15:50:43 --> Form Validation Class Initialized
INFO - 2023-07-24 15:50:43 --> Controller Class Initialized
INFO - 2023-07-24 15:50:43 --> Model Class Initialized
DEBUG - 2023-07-24 15:50:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-24 15:50:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 15:50:48 --> Config Class Initialized
INFO - 2023-07-24 15:50:48 --> Hooks Class Initialized
DEBUG - 2023-07-24 15:50:48 --> UTF-8 Support Enabled
INFO - 2023-07-24 15:50:48 --> Utf8 Class Initialized
INFO - 2023-07-24 15:50:48 --> URI Class Initialized
INFO - 2023-07-24 15:50:48 --> Router Class Initialized
INFO - 2023-07-24 15:50:48 --> Output Class Initialized
INFO - 2023-07-24 15:50:48 --> Security Class Initialized
DEBUG - 2023-07-24 15:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 15:50:48 --> Input Class Initialized
INFO - 2023-07-24 15:50:48 --> Language Class Initialized
INFO - 2023-07-24 15:50:48 --> Loader Class Initialized
INFO - 2023-07-24 15:50:48 --> Helper loaded: url_helper
INFO - 2023-07-24 15:50:48 --> Helper loaded: file_helper
INFO - 2023-07-24 15:50:48 --> Helper loaded: html_helper
INFO - 2023-07-24 15:50:48 --> Helper loaded: text_helper
INFO - 2023-07-24 15:50:48 --> Helper loaded: form_helper
INFO - 2023-07-24 15:50:48 --> Helper loaded: lang_helper
INFO - 2023-07-24 15:50:48 --> Helper loaded: security_helper
INFO - 2023-07-24 15:50:48 --> Helper loaded: cookie_helper
INFO - 2023-07-24 15:50:48 --> Database Driver Class Initialized
INFO - 2023-07-24 15:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 15:50:48 --> Parser Class Initialized
INFO - 2023-07-24 15:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 15:50:48 --> Pagination Class Initialized
INFO - 2023-07-24 15:50:48 --> Form Validation Class Initialized
INFO - 2023-07-24 15:50:48 --> Controller Class Initialized
INFO - 2023-07-24 15:50:48 --> Model Class Initialized
DEBUG - 2023-07-24 15:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-24 15:50:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-24 15:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-24 15:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-24 15:50:48 --> Model Class Initialized
INFO - 2023-07-24 15:50:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-24 15:50:48 --> Final output sent to browser
DEBUG - 2023-07-24 15:50:48 --> Total execution time: 0.0291
ERROR - 2023-07-24 16:31:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 16:31:21 --> Config Class Initialized
INFO - 2023-07-24 16:31:21 --> Hooks Class Initialized
DEBUG - 2023-07-24 16:31:21 --> UTF-8 Support Enabled
INFO - 2023-07-24 16:31:21 --> Utf8 Class Initialized
INFO - 2023-07-24 16:31:21 --> URI Class Initialized
DEBUG - 2023-07-24 16:31:21 --> No URI present. Default controller set.
INFO - 2023-07-24 16:31:21 --> Router Class Initialized
INFO - 2023-07-24 16:31:21 --> Output Class Initialized
INFO - 2023-07-24 16:31:21 --> Security Class Initialized
DEBUG - 2023-07-24 16:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 16:31:21 --> Input Class Initialized
INFO - 2023-07-24 16:31:21 --> Language Class Initialized
INFO - 2023-07-24 16:31:21 --> Loader Class Initialized
INFO - 2023-07-24 16:31:21 --> Helper loaded: url_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: file_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: html_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: text_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: form_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: lang_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: security_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: cookie_helper
INFO - 2023-07-24 16:31:21 --> Database Driver Class Initialized
INFO - 2023-07-24 16:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 16:31:21 --> Parser Class Initialized
INFO - 2023-07-24 16:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 16:31:21 --> Pagination Class Initialized
INFO - 2023-07-24 16:31:21 --> Form Validation Class Initialized
INFO - 2023-07-24 16:31:21 --> Controller Class Initialized
INFO - 2023-07-24 16:31:21 --> Model Class Initialized
DEBUG - 2023-07-24 16:31:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-24 16:31:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-24 16:31:21 --> Config Class Initialized
INFO - 2023-07-24 16:31:21 --> Hooks Class Initialized
DEBUG - 2023-07-24 16:31:21 --> UTF-8 Support Enabled
INFO - 2023-07-24 16:31:21 --> Utf8 Class Initialized
INFO - 2023-07-24 16:31:21 --> URI Class Initialized
DEBUG - 2023-07-24 16:31:21 --> No URI present. Default controller set.
INFO - 2023-07-24 16:31:21 --> Router Class Initialized
INFO - 2023-07-24 16:31:21 --> Output Class Initialized
INFO - 2023-07-24 16:31:21 --> Security Class Initialized
DEBUG - 2023-07-24 16:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-24 16:31:21 --> Input Class Initialized
INFO - 2023-07-24 16:31:21 --> Language Class Initialized
INFO - 2023-07-24 16:31:21 --> Loader Class Initialized
INFO - 2023-07-24 16:31:21 --> Helper loaded: url_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: file_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: html_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: text_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: form_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: lang_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: security_helper
INFO - 2023-07-24 16:31:21 --> Helper loaded: cookie_helper
INFO - 2023-07-24 16:31:21 --> Database Driver Class Initialized
INFO - 2023-07-24 16:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-24 16:31:21 --> Parser Class Initialized
INFO - 2023-07-24 16:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-24 16:31:21 --> Pagination Class Initialized
INFO - 2023-07-24 16:31:21 --> Form Validation Class Initialized
INFO - 2023-07-24 16:31:21 --> Controller Class Initialized
INFO - 2023-07-24 16:31:21 --> Model Class Initialized
DEBUG - 2023-07-24 16:31:21 --> Session class already loaded. Second attempt ignored.
