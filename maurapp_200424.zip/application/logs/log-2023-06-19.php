<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-19 04:06:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-19 04:06:30 --> Config Class Initialized
INFO - 2023-06-19 04:06:30 --> Hooks Class Initialized
DEBUG - 2023-06-19 04:06:30 --> UTF-8 Support Enabled
INFO - 2023-06-19 04:06:30 --> Utf8 Class Initialized
INFO - 2023-06-19 04:06:30 --> URI Class Initialized
DEBUG - 2023-06-19 04:06:30 --> No URI present. Default controller set.
INFO - 2023-06-19 04:06:30 --> Router Class Initialized
INFO - 2023-06-19 04:06:30 --> Output Class Initialized
INFO - 2023-06-19 04:06:30 --> Security Class Initialized
DEBUG - 2023-06-19 04:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-19 04:06:30 --> Input Class Initialized
INFO - 2023-06-19 04:06:30 --> Language Class Initialized
INFO - 2023-06-19 04:06:30 --> Loader Class Initialized
INFO - 2023-06-19 04:06:30 --> Helper loaded: url_helper
INFO - 2023-06-19 04:06:30 --> Helper loaded: file_helper
INFO - 2023-06-19 04:06:30 --> Helper loaded: html_helper
INFO - 2023-06-19 04:06:30 --> Helper loaded: text_helper
INFO - 2023-06-19 04:06:30 --> Helper loaded: form_helper
INFO - 2023-06-19 04:06:30 --> Helper loaded: lang_helper
INFO - 2023-06-19 04:06:30 --> Helper loaded: security_helper
INFO - 2023-06-19 04:06:30 --> Helper loaded: cookie_helper
INFO - 2023-06-19 04:06:30 --> Database Driver Class Initialized
INFO - 2023-06-19 04:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-19 04:06:30 --> Parser Class Initialized
INFO - 2023-06-19 04:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-19 04:06:30 --> Pagination Class Initialized
INFO - 2023-06-19 04:06:30 --> Form Validation Class Initialized
INFO - 2023-06-19 04:06:30 --> Controller Class Initialized
INFO - 2023-06-19 04:06:30 --> Model Class Initialized
DEBUG - 2023-06-19 04:06:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-19 04:06:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-19 04:06:31 --> Config Class Initialized
INFO - 2023-06-19 04:06:31 --> Hooks Class Initialized
DEBUG - 2023-06-19 04:06:31 --> UTF-8 Support Enabled
INFO - 2023-06-19 04:06:31 --> Utf8 Class Initialized
INFO - 2023-06-19 04:06:31 --> URI Class Initialized
INFO - 2023-06-19 04:06:31 --> Router Class Initialized
INFO - 2023-06-19 04:06:31 --> Output Class Initialized
INFO - 2023-06-19 04:06:31 --> Security Class Initialized
DEBUG - 2023-06-19 04:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-19 04:06:31 --> Input Class Initialized
INFO - 2023-06-19 04:06:31 --> Language Class Initialized
INFO - 2023-06-19 04:06:31 --> Loader Class Initialized
INFO - 2023-06-19 04:06:31 --> Helper loaded: url_helper
INFO - 2023-06-19 04:06:31 --> Helper loaded: file_helper
INFO - 2023-06-19 04:06:31 --> Helper loaded: html_helper
INFO - 2023-06-19 04:06:31 --> Helper loaded: text_helper
INFO - 2023-06-19 04:06:31 --> Helper loaded: form_helper
INFO - 2023-06-19 04:06:31 --> Helper loaded: lang_helper
INFO - 2023-06-19 04:06:31 --> Helper loaded: security_helper
INFO - 2023-06-19 04:06:31 --> Helper loaded: cookie_helper
INFO - 2023-06-19 04:06:31 --> Database Driver Class Initialized
INFO - 2023-06-19 04:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-19 04:06:31 --> Parser Class Initialized
INFO - 2023-06-19 04:06:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-19 04:06:31 --> Pagination Class Initialized
INFO - 2023-06-19 04:06:31 --> Form Validation Class Initialized
INFO - 2023-06-19 04:06:31 --> Controller Class Initialized
INFO - 2023-06-19 04:06:31 --> Model Class Initialized
DEBUG - 2023-06-19 04:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-19 04:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-19 04:06:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-19 04:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-19 04:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-19 04:06:31 --> Model Class Initialized
INFO - 2023-06-19 04:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-19 04:06:31 --> Final output sent to browser
DEBUG - 2023-06-19 04:06:31 --> Total execution time: 0.0302
ERROR - 2023-06-19 11:50:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-19 11:50:35 --> Config Class Initialized
INFO - 2023-06-19 11:50:35 --> Hooks Class Initialized
DEBUG - 2023-06-19 11:50:35 --> UTF-8 Support Enabled
INFO - 2023-06-19 11:50:35 --> Utf8 Class Initialized
INFO - 2023-06-19 11:50:35 --> URI Class Initialized
DEBUG - 2023-06-19 11:50:35 --> No URI present. Default controller set.
INFO - 2023-06-19 11:50:35 --> Router Class Initialized
INFO - 2023-06-19 11:50:35 --> Output Class Initialized
INFO - 2023-06-19 11:50:35 --> Security Class Initialized
DEBUG - 2023-06-19 11:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-19 11:50:35 --> Input Class Initialized
INFO - 2023-06-19 11:50:35 --> Language Class Initialized
INFO - 2023-06-19 11:50:35 --> Loader Class Initialized
INFO - 2023-06-19 11:50:35 --> Helper loaded: url_helper
INFO - 2023-06-19 11:50:35 --> Helper loaded: file_helper
INFO - 2023-06-19 11:50:35 --> Helper loaded: html_helper
INFO - 2023-06-19 11:50:35 --> Helper loaded: text_helper
INFO - 2023-06-19 11:50:35 --> Helper loaded: form_helper
INFO - 2023-06-19 11:50:35 --> Helper loaded: lang_helper
INFO - 2023-06-19 11:50:35 --> Helper loaded: security_helper
INFO - 2023-06-19 11:50:35 --> Helper loaded: cookie_helper
INFO - 2023-06-19 11:50:35 --> Database Driver Class Initialized
INFO - 2023-06-19 11:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-19 11:50:35 --> Parser Class Initialized
INFO - 2023-06-19 11:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-19 11:50:35 --> Pagination Class Initialized
INFO - 2023-06-19 11:50:35 --> Form Validation Class Initialized
INFO - 2023-06-19 11:50:35 --> Controller Class Initialized
INFO - 2023-06-19 11:50:35 --> Model Class Initialized
DEBUG - 2023-06-19 11:50:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-19 11:50:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-19 11:50:36 --> Config Class Initialized
INFO - 2023-06-19 11:50:36 --> Hooks Class Initialized
DEBUG - 2023-06-19 11:50:36 --> UTF-8 Support Enabled
INFO - 2023-06-19 11:50:36 --> Utf8 Class Initialized
INFO - 2023-06-19 11:50:36 --> URI Class Initialized
INFO - 2023-06-19 11:50:36 --> Router Class Initialized
INFO - 2023-06-19 11:50:36 --> Output Class Initialized
INFO - 2023-06-19 11:50:36 --> Security Class Initialized
DEBUG - 2023-06-19 11:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-19 11:50:36 --> Input Class Initialized
INFO - 2023-06-19 11:50:36 --> Language Class Initialized
INFO - 2023-06-19 11:50:36 --> Loader Class Initialized
INFO - 2023-06-19 11:50:36 --> Helper loaded: url_helper
INFO - 2023-06-19 11:50:36 --> Helper loaded: file_helper
INFO - 2023-06-19 11:50:36 --> Helper loaded: html_helper
INFO - 2023-06-19 11:50:36 --> Helper loaded: text_helper
INFO - 2023-06-19 11:50:36 --> Helper loaded: form_helper
INFO - 2023-06-19 11:50:36 --> Helper loaded: lang_helper
INFO - 2023-06-19 11:50:36 --> Helper loaded: security_helper
INFO - 2023-06-19 11:50:36 --> Helper loaded: cookie_helper
INFO - 2023-06-19 11:50:36 --> Database Driver Class Initialized
INFO - 2023-06-19 11:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-19 11:50:36 --> Parser Class Initialized
INFO - 2023-06-19 11:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-19 11:50:36 --> Pagination Class Initialized
INFO - 2023-06-19 11:50:36 --> Form Validation Class Initialized
INFO - 2023-06-19 11:50:36 --> Controller Class Initialized
INFO - 2023-06-19 11:50:36 --> Model Class Initialized
DEBUG - 2023-06-19 11:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-19 11:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-19 11:50:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-19 11:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-19 11:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-19 11:50:36 --> Model Class Initialized
INFO - 2023-06-19 11:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-19 11:50:36 --> Final output sent to browser
DEBUG - 2023-06-19 11:50:36 --> Total execution time: 0.0335
ERROR - 2023-06-19 11:50:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-19 11:50:41 --> Config Class Initialized
INFO - 2023-06-19 11:50:41 --> Hooks Class Initialized
DEBUG - 2023-06-19 11:50:41 --> UTF-8 Support Enabled
INFO - 2023-06-19 11:50:41 --> Utf8 Class Initialized
INFO - 2023-06-19 11:50:41 --> URI Class Initialized
INFO - 2023-06-19 11:50:41 --> Router Class Initialized
INFO - 2023-06-19 11:50:41 --> Output Class Initialized
INFO - 2023-06-19 11:50:41 --> Security Class Initialized
DEBUG - 2023-06-19 11:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-19 11:50:41 --> Input Class Initialized
INFO - 2023-06-19 11:50:41 --> Language Class Initialized
INFO - 2023-06-19 11:50:41 --> Loader Class Initialized
INFO - 2023-06-19 11:50:41 --> Helper loaded: url_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: file_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: html_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: text_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: form_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: lang_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: security_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: cookie_helper
INFO - 2023-06-19 11:50:41 --> Database Driver Class Initialized
INFO - 2023-06-19 11:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-19 11:50:41 --> Parser Class Initialized
INFO - 2023-06-19 11:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-19 11:50:41 --> Pagination Class Initialized
INFO - 2023-06-19 11:50:41 --> Form Validation Class Initialized
INFO - 2023-06-19 11:50:41 --> Controller Class Initialized
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
DEBUG - 2023-06-19 11:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
INFO - 2023-06-19 11:50:41 --> Final output sent to browser
DEBUG - 2023-06-19 11:50:41 --> Total execution time: 0.0175
ERROR - 2023-06-19 11:50:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-19 11:50:41 --> Config Class Initialized
INFO - 2023-06-19 11:50:41 --> Hooks Class Initialized
DEBUG - 2023-06-19 11:50:41 --> UTF-8 Support Enabled
INFO - 2023-06-19 11:50:41 --> Utf8 Class Initialized
INFO - 2023-06-19 11:50:41 --> URI Class Initialized
DEBUG - 2023-06-19 11:50:41 --> No URI present. Default controller set.
INFO - 2023-06-19 11:50:41 --> Router Class Initialized
INFO - 2023-06-19 11:50:41 --> Output Class Initialized
INFO - 2023-06-19 11:50:41 --> Security Class Initialized
DEBUG - 2023-06-19 11:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-19 11:50:41 --> Input Class Initialized
INFO - 2023-06-19 11:50:41 --> Language Class Initialized
INFO - 2023-06-19 11:50:41 --> Loader Class Initialized
INFO - 2023-06-19 11:50:41 --> Helper loaded: url_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: file_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: html_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: text_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: form_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: lang_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: security_helper
INFO - 2023-06-19 11:50:41 --> Helper loaded: cookie_helper
INFO - 2023-06-19 11:50:41 --> Database Driver Class Initialized
INFO - 2023-06-19 11:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-19 11:50:41 --> Parser Class Initialized
INFO - 2023-06-19 11:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-19 11:50:41 --> Pagination Class Initialized
INFO - 2023-06-19 11:50:41 --> Form Validation Class Initialized
INFO - 2023-06-19 11:50:41 --> Controller Class Initialized
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
DEBUG - 2023-06-19 11:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
DEBUG - 2023-06-19 11:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
DEBUG - 2023-06-19 11:50:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-19 11:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
INFO - 2023-06-19 11:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-19 11:50:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-19 11:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-19 11:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-19 11:50:41 --> Model Class Initialized
INFO - 2023-06-19 11:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-19 11:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-19 11:50:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-19 11:50:41 --> Final output sent to browser
DEBUG - 2023-06-19 11:50:41 --> Total execution time: 0.1874
ERROR - 2023-06-19 11:50:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-19 11:50:43 --> Config Class Initialized
INFO - 2023-06-19 11:50:43 --> Hooks Class Initialized
DEBUG - 2023-06-19 11:50:43 --> UTF-8 Support Enabled
INFO - 2023-06-19 11:50:43 --> Utf8 Class Initialized
INFO - 2023-06-19 11:50:43 --> URI Class Initialized
INFO - 2023-06-19 11:50:43 --> Router Class Initialized
INFO - 2023-06-19 11:50:43 --> Output Class Initialized
INFO - 2023-06-19 11:50:43 --> Security Class Initialized
DEBUG - 2023-06-19 11:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-19 11:50:43 --> Input Class Initialized
INFO - 2023-06-19 11:50:43 --> Language Class Initialized
INFO - 2023-06-19 11:50:43 --> Loader Class Initialized
INFO - 2023-06-19 11:50:43 --> Helper loaded: url_helper
INFO - 2023-06-19 11:50:43 --> Helper loaded: file_helper
INFO - 2023-06-19 11:50:43 --> Helper loaded: html_helper
INFO - 2023-06-19 11:50:43 --> Helper loaded: text_helper
INFO - 2023-06-19 11:50:43 --> Helper loaded: form_helper
INFO - 2023-06-19 11:50:43 --> Helper loaded: lang_helper
INFO - 2023-06-19 11:50:43 --> Helper loaded: security_helper
INFO - 2023-06-19 11:50:43 --> Helper loaded: cookie_helper
INFO - 2023-06-19 11:50:43 --> Database Driver Class Initialized
INFO - 2023-06-19 11:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-19 11:50:43 --> Parser Class Initialized
INFO - 2023-06-19 11:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-19 11:50:43 --> Pagination Class Initialized
INFO - 2023-06-19 11:50:43 --> Form Validation Class Initialized
INFO - 2023-06-19 11:50:43 --> Controller Class Initialized
DEBUG - 2023-06-19 11:50:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-19 11:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-19 11:50:43 --> Model Class Initialized
INFO - 2023-06-19 11:50:43 --> Final output sent to browser
DEBUG - 2023-06-19 11:50:43 --> Total execution time: 0.0135
ERROR - 2023-06-19 15:55:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-19 15:55:48 --> Config Class Initialized
INFO - 2023-06-19 15:55:48 --> Hooks Class Initialized
DEBUG - 2023-06-19 15:55:48 --> UTF-8 Support Enabled
INFO - 2023-06-19 15:55:48 --> Utf8 Class Initialized
INFO - 2023-06-19 15:55:48 --> URI Class Initialized
DEBUG - 2023-06-19 15:55:48 --> No URI present. Default controller set.
INFO - 2023-06-19 15:55:48 --> Router Class Initialized
INFO - 2023-06-19 15:55:48 --> Output Class Initialized
INFO - 2023-06-19 15:55:48 --> Security Class Initialized
DEBUG - 2023-06-19 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-19 15:55:48 --> Input Class Initialized
INFO - 2023-06-19 15:55:48 --> Language Class Initialized
INFO - 2023-06-19 15:55:48 --> Loader Class Initialized
INFO - 2023-06-19 15:55:48 --> Helper loaded: url_helper
INFO - 2023-06-19 15:55:48 --> Helper loaded: file_helper
INFO - 2023-06-19 15:55:48 --> Helper loaded: html_helper
INFO - 2023-06-19 15:55:48 --> Helper loaded: text_helper
INFO - 2023-06-19 15:55:48 --> Helper loaded: form_helper
INFO - 2023-06-19 15:55:48 --> Helper loaded: lang_helper
INFO - 2023-06-19 15:55:48 --> Helper loaded: security_helper
INFO - 2023-06-19 15:55:48 --> Helper loaded: cookie_helper
INFO - 2023-06-19 15:55:48 --> Database Driver Class Initialized
INFO - 2023-06-19 15:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-19 15:55:48 --> Parser Class Initialized
INFO - 2023-06-19 15:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-19 15:55:48 --> Pagination Class Initialized
INFO - 2023-06-19 15:55:48 --> Form Validation Class Initialized
INFO - 2023-06-19 15:55:48 --> Controller Class Initialized
INFO - 2023-06-19 15:55:48 --> Model Class Initialized
DEBUG - 2023-06-19 15:55:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-19 15:55:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-19 15:55:49 --> Config Class Initialized
INFO - 2023-06-19 15:55:49 --> Hooks Class Initialized
DEBUG - 2023-06-19 15:55:49 --> UTF-8 Support Enabled
INFO - 2023-06-19 15:55:49 --> Utf8 Class Initialized
INFO - 2023-06-19 15:55:49 --> URI Class Initialized
INFO - 2023-06-19 15:55:49 --> Router Class Initialized
INFO - 2023-06-19 15:55:49 --> Output Class Initialized
INFO - 2023-06-19 15:55:49 --> Security Class Initialized
DEBUG - 2023-06-19 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-19 15:55:49 --> Input Class Initialized
INFO - 2023-06-19 15:55:49 --> Language Class Initialized
INFO - 2023-06-19 15:55:49 --> Loader Class Initialized
INFO - 2023-06-19 15:55:49 --> Helper loaded: url_helper
INFO - 2023-06-19 15:55:49 --> Helper loaded: file_helper
INFO - 2023-06-19 15:55:49 --> Helper loaded: html_helper
INFO - 2023-06-19 15:55:49 --> Helper loaded: text_helper
INFO - 2023-06-19 15:55:49 --> Helper loaded: form_helper
INFO - 2023-06-19 15:55:49 --> Helper loaded: lang_helper
INFO - 2023-06-19 15:55:49 --> Helper loaded: security_helper
INFO - 2023-06-19 15:55:49 --> Helper loaded: cookie_helper
INFO - 2023-06-19 15:55:49 --> Database Driver Class Initialized
INFO - 2023-06-19 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-19 15:55:49 --> Parser Class Initialized
INFO - 2023-06-19 15:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-19 15:55:49 --> Pagination Class Initialized
INFO - 2023-06-19 15:55:49 --> Form Validation Class Initialized
INFO - 2023-06-19 15:55:49 --> Controller Class Initialized
INFO - 2023-06-19 15:55:49 --> Model Class Initialized
DEBUG - 2023-06-19 15:55:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-19 15:55:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-19 15:55:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-19 15:55:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-19 15:55:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-19 15:55:49 --> Model Class Initialized
INFO - 2023-06-19 15:55:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-19 15:55:49 --> Final output sent to browser
DEBUG - 2023-06-19 15:55:49 --> Total execution time: 0.0316
