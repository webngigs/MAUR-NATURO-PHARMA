<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-30 01:52:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 01:52:15 --> Config Class Initialized
INFO - 2023-12-30 01:52:15 --> Hooks Class Initialized
DEBUG - 2023-12-30 01:52:15 --> UTF-8 Support Enabled
INFO - 2023-12-30 01:52:15 --> Utf8 Class Initialized
INFO - 2023-12-30 01:52:15 --> URI Class Initialized
INFO - 2023-12-30 01:52:15 --> Router Class Initialized
INFO - 2023-12-30 01:52:15 --> Output Class Initialized
INFO - 2023-12-30 01:52:15 --> Security Class Initialized
DEBUG - 2023-12-30 01:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 01:52:15 --> Input Class Initialized
INFO - 2023-12-30 01:52:15 --> Language Class Initialized
ERROR - 2023-12-30 01:52:15 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-30 04:48:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 04:48:09 --> Config Class Initialized
INFO - 2023-12-30 04:48:09 --> Hooks Class Initialized
DEBUG - 2023-12-30 04:48:09 --> UTF-8 Support Enabled
INFO - 2023-12-30 04:48:09 --> Utf8 Class Initialized
INFO - 2023-12-30 04:48:09 --> URI Class Initialized
DEBUG - 2023-12-30 04:48:09 --> No URI present. Default controller set.
INFO - 2023-12-30 04:48:09 --> Router Class Initialized
INFO - 2023-12-30 04:48:09 --> Output Class Initialized
INFO - 2023-12-30 04:48:09 --> Security Class Initialized
DEBUG - 2023-12-30 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 04:48:09 --> Input Class Initialized
INFO - 2023-12-30 04:48:09 --> Language Class Initialized
INFO - 2023-12-30 04:48:09 --> Loader Class Initialized
INFO - 2023-12-30 04:48:09 --> Helper loaded: url_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: file_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: html_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: text_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: form_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: lang_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: security_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: cookie_helper
INFO - 2023-12-30 04:48:09 --> Database Driver Class Initialized
INFO - 2023-12-30 04:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 04:48:09 --> Parser Class Initialized
INFO - 2023-12-30 04:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 04:48:09 --> Pagination Class Initialized
INFO - 2023-12-30 04:48:09 --> Form Validation Class Initialized
INFO - 2023-12-30 04:48:09 --> Controller Class Initialized
INFO - 2023-12-30 04:48:09 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-30 04:48:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 04:48:09 --> Config Class Initialized
INFO - 2023-12-30 04:48:09 --> Hooks Class Initialized
DEBUG - 2023-12-30 04:48:09 --> UTF-8 Support Enabled
INFO - 2023-12-30 04:48:09 --> Utf8 Class Initialized
INFO - 2023-12-30 04:48:09 --> URI Class Initialized
INFO - 2023-12-30 04:48:09 --> Router Class Initialized
INFO - 2023-12-30 04:48:09 --> Output Class Initialized
INFO - 2023-12-30 04:48:09 --> Security Class Initialized
DEBUG - 2023-12-30 04:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 04:48:09 --> Input Class Initialized
INFO - 2023-12-30 04:48:09 --> Language Class Initialized
INFO - 2023-12-30 04:48:09 --> Loader Class Initialized
INFO - 2023-12-30 04:48:09 --> Helper loaded: url_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: file_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: html_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: text_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: form_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: lang_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: security_helper
INFO - 2023-12-30 04:48:09 --> Helper loaded: cookie_helper
INFO - 2023-12-30 04:48:09 --> Database Driver Class Initialized
INFO - 2023-12-30 04:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 04:48:09 --> Parser Class Initialized
INFO - 2023-12-30 04:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 04:48:09 --> Pagination Class Initialized
INFO - 2023-12-30 04:48:09 --> Form Validation Class Initialized
INFO - 2023-12-30 04:48:09 --> Controller Class Initialized
INFO - 2023-12-30 04:48:09 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-30 04:48:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 04:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 04:48:09 --> Model Class Initialized
INFO - 2023-12-30 04:48:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 04:48:09 --> Final output sent to browser
DEBUG - 2023-12-30 04:48:09 --> Total execution time: 0.0416
ERROR - 2023-12-30 04:48:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 04:48:15 --> Config Class Initialized
INFO - 2023-12-30 04:48:15 --> Hooks Class Initialized
DEBUG - 2023-12-30 04:48:15 --> UTF-8 Support Enabled
INFO - 2023-12-30 04:48:15 --> Utf8 Class Initialized
INFO - 2023-12-30 04:48:15 --> URI Class Initialized
INFO - 2023-12-30 04:48:15 --> Router Class Initialized
INFO - 2023-12-30 04:48:15 --> Output Class Initialized
INFO - 2023-12-30 04:48:15 --> Security Class Initialized
DEBUG - 2023-12-30 04:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 04:48:15 --> Input Class Initialized
INFO - 2023-12-30 04:48:15 --> Language Class Initialized
INFO - 2023-12-30 04:48:15 --> Loader Class Initialized
INFO - 2023-12-30 04:48:15 --> Helper loaded: url_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: file_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: html_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: text_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: form_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: lang_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: security_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: cookie_helper
INFO - 2023-12-30 04:48:15 --> Database Driver Class Initialized
INFO - 2023-12-30 04:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 04:48:15 --> Parser Class Initialized
INFO - 2023-12-30 04:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 04:48:15 --> Pagination Class Initialized
INFO - 2023-12-30 04:48:15 --> Form Validation Class Initialized
INFO - 2023-12-30 04:48:15 --> Controller Class Initialized
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
INFO - 2023-12-30 04:48:15 --> Final output sent to browser
DEBUG - 2023-12-30 04:48:15 --> Total execution time: 0.0197
ERROR - 2023-12-30 04:48:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 04:48:15 --> Config Class Initialized
INFO - 2023-12-30 04:48:15 --> Hooks Class Initialized
DEBUG - 2023-12-30 04:48:15 --> UTF-8 Support Enabled
INFO - 2023-12-30 04:48:15 --> Utf8 Class Initialized
INFO - 2023-12-30 04:48:15 --> URI Class Initialized
DEBUG - 2023-12-30 04:48:15 --> No URI present. Default controller set.
INFO - 2023-12-30 04:48:15 --> Router Class Initialized
INFO - 2023-12-30 04:48:15 --> Output Class Initialized
INFO - 2023-12-30 04:48:15 --> Security Class Initialized
DEBUG - 2023-12-30 04:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 04:48:15 --> Input Class Initialized
INFO - 2023-12-30 04:48:15 --> Language Class Initialized
INFO - 2023-12-30 04:48:15 --> Loader Class Initialized
INFO - 2023-12-30 04:48:15 --> Helper loaded: url_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: file_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: html_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: text_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: form_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: lang_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: security_helper
INFO - 2023-12-30 04:48:15 --> Helper loaded: cookie_helper
INFO - 2023-12-30 04:48:15 --> Database Driver Class Initialized
INFO - 2023-12-30 04:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 04:48:15 --> Parser Class Initialized
INFO - 2023-12-30 04:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 04:48:15 --> Pagination Class Initialized
INFO - 2023-12-30 04:48:15 --> Form Validation Class Initialized
INFO - 2023-12-30 04:48:15 --> Controller Class Initialized
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 04:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
INFO - 2023-12-30 04:48:15 --> Model Class Initialized
INFO - 2023-12-30 04:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 04:48:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 04:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 04:48:16 --> Model Class Initialized
INFO - 2023-12-30 04:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 04:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 04:48:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 04:48:16 --> Final output sent to browser
DEBUG - 2023-12-30 04:48:16 --> Total execution time: 0.2452
ERROR - 2023-12-30 04:48:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 04:48:48 --> Config Class Initialized
INFO - 2023-12-30 04:48:48 --> Hooks Class Initialized
DEBUG - 2023-12-30 04:48:48 --> UTF-8 Support Enabled
INFO - 2023-12-30 04:48:48 --> Utf8 Class Initialized
INFO - 2023-12-30 04:48:48 --> URI Class Initialized
INFO - 2023-12-30 04:48:48 --> Router Class Initialized
INFO - 2023-12-30 04:48:48 --> Output Class Initialized
INFO - 2023-12-30 04:48:48 --> Security Class Initialized
DEBUG - 2023-12-30 04:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 04:48:48 --> Input Class Initialized
INFO - 2023-12-30 04:48:48 --> Language Class Initialized
INFO - 2023-12-30 04:48:48 --> Loader Class Initialized
INFO - 2023-12-30 04:48:48 --> Helper loaded: url_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: file_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: html_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: text_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: form_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: lang_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: security_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: cookie_helper
INFO - 2023-12-30 04:48:48 --> Database Driver Class Initialized
INFO - 2023-12-30 04:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 04:48:48 --> Parser Class Initialized
INFO - 2023-12-30 04:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 04:48:48 --> Pagination Class Initialized
INFO - 2023-12-30 04:48:48 --> Form Validation Class Initialized
INFO - 2023-12-30 04:48:48 --> Controller Class Initialized
INFO - 2023-12-30 04:48:48 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 04:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:48 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:48 --> Model Class Initialized
INFO - 2023-12-30 04:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-30 04:48:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 04:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 04:48:48 --> Model Class Initialized
INFO - 2023-12-30 04:48:48 --> Model Class Initialized
INFO - 2023-12-30 04:48:48 --> Model Class Initialized
INFO - 2023-12-30 04:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 04:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 04:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 04:48:48 --> Final output sent to browser
DEBUG - 2023-12-30 04:48:48 --> Total execution time: 0.1430
ERROR - 2023-12-30 04:48:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 04:48:48 --> Config Class Initialized
INFO - 2023-12-30 04:48:48 --> Hooks Class Initialized
DEBUG - 2023-12-30 04:48:48 --> UTF-8 Support Enabled
INFO - 2023-12-30 04:48:48 --> Utf8 Class Initialized
INFO - 2023-12-30 04:48:48 --> URI Class Initialized
INFO - 2023-12-30 04:48:48 --> Router Class Initialized
INFO - 2023-12-30 04:48:48 --> Output Class Initialized
INFO - 2023-12-30 04:48:48 --> Security Class Initialized
DEBUG - 2023-12-30 04:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 04:48:48 --> Input Class Initialized
INFO - 2023-12-30 04:48:48 --> Language Class Initialized
INFO - 2023-12-30 04:48:48 --> Loader Class Initialized
INFO - 2023-12-30 04:48:48 --> Helper loaded: url_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: file_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: html_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: text_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: form_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: lang_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: security_helper
INFO - 2023-12-30 04:48:48 --> Helper loaded: cookie_helper
INFO - 2023-12-30 04:48:48 --> Database Driver Class Initialized
INFO - 2023-12-30 04:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 04:48:48 --> Parser Class Initialized
INFO - 2023-12-30 04:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 04:48:48 --> Pagination Class Initialized
INFO - 2023-12-30 04:48:48 --> Form Validation Class Initialized
INFO - 2023-12-30 04:48:48 --> Controller Class Initialized
INFO - 2023-12-30 04:48:48 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 04:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:48 --> Model Class Initialized
DEBUG - 2023-12-30 04:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:48:48 --> Model Class Initialized
INFO - 2023-12-30 04:48:49 --> Final output sent to browser
DEBUG - 2023-12-30 04:48:49 --> Total execution time: 0.0478
ERROR - 2023-12-30 04:49:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 04:49:07 --> Config Class Initialized
INFO - 2023-12-30 04:49:07 --> Hooks Class Initialized
DEBUG - 2023-12-30 04:49:07 --> UTF-8 Support Enabled
INFO - 2023-12-30 04:49:07 --> Utf8 Class Initialized
INFO - 2023-12-30 04:49:07 --> URI Class Initialized
INFO - 2023-12-30 04:49:07 --> Router Class Initialized
INFO - 2023-12-30 04:49:07 --> Output Class Initialized
INFO - 2023-12-30 04:49:07 --> Security Class Initialized
DEBUG - 2023-12-30 04:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 04:49:07 --> Input Class Initialized
INFO - 2023-12-30 04:49:07 --> Language Class Initialized
INFO - 2023-12-30 04:49:07 --> Loader Class Initialized
INFO - 2023-12-30 04:49:07 --> Helper loaded: url_helper
INFO - 2023-12-30 04:49:07 --> Helper loaded: file_helper
INFO - 2023-12-30 04:49:07 --> Helper loaded: html_helper
INFO - 2023-12-30 04:49:07 --> Helper loaded: text_helper
INFO - 2023-12-30 04:49:07 --> Helper loaded: form_helper
INFO - 2023-12-30 04:49:07 --> Helper loaded: lang_helper
INFO - 2023-12-30 04:49:07 --> Helper loaded: security_helper
INFO - 2023-12-30 04:49:07 --> Helper loaded: cookie_helper
INFO - 2023-12-30 04:49:07 --> Database Driver Class Initialized
INFO - 2023-12-30 04:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 04:49:07 --> Parser Class Initialized
INFO - 2023-12-30 04:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 04:49:07 --> Pagination Class Initialized
INFO - 2023-12-30 04:49:07 --> Form Validation Class Initialized
INFO - 2023-12-30 04:49:07 --> Controller Class Initialized
INFO - 2023-12-30 04:49:07 --> Model Class Initialized
DEBUG - 2023-12-30 04:49:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 04:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:49:07 --> Model Class Initialized
DEBUG - 2023-12-30 04:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:49:07 --> Model Class Initialized
DEBUG - 2023-12-30 04:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-30 04:49:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 04:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 04:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 04:49:07 --> Model Class Initialized
INFO - 2023-12-30 04:49:07 --> Model Class Initialized
INFO - 2023-12-30 04:49:07 --> Model Class Initialized
INFO - 2023-12-30 04:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 04:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 04:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 04:49:07 --> Final output sent to browser
DEBUG - 2023-12-30 04:49:07 --> Total execution time: 0.1591
ERROR - 2023-12-30 05:42:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:42:00 --> Config Class Initialized
INFO - 2023-12-30 05:42:00 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:42:00 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:42:00 --> Utf8 Class Initialized
INFO - 2023-12-30 05:42:00 --> URI Class Initialized
DEBUG - 2023-12-30 05:42:00 --> No URI present. Default controller set.
INFO - 2023-12-30 05:42:00 --> Router Class Initialized
INFO - 2023-12-30 05:42:00 --> Output Class Initialized
INFO - 2023-12-30 05:42:00 --> Security Class Initialized
DEBUG - 2023-12-30 05:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:42:00 --> Input Class Initialized
INFO - 2023-12-30 05:42:00 --> Language Class Initialized
INFO - 2023-12-30 05:42:00 --> Loader Class Initialized
INFO - 2023-12-30 05:42:00 --> Helper loaded: url_helper
INFO - 2023-12-30 05:42:00 --> Helper loaded: file_helper
INFO - 2023-12-30 05:42:00 --> Helper loaded: html_helper
INFO - 2023-12-30 05:42:00 --> Helper loaded: text_helper
INFO - 2023-12-30 05:42:00 --> Helper loaded: form_helper
INFO - 2023-12-30 05:42:00 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:42:00 --> Helper loaded: security_helper
INFO - 2023-12-30 05:42:00 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:42:00 --> Database Driver Class Initialized
INFO - 2023-12-30 05:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:42:00 --> Parser Class Initialized
INFO - 2023-12-30 05:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:42:00 --> Pagination Class Initialized
INFO - 2023-12-30 05:42:00 --> Form Validation Class Initialized
INFO - 2023-12-30 05:42:00 --> Controller Class Initialized
INFO - 2023-12-30 05:42:00 --> Model Class Initialized
DEBUG - 2023-12-30 05:42:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-30 05:42:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:42:05 --> Config Class Initialized
INFO - 2023-12-30 05:42:05 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:42:05 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:42:05 --> Utf8 Class Initialized
INFO - 2023-12-30 05:42:05 --> URI Class Initialized
INFO - 2023-12-30 05:42:05 --> Router Class Initialized
INFO - 2023-12-30 05:42:05 --> Output Class Initialized
INFO - 2023-12-30 05:42:05 --> Security Class Initialized
DEBUG - 2023-12-30 05:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:42:05 --> Input Class Initialized
INFO - 2023-12-30 05:42:05 --> Language Class Initialized
INFO - 2023-12-30 05:42:05 --> Loader Class Initialized
INFO - 2023-12-30 05:42:05 --> Helper loaded: url_helper
INFO - 2023-12-30 05:42:05 --> Helper loaded: file_helper
INFO - 2023-12-30 05:42:05 --> Helper loaded: html_helper
INFO - 2023-12-30 05:42:05 --> Helper loaded: text_helper
INFO - 2023-12-30 05:42:05 --> Helper loaded: form_helper
INFO - 2023-12-30 05:42:05 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:42:05 --> Helper loaded: security_helper
INFO - 2023-12-30 05:42:05 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:42:05 --> Database Driver Class Initialized
INFO - 2023-12-30 05:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:42:05 --> Parser Class Initialized
INFO - 2023-12-30 05:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:42:05 --> Pagination Class Initialized
INFO - 2023-12-30 05:42:05 --> Form Validation Class Initialized
INFO - 2023-12-30 05:42:05 --> Controller Class Initialized
INFO - 2023-12-30 05:42:05 --> Model Class Initialized
DEBUG - 2023-12-30 05:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-30 05:42:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 05:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 05:42:05 --> Model Class Initialized
INFO - 2023-12-30 05:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 05:42:05 --> Final output sent to browser
DEBUG - 2023-12-30 05:42:05 --> Total execution time: 0.0358
ERROR - 2023-12-30 05:42:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:42:23 --> Config Class Initialized
INFO - 2023-12-30 05:42:23 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:42:23 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:42:23 --> Utf8 Class Initialized
INFO - 2023-12-30 05:42:23 --> URI Class Initialized
INFO - 2023-12-30 05:42:23 --> Router Class Initialized
INFO - 2023-12-30 05:42:23 --> Output Class Initialized
INFO - 2023-12-30 05:42:23 --> Security Class Initialized
DEBUG - 2023-12-30 05:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:42:23 --> Input Class Initialized
INFO - 2023-12-30 05:42:23 --> Language Class Initialized
INFO - 2023-12-30 05:42:23 --> Loader Class Initialized
INFO - 2023-12-30 05:42:23 --> Helper loaded: url_helper
INFO - 2023-12-30 05:42:23 --> Helper loaded: file_helper
INFO - 2023-12-30 05:42:23 --> Helper loaded: html_helper
INFO - 2023-12-30 05:42:23 --> Helper loaded: text_helper
INFO - 2023-12-30 05:42:23 --> Helper loaded: form_helper
INFO - 2023-12-30 05:42:23 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:42:23 --> Helper loaded: security_helper
INFO - 2023-12-30 05:42:23 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:42:23 --> Database Driver Class Initialized
INFO - 2023-12-30 05:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:42:23 --> Parser Class Initialized
INFO - 2023-12-30 05:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:42:23 --> Pagination Class Initialized
INFO - 2023-12-30 05:42:23 --> Form Validation Class Initialized
INFO - 2023-12-30 05:42:23 --> Controller Class Initialized
INFO - 2023-12-30 05:42:23 --> Model Class Initialized
DEBUG - 2023-12-30 05:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:23 --> Model Class Initialized
INFO - 2023-12-30 05:42:23 --> Final output sent to browser
DEBUG - 2023-12-30 05:42:23 --> Total execution time: 0.0220
ERROR - 2023-12-30 05:42:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:42:25 --> Config Class Initialized
INFO - 2023-12-30 05:42:25 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:42:25 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:42:25 --> Utf8 Class Initialized
INFO - 2023-12-30 05:42:25 --> URI Class Initialized
DEBUG - 2023-12-30 05:42:25 --> No URI present. Default controller set.
INFO - 2023-12-30 05:42:25 --> Router Class Initialized
INFO - 2023-12-30 05:42:25 --> Output Class Initialized
INFO - 2023-12-30 05:42:25 --> Security Class Initialized
DEBUG - 2023-12-30 05:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:42:25 --> Input Class Initialized
INFO - 2023-12-30 05:42:25 --> Language Class Initialized
INFO - 2023-12-30 05:42:25 --> Loader Class Initialized
INFO - 2023-12-30 05:42:25 --> Helper loaded: url_helper
INFO - 2023-12-30 05:42:25 --> Helper loaded: file_helper
INFO - 2023-12-30 05:42:25 --> Helper loaded: html_helper
INFO - 2023-12-30 05:42:25 --> Helper loaded: text_helper
INFO - 2023-12-30 05:42:25 --> Helper loaded: form_helper
INFO - 2023-12-30 05:42:25 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:42:25 --> Helper loaded: security_helper
INFO - 2023-12-30 05:42:25 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:42:25 --> Database Driver Class Initialized
INFO - 2023-12-30 05:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:42:25 --> Parser Class Initialized
INFO - 2023-12-30 05:42:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:42:25 --> Pagination Class Initialized
INFO - 2023-12-30 05:42:25 --> Form Validation Class Initialized
INFO - 2023-12-30 05:42:25 --> Controller Class Initialized
INFO - 2023-12-30 05:42:25 --> Model Class Initialized
DEBUG - 2023-12-30 05:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:25 --> Model Class Initialized
DEBUG - 2023-12-30 05:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:25 --> Model Class Initialized
INFO - 2023-12-30 05:42:25 --> Model Class Initialized
INFO - 2023-12-30 05:42:25 --> Model Class Initialized
INFO - 2023-12-30 05:42:25 --> Model Class Initialized
DEBUG - 2023-12-30 05:42:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:25 --> Model Class Initialized
INFO - 2023-12-30 05:42:25 --> Model Class Initialized
INFO - 2023-12-30 05:42:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 05:42:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 05:42:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 05:42:25 --> Model Class Initialized
INFO - 2023-12-30 05:42:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 05:42:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 05:42:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 05:42:25 --> Final output sent to browser
DEBUG - 2023-12-30 05:42:25 --> Total execution time: 0.4008
ERROR - 2023-12-30 05:42:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:42:32 --> Config Class Initialized
INFO - 2023-12-30 05:42:32 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:42:32 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:42:32 --> Utf8 Class Initialized
INFO - 2023-12-30 05:42:32 --> URI Class Initialized
INFO - 2023-12-30 05:42:32 --> Router Class Initialized
INFO - 2023-12-30 05:42:32 --> Output Class Initialized
INFO - 2023-12-30 05:42:32 --> Security Class Initialized
DEBUG - 2023-12-30 05:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:42:32 --> Input Class Initialized
INFO - 2023-12-30 05:42:32 --> Language Class Initialized
INFO - 2023-12-30 05:42:32 --> Loader Class Initialized
INFO - 2023-12-30 05:42:32 --> Helper loaded: url_helper
INFO - 2023-12-30 05:42:32 --> Helper loaded: file_helper
INFO - 2023-12-30 05:42:32 --> Helper loaded: html_helper
INFO - 2023-12-30 05:42:32 --> Helper loaded: text_helper
INFO - 2023-12-30 05:42:32 --> Helper loaded: form_helper
INFO - 2023-12-30 05:42:32 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:42:32 --> Helper loaded: security_helper
INFO - 2023-12-30 05:42:32 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:42:32 --> Database Driver Class Initialized
INFO - 2023-12-30 05:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:42:32 --> Parser Class Initialized
INFO - 2023-12-30 05:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:42:32 --> Pagination Class Initialized
INFO - 2023-12-30 05:42:32 --> Form Validation Class Initialized
INFO - 2023-12-30 05:42:32 --> Controller Class Initialized
DEBUG - 2023-12-30 05:42:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:32 --> Model Class Initialized
INFO - 2023-12-30 05:42:32 --> Final output sent to browser
DEBUG - 2023-12-30 05:42:32 --> Total execution time: 0.0132
ERROR - 2023-12-30 05:42:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:42:53 --> Config Class Initialized
INFO - 2023-12-30 05:42:53 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:42:53 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:42:53 --> Utf8 Class Initialized
INFO - 2023-12-30 05:42:53 --> URI Class Initialized
DEBUG - 2023-12-30 05:42:53 --> No URI present. Default controller set.
INFO - 2023-12-30 05:42:53 --> Router Class Initialized
INFO - 2023-12-30 05:42:53 --> Output Class Initialized
INFO - 2023-12-30 05:42:53 --> Security Class Initialized
DEBUG - 2023-12-30 05:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:42:53 --> Input Class Initialized
INFO - 2023-12-30 05:42:53 --> Language Class Initialized
INFO - 2023-12-30 05:42:53 --> Loader Class Initialized
INFO - 2023-12-30 05:42:53 --> Helper loaded: url_helper
INFO - 2023-12-30 05:42:53 --> Helper loaded: file_helper
INFO - 2023-12-30 05:42:53 --> Helper loaded: html_helper
INFO - 2023-12-30 05:42:53 --> Helper loaded: text_helper
INFO - 2023-12-30 05:42:53 --> Helper loaded: form_helper
INFO - 2023-12-30 05:42:53 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:42:53 --> Helper loaded: security_helper
INFO - 2023-12-30 05:42:53 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:42:53 --> Database Driver Class Initialized
INFO - 2023-12-30 05:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:42:53 --> Parser Class Initialized
INFO - 2023-12-30 05:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:42:53 --> Pagination Class Initialized
INFO - 2023-12-30 05:42:53 --> Form Validation Class Initialized
INFO - 2023-12-30 05:42:53 --> Controller Class Initialized
INFO - 2023-12-30 05:42:53 --> Model Class Initialized
DEBUG - 2023-12-30 05:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:53 --> Model Class Initialized
DEBUG - 2023-12-30 05:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:53 --> Model Class Initialized
INFO - 2023-12-30 05:42:53 --> Model Class Initialized
INFO - 2023-12-30 05:42:53 --> Model Class Initialized
INFO - 2023-12-30 05:42:53 --> Model Class Initialized
DEBUG - 2023-12-30 05:42:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:53 --> Model Class Initialized
INFO - 2023-12-30 05:42:53 --> Model Class Initialized
INFO - 2023-12-30 05:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 05:42:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 05:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 05:42:54 --> Model Class Initialized
INFO - 2023-12-30 05:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 05:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 05:42:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 05:42:54 --> Final output sent to browser
DEBUG - 2023-12-30 05:42:54 --> Total execution time: 0.4084
ERROR - 2023-12-30 05:43:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:43:04 --> Config Class Initialized
INFO - 2023-12-30 05:43:04 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:43:04 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:43:04 --> Utf8 Class Initialized
INFO - 2023-12-30 05:43:04 --> URI Class Initialized
INFO - 2023-12-30 05:43:04 --> Router Class Initialized
INFO - 2023-12-30 05:43:04 --> Output Class Initialized
INFO - 2023-12-30 05:43:04 --> Security Class Initialized
DEBUG - 2023-12-30 05:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:43:04 --> Input Class Initialized
INFO - 2023-12-30 05:43:04 --> Language Class Initialized
INFO - 2023-12-30 05:43:04 --> Loader Class Initialized
INFO - 2023-12-30 05:43:04 --> Helper loaded: url_helper
INFO - 2023-12-30 05:43:04 --> Helper loaded: file_helper
INFO - 2023-12-30 05:43:04 --> Helper loaded: html_helper
INFO - 2023-12-30 05:43:04 --> Helper loaded: text_helper
INFO - 2023-12-30 05:43:04 --> Helper loaded: form_helper
INFO - 2023-12-30 05:43:04 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:43:04 --> Helper loaded: security_helper
INFO - 2023-12-30 05:43:04 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:43:04 --> Database Driver Class Initialized
INFO - 2023-12-30 05:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:43:04 --> Parser Class Initialized
INFO - 2023-12-30 05:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:43:04 --> Pagination Class Initialized
INFO - 2023-12-30 05:43:04 --> Form Validation Class Initialized
INFO - 2023-12-30 05:43:04 --> Controller Class Initialized
DEBUG - 2023-12-30 05:43:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:04 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:04 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:04 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:04 --> Model Class Initialized
INFO - 2023-12-30 05:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-12-30 05:43:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 05:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 05:43:04 --> Model Class Initialized
INFO - 2023-12-30 05:43:04 --> Model Class Initialized
INFO - 2023-12-30 05:43:04 --> Model Class Initialized
INFO - 2023-12-30 05:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 05:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 05:43:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 05:43:04 --> Final output sent to browser
DEBUG - 2023-12-30 05:43:04 --> Total execution time: 0.2350
ERROR - 2023-12-30 05:43:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:43:06 --> Config Class Initialized
INFO - 2023-12-30 05:43:06 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:43:06 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:43:06 --> Utf8 Class Initialized
INFO - 2023-12-30 05:43:06 --> URI Class Initialized
INFO - 2023-12-30 05:43:06 --> Router Class Initialized
INFO - 2023-12-30 05:43:06 --> Output Class Initialized
INFO - 2023-12-30 05:43:06 --> Security Class Initialized
DEBUG - 2023-12-30 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:43:06 --> Input Class Initialized
INFO - 2023-12-30 05:43:06 --> Language Class Initialized
INFO - 2023-12-30 05:43:06 --> Loader Class Initialized
INFO - 2023-12-30 05:43:06 --> Helper loaded: url_helper
INFO - 2023-12-30 05:43:06 --> Helper loaded: file_helper
INFO - 2023-12-30 05:43:06 --> Helper loaded: html_helper
INFO - 2023-12-30 05:43:06 --> Helper loaded: text_helper
INFO - 2023-12-30 05:43:06 --> Helper loaded: form_helper
INFO - 2023-12-30 05:43:06 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:43:06 --> Helper loaded: security_helper
INFO - 2023-12-30 05:43:06 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:43:06 --> Database Driver Class Initialized
INFO - 2023-12-30 05:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:43:06 --> Parser Class Initialized
INFO - 2023-12-30 05:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:43:06 --> Pagination Class Initialized
INFO - 2023-12-30 05:43:06 --> Form Validation Class Initialized
INFO - 2023-12-30 05:43:06 --> Controller Class Initialized
DEBUG - 2023-12-30 05:43:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:06 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:06 --> Model Class Initialized
INFO - 2023-12-30 05:43:06 --> Final output sent to browser
DEBUG - 2023-12-30 05:43:06 --> Total execution time: 0.0346
ERROR - 2023-12-30 05:43:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:43:09 --> Config Class Initialized
INFO - 2023-12-30 05:43:09 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:43:09 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:43:09 --> Utf8 Class Initialized
INFO - 2023-12-30 05:43:09 --> URI Class Initialized
INFO - 2023-12-30 05:43:09 --> Router Class Initialized
INFO - 2023-12-30 05:43:09 --> Output Class Initialized
INFO - 2023-12-30 05:43:09 --> Security Class Initialized
DEBUG - 2023-12-30 05:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:43:09 --> Input Class Initialized
INFO - 2023-12-30 05:43:09 --> Language Class Initialized
INFO - 2023-12-30 05:43:09 --> Loader Class Initialized
INFO - 2023-12-30 05:43:09 --> Helper loaded: url_helper
INFO - 2023-12-30 05:43:09 --> Helper loaded: file_helper
INFO - 2023-12-30 05:43:09 --> Helper loaded: html_helper
INFO - 2023-12-30 05:43:09 --> Helper loaded: text_helper
INFO - 2023-12-30 05:43:09 --> Helper loaded: form_helper
INFO - 2023-12-30 05:43:09 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:43:09 --> Helper loaded: security_helper
INFO - 2023-12-30 05:43:09 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:43:09 --> Database Driver Class Initialized
INFO - 2023-12-30 05:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:43:09 --> Parser Class Initialized
INFO - 2023-12-30 05:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:43:09 --> Pagination Class Initialized
INFO - 2023-12-30 05:43:09 --> Form Validation Class Initialized
INFO - 2023-12-30 05:43:09 --> Controller Class Initialized
DEBUG - 2023-12-30 05:43:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:09 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:09 --> Model Class Initialized
INFO - 2023-12-30 05:43:09 --> Final output sent to browser
DEBUG - 2023-12-30 05:43:09 --> Total execution time: 0.1959
ERROR - 2023-12-30 05:43:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:43:36 --> Config Class Initialized
INFO - 2023-12-30 05:43:36 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:43:36 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:43:36 --> Utf8 Class Initialized
INFO - 2023-12-30 05:43:36 --> URI Class Initialized
INFO - 2023-12-30 05:43:36 --> Router Class Initialized
INFO - 2023-12-30 05:43:36 --> Output Class Initialized
INFO - 2023-12-30 05:43:36 --> Security Class Initialized
DEBUG - 2023-12-30 05:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:43:36 --> Input Class Initialized
INFO - 2023-12-30 05:43:36 --> Language Class Initialized
INFO - 2023-12-30 05:43:36 --> Loader Class Initialized
INFO - 2023-12-30 05:43:36 --> Helper loaded: url_helper
INFO - 2023-12-30 05:43:36 --> Helper loaded: file_helper
INFO - 2023-12-30 05:43:36 --> Helper loaded: html_helper
INFO - 2023-12-30 05:43:36 --> Helper loaded: text_helper
INFO - 2023-12-30 05:43:36 --> Helper loaded: form_helper
INFO - 2023-12-30 05:43:36 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:43:36 --> Helper loaded: security_helper
INFO - 2023-12-30 05:43:36 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:43:36 --> Database Driver Class Initialized
INFO - 2023-12-30 05:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:43:36 --> Parser Class Initialized
INFO - 2023-12-30 05:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:43:36 --> Pagination Class Initialized
INFO - 2023-12-30 05:43:36 --> Form Validation Class Initialized
INFO - 2023-12-30 05:43:36 --> Controller Class Initialized
INFO - 2023-12-30 05:43:36 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:36 --> Final output sent to browser
DEBUG - 2023-12-30 05:43:36 --> Total execution time: 0.0190
ERROR - 2023-12-30 05:43:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:43:38 --> Config Class Initialized
INFO - 2023-12-30 05:43:38 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:43:38 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:43:38 --> Utf8 Class Initialized
INFO - 2023-12-30 05:43:38 --> URI Class Initialized
INFO - 2023-12-30 05:43:38 --> Router Class Initialized
INFO - 2023-12-30 05:43:38 --> Output Class Initialized
INFO - 2023-12-30 05:43:38 --> Security Class Initialized
DEBUG - 2023-12-30 05:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:43:38 --> Input Class Initialized
INFO - 2023-12-30 05:43:38 --> Language Class Initialized
INFO - 2023-12-30 05:43:38 --> Loader Class Initialized
INFO - 2023-12-30 05:43:38 --> Helper loaded: url_helper
INFO - 2023-12-30 05:43:38 --> Helper loaded: file_helper
INFO - 2023-12-30 05:43:38 --> Helper loaded: html_helper
INFO - 2023-12-30 05:43:38 --> Helper loaded: text_helper
INFO - 2023-12-30 05:43:38 --> Helper loaded: form_helper
INFO - 2023-12-30 05:43:38 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:43:38 --> Helper loaded: security_helper
INFO - 2023-12-30 05:43:38 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:43:38 --> Database Driver Class Initialized
INFO - 2023-12-30 05:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:43:38 --> Parser Class Initialized
INFO - 2023-12-30 05:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:43:38 --> Pagination Class Initialized
INFO - 2023-12-30 05:43:38 --> Form Validation Class Initialized
INFO - 2023-12-30 05:43:38 --> Controller Class Initialized
INFO - 2023-12-30 05:43:38 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-30 05:43:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 05:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 05:43:38 --> Model Class Initialized
INFO - 2023-12-30 05:43:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 05:43:38 --> Final output sent to browser
DEBUG - 2023-12-30 05:43:38 --> Total execution time: 0.0356
ERROR - 2023-12-30 05:43:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:43:45 --> Config Class Initialized
INFO - 2023-12-30 05:43:45 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:43:45 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:43:45 --> Utf8 Class Initialized
INFO - 2023-12-30 05:43:45 --> URI Class Initialized
INFO - 2023-12-30 05:43:45 --> Router Class Initialized
INFO - 2023-12-30 05:43:45 --> Output Class Initialized
INFO - 2023-12-30 05:43:45 --> Security Class Initialized
DEBUG - 2023-12-30 05:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:43:45 --> Input Class Initialized
INFO - 2023-12-30 05:43:45 --> Language Class Initialized
INFO - 2023-12-30 05:43:45 --> Loader Class Initialized
INFO - 2023-12-30 05:43:45 --> Helper loaded: url_helper
INFO - 2023-12-30 05:43:45 --> Helper loaded: file_helper
INFO - 2023-12-30 05:43:45 --> Helper loaded: html_helper
INFO - 2023-12-30 05:43:45 --> Helper loaded: text_helper
INFO - 2023-12-30 05:43:45 --> Helper loaded: form_helper
INFO - 2023-12-30 05:43:45 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:43:45 --> Helper loaded: security_helper
INFO - 2023-12-30 05:43:45 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:43:45 --> Database Driver Class Initialized
INFO - 2023-12-30 05:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:43:45 --> Parser Class Initialized
INFO - 2023-12-30 05:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:43:45 --> Pagination Class Initialized
INFO - 2023-12-30 05:43:45 --> Form Validation Class Initialized
INFO - 2023-12-30 05:43:45 --> Controller Class Initialized
INFO - 2023-12-30 05:43:45 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:45 --> Model Class Initialized
INFO - 2023-12-30 05:43:45 --> Final output sent to browser
DEBUG - 2023-12-30 05:43:45 --> Total execution time: 0.0208
ERROR - 2023-12-30 05:43:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:43:47 --> Config Class Initialized
INFO - 2023-12-30 05:43:47 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:43:47 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:43:47 --> Utf8 Class Initialized
INFO - 2023-12-30 05:43:47 --> URI Class Initialized
DEBUG - 2023-12-30 05:43:47 --> No URI present. Default controller set.
INFO - 2023-12-30 05:43:47 --> Router Class Initialized
INFO - 2023-12-30 05:43:47 --> Output Class Initialized
INFO - 2023-12-30 05:43:47 --> Security Class Initialized
DEBUG - 2023-12-30 05:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:43:47 --> Input Class Initialized
INFO - 2023-12-30 05:43:47 --> Language Class Initialized
INFO - 2023-12-30 05:43:47 --> Loader Class Initialized
INFO - 2023-12-30 05:43:47 --> Helper loaded: url_helper
INFO - 2023-12-30 05:43:47 --> Helper loaded: file_helper
INFO - 2023-12-30 05:43:47 --> Helper loaded: html_helper
INFO - 2023-12-30 05:43:47 --> Helper loaded: text_helper
INFO - 2023-12-30 05:43:47 --> Helper loaded: form_helper
INFO - 2023-12-30 05:43:47 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:43:47 --> Helper loaded: security_helper
INFO - 2023-12-30 05:43:47 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:43:47 --> Database Driver Class Initialized
INFO - 2023-12-30 05:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:43:47 --> Parser Class Initialized
INFO - 2023-12-30 05:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:43:47 --> Pagination Class Initialized
INFO - 2023-12-30 05:43:47 --> Form Validation Class Initialized
INFO - 2023-12-30 05:43:47 --> Controller Class Initialized
INFO - 2023-12-30 05:43:47 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:47 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:47 --> Model Class Initialized
INFO - 2023-12-30 05:43:47 --> Model Class Initialized
INFO - 2023-12-30 05:43:47 --> Model Class Initialized
INFO - 2023-12-30 05:43:47 --> Model Class Initialized
DEBUG - 2023-12-30 05:43:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:47 --> Model Class Initialized
INFO - 2023-12-30 05:43:47 --> Model Class Initialized
INFO - 2023-12-30 05:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 05:43:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 05:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 05:43:47 --> Model Class Initialized
INFO - 2023-12-30 05:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 05:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 05:43:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 05:43:47 --> Final output sent to browser
DEBUG - 2023-12-30 05:43:47 --> Total execution time: 0.2357
ERROR - 2023-12-30 05:44:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:44:27 --> Config Class Initialized
INFO - 2023-12-30 05:44:27 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:44:27 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:44:27 --> Utf8 Class Initialized
INFO - 2023-12-30 05:44:27 --> URI Class Initialized
INFO - 2023-12-30 05:44:27 --> Router Class Initialized
INFO - 2023-12-30 05:44:27 --> Output Class Initialized
INFO - 2023-12-30 05:44:27 --> Security Class Initialized
DEBUG - 2023-12-30 05:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:44:27 --> Input Class Initialized
INFO - 2023-12-30 05:44:27 --> Language Class Initialized
INFO - 2023-12-30 05:44:27 --> Loader Class Initialized
INFO - 2023-12-30 05:44:27 --> Helper loaded: url_helper
INFO - 2023-12-30 05:44:27 --> Helper loaded: file_helper
INFO - 2023-12-30 05:44:27 --> Helper loaded: html_helper
INFO - 2023-12-30 05:44:27 --> Helper loaded: text_helper
INFO - 2023-12-30 05:44:27 --> Helper loaded: form_helper
INFO - 2023-12-30 05:44:27 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:44:27 --> Helper loaded: security_helper
INFO - 2023-12-30 05:44:27 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:44:27 --> Database Driver Class Initialized
INFO - 2023-12-30 05:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:44:27 --> Parser Class Initialized
INFO - 2023-12-30 05:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:44:27 --> Pagination Class Initialized
INFO - 2023-12-30 05:44:27 --> Form Validation Class Initialized
INFO - 2023-12-30 05:44:27 --> Controller Class Initialized
INFO - 2023-12-30 05:44:27 --> Model Class Initialized
DEBUG - 2023-12-30 05:44:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:44:27 --> Model Class Initialized
DEBUG - 2023-12-30 05:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:44:27 --> Model Class Initialized
INFO - 2023-12-30 05:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-12-30 05:44:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 05:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 05:44:27 --> Model Class Initialized
INFO - 2023-12-30 05:44:27 --> Model Class Initialized
INFO - 2023-12-30 05:44:27 --> Model Class Initialized
INFO - 2023-12-30 05:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 05:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 05:44:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 05:44:27 --> Final output sent to browser
DEBUG - 2023-12-30 05:44:27 --> Total execution time: 0.1682
ERROR - 2023-12-30 05:44:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:44:28 --> Config Class Initialized
INFO - 2023-12-30 05:44:28 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:44:28 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:44:28 --> Utf8 Class Initialized
INFO - 2023-12-30 05:44:28 --> URI Class Initialized
INFO - 2023-12-30 05:44:28 --> Router Class Initialized
INFO - 2023-12-30 05:44:28 --> Output Class Initialized
INFO - 2023-12-30 05:44:28 --> Security Class Initialized
DEBUG - 2023-12-30 05:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:44:28 --> Input Class Initialized
INFO - 2023-12-30 05:44:28 --> Language Class Initialized
INFO - 2023-12-30 05:44:28 --> Loader Class Initialized
INFO - 2023-12-30 05:44:28 --> Helper loaded: url_helper
INFO - 2023-12-30 05:44:28 --> Helper loaded: file_helper
INFO - 2023-12-30 05:44:28 --> Helper loaded: html_helper
INFO - 2023-12-30 05:44:28 --> Helper loaded: text_helper
INFO - 2023-12-30 05:44:28 --> Helper loaded: form_helper
INFO - 2023-12-30 05:44:28 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:44:28 --> Helper loaded: security_helper
INFO - 2023-12-30 05:44:28 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:44:28 --> Database Driver Class Initialized
INFO - 2023-12-30 05:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:44:28 --> Parser Class Initialized
INFO - 2023-12-30 05:44:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:44:28 --> Pagination Class Initialized
INFO - 2023-12-30 05:44:28 --> Form Validation Class Initialized
INFO - 2023-12-30 05:44:28 --> Controller Class Initialized
INFO - 2023-12-30 05:44:28 --> Model Class Initialized
DEBUG - 2023-12-30 05:44:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:44:28 --> Model Class Initialized
DEBUG - 2023-12-30 05:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:44:28 --> Model Class Initialized
INFO - 2023-12-30 05:44:28 --> Final output sent to browser
DEBUG - 2023-12-30 05:44:28 --> Total execution time: 0.0562
ERROR - 2023-12-30 05:44:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 05:44:45 --> Config Class Initialized
INFO - 2023-12-30 05:44:45 --> Hooks Class Initialized
DEBUG - 2023-12-30 05:44:45 --> UTF-8 Support Enabled
INFO - 2023-12-30 05:44:45 --> Utf8 Class Initialized
INFO - 2023-12-30 05:44:45 --> URI Class Initialized
INFO - 2023-12-30 05:44:45 --> Router Class Initialized
INFO - 2023-12-30 05:44:45 --> Output Class Initialized
INFO - 2023-12-30 05:44:45 --> Security Class Initialized
DEBUG - 2023-12-30 05:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 05:44:45 --> Input Class Initialized
INFO - 2023-12-30 05:44:45 --> Language Class Initialized
INFO - 2023-12-30 05:44:45 --> Loader Class Initialized
INFO - 2023-12-30 05:44:45 --> Helper loaded: url_helper
INFO - 2023-12-30 05:44:45 --> Helper loaded: file_helper
INFO - 2023-12-30 05:44:45 --> Helper loaded: html_helper
INFO - 2023-12-30 05:44:45 --> Helper loaded: text_helper
INFO - 2023-12-30 05:44:45 --> Helper loaded: form_helper
INFO - 2023-12-30 05:44:45 --> Helper loaded: lang_helper
INFO - 2023-12-30 05:44:45 --> Helper loaded: security_helper
INFO - 2023-12-30 05:44:45 --> Helper loaded: cookie_helper
INFO - 2023-12-30 05:44:45 --> Database Driver Class Initialized
INFO - 2023-12-30 05:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 05:44:45 --> Parser Class Initialized
INFO - 2023-12-30 05:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 05:44:45 --> Pagination Class Initialized
INFO - 2023-12-30 05:44:45 --> Form Validation Class Initialized
INFO - 2023-12-30 05:44:45 --> Controller Class Initialized
INFO - 2023-12-30 05:44:45 --> Model Class Initialized
DEBUG - 2023-12-30 05:44:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 05:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:44:45 --> Model Class Initialized
DEBUG - 2023-12-30 05:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 05:44:45 --> Model Class Initialized
INFO - 2023-12-30 05:44:45 --> Final output sent to browser
DEBUG - 2023-12-30 05:44:45 --> Total execution time: 0.2275
ERROR - 2023-12-30 06:22:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 06:22:16 --> Config Class Initialized
INFO - 2023-12-30 06:22:16 --> Hooks Class Initialized
DEBUG - 2023-12-30 06:22:16 --> UTF-8 Support Enabled
INFO - 2023-12-30 06:22:16 --> Utf8 Class Initialized
INFO - 2023-12-30 06:22:16 --> URI Class Initialized
INFO - 2023-12-30 06:22:16 --> Router Class Initialized
INFO - 2023-12-30 06:22:16 --> Output Class Initialized
INFO - 2023-12-30 06:22:16 --> Security Class Initialized
DEBUG - 2023-12-30 06:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 06:22:16 --> Input Class Initialized
INFO - 2023-12-30 06:22:16 --> Language Class Initialized
ERROR - 2023-12-30 06:22:16 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-30 08:45:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:45:29 --> Config Class Initialized
INFO - 2023-12-30 08:45:29 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:45:29 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:45:29 --> Utf8 Class Initialized
INFO - 2023-12-30 08:45:29 --> URI Class Initialized
DEBUG - 2023-12-30 08:45:29 --> No URI present. Default controller set.
INFO - 2023-12-30 08:45:29 --> Router Class Initialized
INFO - 2023-12-30 08:45:29 --> Output Class Initialized
INFO - 2023-12-30 08:45:29 --> Security Class Initialized
DEBUG - 2023-12-30 08:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:45:29 --> Input Class Initialized
INFO - 2023-12-30 08:45:29 --> Language Class Initialized
INFO - 2023-12-30 08:45:29 --> Loader Class Initialized
INFO - 2023-12-30 08:45:29 --> Helper loaded: url_helper
INFO - 2023-12-30 08:45:29 --> Helper loaded: file_helper
INFO - 2023-12-30 08:45:29 --> Helper loaded: html_helper
INFO - 2023-12-30 08:45:29 --> Helper loaded: text_helper
INFO - 2023-12-30 08:45:29 --> Helper loaded: form_helper
INFO - 2023-12-30 08:45:29 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:45:29 --> Helper loaded: security_helper
INFO - 2023-12-30 08:45:29 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:45:29 --> Database Driver Class Initialized
INFO - 2023-12-30 08:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:45:29 --> Parser Class Initialized
INFO - 2023-12-30 08:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:45:29 --> Pagination Class Initialized
INFO - 2023-12-30 08:45:29 --> Form Validation Class Initialized
INFO - 2023-12-30 08:45:29 --> Controller Class Initialized
INFO - 2023-12-30 08:45:29 --> Model Class Initialized
DEBUG - 2023-12-30 08:45:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-30 08:45:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:45:31 --> Config Class Initialized
INFO - 2023-12-30 08:45:31 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:45:31 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:45:31 --> Utf8 Class Initialized
INFO - 2023-12-30 08:45:31 --> URI Class Initialized
INFO - 2023-12-30 08:45:31 --> Router Class Initialized
INFO - 2023-12-30 08:45:31 --> Output Class Initialized
INFO - 2023-12-30 08:45:31 --> Security Class Initialized
DEBUG - 2023-12-30 08:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:45:31 --> Input Class Initialized
INFO - 2023-12-30 08:45:31 --> Language Class Initialized
INFO - 2023-12-30 08:45:31 --> Loader Class Initialized
INFO - 2023-12-30 08:45:31 --> Helper loaded: url_helper
INFO - 2023-12-30 08:45:31 --> Helper loaded: file_helper
INFO - 2023-12-30 08:45:31 --> Helper loaded: html_helper
INFO - 2023-12-30 08:45:31 --> Helper loaded: text_helper
INFO - 2023-12-30 08:45:31 --> Helper loaded: form_helper
INFO - 2023-12-30 08:45:31 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:45:31 --> Helper loaded: security_helper
INFO - 2023-12-30 08:45:31 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:45:31 --> Database Driver Class Initialized
INFO - 2023-12-30 08:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:45:31 --> Parser Class Initialized
INFO - 2023-12-30 08:45:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:45:31 --> Pagination Class Initialized
INFO - 2023-12-30 08:45:31 --> Form Validation Class Initialized
INFO - 2023-12-30 08:45:31 --> Controller Class Initialized
INFO - 2023-12-30 08:45:31 --> Model Class Initialized
DEBUG - 2023-12-30 08:45:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-30 08:45:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 08:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 08:45:31 --> Model Class Initialized
INFO - 2023-12-30 08:45:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 08:45:31 --> Final output sent to browser
DEBUG - 2023-12-30 08:45:31 --> Total execution time: 0.0355
ERROR - 2023-12-30 08:45:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:45:38 --> Config Class Initialized
INFO - 2023-12-30 08:45:38 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:45:38 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:45:38 --> Utf8 Class Initialized
INFO - 2023-12-30 08:45:38 --> URI Class Initialized
INFO - 2023-12-30 08:45:38 --> Router Class Initialized
INFO - 2023-12-30 08:45:38 --> Output Class Initialized
INFO - 2023-12-30 08:45:38 --> Security Class Initialized
DEBUG - 2023-12-30 08:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:45:38 --> Input Class Initialized
INFO - 2023-12-30 08:45:38 --> Language Class Initialized
INFO - 2023-12-30 08:45:38 --> Loader Class Initialized
INFO - 2023-12-30 08:45:38 --> Helper loaded: url_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: file_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: html_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: text_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: form_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: security_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:45:38 --> Database Driver Class Initialized
INFO - 2023-12-30 08:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:45:38 --> Parser Class Initialized
INFO - 2023-12-30 08:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:45:38 --> Pagination Class Initialized
INFO - 2023-12-30 08:45:38 --> Form Validation Class Initialized
INFO - 2023-12-30 08:45:38 --> Controller Class Initialized
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
DEBUG - 2023-12-30 08:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
INFO - 2023-12-30 08:45:38 --> Final output sent to browser
DEBUG - 2023-12-30 08:45:38 --> Total execution time: 0.0214
ERROR - 2023-12-30 08:45:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:45:38 --> Config Class Initialized
INFO - 2023-12-30 08:45:38 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:45:38 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:45:38 --> Utf8 Class Initialized
INFO - 2023-12-30 08:45:38 --> URI Class Initialized
DEBUG - 2023-12-30 08:45:38 --> No URI present. Default controller set.
INFO - 2023-12-30 08:45:38 --> Router Class Initialized
INFO - 2023-12-30 08:45:38 --> Output Class Initialized
INFO - 2023-12-30 08:45:38 --> Security Class Initialized
DEBUG - 2023-12-30 08:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:45:38 --> Input Class Initialized
INFO - 2023-12-30 08:45:38 --> Language Class Initialized
INFO - 2023-12-30 08:45:38 --> Loader Class Initialized
INFO - 2023-12-30 08:45:38 --> Helper loaded: url_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: file_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: html_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: text_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: form_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: security_helper
INFO - 2023-12-30 08:45:38 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:45:38 --> Database Driver Class Initialized
INFO - 2023-12-30 08:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:45:38 --> Parser Class Initialized
INFO - 2023-12-30 08:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:45:38 --> Pagination Class Initialized
INFO - 2023-12-30 08:45:38 --> Form Validation Class Initialized
INFO - 2023-12-30 08:45:38 --> Controller Class Initialized
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
DEBUG - 2023-12-30 08:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
DEBUG - 2023-12-30 08:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
DEBUG - 2023-12-30 08:45:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
INFO - 2023-12-30 08:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 08:45:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 08:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 08:45:38 --> Model Class Initialized
INFO - 2023-12-30 08:45:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 08:45:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 08:45:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 08:45:39 --> Final output sent to browser
DEBUG - 2023-12-30 08:45:39 --> Total execution time: 0.4177
ERROR - 2023-12-30 08:45:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:45:39 --> Config Class Initialized
INFO - 2023-12-30 08:45:39 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:45:39 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:45:39 --> Utf8 Class Initialized
INFO - 2023-12-30 08:45:39 --> URI Class Initialized
INFO - 2023-12-30 08:45:39 --> Router Class Initialized
INFO - 2023-12-30 08:45:39 --> Output Class Initialized
INFO - 2023-12-30 08:45:39 --> Security Class Initialized
DEBUG - 2023-12-30 08:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:45:39 --> Input Class Initialized
INFO - 2023-12-30 08:45:39 --> Language Class Initialized
INFO - 2023-12-30 08:45:39 --> Loader Class Initialized
INFO - 2023-12-30 08:45:39 --> Helper loaded: url_helper
INFO - 2023-12-30 08:45:39 --> Helper loaded: file_helper
INFO - 2023-12-30 08:45:39 --> Helper loaded: html_helper
INFO - 2023-12-30 08:45:39 --> Helper loaded: text_helper
INFO - 2023-12-30 08:45:39 --> Helper loaded: form_helper
INFO - 2023-12-30 08:45:39 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:45:39 --> Helper loaded: security_helper
INFO - 2023-12-30 08:45:39 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:45:39 --> Database Driver Class Initialized
INFO - 2023-12-30 08:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:45:39 --> Parser Class Initialized
INFO - 2023-12-30 08:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:45:39 --> Pagination Class Initialized
INFO - 2023-12-30 08:45:39 --> Form Validation Class Initialized
INFO - 2023-12-30 08:45:39 --> Controller Class Initialized
DEBUG - 2023-12-30 08:45:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:39 --> Model Class Initialized
INFO - 2023-12-30 08:45:39 --> Final output sent to browser
DEBUG - 2023-12-30 08:45:39 --> Total execution time: 0.0130
ERROR - 2023-12-30 08:45:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:45:54 --> Config Class Initialized
INFO - 2023-12-30 08:45:54 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:45:54 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:45:54 --> Utf8 Class Initialized
INFO - 2023-12-30 08:45:54 --> URI Class Initialized
INFO - 2023-12-30 08:45:54 --> Router Class Initialized
INFO - 2023-12-30 08:45:54 --> Output Class Initialized
INFO - 2023-12-30 08:45:54 --> Security Class Initialized
DEBUG - 2023-12-30 08:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:45:54 --> Input Class Initialized
INFO - 2023-12-30 08:45:54 --> Language Class Initialized
INFO - 2023-12-30 08:45:54 --> Loader Class Initialized
INFO - 2023-12-30 08:45:54 --> Helper loaded: url_helper
INFO - 2023-12-30 08:45:54 --> Helper loaded: file_helper
INFO - 2023-12-30 08:45:54 --> Helper loaded: html_helper
INFO - 2023-12-30 08:45:54 --> Helper loaded: text_helper
INFO - 2023-12-30 08:45:54 --> Helper loaded: form_helper
INFO - 2023-12-30 08:45:54 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:45:54 --> Helper loaded: security_helper
INFO - 2023-12-30 08:45:54 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:45:54 --> Database Driver Class Initialized
INFO - 2023-12-30 08:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:45:54 --> Parser Class Initialized
INFO - 2023-12-30 08:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:45:54 --> Pagination Class Initialized
INFO - 2023-12-30 08:45:54 --> Form Validation Class Initialized
INFO - 2023-12-30 08:45:54 --> Controller Class Initialized
DEBUG - 2023-12-30 08:45:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:54 --> Model Class Initialized
DEBUG - 2023-12-30 08:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:54 --> Model Class Initialized
DEBUG - 2023-12-30 08:45:54 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:54 --> Model Class Initialized
INFO - 2023-12-30 08:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-12-30 08:45:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 08:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 08:45:54 --> Model Class Initialized
INFO - 2023-12-30 08:45:54 --> Model Class Initialized
INFO - 2023-12-30 08:45:54 --> Model Class Initialized
INFO - 2023-12-30 08:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 08:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 08:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 08:45:54 --> Final output sent to browser
DEBUG - 2023-12-30 08:45:54 --> Total execution time: 0.2092
ERROR - 2023-12-30 08:45:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:45:55 --> Config Class Initialized
INFO - 2023-12-30 08:45:55 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:45:55 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:45:55 --> Utf8 Class Initialized
INFO - 2023-12-30 08:45:55 --> URI Class Initialized
INFO - 2023-12-30 08:45:55 --> Router Class Initialized
INFO - 2023-12-30 08:45:55 --> Output Class Initialized
INFO - 2023-12-30 08:45:55 --> Security Class Initialized
DEBUG - 2023-12-30 08:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:45:55 --> Input Class Initialized
INFO - 2023-12-30 08:45:55 --> Language Class Initialized
INFO - 2023-12-30 08:45:55 --> Loader Class Initialized
INFO - 2023-12-30 08:45:55 --> Helper loaded: url_helper
INFO - 2023-12-30 08:45:55 --> Helper loaded: file_helper
INFO - 2023-12-30 08:45:55 --> Helper loaded: html_helper
INFO - 2023-12-30 08:45:55 --> Helper loaded: text_helper
INFO - 2023-12-30 08:45:55 --> Helper loaded: form_helper
INFO - 2023-12-30 08:45:55 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:45:55 --> Helper loaded: security_helper
INFO - 2023-12-30 08:45:55 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:45:55 --> Database Driver Class Initialized
INFO - 2023-12-30 08:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:45:55 --> Parser Class Initialized
INFO - 2023-12-30 08:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:45:55 --> Pagination Class Initialized
INFO - 2023-12-30 08:45:55 --> Form Validation Class Initialized
INFO - 2023-12-30 08:45:55 --> Controller Class Initialized
DEBUG - 2023-12-30 08:45:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:55 --> Model Class Initialized
DEBUG - 2023-12-30 08:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:45:55 --> Model Class Initialized
INFO - 2023-12-30 08:45:55 --> Final output sent to browser
DEBUG - 2023-12-30 08:45:55 --> Total execution time: 0.0396
ERROR - 2023-12-30 08:46:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:11 --> Config Class Initialized
INFO - 2023-12-30 08:46:11 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:11 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:11 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:11 --> URI Class Initialized
INFO - 2023-12-30 08:46:11 --> Router Class Initialized
INFO - 2023-12-30 08:46:11 --> Output Class Initialized
INFO - 2023-12-30 08:46:11 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:11 --> Input Class Initialized
INFO - 2023-12-30 08:46:11 --> Language Class Initialized
INFO - 2023-12-30 08:46:11 --> Loader Class Initialized
INFO - 2023-12-30 08:46:11 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:11 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:11 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:11 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:11 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:11 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:11 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:11 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:11 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:11 --> Parser Class Initialized
INFO - 2023-12-30 08:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:11 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:11 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:11 --> Controller Class Initialized
DEBUG - 2023-12-30 08:46:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:11 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:11 --> Model Class Initialized
INFO - 2023-12-30 08:46:11 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:11 --> Total execution time: 0.0349
ERROR - 2023-12-30 08:46:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:12 --> Config Class Initialized
INFO - 2023-12-30 08:46:12 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:12 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:12 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:12 --> URI Class Initialized
INFO - 2023-12-30 08:46:12 --> Router Class Initialized
INFO - 2023-12-30 08:46:12 --> Output Class Initialized
INFO - 2023-12-30 08:46:12 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:12 --> Input Class Initialized
INFO - 2023-12-30 08:46:12 --> Language Class Initialized
INFO - 2023-12-30 08:46:12 --> Loader Class Initialized
INFO - 2023-12-30 08:46:12 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:12 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:12 --> Parser Class Initialized
INFO - 2023-12-30 08:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:12 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:12 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:12 --> Controller Class Initialized
DEBUG - 2023-12-30 08:46:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:12 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:12 --> Model Class Initialized
INFO - 2023-12-30 08:46:12 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:12 --> Total execution time: 0.0319
ERROR - 2023-12-30 08:46:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:12 --> Config Class Initialized
INFO - 2023-12-30 08:46:12 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:12 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:12 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:12 --> URI Class Initialized
INFO - 2023-12-30 08:46:12 --> Router Class Initialized
INFO - 2023-12-30 08:46:12 --> Output Class Initialized
INFO - 2023-12-30 08:46:12 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:12 --> Input Class Initialized
INFO - 2023-12-30 08:46:12 --> Language Class Initialized
INFO - 2023-12-30 08:46:12 --> Loader Class Initialized
INFO - 2023-12-30 08:46:12 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:12 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:12 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:12 --> Parser Class Initialized
INFO - 2023-12-30 08:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:12 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:12 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:12 --> Controller Class Initialized
DEBUG - 2023-12-30 08:46:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:12 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:12 --> Model Class Initialized
INFO - 2023-12-30 08:46:12 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:12 --> Total execution time: 0.0276
ERROR - 2023-12-30 08:46:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:13 --> Config Class Initialized
INFO - 2023-12-30 08:46:13 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:13 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:13 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:13 --> URI Class Initialized
INFO - 2023-12-30 08:46:13 --> Router Class Initialized
INFO - 2023-12-30 08:46:13 --> Output Class Initialized
INFO - 2023-12-30 08:46:13 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:13 --> Input Class Initialized
INFO - 2023-12-30 08:46:13 --> Language Class Initialized
INFO - 2023-12-30 08:46:13 --> Loader Class Initialized
INFO - 2023-12-30 08:46:13 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:13 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:13 --> Parser Class Initialized
INFO - 2023-12-30 08:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:13 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:13 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:13 --> Controller Class Initialized
DEBUG - 2023-12-30 08:46:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:13 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:13 --> Model Class Initialized
INFO - 2023-12-30 08:46:13 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:13 --> Total execution time: 0.0244
ERROR - 2023-12-30 08:46:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:13 --> Config Class Initialized
INFO - 2023-12-30 08:46:13 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:13 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:13 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:13 --> URI Class Initialized
INFO - 2023-12-30 08:46:13 --> Router Class Initialized
INFO - 2023-12-30 08:46:13 --> Output Class Initialized
INFO - 2023-12-30 08:46:13 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:13 --> Input Class Initialized
INFO - 2023-12-30 08:46:13 --> Language Class Initialized
INFO - 2023-12-30 08:46:13 --> Loader Class Initialized
INFO - 2023-12-30 08:46:13 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:13 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:13 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:13 --> Parser Class Initialized
INFO - 2023-12-30 08:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:13 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:13 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:13 --> Controller Class Initialized
DEBUG - 2023-12-30 08:46:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:13 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:13 --> Model Class Initialized
INFO - 2023-12-30 08:46:13 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:13 --> Total execution time: 0.0246
ERROR - 2023-12-30 08:46:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:25 --> Config Class Initialized
INFO - 2023-12-30 08:46:25 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:25 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:25 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:25 --> URI Class Initialized
DEBUG - 2023-12-30 08:46:25 --> No URI present. Default controller set.
INFO - 2023-12-30 08:46:25 --> Router Class Initialized
INFO - 2023-12-30 08:46:25 --> Output Class Initialized
INFO - 2023-12-30 08:46:25 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:25 --> Input Class Initialized
INFO - 2023-12-30 08:46:25 --> Language Class Initialized
INFO - 2023-12-30 08:46:25 --> Loader Class Initialized
INFO - 2023-12-30 08:46:25 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:25 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:25 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:25 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:25 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:25 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:25 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:25 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:25 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:25 --> Parser Class Initialized
INFO - 2023-12-30 08:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:25 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:25 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:25 --> Controller Class Initialized
INFO - 2023-12-30 08:46:25 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:25 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:25 --> Model Class Initialized
INFO - 2023-12-30 08:46:25 --> Model Class Initialized
INFO - 2023-12-30 08:46:25 --> Model Class Initialized
INFO - 2023-12-30 08:46:25 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:25 --> Model Class Initialized
INFO - 2023-12-30 08:46:25 --> Model Class Initialized
INFO - 2023-12-30 08:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 08:46:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 08:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 08:46:25 --> Model Class Initialized
INFO - 2023-12-30 08:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 08:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 08:46:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 08:46:25 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:25 --> Total execution time: 0.4080
ERROR - 2023-12-30 08:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:28 --> Config Class Initialized
INFO - 2023-12-30 08:46:28 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:28 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:28 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:28 --> URI Class Initialized
INFO - 2023-12-30 08:46:28 --> Router Class Initialized
INFO - 2023-12-30 08:46:28 --> Output Class Initialized
INFO - 2023-12-30 08:46:28 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:28 --> Input Class Initialized
INFO - 2023-12-30 08:46:28 --> Language Class Initialized
INFO - 2023-12-30 08:46:28 --> Loader Class Initialized
INFO - 2023-12-30 08:46:28 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:28 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:28 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:28 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:28 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:28 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:28 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:28 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:28 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:28 --> Parser Class Initialized
INFO - 2023-12-30 08:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:28 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:28 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:28 --> Controller Class Initialized
DEBUG - 2023-12-30 08:46:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:28 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:28 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:28 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:28 --> Model Class Initialized
INFO - 2023-12-30 08:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/credit_customer.php
DEBUG - 2023-12-30 08:46:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 08:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 08:46:28 --> Model Class Initialized
INFO - 2023-12-30 08:46:28 --> Model Class Initialized
INFO - 2023-12-30 08:46:28 --> Model Class Initialized
INFO - 2023-12-30 08:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 08:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 08:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 08:46:28 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:28 --> Total execution time: 0.2283
ERROR - 2023-12-30 08:46:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:29 --> Config Class Initialized
INFO - 2023-12-30 08:46:29 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:29 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:29 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:29 --> URI Class Initialized
INFO - 2023-12-30 08:46:29 --> Router Class Initialized
INFO - 2023-12-30 08:46:29 --> Output Class Initialized
INFO - 2023-12-30 08:46:29 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:29 --> Input Class Initialized
INFO - 2023-12-30 08:46:29 --> Language Class Initialized
INFO - 2023-12-30 08:46:29 --> Loader Class Initialized
INFO - 2023-12-30 08:46:29 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:29 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:29 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:29 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:29 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:29 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:29 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:29 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:29 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:29 --> Parser Class Initialized
INFO - 2023-12-30 08:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:29 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:29 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:29 --> Controller Class Initialized
DEBUG - 2023-12-30 08:46:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:29 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:29 --> Model Class Initialized
INFO - 2023-12-30 08:46:29 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:29 --> Total execution time: 0.0598
ERROR - 2023-12-30 08:46:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:50 --> Config Class Initialized
INFO - 2023-12-30 08:46:50 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:50 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:50 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:50 --> URI Class Initialized
INFO - 2023-12-30 08:46:50 --> Router Class Initialized
INFO - 2023-12-30 08:46:50 --> Output Class Initialized
INFO - 2023-12-30 08:46:50 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:50 --> Input Class Initialized
INFO - 2023-12-30 08:46:50 --> Language Class Initialized
INFO - 2023-12-30 08:46:50 --> Loader Class Initialized
INFO - 2023-12-30 08:46:50 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:50 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:50 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:50 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:50 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:50 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:50 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:50 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:50 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:50 --> Parser Class Initialized
INFO - 2023-12-30 08:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:50 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:50 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:50 --> Controller Class Initialized
DEBUG - 2023-12-30 08:46:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:50 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:50 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:50 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:50 --> Model Class Initialized
INFO - 2023-12-30 08:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/paid_customer.php
DEBUG - 2023-12-30 08:46:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 08:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 08:46:51 --> Model Class Initialized
INFO - 2023-12-30 08:46:51 --> Model Class Initialized
INFO - 2023-12-30 08:46:51 --> Model Class Initialized
INFO - 2023-12-30 08:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 08:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 08:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 08:46:51 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:51 --> Total execution time: 0.2409
ERROR - 2023-12-30 08:46:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:46:53 --> Config Class Initialized
INFO - 2023-12-30 08:46:53 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:46:53 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:46:53 --> Utf8 Class Initialized
INFO - 2023-12-30 08:46:53 --> URI Class Initialized
INFO - 2023-12-30 08:46:53 --> Router Class Initialized
INFO - 2023-12-30 08:46:53 --> Output Class Initialized
INFO - 2023-12-30 08:46:53 --> Security Class Initialized
DEBUG - 2023-12-30 08:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:46:53 --> Input Class Initialized
INFO - 2023-12-30 08:46:53 --> Language Class Initialized
INFO - 2023-12-30 08:46:53 --> Loader Class Initialized
INFO - 2023-12-30 08:46:53 --> Helper loaded: url_helper
INFO - 2023-12-30 08:46:53 --> Helper loaded: file_helper
INFO - 2023-12-30 08:46:53 --> Helper loaded: html_helper
INFO - 2023-12-30 08:46:53 --> Helper loaded: text_helper
INFO - 2023-12-30 08:46:53 --> Helper loaded: form_helper
INFO - 2023-12-30 08:46:53 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:46:53 --> Helper loaded: security_helper
INFO - 2023-12-30 08:46:53 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:46:53 --> Database Driver Class Initialized
INFO - 2023-12-30 08:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:46:53 --> Parser Class Initialized
INFO - 2023-12-30 08:46:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:46:53 --> Pagination Class Initialized
INFO - 2023-12-30 08:46:53 --> Form Validation Class Initialized
INFO - 2023-12-30 08:46:53 --> Controller Class Initialized
DEBUG - 2023-12-30 08:46:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:53 --> Model Class Initialized
DEBUG - 2023-12-30 08:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:46:53 --> Model Class Initialized
INFO - 2023-12-30 08:46:53 --> Final output sent to browser
DEBUG - 2023-12-30 08:46:53 --> Total execution time: 0.0601
ERROR - 2023-12-30 08:47:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:47:00 --> Config Class Initialized
INFO - 2023-12-30 08:47:00 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:47:00 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:47:00 --> Utf8 Class Initialized
INFO - 2023-12-30 08:47:00 --> URI Class Initialized
INFO - 2023-12-30 08:47:00 --> Router Class Initialized
INFO - 2023-12-30 08:47:00 --> Output Class Initialized
INFO - 2023-12-30 08:47:00 --> Security Class Initialized
DEBUG - 2023-12-30 08:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:47:00 --> Input Class Initialized
INFO - 2023-12-30 08:47:00 --> Language Class Initialized
INFO - 2023-12-30 08:47:00 --> Loader Class Initialized
INFO - 2023-12-30 08:47:00 --> Helper loaded: url_helper
INFO - 2023-12-30 08:47:00 --> Helper loaded: file_helper
INFO - 2023-12-30 08:47:00 --> Helper loaded: html_helper
INFO - 2023-12-30 08:47:00 --> Helper loaded: text_helper
INFO - 2023-12-30 08:47:00 --> Helper loaded: form_helper
INFO - 2023-12-30 08:47:00 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:47:00 --> Helper loaded: security_helper
INFO - 2023-12-30 08:47:00 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:47:00 --> Database Driver Class Initialized
INFO - 2023-12-30 08:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:47:00 --> Parser Class Initialized
INFO - 2023-12-30 08:47:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:47:00 --> Pagination Class Initialized
INFO - 2023-12-30 08:47:00 --> Form Validation Class Initialized
INFO - 2023-12-30 08:47:00 --> Controller Class Initialized
DEBUG - 2023-12-30 08:47:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:47:00 --> Model Class Initialized
DEBUG - 2023-12-30 08:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:47:00 --> Model Class Initialized
INFO - 2023-12-30 08:47:01 --> Final output sent to browser
DEBUG - 2023-12-30 08:47:01 --> Total execution time: 0.1560
ERROR - 2023-12-30 08:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 08:47:07 --> Config Class Initialized
INFO - 2023-12-30 08:47:07 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:47:07 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:47:07 --> Utf8 Class Initialized
INFO - 2023-12-30 08:47:07 --> URI Class Initialized
INFO - 2023-12-30 08:47:07 --> Router Class Initialized
INFO - 2023-12-30 08:47:07 --> Output Class Initialized
INFO - 2023-12-30 08:47:07 --> Security Class Initialized
DEBUG - 2023-12-30 08:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:47:07 --> Input Class Initialized
INFO - 2023-12-30 08:47:07 --> Language Class Initialized
INFO - 2023-12-30 08:47:07 --> Loader Class Initialized
INFO - 2023-12-30 08:47:07 --> Helper loaded: url_helper
INFO - 2023-12-30 08:47:07 --> Helper loaded: file_helper
INFO - 2023-12-30 08:47:07 --> Helper loaded: html_helper
INFO - 2023-12-30 08:47:07 --> Helper loaded: text_helper
INFO - 2023-12-30 08:47:07 --> Helper loaded: form_helper
INFO - 2023-12-30 08:47:07 --> Helper loaded: lang_helper
INFO - 2023-12-30 08:47:07 --> Helper loaded: security_helper
INFO - 2023-12-30 08:47:07 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:47:07 --> Database Driver Class Initialized
INFO - 2023-12-30 08:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:47:07 --> Parser Class Initialized
INFO - 2023-12-30 08:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 08:47:07 --> Pagination Class Initialized
INFO - 2023-12-30 08:47:07 --> Form Validation Class Initialized
INFO - 2023-12-30 08:47:07 --> Controller Class Initialized
DEBUG - 2023-12-30 08:47:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 08:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:47:07 --> Model Class Initialized
DEBUG - 2023-12-30 08:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:47:07 --> Model Class Initialized
DEBUG - 2023-12-30 08:47:07 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:47:07 --> Model Class Initialized
INFO - 2023-12-30 08:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/credit_customer.php
DEBUG - 2023-12-30 08:47:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 08:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 08:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 08:47:07 --> Model Class Initialized
INFO - 2023-12-30 08:47:07 --> Model Class Initialized
INFO - 2023-12-30 08:47:07 --> Model Class Initialized
INFO - 2023-12-30 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 08:47:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 08:47:08 --> Final output sent to browser
DEBUG - 2023-12-30 08:47:08 --> Total execution time: 0.2254
ERROR - 2023-12-30 09:15:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 09:15:03 --> Config Class Initialized
INFO - 2023-12-30 09:15:03 --> Hooks Class Initialized
DEBUG - 2023-12-30 09:15:03 --> UTF-8 Support Enabled
INFO - 2023-12-30 09:15:03 --> Utf8 Class Initialized
INFO - 2023-12-30 09:15:03 --> URI Class Initialized
DEBUG - 2023-12-30 09:15:03 --> No URI present. Default controller set.
INFO - 2023-12-30 09:15:03 --> Router Class Initialized
INFO - 2023-12-30 09:15:03 --> Output Class Initialized
INFO - 2023-12-30 09:15:03 --> Security Class Initialized
DEBUG - 2023-12-30 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 09:15:03 --> Input Class Initialized
INFO - 2023-12-30 09:15:03 --> Language Class Initialized
INFO - 2023-12-30 09:15:03 --> Loader Class Initialized
INFO - 2023-12-30 09:15:03 --> Helper loaded: url_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: file_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: html_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: text_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: form_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: lang_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: security_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: cookie_helper
INFO - 2023-12-30 09:15:03 --> Database Driver Class Initialized
INFO - 2023-12-30 09:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 09:15:03 --> Parser Class Initialized
INFO - 2023-12-30 09:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 09:15:03 --> Pagination Class Initialized
INFO - 2023-12-30 09:15:03 --> Form Validation Class Initialized
INFO - 2023-12-30 09:15:03 --> Controller Class Initialized
INFO - 2023-12-30 09:15:03 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-30 09:15:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 09:15:03 --> Config Class Initialized
INFO - 2023-12-30 09:15:03 --> Hooks Class Initialized
DEBUG - 2023-12-30 09:15:03 --> UTF-8 Support Enabled
INFO - 2023-12-30 09:15:03 --> Utf8 Class Initialized
INFO - 2023-12-30 09:15:03 --> URI Class Initialized
INFO - 2023-12-30 09:15:03 --> Router Class Initialized
INFO - 2023-12-30 09:15:03 --> Output Class Initialized
INFO - 2023-12-30 09:15:03 --> Security Class Initialized
DEBUG - 2023-12-30 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 09:15:03 --> Input Class Initialized
INFO - 2023-12-30 09:15:03 --> Language Class Initialized
INFO - 2023-12-30 09:15:03 --> Loader Class Initialized
INFO - 2023-12-30 09:15:03 --> Helper loaded: url_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: file_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: html_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: text_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: form_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: lang_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: security_helper
INFO - 2023-12-30 09:15:03 --> Helper loaded: cookie_helper
INFO - 2023-12-30 09:15:03 --> Database Driver Class Initialized
INFO - 2023-12-30 09:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 09:15:03 --> Parser Class Initialized
INFO - 2023-12-30 09:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 09:15:03 --> Pagination Class Initialized
INFO - 2023-12-30 09:15:03 --> Form Validation Class Initialized
INFO - 2023-12-30 09:15:03 --> Controller Class Initialized
INFO - 2023-12-30 09:15:03 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-30 09:15:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 09:15:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 09:15:03 --> Model Class Initialized
INFO - 2023-12-30 09:15:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 09:15:03 --> Final output sent to browser
DEBUG - 2023-12-30 09:15:03 --> Total execution time: 0.0430
ERROR - 2023-12-30 09:15:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 09:15:14 --> Config Class Initialized
INFO - 2023-12-30 09:15:14 --> Hooks Class Initialized
DEBUG - 2023-12-30 09:15:14 --> UTF-8 Support Enabled
INFO - 2023-12-30 09:15:14 --> Utf8 Class Initialized
INFO - 2023-12-30 09:15:14 --> URI Class Initialized
INFO - 2023-12-30 09:15:14 --> Router Class Initialized
INFO - 2023-12-30 09:15:14 --> Output Class Initialized
INFO - 2023-12-30 09:15:14 --> Security Class Initialized
DEBUG - 2023-12-30 09:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 09:15:14 --> Input Class Initialized
INFO - 2023-12-30 09:15:14 --> Language Class Initialized
INFO - 2023-12-30 09:15:15 --> Loader Class Initialized
INFO - 2023-12-30 09:15:15 --> Helper loaded: url_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: file_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: html_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: text_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: form_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: lang_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: security_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: cookie_helper
INFO - 2023-12-30 09:15:15 --> Database Driver Class Initialized
INFO - 2023-12-30 09:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 09:15:15 --> Parser Class Initialized
INFO - 2023-12-30 09:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 09:15:15 --> Pagination Class Initialized
INFO - 2023-12-30 09:15:15 --> Form Validation Class Initialized
INFO - 2023-12-30 09:15:15 --> Controller Class Initialized
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
INFO - 2023-12-30 09:15:15 --> Final output sent to browser
DEBUG - 2023-12-30 09:15:15 --> Total execution time: 0.0236
ERROR - 2023-12-30 09:15:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 09:15:15 --> Config Class Initialized
INFO - 2023-12-30 09:15:15 --> Hooks Class Initialized
DEBUG - 2023-12-30 09:15:15 --> UTF-8 Support Enabled
INFO - 2023-12-30 09:15:15 --> Utf8 Class Initialized
INFO - 2023-12-30 09:15:15 --> URI Class Initialized
DEBUG - 2023-12-30 09:15:15 --> No URI present. Default controller set.
INFO - 2023-12-30 09:15:15 --> Router Class Initialized
INFO - 2023-12-30 09:15:15 --> Output Class Initialized
INFO - 2023-12-30 09:15:15 --> Security Class Initialized
DEBUG - 2023-12-30 09:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 09:15:15 --> Input Class Initialized
INFO - 2023-12-30 09:15:15 --> Language Class Initialized
INFO - 2023-12-30 09:15:15 --> Loader Class Initialized
INFO - 2023-12-30 09:15:15 --> Helper loaded: url_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: file_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: html_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: text_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: form_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: lang_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: security_helper
INFO - 2023-12-30 09:15:15 --> Helper loaded: cookie_helper
INFO - 2023-12-30 09:15:15 --> Database Driver Class Initialized
INFO - 2023-12-30 09:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 09:15:15 --> Parser Class Initialized
INFO - 2023-12-30 09:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 09:15:15 --> Pagination Class Initialized
INFO - 2023-12-30 09:15:15 --> Form Validation Class Initialized
INFO - 2023-12-30 09:15:15 --> Controller Class Initialized
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 09:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
INFO - 2023-12-30 09:15:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 09:15:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 09:15:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 09:15:15 --> Model Class Initialized
INFO - 2023-12-30 09:15:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 09:15:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 09:15:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 09:15:15 --> Final output sent to browser
DEBUG - 2023-12-30 09:15:15 --> Total execution time: 0.2432
ERROR - 2023-12-30 09:15:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 09:15:20 --> Config Class Initialized
INFO - 2023-12-30 09:15:20 --> Hooks Class Initialized
DEBUG - 2023-12-30 09:15:20 --> UTF-8 Support Enabled
INFO - 2023-12-30 09:15:20 --> Utf8 Class Initialized
INFO - 2023-12-30 09:15:20 --> URI Class Initialized
INFO - 2023-12-30 09:15:20 --> Router Class Initialized
INFO - 2023-12-30 09:15:20 --> Output Class Initialized
INFO - 2023-12-30 09:15:20 --> Security Class Initialized
DEBUG - 2023-12-30 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 09:15:20 --> Input Class Initialized
INFO - 2023-12-30 09:15:20 --> Language Class Initialized
INFO - 2023-12-30 09:15:20 --> Loader Class Initialized
INFO - 2023-12-30 09:15:20 --> Helper loaded: url_helper
INFO - 2023-12-30 09:15:20 --> Helper loaded: file_helper
INFO - 2023-12-30 09:15:20 --> Helper loaded: html_helper
INFO - 2023-12-30 09:15:20 --> Helper loaded: text_helper
INFO - 2023-12-30 09:15:20 --> Helper loaded: form_helper
INFO - 2023-12-30 09:15:20 --> Helper loaded: lang_helper
INFO - 2023-12-30 09:15:20 --> Helper loaded: security_helper
INFO - 2023-12-30 09:15:20 --> Helper loaded: cookie_helper
INFO - 2023-12-30 09:15:20 --> Database Driver Class Initialized
INFO - 2023-12-30 09:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 09:15:20 --> Parser Class Initialized
INFO - 2023-12-30 09:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 09:15:20 --> Pagination Class Initialized
INFO - 2023-12-30 09:15:20 --> Form Validation Class Initialized
INFO - 2023-12-30 09:15:20 --> Controller Class Initialized
INFO - 2023-12-30 09:15:20 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 09:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:20 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:20 --> Model Class Initialized
INFO - 2023-12-30 09:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-30 09:15:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 09:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 09:15:20 --> Model Class Initialized
INFO - 2023-12-30 09:15:20 --> Model Class Initialized
INFO - 2023-12-30 09:15:20 --> Model Class Initialized
INFO - 2023-12-30 09:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 09:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 09:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 09:15:20 --> Final output sent to browser
DEBUG - 2023-12-30 09:15:20 --> Total execution time: 0.1487
ERROR - 2023-12-30 09:15:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 09:15:21 --> Config Class Initialized
INFO - 2023-12-30 09:15:21 --> Hooks Class Initialized
DEBUG - 2023-12-30 09:15:21 --> UTF-8 Support Enabled
INFO - 2023-12-30 09:15:21 --> Utf8 Class Initialized
INFO - 2023-12-30 09:15:21 --> URI Class Initialized
INFO - 2023-12-30 09:15:21 --> Router Class Initialized
INFO - 2023-12-30 09:15:21 --> Output Class Initialized
INFO - 2023-12-30 09:15:21 --> Security Class Initialized
DEBUG - 2023-12-30 09:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 09:15:21 --> Input Class Initialized
INFO - 2023-12-30 09:15:21 --> Language Class Initialized
INFO - 2023-12-30 09:15:21 --> Loader Class Initialized
INFO - 2023-12-30 09:15:21 --> Helper loaded: url_helper
INFO - 2023-12-30 09:15:21 --> Helper loaded: file_helper
INFO - 2023-12-30 09:15:21 --> Helper loaded: html_helper
INFO - 2023-12-30 09:15:21 --> Helper loaded: text_helper
INFO - 2023-12-30 09:15:21 --> Helper loaded: form_helper
INFO - 2023-12-30 09:15:21 --> Helper loaded: lang_helper
INFO - 2023-12-30 09:15:21 --> Helper loaded: security_helper
INFO - 2023-12-30 09:15:21 --> Helper loaded: cookie_helper
INFO - 2023-12-30 09:15:21 --> Database Driver Class Initialized
INFO - 2023-12-30 09:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 09:15:21 --> Parser Class Initialized
INFO - 2023-12-30 09:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 09:15:21 --> Pagination Class Initialized
INFO - 2023-12-30 09:15:21 --> Form Validation Class Initialized
INFO - 2023-12-30 09:15:21 --> Controller Class Initialized
INFO - 2023-12-30 09:15:21 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 09:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:21 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:21 --> Model Class Initialized
INFO - 2023-12-30 09:15:21 --> Final output sent to browser
DEBUG - 2023-12-30 09:15:21 --> Total execution time: 0.0462
ERROR - 2023-12-30 09:15:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 09:15:34 --> Config Class Initialized
INFO - 2023-12-30 09:15:34 --> Hooks Class Initialized
DEBUG - 2023-12-30 09:15:34 --> UTF-8 Support Enabled
INFO - 2023-12-30 09:15:34 --> Utf8 Class Initialized
INFO - 2023-12-30 09:15:34 --> URI Class Initialized
INFO - 2023-12-30 09:15:34 --> Router Class Initialized
INFO - 2023-12-30 09:15:34 --> Output Class Initialized
INFO - 2023-12-30 09:15:34 --> Security Class Initialized
DEBUG - 2023-12-30 09:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 09:15:34 --> Input Class Initialized
INFO - 2023-12-30 09:15:34 --> Language Class Initialized
INFO - 2023-12-30 09:15:34 --> Loader Class Initialized
INFO - 2023-12-30 09:15:34 --> Helper loaded: url_helper
INFO - 2023-12-30 09:15:34 --> Helper loaded: file_helper
INFO - 2023-12-30 09:15:34 --> Helper loaded: html_helper
INFO - 2023-12-30 09:15:34 --> Helper loaded: text_helper
INFO - 2023-12-30 09:15:34 --> Helper loaded: form_helper
INFO - 2023-12-30 09:15:34 --> Helper loaded: lang_helper
INFO - 2023-12-30 09:15:34 --> Helper loaded: security_helper
INFO - 2023-12-30 09:15:34 --> Helper loaded: cookie_helper
INFO - 2023-12-30 09:15:34 --> Database Driver Class Initialized
INFO - 2023-12-30 09:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 09:15:34 --> Parser Class Initialized
INFO - 2023-12-30 09:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 09:15:34 --> Pagination Class Initialized
INFO - 2023-12-30 09:15:34 --> Form Validation Class Initialized
INFO - 2023-12-30 09:15:34 --> Controller Class Initialized
INFO - 2023-12-30 09:15:34 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 09:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:34 --> Model Class Initialized
DEBUG - 2023-12-30 09:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:15:34 --> Model Class Initialized
INFO - 2023-12-30 09:15:34 --> Final output sent to browser
DEBUG - 2023-12-30 09:15:34 --> Total execution time: 0.0791
ERROR - 2023-12-30 09:16:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 09:16:28 --> Config Class Initialized
INFO - 2023-12-30 09:16:28 --> Hooks Class Initialized
DEBUG - 2023-12-30 09:16:28 --> UTF-8 Support Enabled
INFO - 2023-12-30 09:16:28 --> Utf8 Class Initialized
INFO - 2023-12-30 09:16:28 --> URI Class Initialized
INFO - 2023-12-30 09:16:28 --> Router Class Initialized
INFO - 2023-12-30 09:16:28 --> Output Class Initialized
INFO - 2023-12-30 09:16:28 --> Security Class Initialized
DEBUG - 2023-12-30 09:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 09:16:28 --> Input Class Initialized
INFO - 2023-12-30 09:16:28 --> Language Class Initialized
INFO - 2023-12-30 09:16:28 --> Loader Class Initialized
INFO - 2023-12-30 09:16:28 --> Helper loaded: url_helper
INFO - 2023-12-30 09:16:28 --> Helper loaded: file_helper
INFO - 2023-12-30 09:16:28 --> Helper loaded: html_helper
INFO - 2023-12-30 09:16:28 --> Helper loaded: text_helper
INFO - 2023-12-30 09:16:28 --> Helper loaded: form_helper
INFO - 2023-12-30 09:16:28 --> Helper loaded: lang_helper
INFO - 2023-12-30 09:16:28 --> Helper loaded: security_helper
INFO - 2023-12-30 09:16:28 --> Helper loaded: cookie_helper
INFO - 2023-12-30 09:16:28 --> Database Driver Class Initialized
INFO - 2023-12-30 09:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 09:16:28 --> Parser Class Initialized
INFO - 2023-12-30 09:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 09:16:28 --> Pagination Class Initialized
INFO - 2023-12-30 09:16:28 --> Form Validation Class Initialized
INFO - 2023-12-30 09:16:28 --> Controller Class Initialized
INFO - 2023-12-30 09:16:28 --> Model Class Initialized
DEBUG - 2023-12-30 09:16:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 09:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:16:28 --> Model Class Initialized
DEBUG - 2023-12-30 09:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:16:28 --> Model Class Initialized
DEBUG - 2023-12-30 09:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-12-30 09:16:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 09:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 09:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 09:16:28 --> Model Class Initialized
INFO - 2023-12-30 09:16:28 --> Model Class Initialized
INFO - 2023-12-30 09:16:28 --> Model Class Initialized
INFO - 2023-12-30 09:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 09:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 09:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 09:16:28 --> Final output sent to browser
DEBUG - 2023-12-30 09:16:28 --> Total execution time: 0.1520
ERROR - 2023-12-30 14:32:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:32:18 --> Config Class Initialized
INFO - 2023-12-30 14:32:18 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:32:18 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:32:18 --> Utf8 Class Initialized
INFO - 2023-12-30 14:32:18 --> URI Class Initialized
DEBUG - 2023-12-30 14:32:18 --> No URI present. Default controller set.
INFO - 2023-12-30 14:32:18 --> Router Class Initialized
INFO - 2023-12-30 14:32:18 --> Output Class Initialized
INFO - 2023-12-30 14:32:18 --> Security Class Initialized
DEBUG - 2023-12-30 14:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:32:18 --> Input Class Initialized
INFO - 2023-12-30 14:32:18 --> Language Class Initialized
INFO - 2023-12-30 14:32:18 --> Loader Class Initialized
INFO - 2023-12-30 14:32:18 --> Helper loaded: url_helper
INFO - 2023-12-30 14:32:18 --> Helper loaded: file_helper
INFO - 2023-12-30 14:32:18 --> Helper loaded: html_helper
INFO - 2023-12-30 14:32:18 --> Helper loaded: text_helper
INFO - 2023-12-30 14:32:18 --> Helper loaded: form_helper
INFO - 2023-12-30 14:32:18 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:32:18 --> Helper loaded: security_helper
INFO - 2023-12-30 14:32:18 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:32:18 --> Database Driver Class Initialized
INFO - 2023-12-30 14:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:32:18 --> Parser Class Initialized
INFO - 2023-12-30 14:32:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:32:18 --> Pagination Class Initialized
INFO - 2023-12-30 14:32:18 --> Form Validation Class Initialized
INFO - 2023-12-30 14:32:18 --> Controller Class Initialized
INFO - 2023-12-30 14:32:18 --> Model Class Initialized
DEBUG - 2023-12-30 14:32:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-30 14:32:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:32:19 --> Config Class Initialized
INFO - 2023-12-30 14:32:19 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:32:19 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:32:19 --> Utf8 Class Initialized
INFO - 2023-12-30 14:32:19 --> URI Class Initialized
INFO - 2023-12-30 14:32:19 --> Router Class Initialized
INFO - 2023-12-30 14:32:19 --> Output Class Initialized
INFO - 2023-12-30 14:32:19 --> Security Class Initialized
DEBUG - 2023-12-30 14:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:32:19 --> Input Class Initialized
INFO - 2023-12-30 14:32:19 --> Language Class Initialized
INFO - 2023-12-30 14:32:19 --> Loader Class Initialized
INFO - 2023-12-30 14:32:19 --> Helper loaded: url_helper
INFO - 2023-12-30 14:32:19 --> Helper loaded: file_helper
INFO - 2023-12-30 14:32:19 --> Helper loaded: html_helper
INFO - 2023-12-30 14:32:19 --> Helper loaded: text_helper
INFO - 2023-12-30 14:32:19 --> Helper loaded: form_helper
INFO - 2023-12-30 14:32:19 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:32:19 --> Helper loaded: security_helper
INFO - 2023-12-30 14:32:19 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:32:19 --> Database Driver Class Initialized
INFO - 2023-12-30 14:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:32:19 --> Parser Class Initialized
INFO - 2023-12-30 14:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:32:19 --> Pagination Class Initialized
INFO - 2023-12-30 14:32:19 --> Form Validation Class Initialized
INFO - 2023-12-30 14:32:19 --> Controller Class Initialized
INFO - 2023-12-30 14:32:19 --> Model Class Initialized
DEBUG - 2023-12-30 14:32:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:32:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-30 14:32:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:32:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 14:32:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 14:32:19 --> Model Class Initialized
INFO - 2023-12-30 14:32:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 14:32:19 --> Final output sent to browser
DEBUG - 2023-12-30 14:32:19 --> Total execution time: 0.0429
ERROR - 2023-12-30 14:37:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:30 --> Config Class Initialized
INFO - 2023-12-30 14:37:30 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:30 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:30 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:30 --> URI Class Initialized
DEBUG - 2023-12-30 14:37:30 --> No URI present. Default controller set.
INFO - 2023-12-30 14:37:30 --> Router Class Initialized
INFO - 2023-12-30 14:37:30 --> Output Class Initialized
INFO - 2023-12-30 14:37:30 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:30 --> Input Class Initialized
INFO - 2023-12-30 14:37:30 --> Language Class Initialized
INFO - 2023-12-30 14:37:30 --> Loader Class Initialized
INFO - 2023-12-30 14:37:30 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:30 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:30 --> Parser Class Initialized
INFO - 2023-12-30 14:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:30 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:30 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:30 --> Controller Class Initialized
INFO - 2023-12-30 14:37:30 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-30 14:37:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:30 --> Config Class Initialized
INFO - 2023-12-30 14:37:30 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:30 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:30 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:30 --> URI Class Initialized
INFO - 2023-12-30 14:37:30 --> Router Class Initialized
INFO - 2023-12-30 14:37:30 --> Output Class Initialized
INFO - 2023-12-30 14:37:30 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:30 --> Input Class Initialized
INFO - 2023-12-30 14:37:30 --> Language Class Initialized
INFO - 2023-12-30 14:37:30 --> Loader Class Initialized
INFO - 2023-12-30 14:37:30 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:30 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:30 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:30 --> Parser Class Initialized
INFO - 2023-12-30 14:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:30 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:30 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:30 --> Controller Class Initialized
INFO - 2023-12-30 14:37:30 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-30 14:37:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 14:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 14:37:30 --> Model Class Initialized
INFO - 2023-12-30 14:37:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 14:37:30 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:30 --> Total execution time: 0.0377
ERROR - 2023-12-30 14:37:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:36 --> Config Class Initialized
INFO - 2023-12-30 14:37:36 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:36 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:36 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:36 --> URI Class Initialized
INFO - 2023-12-30 14:37:36 --> Router Class Initialized
INFO - 2023-12-30 14:37:36 --> Output Class Initialized
INFO - 2023-12-30 14:37:36 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:36 --> Input Class Initialized
INFO - 2023-12-30 14:37:36 --> Language Class Initialized
INFO - 2023-12-30 14:37:36 --> Loader Class Initialized
INFO - 2023-12-30 14:37:36 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:36 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:36 --> Parser Class Initialized
INFO - 2023-12-30 14:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:36 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:36 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:36 --> Controller Class Initialized
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
INFO - 2023-12-30 14:37:36 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:36 --> Total execution time: 0.0208
ERROR - 2023-12-30 14:37:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:36 --> Config Class Initialized
INFO - 2023-12-30 14:37:36 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:36 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:36 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:36 --> URI Class Initialized
DEBUG - 2023-12-30 14:37:36 --> No URI present. Default controller set.
INFO - 2023-12-30 14:37:36 --> Router Class Initialized
INFO - 2023-12-30 14:37:36 --> Output Class Initialized
INFO - 2023-12-30 14:37:36 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:36 --> Input Class Initialized
INFO - 2023-12-30 14:37:36 --> Language Class Initialized
INFO - 2023-12-30 14:37:36 --> Loader Class Initialized
INFO - 2023-12-30 14:37:36 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:36 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:36 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:36 --> Parser Class Initialized
INFO - 2023-12-30 14:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:36 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:36 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:36 --> Controller Class Initialized
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
INFO - 2023-12-30 14:37:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 14:37:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 14:37:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 14:37:36 --> Model Class Initialized
INFO - 2023-12-30 14:37:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 14:37:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 14:37:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 14:37:36 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:36 --> Total execution time: 0.4406
ERROR - 2023-12-30 14:37:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:37 --> Config Class Initialized
INFO - 2023-12-30 14:37:37 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:37 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:37 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:37 --> URI Class Initialized
INFO - 2023-12-30 14:37:37 --> Router Class Initialized
INFO - 2023-12-30 14:37:37 --> Output Class Initialized
INFO - 2023-12-30 14:37:37 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:37 --> Input Class Initialized
INFO - 2023-12-30 14:37:37 --> Language Class Initialized
INFO - 2023-12-30 14:37:37 --> Loader Class Initialized
INFO - 2023-12-30 14:37:37 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:37 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:37 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:37 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:37 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:37 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:37 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:37 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:37 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:37 --> Parser Class Initialized
INFO - 2023-12-30 14:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:37 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:37 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:37 --> Controller Class Initialized
DEBUG - 2023-12-30 14:37:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:37:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:37 --> Model Class Initialized
INFO - 2023-12-30 14:37:37 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:37 --> Total execution time: 0.0145
ERROR - 2023-12-30 14:37:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:43 --> Config Class Initialized
INFO - 2023-12-30 14:37:43 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:43 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:43 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:43 --> URI Class Initialized
INFO - 2023-12-30 14:37:43 --> Router Class Initialized
INFO - 2023-12-30 14:37:43 --> Output Class Initialized
INFO - 2023-12-30 14:37:43 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:43 --> Input Class Initialized
INFO - 2023-12-30 14:37:43 --> Language Class Initialized
INFO - 2023-12-30 14:37:43 --> Loader Class Initialized
INFO - 2023-12-30 14:37:43 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:43 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:43 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:43 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:43 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:43 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:43 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:43 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:43 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:43 --> Parser Class Initialized
INFO - 2023-12-30 14:37:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:43 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:43 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:43 --> Controller Class Initialized
INFO - 2023-12-30 14:37:43 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:43 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:43 --> Model Class Initialized
INFO - 2023-12-30 14:37:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-30 14:37:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 14:37:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 14:37:43 --> Model Class Initialized
INFO - 2023-12-30 14:37:43 --> Model Class Initialized
INFO - 2023-12-30 14:37:43 --> Model Class Initialized
INFO - 2023-12-30 14:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 14:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 14:37:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 14:37:44 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:44 --> Total execution time: 0.2382
ERROR - 2023-12-30 14:37:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:44 --> Config Class Initialized
INFO - 2023-12-30 14:37:44 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:44 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:44 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:44 --> URI Class Initialized
INFO - 2023-12-30 14:37:44 --> Router Class Initialized
INFO - 2023-12-30 14:37:44 --> Output Class Initialized
INFO - 2023-12-30 14:37:44 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:44 --> Input Class Initialized
INFO - 2023-12-30 14:37:44 --> Language Class Initialized
INFO - 2023-12-30 14:37:44 --> Loader Class Initialized
INFO - 2023-12-30 14:37:44 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:44 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:44 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:44 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:44 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:44 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:44 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:44 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:44 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:44 --> Parser Class Initialized
INFO - 2023-12-30 14:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:44 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:44 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:44 --> Controller Class Initialized
INFO - 2023-12-30 14:37:44 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:44 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:44 --> Model Class Initialized
INFO - 2023-12-30 14:37:44 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:44 --> Total execution time: 0.0706
ERROR - 2023-12-30 14:37:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:53 --> Config Class Initialized
INFO - 2023-12-30 14:37:53 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:53 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:53 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:53 --> URI Class Initialized
INFO - 2023-12-30 14:37:53 --> Router Class Initialized
INFO - 2023-12-30 14:37:53 --> Output Class Initialized
INFO - 2023-12-30 14:37:53 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:53 --> Input Class Initialized
INFO - 2023-12-30 14:37:53 --> Language Class Initialized
INFO - 2023-12-30 14:37:53 --> Loader Class Initialized
INFO - 2023-12-30 14:37:53 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:53 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:53 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:53 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:53 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:53 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:53 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:53 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:53 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:53 --> Parser Class Initialized
INFO - 2023-12-30 14:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:53 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:53 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:53 --> Controller Class Initialized
INFO - 2023-12-30 14:37:53 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:53 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:53 --> Total execution time: 0.0144
ERROR - 2023-12-30 14:37:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:54 --> Config Class Initialized
INFO - 2023-12-30 14:37:54 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:54 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:54 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:54 --> URI Class Initialized
INFO - 2023-12-30 14:37:54 --> Router Class Initialized
INFO - 2023-12-30 14:37:54 --> Output Class Initialized
INFO - 2023-12-30 14:37:54 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:54 --> Input Class Initialized
INFO - 2023-12-30 14:37:54 --> Language Class Initialized
INFO - 2023-12-30 14:37:54 --> Loader Class Initialized
INFO - 2023-12-30 14:37:54 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:54 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:54 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:54 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:54 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:54 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:54 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:54 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:54 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:54 --> Parser Class Initialized
INFO - 2023-12-30 14:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:54 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:54 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:54 --> Controller Class Initialized
INFO - 2023-12-30 14:37:54 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-30 14:37:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 14:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 14:37:54 --> Model Class Initialized
INFO - 2023-12-30 14:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 14:37:54 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:54 --> Total execution time: 0.0352
ERROR - 2023-12-30 14:37:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:58 --> Config Class Initialized
INFO - 2023-12-30 14:37:58 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:58 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:58 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:58 --> URI Class Initialized
INFO - 2023-12-30 14:37:58 --> Router Class Initialized
INFO - 2023-12-30 14:37:58 --> Output Class Initialized
INFO - 2023-12-30 14:37:58 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:58 --> Input Class Initialized
INFO - 2023-12-30 14:37:58 --> Language Class Initialized
INFO - 2023-12-30 14:37:58 --> Loader Class Initialized
INFO - 2023-12-30 14:37:58 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:58 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:58 --> Parser Class Initialized
INFO - 2023-12-30 14:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:58 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:58 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:58 --> Controller Class Initialized
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
INFO - 2023-12-30 14:37:58 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:58 --> Total execution time: 0.0176
ERROR - 2023-12-30 14:37:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:37:58 --> Config Class Initialized
INFO - 2023-12-30 14:37:58 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:37:58 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:37:58 --> Utf8 Class Initialized
INFO - 2023-12-30 14:37:58 --> URI Class Initialized
DEBUG - 2023-12-30 14:37:58 --> No URI present. Default controller set.
INFO - 2023-12-30 14:37:58 --> Router Class Initialized
INFO - 2023-12-30 14:37:58 --> Output Class Initialized
INFO - 2023-12-30 14:37:58 --> Security Class Initialized
DEBUG - 2023-12-30 14:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:37:58 --> Input Class Initialized
INFO - 2023-12-30 14:37:58 --> Language Class Initialized
INFO - 2023-12-30 14:37:58 --> Loader Class Initialized
INFO - 2023-12-30 14:37:58 --> Helper loaded: url_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: file_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: html_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: text_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: form_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: security_helper
INFO - 2023-12-30 14:37:58 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:37:58 --> Database Driver Class Initialized
INFO - 2023-12-30 14:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:37:58 --> Parser Class Initialized
INFO - 2023-12-30 14:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:37:58 --> Pagination Class Initialized
INFO - 2023-12-30 14:37:58 --> Form Validation Class Initialized
INFO - 2023-12-30 14:37:58 --> Controller Class Initialized
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
DEBUG - 2023-12-30 14:37:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
INFO - 2023-12-30 14:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 14:37:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 14:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 14:37:58 --> Model Class Initialized
INFO - 2023-12-30 14:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 14:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 14:37:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 14:37:58 --> Final output sent to browser
DEBUG - 2023-12-30 14:37:58 --> Total execution time: 0.2385
ERROR - 2023-12-30 14:38:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:38:02 --> Config Class Initialized
INFO - 2023-12-30 14:38:02 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:38:02 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:38:02 --> Utf8 Class Initialized
INFO - 2023-12-30 14:38:02 --> URI Class Initialized
INFO - 2023-12-30 14:38:02 --> Router Class Initialized
INFO - 2023-12-30 14:38:02 --> Output Class Initialized
INFO - 2023-12-30 14:38:02 --> Security Class Initialized
DEBUG - 2023-12-30 14:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:38:02 --> Input Class Initialized
INFO - 2023-12-30 14:38:02 --> Language Class Initialized
INFO - 2023-12-30 14:38:02 --> Loader Class Initialized
INFO - 2023-12-30 14:38:02 --> Helper loaded: url_helper
INFO - 2023-12-30 14:38:02 --> Helper loaded: file_helper
INFO - 2023-12-30 14:38:02 --> Helper loaded: html_helper
INFO - 2023-12-30 14:38:02 --> Helper loaded: text_helper
INFO - 2023-12-30 14:38:02 --> Helper loaded: form_helper
INFO - 2023-12-30 14:38:02 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:38:02 --> Helper loaded: security_helper
INFO - 2023-12-30 14:38:02 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:38:02 --> Database Driver Class Initialized
INFO - 2023-12-30 14:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:38:02 --> Parser Class Initialized
INFO - 2023-12-30 14:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:38:02 --> Pagination Class Initialized
INFO - 2023-12-30 14:38:02 --> Form Validation Class Initialized
INFO - 2023-12-30 14:38:02 --> Controller Class Initialized
INFO - 2023-12-30 14:38:02 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:02 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:02 --> Model Class Initialized
INFO - 2023-12-30 14:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-30 14:38:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 14:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 14:38:02 --> Model Class Initialized
INFO - 2023-12-30 14:38:02 --> Model Class Initialized
INFO - 2023-12-30 14:38:02 --> Model Class Initialized
INFO - 2023-12-30 14:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 14:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 14:38:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 14:38:03 --> Final output sent to browser
DEBUG - 2023-12-30 14:38:03 --> Total execution time: 0.1661
ERROR - 2023-12-30 14:38:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:38:03 --> Config Class Initialized
INFO - 2023-12-30 14:38:03 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:38:03 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:38:03 --> Utf8 Class Initialized
INFO - 2023-12-30 14:38:03 --> URI Class Initialized
INFO - 2023-12-30 14:38:03 --> Router Class Initialized
INFO - 2023-12-30 14:38:03 --> Output Class Initialized
INFO - 2023-12-30 14:38:03 --> Security Class Initialized
DEBUG - 2023-12-30 14:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:38:03 --> Input Class Initialized
INFO - 2023-12-30 14:38:03 --> Language Class Initialized
INFO - 2023-12-30 14:38:03 --> Loader Class Initialized
INFO - 2023-12-30 14:38:03 --> Helper loaded: url_helper
INFO - 2023-12-30 14:38:03 --> Helper loaded: file_helper
INFO - 2023-12-30 14:38:03 --> Helper loaded: html_helper
INFO - 2023-12-30 14:38:03 --> Helper loaded: text_helper
INFO - 2023-12-30 14:38:03 --> Helper loaded: form_helper
INFO - 2023-12-30 14:38:03 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:38:03 --> Helper loaded: security_helper
INFO - 2023-12-30 14:38:03 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:38:03 --> Database Driver Class Initialized
INFO - 2023-12-30 14:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:38:03 --> Parser Class Initialized
INFO - 2023-12-30 14:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:38:03 --> Pagination Class Initialized
INFO - 2023-12-30 14:38:03 --> Form Validation Class Initialized
INFO - 2023-12-30 14:38:03 --> Controller Class Initialized
INFO - 2023-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:03 --> Model Class Initialized
INFO - 2023-12-30 14:38:03 --> Final output sent to browser
DEBUG - 2023-12-30 14:38:03 --> Total execution time: 0.0453
ERROR - 2023-12-30 14:38:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:38:13 --> Config Class Initialized
INFO - 2023-12-30 14:38:13 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:38:13 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:38:13 --> Utf8 Class Initialized
INFO - 2023-12-30 14:38:13 --> URI Class Initialized
INFO - 2023-12-30 14:38:13 --> Router Class Initialized
INFO - 2023-12-30 14:38:13 --> Output Class Initialized
INFO - 2023-12-30 14:38:13 --> Security Class Initialized
DEBUG - 2023-12-30 14:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:38:13 --> Input Class Initialized
INFO - 2023-12-30 14:38:13 --> Language Class Initialized
INFO - 2023-12-30 14:38:13 --> Loader Class Initialized
INFO - 2023-12-30 14:38:13 --> Helper loaded: url_helper
INFO - 2023-12-30 14:38:13 --> Helper loaded: file_helper
INFO - 2023-12-30 14:38:13 --> Helper loaded: html_helper
INFO - 2023-12-30 14:38:13 --> Helper loaded: text_helper
INFO - 2023-12-30 14:38:13 --> Helper loaded: form_helper
INFO - 2023-12-30 14:38:13 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:38:13 --> Helper loaded: security_helper
INFO - 2023-12-30 14:38:13 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:38:13 --> Database Driver Class Initialized
INFO - 2023-12-30 14:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:38:13 --> Parser Class Initialized
INFO - 2023-12-30 14:38:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:38:13 --> Pagination Class Initialized
INFO - 2023-12-30 14:38:13 --> Form Validation Class Initialized
INFO - 2023-12-30 14:38:13 --> Controller Class Initialized
INFO - 2023-12-30 14:38:13 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:13 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:13 --> Model Class Initialized
INFO - 2023-12-30 14:38:13 --> Final output sent to browser
DEBUG - 2023-12-30 14:38:13 --> Total execution time: 0.0529
ERROR - 2023-12-30 14:38:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:38:17 --> Config Class Initialized
INFO - 2023-12-30 14:38:17 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:38:17 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:38:17 --> Utf8 Class Initialized
INFO - 2023-12-30 14:38:17 --> URI Class Initialized
INFO - 2023-12-30 14:38:17 --> Router Class Initialized
INFO - 2023-12-30 14:38:17 --> Output Class Initialized
INFO - 2023-12-30 14:38:17 --> Security Class Initialized
DEBUG - 2023-12-30 14:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:38:17 --> Input Class Initialized
INFO - 2023-12-30 14:38:17 --> Language Class Initialized
INFO - 2023-12-30 14:38:17 --> Loader Class Initialized
INFO - 2023-12-30 14:38:17 --> Helper loaded: url_helper
INFO - 2023-12-30 14:38:17 --> Helper loaded: file_helper
INFO - 2023-12-30 14:38:17 --> Helper loaded: html_helper
INFO - 2023-12-30 14:38:17 --> Helper loaded: text_helper
INFO - 2023-12-30 14:38:17 --> Helper loaded: form_helper
INFO - 2023-12-30 14:38:17 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:38:17 --> Helper loaded: security_helper
INFO - 2023-12-30 14:38:17 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:38:17 --> Database Driver Class Initialized
INFO - 2023-12-30 14:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:38:17 --> Parser Class Initialized
INFO - 2023-12-30 14:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:38:17 --> Pagination Class Initialized
INFO - 2023-12-30 14:38:17 --> Form Validation Class Initialized
INFO - 2023-12-30 14:38:17 --> Controller Class Initialized
INFO - 2023-12-30 14:38:17 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:17 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:17 --> Model Class Initialized
INFO - 2023-12-30 14:38:17 --> Final output sent to browser
DEBUG - 2023-12-30 14:38:17 --> Total execution time: 0.0565
ERROR - 2023-12-30 14:38:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:38:24 --> Config Class Initialized
INFO - 2023-12-30 14:38:24 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:38:24 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:38:24 --> Utf8 Class Initialized
INFO - 2023-12-30 14:38:24 --> URI Class Initialized
DEBUG - 2023-12-30 14:38:24 --> No URI present. Default controller set.
INFO - 2023-12-30 14:38:24 --> Router Class Initialized
INFO - 2023-12-30 14:38:24 --> Output Class Initialized
INFO - 2023-12-30 14:38:24 --> Security Class Initialized
DEBUG - 2023-12-30 14:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:38:24 --> Input Class Initialized
INFO - 2023-12-30 14:38:24 --> Language Class Initialized
INFO - 2023-12-30 14:38:24 --> Loader Class Initialized
INFO - 2023-12-30 14:38:24 --> Helper loaded: url_helper
INFO - 2023-12-30 14:38:24 --> Helper loaded: file_helper
INFO - 2023-12-30 14:38:24 --> Helper loaded: html_helper
INFO - 2023-12-30 14:38:24 --> Helper loaded: text_helper
INFO - 2023-12-30 14:38:24 --> Helper loaded: form_helper
INFO - 2023-12-30 14:38:24 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:38:24 --> Helper loaded: security_helper
INFO - 2023-12-30 14:38:24 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:38:24 --> Database Driver Class Initialized
INFO - 2023-12-30 14:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:38:24 --> Parser Class Initialized
INFO - 2023-12-30 14:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:38:24 --> Pagination Class Initialized
INFO - 2023-12-30 14:38:24 --> Form Validation Class Initialized
INFO - 2023-12-30 14:38:24 --> Controller Class Initialized
INFO - 2023-12-30 14:38:24 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:24 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:24 --> Model Class Initialized
INFO - 2023-12-30 14:38:24 --> Model Class Initialized
INFO - 2023-12-30 14:38:24 --> Model Class Initialized
INFO - 2023-12-30 14:38:24 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-30 14:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:24 --> Model Class Initialized
INFO - 2023-12-30 14:38:24 --> Model Class Initialized
INFO - 2023-12-30 14:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-30 14:38:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 14:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 14:38:24 --> Model Class Initialized
INFO - 2023-12-30 14:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-30 14:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-30 14:38:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 14:38:24 --> Final output sent to browser
DEBUG - 2023-12-30 14:38:24 --> Total execution time: 0.2370
ERROR - 2023-12-30 14:38:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:38:40 --> Config Class Initialized
INFO - 2023-12-30 14:38:40 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:38:40 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:38:40 --> Utf8 Class Initialized
INFO - 2023-12-30 14:38:40 --> URI Class Initialized
INFO - 2023-12-30 14:38:40 --> Router Class Initialized
INFO - 2023-12-30 14:38:40 --> Output Class Initialized
INFO - 2023-12-30 14:38:40 --> Security Class Initialized
DEBUG - 2023-12-30 14:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:38:40 --> Input Class Initialized
INFO - 2023-12-30 14:38:40 --> Language Class Initialized
INFO - 2023-12-30 14:38:40 --> Loader Class Initialized
INFO - 2023-12-30 14:38:40 --> Helper loaded: url_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: file_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: html_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: text_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: form_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: security_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:38:40 --> Database Driver Class Initialized
INFO - 2023-12-30 14:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:38:40 --> Parser Class Initialized
INFO - 2023-12-30 14:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:38:40 --> Pagination Class Initialized
INFO - 2023-12-30 14:38:40 --> Form Validation Class Initialized
INFO - 2023-12-30 14:38:40 --> Controller Class Initialized
INFO - 2023-12-30 14:38:40 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:40 --> Final output sent to browser
DEBUG - 2023-12-30 14:38:40 --> Total execution time: 0.0171
ERROR - 2023-12-30 14:38:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 14:38:40 --> Config Class Initialized
INFO - 2023-12-30 14:38:40 --> Hooks Class Initialized
DEBUG - 2023-12-30 14:38:40 --> UTF-8 Support Enabled
INFO - 2023-12-30 14:38:40 --> Utf8 Class Initialized
INFO - 2023-12-30 14:38:40 --> URI Class Initialized
INFO - 2023-12-30 14:38:40 --> Router Class Initialized
INFO - 2023-12-30 14:38:40 --> Output Class Initialized
INFO - 2023-12-30 14:38:40 --> Security Class Initialized
DEBUG - 2023-12-30 14:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 14:38:40 --> Input Class Initialized
INFO - 2023-12-30 14:38:40 --> Language Class Initialized
INFO - 2023-12-30 14:38:40 --> Loader Class Initialized
INFO - 2023-12-30 14:38:40 --> Helper loaded: url_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: file_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: html_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: text_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: form_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: lang_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: security_helper
INFO - 2023-12-30 14:38:40 --> Helper loaded: cookie_helper
INFO - 2023-12-30 14:38:40 --> Database Driver Class Initialized
INFO - 2023-12-30 14:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 14:38:40 --> Parser Class Initialized
INFO - 2023-12-30 14:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 14:38:40 --> Pagination Class Initialized
INFO - 2023-12-30 14:38:40 --> Form Validation Class Initialized
INFO - 2023-12-30 14:38:40 --> Controller Class Initialized
INFO - 2023-12-30 14:38:40 --> Model Class Initialized
DEBUG - 2023-12-30 14:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-30 14:38:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-30 14:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-30 14:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-30 14:38:40 --> Model Class Initialized
INFO - 2023-12-30 14:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-30 14:38:40 --> Final output sent to browser
DEBUG - 2023-12-30 14:38:40 --> Total execution time: 0.0335
ERROR - 2023-12-30 17:44:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 17:44:58 --> Config Class Initialized
INFO - 2023-12-30 17:44:58 --> Hooks Class Initialized
DEBUG - 2023-12-30 17:44:58 --> UTF-8 Support Enabled
INFO - 2023-12-30 17:44:58 --> Utf8 Class Initialized
INFO - 2023-12-30 17:44:58 --> URI Class Initialized
DEBUG - 2023-12-30 17:44:58 --> No URI present. Default controller set.
INFO - 2023-12-30 17:44:58 --> Router Class Initialized
INFO - 2023-12-30 17:44:58 --> Output Class Initialized
INFO - 2023-12-30 17:44:58 --> Security Class Initialized
DEBUG - 2023-12-30 17:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 17:44:58 --> Input Class Initialized
INFO - 2023-12-30 17:44:58 --> Language Class Initialized
INFO - 2023-12-30 17:44:58 --> Loader Class Initialized
INFO - 2023-12-30 17:44:58 --> Helper loaded: url_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: file_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: html_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: text_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: form_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: lang_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: security_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: cookie_helper
INFO - 2023-12-30 17:44:58 --> Database Driver Class Initialized
INFO - 2023-12-30 17:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 17:44:58 --> Parser Class Initialized
INFO - 2023-12-30 17:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 17:44:58 --> Pagination Class Initialized
INFO - 2023-12-30 17:44:58 --> Form Validation Class Initialized
INFO - 2023-12-30 17:44:58 --> Controller Class Initialized
INFO - 2023-12-30 17:44:58 --> Model Class Initialized
DEBUG - 2023-12-30 17:44:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-30 17:44:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 17:44:58 --> Config Class Initialized
INFO - 2023-12-30 17:44:58 --> Hooks Class Initialized
DEBUG - 2023-12-30 17:44:58 --> UTF-8 Support Enabled
INFO - 2023-12-30 17:44:58 --> Utf8 Class Initialized
INFO - 2023-12-30 17:44:58 --> URI Class Initialized
DEBUG - 2023-12-30 17:44:58 --> No URI present. Default controller set.
INFO - 2023-12-30 17:44:58 --> Router Class Initialized
INFO - 2023-12-30 17:44:58 --> Output Class Initialized
INFO - 2023-12-30 17:44:58 --> Security Class Initialized
DEBUG - 2023-12-30 17:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 17:44:58 --> Input Class Initialized
INFO - 2023-12-30 17:44:58 --> Language Class Initialized
INFO - 2023-12-30 17:44:58 --> Loader Class Initialized
INFO - 2023-12-30 17:44:58 --> Helper loaded: url_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: file_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: html_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: text_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: form_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: lang_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: security_helper
INFO - 2023-12-30 17:44:58 --> Helper loaded: cookie_helper
INFO - 2023-12-30 17:44:58 --> Database Driver Class Initialized
INFO - 2023-12-30 17:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 17:44:58 --> Parser Class Initialized
INFO - 2023-12-30 17:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 17:44:58 --> Pagination Class Initialized
INFO - 2023-12-30 17:44:58 --> Form Validation Class Initialized
INFO - 2023-12-30 17:44:58 --> Controller Class Initialized
INFO - 2023-12-30 17:44:58 --> Model Class Initialized
DEBUG - 2023-12-30 17:44:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-30 17:44:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 17:44:59 --> Config Class Initialized
INFO - 2023-12-30 17:44:59 --> Hooks Class Initialized
DEBUG - 2023-12-30 17:44:59 --> UTF-8 Support Enabled
INFO - 2023-12-30 17:44:59 --> Utf8 Class Initialized
INFO - 2023-12-30 17:44:59 --> URI Class Initialized
DEBUG - 2023-12-30 17:44:59 --> No URI present. Default controller set.
INFO - 2023-12-30 17:44:59 --> Router Class Initialized
INFO - 2023-12-30 17:44:59 --> Output Class Initialized
INFO - 2023-12-30 17:44:59 --> Security Class Initialized
DEBUG - 2023-12-30 17:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 17:44:59 --> Input Class Initialized
INFO - 2023-12-30 17:44:59 --> Language Class Initialized
INFO - 2023-12-30 17:44:59 --> Loader Class Initialized
INFO - 2023-12-30 17:44:59 --> Helper loaded: url_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: file_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: html_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: text_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: form_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: lang_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: security_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: cookie_helper
INFO - 2023-12-30 17:44:59 --> Database Driver Class Initialized
INFO - 2023-12-30 17:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 17:44:59 --> Parser Class Initialized
INFO - 2023-12-30 17:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 17:44:59 --> Pagination Class Initialized
INFO - 2023-12-30 17:44:59 --> Form Validation Class Initialized
INFO - 2023-12-30 17:44:59 --> Controller Class Initialized
INFO - 2023-12-30 17:44:59 --> Model Class Initialized
DEBUG - 2023-12-30 17:44:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-30 17:44:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-30 17:44:59 --> Config Class Initialized
INFO - 2023-12-30 17:44:59 --> Hooks Class Initialized
DEBUG - 2023-12-30 17:44:59 --> UTF-8 Support Enabled
INFO - 2023-12-30 17:44:59 --> Utf8 Class Initialized
INFO - 2023-12-30 17:44:59 --> URI Class Initialized
DEBUG - 2023-12-30 17:44:59 --> No URI present. Default controller set.
INFO - 2023-12-30 17:44:59 --> Router Class Initialized
INFO - 2023-12-30 17:44:59 --> Output Class Initialized
INFO - 2023-12-30 17:44:59 --> Security Class Initialized
DEBUG - 2023-12-30 17:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 17:44:59 --> Input Class Initialized
INFO - 2023-12-30 17:44:59 --> Language Class Initialized
INFO - 2023-12-30 17:44:59 --> Loader Class Initialized
INFO - 2023-12-30 17:44:59 --> Helper loaded: url_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: file_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: html_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: text_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: form_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: lang_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: security_helper
INFO - 2023-12-30 17:44:59 --> Helper loaded: cookie_helper
INFO - 2023-12-30 17:44:59 --> Database Driver Class Initialized
INFO - 2023-12-30 17:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 17:44:59 --> Parser Class Initialized
INFO - 2023-12-30 17:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-30 17:44:59 --> Pagination Class Initialized
INFO - 2023-12-30 17:44:59 --> Form Validation Class Initialized
INFO - 2023-12-30 17:44:59 --> Controller Class Initialized
INFO - 2023-12-30 17:44:59 --> Model Class Initialized
DEBUG - 2023-12-30 17:44:59 --> Session class already loaded. Second attempt ignored.
