<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-31 02:31:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:31:54 --> Config Class Initialized
INFO - 2024-03-31 02:31:54 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:31:54 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:31:54 --> Utf8 Class Initialized
INFO - 2024-03-31 02:31:54 --> URI Class Initialized
DEBUG - 2024-03-31 02:31:54 --> No URI present. Default controller set.
INFO - 2024-03-31 02:31:54 --> Router Class Initialized
INFO - 2024-03-31 02:31:54 --> Output Class Initialized
INFO - 2024-03-31 02:31:54 --> Security Class Initialized
DEBUG - 2024-03-31 02:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:31:54 --> Input Class Initialized
INFO - 2024-03-31 02:31:54 --> Language Class Initialized
INFO - 2024-03-31 02:31:54 --> Loader Class Initialized
INFO - 2024-03-31 02:31:54 --> Helper loaded: url_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: file_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: html_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: text_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: form_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: security_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:31:54 --> Database Driver Class Initialized
INFO - 2024-03-31 02:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:31:54 --> Parser Class Initialized
INFO - 2024-03-31 02:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:31:54 --> Pagination Class Initialized
INFO - 2024-03-31 02:31:54 --> Form Validation Class Initialized
INFO - 2024-03-31 02:31:54 --> Controller Class Initialized
INFO - 2024-03-31 02:31:54 --> Model Class Initialized
DEBUG - 2024-03-31 02:31:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-31 02:31:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:31:54 --> Config Class Initialized
INFO - 2024-03-31 02:31:54 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:31:54 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:31:54 --> Utf8 Class Initialized
INFO - 2024-03-31 02:31:54 --> URI Class Initialized
INFO - 2024-03-31 02:31:54 --> Router Class Initialized
INFO - 2024-03-31 02:31:54 --> Output Class Initialized
INFO - 2024-03-31 02:31:54 --> Security Class Initialized
DEBUG - 2024-03-31 02:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:31:54 --> Input Class Initialized
INFO - 2024-03-31 02:31:54 --> Language Class Initialized
INFO - 2024-03-31 02:31:54 --> Loader Class Initialized
INFO - 2024-03-31 02:31:54 --> Helper loaded: url_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: file_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: html_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: text_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: form_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: security_helper
INFO - 2024-03-31 02:31:54 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:31:54 --> Database Driver Class Initialized
INFO - 2024-03-31 02:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:31:54 --> Parser Class Initialized
INFO - 2024-03-31 02:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:31:54 --> Pagination Class Initialized
INFO - 2024-03-31 02:31:54 --> Form Validation Class Initialized
INFO - 2024-03-31 02:31:54 --> Controller Class Initialized
INFO - 2024-03-31 02:31:54 --> Model Class Initialized
DEBUG - 2024-03-31 02:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-31 02:31:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 02:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 02:31:54 --> Model Class Initialized
INFO - 2024-03-31 02:31:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 02:31:54 --> Final output sent to browser
DEBUG - 2024-03-31 02:31:54 --> Total execution time: 0.0351
ERROR - 2024-03-31 02:32:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:32:05 --> Config Class Initialized
INFO - 2024-03-31 02:32:05 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:32:05 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:32:05 --> Utf8 Class Initialized
INFO - 2024-03-31 02:32:05 --> URI Class Initialized
INFO - 2024-03-31 02:32:05 --> Router Class Initialized
INFO - 2024-03-31 02:32:05 --> Output Class Initialized
INFO - 2024-03-31 02:32:05 --> Security Class Initialized
DEBUG - 2024-03-31 02:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:32:05 --> Input Class Initialized
INFO - 2024-03-31 02:32:05 --> Language Class Initialized
INFO - 2024-03-31 02:32:05 --> Loader Class Initialized
INFO - 2024-03-31 02:32:05 --> Helper loaded: url_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: file_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: html_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: text_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: form_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: security_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:32:05 --> Database Driver Class Initialized
INFO - 2024-03-31 02:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:32:05 --> Parser Class Initialized
INFO - 2024-03-31 02:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:32:05 --> Pagination Class Initialized
INFO - 2024-03-31 02:32:05 --> Form Validation Class Initialized
INFO - 2024-03-31 02:32:05 --> Controller Class Initialized
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
INFO - 2024-03-31 02:32:05 --> Final output sent to browser
DEBUG - 2024-03-31 02:32:05 --> Total execution time: 0.0235
ERROR - 2024-03-31 02:32:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:32:05 --> Config Class Initialized
INFO - 2024-03-31 02:32:05 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:32:05 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:32:05 --> Utf8 Class Initialized
INFO - 2024-03-31 02:32:05 --> URI Class Initialized
DEBUG - 2024-03-31 02:32:05 --> No URI present. Default controller set.
INFO - 2024-03-31 02:32:05 --> Router Class Initialized
INFO - 2024-03-31 02:32:05 --> Output Class Initialized
INFO - 2024-03-31 02:32:05 --> Security Class Initialized
DEBUG - 2024-03-31 02:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:32:05 --> Input Class Initialized
INFO - 2024-03-31 02:32:05 --> Language Class Initialized
INFO - 2024-03-31 02:32:05 --> Loader Class Initialized
INFO - 2024-03-31 02:32:05 --> Helper loaded: url_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: file_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: html_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: text_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: form_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: security_helper
INFO - 2024-03-31 02:32:05 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:32:05 --> Database Driver Class Initialized
INFO - 2024-03-31 02:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:32:05 --> Parser Class Initialized
INFO - 2024-03-31 02:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:32:05 --> Pagination Class Initialized
INFO - 2024-03-31 02:32:05 --> Form Validation Class Initialized
INFO - 2024-03-31 02:32:05 --> Controller Class Initialized
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 02:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
INFO - 2024-03-31 02:32:05 --> Model Class Initialized
INFO - 2024-03-31 02:32:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-31 02:32:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 02:32:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 02:32:06 --> Model Class Initialized
INFO - 2024-03-31 02:32:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 02:32:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 02:32:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 02:32:06 --> Final output sent to browser
DEBUG - 2024-03-31 02:32:06 --> Total execution time: 0.2594
ERROR - 2024-03-31 02:32:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:32:11 --> Config Class Initialized
INFO - 2024-03-31 02:32:11 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:32:11 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:32:11 --> Utf8 Class Initialized
INFO - 2024-03-31 02:32:11 --> URI Class Initialized
INFO - 2024-03-31 02:32:11 --> Router Class Initialized
INFO - 2024-03-31 02:32:11 --> Output Class Initialized
INFO - 2024-03-31 02:32:11 --> Security Class Initialized
DEBUG - 2024-03-31 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:32:11 --> Input Class Initialized
INFO - 2024-03-31 02:32:11 --> Language Class Initialized
INFO - 2024-03-31 02:32:11 --> Loader Class Initialized
INFO - 2024-03-31 02:32:11 --> Helper loaded: url_helper
INFO - 2024-03-31 02:32:11 --> Helper loaded: file_helper
INFO - 2024-03-31 02:32:11 --> Helper loaded: html_helper
INFO - 2024-03-31 02:32:11 --> Helper loaded: text_helper
INFO - 2024-03-31 02:32:11 --> Helper loaded: form_helper
INFO - 2024-03-31 02:32:11 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:32:11 --> Helper loaded: security_helper
INFO - 2024-03-31 02:32:11 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:32:11 --> Database Driver Class Initialized
INFO - 2024-03-31 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:32:11 --> Parser Class Initialized
INFO - 2024-03-31 02:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:32:11 --> Pagination Class Initialized
INFO - 2024-03-31 02:32:11 --> Form Validation Class Initialized
INFO - 2024-03-31 02:32:11 --> Controller Class Initialized
DEBUG - 2024-03-31 02:32:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 02:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:11 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:11 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:11 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:11 --> Model Class Initialized
INFO - 2024-03-31 02:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-31 02:32:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 02:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 02:32:11 --> Model Class Initialized
INFO - 2024-03-31 02:32:11 --> Model Class Initialized
INFO - 2024-03-31 02:32:11 --> Model Class Initialized
INFO - 2024-03-31 02:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 02:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 02:32:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 02:32:11 --> Final output sent to browser
DEBUG - 2024-03-31 02:32:11 --> Total execution time: 0.1684
ERROR - 2024-03-31 02:32:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:32:12 --> Config Class Initialized
INFO - 2024-03-31 02:32:12 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:32:12 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:32:12 --> Utf8 Class Initialized
INFO - 2024-03-31 02:32:12 --> URI Class Initialized
INFO - 2024-03-31 02:32:12 --> Router Class Initialized
INFO - 2024-03-31 02:32:12 --> Output Class Initialized
INFO - 2024-03-31 02:32:12 --> Security Class Initialized
DEBUG - 2024-03-31 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:32:12 --> Input Class Initialized
INFO - 2024-03-31 02:32:12 --> Language Class Initialized
INFO - 2024-03-31 02:32:12 --> Loader Class Initialized
INFO - 2024-03-31 02:32:12 --> Helper loaded: url_helper
INFO - 2024-03-31 02:32:12 --> Helper loaded: file_helper
INFO - 2024-03-31 02:32:12 --> Helper loaded: html_helper
INFO - 2024-03-31 02:32:12 --> Helper loaded: text_helper
INFO - 2024-03-31 02:32:12 --> Helper loaded: form_helper
INFO - 2024-03-31 02:32:12 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:32:12 --> Helper loaded: security_helper
INFO - 2024-03-31 02:32:12 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:32:12 --> Database Driver Class Initialized
INFO - 2024-03-31 02:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:32:12 --> Parser Class Initialized
INFO - 2024-03-31 02:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:32:12 --> Pagination Class Initialized
INFO - 2024-03-31 02:32:12 --> Form Validation Class Initialized
INFO - 2024-03-31 02:32:12 --> Controller Class Initialized
DEBUG - 2024-03-31 02:32:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 02:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:12 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:12 --> Model Class Initialized
INFO - 2024-03-31 02:32:12 --> Final output sent to browser
DEBUG - 2024-03-31 02:32:12 --> Total execution time: 0.0231
ERROR - 2024-03-31 02:32:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:32:14 --> Config Class Initialized
INFO - 2024-03-31 02:32:14 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:32:14 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:32:14 --> Utf8 Class Initialized
INFO - 2024-03-31 02:32:14 --> URI Class Initialized
DEBUG - 2024-03-31 02:32:14 --> No URI present. Default controller set.
INFO - 2024-03-31 02:32:14 --> Router Class Initialized
INFO - 2024-03-31 02:32:14 --> Output Class Initialized
INFO - 2024-03-31 02:32:14 --> Security Class Initialized
DEBUG - 2024-03-31 02:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:32:14 --> Input Class Initialized
INFO - 2024-03-31 02:32:14 --> Language Class Initialized
INFO - 2024-03-31 02:32:14 --> Loader Class Initialized
INFO - 2024-03-31 02:32:14 --> Helper loaded: url_helper
INFO - 2024-03-31 02:32:14 --> Helper loaded: file_helper
INFO - 2024-03-31 02:32:14 --> Helper loaded: html_helper
INFO - 2024-03-31 02:32:14 --> Helper loaded: text_helper
INFO - 2024-03-31 02:32:14 --> Helper loaded: form_helper
INFO - 2024-03-31 02:32:14 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:32:14 --> Helper loaded: security_helper
INFO - 2024-03-31 02:32:14 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:32:14 --> Database Driver Class Initialized
INFO - 2024-03-31 02:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:32:14 --> Parser Class Initialized
INFO - 2024-03-31 02:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:32:14 --> Pagination Class Initialized
INFO - 2024-03-31 02:32:14 --> Form Validation Class Initialized
INFO - 2024-03-31 02:32:14 --> Controller Class Initialized
INFO - 2024-03-31 02:32:14 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:14 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:14 --> Model Class Initialized
INFO - 2024-03-31 02:32:14 --> Model Class Initialized
INFO - 2024-03-31 02:32:14 --> Model Class Initialized
INFO - 2024-03-31 02:32:14 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 02:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:14 --> Model Class Initialized
INFO - 2024-03-31 02:32:14 --> Model Class Initialized
INFO - 2024-03-31 02:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-31 02:32:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 02:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 02:32:14 --> Model Class Initialized
INFO - 2024-03-31 02:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 02:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 02:32:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 02:32:14 --> Final output sent to browser
DEBUG - 2024-03-31 02:32:14 --> Total execution time: 0.2566
ERROR - 2024-03-31 02:32:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:32:19 --> Config Class Initialized
INFO - 2024-03-31 02:32:19 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:32:19 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:32:19 --> Utf8 Class Initialized
INFO - 2024-03-31 02:32:19 --> URI Class Initialized
INFO - 2024-03-31 02:32:19 --> Router Class Initialized
INFO - 2024-03-31 02:32:19 --> Output Class Initialized
INFO - 2024-03-31 02:32:19 --> Security Class Initialized
DEBUG - 2024-03-31 02:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:32:19 --> Input Class Initialized
INFO - 2024-03-31 02:32:19 --> Language Class Initialized
INFO - 2024-03-31 02:32:19 --> Loader Class Initialized
INFO - 2024-03-31 02:32:19 --> Helper loaded: url_helper
INFO - 2024-03-31 02:32:19 --> Helper loaded: file_helper
INFO - 2024-03-31 02:32:19 --> Helper loaded: html_helper
INFO - 2024-03-31 02:32:19 --> Helper loaded: text_helper
INFO - 2024-03-31 02:32:19 --> Helper loaded: form_helper
INFO - 2024-03-31 02:32:19 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:32:19 --> Helper loaded: security_helper
INFO - 2024-03-31 02:32:19 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:32:19 --> Database Driver Class Initialized
INFO - 2024-03-31 02:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:32:19 --> Parser Class Initialized
INFO - 2024-03-31 02:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:32:19 --> Pagination Class Initialized
INFO - 2024-03-31 02:32:19 --> Form Validation Class Initialized
INFO - 2024-03-31 02:32:19 --> Controller Class Initialized
INFO - 2024-03-31 02:32:19 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 02:32:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:19 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:19 --> Model Class Initialized
INFO - 2024-03-31 02:32:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-31 02:32:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 02:32:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 02:32:19 --> Model Class Initialized
INFO - 2024-03-31 02:32:19 --> Model Class Initialized
INFO - 2024-03-31 02:32:19 --> Model Class Initialized
INFO - 2024-03-31 02:32:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 02:32:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 02:32:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 02:32:20 --> Final output sent to browser
DEBUG - 2024-03-31 02:32:20 --> Total execution time: 0.1603
ERROR - 2024-03-31 02:32:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:32:20 --> Config Class Initialized
INFO - 2024-03-31 02:32:20 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:32:20 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:32:20 --> Utf8 Class Initialized
INFO - 2024-03-31 02:32:20 --> URI Class Initialized
INFO - 2024-03-31 02:32:20 --> Router Class Initialized
INFO - 2024-03-31 02:32:20 --> Output Class Initialized
INFO - 2024-03-31 02:32:20 --> Security Class Initialized
DEBUG - 2024-03-31 02:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:32:20 --> Input Class Initialized
INFO - 2024-03-31 02:32:20 --> Language Class Initialized
INFO - 2024-03-31 02:32:20 --> Loader Class Initialized
INFO - 2024-03-31 02:32:20 --> Helper loaded: url_helper
INFO - 2024-03-31 02:32:20 --> Helper loaded: file_helper
INFO - 2024-03-31 02:32:20 --> Helper loaded: html_helper
INFO - 2024-03-31 02:32:20 --> Helper loaded: text_helper
INFO - 2024-03-31 02:32:20 --> Helper loaded: form_helper
INFO - 2024-03-31 02:32:20 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:32:20 --> Helper loaded: security_helper
INFO - 2024-03-31 02:32:20 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:32:20 --> Database Driver Class Initialized
INFO - 2024-03-31 02:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:32:20 --> Parser Class Initialized
INFO - 2024-03-31 02:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:32:20 --> Pagination Class Initialized
INFO - 2024-03-31 02:32:20 --> Form Validation Class Initialized
INFO - 2024-03-31 02:32:20 --> Controller Class Initialized
INFO - 2024-03-31 02:32:20 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 02:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:20 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:20 --> Model Class Initialized
INFO - 2024-03-31 02:32:20 --> Final output sent to browser
DEBUG - 2024-03-31 02:32:20 --> Total execution time: 0.0420
ERROR - 2024-03-31 02:32:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 02:32:28 --> Config Class Initialized
INFO - 2024-03-31 02:32:28 --> Hooks Class Initialized
DEBUG - 2024-03-31 02:32:28 --> UTF-8 Support Enabled
INFO - 2024-03-31 02:32:28 --> Utf8 Class Initialized
INFO - 2024-03-31 02:32:28 --> URI Class Initialized
INFO - 2024-03-31 02:32:28 --> Router Class Initialized
INFO - 2024-03-31 02:32:28 --> Output Class Initialized
INFO - 2024-03-31 02:32:28 --> Security Class Initialized
DEBUG - 2024-03-31 02:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 02:32:28 --> Input Class Initialized
INFO - 2024-03-31 02:32:28 --> Language Class Initialized
INFO - 2024-03-31 02:32:28 --> Loader Class Initialized
INFO - 2024-03-31 02:32:28 --> Helper loaded: url_helper
INFO - 2024-03-31 02:32:28 --> Helper loaded: file_helper
INFO - 2024-03-31 02:32:28 --> Helper loaded: html_helper
INFO - 2024-03-31 02:32:28 --> Helper loaded: text_helper
INFO - 2024-03-31 02:32:28 --> Helper loaded: form_helper
INFO - 2024-03-31 02:32:28 --> Helper loaded: lang_helper
INFO - 2024-03-31 02:32:28 --> Helper loaded: security_helper
INFO - 2024-03-31 02:32:28 --> Helper loaded: cookie_helper
INFO - 2024-03-31 02:32:28 --> Database Driver Class Initialized
INFO - 2024-03-31 02:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 02:32:28 --> Parser Class Initialized
INFO - 2024-03-31 02:32:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 02:32:28 --> Pagination Class Initialized
INFO - 2024-03-31 02:32:28 --> Form Validation Class Initialized
INFO - 2024-03-31 02:32:28 --> Controller Class Initialized
INFO - 2024-03-31 02:32:28 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 02:32:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:28 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:28 --> Model Class Initialized
DEBUG - 2024-03-31 02:32:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-31 02:32:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 02:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 02:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 02:32:28 --> Model Class Initialized
INFO - 2024-03-31 02:32:28 --> Model Class Initialized
INFO - 2024-03-31 02:32:28 --> Model Class Initialized
INFO - 2024-03-31 02:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 02:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 02:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 02:32:28 --> Final output sent to browser
DEBUG - 2024-03-31 02:32:28 --> Total execution time: 0.1759
ERROR - 2024-03-31 04:16:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:16:44 --> Config Class Initialized
INFO - 2024-03-31 04:16:44 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:16:44 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:16:44 --> Utf8 Class Initialized
INFO - 2024-03-31 04:16:44 --> URI Class Initialized
DEBUG - 2024-03-31 04:16:44 --> No URI present. Default controller set.
INFO - 2024-03-31 04:16:44 --> Router Class Initialized
INFO - 2024-03-31 04:16:44 --> Output Class Initialized
INFO - 2024-03-31 04:16:44 --> Security Class Initialized
DEBUG - 2024-03-31 04:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:16:44 --> Input Class Initialized
INFO - 2024-03-31 04:16:44 --> Language Class Initialized
INFO - 2024-03-31 04:16:44 --> Loader Class Initialized
INFO - 2024-03-31 04:16:44 --> Helper loaded: url_helper
INFO - 2024-03-31 04:16:44 --> Helper loaded: file_helper
INFO - 2024-03-31 04:16:44 --> Helper loaded: html_helper
INFO - 2024-03-31 04:16:44 --> Helper loaded: text_helper
INFO - 2024-03-31 04:16:44 --> Helper loaded: form_helper
INFO - 2024-03-31 04:16:44 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:16:44 --> Helper loaded: security_helper
INFO - 2024-03-31 04:16:44 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:16:44 --> Database Driver Class Initialized
INFO - 2024-03-31 04:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:16:44 --> Parser Class Initialized
INFO - 2024-03-31 04:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:16:44 --> Pagination Class Initialized
INFO - 2024-03-31 04:16:44 --> Form Validation Class Initialized
INFO - 2024-03-31 04:16:44 --> Controller Class Initialized
INFO - 2024-03-31 04:16:44 --> Model Class Initialized
DEBUG - 2024-03-31 04:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:44 --> Model Class Initialized
DEBUG - 2024-03-31 04:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:44 --> Model Class Initialized
INFO - 2024-03-31 04:16:44 --> Model Class Initialized
INFO - 2024-03-31 04:16:44 --> Model Class Initialized
INFO - 2024-03-31 04:16:44 --> Model Class Initialized
DEBUG - 2024-03-31 04:16:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:44 --> Model Class Initialized
INFO - 2024-03-31 04:16:44 --> Model Class Initialized
INFO - 2024-03-31 04:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-31 04:16:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:16:45 --> Model Class Initialized
INFO - 2024-03-31 04:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:16:45 --> Final output sent to browser
DEBUG - 2024-03-31 04:16:45 --> Total execution time: 0.2683
ERROR - 2024-03-31 04:16:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:16:51 --> Config Class Initialized
INFO - 2024-03-31 04:16:51 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:16:51 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:16:51 --> Utf8 Class Initialized
INFO - 2024-03-31 04:16:51 --> URI Class Initialized
INFO - 2024-03-31 04:16:51 --> Router Class Initialized
INFO - 2024-03-31 04:16:51 --> Output Class Initialized
INFO - 2024-03-31 04:16:51 --> Security Class Initialized
DEBUG - 2024-03-31 04:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:16:51 --> Input Class Initialized
INFO - 2024-03-31 04:16:51 --> Language Class Initialized
INFO - 2024-03-31 04:16:51 --> Loader Class Initialized
INFO - 2024-03-31 04:16:51 --> Helper loaded: url_helper
INFO - 2024-03-31 04:16:51 --> Helper loaded: file_helper
INFO - 2024-03-31 04:16:51 --> Helper loaded: html_helper
INFO - 2024-03-31 04:16:51 --> Helper loaded: text_helper
INFO - 2024-03-31 04:16:51 --> Helper loaded: form_helper
INFO - 2024-03-31 04:16:51 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:16:51 --> Helper loaded: security_helper
INFO - 2024-03-31 04:16:51 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:16:51 --> Database Driver Class Initialized
INFO - 2024-03-31 04:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:16:51 --> Parser Class Initialized
INFO - 2024-03-31 04:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:16:51 --> Pagination Class Initialized
INFO - 2024-03-31 04:16:51 --> Form Validation Class Initialized
INFO - 2024-03-31 04:16:51 --> Controller Class Initialized
INFO - 2024-03-31 04:16:51 --> Model Class Initialized
DEBUG - 2024-03-31 04:16:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:51 --> Model Class Initialized
DEBUG - 2024-03-31 04:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:51 --> Model Class Initialized
INFO - 2024-03-31 04:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-31 04:16:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:16:51 --> Model Class Initialized
INFO - 2024-03-31 04:16:51 --> Model Class Initialized
INFO - 2024-03-31 04:16:51 --> Model Class Initialized
INFO - 2024-03-31 04:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:16:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:16:51 --> Final output sent to browser
DEBUG - 2024-03-31 04:16:51 --> Total execution time: 0.1765
ERROR - 2024-03-31 04:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:16:52 --> Config Class Initialized
INFO - 2024-03-31 04:16:52 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:16:52 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:16:52 --> Utf8 Class Initialized
INFO - 2024-03-31 04:16:52 --> URI Class Initialized
INFO - 2024-03-31 04:16:52 --> Router Class Initialized
INFO - 2024-03-31 04:16:52 --> Output Class Initialized
INFO - 2024-03-31 04:16:52 --> Security Class Initialized
DEBUG - 2024-03-31 04:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:16:52 --> Input Class Initialized
INFO - 2024-03-31 04:16:52 --> Language Class Initialized
INFO - 2024-03-31 04:16:52 --> Loader Class Initialized
INFO - 2024-03-31 04:16:52 --> Helper loaded: url_helper
INFO - 2024-03-31 04:16:52 --> Helper loaded: file_helper
INFO - 2024-03-31 04:16:52 --> Helper loaded: html_helper
INFO - 2024-03-31 04:16:52 --> Helper loaded: text_helper
INFO - 2024-03-31 04:16:52 --> Helper loaded: form_helper
INFO - 2024-03-31 04:16:52 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:16:52 --> Helper loaded: security_helper
INFO - 2024-03-31 04:16:52 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:16:52 --> Database Driver Class Initialized
INFO - 2024-03-31 04:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:16:52 --> Parser Class Initialized
INFO - 2024-03-31 04:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:16:52 --> Pagination Class Initialized
INFO - 2024-03-31 04:16:52 --> Form Validation Class Initialized
INFO - 2024-03-31 04:16:52 --> Controller Class Initialized
INFO - 2024-03-31 04:16:52 --> Model Class Initialized
DEBUG - 2024-03-31 04:16:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:52 --> Model Class Initialized
DEBUG - 2024-03-31 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:52 --> Model Class Initialized
INFO - 2024-03-31 04:16:52 --> Final output sent to browser
DEBUG - 2024-03-31 04:16:52 --> Total execution time: 0.0445
ERROR - 2024-03-31 04:16:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:16:57 --> Config Class Initialized
INFO - 2024-03-31 04:16:57 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:16:57 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:16:57 --> Utf8 Class Initialized
INFO - 2024-03-31 04:16:57 --> URI Class Initialized
INFO - 2024-03-31 04:16:57 --> Router Class Initialized
INFO - 2024-03-31 04:16:57 --> Output Class Initialized
INFO - 2024-03-31 04:16:57 --> Security Class Initialized
DEBUG - 2024-03-31 04:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:16:57 --> Input Class Initialized
INFO - 2024-03-31 04:16:57 --> Language Class Initialized
INFO - 2024-03-31 04:16:57 --> Loader Class Initialized
INFO - 2024-03-31 04:16:57 --> Helper loaded: url_helper
INFO - 2024-03-31 04:16:57 --> Helper loaded: file_helper
INFO - 2024-03-31 04:16:57 --> Helper loaded: html_helper
INFO - 2024-03-31 04:16:57 --> Helper loaded: text_helper
INFO - 2024-03-31 04:16:57 --> Helper loaded: form_helper
INFO - 2024-03-31 04:16:57 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:16:57 --> Helper loaded: security_helper
INFO - 2024-03-31 04:16:57 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:16:57 --> Database Driver Class Initialized
INFO - 2024-03-31 04:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:16:57 --> Parser Class Initialized
INFO - 2024-03-31 04:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:16:57 --> Pagination Class Initialized
INFO - 2024-03-31 04:16:57 --> Form Validation Class Initialized
INFO - 2024-03-31 04:16:57 --> Controller Class Initialized
INFO - 2024-03-31 04:16:57 --> Model Class Initialized
DEBUG - 2024-03-31 04:16:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:57 --> Model Class Initialized
DEBUG - 2024-03-31 04:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:57 --> Model Class Initialized
INFO - 2024-03-31 04:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-31 04:16:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:16:58 --> Model Class Initialized
INFO - 2024-03-31 04:16:58 --> Model Class Initialized
INFO - 2024-03-31 04:16:58 --> Model Class Initialized
INFO - 2024-03-31 04:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:16:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:16:58 --> Final output sent to browser
DEBUG - 2024-03-31 04:16:58 --> Total execution time: 0.3473
ERROR - 2024-03-31 04:17:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:04 --> Config Class Initialized
INFO - 2024-03-31 04:17:04 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:04 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:04 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:04 --> URI Class Initialized
INFO - 2024-03-31 04:17:04 --> Router Class Initialized
INFO - 2024-03-31 04:17:04 --> Output Class Initialized
INFO - 2024-03-31 04:17:04 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:04 --> Input Class Initialized
INFO - 2024-03-31 04:17:04 --> Language Class Initialized
INFO - 2024-03-31 04:17:04 --> Loader Class Initialized
INFO - 2024-03-31 04:17:04 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:04 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:04 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:04 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:04 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:04 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:04 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:04 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:04 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:04 --> Parser Class Initialized
INFO - 2024-03-31 04:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:04 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:04 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:04 --> Controller Class Initialized
INFO - 2024-03-31 04:17:04 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-31 04:17:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-03-31 04:17:04 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:04 --> Total execution time: 0.0161
ERROR - 2024-03-31 04:17:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:06 --> Config Class Initialized
INFO - 2024-03-31 04:17:06 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:06 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:06 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:06 --> URI Class Initialized
INFO - 2024-03-31 04:17:06 --> Router Class Initialized
INFO - 2024-03-31 04:17:06 --> Output Class Initialized
INFO - 2024-03-31 04:17:06 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:06 --> Input Class Initialized
INFO - 2024-03-31 04:17:06 --> Language Class Initialized
INFO - 2024-03-31 04:17:06 --> Loader Class Initialized
INFO - 2024-03-31 04:17:06 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:06 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:06 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:06 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:06 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:06 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:06 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:06 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:06 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:06 --> Parser Class Initialized
INFO - 2024-03-31 04:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:06 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:06 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:06 --> Controller Class Initialized
INFO - 2024-03-31 04:17:06 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:06 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:06 --> Total execution time: 0.0145
ERROR - 2024-03-31 04:17:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:07 --> Config Class Initialized
INFO - 2024-03-31 04:17:07 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:07 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:07 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:07 --> URI Class Initialized
INFO - 2024-03-31 04:17:07 --> Router Class Initialized
INFO - 2024-03-31 04:17:07 --> Output Class Initialized
INFO - 2024-03-31 04:17:07 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:07 --> Input Class Initialized
INFO - 2024-03-31 04:17:07 --> Language Class Initialized
INFO - 2024-03-31 04:17:07 --> Loader Class Initialized
INFO - 2024-03-31 04:17:07 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:07 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:07 --> Parser Class Initialized
INFO - 2024-03-31 04:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:07 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:07 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:07 --> Controller Class Initialized
INFO - 2024-03-31 04:17:07 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:07 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:07 --> Total execution time: 0.0172
ERROR - 2024-03-31 04:17:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:07 --> Config Class Initialized
INFO - 2024-03-31 04:17:07 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:07 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:07 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:07 --> URI Class Initialized
INFO - 2024-03-31 04:17:07 --> Router Class Initialized
INFO - 2024-03-31 04:17:07 --> Output Class Initialized
INFO - 2024-03-31 04:17:07 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:07 --> Input Class Initialized
INFO - 2024-03-31 04:17:07 --> Language Class Initialized
INFO - 2024-03-31 04:17:07 --> Loader Class Initialized
INFO - 2024-03-31 04:17:07 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:07 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:07 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:07 --> Parser Class Initialized
INFO - 2024-03-31 04:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:07 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:07 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:07 --> Controller Class Initialized
INFO - 2024-03-31 04:17:07 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:07 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:07 --> Total execution time: 0.0180
ERROR - 2024-03-31 04:17:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:27 --> Config Class Initialized
INFO - 2024-03-31 04:17:27 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:27 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:27 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:27 --> URI Class Initialized
INFO - 2024-03-31 04:17:27 --> Router Class Initialized
INFO - 2024-03-31 04:17:27 --> Output Class Initialized
INFO - 2024-03-31 04:17:27 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:27 --> Input Class Initialized
INFO - 2024-03-31 04:17:27 --> Language Class Initialized
INFO - 2024-03-31 04:17:27 --> Loader Class Initialized
INFO - 2024-03-31 04:17:27 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:27 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:27 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:27 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:27 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:27 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:27 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:27 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:27 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:27 --> Parser Class Initialized
INFO - 2024-03-31 04:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:27 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:27 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:27 --> Controller Class Initialized
INFO - 2024-03-31 04:17:27 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-31 04:17:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-03-31 04:17:27 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:27 --> Total execution time: 0.0236
ERROR - 2024-03-31 04:17:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:30 --> Config Class Initialized
INFO - 2024-03-31 04:17:30 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:30 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:30 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:30 --> URI Class Initialized
INFO - 2024-03-31 04:17:30 --> Router Class Initialized
INFO - 2024-03-31 04:17:30 --> Output Class Initialized
INFO - 2024-03-31 04:17:30 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:30 --> Input Class Initialized
INFO - 2024-03-31 04:17:30 --> Language Class Initialized
INFO - 2024-03-31 04:17:30 --> Loader Class Initialized
INFO - 2024-03-31 04:17:30 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:30 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:30 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:30 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:30 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:30 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:30 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:30 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:30 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:30 --> Parser Class Initialized
INFO - 2024-03-31 04:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:30 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:30 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:30 --> Controller Class Initialized
INFO - 2024-03-31 04:17:30 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:30 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:30 --> Total execution time: 0.0171
ERROR - 2024-03-31 04:17:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:42 --> Config Class Initialized
INFO - 2024-03-31 04:17:42 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:42 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:42 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:42 --> URI Class Initialized
INFO - 2024-03-31 04:17:42 --> Router Class Initialized
INFO - 2024-03-31 04:17:42 --> Output Class Initialized
INFO - 2024-03-31 04:17:42 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:42 --> Input Class Initialized
INFO - 2024-03-31 04:17:42 --> Language Class Initialized
INFO - 2024-03-31 04:17:42 --> Loader Class Initialized
INFO - 2024-03-31 04:17:42 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:42 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:42 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:42 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:42 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:42 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:42 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:42 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:42 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:42 --> Parser Class Initialized
INFO - 2024-03-31 04:17:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:42 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:42 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:42 --> Controller Class Initialized
INFO - 2024-03-31 04:17:42 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:42 --> Total execution time: 0.0166
ERROR - 2024-03-31 04:17:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:51 --> Config Class Initialized
INFO - 2024-03-31 04:17:51 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:51 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:51 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:51 --> URI Class Initialized
INFO - 2024-03-31 04:17:51 --> Router Class Initialized
INFO - 2024-03-31 04:17:51 --> Output Class Initialized
INFO - 2024-03-31 04:17:51 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:51 --> Input Class Initialized
INFO - 2024-03-31 04:17:51 --> Language Class Initialized
INFO - 2024-03-31 04:17:51 --> Loader Class Initialized
INFO - 2024-03-31 04:17:51 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:51 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:51 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:51 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:51 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:51 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:51 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:51 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:51 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:51 --> Parser Class Initialized
INFO - 2024-03-31 04:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:51 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:51 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:51 --> Controller Class Initialized
INFO - 2024-03-31 04:17:51 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:51 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:51 --> Model Class Initialized
INFO - 2024-03-31 04:17:51 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:51 --> Total execution time: 0.1493
ERROR - 2024-03-31 04:17:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:52 --> Config Class Initialized
INFO - 2024-03-31 04:17:52 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:52 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:52 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:52 --> URI Class Initialized
INFO - 2024-03-31 04:17:52 --> Router Class Initialized
INFO - 2024-03-31 04:17:52 --> Output Class Initialized
INFO - 2024-03-31 04:17:52 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:52 --> Input Class Initialized
INFO - 2024-03-31 04:17:52 --> Language Class Initialized
INFO - 2024-03-31 04:17:52 --> Loader Class Initialized
INFO - 2024-03-31 04:17:52 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:52 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:52 --> Parser Class Initialized
INFO - 2024-03-31 04:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:52 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:52 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:52 --> Controller Class Initialized
INFO - 2024-03-31 04:17:52 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:52 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:52 --> Model Class Initialized
INFO - 2024-03-31 04:17:52 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:52 --> Total execution time: 0.1473
ERROR - 2024-03-31 04:17:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:52 --> Config Class Initialized
INFO - 2024-03-31 04:17:52 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:52 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:52 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:52 --> URI Class Initialized
INFO - 2024-03-31 04:17:52 --> Router Class Initialized
INFO - 2024-03-31 04:17:52 --> Output Class Initialized
INFO - 2024-03-31 04:17:52 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:52 --> Input Class Initialized
INFO - 2024-03-31 04:17:52 --> Language Class Initialized
INFO - 2024-03-31 04:17:52 --> Loader Class Initialized
INFO - 2024-03-31 04:17:52 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:52 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:52 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:52 --> Parser Class Initialized
INFO - 2024-03-31 04:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:52 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:52 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:52 --> Controller Class Initialized
INFO - 2024-03-31 04:17:52 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:52 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:52 --> Model Class Initialized
INFO - 2024-03-31 04:17:52 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:52 --> Total execution time: 0.1432
ERROR - 2024-03-31 04:17:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:55 --> Config Class Initialized
INFO - 2024-03-31 04:17:55 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:55 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:55 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:55 --> URI Class Initialized
INFO - 2024-03-31 04:17:55 --> Router Class Initialized
INFO - 2024-03-31 04:17:55 --> Output Class Initialized
INFO - 2024-03-31 04:17:55 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:55 --> Input Class Initialized
INFO - 2024-03-31 04:17:55 --> Language Class Initialized
INFO - 2024-03-31 04:17:55 --> Loader Class Initialized
INFO - 2024-03-31 04:17:55 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:55 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:55 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:55 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:55 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:55 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:55 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:55 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:55 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:55 --> Parser Class Initialized
INFO - 2024-03-31 04:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:55 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:55 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:55 --> Controller Class Initialized
INFO - 2024-03-31 04:17:55 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:55 --> Model Class Initialized
INFO - 2024-03-31 04:17:55 --> Model Class Initialized
INFO - 2024-03-31 04:17:55 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:55 --> Total execution time: 0.0189
ERROR - 2024-03-31 04:17:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:17:58 --> Config Class Initialized
INFO - 2024-03-31 04:17:58 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:17:58 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:17:58 --> Utf8 Class Initialized
INFO - 2024-03-31 04:17:58 --> URI Class Initialized
INFO - 2024-03-31 04:17:58 --> Router Class Initialized
INFO - 2024-03-31 04:17:58 --> Output Class Initialized
INFO - 2024-03-31 04:17:58 --> Security Class Initialized
DEBUG - 2024-03-31 04:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:17:58 --> Input Class Initialized
INFO - 2024-03-31 04:17:58 --> Language Class Initialized
INFO - 2024-03-31 04:17:58 --> Loader Class Initialized
INFO - 2024-03-31 04:17:58 --> Helper loaded: url_helper
INFO - 2024-03-31 04:17:58 --> Helper loaded: file_helper
INFO - 2024-03-31 04:17:58 --> Helper loaded: html_helper
INFO - 2024-03-31 04:17:58 --> Helper loaded: text_helper
INFO - 2024-03-31 04:17:58 --> Helper loaded: form_helper
INFO - 2024-03-31 04:17:58 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:17:58 --> Helper loaded: security_helper
INFO - 2024-03-31 04:17:58 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:17:58 --> Database Driver Class Initialized
INFO - 2024-03-31 04:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:17:58 --> Parser Class Initialized
INFO - 2024-03-31 04:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:17:58 --> Pagination Class Initialized
INFO - 2024-03-31 04:17:58 --> Form Validation Class Initialized
INFO - 2024-03-31 04:17:58 --> Controller Class Initialized
INFO - 2024-03-31 04:17:58 --> Model Class Initialized
DEBUG - 2024-03-31 04:17:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:17:58 --> Model Class Initialized
INFO - 2024-03-31 04:17:58 --> Final output sent to browser
DEBUG - 2024-03-31 04:17:58 --> Total execution time: 0.0167
ERROR - 2024-03-31 04:18:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:25 --> Config Class Initialized
INFO - 2024-03-31 04:18:25 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:25 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:25 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:25 --> URI Class Initialized
INFO - 2024-03-31 04:18:25 --> Router Class Initialized
INFO - 2024-03-31 04:18:25 --> Output Class Initialized
INFO - 2024-03-31 04:18:25 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:25 --> Input Class Initialized
INFO - 2024-03-31 04:18:25 --> Language Class Initialized
INFO - 2024-03-31 04:18:25 --> Loader Class Initialized
INFO - 2024-03-31 04:18:25 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:25 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:25 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:25 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:25 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:25 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:25 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:25 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:25 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:25 --> Parser Class Initialized
INFO - 2024-03-31 04:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:25 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:25 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:25 --> Controller Class Initialized
INFO - 2024-03-31 04:18:25 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:25 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:25 --> Model Class Initialized
INFO - 2024-03-31 04:18:25 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:25 --> Total execution time: 0.1471
ERROR - 2024-03-31 04:18:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:26 --> Config Class Initialized
INFO - 2024-03-31 04:18:26 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:26 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:26 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:26 --> URI Class Initialized
INFO - 2024-03-31 04:18:26 --> Router Class Initialized
INFO - 2024-03-31 04:18:26 --> Output Class Initialized
INFO - 2024-03-31 04:18:26 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:26 --> Input Class Initialized
INFO - 2024-03-31 04:18:26 --> Language Class Initialized
INFO - 2024-03-31 04:18:26 --> Loader Class Initialized
INFO - 2024-03-31 04:18:26 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:26 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:26 --> Parser Class Initialized
INFO - 2024-03-31 04:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:26 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:26 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:26 --> Controller Class Initialized
INFO - 2024-03-31 04:18:26 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:26 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:26 --> Model Class Initialized
INFO - 2024-03-31 04:18:26 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:26 --> Total execution time: 0.1473
ERROR - 2024-03-31 04:18:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:26 --> Config Class Initialized
INFO - 2024-03-31 04:18:26 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:26 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:26 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:26 --> URI Class Initialized
INFO - 2024-03-31 04:18:26 --> Router Class Initialized
INFO - 2024-03-31 04:18:26 --> Output Class Initialized
INFO - 2024-03-31 04:18:26 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:26 --> Input Class Initialized
INFO - 2024-03-31 04:18:26 --> Language Class Initialized
INFO - 2024-03-31 04:18:26 --> Loader Class Initialized
INFO - 2024-03-31 04:18:26 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:26 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:26 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:26 --> Parser Class Initialized
INFO - 2024-03-31 04:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:26 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:26 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:26 --> Controller Class Initialized
INFO - 2024-03-31 04:18:26 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:26 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:26 --> Model Class Initialized
INFO - 2024-03-31 04:18:26 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:26 --> Total execution time: 0.0234
ERROR - 2024-03-31 04:18:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:27 --> Config Class Initialized
INFO - 2024-03-31 04:18:27 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:27 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:27 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:27 --> URI Class Initialized
INFO - 2024-03-31 04:18:27 --> Router Class Initialized
INFO - 2024-03-31 04:18:27 --> Output Class Initialized
INFO - 2024-03-31 04:18:27 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:27 --> Input Class Initialized
INFO - 2024-03-31 04:18:27 --> Language Class Initialized
INFO - 2024-03-31 04:18:27 --> Loader Class Initialized
INFO - 2024-03-31 04:18:27 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:27 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:27 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:27 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:27 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:27 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:27 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:27 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:27 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:27 --> Parser Class Initialized
INFO - 2024-03-31 04:18:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:27 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:27 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:27 --> Controller Class Initialized
INFO - 2024-03-31 04:18:27 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:27 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:27 --> Model Class Initialized
INFO - 2024-03-31 04:18:27 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:27 --> Total execution time: 0.1498
ERROR - 2024-03-31 04:18:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:28 --> Config Class Initialized
INFO - 2024-03-31 04:18:28 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:28 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:28 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:28 --> URI Class Initialized
INFO - 2024-03-31 04:18:28 --> Router Class Initialized
INFO - 2024-03-31 04:18:28 --> Output Class Initialized
INFO - 2024-03-31 04:18:28 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:28 --> Input Class Initialized
INFO - 2024-03-31 04:18:28 --> Language Class Initialized
INFO - 2024-03-31 04:18:28 --> Loader Class Initialized
INFO - 2024-03-31 04:18:28 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:28 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:28 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:28 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:28 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:28 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:28 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:28 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:28 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:28 --> Parser Class Initialized
INFO - 2024-03-31 04:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:28 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:28 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:28 --> Controller Class Initialized
INFO - 2024-03-31 04:18:28 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:28 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:28 --> Model Class Initialized
INFO - 2024-03-31 04:18:28 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:28 --> Total execution time: 0.1476
ERROR - 2024-03-31 04:18:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:31 --> Config Class Initialized
INFO - 2024-03-31 04:18:31 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:31 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:31 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:31 --> URI Class Initialized
INFO - 2024-03-31 04:18:31 --> Router Class Initialized
INFO - 2024-03-31 04:18:31 --> Output Class Initialized
INFO - 2024-03-31 04:18:31 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:31 --> Input Class Initialized
INFO - 2024-03-31 04:18:31 --> Language Class Initialized
INFO - 2024-03-31 04:18:31 --> Loader Class Initialized
INFO - 2024-03-31 04:18:31 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:31 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:31 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:31 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:31 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:31 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:31 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:31 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:31 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:31 --> Parser Class Initialized
INFO - 2024-03-31 04:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:31 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:31 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:31 --> Controller Class Initialized
INFO - 2024-03-31 04:18:31 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:31 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:31 --> Model Class Initialized
INFO - 2024-03-31 04:18:31 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:31 --> Total execution time: 0.0536
ERROR - 2024-03-31 04:18:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:32 --> Config Class Initialized
INFO - 2024-03-31 04:18:32 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:32 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:32 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:32 --> URI Class Initialized
INFO - 2024-03-31 04:18:32 --> Router Class Initialized
INFO - 2024-03-31 04:18:32 --> Output Class Initialized
INFO - 2024-03-31 04:18:32 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:32 --> Input Class Initialized
INFO - 2024-03-31 04:18:32 --> Language Class Initialized
INFO - 2024-03-31 04:18:32 --> Loader Class Initialized
INFO - 2024-03-31 04:18:32 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:32 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:32 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:32 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:32 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:32 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:32 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:32 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:32 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:32 --> Parser Class Initialized
INFO - 2024-03-31 04:18:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:32 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:32 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:32 --> Controller Class Initialized
INFO - 2024-03-31 04:18:32 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:32 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:32 --> Model Class Initialized
INFO - 2024-03-31 04:18:32 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:32 --> Total execution time: 0.0275
ERROR - 2024-03-31 04:18:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:34 --> Config Class Initialized
INFO - 2024-03-31 04:18:34 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:34 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:34 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:34 --> URI Class Initialized
INFO - 2024-03-31 04:18:34 --> Router Class Initialized
INFO - 2024-03-31 04:18:34 --> Output Class Initialized
INFO - 2024-03-31 04:18:34 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:34 --> Input Class Initialized
INFO - 2024-03-31 04:18:34 --> Language Class Initialized
INFO - 2024-03-31 04:18:34 --> Loader Class Initialized
INFO - 2024-03-31 04:18:34 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:34 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:34 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:34 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:34 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:34 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:34 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:34 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:34 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:34 --> Parser Class Initialized
INFO - 2024-03-31 04:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:34 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:34 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:34 --> Controller Class Initialized
INFO - 2024-03-31 04:18:34 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:34 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:34 --> Model Class Initialized
INFO - 2024-03-31 04:18:34 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:34 --> Total execution time: 0.0265
ERROR - 2024-03-31 04:18:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:37 --> Config Class Initialized
INFO - 2024-03-31 04:18:37 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:37 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:37 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:37 --> URI Class Initialized
INFO - 2024-03-31 04:18:37 --> Router Class Initialized
INFO - 2024-03-31 04:18:37 --> Output Class Initialized
INFO - 2024-03-31 04:18:37 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:37 --> Input Class Initialized
INFO - 2024-03-31 04:18:37 --> Language Class Initialized
INFO - 2024-03-31 04:18:37 --> Loader Class Initialized
INFO - 2024-03-31 04:18:37 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:37 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:37 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:37 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:37 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:37 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:37 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:37 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:37 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:37 --> Parser Class Initialized
INFO - 2024-03-31 04:18:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:37 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:37 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:37 --> Controller Class Initialized
INFO - 2024-03-31 04:18:37 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:37 --> Model Class Initialized
INFO - 2024-03-31 04:18:37 --> Model Class Initialized
INFO - 2024-03-31 04:18:37 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:37 --> Total execution time: 0.0195
ERROR - 2024-03-31 04:18:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:40 --> Config Class Initialized
INFO - 2024-03-31 04:18:40 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:40 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:40 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:40 --> URI Class Initialized
INFO - 2024-03-31 04:18:40 --> Router Class Initialized
INFO - 2024-03-31 04:18:40 --> Output Class Initialized
INFO - 2024-03-31 04:18:40 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:40 --> Input Class Initialized
INFO - 2024-03-31 04:18:40 --> Language Class Initialized
INFO - 2024-03-31 04:18:40 --> Loader Class Initialized
INFO - 2024-03-31 04:18:40 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:40 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:40 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:40 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:40 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:40 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:40 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:40 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:40 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:40 --> Parser Class Initialized
INFO - 2024-03-31 04:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:40 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:40 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:40 --> Controller Class Initialized
INFO - 2024-03-31 04:18:40 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:40 --> Model Class Initialized
INFO - 2024-03-31 04:18:40 --> Final output sent to browser
DEBUG - 2024-03-31 04:18:40 --> Total execution time: 0.0157
ERROR - 2024-03-31 04:18:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:18:59 --> Config Class Initialized
INFO - 2024-03-31 04:18:59 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:18:59 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:18:59 --> Utf8 Class Initialized
INFO - 2024-03-31 04:18:59 --> URI Class Initialized
INFO - 2024-03-31 04:18:59 --> Router Class Initialized
INFO - 2024-03-31 04:18:59 --> Output Class Initialized
INFO - 2024-03-31 04:18:59 --> Security Class Initialized
DEBUG - 2024-03-31 04:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:18:59 --> Input Class Initialized
INFO - 2024-03-31 04:18:59 --> Language Class Initialized
INFO - 2024-03-31 04:18:59 --> Loader Class Initialized
INFO - 2024-03-31 04:18:59 --> Helper loaded: url_helper
INFO - 2024-03-31 04:18:59 --> Helper loaded: file_helper
INFO - 2024-03-31 04:18:59 --> Helper loaded: html_helper
INFO - 2024-03-31 04:18:59 --> Helper loaded: text_helper
INFO - 2024-03-31 04:18:59 --> Helper loaded: form_helper
INFO - 2024-03-31 04:18:59 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:18:59 --> Helper loaded: security_helper
INFO - 2024-03-31 04:18:59 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:18:59 --> Database Driver Class Initialized
INFO - 2024-03-31 04:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:18:59 --> Parser Class Initialized
INFO - 2024-03-31 04:18:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:18:59 --> Pagination Class Initialized
INFO - 2024-03-31 04:18:59 --> Form Validation Class Initialized
INFO - 2024-03-31 04:18:59 --> Controller Class Initialized
INFO - 2024-03-31 04:18:59 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:59 --> Model Class Initialized
DEBUG - 2024-03-31 04:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:59 --> Model Class Initialized
INFO - 2024-03-31 04:18:59 --> Email Class Initialized
DEBUG - 2024-03-31 04:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:18:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-31 04:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-31 04:19:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-03-31 04:19:00 --> Language file loaded: language/english/email_lang.php
INFO - 2024-03-31 04:19:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-03-31 04:19:00 --> Final output sent to browser
DEBUG - 2024-03-31 04:19:00 --> Total execution time: 0.2548
ERROR - 2024-03-31 04:19:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:19:06 --> Config Class Initialized
INFO - 2024-03-31 04:19:06 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:19:06 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:19:06 --> Utf8 Class Initialized
INFO - 2024-03-31 04:19:06 --> URI Class Initialized
INFO - 2024-03-31 04:19:06 --> Router Class Initialized
INFO - 2024-03-31 04:19:06 --> Output Class Initialized
INFO - 2024-03-31 04:19:06 --> Security Class Initialized
DEBUG - 2024-03-31 04:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:19:06 --> Input Class Initialized
INFO - 2024-03-31 04:19:06 --> Language Class Initialized
INFO - 2024-03-31 04:19:06 --> Loader Class Initialized
INFO - 2024-03-31 04:19:06 --> Helper loaded: url_helper
INFO - 2024-03-31 04:19:06 --> Helper loaded: file_helper
INFO - 2024-03-31 04:19:06 --> Helper loaded: html_helper
INFO - 2024-03-31 04:19:06 --> Helper loaded: text_helper
INFO - 2024-03-31 04:19:06 --> Helper loaded: form_helper
INFO - 2024-03-31 04:19:06 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:19:06 --> Helper loaded: security_helper
INFO - 2024-03-31 04:19:06 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:19:06 --> Database Driver Class Initialized
INFO - 2024-03-31 04:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:19:06 --> Parser Class Initialized
INFO - 2024-03-31 04:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:19:06 --> Pagination Class Initialized
INFO - 2024-03-31 04:19:06 --> Form Validation Class Initialized
INFO - 2024-03-31 04:19:06 --> Controller Class Initialized
INFO - 2024-03-31 04:19:06 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:06 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:06 --> Model Class Initialized
INFO - 2024-03-31 04:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-31 04:19:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:19:06 --> Model Class Initialized
INFO - 2024-03-31 04:19:06 --> Model Class Initialized
INFO - 2024-03-31 04:19:06 --> Model Class Initialized
INFO - 2024-03-31 04:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:19:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:19:06 --> Final output sent to browser
DEBUG - 2024-03-31 04:19:06 --> Total execution time: 0.1880
ERROR - 2024-03-31 04:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:19:15 --> Config Class Initialized
INFO - 2024-03-31 04:19:15 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:19:15 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:19:15 --> Utf8 Class Initialized
INFO - 2024-03-31 04:19:15 --> URI Class Initialized
INFO - 2024-03-31 04:19:15 --> Router Class Initialized
INFO - 2024-03-31 04:19:15 --> Output Class Initialized
INFO - 2024-03-31 04:19:15 --> Security Class Initialized
DEBUG - 2024-03-31 04:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:19:15 --> Input Class Initialized
INFO - 2024-03-31 04:19:15 --> Language Class Initialized
INFO - 2024-03-31 04:19:15 --> Loader Class Initialized
INFO - 2024-03-31 04:19:15 --> Helper loaded: url_helper
INFO - 2024-03-31 04:19:15 --> Helper loaded: file_helper
INFO - 2024-03-31 04:19:15 --> Helper loaded: html_helper
INFO - 2024-03-31 04:19:15 --> Helper loaded: text_helper
INFO - 2024-03-31 04:19:15 --> Helper loaded: form_helper
INFO - 2024-03-31 04:19:15 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:19:15 --> Helper loaded: security_helper
INFO - 2024-03-31 04:19:15 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:19:15 --> Database Driver Class Initialized
INFO - 2024-03-31 04:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:19:15 --> Parser Class Initialized
INFO - 2024-03-31 04:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:19:15 --> Pagination Class Initialized
INFO - 2024-03-31 04:19:15 --> Form Validation Class Initialized
INFO - 2024-03-31 04:19:15 --> Controller Class Initialized
INFO - 2024-03-31 04:19:15 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:15 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:15 --> Model Class Initialized
INFO - 2024-03-31 04:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-31 04:19:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:19:15 --> Model Class Initialized
INFO - 2024-03-31 04:19:15 --> Model Class Initialized
INFO - 2024-03-31 04:19:15 --> Model Class Initialized
INFO - 2024-03-31 04:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:19:15 --> Final output sent to browser
DEBUG - 2024-03-31 04:19:15 --> Total execution time: 0.1859
ERROR - 2024-03-31 04:19:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:19:16 --> Config Class Initialized
INFO - 2024-03-31 04:19:16 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:19:16 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:19:16 --> Utf8 Class Initialized
INFO - 2024-03-31 04:19:16 --> URI Class Initialized
INFO - 2024-03-31 04:19:16 --> Router Class Initialized
INFO - 2024-03-31 04:19:16 --> Output Class Initialized
INFO - 2024-03-31 04:19:16 --> Security Class Initialized
DEBUG - 2024-03-31 04:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:19:16 --> Input Class Initialized
INFO - 2024-03-31 04:19:16 --> Language Class Initialized
INFO - 2024-03-31 04:19:16 --> Loader Class Initialized
INFO - 2024-03-31 04:19:16 --> Helper loaded: url_helper
INFO - 2024-03-31 04:19:16 --> Helper loaded: file_helper
INFO - 2024-03-31 04:19:16 --> Helper loaded: html_helper
INFO - 2024-03-31 04:19:16 --> Helper loaded: text_helper
INFO - 2024-03-31 04:19:16 --> Helper loaded: form_helper
INFO - 2024-03-31 04:19:16 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:19:16 --> Helper loaded: security_helper
INFO - 2024-03-31 04:19:16 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:19:16 --> Database Driver Class Initialized
INFO - 2024-03-31 04:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:19:16 --> Parser Class Initialized
INFO - 2024-03-31 04:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:19:16 --> Pagination Class Initialized
INFO - 2024-03-31 04:19:16 --> Form Validation Class Initialized
INFO - 2024-03-31 04:19:16 --> Controller Class Initialized
INFO - 2024-03-31 04:19:16 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:16 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:16 --> Model Class Initialized
INFO - 2024-03-31 04:19:16 --> Final output sent to browser
DEBUG - 2024-03-31 04:19:16 --> Total execution time: 0.0427
ERROR - 2024-03-31 04:19:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:19:30 --> Config Class Initialized
INFO - 2024-03-31 04:19:30 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:19:30 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:19:30 --> Utf8 Class Initialized
INFO - 2024-03-31 04:19:30 --> URI Class Initialized
DEBUG - 2024-03-31 04:19:30 --> No URI present. Default controller set.
INFO - 2024-03-31 04:19:30 --> Router Class Initialized
INFO - 2024-03-31 04:19:30 --> Output Class Initialized
INFO - 2024-03-31 04:19:30 --> Security Class Initialized
DEBUG - 2024-03-31 04:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:19:30 --> Input Class Initialized
INFO - 2024-03-31 04:19:30 --> Language Class Initialized
INFO - 2024-03-31 04:19:30 --> Loader Class Initialized
INFO - 2024-03-31 04:19:30 --> Helper loaded: url_helper
INFO - 2024-03-31 04:19:30 --> Helper loaded: file_helper
INFO - 2024-03-31 04:19:30 --> Helper loaded: html_helper
INFO - 2024-03-31 04:19:30 --> Helper loaded: text_helper
INFO - 2024-03-31 04:19:30 --> Helper loaded: form_helper
INFO - 2024-03-31 04:19:30 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:19:30 --> Helper loaded: security_helper
INFO - 2024-03-31 04:19:30 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:19:30 --> Database Driver Class Initialized
INFO - 2024-03-31 04:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:19:30 --> Parser Class Initialized
INFO - 2024-03-31 04:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:19:30 --> Pagination Class Initialized
INFO - 2024-03-31 04:19:30 --> Form Validation Class Initialized
INFO - 2024-03-31 04:19:30 --> Controller Class Initialized
INFO - 2024-03-31 04:19:30 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:30 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:30 --> Model Class Initialized
INFO - 2024-03-31 04:19:30 --> Model Class Initialized
INFO - 2024-03-31 04:19:30 --> Model Class Initialized
INFO - 2024-03-31 04:19:30 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:30 --> Model Class Initialized
INFO - 2024-03-31 04:19:30 --> Model Class Initialized
INFO - 2024-03-31 04:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-31 04:19:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:19:30 --> Model Class Initialized
INFO - 2024-03-31 04:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:19:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:19:30 --> Final output sent to browser
DEBUG - 2024-03-31 04:19:30 --> Total execution time: 0.2584
ERROR - 2024-03-31 04:19:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:19:39 --> Config Class Initialized
INFO - 2024-03-31 04:19:39 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:19:39 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:19:39 --> Utf8 Class Initialized
INFO - 2024-03-31 04:19:39 --> URI Class Initialized
DEBUG - 2024-03-31 04:19:39 --> No URI present. Default controller set.
INFO - 2024-03-31 04:19:39 --> Router Class Initialized
INFO - 2024-03-31 04:19:39 --> Output Class Initialized
INFO - 2024-03-31 04:19:39 --> Security Class Initialized
DEBUG - 2024-03-31 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:19:39 --> Input Class Initialized
INFO - 2024-03-31 04:19:39 --> Language Class Initialized
INFO - 2024-03-31 04:19:39 --> Loader Class Initialized
INFO - 2024-03-31 04:19:39 --> Helper loaded: url_helper
INFO - 2024-03-31 04:19:39 --> Helper loaded: file_helper
INFO - 2024-03-31 04:19:39 --> Helper loaded: html_helper
INFO - 2024-03-31 04:19:39 --> Helper loaded: text_helper
INFO - 2024-03-31 04:19:39 --> Helper loaded: form_helper
INFO - 2024-03-31 04:19:39 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:19:39 --> Helper loaded: security_helper
INFO - 2024-03-31 04:19:39 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:19:39 --> Database Driver Class Initialized
INFO - 2024-03-31 04:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:19:39 --> Parser Class Initialized
INFO - 2024-03-31 04:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:19:39 --> Pagination Class Initialized
INFO - 2024-03-31 04:19:39 --> Form Validation Class Initialized
INFO - 2024-03-31 04:19:39 --> Controller Class Initialized
INFO - 2024-03-31 04:19:39 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:39 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:39 --> Model Class Initialized
INFO - 2024-03-31 04:19:39 --> Model Class Initialized
INFO - 2024-03-31 04:19:39 --> Model Class Initialized
INFO - 2024-03-31 04:19:39 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:39 --> Model Class Initialized
INFO - 2024-03-31 04:19:39 --> Model Class Initialized
INFO - 2024-03-31 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-31 04:19:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:19:39 --> Model Class Initialized
INFO - 2024-03-31 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:19:39 --> Final output sent to browser
DEBUG - 2024-03-31 04:19:39 --> Total execution time: 0.2571
ERROR - 2024-03-31 04:19:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:19:52 --> Config Class Initialized
INFO - 2024-03-31 04:19:52 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:19:52 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:19:52 --> Utf8 Class Initialized
INFO - 2024-03-31 04:19:52 --> URI Class Initialized
DEBUG - 2024-03-31 04:19:52 --> No URI present. Default controller set.
INFO - 2024-03-31 04:19:52 --> Router Class Initialized
INFO - 2024-03-31 04:19:52 --> Output Class Initialized
INFO - 2024-03-31 04:19:52 --> Security Class Initialized
DEBUG - 2024-03-31 04:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:19:52 --> Input Class Initialized
INFO - 2024-03-31 04:19:52 --> Language Class Initialized
INFO - 2024-03-31 04:19:52 --> Loader Class Initialized
INFO - 2024-03-31 04:19:52 --> Helper loaded: url_helper
INFO - 2024-03-31 04:19:52 --> Helper loaded: file_helper
INFO - 2024-03-31 04:19:52 --> Helper loaded: html_helper
INFO - 2024-03-31 04:19:52 --> Helper loaded: text_helper
INFO - 2024-03-31 04:19:52 --> Helper loaded: form_helper
INFO - 2024-03-31 04:19:52 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:19:52 --> Helper loaded: security_helper
INFO - 2024-03-31 04:19:52 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:19:52 --> Database Driver Class Initialized
INFO - 2024-03-31 04:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:19:52 --> Parser Class Initialized
INFO - 2024-03-31 04:19:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:19:52 --> Pagination Class Initialized
INFO - 2024-03-31 04:19:52 --> Form Validation Class Initialized
INFO - 2024-03-31 04:19:52 --> Controller Class Initialized
INFO - 2024-03-31 04:19:52 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:52 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:52 --> Model Class Initialized
INFO - 2024-03-31 04:19:52 --> Model Class Initialized
INFO - 2024-03-31 04:19:52 --> Model Class Initialized
INFO - 2024-03-31 04:19:52 --> Model Class Initialized
DEBUG - 2024-03-31 04:19:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:52 --> Model Class Initialized
INFO - 2024-03-31 04:19:52 --> Model Class Initialized
INFO - 2024-03-31 04:19:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-31 04:19:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:19:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:19:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:19:53 --> Model Class Initialized
INFO - 2024-03-31 04:19:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:19:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:19:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:19:53 --> Final output sent to browser
DEBUG - 2024-03-31 04:19:53 --> Total execution time: 0.2669
ERROR - 2024-03-31 04:20:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:20:08 --> Config Class Initialized
INFO - 2024-03-31 04:20:08 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:20:08 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:20:08 --> Utf8 Class Initialized
INFO - 2024-03-31 04:20:08 --> URI Class Initialized
INFO - 2024-03-31 04:20:08 --> Router Class Initialized
INFO - 2024-03-31 04:20:08 --> Output Class Initialized
INFO - 2024-03-31 04:20:08 --> Security Class Initialized
DEBUG - 2024-03-31 04:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:20:08 --> Input Class Initialized
INFO - 2024-03-31 04:20:08 --> Language Class Initialized
INFO - 2024-03-31 04:20:08 --> Loader Class Initialized
INFO - 2024-03-31 04:20:08 --> Helper loaded: url_helper
INFO - 2024-03-31 04:20:08 --> Helper loaded: file_helper
INFO - 2024-03-31 04:20:08 --> Helper loaded: html_helper
INFO - 2024-03-31 04:20:08 --> Helper loaded: text_helper
INFO - 2024-03-31 04:20:08 --> Helper loaded: form_helper
INFO - 2024-03-31 04:20:08 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:20:08 --> Helper loaded: security_helper
INFO - 2024-03-31 04:20:08 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:20:08 --> Database Driver Class Initialized
INFO - 2024-03-31 04:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:20:08 --> Parser Class Initialized
INFO - 2024-03-31 04:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:20:08 --> Pagination Class Initialized
INFO - 2024-03-31 04:20:08 --> Form Validation Class Initialized
INFO - 2024-03-31 04:20:08 --> Controller Class Initialized
INFO - 2024-03-31 04:20:08 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:08 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:08 --> Model Class Initialized
INFO - 2024-03-31 04:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-31 04:20:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:20:08 --> Model Class Initialized
INFO - 2024-03-31 04:20:08 --> Model Class Initialized
INFO - 2024-03-31 04:20:08 --> Model Class Initialized
INFO - 2024-03-31 04:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:20:08 --> Final output sent to browser
DEBUG - 2024-03-31 04:20:08 --> Total execution time: 0.1736
ERROR - 2024-03-31 04:20:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:20:09 --> Config Class Initialized
INFO - 2024-03-31 04:20:09 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:20:09 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:20:09 --> Utf8 Class Initialized
INFO - 2024-03-31 04:20:09 --> URI Class Initialized
INFO - 2024-03-31 04:20:09 --> Router Class Initialized
INFO - 2024-03-31 04:20:09 --> Output Class Initialized
INFO - 2024-03-31 04:20:09 --> Security Class Initialized
DEBUG - 2024-03-31 04:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:20:09 --> Input Class Initialized
INFO - 2024-03-31 04:20:09 --> Language Class Initialized
INFO - 2024-03-31 04:20:09 --> Loader Class Initialized
INFO - 2024-03-31 04:20:09 --> Helper loaded: url_helper
INFO - 2024-03-31 04:20:09 --> Helper loaded: file_helper
INFO - 2024-03-31 04:20:09 --> Helper loaded: html_helper
INFO - 2024-03-31 04:20:09 --> Helper loaded: text_helper
INFO - 2024-03-31 04:20:09 --> Helper loaded: form_helper
INFO - 2024-03-31 04:20:09 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:20:09 --> Helper loaded: security_helper
INFO - 2024-03-31 04:20:09 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:20:09 --> Database Driver Class Initialized
INFO - 2024-03-31 04:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:20:09 --> Parser Class Initialized
INFO - 2024-03-31 04:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:20:09 --> Pagination Class Initialized
INFO - 2024-03-31 04:20:09 --> Form Validation Class Initialized
INFO - 2024-03-31 04:20:09 --> Controller Class Initialized
INFO - 2024-03-31 04:20:09 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:09 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:09 --> Model Class Initialized
INFO - 2024-03-31 04:20:09 --> Final output sent to browser
DEBUG - 2024-03-31 04:20:09 --> Total execution time: 0.0581
ERROR - 2024-03-31 04:20:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:20:16 --> Config Class Initialized
INFO - 2024-03-31 04:20:16 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:20:16 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:20:16 --> Utf8 Class Initialized
INFO - 2024-03-31 04:20:16 --> URI Class Initialized
INFO - 2024-03-31 04:20:16 --> Router Class Initialized
INFO - 2024-03-31 04:20:16 --> Output Class Initialized
INFO - 2024-03-31 04:20:16 --> Security Class Initialized
DEBUG - 2024-03-31 04:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:20:16 --> Input Class Initialized
INFO - 2024-03-31 04:20:16 --> Language Class Initialized
INFO - 2024-03-31 04:20:16 --> Loader Class Initialized
INFO - 2024-03-31 04:20:16 --> Helper loaded: url_helper
INFO - 2024-03-31 04:20:16 --> Helper loaded: file_helper
INFO - 2024-03-31 04:20:16 --> Helper loaded: html_helper
INFO - 2024-03-31 04:20:16 --> Helper loaded: text_helper
INFO - 2024-03-31 04:20:16 --> Helper loaded: form_helper
INFO - 2024-03-31 04:20:16 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:20:16 --> Helper loaded: security_helper
INFO - 2024-03-31 04:20:16 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:20:16 --> Database Driver Class Initialized
INFO - 2024-03-31 04:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:20:16 --> Parser Class Initialized
INFO - 2024-03-31 04:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:20:16 --> Pagination Class Initialized
INFO - 2024-03-31 04:20:16 --> Form Validation Class Initialized
INFO - 2024-03-31 04:20:16 --> Controller Class Initialized
INFO - 2024-03-31 04:20:16 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:16 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:16 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-31 04:20:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:20:16 --> Model Class Initialized
INFO - 2024-03-31 04:20:16 --> Model Class Initialized
INFO - 2024-03-31 04:20:16 --> Model Class Initialized
INFO - 2024-03-31 04:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:20:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:20:16 --> Final output sent to browser
DEBUG - 2024-03-31 04:20:16 --> Total execution time: 0.1898
ERROR - 2024-03-31 04:20:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:20:39 --> Config Class Initialized
INFO - 2024-03-31 04:20:39 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:20:39 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:20:39 --> Utf8 Class Initialized
INFO - 2024-03-31 04:20:39 --> URI Class Initialized
INFO - 2024-03-31 04:20:39 --> Router Class Initialized
INFO - 2024-03-31 04:20:39 --> Output Class Initialized
INFO - 2024-03-31 04:20:39 --> Security Class Initialized
DEBUG - 2024-03-31 04:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:20:39 --> Input Class Initialized
INFO - 2024-03-31 04:20:39 --> Language Class Initialized
INFO - 2024-03-31 04:20:39 --> Loader Class Initialized
INFO - 2024-03-31 04:20:39 --> Helper loaded: url_helper
INFO - 2024-03-31 04:20:39 --> Helper loaded: file_helper
INFO - 2024-03-31 04:20:39 --> Helper loaded: html_helper
INFO - 2024-03-31 04:20:39 --> Helper loaded: text_helper
INFO - 2024-03-31 04:20:39 --> Helper loaded: form_helper
INFO - 2024-03-31 04:20:39 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:20:39 --> Helper loaded: security_helper
INFO - 2024-03-31 04:20:39 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:20:39 --> Database Driver Class Initialized
INFO - 2024-03-31 04:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:20:39 --> Parser Class Initialized
INFO - 2024-03-31 04:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:20:39 --> Pagination Class Initialized
INFO - 2024-03-31 04:20:39 --> Form Validation Class Initialized
INFO - 2024-03-31 04:20:39 --> Controller Class Initialized
INFO - 2024-03-31 04:20:39 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:39 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:39 --> Model Class Initialized
INFO - 2024-03-31 04:20:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-31 04:20:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:20:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:20:39 --> Model Class Initialized
INFO - 2024-03-31 04:20:39 --> Model Class Initialized
INFO - 2024-03-31 04:20:39 --> Model Class Initialized
INFO - 2024-03-31 04:20:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:20:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:20:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:20:39 --> Final output sent to browser
DEBUG - 2024-03-31 04:20:39 --> Total execution time: 0.2011
ERROR - 2024-03-31 04:20:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:20:40 --> Config Class Initialized
INFO - 2024-03-31 04:20:40 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:20:40 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:20:40 --> Utf8 Class Initialized
INFO - 2024-03-31 04:20:40 --> URI Class Initialized
INFO - 2024-03-31 04:20:40 --> Router Class Initialized
INFO - 2024-03-31 04:20:40 --> Output Class Initialized
INFO - 2024-03-31 04:20:40 --> Security Class Initialized
DEBUG - 2024-03-31 04:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:20:40 --> Input Class Initialized
INFO - 2024-03-31 04:20:40 --> Language Class Initialized
INFO - 2024-03-31 04:20:40 --> Loader Class Initialized
INFO - 2024-03-31 04:20:40 --> Helper loaded: url_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: file_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: html_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: text_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: form_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: security_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:20:40 --> Database Driver Class Initialized
INFO - 2024-03-31 04:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:20:40 --> Parser Class Initialized
INFO - 2024-03-31 04:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:20:40 --> Pagination Class Initialized
INFO - 2024-03-31 04:20:40 --> Form Validation Class Initialized
INFO - 2024-03-31 04:20:40 --> Controller Class Initialized
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
INFO - 2024-03-31 04:20:40 --> Final output sent to browser
DEBUG - 2024-03-31 04:20:40 --> Total execution time: 0.0421
ERROR - 2024-03-31 04:20:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:20:40 --> Config Class Initialized
INFO - 2024-03-31 04:20:40 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:20:40 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:20:40 --> Utf8 Class Initialized
INFO - 2024-03-31 04:20:40 --> URI Class Initialized
DEBUG - 2024-03-31 04:20:40 --> No URI present. Default controller set.
INFO - 2024-03-31 04:20:40 --> Router Class Initialized
INFO - 2024-03-31 04:20:40 --> Output Class Initialized
INFO - 2024-03-31 04:20:40 --> Security Class Initialized
DEBUG - 2024-03-31 04:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:20:40 --> Input Class Initialized
INFO - 2024-03-31 04:20:40 --> Language Class Initialized
INFO - 2024-03-31 04:20:40 --> Loader Class Initialized
INFO - 2024-03-31 04:20:40 --> Helper loaded: url_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: file_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: html_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: text_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: form_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: security_helper
INFO - 2024-03-31 04:20:40 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:20:40 --> Database Driver Class Initialized
INFO - 2024-03-31 04:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:20:40 --> Parser Class Initialized
INFO - 2024-03-31 04:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:20:40 --> Pagination Class Initialized
INFO - 2024-03-31 04:20:40 --> Form Validation Class Initialized
INFO - 2024-03-31 04:20:40 --> Controller Class Initialized
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
DEBUG - 2024-03-31 04:20:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
INFO - 2024-03-31 04:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-31 04:20:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:20:40 --> Model Class Initialized
INFO - 2024-03-31 04:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:20:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:20:40 --> Final output sent to browser
DEBUG - 2024-03-31 04:20:40 --> Total execution time: 0.2685
ERROR - 2024-03-31 04:21:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:21:10 --> Config Class Initialized
INFO - 2024-03-31 04:21:10 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:21:10 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:21:10 --> Utf8 Class Initialized
INFO - 2024-03-31 04:21:10 --> URI Class Initialized
INFO - 2024-03-31 04:21:10 --> Router Class Initialized
INFO - 2024-03-31 04:21:10 --> Output Class Initialized
INFO - 2024-03-31 04:21:10 --> Security Class Initialized
DEBUG - 2024-03-31 04:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:21:10 --> Input Class Initialized
INFO - 2024-03-31 04:21:10 --> Language Class Initialized
INFO - 2024-03-31 04:21:10 --> Loader Class Initialized
INFO - 2024-03-31 04:21:10 --> Helper loaded: url_helper
INFO - 2024-03-31 04:21:10 --> Helper loaded: file_helper
INFO - 2024-03-31 04:21:10 --> Helper loaded: html_helper
INFO - 2024-03-31 04:21:10 --> Helper loaded: text_helper
INFO - 2024-03-31 04:21:10 --> Helper loaded: form_helper
INFO - 2024-03-31 04:21:10 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:21:10 --> Helper loaded: security_helper
INFO - 2024-03-31 04:21:10 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:21:10 --> Database Driver Class Initialized
INFO - 2024-03-31 04:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:21:10 --> Parser Class Initialized
INFO - 2024-03-31 04:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:21:10 --> Pagination Class Initialized
INFO - 2024-03-31 04:21:10 --> Form Validation Class Initialized
INFO - 2024-03-31 04:21:10 --> Controller Class Initialized
INFO - 2024-03-31 04:21:10 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:10 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:10 --> Model Class Initialized
INFO - 2024-03-31 04:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-31 04:21:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:21:10 --> Model Class Initialized
INFO - 2024-03-31 04:21:10 --> Model Class Initialized
INFO - 2024-03-31 04:21:10 --> Model Class Initialized
INFO - 2024-03-31 04:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:21:10 --> Final output sent to browser
DEBUG - 2024-03-31 04:21:10 --> Total execution time: 0.1912
ERROR - 2024-03-31 04:21:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:21:11 --> Config Class Initialized
INFO - 2024-03-31 04:21:11 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:21:11 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:21:11 --> Utf8 Class Initialized
INFO - 2024-03-31 04:21:11 --> URI Class Initialized
INFO - 2024-03-31 04:21:11 --> Router Class Initialized
INFO - 2024-03-31 04:21:11 --> Output Class Initialized
INFO - 2024-03-31 04:21:11 --> Security Class Initialized
DEBUG - 2024-03-31 04:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:21:11 --> Input Class Initialized
INFO - 2024-03-31 04:21:11 --> Language Class Initialized
INFO - 2024-03-31 04:21:11 --> Loader Class Initialized
INFO - 2024-03-31 04:21:11 --> Helper loaded: url_helper
INFO - 2024-03-31 04:21:11 --> Helper loaded: file_helper
INFO - 2024-03-31 04:21:11 --> Helper loaded: html_helper
INFO - 2024-03-31 04:21:11 --> Helper loaded: text_helper
INFO - 2024-03-31 04:21:11 --> Helper loaded: form_helper
INFO - 2024-03-31 04:21:11 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:21:11 --> Helper loaded: security_helper
INFO - 2024-03-31 04:21:11 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:21:11 --> Database Driver Class Initialized
INFO - 2024-03-31 04:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:21:11 --> Parser Class Initialized
INFO - 2024-03-31 04:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:21:11 --> Pagination Class Initialized
INFO - 2024-03-31 04:21:11 --> Form Validation Class Initialized
INFO - 2024-03-31 04:21:11 --> Controller Class Initialized
INFO - 2024-03-31 04:21:11 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:11 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:11 --> Model Class Initialized
INFO - 2024-03-31 04:21:11 --> Final output sent to browser
DEBUG - 2024-03-31 04:21:11 --> Total execution time: 0.0421
ERROR - 2024-03-31 04:21:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:21:25 --> Config Class Initialized
INFO - 2024-03-31 04:21:25 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:21:25 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:21:25 --> Utf8 Class Initialized
INFO - 2024-03-31 04:21:25 --> URI Class Initialized
INFO - 2024-03-31 04:21:25 --> Router Class Initialized
INFO - 2024-03-31 04:21:25 --> Output Class Initialized
INFO - 2024-03-31 04:21:25 --> Security Class Initialized
DEBUG - 2024-03-31 04:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:21:25 --> Input Class Initialized
INFO - 2024-03-31 04:21:25 --> Language Class Initialized
INFO - 2024-03-31 04:21:25 --> Loader Class Initialized
INFO - 2024-03-31 04:21:25 --> Helper loaded: url_helper
INFO - 2024-03-31 04:21:25 --> Helper loaded: file_helper
INFO - 2024-03-31 04:21:25 --> Helper loaded: html_helper
INFO - 2024-03-31 04:21:25 --> Helper loaded: text_helper
INFO - 2024-03-31 04:21:25 --> Helper loaded: form_helper
INFO - 2024-03-31 04:21:25 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:21:25 --> Helper loaded: security_helper
INFO - 2024-03-31 04:21:25 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:21:25 --> Database Driver Class Initialized
INFO - 2024-03-31 04:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:21:25 --> Parser Class Initialized
INFO - 2024-03-31 04:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:21:25 --> Pagination Class Initialized
INFO - 2024-03-31 04:21:25 --> Form Validation Class Initialized
INFO - 2024-03-31 04:21:25 --> Controller Class Initialized
INFO - 2024-03-31 04:21:25 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:25 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:25 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-31 04:21:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:21:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:21:25 --> Model Class Initialized
INFO - 2024-03-31 04:21:25 --> Model Class Initialized
INFO - 2024-03-31 04:21:25 --> Model Class Initialized
INFO - 2024-03-31 04:21:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:21:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:21:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:21:25 --> Final output sent to browser
DEBUG - 2024-03-31 04:21:25 --> Total execution time: 0.1809
ERROR - 2024-03-31 04:21:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:21:34 --> Config Class Initialized
INFO - 2024-03-31 04:21:34 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:21:34 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:21:34 --> Utf8 Class Initialized
INFO - 2024-03-31 04:21:34 --> URI Class Initialized
INFO - 2024-03-31 04:21:34 --> Router Class Initialized
INFO - 2024-03-31 04:21:34 --> Output Class Initialized
INFO - 2024-03-31 04:21:34 --> Security Class Initialized
DEBUG - 2024-03-31 04:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:21:35 --> Input Class Initialized
INFO - 2024-03-31 04:21:35 --> Language Class Initialized
INFO - 2024-03-31 04:21:35 --> Loader Class Initialized
INFO - 2024-03-31 04:21:35 --> Helper loaded: url_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: file_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: html_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: text_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: form_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: security_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:21:35 --> Database Driver Class Initialized
INFO - 2024-03-31 04:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:21:35 --> Parser Class Initialized
INFO - 2024-03-31 04:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:21:35 --> Pagination Class Initialized
INFO - 2024-03-31 04:21:35 --> Form Validation Class Initialized
INFO - 2024-03-31 04:21:35 --> Controller Class Initialized
INFO - 2024-03-31 04:21:35 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:35 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:35 --> Model Class Initialized
INFO - 2024-03-31 04:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-31 04:21:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:21:35 --> Model Class Initialized
INFO - 2024-03-31 04:21:35 --> Model Class Initialized
INFO - 2024-03-31 04:21:35 --> Model Class Initialized
INFO - 2024-03-31 04:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:21:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:21:35 --> Final output sent to browser
DEBUG - 2024-03-31 04:21:35 --> Total execution time: 0.1657
ERROR - 2024-03-31 04:21:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:21:35 --> Config Class Initialized
INFO - 2024-03-31 04:21:35 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:21:35 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:21:35 --> Utf8 Class Initialized
INFO - 2024-03-31 04:21:35 --> URI Class Initialized
INFO - 2024-03-31 04:21:35 --> Router Class Initialized
INFO - 2024-03-31 04:21:35 --> Output Class Initialized
INFO - 2024-03-31 04:21:35 --> Security Class Initialized
DEBUG - 2024-03-31 04:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:21:35 --> Input Class Initialized
INFO - 2024-03-31 04:21:35 --> Language Class Initialized
INFO - 2024-03-31 04:21:35 --> Loader Class Initialized
INFO - 2024-03-31 04:21:35 --> Helper loaded: url_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: file_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: html_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: text_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: form_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: security_helper
INFO - 2024-03-31 04:21:35 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:21:35 --> Database Driver Class Initialized
INFO - 2024-03-31 04:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:21:35 --> Parser Class Initialized
INFO - 2024-03-31 04:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:21:35 --> Pagination Class Initialized
INFO - 2024-03-31 04:21:35 --> Form Validation Class Initialized
INFO - 2024-03-31 04:21:35 --> Controller Class Initialized
INFO - 2024-03-31 04:21:35 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:35 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:35 --> Model Class Initialized
INFO - 2024-03-31 04:21:35 --> Final output sent to browser
DEBUG - 2024-03-31 04:21:35 --> Total execution time: 0.0450
ERROR - 2024-03-31 04:21:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 04:21:44 --> Config Class Initialized
INFO - 2024-03-31 04:21:44 --> Hooks Class Initialized
DEBUG - 2024-03-31 04:21:44 --> UTF-8 Support Enabled
INFO - 2024-03-31 04:21:44 --> Utf8 Class Initialized
INFO - 2024-03-31 04:21:44 --> URI Class Initialized
DEBUG - 2024-03-31 04:21:44 --> No URI present. Default controller set.
INFO - 2024-03-31 04:21:44 --> Router Class Initialized
INFO - 2024-03-31 04:21:44 --> Output Class Initialized
INFO - 2024-03-31 04:21:44 --> Security Class Initialized
DEBUG - 2024-03-31 04:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 04:21:44 --> Input Class Initialized
INFO - 2024-03-31 04:21:44 --> Language Class Initialized
INFO - 2024-03-31 04:21:44 --> Loader Class Initialized
INFO - 2024-03-31 04:21:44 --> Helper loaded: url_helper
INFO - 2024-03-31 04:21:44 --> Helper loaded: file_helper
INFO - 2024-03-31 04:21:44 --> Helper loaded: html_helper
INFO - 2024-03-31 04:21:44 --> Helper loaded: text_helper
INFO - 2024-03-31 04:21:44 --> Helper loaded: form_helper
INFO - 2024-03-31 04:21:44 --> Helper loaded: lang_helper
INFO - 2024-03-31 04:21:44 --> Helper loaded: security_helper
INFO - 2024-03-31 04:21:44 --> Helper loaded: cookie_helper
INFO - 2024-03-31 04:21:44 --> Database Driver Class Initialized
INFO - 2024-03-31 04:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 04:21:44 --> Parser Class Initialized
INFO - 2024-03-31 04:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 04:21:44 --> Pagination Class Initialized
INFO - 2024-03-31 04:21:44 --> Form Validation Class Initialized
INFO - 2024-03-31 04:21:44 --> Controller Class Initialized
INFO - 2024-03-31 04:21:44 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:44 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:44 --> Model Class Initialized
INFO - 2024-03-31 04:21:44 --> Model Class Initialized
INFO - 2024-03-31 04:21:44 --> Model Class Initialized
INFO - 2024-03-31 04:21:44 --> Model Class Initialized
DEBUG - 2024-03-31 04:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 04:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:44 --> Model Class Initialized
INFO - 2024-03-31 04:21:44 --> Model Class Initialized
INFO - 2024-03-31 04:21:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-31 04:21:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 04:21:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 04:21:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 04:21:45 --> Model Class Initialized
INFO - 2024-03-31 04:21:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 04:21:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 04:21:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 04:21:45 --> Final output sent to browser
DEBUG - 2024-03-31 04:21:45 --> Total execution time: 0.2783
ERROR - 2024-03-31 06:46:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:06 --> Config Class Initialized
INFO - 2024-03-31 06:46:06 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:06 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:06 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:06 --> URI Class Initialized
DEBUG - 2024-03-31 06:46:06 --> No URI present. Default controller set.
INFO - 2024-03-31 06:46:06 --> Router Class Initialized
INFO - 2024-03-31 06:46:06 --> Output Class Initialized
INFO - 2024-03-31 06:46:06 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:06 --> Input Class Initialized
INFO - 2024-03-31 06:46:06 --> Language Class Initialized
INFO - 2024-03-31 06:46:06 --> Loader Class Initialized
INFO - 2024-03-31 06:46:06 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:06 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:06 --> Parser Class Initialized
INFO - 2024-03-31 06:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:06 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:06 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:06 --> Controller Class Initialized
INFO - 2024-03-31 06:46:06 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-31 06:46:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:06 --> Config Class Initialized
INFO - 2024-03-31 06:46:06 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:06 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:06 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:06 --> URI Class Initialized
INFO - 2024-03-31 06:46:06 --> Router Class Initialized
INFO - 2024-03-31 06:46:06 --> Output Class Initialized
INFO - 2024-03-31 06:46:06 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:06 --> Input Class Initialized
INFO - 2024-03-31 06:46:06 --> Language Class Initialized
INFO - 2024-03-31 06:46:06 --> Loader Class Initialized
INFO - 2024-03-31 06:46:06 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:06 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:06 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:06 --> Parser Class Initialized
INFO - 2024-03-31 06:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:06 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:06 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:06 --> Controller Class Initialized
INFO - 2024-03-31 06:46:06 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-31 06:46:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 06:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 06:46:06 --> Model Class Initialized
INFO - 2024-03-31 06:46:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 06:46:06 --> Final output sent to browser
DEBUG - 2024-03-31 06:46:06 --> Total execution time: 0.0370
ERROR - 2024-03-31 06:46:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:11 --> Config Class Initialized
INFO - 2024-03-31 06:46:11 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:11 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:11 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:11 --> URI Class Initialized
INFO - 2024-03-31 06:46:11 --> Router Class Initialized
INFO - 2024-03-31 06:46:11 --> Output Class Initialized
INFO - 2024-03-31 06:46:11 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:11 --> Input Class Initialized
INFO - 2024-03-31 06:46:11 --> Language Class Initialized
INFO - 2024-03-31 06:46:11 --> Loader Class Initialized
INFO - 2024-03-31 06:46:11 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:11 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:11 --> Parser Class Initialized
INFO - 2024-03-31 06:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:11 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:11 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:11 --> Controller Class Initialized
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
INFO - 2024-03-31 06:46:11 --> Final output sent to browser
DEBUG - 2024-03-31 06:46:11 --> Total execution time: 0.0201
ERROR - 2024-03-31 06:46:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:11 --> Config Class Initialized
INFO - 2024-03-31 06:46:11 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:11 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:11 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:11 --> URI Class Initialized
DEBUG - 2024-03-31 06:46:11 --> No URI present. Default controller set.
INFO - 2024-03-31 06:46:11 --> Router Class Initialized
INFO - 2024-03-31 06:46:11 --> Output Class Initialized
INFO - 2024-03-31 06:46:11 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:11 --> Input Class Initialized
INFO - 2024-03-31 06:46:11 --> Language Class Initialized
INFO - 2024-03-31 06:46:11 --> Loader Class Initialized
INFO - 2024-03-31 06:46:11 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:11 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:11 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:11 --> Parser Class Initialized
INFO - 2024-03-31 06:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:11 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:11 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:11 --> Controller Class Initialized
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 06:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
INFO - 2024-03-31 06:46:11 --> Model Class Initialized
INFO - 2024-03-31 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-31 06:46:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 06:46:12 --> Model Class Initialized
INFO - 2024-03-31 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 06:46:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 06:46:12 --> Final output sent to browser
DEBUG - 2024-03-31 06:46:12 --> Total execution time: 0.5314
ERROR - 2024-03-31 06:46:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:13 --> Config Class Initialized
INFO - 2024-03-31 06:46:13 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:13 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:13 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:13 --> URI Class Initialized
INFO - 2024-03-31 06:46:13 --> Router Class Initialized
INFO - 2024-03-31 06:46:13 --> Output Class Initialized
INFO - 2024-03-31 06:46:13 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:13 --> Input Class Initialized
INFO - 2024-03-31 06:46:13 --> Language Class Initialized
INFO - 2024-03-31 06:46:13 --> Loader Class Initialized
INFO - 2024-03-31 06:46:13 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:13 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:13 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:13 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:13 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:13 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:13 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:13 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:13 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:13 --> Parser Class Initialized
INFO - 2024-03-31 06:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:13 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:13 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:13 --> Controller Class Initialized
DEBUG - 2024-03-31 06:46:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 06:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:13 --> Model Class Initialized
INFO - 2024-03-31 06:46:13 --> Final output sent to browser
DEBUG - 2024-03-31 06:46:13 --> Total execution time: 0.0154
ERROR - 2024-03-31 06:46:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:19 --> Config Class Initialized
INFO - 2024-03-31 06:46:19 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:19 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:19 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:19 --> URI Class Initialized
INFO - 2024-03-31 06:46:19 --> Router Class Initialized
INFO - 2024-03-31 06:46:19 --> Output Class Initialized
INFO - 2024-03-31 06:46:19 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:19 --> Input Class Initialized
INFO - 2024-03-31 06:46:19 --> Language Class Initialized
INFO - 2024-03-31 06:46:19 --> Loader Class Initialized
INFO - 2024-03-31 06:46:19 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:19 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:19 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:19 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:19 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:19 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:19 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:19 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:19 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:19 --> Parser Class Initialized
INFO - 2024-03-31 06:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:19 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:19 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:19 --> Controller Class Initialized
INFO - 2024-03-31 06:46:19 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 06:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:19 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:19 --> Model Class Initialized
INFO - 2024-03-31 06:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-31 06:46:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 06:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 06:46:19 --> Model Class Initialized
INFO - 2024-03-31 06:46:19 --> Model Class Initialized
INFO - 2024-03-31 06:46:19 --> Model Class Initialized
INFO - 2024-03-31 06:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 06:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 06:46:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 06:46:19 --> Final output sent to browser
DEBUG - 2024-03-31 06:46:19 --> Total execution time: 0.2386
ERROR - 2024-03-31 06:46:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:20 --> Config Class Initialized
INFO - 2024-03-31 06:46:20 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:20 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:20 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:20 --> URI Class Initialized
INFO - 2024-03-31 06:46:20 --> Router Class Initialized
INFO - 2024-03-31 06:46:20 --> Output Class Initialized
INFO - 2024-03-31 06:46:20 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:20 --> Input Class Initialized
INFO - 2024-03-31 06:46:20 --> Language Class Initialized
INFO - 2024-03-31 06:46:20 --> Loader Class Initialized
INFO - 2024-03-31 06:46:20 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:20 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:20 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:20 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:20 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:20 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:20 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:20 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:20 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:20 --> Parser Class Initialized
INFO - 2024-03-31 06:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:20 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:20 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:20 --> Controller Class Initialized
INFO - 2024-03-31 06:46:20 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 06:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:20 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:20 --> Model Class Initialized
INFO - 2024-03-31 06:46:20 --> Final output sent to browser
DEBUG - 2024-03-31 06:46:20 --> Total execution time: 0.0688
ERROR - 2024-03-31 06:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:28 --> Config Class Initialized
INFO - 2024-03-31 06:46:28 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:28 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:28 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:28 --> URI Class Initialized
INFO - 2024-03-31 06:46:28 --> Router Class Initialized
INFO - 2024-03-31 06:46:28 --> Output Class Initialized
INFO - 2024-03-31 06:46:28 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:28 --> Input Class Initialized
INFO - 2024-03-31 06:46:28 --> Language Class Initialized
INFO - 2024-03-31 06:46:28 --> Loader Class Initialized
INFO - 2024-03-31 06:46:28 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:28 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:28 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:28 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:28 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:28 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:28 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:28 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:28 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:28 --> Parser Class Initialized
INFO - 2024-03-31 06:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:28 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:28 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:28 --> Controller Class Initialized
INFO - 2024-03-31 06:46:28 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 06:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:28 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:28 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-31 06:46:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 06:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 06:46:28 --> Model Class Initialized
INFO - 2024-03-31 06:46:28 --> Model Class Initialized
INFO - 2024-03-31 06:46:28 --> Model Class Initialized
INFO - 2024-03-31 06:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 06:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 06:46:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 06:46:28 --> Final output sent to browser
DEBUG - 2024-03-31 06:46:28 --> Total execution time: 0.2547
ERROR - 2024-03-31 06:46:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:59 --> Config Class Initialized
INFO - 2024-03-31 06:46:59 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:59 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:59 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:59 --> URI Class Initialized
INFO - 2024-03-31 06:46:59 --> Router Class Initialized
INFO - 2024-03-31 06:46:59 --> Output Class Initialized
INFO - 2024-03-31 06:46:59 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:59 --> Input Class Initialized
INFO - 2024-03-31 06:46:59 --> Language Class Initialized
INFO - 2024-03-31 06:46:59 --> Loader Class Initialized
INFO - 2024-03-31 06:46:59 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:59 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:59 --> Parser Class Initialized
INFO - 2024-03-31 06:46:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:59 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:59 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:59 --> Controller Class Initialized
INFO - 2024-03-31 06:46:59 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 06:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:59 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:59 --> Model Class Initialized
INFO - 2024-03-31 06:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-31 06:46:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-31 06:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-31 06:46:59 --> Model Class Initialized
INFO - 2024-03-31 06:46:59 --> Model Class Initialized
INFO - 2024-03-31 06:46:59 --> Model Class Initialized
INFO - 2024-03-31 06:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-31 06:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-31 06:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-31 06:46:59 --> Final output sent to browser
DEBUG - 2024-03-31 06:46:59 --> Total execution time: 0.2393
ERROR - 2024-03-31 06:46:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:46:59 --> Config Class Initialized
INFO - 2024-03-31 06:46:59 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:46:59 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:46:59 --> Utf8 Class Initialized
INFO - 2024-03-31 06:46:59 --> URI Class Initialized
INFO - 2024-03-31 06:46:59 --> Router Class Initialized
INFO - 2024-03-31 06:46:59 --> Output Class Initialized
INFO - 2024-03-31 06:46:59 --> Security Class Initialized
DEBUG - 2024-03-31 06:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:46:59 --> Input Class Initialized
INFO - 2024-03-31 06:46:59 --> Language Class Initialized
INFO - 2024-03-31 06:46:59 --> Loader Class Initialized
INFO - 2024-03-31 06:46:59 --> Helper loaded: url_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: file_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: html_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: text_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: form_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: security_helper
INFO - 2024-03-31 06:46:59 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:46:59 --> Database Driver Class Initialized
INFO - 2024-03-31 06:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:46:59 --> Parser Class Initialized
INFO - 2024-03-31 06:46:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:46:59 --> Pagination Class Initialized
INFO - 2024-03-31 06:46:59 --> Form Validation Class Initialized
INFO - 2024-03-31 06:46:59 --> Controller Class Initialized
INFO - 2024-03-31 06:46:59 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 06:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:59 --> Model Class Initialized
DEBUG - 2024-03-31 06:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:46:59 --> Model Class Initialized
INFO - 2024-03-31 06:46:59 --> Final output sent to browser
DEBUG - 2024-03-31 06:46:59 --> Total execution time: 0.0749
ERROR - 2024-03-31 06:47:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 06:47:02 --> Config Class Initialized
INFO - 2024-03-31 06:47:02 --> Hooks Class Initialized
DEBUG - 2024-03-31 06:47:02 --> UTF-8 Support Enabled
INFO - 2024-03-31 06:47:02 --> Utf8 Class Initialized
INFO - 2024-03-31 06:47:02 --> URI Class Initialized
INFO - 2024-03-31 06:47:02 --> Router Class Initialized
INFO - 2024-03-31 06:47:02 --> Output Class Initialized
INFO - 2024-03-31 06:47:02 --> Security Class Initialized
DEBUG - 2024-03-31 06:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 06:47:02 --> Input Class Initialized
INFO - 2024-03-31 06:47:02 --> Language Class Initialized
INFO - 2024-03-31 06:47:02 --> Loader Class Initialized
INFO - 2024-03-31 06:47:02 --> Helper loaded: url_helper
INFO - 2024-03-31 06:47:02 --> Helper loaded: file_helper
INFO - 2024-03-31 06:47:02 --> Helper loaded: html_helper
INFO - 2024-03-31 06:47:02 --> Helper loaded: text_helper
INFO - 2024-03-31 06:47:02 --> Helper loaded: form_helper
INFO - 2024-03-31 06:47:02 --> Helper loaded: lang_helper
INFO - 2024-03-31 06:47:02 --> Helper loaded: security_helper
INFO - 2024-03-31 06:47:02 --> Helper loaded: cookie_helper
INFO - 2024-03-31 06:47:02 --> Database Driver Class Initialized
INFO - 2024-03-31 06:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 06:47:02 --> Parser Class Initialized
INFO - 2024-03-31 06:47:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 06:47:02 --> Pagination Class Initialized
INFO - 2024-03-31 06:47:02 --> Form Validation Class Initialized
INFO - 2024-03-31 06:47:02 --> Controller Class Initialized
INFO - 2024-03-31 06:47:02 --> Model Class Initialized
DEBUG - 2024-03-31 06:47:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-31 06:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:47:02 --> Model Class Initialized
DEBUG - 2024-03-31 06:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-31 06:47:02 --> Model Class Initialized
INFO - 2024-03-31 06:47:04 --> Final output sent to browser
DEBUG - 2024-03-31 06:47:04 --> Total execution time: 1.6867
ERROR - 2024-03-31 08:45:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 08:45:39 --> Config Class Initialized
INFO - 2024-03-31 08:45:39 --> Hooks Class Initialized
DEBUG - 2024-03-31 08:45:39 --> UTF-8 Support Enabled
INFO - 2024-03-31 08:45:39 --> Utf8 Class Initialized
INFO - 2024-03-31 08:45:39 --> URI Class Initialized
DEBUG - 2024-03-31 08:45:39 --> No URI present. Default controller set.
INFO - 2024-03-31 08:45:39 --> Router Class Initialized
INFO - 2024-03-31 08:45:39 --> Output Class Initialized
INFO - 2024-03-31 08:45:39 --> Security Class Initialized
DEBUG - 2024-03-31 08:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 08:45:39 --> Input Class Initialized
INFO - 2024-03-31 08:45:39 --> Language Class Initialized
INFO - 2024-03-31 08:45:39 --> Loader Class Initialized
INFO - 2024-03-31 08:45:39 --> Helper loaded: url_helper
INFO - 2024-03-31 08:45:39 --> Helper loaded: file_helper
INFO - 2024-03-31 08:45:39 --> Helper loaded: html_helper
INFO - 2024-03-31 08:45:39 --> Helper loaded: text_helper
INFO - 2024-03-31 08:45:39 --> Helper loaded: form_helper
INFO - 2024-03-31 08:45:39 --> Helper loaded: lang_helper
INFO - 2024-03-31 08:45:39 --> Helper loaded: security_helper
INFO - 2024-03-31 08:45:39 --> Helper loaded: cookie_helper
INFO - 2024-03-31 08:45:39 --> Database Driver Class Initialized
INFO - 2024-03-31 08:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-31 08:45:39 --> Parser Class Initialized
INFO - 2024-03-31 08:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-31 08:45:39 --> Pagination Class Initialized
INFO - 2024-03-31 08:45:39 --> Form Validation Class Initialized
INFO - 2024-03-31 08:45:39 --> Controller Class Initialized
INFO - 2024-03-31 08:45:39 --> Model Class Initialized
DEBUG - 2024-03-31 08:45:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-31 13:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 13:58:16 --> Config Class Initialized
INFO - 2024-03-31 13:58:16 --> Hooks Class Initialized
DEBUG - 2024-03-31 13:58:16 --> UTF-8 Support Enabled
INFO - 2024-03-31 13:58:16 --> Utf8 Class Initialized
INFO - 2024-03-31 13:58:16 --> URI Class Initialized
INFO - 2024-03-31 13:58:16 --> Router Class Initialized
INFO - 2024-03-31 13:58:16 --> Output Class Initialized
INFO - 2024-03-31 13:58:16 --> Security Class Initialized
DEBUG - 2024-03-31 13:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 13:58:16 --> Input Class Initialized
INFO - 2024-03-31 13:58:16 --> Language Class Initialized
ERROR - 2024-03-31 13:58:16 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-31 19:28:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-31 19:28:20 --> Config Class Initialized
INFO - 2024-03-31 19:28:20 --> Hooks Class Initialized
DEBUG - 2024-03-31 19:28:20 --> UTF-8 Support Enabled
INFO - 2024-03-31 19:28:20 --> Utf8 Class Initialized
INFO - 2024-03-31 19:28:20 --> URI Class Initialized
INFO - 2024-03-31 19:28:20 --> Router Class Initialized
INFO - 2024-03-31 19:28:20 --> Output Class Initialized
INFO - 2024-03-31 19:28:20 --> Security Class Initialized
DEBUG - 2024-03-31 19:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-31 19:28:20 --> Input Class Initialized
INFO - 2024-03-31 19:28:20 --> Language Class Initialized
ERROR - 2024-03-31 19:28:20 --> 404 Page Not Found: Well-known/assetlinks.json
