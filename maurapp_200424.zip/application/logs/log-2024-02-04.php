<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-04 02:23:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 02:23:47 --> Config Class Initialized
INFO - 2024-02-04 02:23:47 --> Hooks Class Initialized
DEBUG - 2024-02-04 02:23:47 --> UTF-8 Support Enabled
INFO - 2024-02-04 02:23:47 --> Utf8 Class Initialized
INFO - 2024-02-04 02:23:47 --> URI Class Initialized
INFO - 2024-02-04 02:23:47 --> Router Class Initialized
INFO - 2024-02-04 02:23:47 --> Output Class Initialized
INFO - 2024-02-04 02:23:47 --> Security Class Initialized
DEBUG - 2024-02-04 02:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 02:23:47 --> Input Class Initialized
INFO - 2024-02-04 02:23:47 --> Language Class Initialized
ERROR - 2024-02-04 02:23:47 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-04 03:51:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:51:38 --> Config Class Initialized
INFO - 2024-02-04 03:51:38 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:51:38 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:51:38 --> Utf8 Class Initialized
INFO - 2024-02-04 03:51:38 --> URI Class Initialized
DEBUG - 2024-02-04 03:51:38 --> No URI present. Default controller set.
INFO - 2024-02-04 03:51:38 --> Router Class Initialized
INFO - 2024-02-04 03:51:38 --> Output Class Initialized
INFO - 2024-02-04 03:51:38 --> Security Class Initialized
DEBUG - 2024-02-04 03:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:51:38 --> Input Class Initialized
INFO - 2024-02-04 03:51:38 --> Language Class Initialized
INFO - 2024-02-04 03:51:38 --> Loader Class Initialized
INFO - 2024-02-04 03:51:38 --> Helper loaded: url_helper
INFO - 2024-02-04 03:51:38 --> Helper loaded: file_helper
INFO - 2024-02-04 03:51:38 --> Helper loaded: html_helper
INFO - 2024-02-04 03:51:38 --> Helper loaded: text_helper
INFO - 2024-02-04 03:51:38 --> Helper loaded: form_helper
INFO - 2024-02-04 03:51:38 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:51:38 --> Helper loaded: security_helper
INFO - 2024-02-04 03:51:38 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:51:38 --> Database Driver Class Initialized
INFO - 2024-02-04 03:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:51:38 --> Parser Class Initialized
INFO - 2024-02-04 03:51:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:51:38 --> Pagination Class Initialized
INFO - 2024-02-04 03:51:38 --> Form Validation Class Initialized
INFO - 2024-02-04 03:51:38 --> Controller Class Initialized
INFO - 2024-02-04 03:51:38 --> Model Class Initialized
DEBUG - 2024-02-04 03:51:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-04 03:51:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:51:39 --> Config Class Initialized
INFO - 2024-02-04 03:51:39 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:51:39 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:51:39 --> Utf8 Class Initialized
INFO - 2024-02-04 03:51:39 --> URI Class Initialized
INFO - 2024-02-04 03:51:39 --> Router Class Initialized
INFO - 2024-02-04 03:51:39 --> Output Class Initialized
INFO - 2024-02-04 03:51:39 --> Security Class Initialized
DEBUG - 2024-02-04 03:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:51:39 --> Input Class Initialized
INFO - 2024-02-04 03:51:39 --> Language Class Initialized
INFO - 2024-02-04 03:51:39 --> Loader Class Initialized
INFO - 2024-02-04 03:51:39 --> Helper loaded: url_helper
INFO - 2024-02-04 03:51:39 --> Helper loaded: file_helper
INFO - 2024-02-04 03:51:39 --> Helper loaded: html_helper
INFO - 2024-02-04 03:51:39 --> Helper loaded: text_helper
INFO - 2024-02-04 03:51:39 --> Helper loaded: form_helper
INFO - 2024-02-04 03:51:39 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:51:39 --> Helper loaded: security_helper
INFO - 2024-02-04 03:51:39 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:51:39 --> Database Driver Class Initialized
INFO - 2024-02-04 03:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:51:39 --> Parser Class Initialized
INFO - 2024-02-04 03:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:51:39 --> Pagination Class Initialized
INFO - 2024-02-04 03:51:39 --> Form Validation Class Initialized
INFO - 2024-02-04 03:51:39 --> Controller Class Initialized
INFO - 2024-02-04 03:51:39 --> Model Class Initialized
DEBUG - 2024-02-04 03:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:51:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-04 03:51:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:51:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-04 03:51:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-04 03:51:39 --> Model Class Initialized
INFO - 2024-02-04 03:51:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-04 03:51:39 --> Final output sent to browser
DEBUG - 2024-02-04 03:51:39 --> Total execution time: 0.0337
ERROR - 2024-02-04 03:52:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:52:01 --> Config Class Initialized
INFO - 2024-02-04 03:52:01 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:52:01 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:52:01 --> Utf8 Class Initialized
INFO - 2024-02-04 03:52:01 --> URI Class Initialized
INFO - 2024-02-04 03:52:01 --> Router Class Initialized
INFO - 2024-02-04 03:52:01 --> Output Class Initialized
INFO - 2024-02-04 03:52:01 --> Security Class Initialized
DEBUG - 2024-02-04 03:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:52:01 --> Input Class Initialized
INFO - 2024-02-04 03:52:01 --> Language Class Initialized
INFO - 2024-02-04 03:52:01 --> Loader Class Initialized
INFO - 2024-02-04 03:52:01 --> Helper loaded: url_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: file_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: html_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: text_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: form_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: security_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:52:01 --> Database Driver Class Initialized
INFO - 2024-02-04 03:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:52:01 --> Parser Class Initialized
INFO - 2024-02-04 03:52:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:52:01 --> Pagination Class Initialized
INFO - 2024-02-04 03:52:01 --> Form Validation Class Initialized
INFO - 2024-02-04 03:52:01 --> Controller Class Initialized
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
INFO - 2024-02-04 03:52:01 --> Final output sent to browser
DEBUG - 2024-02-04 03:52:01 --> Total execution time: 0.0214
ERROR - 2024-02-04 03:52:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:52:01 --> Config Class Initialized
INFO - 2024-02-04 03:52:01 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:52:01 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:52:01 --> Utf8 Class Initialized
INFO - 2024-02-04 03:52:01 --> URI Class Initialized
DEBUG - 2024-02-04 03:52:01 --> No URI present. Default controller set.
INFO - 2024-02-04 03:52:01 --> Router Class Initialized
INFO - 2024-02-04 03:52:01 --> Output Class Initialized
INFO - 2024-02-04 03:52:01 --> Security Class Initialized
DEBUG - 2024-02-04 03:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:52:01 --> Input Class Initialized
INFO - 2024-02-04 03:52:01 --> Language Class Initialized
INFO - 2024-02-04 03:52:01 --> Loader Class Initialized
INFO - 2024-02-04 03:52:01 --> Helper loaded: url_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: file_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: html_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: text_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: form_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: security_helper
INFO - 2024-02-04 03:52:01 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:52:01 --> Database Driver Class Initialized
INFO - 2024-02-04 03:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:52:01 --> Parser Class Initialized
INFO - 2024-02-04 03:52:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:52:01 --> Pagination Class Initialized
INFO - 2024-02-04 03:52:01 --> Form Validation Class Initialized
INFO - 2024-02-04 03:52:01 --> Controller Class Initialized
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 03:52:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
INFO - 2024-02-04 03:52:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-04 03:52:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-04 03:52:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-04 03:52:01 --> Model Class Initialized
INFO - 2024-02-04 03:52:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-04 03:52:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-04 03:52:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-04 03:52:02 --> Final output sent to browser
DEBUG - 2024-02-04 03:52:02 --> Total execution time: 0.2409
ERROR - 2024-02-04 03:52:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:52:15 --> Config Class Initialized
INFO - 2024-02-04 03:52:15 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:52:15 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:52:15 --> Utf8 Class Initialized
INFO - 2024-02-04 03:52:15 --> URI Class Initialized
INFO - 2024-02-04 03:52:15 --> Router Class Initialized
INFO - 2024-02-04 03:52:15 --> Output Class Initialized
INFO - 2024-02-04 03:52:15 --> Security Class Initialized
DEBUG - 2024-02-04 03:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:52:15 --> Input Class Initialized
INFO - 2024-02-04 03:52:15 --> Language Class Initialized
INFO - 2024-02-04 03:52:15 --> Loader Class Initialized
INFO - 2024-02-04 03:52:15 --> Helper loaded: url_helper
INFO - 2024-02-04 03:52:15 --> Helper loaded: file_helper
INFO - 2024-02-04 03:52:15 --> Helper loaded: html_helper
INFO - 2024-02-04 03:52:15 --> Helper loaded: text_helper
INFO - 2024-02-04 03:52:15 --> Helper loaded: form_helper
INFO - 2024-02-04 03:52:15 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:52:15 --> Helper loaded: security_helper
INFO - 2024-02-04 03:52:15 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:52:15 --> Database Driver Class Initialized
INFO - 2024-02-04 03:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:52:15 --> Parser Class Initialized
INFO - 2024-02-04 03:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:52:15 --> Pagination Class Initialized
INFO - 2024-02-04 03:52:15 --> Form Validation Class Initialized
INFO - 2024-02-04 03:52:15 --> Controller Class Initialized
INFO - 2024-02-04 03:52:15 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 03:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:15 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:15 --> Model Class Initialized
INFO - 2024-02-04 03:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-04 03:52:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-04 03:52:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-04 03:52:16 --> Model Class Initialized
INFO - 2024-02-04 03:52:16 --> Model Class Initialized
INFO - 2024-02-04 03:52:16 --> Model Class Initialized
INFO - 2024-02-04 03:52:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-04 03:52:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-04 03:52:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-04 03:52:16 --> Final output sent to browser
DEBUG - 2024-02-04 03:52:16 --> Total execution time: 0.1694
ERROR - 2024-02-04 03:52:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:52:16 --> Config Class Initialized
INFO - 2024-02-04 03:52:16 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:52:16 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:52:16 --> Utf8 Class Initialized
INFO - 2024-02-04 03:52:16 --> URI Class Initialized
INFO - 2024-02-04 03:52:16 --> Router Class Initialized
INFO - 2024-02-04 03:52:16 --> Output Class Initialized
INFO - 2024-02-04 03:52:16 --> Security Class Initialized
DEBUG - 2024-02-04 03:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:52:16 --> Input Class Initialized
INFO - 2024-02-04 03:52:16 --> Language Class Initialized
INFO - 2024-02-04 03:52:16 --> Loader Class Initialized
INFO - 2024-02-04 03:52:16 --> Helper loaded: url_helper
INFO - 2024-02-04 03:52:16 --> Helper loaded: file_helper
INFO - 2024-02-04 03:52:16 --> Helper loaded: html_helper
INFO - 2024-02-04 03:52:16 --> Helper loaded: text_helper
INFO - 2024-02-04 03:52:16 --> Helper loaded: form_helper
INFO - 2024-02-04 03:52:16 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:52:16 --> Helper loaded: security_helper
INFO - 2024-02-04 03:52:16 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:52:16 --> Database Driver Class Initialized
INFO - 2024-02-04 03:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:52:16 --> Parser Class Initialized
INFO - 2024-02-04 03:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:52:16 --> Pagination Class Initialized
INFO - 2024-02-04 03:52:16 --> Form Validation Class Initialized
INFO - 2024-02-04 03:52:16 --> Controller Class Initialized
INFO - 2024-02-04 03:52:16 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 03:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:16 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:16 --> Model Class Initialized
INFO - 2024-02-04 03:52:16 --> Final output sent to browser
DEBUG - 2024-02-04 03:52:16 --> Total execution time: 0.0415
ERROR - 2024-02-04 03:52:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:52:19 --> Config Class Initialized
INFO - 2024-02-04 03:52:19 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:52:19 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:52:19 --> Utf8 Class Initialized
INFO - 2024-02-04 03:52:19 --> URI Class Initialized
INFO - 2024-02-04 03:52:20 --> Router Class Initialized
INFO - 2024-02-04 03:52:20 --> Output Class Initialized
INFO - 2024-02-04 03:52:20 --> Security Class Initialized
DEBUG - 2024-02-04 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:52:20 --> Input Class Initialized
INFO - 2024-02-04 03:52:20 --> Language Class Initialized
INFO - 2024-02-04 03:52:20 --> Loader Class Initialized
INFO - 2024-02-04 03:52:20 --> Helper loaded: url_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: file_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: html_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: text_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: form_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: security_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:52:20 --> Database Driver Class Initialized
INFO - 2024-02-04 03:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:52:20 --> Parser Class Initialized
INFO - 2024-02-04 03:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:52:20 --> Pagination Class Initialized
INFO - 2024-02-04 03:52:20 --> Form Validation Class Initialized
INFO - 2024-02-04 03:52:20 --> Controller Class Initialized
INFO - 2024-02-04 03:52:20 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 03:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:20 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:20 --> Model Class Initialized
INFO - 2024-02-04 03:52:20 --> Final output sent to browser
DEBUG - 2024-02-04 03:52:20 --> Total execution time: 0.0425
ERROR - 2024-02-04 03:52:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:52:20 --> Config Class Initialized
INFO - 2024-02-04 03:52:20 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:52:20 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:52:20 --> Utf8 Class Initialized
INFO - 2024-02-04 03:52:20 --> URI Class Initialized
INFO - 2024-02-04 03:52:20 --> Router Class Initialized
INFO - 2024-02-04 03:52:20 --> Output Class Initialized
INFO - 2024-02-04 03:52:20 --> Security Class Initialized
DEBUG - 2024-02-04 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:52:20 --> Input Class Initialized
INFO - 2024-02-04 03:52:20 --> Language Class Initialized
INFO - 2024-02-04 03:52:20 --> Loader Class Initialized
INFO - 2024-02-04 03:52:20 --> Helper loaded: url_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: file_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: html_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: text_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: form_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: security_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:52:20 --> Database Driver Class Initialized
INFO - 2024-02-04 03:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:52:20 --> Parser Class Initialized
INFO - 2024-02-04 03:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:52:20 --> Pagination Class Initialized
INFO - 2024-02-04 03:52:20 --> Form Validation Class Initialized
INFO - 2024-02-04 03:52:20 --> Controller Class Initialized
INFO - 2024-02-04 03:52:20 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 03:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:20 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:20 --> Model Class Initialized
INFO - 2024-02-04 03:52:20 --> Final output sent to browser
DEBUG - 2024-02-04 03:52:20 --> Total execution time: 0.0345
ERROR - 2024-02-04 03:52:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:52:20 --> Config Class Initialized
INFO - 2024-02-04 03:52:20 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:52:20 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:52:20 --> Utf8 Class Initialized
INFO - 2024-02-04 03:52:20 --> URI Class Initialized
INFO - 2024-02-04 03:52:20 --> Router Class Initialized
INFO - 2024-02-04 03:52:20 --> Output Class Initialized
INFO - 2024-02-04 03:52:20 --> Security Class Initialized
DEBUG - 2024-02-04 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:52:20 --> Input Class Initialized
INFO - 2024-02-04 03:52:20 --> Language Class Initialized
INFO - 2024-02-04 03:52:20 --> Loader Class Initialized
INFO - 2024-02-04 03:52:20 --> Helper loaded: url_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: file_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: html_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: text_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: form_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: security_helper
INFO - 2024-02-04 03:52:20 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:52:20 --> Database Driver Class Initialized
INFO - 2024-02-04 03:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:52:20 --> Parser Class Initialized
INFO - 2024-02-04 03:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:52:20 --> Pagination Class Initialized
INFO - 2024-02-04 03:52:20 --> Form Validation Class Initialized
INFO - 2024-02-04 03:52:20 --> Controller Class Initialized
INFO - 2024-02-04 03:52:20 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 03:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:20 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:20 --> Model Class Initialized
INFO - 2024-02-04 03:52:20 --> Final output sent to browser
DEBUG - 2024-02-04 03:52:20 --> Total execution time: 0.0339
ERROR - 2024-02-04 03:52:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 03:52:32 --> Config Class Initialized
INFO - 2024-02-04 03:52:32 --> Hooks Class Initialized
DEBUG - 2024-02-04 03:52:32 --> UTF-8 Support Enabled
INFO - 2024-02-04 03:52:32 --> Utf8 Class Initialized
INFO - 2024-02-04 03:52:32 --> URI Class Initialized
INFO - 2024-02-04 03:52:32 --> Router Class Initialized
INFO - 2024-02-04 03:52:32 --> Output Class Initialized
INFO - 2024-02-04 03:52:32 --> Security Class Initialized
DEBUG - 2024-02-04 03:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 03:52:32 --> Input Class Initialized
INFO - 2024-02-04 03:52:32 --> Language Class Initialized
INFO - 2024-02-04 03:52:32 --> Loader Class Initialized
INFO - 2024-02-04 03:52:32 --> Helper loaded: url_helper
INFO - 2024-02-04 03:52:32 --> Helper loaded: file_helper
INFO - 2024-02-04 03:52:32 --> Helper loaded: html_helper
INFO - 2024-02-04 03:52:32 --> Helper loaded: text_helper
INFO - 2024-02-04 03:52:32 --> Helper loaded: form_helper
INFO - 2024-02-04 03:52:32 --> Helper loaded: lang_helper
INFO - 2024-02-04 03:52:32 --> Helper loaded: security_helper
INFO - 2024-02-04 03:52:32 --> Helper loaded: cookie_helper
INFO - 2024-02-04 03:52:32 --> Database Driver Class Initialized
INFO - 2024-02-04 03:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 03:52:32 --> Parser Class Initialized
INFO - 2024-02-04 03:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 03:52:32 --> Pagination Class Initialized
INFO - 2024-02-04 03:52:32 --> Form Validation Class Initialized
INFO - 2024-02-04 03:52:32 --> Controller Class Initialized
INFO - 2024-02-04 03:52:32 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 03:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:32 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:32 --> Model Class Initialized
DEBUG - 2024-02-04 03:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-04 03:52:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-04 03:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-04 03:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-04 03:52:32 --> Model Class Initialized
INFO - 2024-02-04 03:52:32 --> Model Class Initialized
INFO - 2024-02-04 03:52:32 --> Model Class Initialized
INFO - 2024-02-04 03:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-04 03:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-04 03:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-04 03:52:32 --> Final output sent to browser
DEBUG - 2024-02-04 03:52:32 --> Total execution time: 0.1598
ERROR - 2024-02-04 07:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 07:33:40 --> Config Class Initialized
INFO - 2024-02-04 07:33:40 --> Hooks Class Initialized
DEBUG - 2024-02-04 07:33:40 --> UTF-8 Support Enabled
INFO - 2024-02-04 07:33:40 --> Utf8 Class Initialized
INFO - 2024-02-04 07:33:40 --> URI Class Initialized
DEBUG - 2024-02-04 07:33:40 --> No URI present. Default controller set.
INFO - 2024-02-04 07:33:40 --> Router Class Initialized
INFO - 2024-02-04 07:33:40 --> Output Class Initialized
INFO - 2024-02-04 07:33:40 --> Security Class Initialized
DEBUG - 2024-02-04 07:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 07:33:40 --> Input Class Initialized
INFO - 2024-02-04 07:33:40 --> Language Class Initialized
INFO - 2024-02-04 07:33:40 --> Loader Class Initialized
INFO - 2024-02-04 07:33:40 --> Helper loaded: url_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: file_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: html_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: text_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: form_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: lang_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: security_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: cookie_helper
INFO - 2024-02-04 07:33:40 --> Database Driver Class Initialized
INFO - 2024-02-04 07:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 07:33:40 --> Parser Class Initialized
INFO - 2024-02-04 07:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 07:33:40 --> Pagination Class Initialized
INFO - 2024-02-04 07:33:40 --> Form Validation Class Initialized
INFO - 2024-02-04 07:33:40 --> Controller Class Initialized
INFO - 2024-02-04 07:33:40 --> Model Class Initialized
DEBUG - 2024-02-04 07:33:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-04 07:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 07:33:40 --> Config Class Initialized
INFO - 2024-02-04 07:33:40 --> Hooks Class Initialized
DEBUG - 2024-02-04 07:33:40 --> UTF-8 Support Enabled
INFO - 2024-02-04 07:33:40 --> Utf8 Class Initialized
INFO - 2024-02-04 07:33:40 --> URI Class Initialized
DEBUG - 2024-02-04 07:33:40 --> No URI present. Default controller set.
INFO - 2024-02-04 07:33:40 --> Router Class Initialized
INFO - 2024-02-04 07:33:40 --> Output Class Initialized
INFO - 2024-02-04 07:33:40 --> Security Class Initialized
DEBUG - 2024-02-04 07:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 07:33:40 --> Input Class Initialized
INFO - 2024-02-04 07:33:40 --> Language Class Initialized
INFO - 2024-02-04 07:33:40 --> Loader Class Initialized
INFO - 2024-02-04 07:33:40 --> Helper loaded: url_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: file_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: html_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: text_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: form_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: lang_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: security_helper
INFO - 2024-02-04 07:33:40 --> Helper loaded: cookie_helper
INFO - 2024-02-04 07:33:40 --> Database Driver Class Initialized
INFO - 2024-02-04 07:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 07:33:40 --> Parser Class Initialized
INFO - 2024-02-04 07:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 07:33:40 --> Pagination Class Initialized
INFO - 2024-02-04 07:33:41 --> Form Validation Class Initialized
INFO - 2024-02-04 07:33:41 --> Controller Class Initialized
INFO - 2024-02-04 07:33:41 --> Model Class Initialized
DEBUG - 2024-02-04 07:33:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-04 07:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 07:33:41 --> Config Class Initialized
INFO - 2024-02-04 07:33:41 --> Hooks Class Initialized
DEBUG - 2024-02-04 07:33:41 --> UTF-8 Support Enabled
INFO - 2024-02-04 07:33:41 --> Utf8 Class Initialized
INFO - 2024-02-04 07:33:41 --> URI Class Initialized
DEBUG - 2024-02-04 07:33:41 --> No URI present. Default controller set.
INFO - 2024-02-04 07:33:41 --> Router Class Initialized
INFO - 2024-02-04 07:33:41 --> Output Class Initialized
INFO - 2024-02-04 07:33:41 --> Security Class Initialized
DEBUG - 2024-02-04 07:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 07:33:41 --> Input Class Initialized
INFO - 2024-02-04 07:33:41 --> Language Class Initialized
INFO - 2024-02-04 07:33:41 --> Loader Class Initialized
INFO - 2024-02-04 07:33:41 --> Helper loaded: url_helper
INFO - 2024-02-04 07:33:41 --> Helper loaded: file_helper
INFO - 2024-02-04 07:33:41 --> Helper loaded: html_helper
INFO - 2024-02-04 07:33:41 --> Helper loaded: text_helper
INFO - 2024-02-04 07:33:41 --> Helper loaded: form_helper
INFO - 2024-02-04 07:33:41 --> Helper loaded: lang_helper
INFO - 2024-02-04 07:33:41 --> Helper loaded: security_helper
INFO - 2024-02-04 07:33:41 --> Helper loaded: cookie_helper
INFO - 2024-02-04 07:33:41 --> Database Driver Class Initialized
INFO - 2024-02-04 07:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 07:33:41 --> Parser Class Initialized
INFO - 2024-02-04 07:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 07:33:41 --> Pagination Class Initialized
INFO - 2024-02-04 07:33:41 --> Form Validation Class Initialized
INFO - 2024-02-04 07:33:41 --> Controller Class Initialized
INFO - 2024-02-04 07:33:41 --> Model Class Initialized
DEBUG - 2024-02-04 07:33:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-04 07:33:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 07:33:42 --> Config Class Initialized
INFO - 2024-02-04 07:33:42 --> Hooks Class Initialized
DEBUG - 2024-02-04 07:33:42 --> UTF-8 Support Enabled
INFO - 2024-02-04 07:33:42 --> Utf8 Class Initialized
INFO - 2024-02-04 07:33:42 --> URI Class Initialized
DEBUG - 2024-02-04 07:33:42 --> No URI present. Default controller set.
INFO - 2024-02-04 07:33:42 --> Router Class Initialized
INFO - 2024-02-04 07:33:42 --> Output Class Initialized
INFO - 2024-02-04 07:33:42 --> Security Class Initialized
DEBUG - 2024-02-04 07:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 07:33:42 --> Input Class Initialized
INFO - 2024-02-04 07:33:42 --> Language Class Initialized
INFO - 2024-02-04 07:33:42 --> Loader Class Initialized
INFO - 2024-02-04 07:33:42 --> Helper loaded: url_helper
INFO - 2024-02-04 07:33:42 --> Helper loaded: file_helper
INFO - 2024-02-04 07:33:42 --> Helper loaded: html_helper
INFO - 2024-02-04 07:33:42 --> Helper loaded: text_helper
INFO - 2024-02-04 07:33:42 --> Helper loaded: form_helper
INFO - 2024-02-04 07:33:42 --> Helper loaded: lang_helper
INFO - 2024-02-04 07:33:42 --> Helper loaded: security_helper
INFO - 2024-02-04 07:33:42 --> Helper loaded: cookie_helper
INFO - 2024-02-04 07:33:42 --> Database Driver Class Initialized
INFO - 2024-02-04 07:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 07:33:42 --> Parser Class Initialized
INFO - 2024-02-04 07:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 07:33:42 --> Pagination Class Initialized
INFO - 2024-02-04 07:33:42 --> Form Validation Class Initialized
INFO - 2024-02-04 07:33:42 --> Controller Class Initialized
INFO - 2024-02-04 07:33:42 --> Model Class Initialized
DEBUG - 2024-02-04 07:33:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-04 10:43:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 10:43:02 --> Config Class Initialized
INFO - 2024-02-04 10:43:02 --> Hooks Class Initialized
DEBUG - 2024-02-04 10:43:02 --> UTF-8 Support Enabled
INFO - 2024-02-04 10:43:02 --> Utf8 Class Initialized
INFO - 2024-02-04 10:43:02 --> URI Class Initialized
DEBUG - 2024-02-04 10:43:02 --> No URI present. Default controller set.
INFO - 2024-02-04 10:43:02 --> Router Class Initialized
INFO - 2024-02-04 10:43:02 --> Output Class Initialized
INFO - 2024-02-04 10:43:02 --> Security Class Initialized
DEBUG - 2024-02-04 10:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 10:43:02 --> Input Class Initialized
INFO - 2024-02-04 10:43:02 --> Language Class Initialized
INFO - 2024-02-04 10:43:02 --> Loader Class Initialized
INFO - 2024-02-04 10:43:02 --> Helper loaded: url_helper
INFO - 2024-02-04 10:43:02 --> Helper loaded: file_helper
INFO - 2024-02-04 10:43:02 --> Helper loaded: html_helper
INFO - 2024-02-04 10:43:02 --> Helper loaded: text_helper
INFO - 2024-02-04 10:43:02 --> Helper loaded: form_helper
INFO - 2024-02-04 10:43:02 --> Helper loaded: lang_helper
INFO - 2024-02-04 10:43:02 --> Helper loaded: security_helper
INFO - 2024-02-04 10:43:02 --> Helper loaded: cookie_helper
INFO - 2024-02-04 10:43:02 --> Database Driver Class Initialized
INFO - 2024-02-04 10:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 10:43:02 --> Parser Class Initialized
INFO - 2024-02-04 10:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 10:43:02 --> Pagination Class Initialized
INFO - 2024-02-04 10:43:02 --> Form Validation Class Initialized
INFO - 2024-02-04 10:43:02 --> Controller Class Initialized
INFO - 2024-02-04 10:43:02 --> Model Class Initialized
DEBUG - 2024-02-04 10:43:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-04 13:21:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 13:21:41 --> Config Class Initialized
INFO - 2024-02-04 13:21:41 --> Hooks Class Initialized
DEBUG - 2024-02-04 13:21:41 --> UTF-8 Support Enabled
INFO - 2024-02-04 13:21:41 --> Utf8 Class Initialized
INFO - 2024-02-04 13:21:41 --> URI Class Initialized
DEBUG - 2024-02-04 13:21:41 --> No URI present. Default controller set.
INFO - 2024-02-04 13:21:41 --> Router Class Initialized
INFO - 2024-02-04 13:21:41 --> Output Class Initialized
INFO - 2024-02-04 13:21:41 --> Security Class Initialized
DEBUG - 2024-02-04 13:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 13:21:41 --> Input Class Initialized
INFO - 2024-02-04 13:21:41 --> Language Class Initialized
INFO - 2024-02-04 13:21:41 --> Loader Class Initialized
INFO - 2024-02-04 13:21:41 --> Helper loaded: url_helper
INFO - 2024-02-04 13:21:41 --> Helper loaded: file_helper
INFO - 2024-02-04 13:21:41 --> Helper loaded: html_helper
INFO - 2024-02-04 13:21:41 --> Helper loaded: text_helper
INFO - 2024-02-04 13:21:41 --> Helper loaded: form_helper
INFO - 2024-02-04 13:21:41 --> Helper loaded: lang_helper
INFO - 2024-02-04 13:21:41 --> Helper loaded: security_helper
INFO - 2024-02-04 13:21:41 --> Helper loaded: cookie_helper
INFO - 2024-02-04 13:21:41 --> Database Driver Class Initialized
INFO - 2024-02-04 13:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 13:21:41 --> Parser Class Initialized
INFO - 2024-02-04 13:21:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 13:21:41 --> Pagination Class Initialized
INFO - 2024-02-04 13:21:41 --> Form Validation Class Initialized
INFO - 2024-02-04 13:21:41 --> Controller Class Initialized
INFO - 2024-02-04 13:21:41 --> Model Class Initialized
DEBUG - 2024-02-04 13:21:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-04 13:21:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 13:21:42 --> Config Class Initialized
INFO - 2024-02-04 13:21:42 --> Hooks Class Initialized
DEBUG - 2024-02-04 13:21:42 --> UTF-8 Support Enabled
INFO - 2024-02-04 13:21:42 --> Utf8 Class Initialized
INFO - 2024-02-04 13:21:42 --> URI Class Initialized
INFO - 2024-02-04 13:21:42 --> Router Class Initialized
INFO - 2024-02-04 13:21:42 --> Output Class Initialized
INFO - 2024-02-04 13:21:42 --> Security Class Initialized
DEBUG - 2024-02-04 13:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 13:21:42 --> Input Class Initialized
INFO - 2024-02-04 13:21:42 --> Language Class Initialized
INFO - 2024-02-04 13:21:42 --> Loader Class Initialized
INFO - 2024-02-04 13:21:42 --> Helper loaded: url_helper
INFO - 2024-02-04 13:21:42 --> Helper loaded: file_helper
INFO - 2024-02-04 13:21:42 --> Helper loaded: html_helper
INFO - 2024-02-04 13:21:42 --> Helper loaded: text_helper
INFO - 2024-02-04 13:21:42 --> Helper loaded: form_helper
INFO - 2024-02-04 13:21:42 --> Helper loaded: lang_helper
INFO - 2024-02-04 13:21:42 --> Helper loaded: security_helper
INFO - 2024-02-04 13:21:42 --> Helper loaded: cookie_helper
INFO - 2024-02-04 13:21:42 --> Database Driver Class Initialized
INFO - 2024-02-04 13:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 13:21:42 --> Parser Class Initialized
INFO - 2024-02-04 13:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-04 13:21:42 --> Pagination Class Initialized
INFO - 2024-02-04 13:21:42 --> Form Validation Class Initialized
INFO - 2024-02-04 13:21:42 --> Controller Class Initialized
INFO - 2024-02-04 13:21:42 --> Model Class Initialized
DEBUG - 2024-02-04 13:21:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-04 13:21:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-04 13:21:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-04 13:21:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-04 13:21:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-04 13:21:42 --> Model Class Initialized
INFO - 2024-02-04 13:21:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-04 13:21:42 --> Final output sent to browser
DEBUG - 2024-02-04 13:21:42 --> Total execution time: 0.0337
ERROR - 2024-02-04 15:06:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-04 15:06:17 --> Config Class Initialized
INFO - 2024-02-04 15:06:17 --> Hooks Class Initialized
DEBUG - 2024-02-04 15:06:17 --> UTF-8 Support Enabled
INFO - 2024-02-04 15:06:17 --> Utf8 Class Initialized
INFO - 2024-02-04 15:06:17 --> URI Class Initialized
INFO - 2024-02-04 15:06:17 --> Router Class Initialized
INFO - 2024-02-04 15:06:17 --> Output Class Initialized
INFO - 2024-02-04 15:06:17 --> Security Class Initialized
DEBUG - 2024-02-04 15:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 15:06:17 --> Input Class Initialized
INFO - 2024-02-04 15:06:17 --> Language Class Initialized
ERROR - 2024-02-04 15:06:17 --> 404 Page Not Found: Well-known/assetlinks.json
