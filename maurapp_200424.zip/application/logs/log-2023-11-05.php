<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-05 04:36:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 04:36:22 --> Config Class Initialized
INFO - 2023-11-05 04:36:22 --> Hooks Class Initialized
DEBUG - 2023-11-05 04:36:22 --> UTF-8 Support Enabled
INFO - 2023-11-05 04:36:22 --> Utf8 Class Initialized
INFO - 2023-11-05 04:36:22 --> URI Class Initialized
DEBUG - 2023-11-05 04:36:22 --> No URI present. Default controller set.
INFO - 2023-11-05 04:36:22 --> Router Class Initialized
INFO - 2023-11-05 04:36:22 --> Output Class Initialized
INFO - 2023-11-05 04:36:22 --> Security Class Initialized
DEBUG - 2023-11-05 04:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 04:36:22 --> Input Class Initialized
INFO - 2023-11-05 04:36:22 --> Language Class Initialized
INFO - 2023-11-05 04:36:22 --> Loader Class Initialized
INFO - 2023-11-05 04:36:22 --> Helper loaded: url_helper
INFO - 2023-11-05 04:36:22 --> Helper loaded: file_helper
INFO - 2023-11-05 04:36:22 --> Helper loaded: html_helper
INFO - 2023-11-05 04:36:22 --> Helper loaded: text_helper
INFO - 2023-11-05 04:36:22 --> Helper loaded: form_helper
INFO - 2023-11-05 04:36:22 --> Helper loaded: lang_helper
INFO - 2023-11-05 04:36:22 --> Helper loaded: security_helper
INFO - 2023-11-05 04:36:22 --> Helper loaded: cookie_helper
INFO - 2023-11-05 04:36:22 --> Database Driver Class Initialized
INFO - 2023-11-05 04:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 04:36:22 --> Parser Class Initialized
INFO - 2023-11-05 04:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 04:36:22 --> Pagination Class Initialized
INFO - 2023-11-05 04:36:22 --> Form Validation Class Initialized
INFO - 2023-11-05 04:36:22 --> Controller Class Initialized
INFO - 2023-11-05 04:36:22 --> Model Class Initialized
DEBUG - 2023-11-05 04:36:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-05 04:36:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 04:36:24 --> Config Class Initialized
INFO - 2023-11-05 04:36:24 --> Hooks Class Initialized
DEBUG - 2023-11-05 04:36:24 --> UTF-8 Support Enabled
INFO - 2023-11-05 04:36:24 --> Utf8 Class Initialized
INFO - 2023-11-05 04:36:24 --> URI Class Initialized
INFO - 2023-11-05 04:36:24 --> Router Class Initialized
INFO - 2023-11-05 04:36:24 --> Output Class Initialized
INFO - 2023-11-05 04:36:24 --> Security Class Initialized
DEBUG - 2023-11-05 04:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 04:36:24 --> Input Class Initialized
INFO - 2023-11-05 04:36:24 --> Language Class Initialized
INFO - 2023-11-05 04:36:24 --> Loader Class Initialized
INFO - 2023-11-05 04:36:24 --> Helper loaded: url_helper
INFO - 2023-11-05 04:36:24 --> Helper loaded: file_helper
INFO - 2023-11-05 04:36:24 --> Helper loaded: html_helper
INFO - 2023-11-05 04:36:24 --> Helper loaded: text_helper
INFO - 2023-11-05 04:36:24 --> Helper loaded: form_helper
INFO - 2023-11-05 04:36:24 --> Helper loaded: lang_helper
INFO - 2023-11-05 04:36:24 --> Helper loaded: security_helper
INFO - 2023-11-05 04:36:24 --> Helper loaded: cookie_helper
INFO - 2023-11-05 04:36:24 --> Database Driver Class Initialized
INFO - 2023-11-05 04:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 04:36:24 --> Parser Class Initialized
INFO - 2023-11-05 04:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 04:36:24 --> Pagination Class Initialized
INFO - 2023-11-05 04:36:24 --> Form Validation Class Initialized
INFO - 2023-11-05 04:36:24 --> Controller Class Initialized
INFO - 2023-11-05 04:36:24 --> Model Class Initialized
DEBUG - 2023-11-05 04:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 04:36:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 04:36:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 04:36:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 04:36:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 04:36:24 --> Model Class Initialized
INFO - 2023-11-05 04:36:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 04:36:24 --> Final output sent to browser
DEBUG - 2023-11-05 04:36:24 --> Total execution time: 0.0334
ERROR - 2023-11-05 04:43:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 04:43:28 --> Config Class Initialized
INFO - 2023-11-05 04:43:28 --> Hooks Class Initialized
DEBUG - 2023-11-05 04:43:28 --> UTF-8 Support Enabled
INFO - 2023-11-05 04:43:28 --> Utf8 Class Initialized
INFO - 2023-11-05 04:43:28 --> URI Class Initialized
DEBUG - 2023-11-05 04:43:28 --> No URI present. Default controller set.
INFO - 2023-11-05 04:43:28 --> Router Class Initialized
INFO - 2023-11-05 04:43:28 --> Output Class Initialized
INFO - 2023-11-05 04:43:28 --> Security Class Initialized
DEBUG - 2023-11-05 04:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 04:43:28 --> Input Class Initialized
INFO - 2023-11-05 04:43:28 --> Language Class Initialized
INFO - 2023-11-05 04:43:28 --> Loader Class Initialized
INFO - 2023-11-05 04:43:28 --> Helper loaded: url_helper
INFO - 2023-11-05 04:43:28 --> Helper loaded: file_helper
INFO - 2023-11-05 04:43:28 --> Helper loaded: html_helper
INFO - 2023-11-05 04:43:28 --> Helper loaded: text_helper
INFO - 2023-11-05 04:43:28 --> Helper loaded: form_helper
INFO - 2023-11-05 04:43:28 --> Helper loaded: lang_helper
INFO - 2023-11-05 04:43:28 --> Helper loaded: security_helper
INFO - 2023-11-05 04:43:28 --> Helper loaded: cookie_helper
INFO - 2023-11-05 04:43:28 --> Database Driver Class Initialized
INFO - 2023-11-05 04:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 04:43:28 --> Parser Class Initialized
INFO - 2023-11-05 04:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 04:43:28 --> Pagination Class Initialized
INFO - 2023-11-05 04:43:28 --> Form Validation Class Initialized
INFO - 2023-11-05 04:43:28 --> Controller Class Initialized
INFO - 2023-11-05 04:43:28 --> Model Class Initialized
DEBUG - 2023-11-05 04:43:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-05 05:03:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 05:03:54 --> Config Class Initialized
INFO - 2023-11-05 05:03:54 --> Hooks Class Initialized
DEBUG - 2023-11-05 05:03:54 --> UTF-8 Support Enabled
INFO - 2023-11-05 05:03:54 --> Utf8 Class Initialized
INFO - 2023-11-05 05:03:54 --> URI Class Initialized
INFO - 2023-11-05 05:03:54 --> Router Class Initialized
INFO - 2023-11-05 05:03:54 --> Output Class Initialized
INFO - 2023-11-05 05:03:54 --> Security Class Initialized
DEBUG - 2023-11-05 05:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 05:03:54 --> Input Class Initialized
INFO - 2023-11-05 05:03:54 --> Language Class Initialized
ERROR - 2023-11-05 05:03:54 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-05 10:22:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:22:59 --> Config Class Initialized
INFO - 2023-11-05 10:22:59 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:22:59 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:22:59 --> Utf8 Class Initialized
INFO - 2023-11-05 10:22:59 --> URI Class Initialized
DEBUG - 2023-11-05 10:22:59 --> No URI present. Default controller set.
INFO - 2023-11-05 10:22:59 --> Router Class Initialized
INFO - 2023-11-05 10:22:59 --> Output Class Initialized
INFO - 2023-11-05 10:22:59 --> Security Class Initialized
DEBUG - 2023-11-05 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:22:59 --> Input Class Initialized
INFO - 2023-11-05 10:22:59 --> Language Class Initialized
INFO - 2023-11-05 10:22:59 --> Loader Class Initialized
INFO - 2023-11-05 10:22:59 --> Helper loaded: url_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: file_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: html_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: text_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: form_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: security_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:22:59 --> Database Driver Class Initialized
INFO - 2023-11-05 10:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:22:59 --> Parser Class Initialized
INFO - 2023-11-05 10:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:22:59 --> Pagination Class Initialized
INFO - 2023-11-05 10:22:59 --> Form Validation Class Initialized
INFO - 2023-11-05 10:22:59 --> Controller Class Initialized
INFO - 2023-11-05 10:22:59 --> Model Class Initialized
DEBUG - 2023-11-05 10:22:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-05 10:22:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:22:59 --> Config Class Initialized
INFO - 2023-11-05 10:22:59 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:22:59 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:22:59 --> Utf8 Class Initialized
INFO - 2023-11-05 10:22:59 --> URI Class Initialized
INFO - 2023-11-05 10:22:59 --> Router Class Initialized
INFO - 2023-11-05 10:22:59 --> Output Class Initialized
INFO - 2023-11-05 10:22:59 --> Security Class Initialized
DEBUG - 2023-11-05 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:22:59 --> Input Class Initialized
INFO - 2023-11-05 10:22:59 --> Language Class Initialized
INFO - 2023-11-05 10:22:59 --> Loader Class Initialized
INFO - 2023-11-05 10:22:59 --> Helper loaded: url_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: file_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: html_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: text_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: form_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: security_helper
INFO - 2023-11-05 10:22:59 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:22:59 --> Database Driver Class Initialized
INFO - 2023-11-05 10:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:22:59 --> Parser Class Initialized
INFO - 2023-11-05 10:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:22:59 --> Pagination Class Initialized
INFO - 2023-11-05 10:22:59 --> Form Validation Class Initialized
INFO - 2023-11-05 10:22:59 --> Controller Class Initialized
INFO - 2023-11-05 10:22:59 --> Model Class Initialized
DEBUG - 2023-11-05 10:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 10:22:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 10:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 10:22:59 --> Model Class Initialized
INFO - 2023-11-05 10:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 10:22:59 --> Final output sent to browser
DEBUG - 2023-11-05 10:22:59 --> Total execution time: 0.0348
ERROR - 2023-11-05 10:23:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:23:31 --> Config Class Initialized
INFO - 2023-11-05 10:23:31 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:23:31 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:23:31 --> Utf8 Class Initialized
INFO - 2023-11-05 10:23:31 --> URI Class Initialized
INFO - 2023-11-05 10:23:31 --> Router Class Initialized
INFO - 2023-11-05 10:23:31 --> Output Class Initialized
INFO - 2023-11-05 10:23:31 --> Security Class Initialized
DEBUG - 2023-11-05 10:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:23:31 --> Input Class Initialized
INFO - 2023-11-05 10:23:31 --> Language Class Initialized
INFO - 2023-11-05 10:23:31 --> Loader Class Initialized
INFO - 2023-11-05 10:23:31 --> Helper loaded: url_helper
INFO - 2023-11-05 10:23:31 --> Helper loaded: file_helper
INFO - 2023-11-05 10:23:31 --> Helper loaded: html_helper
INFO - 2023-11-05 10:23:31 --> Helper loaded: text_helper
INFO - 2023-11-05 10:23:31 --> Helper loaded: form_helper
INFO - 2023-11-05 10:23:31 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:23:31 --> Helper loaded: security_helper
INFO - 2023-11-05 10:23:31 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:23:31 --> Database Driver Class Initialized
INFO - 2023-11-05 10:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:23:31 --> Parser Class Initialized
INFO - 2023-11-05 10:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:23:31 --> Pagination Class Initialized
INFO - 2023-11-05 10:23:31 --> Form Validation Class Initialized
INFO - 2023-11-05 10:23:31 --> Controller Class Initialized
INFO - 2023-11-05 10:23:31 --> Model Class Initialized
DEBUG - 2023-11-05 10:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:23:31 --> Model Class Initialized
INFO - 2023-11-05 10:23:31 --> Final output sent to browser
DEBUG - 2023-11-05 10:23:31 --> Total execution time: 0.0232
ERROR - 2023-11-05 10:23:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:23:32 --> Config Class Initialized
INFO - 2023-11-05 10:23:32 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:23:32 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:23:32 --> Utf8 Class Initialized
INFO - 2023-11-05 10:23:32 --> URI Class Initialized
INFO - 2023-11-05 10:23:32 --> Router Class Initialized
INFO - 2023-11-05 10:23:32 --> Output Class Initialized
INFO - 2023-11-05 10:23:32 --> Security Class Initialized
DEBUG - 2023-11-05 10:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:23:32 --> Input Class Initialized
INFO - 2023-11-05 10:23:32 --> Language Class Initialized
INFO - 2023-11-05 10:23:32 --> Loader Class Initialized
INFO - 2023-11-05 10:23:32 --> Helper loaded: url_helper
INFO - 2023-11-05 10:23:32 --> Helper loaded: file_helper
INFO - 2023-11-05 10:23:32 --> Helper loaded: html_helper
INFO - 2023-11-05 10:23:32 --> Helper loaded: text_helper
INFO - 2023-11-05 10:23:32 --> Helper loaded: form_helper
INFO - 2023-11-05 10:23:32 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:23:32 --> Helper loaded: security_helper
INFO - 2023-11-05 10:23:32 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:23:32 --> Database Driver Class Initialized
INFO - 2023-11-05 10:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:23:32 --> Parser Class Initialized
INFO - 2023-11-05 10:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:23:32 --> Pagination Class Initialized
INFO - 2023-11-05 10:23:32 --> Form Validation Class Initialized
INFO - 2023-11-05 10:23:32 --> Controller Class Initialized
INFO - 2023-11-05 10:23:32 --> Model Class Initialized
DEBUG - 2023-11-05 10:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 10:23:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 10:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 10:23:32 --> Model Class Initialized
INFO - 2023-11-05 10:23:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 10:23:32 --> Final output sent to browser
DEBUG - 2023-11-05 10:23:32 --> Total execution time: 0.0293
ERROR - 2023-11-05 10:24:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:24:03 --> Config Class Initialized
INFO - 2023-11-05 10:24:03 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:24:03 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:24:03 --> Utf8 Class Initialized
INFO - 2023-11-05 10:24:03 --> URI Class Initialized
INFO - 2023-11-05 10:24:03 --> Router Class Initialized
INFO - 2023-11-05 10:24:03 --> Output Class Initialized
INFO - 2023-11-05 10:24:03 --> Security Class Initialized
DEBUG - 2023-11-05 10:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:24:03 --> Input Class Initialized
INFO - 2023-11-05 10:24:03 --> Language Class Initialized
INFO - 2023-11-05 10:24:03 --> Loader Class Initialized
INFO - 2023-11-05 10:24:03 --> Helper loaded: url_helper
INFO - 2023-11-05 10:24:03 --> Helper loaded: file_helper
INFO - 2023-11-05 10:24:03 --> Helper loaded: html_helper
INFO - 2023-11-05 10:24:03 --> Helper loaded: text_helper
INFO - 2023-11-05 10:24:03 --> Helper loaded: form_helper
INFO - 2023-11-05 10:24:03 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:24:03 --> Helper loaded: security_helper
INFO - 2023-11-05 10:24:03 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:24:03 --> Database Driver Class Initialized
INFO - 2023-11-05 10:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:24:03 --> Parser Class Initialized
INFO - 2023-11-05 10:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:24:03 --> Pagination Class Initialized
INFO - 2023-11-05 10:24:03 --> Form Validation Class Initialized
INFO - 2023-11-05 10:24:03 --> Controller Class Initialized
INFO - 2023-11-05 10:24:03 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:03 --> Model Class Initialized
INFO - 2023-11-05 10:24:03 --> Final output sent to browser
DEBUG - 2023-11-05 10:24:03 --> Total execution time: 0.0221
ERROR - 2023-11-05 10:24:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:24:04 --> Config Class Initialized
INFO - 2023-11-05 10:24:04 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:24:04 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:24:04 --> Utf8 Class Initialized
INFO - 2023-11-05 10:24:04 --> URI Class Initialized
DEBUG - 2023-11-05 10:24:04 --> No URI present. Default controller set.
INFO - 2023-11-05 10:24:04 --> Router Class Initialized
INFO - 2023-11-05 10:24:04 --> Output Class Initialized
INFO - 2023-11-05 10:24:04 --> Security Class Initialized
DEBUG - 2023-11-05 10:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:24:04 --> Input Class Initialized
INFO - 2023-11-05 10:24:04 --> Language Class Initialized
INFO - 2023-11-05 10:24:04 --> Loader Class Initialized
INFO - 2023-11-05 10:24:04 --> Helper loaded: url_helper
INFO - 2023-11-05 10:24:04 --> Helper loaded: file_helper
INFO - 2023-11-05 10:24:04 --> Helper loaded: html_helper
INFO - 2023-11-05 10:24:04 --> Helper loaded: text_helper
INFO - 2023-11-05 10:24:04 --> Helper loaded: form_helper
INFO - 2023-11-05 10:24:04 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:24:04 --> Helper loaded: security_helper
INFO - 2023-11-05 10:24:04 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:24:04 --> Database Driver Class Initialized
INFO - 2023-11-05 10:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:24:04 --> Parser Class Initialized
INFO - 2023-11-05 10:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:24:04 --> Pagination Class Initialized
INFO - 2023-11-05 10:24:04 --> Form Validation Class Initialized
INFO - 2023-11-05 10:24:04 --> Controller Class Initialized
INFO - 2023-11-05 10:24:04 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:04 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:04 --> Model Class Initialized
INFO - 2023-11-05 10:24:04 --> Model Class Initialized
INFO - 2023-11-05 10:24:04 --> Model Class Initialized
INFO - 2023-11-05 10:24:04 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 10:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:04 --> Model Class Initialized
INFO - 2023-11-05 10:24:04 --> Model Class Initialized
INFO - 2023-11-05 10:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-05 10:24:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 10:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 10:24:04 --> Model Class Initialized
INFO - 2023-11-05 10:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 10:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 10:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 10:24:04 --> Final output sent to browser
DEBUG - 2023-11-05 10:24:04 --> Total execution time: 0.3839
ERROR - 2023-11-05 10:24:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:24:05 --> Config Class Initialized
INFO - 2023-11-05 10:24:05 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:24:05 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:24:05 --> Utf8 Class Initialized
INFO - 2023-11-05 10:24:05 --> URI Class Initialized
INFO - 2023-11-05 10:24:05 --> Router Class Initialized
INFO - 2023-11-05 10:24:05 --> Output Class Initialized
INFO - 2023-11-05 10:24:05 --> Security Class Initialized
DEBUG - 2023-11-05 10:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:24:05 --> Input Class Initialized
INFO - 2023-11-05 10:24:05 --> Language Class Initialized
INFO - 2023-11-05 10:24:05 --> Loader Class Initialized
INFO - 2023-11-05 10:24:05 --> Helper loaded: url_helper
INFO - 2023-11-05 10:24:05 --> Helper loaded: file_helper
INFO - 2023-11-05 10:24:05 --> Helper loaded: html_helper
INFO - 2023-11-05 10:24:05 --> Helper loaded: text_helper
INFO - 2023-11-05 10:24:05 --> Helper loaded: form_helper
INFO - 2023-11-05 10:24:05 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:24:05 --> Helper loaded: security_helper
INFO - 2023-11-05 10:24:05 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:24:05 --> Database Driver Class Initialized
INFO - 2023-11-05 10:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:24:05 --> Parser Class Initialized
INFO - 2023-11-05 10:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:24:05 --> Pagination Class Initialized
INFO - 2023-11-05 10:24:05 --> Form Validation Class Initialized
INFO - 2023-11-05 10:24:05 --> Controller Class Initialized
DEBUG - 2023-11-05 10:24:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 10:24:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:05 --> Model Class Initialized
INFO - 2023-11-05 10:24:05 --> Final output sent to browser
DEBUG - 2023-11-05 10:24:05 --> Total execution time: 0.0131
ERROR - 2023-11-05 10:24:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:24:20 --> Config Class Initialized
INFO - 2023-11-05 10:24:20 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:24:20 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:24:20 --> Utf8 Class Initialized
INFO - 2023-11-05 10:24:20 --> URI Class Initialized
INFO - 2023-11-05 10:24:20 --> Router Class Initialized
INFO - 2023-11-05 10:24:20 --> Output Class Initialized
INFO - 2023-11-05 10:24:20 --> Security Class Initialized
DEBUG - 2023-11-05 10:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:24:20 --> Input Class Initialized
INFO - 2023-11-05 10:24:20 --> Language Class Initialized
INFO - 2023-11-05 10:24:20 --> Loader Class Initialized
INFO - 2023-11-05 10:24:20 --> Helper loaded: url_helper
INFO - 2023-11-05 10:24:20 --> Helper loaded: file_helper
INFO - 2023-11-05 10:24:20 --> Helper loaded: html_helper
INFO - 2023-11-05 10:24:20 --> Helper loaded: text_helper
INFO - 2023-11-05 10:24:20 --> Helper loaded: form_helper
INFO - 2023-11-05 10:24:20 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:24:20 --> Helper loaded: security_helper
INFO - 2023-11-05 10:24:20 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:24:20 --> Database Driver Class Initialized
INFO - 2023-11-05 10:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:24:20 --> Parser Class Initialized
INFO - 2023-11-05 10:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:24:20 --> Pagination Class Initialized
INFO - 2023-11-05 10:24:20 --> Form Validation Class Initialized
INFO - 2023-11-05 10:24:20 --> Controller Class Initialized
INFO - 2023-11-05 10:24:20 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 10:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:20 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:20 --> Model Class Initialized
INFO - 2023-11-05 10:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-05 10:24:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 10:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 10:24:20 --> Model Class Initialized
INFO - 2023-11-05 10:24:20 --> Model Class Initialized
INFO - 2023-11-05 10:24:20 --> Model Class Initialized
INFO - 2023-11-05 10:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 10:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 10:24:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 10:24:20 --> Final output sent to browser
DEBUG - 2023-11-05 10:24:20 --> Total execution time: 0.2363
ERROR - 2023-11-05 10:24:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:24:21 --> Config Class Initialized
INFO - 2023-11-05 10:24:21 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:24:21 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:24:21 --> Utf8 Class Initialized
INFO - 2023-11-05 10:24:21 --> URI Class Initialized
INFO - 2023-11-05 10:24:21 --> Router Class Initialized
INFO - 2023-11-05 10:24:21 --> Output Class Initialized
INFO - 2023-11-05 10:24:21 --> Security Class Initialized
DEBUG - 2023-11-05 10:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:24:21 --> Input Class Initialized
INFO - 2023-11-05 10:24:21 --> Language Class Initialized
INFO - 2023-11-05 10:24:21 --> Loader Class Initialized
INFO - 2023-11-05 10:24:21 --> Helper loaded: url_helper
INFO - 2023-11-05 10:24:21 --> Helper loaded: file_helper
INFO - 2023-11-05 10:24:21 --> Helper loaded: html_helper
INFO - 2023-11-05 10:24:21 --> Helper loaded: text_helper
INFO - 2023-11-05 10:24:21 --> Helper loaded: form_helper
INFO - 2023-11-05 10:24:21 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:24:21 --> Helper loaded: security_helper
INFO - 2023-11-05 10:24:21 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:24:21 --> Database Driver Class Initialized
INFO - 2023-11-05 10:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:24:21 --> Parser Class Initialized
INFO - 2023-11-05 10:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:24:21 --> Pagination Class Initialized
INFO - 2023-11-05 10:24:21 --> Form Validation Class Initialized
INFO - 2023-11-05 10:24:21 --> Controller Class Initialized
INFO - 2023-11-05 10:24:21 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 10:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:21 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:21 --> Model Class Initialized
INFO - 2023-11-05 10:24:21 --> Final output sent to browser
DEBUG - 2023-11-05 10:24:21 --> Total execution time: 0.0696
ERROR - 2023-11-05 10:24:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:24:42 --> Config Class Initialized
INFO - 2023-11-05 10:24:42 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:24:42 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:24:42 --> Utf8 Class Initialized
INFO - 2023-11-05 10:24:42 --> URI Class Initialized
INFO - 2023-11-05 10:24:42 --> Router Class Initialized
INFO - 2023-11-05 10:24:42 --> Output Class Initialized
INFO - 2023-11-05 10:24:42 --> Security Class Initialized
DEBUG - 2023-11-05 10:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:24:42 --> Input Class Initialized
INFO - 2023-11-05 10:24:42 --> Language Class Initialized
INFO - 2023-11-05 10:24:42 --> Loader Class Initialized
INFO - 2023-11-05 10:24:42 --> Helper loaded: url_helper
INFO - 2023-11-05 10:24:42 --> Helper loaded: file_helper
INFO - 2023-11-05 10:24:42 --> Helper loaded: html_helper
INFO - 2023-11-05 10:24:42 --> Helper loaded: text_helper
INFO - 2023-11-05 10:24:42 --> Helper loaded: form_helper
INFO - 2023-11-05 10:24:42 --> Helper loaded: lang_helper
INFO - 2023-11-05 10:24:42 --> Helper loaded: security_helper
INFO - 2023-11-05 10:24:42 --> Helper loaded: cookie_helper
INFO - 2023-11-05 10:24:42 --> Database Driver Class Initialized
INFO - 2023-11-05 10:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:24:42 --> Parser Class Initialized
INFO - 2023-11-05 10:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 10:24:42 --> Pagination Class Initialized
INFO - 2023-11-05 10:24:42 --> Form Validation Class Initialized
INFO - 2023-11-05 10:24:42 --> Controller Class Initialized
INFO - 2023-11-05 10:24:42 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 10:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:42 --> Model Class Initialized
DEBUG - 2023-11-05 10:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 10:24:42 --> Model Class Initialized
INFO - 2023-11-05 10:24:43 --> Final output sent to browser
DEBUG - 2023-11-05 10:24:43 --> Total execution time: 1.0155
ERROR - 2023-11-05 13:06:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:06:44 --> Config Class Initialized
INFO - 2023-11-05 13:06:44 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:06:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:06:44 --> Utf8 Class Initialized
INFO - 2023-11-05 13:06:44 --> URI Class Initialized
DEBUG - 2023-11-05 13:06:44 --> No URI present. Default controller set.
INFO - 2023-11-05 13:06:44 --> Router Class Initialized
INFO - 2023-11-05 13:06:44 --> Output Class Initialized
INFO - 2023-11-05 13:06:44 --> Security Class Initialized
DEBUG - 2023-11-05 13:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:06:44 --> Input Class Initialized
INFO - 2023-11-05 13:06:44 --> Language Class Initialized
INFO - 2023-11-05 13:06:44 --> Loader Class Initialized
INFO - 2023-11-05 13:06:44 --> Helper loaded: url_helper
INFO - 2023-11-05 13:06:44 --> Helper loaded: file_helper
INFO - 2023-11-05 13:06:44 --> Helper loaded: html_helper
INFO - 2023-11-05 13:06:44 --> Helper loaded: text_helper
INFO - 2023-11-05 13:06:44 --> Helper loaded: form_helper
INFO - 2023-11-05 13:06:44 --> Helper loaded: lang_helper
INFO - 2023-11-05 13:06:44 --> Helper loaded: security_helper
INFO - 2023-11-05 13:06:44 --> Helper loaded: cookie_helper
INFO - 2023-11-05 13:06:44 --> Database Driver Class Initialized
INFO - 2023-11-05 13:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:06:44 --> Parser Class Initialized
INFO - 2023-11-05 13:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 13:06:44 --> Pagination Class Initialized
INFO - 2023-11-05 13:06:44 --> Form Validation Class Initialized
INFO - 2023-11-05 13:06:44 --> Controller Class Initialized
INFO - 2023-11-05 13:06:44 --> Model Class Initialized
DEBUG - 2023-11-05 13:06:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-05 13:06:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:06:45 --> Config Class Initialized
INFO - 2023-11-05 13:06:45 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:06:45 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:06:45 --> Utf8 Class Initialized
INFO - 2023-11-05 13:06:45 --> URI Class Initialized
INFO - 2023-11-05 13:06:45 --> Router Class Initialized
INFO - 2023-11-05 13:06:45 --> Output Class Initialized
INFO - 2023-11-05 13:06:45 --> Security Class Initialized
DEBUG - 2023-11-05 13:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:06:45 --> Input Class Initialized
INFO - 2023-11-05 13:06:45 --> Language Class Initialized
INFO - 2023-11-05 13:06:45 --> Loader Class Initialized
INFO - 2023-11-05 13:06:45 --> Helper loaded: url_helper
INFO - 2023-11-05 13:06:45 --> Helper loaded: file_helper
INFO - 2023-11-05 13:06:45 --> Helper loaded: html_helper
INFO - 2023-11-05 13:06:45 --> Helper loaded: text_helper
INFO - 2023-11-05 13:06:45 --> Helper loaded: form_helper
INFO - 2023-11-05 13:06:45 --> Helper loaded: lang_helper
INFO - 2023-11-05 13:06:45 --> Helper loaded: security_helper
INFO - 2023-11-05 13:06:45 --> Helper loaded: cookie_helper
INFO - 2023-11-05 13:06:45 --> Database Driver Class Initialized
INFO - 2023-11-05 13:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:06:45 --> Parser Class Initialized
INFO - 2023-11-05 13:06:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 13:06:45 --> Pagination Class Initialized
INFO - 2023-11-05 13:06:45 --> Form Validation Class Initialized
INFO - 2023-11-05 13:06:45 --> Controller Class Initialized
INFO - 2023-11-05 13:06:45 --> Model Class Initialized
DEBUG - 2023-11-05 13:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 13:06:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 13:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 13:06:45 --> Model Class Initialized
INFO - 2023-11-05 13:06:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 13:06:45 --> Final output sent to browser
DEBUG - 2023-11-05 13:06:45 --> Total execution time: 0.0355
ERROR - 2023-11-05 13:07:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:07:11 --> Config Class Initialized
INFO - 2023-11-05 13:07:11 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:07:11 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:07:11 --> Utf8 Class Initialized
INFO - 2023-11-05 13:07:11 --> URI Class Initialized
INFO - 2023-11-05 13:07:11 --> Router Class Initialized
INFO - 2023-11-05 13:07:11 --> Output Class Initialized
INFO - 2023-11-05 13:07:11 --> Security Class Initialized
DEBUG - 2023-11-05 13:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:07:11 --> Input Class Initialized
INFO - 2023-11-05 13:07:11 --> Language Class Initialized
INFO - 2023-11-05 13:07:11 --> Loader Class Initialized
INFO - 2023-11-05 13:07:11 --> Helper loaded: url_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: file_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: html_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: text_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: form_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: lang_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: security_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: cookie_helper
INFO - 2023-11-05 13:07:11 --> Database Driver Class Initialized
INFO - 2023-11-05 13:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:07:11 --> Parser Class Initialized
INFO - 2023-11-05 13:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 13:07:11 --> Pagination Class Initialized
INFO - 2023-11-05 13:07:11 --> Form Validation Class Initialized
INFO - 2023-11-05 13:07:11 --> Controller Class Initialized
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
DEBUG - 2023-11-05 13:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
INFO - 2023-11-05 13:07:11 --> Final output sent to browser
DEBUG - 2023-11-05 13:07:11 --> Total execution time: 0.0215
ERROR - 2023-11-05 13:07:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:07:11 --> Config Class Initialized
INFO - 2023-11-05 13:07:11 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:07:11 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:07:11 --> Utf8 Class Initialized
INFO - 2023-11-05 13:07:11 --> URI Class Initialized
DEBUG - 2023-11-05 13:07:11 --> No URI present. Default controller set.
INFO - 2023-11-05 13:07:11 --> Router Class Initialized
INFO - 2023-11-05 13:07:11 --> Output Class Initialized
INFO - 2023-11-05 13:07:11 --> Security Class Initialized
DEBUG - 2023-11-05 13:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:07:11 --> Input Class Initialized
INFO - 2023-11-05 13:07:11 --> Language Class Initialized
INFO - 2023-11-05 13:07:11 --> Loader Class Initialized
INFO - 2023-11-05 13:07:11 --> Helper loaded: url_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: file_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: html_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: text_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: form_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: lang_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: security_helper
INFO - 2023-11-05 13:07:11 --> Helper loaded: cookie_helper
INFO - 2023-11-05 13:07:11 --> Database Driver Class Initialized
INFO - 2023-11-05 13:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:07:11 --> Parser Class Initialized
INFO - 2023-11-05 13:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 13:07:11 --> Pagination Class Initialized
INFO - 2023-11-05 13:07:11 --> Form Validation Class Initialized
INFO - 2023-11-05 13:07:11 --> Controller Class Initialized
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
DEBUG - 2023-11-05 13:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
DEBUG - 2023-11-05 13:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
DEBUG - 2023-11-05 13:07:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 13:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
INFO - 2023-11-05 13:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-05 13:07:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 13:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 13:07:11 --> Model Class Initialized
INFO - 2023-11-05 13:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 13:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 13:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 13:07:11 --> Final output sent to browser
DEBUG - 2023-11-05 13:07:11 --> Total execution time: 0.2254
ERROR - 2023-11-05 13:07:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:07:35 --> Config Class Initialized
INFO - 2023-11-05 13:07:35 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:07:35 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:07:35 --> Utf8 Class Initialized
INFO - 2023-11-05 13:07:35 --> URI Class Initialized
INFO - 2023-11-05 13:07:35 --> Router Class Initialized
INFO - 2023-11-05 13:07:35 --> Output Class Initialized
INFO - 2023-11-05 13:07:35 --> Security Class Initialized
DEBUG - 2023-11-05 13:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:07:35 --> Input Class Initialized
INFO - 2023-11-05 13:07:35 --> Language Class Initialized
INFO - 2023-11-05 13:07:35 --> Loader Class Initialized
INFO - 2023-11-05 13:07:35 --> Helper loaded: url_helper
INFO - 2023-11-05 13:07:35 --> Helper loaded: file_helper
INFO - 2023-11-05 13:07:35 --> Helper loaded: html_helper
INFO - 2023-11-05 13:07:35 --> Helper loaded: text_helper
INFO - 2023-11-05 13:07:35 --> Helper loaded: form_helper
INFO - 2023-11-05 13:07:35 --> Helper loaded: lang_helper
INFO - 2023-11-05 13:07:35 --> Helper loaded: security_helper
INFO - 2023-11-05 13:07:35 --> Helper loaded: cookie_helper
INFO - 2023-11-05 13:07:35 --> Database Driver Class Initialized
INFO - 2023-11-05 13:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:07:35 --> Parser Class Initialized
INFO - 2023-11-05 13:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 13:07:35 --> Pagination Class Initialized
INFO - 2023-11-05 13:07:35 --> Form Validation Class Initialized
INFO - 2023-11-05 13:07:35 --> Controller Class Initialized
INFO - 2023-11-05 13:07:35 --> Model Class Initialized
INFO - 2023-11-05 13:07:35 --> Model Class Initialized
INFO - 2023-11-05 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-11-05 13:07:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 13:07:35 --> Model Class Initialized
INFO - 2023-11-05 13:07:35 --> Model Class Initialized
INFO - 2023-11-05 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 13:07:35 --> Final output sent to browser
DEBUG - 2023-11-05 13:07:35 --> Total execution time: 0.1841
ERROR - 2023-11-05 13:07:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:07:36 --> Config Class Initialized
INFO - 2023-11-05 13:07:36 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:07:36 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:07:36 --> Utf8 Class Initialized
INFO - 2023-11-05 13:07:36 --> URI Class Initialized
INFO - 2023-11-05 13:07:36 --> Router Class Initialized
INFO - 2023-11-05 13:07:36 --> Output Class Initialized
INFO - 2023-11-05 13:07:36 --> Security Class Initialized
DEBUG - 2023-11-05 13:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:07:36 --> Input Class Initialized
INFO - 2023-11-05 13:07:36 --> Language Class Initialized
INFO - 2023-11-05 13:07:36 --> Loader Class Initialized
INFO - 2023-11-05 13:07:36 --> Helper loaded: url_helper
INFO - 2023-11-05 13:07:36 --> Helper loaded: file_helper
INFO - 2023-11-05 13:07:36 --> Helper loaded: html_helper
INFO - 2023-11-05 13:07:36 --> Helper loaded: text_helper
INFO - 2023-11-05 13:07:36 --> Helper loaded: form_helper
INFO - 2023-11-05 13:07:36 --> Helper loaded: lang_helper
INFO - 2023-11-05 13:07:36 --> Helper loaded: security_helper
INFO - 2023-11-05 13:07:36 --> Helper loaded: cookie_helper
INFO - 2023-11-05 13:07:36 --> Database Driver Class Initialized
INFO - 2023-11-05 13:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:07:36 --> Parser Class Initialized
INFO - 2023-11-05 13:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 13:07:36 --> Pagination Class Initialized
INFO - 2023-11-05 13:07:36 --> Form Validation Class Initialized
INFO - 2023-11-05 13:07:36 --> Controller Class Initialized
INFO - 2023-11-05 13:07:36 --> Model Class Initialized
INFO - 2023-11-05 13:07:36 --> Model Class Initialized
INFO - 2023-11-05 13:07:37 --> Final output sent to browser
DEBUG - 2023-11-05 13:07:37 --> Total execution time: 0.1747
ERROR - 2023-11-05 13:07:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:07:53 --> Config Class Initialized
INFO - 2023-11-05 13:07:53 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:07:53 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:07:53 --> Utf8 Class Initialized
INFO - 2023-11-05 13:07:53 --> URI Class Initialized
DEBUG - 2023-11-05 13:07:53 --> No URI present. Default controller set.
INFO - 2023-11-05 13:07:53 --> Router Class Initialized
INFO - 2023-11-05 13:07:53 --> Output Class Initialized
INFO - 2023-11-05 13:07:53 --> Security Class Initialized
DEBUG - 2023-11-05 13:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:07:53 --> Input Class Initialized
INFO - 2023-11-05 13:07:53 --> Language Class Initialized
INFO - 2023-11-05 13:07:53 --> Loader Class Initialized
INFO - 2023-11-05 13:07:53 --> Helper loaded: url_helper
INFO - 2023-11-05 13:07:53 --> Helper loaded: file_helper
INFO - 2023-11-05 13:07:53 --> Helper loaded: html_helper
INFO - 2023-11-05 13:07:53 --> Helper loaded: text_helper
INFO - 2023-11-05 13:07:53 --> Helper loaded: form_helper
INFO - 2023-11-05 13:07:53 --> Helper loaded: lang_helper
INFO - 2023-11-05 13:07:53 --> Helper loaded: security_helper
INFO - 2023-11-05 13:07:53 --> Helper loaded: cookie_helper
INFO - 2023-11-05 13:07:53 --> Database Driver Class Initialized
INFO - 2023-11-05 13:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:07:53 --> Parser Class Initialized
INFO - 2023-11-05 13:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 13:07:53 --> Pagination Class Initialized
INFO - 2023-11-05 13:07:53 --> Form Validation Class Initialized
INFO - 2023-11-05 13:07:53 --> Controller Class Initialized
INFO - 2023-11-05 13:07:53 --> Model Class Initialized
DEBUG - 2023-11-05 13:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:53 --> Model Class Initialized
DEBUG - 2023-11-05 13:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:53 --> Model Class Initialized
INFO - 2023-11-05 13:07:53 --> Model Class Initialized
INFO - 2023-11-05 13:07:53 --> Model Class Initialized
INFO - 2023-11-05 13:07:53 --> Model Class Initialized
DEBUG - 2023-11-05 13:07:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 13:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:53 --> Model Class Initialized
INFO - 2023-11-05 13:07:53 --> Model Class Initialized
INFO - 2023-11-05 13:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-05 13:07:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 13:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 13:07:53 --> Model Class Initialized
INFO - 2023-11-05 13:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 13:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 13:07:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 13:07:53 --> Final output sent to browser
DEBUG - 2023-11-05 13:07:53 --> Total execution time: 0.2146
ERROR - 2023-11-05 13:57:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:57:18 --> Config Class Initialized
INFO - 2023-11-05 13:57:18 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:57:18 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:57:18 --> Utf8 Class Initialized
INFO - 2023-11-05 13:57:18 --> URI Class Initialized
DEBUG - 2023-11-05 13:57:18 --> No URI present. Default controller set.
INFO - 2023-11-05 13:57:18 --> Router Class Initialized
INFO - 2023-11-05 13:57:18 --> Output Class Initialized
INFO - 2023-11-05 13:57:18 --> Security Class Initialized
DEBUG - 2023-11-05 13:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:57:18 --> Input Class Initialized
INFO - 2023-11-05 13:57:18 --> Language Class Initialized
INFO - 2023-11-05 13:57:18 --> Loader Class Initialized
INFO - 2023-11-05 13:57:18 --> Helper loaded: url_helper
INFO - 2023-11-05 13:57:18 --> Helper loaded: file_helper
INFO - 2023-11-05 13:57:18 --> Helper loaded: html_helper
INFO - 2023-11-05 13:57:18 --> Helper loaded: text_helper
INFO - 2023-11-05 13:57:18 --> Helper loaded: form_helper
INFO - 2023-11-05 13:57:18 --> Helper loaded: lang_helper
INFO - 2023-11-05 13:57:18 --> Helper loaded: security_helper
INFO - 2023-11-05 13:57:18 --> Helper loaded: cookie_helper
INFO - 2023-11-05 13:57:18 --> Database Driver Class Initialized
INFO - 2023-11-05 13:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:57:18 --> Parser Class Initialized
INFO - 2023-11-05 13:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 13:57:18 --> Pagination Class Initialized
INFO - 2023-11-05 13:57:18 --> Form Validation Class Initialized
INFO - 2023-11-05 13:57:18 --> Controller Class Initialized
INFO - 2023-11-05 13:57:18 --> Model Class Initialized
DEBUG - 2023-11-05 13:57:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-05 13:57:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:57:19 --> Config Class Initialized
INFO - 2023-11-05 13:57:19 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:57:19 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:57:19 --> Utf8 Class Initialized
INFO - 2023-11-05 13:57:19 --> URI Class Initialized
INFO - 2023-11-05 13:57:19 --> Router Class Initialized
INFO - 2023-11-05 13:57:19 --> Output Class Initialized
INFO - 2023-11-05 13:57:19 --> Security Class Initialized
DEBUG - 2023-11-05 13:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:57:19 --> Input Class Initialized
INFO - 2023-11-05 13:57:19 --> Language Class Initialized
INFO - 2023-11-05 13:57:19 --> Loader Class Initialized
INFO - 2023-11-05 13:57:19 --> Helper loaded: url_helper
INFO - 2023-11-05 13:57:19 --> Helper loaded: file_helper
INFO - 2023-11-05 13:57:19 --> Helper loaded: html_helper
INFO - 2023-11-05 13:57:19 --> Helper loaded: text_helper
INFO - 2023-11-05 13:57:19 --> Helper loaded: form_helper
INFO - 2023-11-05 13:57:19 --> Helper loaded: lang_helper
INFO - 2023-11-05 13:57:19 --> Helper loaded: security_helper
INFO - 2023-11-05 13:57:19 --> Helper loaded: cookie_helper
INFO - 2023-11-05 13:57:19 --> Database Driver Class Initialized
INFO - 2023-11-05 13:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:57:19 --> Parser Class Initialized
INFO - 2023-11-05 13:57:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 13:57:19 --> Pagination Class Initialized
INFO - 2023-11-05 13:57:19 --> Form Validation Class Initialized
INFO - 2023-11-05 13:57:19 --> Controller Class Initialized
INFO - 2023-11-05 13:57:19 --> Model Class Initialized
DEBUG - 2023-11-05 13:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:57:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 13:57:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:57:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 13:57:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 13:57:19 --> Model Class Initialized
INFO - 2023-11-05 13:57:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 13:57:19 --> Final output sent to browser
DEBUG - 2023-11-05 13:57:19 --> Total execution time: 0.0307
ERROR - 2023-11-05 16:25:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:25:12 --> Config Class Initialized
INFO - 2023-11-05 16:25:12 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:25:12 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:25:12 --> Utf8 Class Initialized
INFO - 2023-11-05 16:25:12 --> URI Class Initialized
INFO - 2023-11-05 16:25:12 --> Router Class Initialized
INFO - 2023-11-05 16:25:12 --> Output Class Initialized
INFO - 2023-11-05 16:25:12 --> Security Class Initialized
DEBUG - 2023-11-05 16:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:25:12 --> Input Class Initialized
INFO - 2023-11-05 16:25:12 --> Language Class Initialized
INFO - 2023-11-05 16:25:12 --> Loader Class Initialized
INFO - 2023-11-05 16:25:12 --> Helper loaded: url_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: file_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: html_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: text_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: form_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: security_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:25:12 --> Database Driver Class Initialized
INFO - 2023-11-05 16:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:25:12 --> Parser Class Initialized
INFO - 2023-11-05 16:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:25:12 --> Pagination Class Initialized
INFO - 2023-11-05 16:25:12 --> Form Validation Class Initialized
INFO - 2023-11-05 16:25:12 --> Controller Class Initialized
ERROR - 2023-11-05 16:25:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:25:12 --> Config Class Initialized
INFO - 2023-11-05 16:25:12 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:25:12 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:25:12 --> Utf8 Class Initialized
INFO - 2023-11-05 16:25:12 --> URI Class Initialized
INFO - 2023-11-05 16:25:12 --> Router Class Initialized
INFO - 2023-11-05 16:25:12 --> Output Class Initialized
INFO - 2023-11-05 16:25:12 --> Security Class Initialized
DEBUG - 2023-11-05 16:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:25:12 --> Input Class Initialized
INFO - 2023-11-05 16:25:12 --> Language Class Initialized
INFO - 2023-11-05 16:25:12 --> Loader Class Initialized
INFO - 2023-11-05 16:25:12 --> Helper loaded: url_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: file_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: html_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: text_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: form_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: security_helper
INFO - 2023-11-05 16:25:12 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:25:12 --> Database Driver Class Initialized
INFO - 2023-11-05 16:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:25:12 --> Parser Class Initialized
INFO - 2023-11-05 16:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:25:12 --> Pagination Class Initialized
INFO - 2023-11-05 16:25:12 --> Form Validation Class Initialized
INFO - 2023-11-05 16:25:12 --> Controller Class Initialized
INFO - 2023-11-05 16:25:12 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 16:25:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 16:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 16:25:12 --> Model Class Initialized
INFO - 2023-11-05 16:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 16:25:12 --> Final output sent to browser
DEBUG - 2023-11-05 16:25:12 --> Total execution time: 0.0346
ERROR - 2023-11-05 16:25:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:25:32 --> Config Class Initialized
INFO - 2023-11-05 16:25:32 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:25:32 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:25:32 --> Utf8 Class Initialized
INFO - 2023-11-05 16:25:32 --> URI Class Initialized
INFO - 2023-11-05 16:25:32 --> Router Class Initialized
INFO - 2023-11-05 16:25:32 --> Output Class Initialized
INFO - 2023-11-05 16:25:32 --> Security Class Initialized
DEBUG - 2023-11-05 16:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:25:32 --> Input Class Initialized
INFO - 2023-11-05 16:25:32 --> Language Class Initialized
INFO - 2023-11-05 16:25:32 --> Loader Class Initialized
INFO - 2023-11-05 16:25:32 --> Helper loaded: url_helper
INFO - 2023-11-05 16:25:32 --> Helper loaded: file_helper
INFO - 2023-11-05 16:25:32 --> Helper loaded: html_helper
INFO - 2023-11-05 16:25:32 --> Helper loaded: text_helper
INFO - 2023-11-05 16:25:32 --> Helper loaded: form_helper
INFO - 2023-11-05 16:25:32 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:25:32 --> Helper loaded: security_helper
INFO - 2023-11-05 16:25:32 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:25:32 --> Database Driver Class Initialized
INFO - 2023-11-05 16:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:25:32 --> Parser Class Initialized
INFO - 2023-11-05 16:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:25:32 --> Pagination Class Initialized
INFO - 2023-11-05 16:25:32 --> Form Validation Class Initialized
INFO - 2023-11-05 16:25:32 --> Controller Class Initialized
INFO - 2023-11-05 16:25:32 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:32 --> Model Class Initialized
INFO - 2023-11-05 16:25:32 --> Final output sent to browser
DEBUG - 2023-11-05 16:25:32 --> Total execution time: 0.0213
ERROR - 2023-11-05 16:25:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:25:33 --> Config Class Initialized
INFO - 2023-11-05 16:25:33 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:25:33 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:25:33 --> Utf8 Class Initialized
INFO - 2023-11-05 16:25:33 --> URI Class Initialized
DEBUG - 2023-11-05 16:25:33 --> No URI present. Default controller set.
INFO - 2023-11-05 16:25:33 --> Router Class Initialized
INFO - 2023-11-05 16:25:33 --> Output Class Initialized
INFO - 2023-11-05 16:25:33 --> Security Class Initialized
DEBUG - 2023-11-05 16:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:25:33 --> Input Class Initialized
INFO - 2023-11-05 16:25:33 --> Language Class Initialized
INFO - 2023-11-05 16:25:33 --> Loader Class Initialized
INFO - 2023-11-05 16:25:33 --> Helper loaded: url_helper
INFO - 2023-11-05 16:25:33 --> Helper loaded: file_helper
INFO - 2023-11-05 16:25:33 --> Helper loaded: html_helper
INFO - 2023-11-05 16:25:33 --> Helper loaded: text_helper
INFO - 2023-11-05 16:25:33 --> Helper loaded: form_helper
INFO - 2023-11-05 16:25:33 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:25:33 --> Helper loaded: security_helper
INFO - 2023-11-05 16:25:33 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:25:33 --> Database Driver Class Initialized
INFO - 2023-11-05 16:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:25:33 --> Parser Class Initialized
INFO - 2023-11-05 16:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:25:33 --> Pagination Class Initialized
INFO - 2023-11-05 16:25:33 --> Form Validation Class Initialized
INFO - 2023-11-05 16:25:33 --> Controller Class Initialized
INFO - 2023-11-05 16:25:33 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:33 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:33 --> Model Class Initialized
INFO - 2023-11-05 16:25:33 --> Model Class Initialized
INFO - 2023-11-05 16:25:33 --> Model Class Initialized
INFO - 2023-11-05 16:25:33 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:33 --> Model Class Initialized
INFO - 2023-11-05 16:25:33 --> Model Class Initialized
INFO - 2023-11-05 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-05 16:25:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 16:25:33 --> Model Class Initialized
INFO - 2023-11-05 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 16:25:33 --> Final output sent to browser
DEBUG - 2023-11-05 16:25:33 --> Total execution time: 0.2165
ERROR - 2023-11-05 16:25:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:25:39 --> Config Class Initialized
INFO - 2023-11-05 16:25:39 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:25:39 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:25:39 --> Utf8 Class Initialized
INFO - 2023-11-05 16:25:39 --> URI Class Initialized
INFO - 2023-11-05 16:25:39 --> Router Class Initialized
INFO - 2023-11-05 16:25:39 --> Output Class Initialized
INFO - 2023-11-05 16:25:39 --> Security Class Initialized
DEBUG - 2023-11-05 16:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:25:39 --> Input Class Initialized
INFO - 2023-11-05 16:25:39 --> Language Class Initialized
INFO - 2023-11-05 16:25:39 --> Loader Class Initialized
INFO - 2023-11-05 16:25:39 --> Helper loaded: url_helper
INFO - 2023-11-05 16:25:39 --> Helper loaded: file_helper
INFO - 2023-11-05 16:25:39 --> Helper loaded: html_helper
INFO - 2023-11-05 16:25:39 --> Helper loaded: text_helper
INFO - 2023-11-05 16:25:39 --> Helper loaded: form_helper
INFO - 2023-11-05 16:25:39 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:25:39 --> Helper loaded: security_helper
INFO - 2023-11-05 16:25:39 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:25:39 --> Database Driver Class Initialized
INFO - 2023-11-05 16:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:25:39 --> Parser Class Initialized
INFO - 2023-11-05 16:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:25:39 --> Pagination Class Initialized
INFO - 2023-11-05 16:25:39 --> Form Validation Class Initialized
INFO - 2023-11-05 16:25:39 --> Controller Class Initialized
INFO - 2023-11-05 16:25:39 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:39 --> Model Class Initialized
INFO - 2023-11-05 16:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-11-05 16:25:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 16:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 16:25:39 --> Model Class Initialized
INFO - 2023-11-05 16:25:39 --> Model Class Initialized
INFO - 2023-11-05 16:25:39 --> Model Class Initialized
INFO - 2023-11-05 16:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 16:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 16:25:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 16:25:39 --> Final output sent to browser
DEBUG - 2023-11-05 16:25:39 --> Total execution time: 0.1552
ERROR - 2023-11-05 16:25:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:25:40 --> Config Class Initialized
INFO - 2023-11-05 16:25:40 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:25:40 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:25:40 --> Utf8 Class Initialized
INFO - 2023-11-05 16:25:40 --> URI Class Initialized
INFO - 2023-11-05 16:25:40 --> Router Class Initialized
INFO - 2023-11-05 16:25:40 --> Output Class Initialized
INFO - 2023-11-05 16:25:40 --> Security Class Initialized
DEBUG - 2023-11-05 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:25:40 --> Input Class Initialized
INFO - 2023-11-05 16:25:40 --> Language Class Initialized
INFO - 2023-11-05 16:25:40 --> Loader Class Initialized
INFO - 2023-11-05 16:25:40 --> Helper loaded: url_helper
INFO - 2023-11-05 16:25:40 --> Helper loaded: file_helper
INFO - 2023-11-05 16:25:40 --> Helper loaded: html_helper
INFO - 2023-11-05 16:25:40 --> Helper loaded: text_helper
INFO - 2023-11-05 16:25:40 --> Helper loaded: form_helper
INFO - 2023-11-05 16:25:40 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:25:40 --> Helper loaded: security_helper
INFO - 2023-11-05 16:25:40 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:25:40 --> Database Driver Class Initialized
INFO - 2023-11-05 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:25:40 --> Parser Class Initialized
INFO - 2023-11-05 16:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:25:40 --> Pagination Class Initialized
INFO - 2023-11-05 16:25:40 --> Form Validation Class Initialized
INFO - 2023-11-05 16:25:40 --> Controller Class Initialized
INFO - 2023-11-05 16:25:40 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:40 --> Model Class Initialized
INFO - 2023-11-05 16:25:40 --> Final output sent to browser
DEBUG - 2023-11-05 16:25:40 --> Total execution time: 0.0742
ERROR - 2023-11-05 16:25:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:25:43 --> Config Class Initialized
INFO - 2023-11-05 16:25:43 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:25:43 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:25:43 --> Utf8 Class Initialized
INFO - 2023-11-05 16:25:43 --> URI Class Initialized
INFO - 2023-11-05 16:25:43 --> Router Class Initialized
INFO - 2023-11-05 16:25:43 --> Output Class Initialized
INFO - 2023-11-05 16:25:43 --> Security Class Initialized
DEBUG - 2023-11-05 16:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:25:43 --> Input Class Initialized
INFO - 2023-11-05 16:25:43 --> Language Class Initialized
INFO - 2023-11-05 16:25:43 --> Loader Class Initialized
INFO - 2023-11-05 16:25:43 --> Helper loaded: url_helper
INFO - 2023-11-05 16:25:43 --> Helper loaded: file_helper
INFO - 2023-11-05 16:25:43 --> Helper loaded: html_helper
INFO - 2023-11-05 16:25:43 --> Helper loaded: text_helper
INFO - 2023-11-05 16:25:43 --> Helper loaded: form_helper
INFO - 2023-11-05 16:25:43 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:25:43 --> Helper loaded: security_helper
INFO - 2023-11-05 16:25:43 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:25:44 --> Database Driver Class Initialized
INFO - 2023-11-05 16:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:25:44 --> Parser Class Initialized
INFO - 2023-11-05 16:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:25:44 --> Pagination Class Initialized
INFO - 2023-11-05 16:25:44 --> Form Validation Class Initialized
INFO - 2023-11-05 16:25:44 --> Controller Class Initialized
INFO - 2023-11-05 16:25:44 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:25:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:44 --> Model Class Initialized
INFO - 2023-11-05 16:25:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-11-05 16:25:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 16:25:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 16:25:44 --> Model Class Initialized
INFO - 2023-11-05 16:25:44 --> Model Class Initialized
INFO - 2023-11-05 16:25:44 --> Model Class Initialized
INFO - 2023-11-05 16:25:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 16:25:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 16:25:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 16:25:44 --> Final output sent to browser
DEBUG - 2023-11-05 16:25:44 --> Total execution time: 0.1366
ERROR - 2023-11-05 16:25:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:25:44 --> Config Class Initialized
INFO - 2023-11-05 16:25:44 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:25:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:25:44 --> Utf8 Class Initialized
INFO - 2023-11-05 16:25:44 --> URI Class Initialized
INFO - 2023-11-05 16:25:44 --> Router Class Initialized
INFO - 2023-11-05 16:25:44 --> Output Class Initialized
INFO - 2023-11-05 16:25:44 --> Security Class Initialized
DEBUG - 2023-11-05 16:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:25:44 --> Input Class Initialized
INFO - 2023-11-05 16:25:44 --> Language Class Initialized
INFO - 2023-11-05 16:25:44 --> Loader Class Initialized
INFO - 2023-11-05 16:25:44 --> Helper loaded: url_helper
INFO - 2023-11-05 16:25:44 --> Helper loaded: file_helper
INFO - 2023-11-05 16:25:44 --> Helper loaded: html_helper
INFO - 2023-11-05 16:25:44 --> Helper loaded: text_helper
INFO - 2023-11-05 16:25:44 --> Helper loaded: form_helper
INFO - 2023-11-05 16:25:44 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:25:44 --> Helper loaded: security_helper
INFO - 2023-11-05 16:25:44 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:25:44 --> Database Driver Class Initialized
INFO - 2023-11-05 16:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:25:44 --> Parser Class Initialized
INFO - 2023-11-05 16:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:25:44 --> Pagination Class Initialized
INFO - 2023-11-05 16:25:44 --> Form Validation Class Initialized
INFO - 2023-11-05 16:25:44 --> Controller Class Initialized
INFO - 2023-11-05 16:25:44 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:25:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:44 --> Model Class Initialized
INFO - 2023-11-05 16:25:44 --> Final output sent to browser
DEBUG - 2023-11-05 16:25:44 --> Total execution time: 0.0305
ERROR - 2023-11-05 16:25:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:25:57 --> Config Class Initialized
INFO - 2023-11-05 16:25:57 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:25:57 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:25:57 --> Utf8 Class Initialized
INFO - 2023-11-05 16:25:57 --> URI Class Initialized
INFO - 2023-11-05 16:25:57 --> Router Class Initialized
INFO - 2023-11-05 16:25:57 --> Output Class Initialized
INFO - 2023-11-05 16:25:57 --> Security Class Initialized
DEBUG - 2023-11-05 16:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:25:57 --> Input Class Initialized
INFO - 2023-11-05 16:25:57 --> Language Class Initialized
INFO - 2023-11-05 16:25:57 --> Loader Class Initialized
INFO - 2023-11-05 16:25:57 --> Helper loaded: url_helper
INFO - 2023-11-05 16:25:57 --> Helper loaded: file_helper
INFO - 2023-11-05 16:25:57 --> Helper loaded: html_helper
INFO - 2023-11-05 16:25:57 --> Helper loaded: text_helper
INFO - 2023-11-05 16:25:57 --> Helper loaded: form_helper
INFO - 2023-11-05 16:25:57 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:25:57 --> Helper loaded: security_helper
INFO - 2023-11-05 16:25:57 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:25:57 --> Database Driver Class Initialized
INFO - 2023-11-05 16:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:25:57 --> Parser Class Initialized
INFO - 2023-11-05 16:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:25:57 --> Pagination Class Initialized
INFO - 2023-11-05 16:25:57 --> Form Validation Class Initialized
INFO - 2023-11-05 16:25:57 --> Controller Class Initialized
INFO - 2023-11-05 16:25:57 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:57 --> Model Class Initialized
DEBUG - 2023-11-05 16:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-11-05 16:25:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 16:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 16:25:57 --> Model Class Initialized
INFO - 2023-11-05 16:25:57 --> Model Class Initialized
INFO - 2023-11-05 16:25:57 --> Model Class Initialized
INFO - 2023-11-05 16:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 16:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 16:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 16:25:57 --> Final output sent to browser
DEBUG - 2023-11-05 16:25:57 --> Total execution time: 0.1407
ERROR - 2023-11-05 16:27:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:27:05 --> Config Class Initialized
INFO - 2023-11-05 16:27:05 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:27:05 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:27:05 --> Utf8 Class Initialized
INFO - 2023-11-05 16:27:05 --> URI Class Initialized
INFO - 2023-11-05 16:27:05 --> Router Class Initialized
INFO - 2023-11-05 16:27:05 --> Output Class Initialized
INFO - 2023-11-05 16:27:05 --> Security Class Initialized
DEBUG - 2023-11-05 16:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:27:05 --> Input Class Initialized
INFO - 2023-11-05 16:27:05 --> Language Class Initialized
INFO - 2023-11-05 16:27:05 --> Loader Class Initialized
INFO - 2023-11-05 16:27:05 --> Helper loaded: url_helper
INFO - 2023-11-05 16:27:05 --> Helper loaded: file_helper
INFO - 2023-11-05 16:27:05 --> Helper loaded: html_helper
INFO - 2023-11-05 16:27:05 --> Helper loaded: text_helper
INFO - 2023-11-05 16:27:05 --> Helper loaded: form_helper
INFO - 2023-11-05 16:27:05 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:27:05 --> Helper loaded: security_helper
INFO - 2023-11-05 16:27:05 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:27:05 --> Database Driver Class Initialized
INFO - 2023-11-05 16:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:27:05 --> Parser Class Initialized
INFO - 2023-11-05 16:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:27:05 --> Pagination Class Initialized
INFO - 2023-11-05 16:27:05 --> Form Validation Class Initialized
INFO - 2023-11-05 16:27:05 --> Controller Class Initialized
INFO - 2023-11-05 16:27:05 --> Model Class Initialized
DEBUG - 2023-11-05 16:27:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:05 --> Model Class Initialized
INFO - 2023-11-05 16:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-11-05 16:27:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 16:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 16:27:05 --> Model Class Initialized
INFO - 2023-11-05 16:27:05 --> Model Class Initialized
INFO - 2023-11-05 16:27:05 --> Model Class Initialized
INFO - 2023-11-05 16:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 16:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 16:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 16:27:05 --> Final output sent to browser
DEBUG - 2023-11-05 16:27:05 --> Total execution time: 0.1315
ERROR - 2023-11-05 16:27:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:27:06 --> Config Class Initialized
INFO - 2023-11-05 16:27:06 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:27:06 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:27:06 --> Utf8 Class Initialized
INFO - 2023-11-05 16:27:06 --> URI Class Initialized
INFO - 2023-11-05 16:27:06 --> Router Class Initialized
INFO - 2023-11-05 16:27:06 --> Output Class Initialized
INFO - 2023-11-05 16:27:06 --> Security Class Initialized
DEBUG - 2023-11-05 16:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:27:06 --> Input Class Initialized
INFO - 2023-11-05 16:27:06 --> Language Class Initialized
INFO - 2023-11-05 16:27:06 --> Loader Class Initialized
INFO - 2023-11-05 16:27:06 --> Helper loaded: url_helper
INFO - 2023-11-05 16:27:06 --> Helper loaded: file_helper
INFO - 2023-11-05 16:27:06 --> Helper loaded: html_helper
INFO - 2023-11-05 16:27:06 --> Helper loaded: text_helper
INFO - 2023-11-05 16:27:06 --> Helper loaded: form_helper
INFO - 2023-11-05 16:27:06 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:27:06 --> Helper loaded: security_helper
INFO - 2023-11-05 16:27:06 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:27:06 --> Database Driver Class Initialized
INFO - 2023-11-05 16:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:27:06 --> Parser Class Initialized
INFO - 2023-11-05 16:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:27:06 --> Pagination Class Initialized
INFO - 2023-11-05 16:27:06 --> Form Validation Class Initialized
INFO - 2023-11-05 16:27:06 --> Controller Class Initialized
INFO - 2023-11-05 16:27:06 --> Model Class Initialized
DEBUG - 2023-11-05 16:27:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:06 --> Model Class Initialized
INFO - 2023-11-05 16:27:06 --> Final output sent to browser
DEBUG - 2023-11-05 16:27:06 --> Total execution time: 0.0178
ERROR - 2023-11-05 16:27:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:27:09 --> Config Class Initialized
INFO - 2023-11-05 16:27:09 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:27:09 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:27:09 --> Utf8 Class Initialized
INFO - 2023-11-05 16:27:09 --> URI Class Initialized
INFO - 2023-11-05 16:27:09 --> Router Class Initialized
INFO - 2023-11-05 16:27:09 --> Output Class Initialized
INFO - 2023-11-05 16:27:09 --> Security Class Initialized
DEBUG - 2023-11-05 16:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:27:09 --> Input Class Initialized
INFO - 2023-11-05 16:27:09 --> Language Class Initialized
INFO - 2023-11-05 16:27:09 --> Loader Class Initialized
INFO - 2023-11-05 16:27:09 --> Helper loaded: url_helper
INFO - 2023-11-05 16:27:09 --> Helper loaded: file_helper
INFO - 2023-11-05 16:27:09 --> Helper loaded: html_helper
INFO - 2023-11-05 16:27:09 --> Helper loaded: text_helper
INFO - 2023-11-05 16:27:09 --> Helper loaded: form_helper
INFO - 2023-11-05 16:27:09 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:27:09 --> Helper loaded: security_helper
INFO - 2023-11-05 16:27:09 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:27:09 --> Database Driver Class Initialized
INFO - 2023-11-05 16:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:27:09 --> Parser Class Initialized
INFO - 2023-11-05 16:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:27:09 --> Pagination Class Initialized
INFO - 2023-11-05 16:27:09 --> Form Validation Class Initialized
INFO - 2023-11-05 16:27:09 --> Controller Class Initialized
INFO - 2023-11-05 16:27:09 --> Model Class Initialized
DEBUG - 2023-11-05 16:27:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:09 --> Model Class Initialized
INFO - 2023-11-05 16:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-11-05 16:27:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 16:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 16:27:09 --> Model Class Initialized
INFO - 2023-11-05 16:27:09 --> Model Class Initialized
INFO - 2023-11-05 16:27:09 --> Model Class Initialized
INFO - 2023-11-05 16:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 16:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 16:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 16:27:09 --> Final output sent to browser
DEBUG - 2023-11-05 16:27:09 --> Total execution time: 0.1528
ERROR - 2023-11-05 16:27:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:27:10 --> Config Class Initialized
INFO - 2023-11-05 16:27:10 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:27:10 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:27:10 --> Utf8 Class Initialized
INFO - 2023-11-05 16:27:10 --> URI Class Initialized
INFO - 2023-11-05 16:27:10 --> Router Class Initialized
INFO - 2023-11-05 16:27:10 --> Output Class Initialized
INFO - 2023-11-05 16:27:10 --> Security Class Initialized
DEBUG - 2023-11-05 16:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:27:10 --> Input Class Initialized
INFO - 2023-11-05 16:27:10 --> Language Class Initialized
INFO - 2023-11-05 16:27:10 --> Loader Class Initialized
INFO - 2023-11-05 16:27:10 --> Helper loaded: url_helper
INFO - 2023-11-05 16:27:10 --> Helper loaded: file_helper
INFO - 2023-11-05 16:27:10 --> Helper loaded: html_helper
INFO - 2023-11-05 16:27:10 --> Helper loaded: text_helper
INFO - 2023-11-05 16:27:10 --> Helper loaded: form_helper
INFO - 2023-11-05 16:27:10 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:27:10 --> Helper loaded: security_helper
INFO - 2023-11-05 16:27:10 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:27:10 --> Database Driver Class Initialized
INFO - 2023-11-05 16:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:27:10 --> Parser Class Initialized
INFO - 2023-11-05 16:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:27:10 --> Pagination Class Initialized
INFO - 2023-11-05 16:27:10 --> Form Validation Class Initialized
INFO - 2023-11-05 16:27:10 --> Controller Class Initialized
INFO - 2023-11-05 16:27:10 --> Model Class Initialized
DEBUG - 2023-11-05 16:27:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:10 --> Model Class Initialized
INFO - 2023-11-05 16:27:10 --> Final output sent to browser
DEBUG - 2023-11-05 16:27:10 --> Total execution time: 0.0802
ERROR - 2023-11-05 16:27:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:27:18 --> Config Class Initialized
INFO - 2023-11-05 16:27:18 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:27:18 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:27:18 --> Utf8 Class Initialized
INFO - 2023-11-05 16:27:18 --> URI Class Initialized
INFO - 2023-11-05 16:27:18 --> Router Class Initialized
INFO - 2023-11-05 16:27:18 --> Output Class Initialized
INFO - 2023-11-05 16:27:18 --> Security Class Initialized
DEBUG - 2023-11-05 16:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:27:18 --> Input Class Initialized
INFO - 2023-11-05 16:27:18 --> Language Class Initialized
INFO - 2023-11-05 16:27:18 --> Loader Class Initialized
INFO - 2023-11-05 16:27:18 --> Helper loaded: url_helper
INFO - 2023-11-05 16:27:18 --> Helper loaded: file_helper
INFO - 2023-11-05 16:27:18 --> Helper loaded: html_helper
INFO - 2023-11-05 16:27:18 --> Helper loaded: text_helper
INFO - 2023-11-05 16:27:18 --> Helper loaded: form_helper
INFO - 2023-11-05 16:27:18 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:27:18 --> Helper loaded: security_helper
INFO - 2023-11-05 16:27:18 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:27:18 --> Database Driver Class Initialized
INFO - 2023-11-05 16:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:27:18 --> Parser Class Initialized
INFO - 2023-11-05 16:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:27:18 --> Pagination Class Initialized
INFO - 2023-11-05 16:27:18 --> Form Validation Class Initialized
INFO - 2023-11-05 16:27:18 --> Controller Class Initialized
INFO - 2023-11-05 16:27:18 --> Model Class Initialized
DEBUG - 2023-11-05 16:27:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:18 --> Model Class Initialized
INFO - 2023-11-05 16:27:18 --> Final output sent to browser
DEBUG - 2023-11-05 16:27:18 --> Total execution time: 0.0737
ERROR - 2023-11-05 16:27:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:27:50 --> Config Class Initialized
INFO - 2023-11-05 16:27:50 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:27:50 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:27:50 --> Utf8 Class Initialized
INFO - 2023-11-05 16:27:50 --> URI Class Initialized
DEBUG - 2023-11-05 16:27:50 --> No URI present. Default controller set.
INFO - 2023-11-05 16:27:50 --> Router Class Initialized
INFO - 2023-11-05 16:27:50 --> Output Class Initialized
INFO - 2023-11-05 16:27:50 --> Security Class Initialized
DEBUG - 2023-11-05 16:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:27:50 --> Input Class Initialized
INFO - 2023-11-05 16:27:50 --> Language Class Initialized
INFO - 2023-11-05 16:27:50 --> Loader Class Initialized
INFO - 2023-11-05 16:27:50 --> Helper loaded: url_helper
INFO - 2023-11-05 16:27:50 --> Helper loaded: file_helper
INFO - 2023-11-05 16:27:50 --> Helper loaded: html_helper
INFO - 2023-11-05 16:27:50 --> Helper loaded: text_helper
INFO - 2023-11-05 16:27:50 --> Helper loaded: form_helper
INFO - 2023-11-05 16:27:50 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:27:50 --> Helper loaded: security_helper
INFO - 2023-11-05 16:27:50 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:27:50 --> Database Driver Class Initialized
INFO - 2023-11-05 16:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:27:50 --> Parser Class Initialized
INFO - 2023-11-05 16:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:27:50 --> Pagination Class Initialized
INFO - 2023-11-05 16:27:50 --> Form Validation Class Initialized
INFO - 2023-11-05 16:27:50 --> Controller Class Initialized
INFO - 2023-11-05 16:27:50 --> Model Class Initialized
DEBUG - 2023-11-05 16:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:50 --> Model Class Initialized
DEBUG - 2023-11-05 16:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:50 --> Model Class Initialized
INFO - 2023-11-05 16:27:50 --> Model Class Initialized
INFO - 2023-11-05 16:27:50 --> Model Class Initialized
INFO - 2023-11-05 16:27:50 --> Model Class Initialized
DEBUG - 2023-11-05 16:27:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:50 --> Model Class Initialized
INFO - 2023-11-05 16:27:50 --> Model Class Initialized
INFO - 2023-11-05 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-05 16:27:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 16:27:50 --> Model Class Initialized
INFO - 2023-11-05 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 16:27:50 --> Final output sent to browser
DEBUG - 2023-11-05 16:27:50 --> Total execution time: 0.2161
ERROR - 2023-11-05 16:28:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 16:28:16 --> Config Class Initialized
INFO - 2023-11-05 16:28:16 --> Hooks Class Initialized
DEBUG - 2023-11-05 16:28:16 --> UTF-8 Support Enabled
INFO - 2023-11-05 16:28:16 --> Utf8 Class Initialized
INFO - 2023-11-05 16:28:16 --> URI Class Initialized
DEBUG - 2023-11-05 16:28:16 --> No URI present. Default controller set.
INFO - 2023-11-05 16:28:16 --> Router Class Initialized
INFO - 2023-11-05 16:28:16 --> Output Class Initialized
INFO - 2023-11-05 16:28:16 --> Security Class Initialized
DEBUG - 2023-11-05 16:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 16:28:16 --> Input Class Initialized
INFO - 2023-11-05 16:28:16 --> Language Class Initialized
INFO - 2023-11-05 16:28:16 --> Loader Class Initialized
INFO - 2023-11-05 16:28:16 --> Helper loaded: url_helper
INFO - 2023-11-05 16:28:16 --> Helper loaded: file_helper
INFO - 2023-11-05 16:28:16 --> Helper loaded: html_helper
INFO - 2023-11-05 16:28:16 --> Helper loaded: text_helper
INFO - 2023-11-05 16:28:16 --> Helper loaded: form_helper
INFO - 2023-11-05 16:28:16 --> Helper loaded: lang_helper
INFO - 2023-11-05 16:28:16 --> Helper loaded: security_helper
INFO - 2023-11-05 16:28:16 --> Helper loaded: cookie_helper
INFO - 2023-11-05 16:28:16 --> Database Driver Class Initialized
INFO - 2023-11-05 16:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 16:28:16 --> Parser Class Initialized
INFO - 2023-11-05 16:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 16:28:16 --> Pagination Class Initialized
INFO - 2023-11-05 16:28:16 --> Form Validation Class Initialized
INFO - 2023-11-05 16:28:16 --> Controller Class Initialized
INFO - 2023-11-05 16:28:16 --> Model Class Initialized
DEBUG - 2023-11-05 16:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:28:16 --> Model Class Initialized
DEBUG - 2023-11-05 16:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:28:16 --> Model Class Initialized
INFO - 2023-11-05 16:28:16 --> Model Class Initialized
INFO - 2023-11-05 16:28:16 --> Model Class Initialized
INFO - 2023-11-05 16:28:16 --> Model Class Initialized
DEBUG - 2023-11-05 16:28:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 16:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:28:16 --> Model Class Initialized
INFO - 2023-11-05 16:28:16 --> Model Class Initialized
INFO - 2023-11-05 16:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-05 16:28:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 16:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 16:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 16:28:16 --> Model Class Initialized
INFO - 2023-11-05 16:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 16:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 16:28:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 16:28:16 --> Final output sent to browser
DEBUG - 2023-11-05 16:28:16 --> Total execution time: 0.2347
ERROR - 2023-11-05 17:33:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 17:33:57 --> Config Class Initialized
INFO - 2023-11-05 17:33:57 --> Hooks Class Initialized
DEBUG - 2023-11-05 17:33:57 --> UTF-8 Support Enabled
INFO - 2023-11-05 17:33:57 --> Utf8 Class Initialized
INFO - 2023-11-05 17:33:57 --> URI Class Initialized
INFO - 2023-11-05 17:33:57 --> Router Class Initialized
INFO - 2023-11-05 17:33:57 --> Output Class Initialized
INFO - 2023-11-05 17:33:57 --> Security Class Initialized
DEBUG - 2023-11-05 17:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 17:33:57 --> Input Class Initialized
INFO - 2023-11-05 17:33:57 --> Language Class Initialized
ERROR - 2023-11-05 17:33:57 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-05 18:03:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:03:40 --> Config Class Initialized
INFO - 2023-11-05 18:03:40 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:03:40 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:03:40 --> Utf8 Class Initialized
INFO - 2023-11-05 18:03:40 --> URI Class Initialized
DEBUG - 2023-11-05 18:03:40 --> No URI present. Default controller set.
INFO - 2023-11-05 18:03:40 --> Router Class Initialized
INFO - 2023-11-05 18:03:40 --> Output Class Initialized
INFO - 2023-11-05 18:03:40 --> Security Class Initialized
DEBUG - 2023-11-05 18:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:03:40 --> Input Class Initialized
INFO - 2023-11-05 18:03:40 --> Language Class Initialized
INFO - 2023-11-05 18:03:40 --> Loader Class Initialized
INFO - 2023-11-05 18:03:40 --> Helper loaded: url_helper
INFO - 2023-11-05 18:03:40 --> Helper loaded: file_helper
INFO - 2023-11-05 18:03:40 --> Helper loaded: html_helper
INFO - 2023-11-05 18:03:40 --> Helper loaded: text_helper
INFO - 2023-11-05 18:03:40 --> Helper loaded: form_helper
INFO - 2023-11-05 18:03:40 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:03:40 --> Helper loaded: security_helper
INFO - 2023-11-05 18:03:40 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:03:40 --> Database Driver Class Initialized
INFO - 2023-11-05 18:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:03:40 --> Parser Class Initialized
INFO - 2023-11-05 18:03:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:03:40 --> Pagination Class Initialized
INFO - 2023-11-05 18:03:40 --> Form Validation Class Initialized
INFO - 2023-11-05 18:03:40 --> Controller Class Initialized
INFO - 2023-11-05 18:03:40 --> Model Class Initialized
DEBUG - 2023-11-05 18:03:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-05 18:03:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:03:41 --> Config Class Initialized
INFO - 2023-11-05 18:03:41 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:03:41 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:03:41 --> Utf8 Class Initialized
INFO - 2023-11-05 18:03:41 --> URI Class Initialized
INFO - 2023-11-05 18:03:41 --> Router Class Initialized
INFO - 2023-11-05 18:03:41 --> Output Class Initialized
INFO - 2023-11-05 18:03:41 --> Security Class Initialized
DEBUG - 2023-11-05 18:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:03:41 --> Input Class Initialized
INFO - 2023-11-05 18:03:41 --> Language Class Initialized
INFO - 2023-11-05 18:03:41 --> Loader Class Initialized
INFO - 2023-11-05 18:03:41 --> Helper loaded: url_helper
INFO - 2023-11-05 18:03:41 --> Helper loaded: file_helper
INFO - 2023-11-05 18:03:41 --> Helper loaded: html_helper
INFO - 2023-11-05 18:03:41 --> Helper loaded: text_helper
INFO - 2023-11-05 18:03:41 --> Helper loaded: form_helper
INFO - 2023-11-05 18:03:41 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:03:41 --> Helper loaded: security_helper
INFO - 2023-11-05 18:03:41 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:03:41 --> Database Driver Class Initialized
INFO - 2023-11-05 18:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:03:41 --> Parser Class Initialized
INFO - 2023-11-05 18:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:03:41 --> Pagination Class Initialized
INFO - 2023-11-05 18:03:41 --> Form Validation Class Initialized
INFO - 2023-11-05 18:03:41 --> Controller Class Initialized
INFO - 2023-11-05 18:03:41 --> Model Class Initialized
DEBUG - 2023-11-05 18:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:03:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 18:03:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:03:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 18:03:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 18:03:41 --> Model Class Initialized
INFO - 2023-11-05 18:03:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 18:03:41 --> Final output sent to browser
DEBUG - 2023-11-05 18:03:41 --> Total execution time: 0.0383
ERROR - 2023-11-05 18:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:03:44 --> Config Class Initialized
INFO - 2023-11-05 18:03:44 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:03:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:03:44 --> Utf8 Class Initialized
INFO - 2023-11-05 18:03:44 --> URI Class Initialized
INFO - 2023-11-05 18:03:44 --> Router Class Initialized
INFO - 2023-11-05 18:03:44 --> Output Class Initialized
INFO - 2023-11-05 18:03:44 --> Security Class Initialized
DEBUG - 2023-11-05 18:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:03:44 --> Input Class Initialized
INFO - 2023-11-05 18:03:44 --> Language Class Initialized
INFO - 2023-11-05 18:03:44 --> Loader Class Initialized
INFO - 2023-11-05 18:03:44 --> Helper loaded: url_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: file_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: html_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: text_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: form_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: security_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:03:44 --> Database Driver Class Initialized
INFO - 2023-11-05 18:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:03:44 --> Parser Class Initialized
INFO - 2023-11-05 18:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:03:44 --> Pagination Class Initialized
INFO - 2023-11-05 18:03:44 --> Form Validation Class Initialized
INFO - 2023-11-05 18:03:44 --> Controller Class Initialized
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
DEBUG - 2023-11-05 18:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
INFO - 2023-11-05 18:03:44 --> Final output sent to browser
DEBUG - 2023-11-05 18:03:44 --> Total execution time: 0.0183
ERROR - 2023-11-05 18:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:03:44 --> Config Class Initialized
INFO - 2023-11-05 18:03:44 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:03:44 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:03:44 --> Utf8 Class Initialized
INFO - 2023-11-05 18:03:44 --> URI Class Initialized
DEBUG - 2023-11-05 18:03:44 --> No URI present. Default controller set.
INFO - 2023-11-05 18:03:44 --> Router Class Initialized
INFO - 2023-11-05 18:03:44 --> Output Class Initialized
INFO - 2023-11-05 18:03:44 --> Security Class Initialized
DEBUG - 2023-11-05 18:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:03:44 --> Input Class Initialized
INFO - 2023-11-05 18:03:44 --> Language Class Initialized
INFO - 2023-11-05 18:03:44 --> Loader Class Initialized
INFO - 2023-11-05 18:03:44 --> Helper loaded: url_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: file_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: html_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: text_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: form_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: security_helper
INFO - 2023-11-05 18:03:44 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:03:44 --> Database Driver Class Initialized
INFO - 2023-11-05 18:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:03:44 --> Parser Class Initialized
INFO - 2023-11-05 18:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:03:44 --> Pagination Class Initialized
INFO - 2023-11-05 18:03:44 --> Form Validation Class Initialized
INFO - 2023-11-05 18:03:44 --> Controller Class Initialized
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
DEBUG - 2023-11-05 18:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
DEBUG - 2023-11-05 18:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
DEBUG - 2023-11-05 18:03:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
INFO - 2023-11-05 18:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-05 18:03:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 18:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 18:03:44 --> Model Class Initialized
INFO - 2023-11-05 18:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 18:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 18:03:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 18:03:45 --> Final output sent to browser
DEBUG - 2023-11-05 18:03:45 --> Total execution time: 0.3830
ERROR - 2023-11-05 18:03:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:03:45 --> Config Class Initialized
INFO - 2023-11-05 18:03:45 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:03:45 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:03:45 --> Utf8 Class Initialized
INFO - 2023-11-05 18:03:45 --> URI Class Initialized
INFO - 2023-11-05 18:03:45 --> Router Class Initialized
INFO - 2023-11-05 18:03:45 --> Output Class Initialized
INFO - 2023-11-05 18:03:45 --> Security Class Initialized
DEBUG - 2023-11-05 18:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:03:45 --> Input Class Initialized
INFO - 2023-11-05 18:03:45 --> Language Class Initialized
INFO - 2023-11-05 18:03:45 --> Loader Class Initialized
INFO - 2023-11-05 18:03:45 --> Helper loaded: url_helper
INFO - 2023-11-05 18:03:45 --> Helper loaded: file_helper
INFO - 2023-11-05 18:03:45 --> Helper loaded: html_helper
INFO - 2023-11-05 18:03:45 --> Helper loaded: text_helper
INFO - 2023-11-05 18:03:45 --> Helper loaded: form_helper
INFO - 2023-11-05 18:03:45 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:03:45 --> Helper loaded: security_helper
INFO - 2023-11-05 18:03:45 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:03:45 --> Database Driver Class Initialized
INFO - 2023-11-05 18:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:03:45 --> Parser Class Initialized
INFO - 2023-11-05 18:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:03:45 --> Pagination Class Initialized
INFO - 2023-11-05 18:03:45 --> Form Validation Class Initialized
INFO - 2023-11-05 18:03:45 --> Controller Class Initialized
DEBUG - 2023-11-05 18:03:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:03:45 --> Model Class Initialized
INFO - 2023-11-05 18:03:45 --> Final output sent to browser
DEBUG - 2023-11-05 18:03:45 --> Total execution time: 0.0136
ERROR - 2023-11-05 18:04:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:04:13 --> Config Class Initialized
INFO - 2023-11-05 18:04:13 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:04:13 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:04:13 --> Utf8 Class Initialized
INFO - 2023-11-05 18:04:13 --> URI Class Initialized
INFO - 2023-11-05 18:04:13 --> Router Class Initialized
INFO - 2023-11-05 18:04:13 --> Output Class Initialized
INFO - 2023-11-05 18:04:13 --> Security Class Initialized
DEBUG - 2023-11-05 18:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:04:13 --> Input Class Initialized
INFO - 2023-11-05 18:04:13 --> Language Class Initialized
INFO - 2023-11-05 18:04:13 --> Loader Class Initialized
INFO - 2023-11-05 18:04:13 --> Helper loaded: url_helper
INFO - 2023-11-05 18:04:13 --> Helper loaded: file_helper
INFO - 2023-11-05 18:04:13 --> Helper loaded: html_helper
INFO - 2023-11-05 18:04:13 --> Helper loaded: text_helper
INFO - 2023-11-05 18:04:13 --> Helper loaded: form_helper
INFO - 2023-11-05 18:04:13 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:04:13 --> Helper loaded: security_helper
INFO - 2023-11-05 18:04:13 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:04:13 --> Database Driver Class Initialized
INFO - 2023-11-05 18:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:04:13 --> Parser Class Initialized
INFO - 2023-11-05 18:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:04:13 --> Pagination Class Initialized
INFO - 2023-11-05 18:04:13 --> Form Validation Class Initialized
INFO - 2023-11-05 18:04:13 --> Controller Class Initialized
INFO - 2023-11-05 18:04:13 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:13 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:13 --> Model Class Initialized
INFO - 2023-11-05 18:04:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-05 18:04:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 18:04:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 18:04:13 --> Model Class Initialized
INFO - 2023-11-05 18:04:13 --> Model Class Initialized
INFO - 2023-11-05 18:04:13 --> Model Class Initialized
INFO - 2023-11-05 18:04:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 18:04:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 18:04:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 18:04:14 --> Final output sent to browser
DEBUG - 2023-11-05 18:04:14 --> Total execution time: 0.2300
ERROR - 2023-11-05 18:04:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:04:14 --> Config Class Initialized
INFO - 2023-11-05 18:04:14 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:04:14 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:04:14 --> Utf8 Class Initialized
INFO - 2023-11-05 18:04:14 --> URI Class Initialized
INFO - 2023-11-05 18:04:14 --> Router Class Initialized
INFO - 2023-11-05 18:04:14 --> Output Class Initialized
INFO - 2023-11-05 18:04:14 --> Security Class Initialized
DEBUG - 2023-11-05 18:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:04:14 --> Input Class Initialized
INFO - 2023-11-05 18:04:14 --> Language Class Initialized
INFO - 2023-11-05 18:04:14 --> Loader Class Initialized
INFO - 2023-11-05 18:04:14 --> Helper loaded: url_helper
INFO - 2023-11-05 18:04:14 --> Helper loaded: file_helper
INFO - 2023-11-05 18:04:14 --> Helper loaded: html_helper
INFO - 2023-11-05 18:04:14 --> Helper loaded: text_helper
INFO - 2023-11-05 18:04:14 --> Helper loaded: form_helper
INFO - 2023-11-05 18:04:14 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:04:14 --> Helper loaded: security_helper
INFO - 2023-11-05 18:04:14 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:04:14 --> Database Driver Class Initialized
INFO - 2023-11-05 18:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:04:14 --> Parser Class Initialized
INFO - 2023-11-05 18:04:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:04:14 --> Pagination Class Initialized
INFO - 2023-11-05 18:04:14 --> Form Validation Class Initialized
INFO - 2023-11-05 18:04:14 --> Controller Class Initialized
INFO - 2023-11-05 18:04:14 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:04:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:14 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:14 --> Model Class Initialized
INFO - 2023-11-05 18:04:14 --> Final output sent to browser
DEBUG - 2023-11-05 18:04:14 --> Total execution time: 0.0594
ERROR - 2023-11-05 18:04:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:04:22 --> Config Class Initialized
INFO - 2023-11-05 18:04:22 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:04:22 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:04:22 --> Utf8 Class Initialized
INFO - 2023-11-05 18:04:22 --> URI Class Initialized
INFO - 2023-11-05 18:04:22 --> Router Class Initialized
INFO - 2023-11-05 18:04:22 --> Output Class Initialized
INFO - 2023-11-05 18:04:22 --> Security Class Initialized
DEBUG - 2023-11-05 18:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:04:22 --> Input Class Initialized
INFO - 2023-11-05 18:04:22 --> Language Class Initialized
INFO - 2023-11-05 18:04:22 --> Loader Class Initialized
INFO - 2023-11-05 18:04:22 --> Helper loaded: url_helper
INFO - 2023-11-05 18:04:22 --> Helper loaded: file_helper
INFO - 2023-11-05 18:04:22 --> Helper loaded: html_helper
INFO - 2023-11-05 18:04:22 --> Helper loaded: text_helper
INFO - 2023-11-05 18:04:22 --> Helper loaded: form_helper
INFO - 2023-11-05 18:04:22 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:04:22 --> Helper loaded: security_helper
INFO - 2023-11-05 18:04:22 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:04:22 --> Database Driver Class Initialized
INFO - 2023-11-05 18:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:04:22 --> Parser Class Initialized
INFO - 2023-11-05 18:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:04:22 --> Pagination Class Initialized
INFO - 2023-11-05 18:04:22 --> Form Validation Class Initialized
INFO - 2023-11-05 18:04:22 --> Controller Class Initialized
INFO - 2023-11-05 18:04:22 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:22 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:22 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-11-05 18:04:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 18:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 18:04:22 --> Model Class Initialized
INFO - 2023-11-05 18:04:22 --> Model Class Initialized
INFO - 2023-11-05 18:04:22 --> Model Class Initialized
INFO - 2023-11-05 18:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 18:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 18:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 18:04:22 --> Final output sent to browser
DEBUG - 2023-11-05 18:04:22 --> Total execution time: 0.2131
ERROR - 2023-11-05 18:04:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:04:28 --> Config Class Initialized
INFO - 2023-11-05 18:04:28 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:04:28 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:04:28 --> Utf8 Class Initialized
INFO - 2023-11-05 18:04:28 --> URI Class Initialized
INFO - 2023-11-05 18:04:28 --> Router Class Initialized
INFO - 2023-11-05 18:04:28 --> Output Class Initialized
INFO - 2023-11-05 18:04:28 --> Security Class Initialized
DEBUG - 2023-11-05 18:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:04:28 --> Input Class Initialized
INFO - 2023-11-05 18:04:28 --> Language Class Initialized
INFO - 2023-11-05 18:04:28 --> Loader Class Initialized
INFO - 2023-11-05 18:04:28 --> Helper loaded: url_helper
INFO - 2023-11-05 18:04:28 --> Helper loaded: file_helper
INFO - 2023-11-05 18:04:28 --> Helper loaded: html_helper
INFO - 2023-11-05 18:04:28 --> Helper loaded: text_helper
INFO - 2023-11-05 18:04:28 --> Helper loaded: form_helper
INFO - 2023-11-05 18:04:28 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:04:28 --> Helper loaded: security_helper
INFO - 2023-11-05 18:04:28 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:04:28 --> Database Driver Class Initialized
INFO - 2023-11-05 18:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:04:28 --> Parser Class Initialized
INFO - 2023-11-05 18:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:04:28 --> Pagination Class Initialized
INFO - 2023-11-05 18:04:28 --> Form Validation Class Initialized
INFO - 2023-11-05 18:04:28 --> Controller Class Initialized
INFO - 2023-11-05 18:04:28 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:28 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:28 --> Model Class Initialized
INFO - 2023-11-05 18:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-05 18:04:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 18:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 18:04:28 --> Model Class Initialized
INFO - 2023-11-05 18:04:28 --> Model Class Initialized
INFO - 2023-11-05 18:04:28 --> Model Class Initialized
INFO - 2023-11-05 18:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-05 18:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-05 18:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 18:04:28 --> Final output sent to browser
DEBUG - 2023-11-05 18:04:28 --> Total execution time: 0.1996
ERROR - 2023-11-05 18:04:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:04:29 --> Config Class Initialized
INFO - 2023-11-05 18:04:29 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:04:29 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:04:29 --> Utf8 Class Initialized
INFO - 2023-11-05 18:04:29 --> URI Class Initialized
INFO - 2023-11-05 18:04:29 --> Router Class Initialized
INFO - 2023-11-05 18:04:29 --> Output Class Initialized
INFO - 2023-11-05 18:04:29 --> Security Class Initialized
DEBUG - 2023-11-05 18:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:04:29 --> Input Class Initialized
INFO - 2023-11-05 18:04:29 --> Language Class Initialized
INFO - 2023-11-05 18:04:29 --> Loader Class Initialized
INFO - 2023-11-05 18:04:29 --> Helper loaded: url_helper
INFO - 2023-11-05 18:04:29 --> Helper loaded: file_helper
INFO - 2023-11-05 18:04:29 --> Helper loaded: html_helper
INFO - 2023-11-05 18:04:29 --> Helper loaded: text_helper
INFO - 2023-11-05 18:04:29 --> Helper loaded: form_helper
INFO - 2023-11-05 18:04:29 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:04:29 --> Helper loaded: security_helper
INFO - 2023-11-05 18:04:29 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:04:29 --> Database Driver Class Initialized
INFO - 2023-11-05 18:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:04:29 --> Parser Class Initialized
INFO - 2023-11-05 18:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:04:29 --> Pagination Class Initialized
INFO - 2023-11-05 18:04:29 --> Form Validation Class Initialized
INFO - 2023-11-05 18:04:29 --> Controller Class Initialized
INFO - 2023-11-05 18:04:29 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:29 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:29 --> Model Class Initialized
INFO - 2023-11-05 18:04:29 --> Final output sent to browser
DEBUG - 2023-11-05 18:04:29 --> Total execution time: 0.0549
ERROR - 2023-11-05 18:04:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:04:32 --> Config Class Initialized
INFO - 2023-11-05 18:04:32 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:04:32 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:04:32 --> Utf8 Class Initialized
INFO - 2023-11-05 18:04:32 --> URI Class Initialized
INFO - 2023-11-05 18:04:32 --> Router Class Initialized
INFO - 2023-11-05 18:04:32 --> Output Class Initialized
INFO - 2023-11-05 18:04:32 --> Security Class Initialized
DEBUG - 2023-11-05 18:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:04:32 --> Input Class Initialized
INFO - 2023-11-05 18:04:32 --> Language Class Initialized
INFO - 2023-11-05 18:04:32 --> Loader Class Initialized
INFO - 2023-11-05 18:04:32 --> Helper loaded: url_helper
INFO - 2023-11-05 18:04:32 --> Helper loaded: file_helper
INFO - 2023-11-05 18:04:32 --> Helper loaded: html_helper
INFO - 2023-11-05 18:04:32 --> Helper loaded: text_helper
INFO - 2023-11-05 18:04:32 --> Helper loaded: form_helper
INFO - 2023-11-05 18:04:32 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:04:32 --> Helper loaded: security_helper
INFO - 2023-11-05 18:04:32 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:04:32 --> Database Driver Class Initialized
INFO - 2023-11-05 18:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:04:32 --> Parser Class Initialized
INFO - 2023-11-05 18:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:04:32 --> Pagination Class Initialized
INFO - 2023-11-05 18:04:32 --> Form Validation Class Initialized
INFO - 2023-11-05 18:04:32 --> Controller Class Initialized
INFO - 2023-11-05 18:04:32 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:32 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:32 --> Model Class Initialized
DEBUG - 2023-11-05 18:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:04:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:04:32 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-11-05 18:04:32 --> Final output sent to browser
DEBUG - 2023-11-05 18:04:32 --> Total execution time: 0.2216
ERROR - 2023-11-05 18:05:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:05:03 --> Config Class Initialized
INFO - 2023-11-05 18:05:03 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:05:03 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:05:03 --> Utf8 Class Initialized
INFO - 2023-11-05 18:05:03 --> URI Class Initialized
INFO - 2023-11-05 18:05:03 --> Router Class Initialized
INFO - 2023-11-05 18:05:03 --> Output Class Initialized
INFO - 2023-11-05 18:05:03 --> Security Class Initialized
DEBUG - 2023-11-05 18:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:05:03 --> Input Class Initialized
INFO - 2023-11-05 18:05:03 --> Language Class Initialized
INFO - 2023-11-05 18:05:03 --> Loader Class Initialized
INFO - 2023-11-05 18:05:03 --> Helper loaded: url_helper
INFO - 2023-11-05 18:05:03 --> Helper loaded: file_helper
INFO - 2023-11-05 18:05:03 --> Helper loaded: html_helper
INFO - 2023-11-05 18:05:03 --> Helper loaded: text_helper
INFO - 2023-11-05 18:05:03 --> Helper loaded: form_helper
INFO - 2023-11-05 18:05:03 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:05:03 --> Helper loaded: security_helper
INFO - 2023-11-05 18:05:03 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:05:03 --> Database Driver Class Initialized
INFO - 2023-11-05 18:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:05:03 --> Parser Class Initialized
INFO - 2023-11-05 18:05:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:05:03 --> Pagination Class Initialized
INFO - 2023-11-05 18:05:03 --> Form Validation Class Initialized
INFO - 2023-11-05 18:05:03 --> Controller Class Initialized
INFO - 2023-11-05 18:05:03 --> Model Class Initialized
DEBUG - 2023-11-05 18:05:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:05:03 --> Model Class Initialized
DEBUG - 2023-11-05 18:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:05:03 --> Model Class Initialized
DEBUG - 2023-11-05 18:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:05:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:05:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-11-05 18:05:03 --> Final output sent to browser
DEBUG - 2023-11-05 18:05:03 --> Total execution time: 0.2202
ERROR - 2023-11-05 18:07:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:07:02 --> Config Class Initialized
INFO - 2023-11-05 18:07:02 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:07:02 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:07:02 --> Utf8 Class Initialized
INFO - 2023-11-05 18:07:02 --> URI Class Initialized
INFO - 2023-11-05 18:07:02 --> Router Class Initialized
INFO - 2023-11-05 18:07:02 --> Output Class Initialized
INFO - 2023-11-05 18:07:02 --> Security Class Initialized
DEBUG - 2023-11-05 18:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:07:02 --> Input Class Initialized
INFO - 2023-11-05 18:07:02 --> Language Class Initialized
INFO - 2023-11-05 18:07:02 --> Loader Class Initialized
INFO - 2023-11-05 18:07:02 --> Helper loaded: url_helper
INFO - 2023-11-05 18:07:02 --> Helper loaded: file_helper
INFO - 2023-11-05 18:07:02 --> Helper loaded: html_helper
INFO - 2023-11-05 18:07:02 --> Helper loaded: text_helper
INFO - 2023-11-05 18:07:02 --> Helper loaded: form_helper
INFO - 2023-11-05 18:07:02 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:07:02 --> Helper loaded: security_helper
INFO - 2023-11-05 18:07:02 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:07:02 --> Database Driver Class Initialized
INFO - 2023-11-05 18:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:07:02 --> Parser Class Initialized
INFO - 2023-11-05 18:07:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:07:02 --> Pagination Class Initialized
INFO - 2023-11-05 18:07:02 --> Form Validation Class Initialized
INFO - 2023-11-05 18:07:02 --> Controller Class Initialized
INFO - 2023-11-05 18:07:02 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:02 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:02 --> Model Class Initialized
INFO - 2023-11-05 18:07:02 --> Final output sent to browser
DEBUG - 2023-11-05 18:07:02 --> Total execution time: 0.0622
ERROR - 2023-11-05 18:07:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:07:03 --> Config Class Initialized
INFO - 2023-11-05 18:07:03 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:07:03 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:07:03 --> Utf8 Class Initialized
INFO - 2023-11-05 18:07:03 --> URI Class Initialized
INFO - 2023-11-05 18:07:03 --> Router Class Initialized
INFO - 2023-11-05 18:07:03 --> Output Class Initialized
INFO - 2023-11-05 18:07:03 --> Security Class Initialized
DEBUG - 2023-11-05 18:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:07:03 --> Input Class Initialized
INFO - 2023-11-05 18:07:03 --> Language Class Initialized
INFO - 2023-11-05 18:07:03 --> Loader Class Initialized
INFO - 2023-11-05 18:07:03 --> Helper loaded: url_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: file_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: html_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: text_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: form_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: security_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:07:03 --> Database Driver Class Initialized
INFO - 2023-11-05 18:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:07:03 --> Parser Class Initialized
INFO - 2023-11-05 18:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:07:03 --> Pagination Class Initialized
INFO - 2023-11-05 18:07:03 --> Form Validation Class Initialized
INFO - 2023-11-05 18:07:03 --> Controller Class Initialized
INFO - 2023-11-05 18:07:03 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:03 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:03 --> Model Class Initialized
INFO - 2023-11-05 18:07:03 --> Final output sent to browser
DEBUG - 2023-11-05 18:07:03 --> Total execution time: 0.0591
ERROR - 2023-11-05 18:07:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:07:03 --> Config Class Initialized
INFO - 2023-11-05 18:07:03 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:07:03 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:07:03 --> Utf8 Class Initialized
INFO - 2023-11-05 18:07:03 --> URI Class Initialized
INFO - 2023-11-05 18:07:03 --> Router Class Initialized
INFO - 2023-11-05 18:07:03 --> Output Class Initialized
INFO - 2023-11-05 18:07:03 --> Security Class Initialized
DEBUG - 2023-11-05 18:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:07:03 --> Input Class Initialized
INFO - 2023-11-05 18:07:03 --> Language Class Initialized
INFO - 2023-11-05 18:07:03 --> Loader Class Initialized
INFO - 2023-11-05 18:07:03 --> Helper loaded: url_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: file_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: html_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: text_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: form_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: security_helper
INFO - 2023-11-05 18:07:03 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:07:03 --> Database Driver Class Initialized
INFO - 2023-11-05 18:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:07:03 --> Parser Class Initialized
INFO - 2023-11-05 18:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:07:03 --> Pagination Class Initialized
INFO - 2023-11-05 18:07:03 --> Form Validation Class Initialized
INFO - 2023-11-05 18:07:03 --> Controller Class Initialized
INFO - 2023-11-05 18:07:03 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:03 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:03 --> Model Class Initialized
INFO - 2023-11-05 18:07:03 --> Final output sent to browser
DEBUG - 2023-11-05 18:07:03 --> Total execution time: 0.0625
ERROR - 2023-11-05 18:07:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:07:11 --> Config Class Initialized
INFO - 2023-11-05 18:07:11 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:07:11 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:07:11 --> Utf8 Class Initialized
INFO - 2023-11-05 18:07:11 --> URI Class Initialized
INFO - 2023-11-05 18:07:11 --> Router Class Initialized
INFO - 2023-11-05 18:07:11 --> Output Class Initialized
INFO - 2023-11-05 18:07:11 --> Security Class Initialized
DEBUG - 2023-11-05 18:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:07:11 --> Input Class Initialized
INFO - 2023-11-05 18:07:11 --> Language Class Initialized
INFO - 2023-11-05 18:07:11 --> Loader Class Initialized
INFO - 2023-11-05 18:07:11 --> Helper loaded: url_helper
INFO - 2023-11-05 18:07:11 --> Helper loaded: file_helper
INFO - 2023-11-05 18:07:11 --> Helper loaded: html_helper
INFO - 2023-11-05 18:07:11 --> Helper loaded: text_helper
INFO - 2023-11-05 18:07:11 --> Helper loaded: form_helper
INFO - 2023-11-05 18:07:11 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:07:11 --> Helper loaded: security_helper
INFO - 2023-11-05 18:07:11 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:07:11 --> Database Driver Class Initialized
INFO - 2023-11-05 18:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:07:11 --> Parser Class Initialized
INFO - 2023-11-05 18:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:07:11 --> Pagination Class Initialized
INFO - 2023-11-05 18:07:11 --> Form Validation Class Initialized
INFO - 2023-11-05 18:07:11 --> Controller Class Initialized
INFO - 2023-11-05 18:07:11 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:11 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:11 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:11 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-11-05 18:07:11 --> Final output sent to browser
DEBUG - 2023-11-05 18:07:11 --> Total execution time: 0.2150
ERROR - 2023-11-05 18:07:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:07:36 --> Config Class Initialized
INFO - 2023-11-05 18:07:36 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:07:36 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:07:36 --> Utf8 Class Initialized
INFO - 2023-11-05 18:07:36 --> URI Class Initialized
INFO - 2023-11-05 18:07:36 --> Router Class Initialized
INFO - 2023-11-05 18:07:36 --> Output Class Initialized
INFO - 2023-11-05 18:07:36 --> Security Class Initialized
DEBUG - 2023-11-05 18:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:07:36 --> Input Class Initialized
INFO - 2023-11-05 18:07:36 --> Language Class Initialized
INFO - 2023-11-05 18:07:36 --> Loader Class Initialized
INFO - 2023-11-05 18:07:36 --> Helper loaded: url_helper
INFO - 2023-11-05 18:07:36 --> Helper loaded: file_helper
INFO - 2023-11-05 18:07:36 --> Helper loaded: html_helper
INFO - 2023-11-05 18:07:36 --> Helper loaded: text_helper
INFO - 2023-11-05 18:07:36 --> Helper loaded: form_helper
INFO - 2023-11-05 18:07:36 --> Helper loaded: lang_helper
INFO - 2023-11-05 18:07:36 --> Helper loaded: security_helper
INFO - 2023-11-05 18:07:36 --> Helper loaded: cookie_helper
INFO - 2023-11-05 18:07:36 --> Database Driver Class Initialized
INFO - 2023-11-05 18:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:07:36 --> Parser Class Initialized
INFO - 2023-11-05 18:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 18:07:36 --> Pagination Class Initialized
INFO - 2023-11-05 18:07:36 --> Form Validation Class Initialized
INFO - 2023-11-05 18:07:36 --> Controller Class Initialized
INFO - 2023-11-05 18:07:36 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:36 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:36 --> Model Class Initialized
DEBUG - 2023-11-05 18:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:07:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-11-05 18:07:36 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-11-05 18:07:36 --> Final output sent to browser
DEBUG - 2023-11-05 18:07:36 --> Total execution time: 0.1868
ERROR - 2023-11-05 20:06:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 20:06:03 --> Config Class Initialized
INFO - 2023-11-05 20:06:03 --> Hooks Class Initialized
DEBUG - 2023-11-05 20:06:03 --> UTF-8 Support Enabled
INFO - 2023-11-05 20:06:03 --> Utf8 Class Initialized
INFO - 2023-11-05 20:06:03 --> URI Class Initialized
DEBUG - 2023-11-05 20:06:03 --> No URI present. Default controller set.
INFO - 2023-11-05 20:06:03 --> Router Class Initialized
INFO - 2023-11-05 20:06:03 --> Output Class Initialized
INFO - 2023-11-05 20:06:03 --> Security Class Initialized
DEBUG - 2023-11-05 20:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 20:06:03 --> Input Class Initialized
INFO - 2023-11-05 20:06:03 --> Language Class Initialized
INFO - 2023-11-05 20:06:03 --> Loader Class Initialized
INFO - 2023-11-05 20:06:03 --> Helper loaded: url_helper
INFO - 2023-11-05 20:06:03 --> Helper loaded: file_helper
INFO - 2023-11-05 20:06:03 --> Helper loaded: html_helper
INFO - 2023-11-05 20:06:03 --> Helper loaded: text_helper
INFO - 2023-11-05 20:06:03 --> Helper loaded: form_helper
INFO - 2023-11-05 20:06:03 --> Helper loaded: lang_helper
INFO - 2023-11-05 20:06:03 --> Helper loaded: security_helper
INFO - 2023-11-05 20:06:03 --> Helper loaded: cookie_helper
INFO - 2023-11-05 20:06:03 --> Database Driver Class Initialized
INFO - 2023-11-05 20:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 20:06:03 --> Parser Class Initialized
INFO - 2023-11-05 20:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 20:06:03 --> Pagination Class Initialized
INFO - 2023-11-05 20:06:03 --> Form Validation Class Initialized
INFO - 2023-11-05 20:06:03 --> Controller Class Initialized
INFO - 2023-11-05 20:06:03 --> Model Class Initialized
DEBUG - 2023-11-05 20:06:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-05 20:06:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 20:06:04 --> Config Class Initialized
INFO - 2023-11-05 20:06:04 --> Hooks Class Initialized
DEBUG - 2023-11-05 20:06:04 --> UTF-8 Support Enabled
INFO - 2023-11-05 20:06:04 --> Utf8 Class Initialized
INFO - 2023-11-05 20:06:04 --> URI Class Initialized
INFO - 2023-11-05 20:06:04 --> Router Class Initialized
INFO - 2023-11-05 20:06:04 --> Output Class Initialized
INFO - 2023-11-05 20:06:04 --> Security Class Initialized
DEBUG - 2023-11-05 20:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 20:06:04 --> Input Class Initialized
INFO - 2023-11-05 20:06:04 --> Language Class Initialized
INFO - 2023-11-05 20:06:04 --> Loader Class Initialized
INFO - 2023-11-05 20:06:04 --> Helper loaded: url_helper
INFO - 2023-11-05 20:06:04 --> Helper loaded: file_helper
INFO - 2023-11-05 20:06:04 --> Helper loaded: html_helper
INFO - 2023-11-05 20:06:04 --> Helper loaded: text_helper
INFO - 2023-11-05 20:06:04 --> Helper loaded: form_helper
INFO - 2023-11-05 20:06:04 --> Helper loaded: lang_helper
INFO - 2023-11-05 20:06:04 --> Helper loaded: security_helper
INFO - 2023-11-05 20:06:04 --> Helper loaded: cookie_helper
INFO - 2023-11-05 20:06:04 --> Database Driver Class Initialized
INFO - 2023-11-05 20:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 20:06:04 --> Parser Class Initialized
INFO - 2023-11-05 20:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 20:06:04 --> Pagination Class Initialized
INFO - 2023-11-05 20:06:04 --> Form Validation Class Initialized
INFO - 2023-11-05 20:06:04 --> Controller Class Initialized
INFO - 2023-11-05 20:06:04 --> Model Class Initialized
DEBUG - 2023-11-05 20:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 20:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 20:06:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 20:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 20:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 20:06:04 --> Model Class Initialized
INFO - 2023-11-05 20:06:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 20:06:04 --> Final output sent to browser
DEBUG - 2023-11-05 20:06:04 --> Total execution time: 0.0362
ERROR - 2023-11-05 20:11:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 20:11:58 --> Config Class Initialized
INFO - 2023-11-05 20:11:58 --> Hooks Class Initialized
DEBUG - 2023-11-05 20:11:58 --> UTF-8 Support Enabled
INFO - 2023-11-05 20:11:58 --> Utf8 Class Initialized
INFO - 2023-11-05 20:11:58 --> URI Class Initialized
DEBUG - 2023-11-05 20:11:58 --> No URI present. Default controller set.
INFO - 2023-11-05 20:11:58 --> Router Class Initialized
INFO - 2023-11-05 20:11:58 --> Output Class Initialized
INFO - 2023-11-05 20:11:58 --> Security Class Initialized
DEBUG - 2023-11-05 20:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 20:11:58 --> Input Class Initialized
INFO - 2023-11-05 20:11:58 --> Language Class Initialized
INFO - 2023-11-05 20:11:58 --> Loader Class Initialized
INFO - 2023-11-05 20:11:58 --> Helper loaded: url_helper
INFO - 2023-11-05 20:11:58 --> Helper loaded: file_helper
INFO - 2023-11-05 20:11:58 --> Helper loaded: html_helper
INFO - 2023-11-05 20:11:58 --> Helper loaded: text_helper
INFO - 2023-11-05 20:11:58 --> Helper loaded: form_helper
INFO - 2023-11-05 20:11:58 --> Helper loaded: lang_helper
INFO - 2023-11-05 20:11:58 --> Helper loaded: security_helper
INFO - 2023-11-05 20:11:58 --> Helper loaded: cookie_helper
INFO - 2023-11-05 20:11:58 --> Database Driver Class Initialized
INFO - 2023-11-05 20:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 20:11:58 --> Parser Class Initialized
INFO - 2023-11-05 20:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 20:11:58 --> Pagination Class Initialized
INFO - 2023-11-05 20:11:58 --> Form Validation Class Initialized
INFO - 2023-11-05 20:11:58 --> Controller Class Initialized
INFO - 2023-11-05 20:11:58 --> Model Class Initialized
DEBUG - 2023-11-05 20:11:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-05 20:11:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 20:11:59 --> Config Class Initialized
INFO - 2023-11-05 20:11:59 --> Hooks Class Initialized
DEBUG - 2023-11-05 20:11:59 --> UTF-8 Support Enabled
INFO - 2023-11-05 20:11:59 --> Utf8 Class Initialized
INFO - 2023-11-05 20:11:59 --> URI Class Initialized
INFO - 2023-11-05 20:11:59 --> Router Class Initialized
INFO - 2023-11-05 20:11:59 --> Output Class Initialized
INFO - 2023-11-05 20:11:59 --> Security Class Initialized
DEBUG - 2023-11-05 20:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 20:11:59 --> Input Class Initialized
INFO - 2023-11-05 20:11:59 --> Language Class Initialized
INFO - 2023-11-05 20:11:59 --> Loader Class Initialized
INFO - 2023-11-05 20:11:59 --> Helper loaded: url_helper
INFO - 2023-11-05 20:11:59 --> Helper loaded: file_helper
INFO - 2023-11-05 20:11:59 --> Helper loaded: html_helper
INFO - 2023-11-05 20:11:59 --> Helper loaded: text_helper
INFO - 2023-11-05 20:11:59 --> Helper loaded: form_helper
INFO - 2023-11-05 20:11:59 --> Helper loaded: lang_helper
INFO - 2023-11-05 20:11:59 --> Helper loaded: security_helper
INFO - 2023-11-05 20:11:59 --> Helper loaded: cookie_helper
INFO - 2023-11-05 20:11:59 --> Database Driver Class Initialized
INFO - 2023-11-05 20:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 20:11:59 --> Parser Class Initialized
INFO - 2023-11-05 20:11:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 20:11:59 --> Pagination Class Initialized
INFO - 2023-11-05 20:11:59 --> Form Validation Class Initialized
INFO - 2023-11-05 20:11:59 --> Controller Class Initialized
INFO - 2023-11-05 20:11:59 --> Model Class Initialized
DEBUG - 2023-11-05 20:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 20:11:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 20:11:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 20:11:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 20:11:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 20:11:59 --> Model Class Initialized
INFO - 2023-11-05 20:11:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 20:11:59 --> Final output sent to browser
DEBUG - 2023-11-05 20:11:59 --> Total execution time: 0.0333
ERROR - 2023-11-05 21:41:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 21:41:58 --> Config Class Initialized
INFO - 2023-11-05 21:41:58 --> Hooks Class Initialized
DEBUG - 2023-11-05 21:41:58 --> UTF-8 Support Enabled
INFO - 2023-11-05 21:41:58 --> Utf8 Class Initialized
INFO - 2023-11-05 21:41:58 --> URI Class Initialized
DEBUG - 2023-11-05 21:41:58 --> No URI present. Default controller set.
INFO - 2023-11-05 21:41:58 --> Router Class Initialized
INFO - 2023-11-05 21:41:58 --> Output Class Initialized
INFO - 2023-11-05 21:41:58 --> Security Class Initialized
DEBUG - 2023-11-05 21:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 21:41:58 --> Input Class Initialized
INFO - 2023-11-05 21:41:58 --> Language Class Initialized
INFO - 2023-11-05 21:41:58 --> Loader Class Initialized
INFO - 2023-11-05 21:41:58 --> Helper loaded: url_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: file_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: html_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: text_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: form_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: lang_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: security_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: cookie_helper
INFO - 2023-11-05 21:41:58 --> Database Driver Class Initialized
INFO - 2023-11-05 21:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 21:41:58 --> Parser Class Initialized
INFO - 2023-11-05 21:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 21:41:58 --> Pagination Class Initialized
INFO - 2023-11-05 21:41:58 --> Form Validation Class Initialized
INFO - 2023-11-05 21:41:58 --> Controller Class Initialized
INFO - 2023-11-05 21:41:58 --> Model Class Initialized
DEBUG - 2023-11-05 21:41:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-05 21:41:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-05 21:41:58 --> Config Class Initialized
INFO - 2023-11-05 21:41:58 --> Hooks Class Initialized
DEBUG - 2023-11-05 21:41:58 --> UTF-8 Support Enabled
INFO - 2023-11-05 21:41:58 --> Utf8 Class Initialized
INFO - 2023-11-05 21:41:58 --> URI Class Initialized
INFO - 2023-11-05 21:41:58 --> Router Class Initialized
INFO - 2023-11-05 21:41:58 --> Output Class Initialized
INFO - 2023-11-05 21:41:58 --> Security Class Initialized
DEBUG - 2023-11-05 21:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 21:41:58 --> Input Class Initialized
INFO - 2023-11-05 21:41:58 --> Language Class Initialized
INFO - 2023-11-05 21:41:58 --> Loader Class Initialized
INFO - 2023-11-05 21:41:58 --> Helper loaded: url_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: file_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: html_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: text_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: form_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: lang_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: security_helper
INFO - 2023-11-05 21:41:58 --> Helper loaded: cookie_helper
INFO - 2023-11-05 21:41:58 --> Database Driver Class Initialized
INFO - 2023-11-05 21:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 21:41:58 --> Parser Class Initialized
INFO - 2023-11-05 21:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-05 21:41:58 --> Pagination Class Initialized
INFO - 2023-11-05 21:41:58 --> Form Validation Class Initialized
INFO - 2023-11-05 21:41:58 --> Controller Class Initialized
INFO - 2023-11-05 21:41:58 --> Model Class Initialized
DEBUG - 2023-11-05 21:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-05 21:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-05 21:41:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-05 21:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-05 21:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-05 21:41:58 --> Model Class Initialized
INFO - 2023-11-05 21:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-05 21:41:58 --> Final output sent to browser
DEBUG - 2023-11-05 21:41:58 --> Total execution time: 0.0324
