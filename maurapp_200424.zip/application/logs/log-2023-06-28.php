<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-28 02:48:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 02:48:52 --> Config Class Initialized
INFO - 2023-06-28 02:48:52 --> Hooks Class Initialized
DEBUG - 2023-06-28 02:48:52 --> UTF-8 Support Enabled
INFO - 2023-06-28 02:48:52 --> Utf8 Class Initialized
INFO - 2023-06-28 02:48:52 --> URI Class Initialized
DEBUG - 2023-06-28 02:48:52 --> No URI present. Default controller set.
INFO - 2023-06-28 02:48:52 --> Router Class Initialized
INFO - 2023-06-28 02:48:52 --> Output Class Initialized
INFO - 2023-06-28 02:48:52 --> Security Class Initialized
DEBUG - 2023-06-28 02:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 02:48:52 --> Input Class Initialized
INFO - 2023-06-28 02:48:52 --> Language Class Initialized
INFO - 2023-06-28 02:48:52 --> Loader Class Initialized
INFO - 2023-06-28 02:48:52 --> Helper loaded: url_helper
INFO - 2023-06-28 02:48:52 --> Helper loaded: file_helper
INFO - 2023-06-28 02:48:52 --> Helper loaded: html_helper
INFO - 2023-06-28 02:48:52 --> Helper loaded: text_helper
INFO - 2023-06-28 02:48:52 --> Helper loaded: form_helper
INFO - 2023-06-28 02:48:52 --> Helper loaded: lang_helper
INFO - 2023-06-28 02:48:52 --> Helper loaded: security_helper
INFO - 2023-06-28 02:48:52 --> Helper loaded: cookie_helper
INFO - 2023-06-28 02:48:52 --> Database Driver Class Initialized
INFO - 2023-06-28 02:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 02:48:52 --> Parser Class Initialized
INFO - 2023-06-28 02:48:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 02:48:52 --> Pagination Class Initialized
INFO - 2023-06-28 02:48:52 --> Form Validation Class Initialized
INFO - 2023-06-28 02:48:52 --> Controller Class Initialized
INFO - 2023-06-28 02:48:52 --> Model Class Initialized
DEBUG - 2023-06-28 02:48:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 02:48:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 02:48:53 --> Config Class Initialized
INFO - 2023-06-28 02:48:53 --> Hooks Class Initialized
DEBUG - 2023-06-28 02:48:53 --> UTF-8 Support Enabled
INFO - 2023-06-28 02:48:53 --> Utf8 Class Initialized
INFO - 2023-06-28 02:48:53 --> URI Class Initialized
INFO - 2023-06-28 02:48:53 --> Router Class Initialized
INFO - 2023-06-28 02:48:53 --> Output Class Initialized
INFO - 2023-06-28 02:48:53 --> Security Class Initialized
DEBUG - 2023-06-28 02:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 02:48:53 --> Input Class Initialized
INFO - 2023-06-28 02:48:53 --> Language Class Initialized
INFO - 2023-06-28 02:48:53 --> Loader Class Initialized
INFO - 2023-06-28 02:48:53 --> Helper loaded: url_helper
INFO - 2023-06-28 02:48:53 --> Helper loaded: file_helper
INFO - 2023-06-28 02:48:53 --> Helper loaded: html_helper
INFO - 2023-06-28 02:48:53 --> Helper loaded: text_helper
INFO - 2023-06-28 02:48:53 --> Helper loaded: form_helper
INFO - 2023-06-28 02:48:53 --> Helper loaded: lang_helper
INFO - 2023-06-28 02:48:53 --> Helper loaded: security_helper
INFO - 2023-06-28 02:48:53 --> Helper loaded: cookie_helper
INFO - 2023-06-28 02:48:53 --> Database Driver Class Initialized
INFO - 2023-06-28 02:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 02:48:53 --> Parser Class Initialized
INFO - 2023-06-28 02:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 02:48:53 --> Pagination Class Initialized
INFO - 2023-06-28 02:48:53 --> Form Validation Class Initialized
INFO - 2023-06-28 02:48:53 --> Controller Class Initialized
INFO - 2023-06-28 02:48:53 --> Model Class Initialized
DEBUG - 2023-06-28 02:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 02:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 02:48:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 02:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 02:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 02:48:53 --> Model Class Initialized
INFO - 2023-06-28 02:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 02:48:53 --> Final output sent to browser
DEBUG - 2023-06-28 02:48:53 --> Total execution time: 0.0388
ERROR - 2023-06-28 10:11:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:11:16 --> Config Class Initialized
INFO - 2023-06-28 10:11:16 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:11:16 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:11:16 --> Utf8 Class Initialized
INFO - 2023-06-28 10:11:16 --> URI Class Initialized
DEBUG - 2023-06-28 10:11:16 --> No URI present. Default controller set.
INFO - 2023-06-28 10:11:16 --> Router Class Initialized
INFO - 2023-06-28 10:11:16 --> Output Class Initialized
INFO - 2023-06-28 10:11:16 --> Security Class Initialized
DEBUG - 2023-06-28 10:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:11:16 --> Input Class Initialized
INFO - 2023-06-28 10:11:16 --> Language Class Initialized
INFO - 2023-06-28 10:11:16 --> Loader Class Initialized
INFO - 2023-06-28 10:11:16 --> Helper loaded: url_helper
INFO - 2023-06-28 10:11:16 --> Helper loaded: file_helper
INFO - 2023-06-28 10:11:16 --> Helper loaded: html_helper
INFO - 2023-06-28 10:11:16 --> Helper loaded: text_helper
INFO - 2023-06-28 10:11:16 --> Helper loaded: form_helper
INFO - 2023-06-28 10:11:16 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:11:16 --> Helper loaded: security_helper
INFO - 2023-06-28 10:11:16 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:11:16 --> Database Driver Class Initialized
INFO - 2023-06-28 10:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:11:16 --> Parser Class Initialized
INFO - 2023-06-28 10:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:11:16 --> Pagination Class Initialized
INFO - 2023-06-28 10:11:16 --> Form Validation Class Initialized
INFO - 2023-06-28 10:11:16 --> Controller Class Initialized
INFO - 2023-06-28 10:11:16 --> Model Class Initialized
DEBUG - 2023-06-28 10:11:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 10:11:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:11:17 --> Config Class Initialized
INFO - 2023-06-28 10:11:17 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:11:17 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:11:17 --> Utf8 Class Initialized
INFO - 2023-06-28 10:11:17 --> URI Class Initialized
INFO - 2023-06-28 10:11:17 --> Router Class Initialized
INFO - 2023-06-28 10:11:17 --> Output Class Initialized
INFO - 2023-06-28 10:11:17 --> Security Class Initialized
DEBUG - 2023-06-28 10:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:11:17 --> Input Class Initialized
INFO - 2023-06-28 10:11:17 --> Language Class Initialized
INFO - 2023-06-28 10:11:17 --> Loader Class Initialized
INFO - 2023-06-28 10:11:17 --> Helper loaded: url_helper
INFO - 2023-06-28 10:11:17 --> Helper loaded: file_helper
INFO - 2023-06-28 10:11:17 --> Helper loaded: html_helper
INFO - 2023-06-28 10:11:17 --> Helper loaded: text_helper
INFO - 2023-06-28 10:11:17 --> Helper loaded: form_helper
INFO - 2023-06-28 10:11:17 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:11:17 --> Helper loaded: security_helper
INFO - 2023-06-28 10:11:17 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:11:17 --> Database Driver Class Initialized
INFO - 2023-06-28 10:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:11:17 --> Parser Class Initialized
INFO - 2023-06-28 10:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:11:17 --> Pagination Class Initialized
INFO - 2023-06-28 10:11:17 --> Form Validation Class Initialized
INFO - 2023-06-28 10:11:17 --> Controller Class Initialized
INFO - 2023-06-28 10:11:17 --> Model Class Initialized
DEBUG - 2023-06-28 10:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 10:11:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:11:17 --> Model Class Initialized
INFO - 2023-06-28 10:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:11:17 --> Final output sent to browser
DEBUG - 2023-06-28 10:11:17 --> Total execution time: 0.0317
ERROR - 2023-06-28 10:11:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:11:23 --> Config Class Initialized
INFO - 2023-06-28 10:11:23 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:11:23 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:11:23 --> Utf8 Class Initialized
INFO - 2023-06-28 10:11:23 --> URI Class Initialized
INFO - 2023-06-28 10:11:23 --> Router Class Initialized
INFO - 2023-06-28 10:11:23 --> Output Class Initialized
INFO - 2023-06-28 10:11:23 --> Security Class Initialized
DEBUG - 2023-06-28 10:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:11:23 --> Input Class Initialized
INFO - 2023-06-28 10:11:23 --> Language Class Initialized
INFO - 2023-06-28 10:11:23 --> Loader Class Initialized
INFO - 2023-06-28 10:11:23 --> Helper loaded: url_helper
INFO - 2023-06-28 10:11:23 --> Helper loaded: file_helper
INFO - 2023-06-28 10:11:23 --> Helper loaded: html_helper
INFO - 2023-06-28 10:11:23 --> Helper loaded: text_helper
INFO - 2023-06-28 10:11:23 --> Helper loaded: form_helper
INFO - 2023-06-28 10:11:23 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:11:23 --> Helper loaded: security_helper
INFO - 2023-06-28 10:11:23 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:11:23 --> Database Driver Class Initialized
INFO - 2023-06-28 10:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:11:23 --> Parser Class Initialized
INFO - 2023-06-28 10:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:11:23 --> Pagination Class Initialized
INFO - 2023-06-28 10:11:23 --> Form Validation Class Initialized
INFO - 2023-06-28 10:11:23 --> Controller Class Initialized
INFO - 2023-06-28 10:11:23 --> Model Class Initialized
DEBUG - 2023-06-28 10:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:23 --> Model Class Initialized
INFO - 2023-06-28 10:11:23 --> Final output sent to browser
DEBUG - 2023-06-28 10:11:23 --> Total execution time: 0.0197
ERROR - 2023-06-28 10:11:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:11:24 --> Config Class Initialized
INFO - 2023-06-28 10:11:24 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:11:24 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:11:24 --> Utf8 Class Initialized
INFO - 2023-06-28 10:11:24 --> URI Class Initialized
DEBUG - 2023-06-28 10:11:24 --> No URI present. Default controller set.
INFO - 2023-06-28 10:11:24 --> Router Class Initialized
INFO - 2023-06-28 10:11:24 --> Output Class Initialized
INFO - 2023-06-28 10:11:24 --> Security Class Initialized
DEBUG - 2023-06-28 10:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:11:24 --> Input Class Initialized
INFO - 2023-06-28 10:11:24 --> Language Class Initialized
INFO - 2023-06-28 10:11:24 --> Loader Class Initialized
INFO - 2023-06-28 10:11:24 --> Helper loaded: url_helper
INFO - 2023-06-28 10:11:24 --> Helper loaded: file_helper
INFO - 2023-06-28 10:11:24 --> Helper loaded: html_helper
INFO - 2023-06-28 10:11:24 --> Helper loaded: text_helper
INFO - 2023-06-28 10:11:24 --> Helper loaded: form_helper
INFO - 2023-06-28 10:11:24 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:11:24 --> Helper loaded: security_helper
INFO - 2023-06-28 10:11:24 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:11:24 --> Database Driver Class Initialized
INFO - 2023-06-28 10:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:11:24 --> Parser Class Initialized
INFO - 2023-06-28 10:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:11:24 --> Pagination Class Initialized
INFO - 2023-06-28 10:11:24 --> Form Validation Class Initialized
INFO - 2023-06-28 10:11:24 --> Controller Class Initialized
INFO - 2023-06-28 10:11:24 --> Model Class Initialized
DEBUG - 2023-06-28 10:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:24 --> Model Class Initialized
DEBUG - 2023-06-28 10:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:24 --> Model Class Initialized
INFO - 2023-06-28 10:11:24 --> Model Class Initialized
INFO - 2023-06-28 10:11:24 --> Model Class Initialized
INFO - 2023-06-28 10:11:24 --> Model Class Initialized
DEBUG - 2023-06-28 10:11:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:24 --> Model Class Initialized
INFO - 2023-06-28 10:11:24 --> Model Class Initialized
INFO - 2023-06-28 10:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:11:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:11:25 --> Model Class Initialized
INFO - 2023-06-28 10:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:11:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:11:25 --> Final output sent to browser
DEBUG - 2023-06-28 10:11:25 --> Total execution time: 0.0859
ERROR - 2023-06-28 10:11:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:11:29 --> Config Class Initialized
INFO - 2023-06-28 10:11:29 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:11:29 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:11:29 --> Utf8 Class Initialized
INFO - 2023-06-28 10:11:29 --> URI Class Initialized
INFO - 2023-06-28 10:11:29 --> Router Class Initialized
INFO - 2023-06-28 10:11:29 --> Output Class Initialized
INFO - 2023-06-28 10:11:29 --> Security Class Initialized
DEBUG - 2023-06-28 10:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:11:29 --> Input Class Initialized
INFO - 2023-06-28 10:11:29 --> Language Class Initialized
INFO - 2023-06-28 10:11:29 --> Loader Class Initialized
INFO - 2023-06-28 10:11:29 --> Helper loaded: url_helper
INFO - 2023-06-28 10:11:29 --> Helper loaded: file_helper
INFO - 2023-06-28 10:11:29 --> Helper loaded: html_helper
INFO - 2023-06-28 10:11:29 --> Helper loaded: text_helper
INFO - 2023-06-28 10:11:29 --> Helper loaded: form_helper
INFO - 2023-06-28 10:11:29 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:11:29 --> Helper loaded: security_helper
INFO - 2023-06-28 10:11:29 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:11:29 --> Database Driver Class Initialized
INFO - 2023-06-28 10:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:11:29 --> Parser Class Initialized
INFO - 2023-06-28 10:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:11:29 --> Pagination Class Initialized
INFO - 2023-06-28 10:11:29 --> Form Validation Class Initialized
INFO - 2023-06-28 10:11:29 --> Controller Class Initialized
DEBUG - 2023-06-28 10:11:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:29 --> Model Class Initialized
DEBUG - 2023-06-28 10:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:29 --> Model Class Initialized
INFO - 2023-06-28 10:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-06-28 10:11:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:11:29 --> Model Class Initialized
INFO - 2023-06-28 10:11:29 --> Model Class Initialized
INFO - 2023-06-28 10:11:29 --> Model Class Initialized
INFO - 2023-06-28 10:11:29 --> Model Class Initialized
INFO - 2023-06-28 10:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:11:29 --> Final output sent to browser
DEBUG - 2023-06-28 10:11:29 --> Total execution time: 0.0920
ERROR - 2023-06-28 10:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:17:03 --> Config Class Initialized
INFO - 2023-06-28 10:17:03 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:17:03 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:17:03 --> Utf8 Class Initialized
INFO - 2023-06-28 10:17:03 --> URI Class Initialized
DEBUG - 2023-06-28 10:17:03 --> No URI present. Default controller set.
INFO - 2023-06-28 10:17:03 --> Router Class Initialized
INFO - 2023-06-28 10:17:03 --> Output Class Initialized
INFO - 2023-06-28 10:17:03 --> Security Class Initialized
DEBUG - 2023-06-28 10:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:17:03 --> Input Class Initialized
INFO - 2023-06-28 10:17:03 --> Language Class Initialized
INFO - 2023-06-28 10:17:03 --> Loader Class Initialized
INFO - 2023-06-28 10:17:03 --> Helper loaded: url_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: file_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: html_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: text_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: form_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: security_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:17:03 --> Database Driver Class Initialized
INFO - 2023-06-28 10:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:17:03 --> Parser Class Initialized
INFO - 2023-06-28 10:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:17:03 --> Pagination Class Initialized
INFO - 2023-06-28 10:17:03 --> Form Validation Class Initialized
INFO - 2023-06-28 10:17:03 --> Controller Class Initialized
INFO - 2023-06-28 10:17:03 --> Model Class Initialized
DEBUG - 2023-06-28 10:17:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 10:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:17:03 --> Config Class Initialized
INFO - 2023-06-28 10:17:03 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:17:03 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:17:03 --> Utf8 Class Initialized
INFO - 2023-06-28 10:17:03 --> URI Class Initialized
INFO - 2023-06-28 10:17:03 --> Router Class Initialized
INFO - 2023-06-28 10:17:03 --> Output Class Initialized
INFO - 2023-06-28 10:17:03 --> Security Class Initialized
DEBUG - 2023-06-28 10:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:17:03 --> Input Class Initialized
INFO - 2023-06-28 10:17:03 --> Language Class Initialized
INFO - 2023-06-28 10:17:03 --> Loader Class Initialized
INFO - 2023-06-28 10:17:03 --> Helper loaded: url_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: file_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: html_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: text_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: form_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: security_helper
INFO - 2023-06-28 10:17:03 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:17:03 --> Database Driver Class Initialized
INFO - 2023-06-28 10:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:17:03 --> Parser Class Initialized
INFO - 2023-06-28 10:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:17:03 --> Pagination Class Initialized
INFO - 2023-06-28 10:17:03 --> Form Validation Class Initialized
INFO - 2023-06-28 10:17:03 --> Controller Class Initialized
INFO - 2023-06-28 10:17:03 --> Model Class Initialized
DEBUG - 2023-06-28 10:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 10:17:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:17:03 --> Model Class Initialized
INFO - 2023-06-28 10:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:17:03 --> Final output sent to browser
DEBUG - 2023-06-28 10:17:03 --> Total execution time: 0.0328
ERROR - 2023-06-28 10:20:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:06 --> Config Class Initialized
INFO - 2023-06-28 10:20:06 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:06 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:06 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:06 --> URI Class Initialized
INFO - 2023-06-28 10:20:06 --> Router Class Initialized
INFO - 2023-06-28 10:20:06 --> Output Class Initialized
INFO - 2023-06-28 10:20:06 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:06 --> Input Class Initialized
INFO - 2023-06-28 10:20:06 --> Language Class Initialized
INFO - 2023-06-28 10:20:06 --> Loader Class Initialized
INFO - 2023-06-28 10:20:06 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:06 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:06 --> Parser Class Initialized
INFO - 2023-06-28 10:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:06 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:06 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:06 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:06 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:06 --> Email Class Initialized
INFO - 2023-06-28 10:20:06 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-06-28 10:20:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:06 --> Config Class Initialized
INFO - 2023-06-28 10:20:06 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:06 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:06 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:06 --> URI Class Initialized
INFO - 2023-06-28 10:20:06 --> Router Class Initialized
INFO - 2023-06-28 10:20:06 --> Output Class Initialized
INFO - 2023-06-28 10:20:06 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:06 --> Input Class Initialized
INFO - 2023-06-28 10:20:06 --> Language Class Initialized
INFO - 2023-06-28 10:20:06 --> Loader Class Initialized
INFO - 2023-06-28 10:20:06 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:06 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:06 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:06 --> Parser Class Initialized
INFO - 2023-06-28 10:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:06 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:06 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:06 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:06 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:06 --> Model Class Initialized
INFO - 2023-06-28 10:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-28 10:20:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:20:06 --> Model Class Initialized
INFO - 2023-06-28 10:20:06 --> Model Class Initialized
INFO - 2023-06-28 10:20:06 --> Model Class Initialized
INFO - 2023-06-28 10:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:20:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:20:06 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:06 --> Total execution time: 0.0730
ERROR - 2023-06-28 10:20:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:07 --> Config Class Initialized
INFO - 2023-06-28 10:20:07 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:07 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:07 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:07 --> URI Class Initialized
INFO - 2023-06-28 10:20:07 --> Router Class Initialized
INFO - 2023-06-28 10:20:07 --> Output Class Initialized
INFO - 2023-06-28 10:20:07 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:07 --> Input Class Initialized
INFO - 2023-06-28 10:20:07 --> Language Class Initialized
INFO - 2023-06-28 10:20:07 --> Loader Class Initialized
INFO - 2023-06-28 10:20:07 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:07 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:07 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:07 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:07 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:07 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:07 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:07 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:07 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:07 --> Parser Class Initialized
INFO - 2023-06-28 10:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:07 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:07 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:07 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:07 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:07 --> Model Class Initialized
INFO - 2023-06-28 10:20:07 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:07 --> Total execution time: 0.0211
ERROR - 2023-06-28 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:17 --> Config Class Initialized
INFO - 2023-06-28 10:20:17 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:17 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:17 --> URI Class Initialized
DEBUG - 2023-06-28 10:20:17 --> No URI present. Default controller set.
INFO - 2023-06-28 10:20:17 --> Router Class Initialized
INFO - 2023-06-28 10:20:17 --> Output Class Initialized
INFO - 2023-06-28 10:20:17 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:17 --> Input Class Initialized
INFO - 2023-06-28 10:20:17 --> Language Class Initialized
INFO - 2023-06-28 10:20:17 --> Loader Class Initialized
INFO - 2023-06-28 10:20:17 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:17 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:17 --> Parser Class Initialized
INFO - 2023-06-28 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:17 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:17 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:17 --> Controller Class Initialized
INFO - 2023-06-28 10:20:17 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 10:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:17 --> Config Class Initialized
INFO - 2023-06-28 10:20:17 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:17 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:17 --> URI Class Initialized
INFO - 2023-06-28 10:20:17 --> Router Class Initialized
INFO - 2023-06-28 10:20:17 --> Output Class Initialized
INFO - 2023-06-28 10:20:17 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:17 --> Input Class Initialized
INFO - 2023-06-28 10:20:17 --> Language Class Initialized
INFO - 2023-06-28 10:20:17 --> Loader Class Initialized
INFO - 2023-06-28 10:20:17 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:17 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:17 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:17 --> Parser Class Initialized
INFO - 2023-06-28 10:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:17 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:17 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:17 --> Controller Class Initialized
INFO - 2023-06-28 10:20:17 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 10:20:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:20:17 --> Model Class Initialized
INFO - 2023-06-28 10:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:20:17 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:17 --> Total execution time: 0.0268
ERROR - 2023-06-28 10:20:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:20 --> Config Class Initialized
INFO - 2023-06-28 10:20:20 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:20 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:20 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:20 --> URI Class Initialized
INFO - 2023-06-28 10:20:20 --> Router Class Initialized
INFO - 2023-06-28 10:20:20 --> Output Class Initialized
INFO - 2023-06-28 10:20:20 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:20 --> Input Class Initialized
INFO - 2023-06-28 10:20:20 --> Language Class Initialized
INFO - 2023-06-28 10:20:20 --> Loader Class Initialized
INFO - 2023-06-28 10:20:20 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:20 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:20 --> Parser Class Initialized
INFO - 2023-06-28 10:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:20 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:20 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:20 --> Controller Class Initialized
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
INFO - 2023-06-28 10:20:20 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:20 --> Total execution time: 0.0161
ERROR - 2023-06-28 10:20:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:20 --> Config Class Initialized
INFO - 2023-06-28 10:20:20 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:20 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:20 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:20 --> URI Class Initialized
DEBUG - 2023-06-28 10:20:20 --> No URI present. Default controller set.
INFO - 2023-06-28 10:20:20 --> Router Class Initialized
INFO - 2023-06-28 10:20:20 --> Output Class Initialized
INFO - 2023-06-28 10:20:20 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:20 --> Input Class Initialized
INFO - 2023-06-28 10:20:20 --> Language Class Initialized
INFO - 2023-06-28 10:20:20 --> Loader Class Initialized
INFO - 2023-06-28 10:20:20 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:20 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:20 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:20 --> Parser Class Initialized
INFO - 2023-06-28 10:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:20 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:20 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:20 --> Controller Class Initialized
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
INFO - 2023-06-28 10:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:20:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:20:20 --> Model Class Initialized
INFO - 2023-06-28 10:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:20:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:20:20 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:20 --> Total execution time: 0.1611
ERROR - 2023-06-28 10:20:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:21 --> Config Class Initialized
INFO - 2023-06-28 10:20:21 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:21 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:21 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:21 --> URI Class Initialized
INFO - 2023-06-28 10:20:21 --> Router Class Initialized
INFO - 2023-06-28 10:20:21 --> Output Class Initialized
INFO - 2023-06-28 10:20:21 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:21 --> Input Class Initialized
INFO - 2023-06-28 10:20:21 --> Language Class Initialized
INFO - 2023-06-28 10:20:21 --> Loader Class Initialized
INFO - 2023-06-28 10:20:21 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:21 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:21 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:21 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:21 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:21 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:21 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:21 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:21 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:21 --> Parser Class Initialized
INFO - 2023-06-28 10:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:21 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:21 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:21 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:21 --> Model Class Initialized
INFO - 2023-06-28 10:20:21 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:21 --> Total execution time: 0.0175
ERROR - 2023-06-28 10:20:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:26 --> Config Class Initialized
INFO - 2023-06-28 10:20:26 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:26 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:26 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:26 --> URI Class Initialized
INFO - 2023-06-28 10:20:26 --> Router Class Initialized
INFO - 2023-06-28 10:20:26 --> Output Class Initialized
INFO - 2023-06-28 10:20:26 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:26 --> Input Class Initialized
INFO - 2023-06-28 10:20:26 --> Language Class Initialized
INFO - 2023-06-28 10:20:26 --> Loader Class Initialized
INFO - 2023-06-28 10:20:26 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:26 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:26 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:26 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:26 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:26 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:26 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:26 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:26 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:26 --> Parser Class Initialized
INFO - 2023-06-28 10:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:26 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:26 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:26 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:26 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:26 --> Model Class Initialized
INFO - 2023-06-28 10:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-28 10:20:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:20:26 --> Model Class Initialized
INFO - 2023-06-28 10:20:26 --> Model Class Initialized
INFO - 2023-06-28 10:20:26 --> Model Class Initialized
INFO - 2023-06-28 10:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:20:26 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:26 --> Total execution time: 0.1300
ERROR - 2023-06-28 10:20:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:27 --> Config Class Initialized
INFO - 2023-06-28 10:20:27 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:27 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:27 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:27 --> URI Class Initialized
INFO - 2023-06-28 10:20:27 --> Router Class Initialized
INFO - 2023-06-28 10:20:27 --> Output Class Initialized
INFO - 2023-06-28 10:20:27 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:27 --> Input Class Initialized
INFO - 2023-06-28 10:20:27 --> Language Class Initialized
INFO - 2023-06-28 10:20:27 --> Loader Class Initialized
INFO - 2023-06-28 10:20:27 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:27 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:27 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:27 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:27 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:27 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:27 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:27 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:27 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:27 --> Parser Class Initialized
INFO - 2023-06-28 10:20:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:27 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:27 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:27 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:27 --> Model Class Initialized
INFO - 2023-06-28 10:20:27 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:27 --> Total execution time: 0.0317
ERROR - 2023-06-28 10:20:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:31 --> Config Class Initialized
INFO - 2023-06-28 10:20:31 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:31 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:31 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:31 --> URI Class Initialized
INFO - 2023-06-28 10:20:31 --> Router Class Initialized
INFO - 2023-06-28 10:20:31 --> Output Class Initialized
INFO - 2023-06-28 10:20:31 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:31 --> Input Class Initialized
INFO - 2023-06-28 10:20:31 --> Language Class Initialized
INFO - 2023-06-28 10:20:31 --> Loader Class Initialized
INFO - 2023-06-28 10:20:31 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:31 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:31 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:31 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:31 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:31 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:31 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:31 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:31 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:31 --> Parser Class Initialized
INFO - 2023-06-28 10:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:31 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:31 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:31 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:31 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:31 --> Model Class Initialized
INFO - 2023-06-28 10:20:31 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:31 --> Total execution time: 0.1077
ERROR - 2023-06-28 10:20:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:46 --> Config Class Initialized
INFO - 2023-06-28 10:20:46 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:46 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:46 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:46 --> URI Class Initialized
INFO - 2023-06-28 10:20:46 --> Router Class Initialized
INFO - 2023-06-28 10:20:46 --> Output Class Initialized
INFO - 2023-06-28 10:20:46 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:46 --> Input Class Initialized
INFO - 2023-06-28 10:20:46 --> Language Class Initialized
INFO - 2023-06-28 10:20:46 --> Loader Class Initialized
INFO - 2023-06-28 10:20:46 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:46 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:46 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:46 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:46 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:46 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:46 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:46 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:46 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:46 --> Parser Class Initialized
INFO - 2023-06-28 10:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:46 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:46 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:46 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:46 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:46 --> Model Class Initialized
INFO - 2023-06-28 10:20:46 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:46 --> Total execution time: 0.0187
ERROR - 2023-06-28 10:20:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:47 --> Config Class Initialized
INFO - 2023-06-28 10:20:47 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:47 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:47 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:47 --> URI Class Initialized
INFO - 2023-06-28 10:20:47 --> Router Class Initialized
INFO - 2023-06-28 10:20:47 --> Output Class Initialized
INFO - 2023-06-28 10:20:47 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:47 --> Input Class Initialized
INFO - 2023-06-28 10:20:47 --> Language Class Initialized
INFO - 2023-06-28 10:20:47 --> Loader Class Initialized
INFO - 2023-06-28 10:20:47 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:47 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:47 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:47 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:47 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:47 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:47 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:47 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:47 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:47 --> Parser Class Initialized
INFO - 2023-06-28 10:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:47 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:47 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:47 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:47 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:47 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:47 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:47 --> Model Class Initialized
INFO - 2023-06-28 10:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-28 10:20:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:20:47 --> Model Class Initialized
INFO - 2023-06-28 10:20:47 --> Model Class Initialized
INFO - 2023-06-28 10:20:47 --> Model Class Initialized
INFO - 2023-06-28 10:20:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:20:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:20:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:20:48 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:48 --> Total execution time: 0.1264
ERROR - 2023-06-28 10:20:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:48 --> Config Class Initialized
INFO - 2023-06-28 10:20:48 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:48 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:48 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:48 --> URI Class Initialized
INFO - 2023-06-28 10:20:48 --> Router Class Initialized
INFO - 2023-06-28 10:20:48 --> Output Class Initialized
INFO - 2023-06-28 10:20:48 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:48 --> Input Class Initialized
INFO - 2023-06-28 10:20:48 --> Language Class Initialized
INFO - 2023-06-28 10:20:48 --> Loader Class Initialized
INFO - 2023-06-28 10:20:48 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:48 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:48 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:48 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:48 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:48 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:48 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:48 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:48 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:48 --> Parser Class Initialized
INFO - 2023-06-28 10:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:48 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:48 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:48 --> Controller Class Initialized
DEBUG - 2023-06-28 10:20:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:48 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:48 --> Model Class Initialized
INFO - 2023-06-28 10:20:48 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:48 --> Total execution time: 0.0298
ERROR - 2023-06-28 10:20:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:20:56 --> Config Class Initialized
INFO - 2023-06-28 10:20:56 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:20:56 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:20:56 --> Utf8 Class Initialized
INFO - 2023-06-28 10:20:56 --> URI Class Initialized
INFO - 2023-06-28 10:20:56 --> Router Class Initialized
INFO - 2023-06-28 10:20:56 --> Output Class Initialized
INFO - 2023-06-28 10:20:56 --> Security Class Initialized
DEBUG - 2023-06-28 10:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:20:56 --> Input Class Initialized
INFO - 2023-06-28 10:20:56 --> Language Class Initialized
INFO - 2023-06-28 10:20:56 --> Loader Class Initialized
INFO - 2023-06-28 10:20:56 --> Helper loaded: url_helper
INFO - 2023-06-28 10:20:56 --> Helper loaded: file_helper
INFO - 2023-06-28 10:20:56 --> Helper loaded: html_helper
INFO - 2023-06-28 10:20:56 --> Helper loaded: text_helper
INFO - 2023-06-28 10:20:56 --> Helper loaded: form_helper
INFO - 2023-06-28 10:20:56 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:20:56 --> Helper loaded: security_helper
INFO - 2023-06-28 10:20:56 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:20:56 --> Database Driver Class Initialized
INFO - 2023-06-28 10:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:20:56 --> Parser Class Initialized
INFO - 2023-06-28 10:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:20:56 --> Pagination Class Initialized
INFO - 2023-06-28 10:20:56 --> Form Validation Class Initialized
INFO - 2023-06-28 10:20:56 --> Controller Class Initialized
INFO - 2023-06-28 10:20:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:56 --> Model Class Initialized
INFO - 2023-06-28 10:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-28 10:20:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:20:56 --> Model Class Initialized
INFO - 2023-06-28 10:20:56 --> Model Class Initialized
INFO - 2023-06-28 10:20:56 --> Model Class Initialized
INFO - 2023-06-28 10:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:20:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:20:56 --> Final output sent to browser
DEBUG - 2023-06-28 10:20:56 --> Total execution time: 0.0915
ERROR - 2023-06-28 10:21:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:21:00 --> Config Class Initialized
INFO - 2023-06-28 10:21:00 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:21:00 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:21:00 --> Utf8 Class Initialized
INFO - 2023-06-28 10:21:00 --> URI Class Initialized
INFO - 2023-06-28 10:21:00 --> Router Class Initialized
INFO - 2023-06-28 10:21:00 --> Output Class Initialized
INFO - 2023-06-28 10:21:00 --> Security Class Initialized
DEBUG - 2023-06-28 10:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:21:00 --> Input Class Initialized
INFO - 2023-06-28 10:21:00 --> Language Class Initialized
INFO - 2023-06-28 10:21:00 --> Loader Class Initialized
INFO - 2023-06-28 10:21:00 --> Helper loaded: url_helper
INFO - 2023-06-28 10:21:00 --> Helper loaded: file_helper
INFO - 2023-06-28 10:21:00 --> Helper loaded: html_helper
INFO - 2023-06-28 10:21:00 --> Helper loaded: text_helper
INFO - 2023-06-28 10:21:00 --> Helper loaded: form_helper
INFO - 2023-06-28 10:21:00 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:21:00 --> Helper loaded: security_helper
INFO - 2023-06-28 10:21:00 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:21:00 --> Database Driver Class Initialized
INFO - 2023-06-28 10:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:21:00 --> Parser Class Initialized
INFO - 2023-06-28 10:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:21:00 --> Pagination Class Initialized
INFO - 2023-06-28 10:21:00 --> Form Validation Class Initialized
INFO - 2023-06-28 10:21:00 --> Controller Class Initialized
INFO - 2023-06-28 10:21:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:00 --> Final output sent to browser
DEBUG - 2023-06-28 10:21:00 --> Total execution time: 0.0193
ERROR - 2023-06-28 10:21:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:21:02 --> Config Class Initialized
INFO - 2023-06-28 10:21:02 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:21:02 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:21:02 --> Utf8 Class Initialized
INFO - 2023-06-28 10:21:02 --> URI Class Initialized
INFO - 2023-06-28 10:21:02 --> Router Class Initialized
INFO - 2023-06-28 10:21:02 --> Output Class Initialized
INFO - 2023-06-28 10:21:02 --> Security Class Initialized
DEBUG - 2023-06-28 10:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:21:02 --> Input Class Initialized
INFO - 2023-06-28 10:21:02 --> Language Class Initialized
INFO - 2023-06-28 10:21:02 --> Loader Class Initialized
INFO - 2023-06-28 10:21:02 --> Helper loaded: url_helper
INFO - 2023-06-28 10:21:02 --> Helper loaded: file_helper
INFO - 2023-06-28 10:21:02 --> Helper loaded: html_helper
INFO - 2023-06-28 10:21:02 --> Helper loaded: text_helper
INFO - 2023-06-28 10:21:02 --> Helper loaded: form_helper
INFO - 2023-06-28 10:21:02 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:21:02 --> Helper loaded: security_helper
INFO - 2023-06-28 10:21:02 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:21:02 --> Database Driver Class Initialized
INFO - 2023-06-28 10:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:21:02 --> Parser Class Initialized
INFO - 2023-06-28 10:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:21:02 --> Pagination Class Initialized
INFO - 2023-06-28 10:21:02 --> Form Validation Class Initialized
INFO - 2023-06-28 10:21:02 --> Controller Class Initialized
INFO - 2023-06-28 10:21:02 --> Final output sent to browser
DEBUG - 2023-06-28 10:21:02 --> Total execution time: 0.0142
ERROR - 2023-06-28 10:21:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:21:06 --> Config Class Initialized
INFO - 2023-06-28 10:21:06 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:21:06 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:21:06 --> Utf8 Class Initialized
INFO - 2023-06-28 10:21:06 --> URI Class Initialized
INFO - 2023-06-28 10:21:06 --> Router Class Initialized
INFO - 2023-06-28 10:21:06 --> Output Class Initialized
INFO - 2023-06-28 10:21:06 --> Security Class Initialized
DEBUG - 2023-06-28 10:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:21:06 --> Input Class Initialized
INFO - 2023-06-28 10:21:06 --> Language Class Initialized
INFO - 2023-06-28 10:21:06 --> Loader Class Initialized
INFO - 2023-06-28 10:21:06 --> Helper loaded: url_helper
INFO - 2023-06-28 10:21:06 --> Helper loaded: file_helper
INFO - 2023-06-28 10:21:06 --> Helper loaded: html_helper
INFO - 2023-06-28 10:21:06 --> Helper loaded: text_helper
INFO - 2023-06-28 10:21:06 --> Helper loaded: form_helper
INFO - 2023-06-28 10:21:06 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:21:06 --> Helper loaded: security_helper
INFO - 2023-06-28 10:21:06 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:21:06 --> Database Driver Class Initialized
INFO - 2023-06-28 10:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:21:06 --> Parser Class Initialized
INFO - 2023-06-28 10:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:21:06 --> Pagination Class Initialized
INFO - 2023-06-28 10:21:06 --> Form Validation Class Initialized
INFO - 2023-06-28 10:21:06 --> Controller Class Initialized
INFO - 2023-06-28 10:21:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:06 --> Model Class Initialized
INFO - 2023-06-28 10:21:06 --> Final output sent to browser
DEBUG - 2023-06-28 10:21:06 --> Total execution time: 0.0346
ERROR - 2023-06-28 10:21:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:21:07 --> Config Class Initialized
INFO - 2023-06-28 10:21:07 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:21:07 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:21:07 --> Utf8 Class Initialized
INFO - 2023-06-28 10:21:07 --> URI Class Initialized
INFO - 2023-06-28 10:21:07 --> Router Class Initialized
INFO - 2023-06-28 10:21:07 --> Output Class Initialized
INFO - 2023-06-28 10:21:07 --> Security Class Initialized
DEBUG - 2023-06-28 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:21:07 --> Input Class Initialized
INFO - 2023-06-28 10:21:07 --> Language Class Initialized
INFO - 2023-06-28 10:21:07 --> Loader Class Initialized
INFO - 2023-06-28 10:21:07 --> Helper loaded: url_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: file_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: html_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: text_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: form_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: security_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:21:07 --> Database Driver Class Initialized
INFO - 2023-06-28 10:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:21:07 --> Parser Class Initialized
INFO - 2023-06-28 10:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:21:07 --> Pagination Class Initialized
INFO - 2023-06-28 10:21:07 --> Form Validation Class Initialized
INFO - 2023-06-28 10:21:07 --> Controller Class Initialized
INFO - 2023-06-28 10:21:07 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:07 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:07 --> Model Class Initialized
INFO - 2023-06-28 10:21:07 --> Final output sent to browser
DEBUG - 2023-06-28 10:21:07 --> Total execution time: 0.0186
ERROR - 2023-06-28 10:21:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:21:07 --> Config Class Initialized
INFO - 2023-06-28 10:21:07 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:21:07 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:21:07 --> Utf8 Class Initialized
INFO - 2023-06-28 10:21:07 --> URI Class Initialized
INFO - 2023-06-28 10:21:07 --> Router Class Initialized
INFO - 2023-06-28 10:21:07 --> Output Class Initialized
INFO - 2023-06-28 10:21:07 --> Security Class Initialized
DEBUG - 2023-06-28 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:21:07 --> Input Class Initialized
INFO - 2023-06-28 10:21:07 --> Language Class Initialized
INFO - 2023-06-28 10:21:07 --> Loader Class Initialized
INFO - 2023-06-28 10:21:07 --> Helper loaded: url_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: file_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: html_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: text_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: form_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: security_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:21:07 --> Database Driver Class Initialized
INFO - 2023-06-28 10:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:21:07 --> Parser Class Initialized
INFO - 2023-06-28 10:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:21:07 --> Pagination Class Initialized
INFO - 2023-06-28 10:21:07 --> Form Validation Class Initialized
INFO - 2023-06-28 10:21:07 --> Controller Class Initialized
INFO - 2023-06-28 10:21:07 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:07 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:07 --> Model Class Initialized
INFO - 2023-06-28 10:21:07 --> Final output sent to browser
DEBUG - 2023-06-28 10:21:07 --> Total execution time: 0.0188
ERROR - 2023-06-28 10:21:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:21:07 --> Config Class Initialized
INFO - 2023-06-28 10:21:07 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:21:07 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:21:07 --> Utf8 Class Initialized
INFO - 2023-06-28 10:21:07 --> URI Class Initialized
INFO - 2023-06-28 10:21:07 --> Router Class Initialized
INFO - 2023-06-28 10:21:07 --> Output Class Initialized
INFO - 2023-06-28 10:21:07 --> Security Class Initialized
DEBUG - 2023-06-28 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:21:07 --> Input Class Initialized
INFO - 2023-06-28 10:21:07 --> Language Class Initialized
INFO - 2023-06-28 10:21:07 --> Loader Class Initialized
INFO - 2023-06-28 10:21:07 --> Helper loaded: url_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: file_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: html_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: text_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: form_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: security_helper
INFO - 2023-06-28 10:21:07 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:21:07 --> Database Driver Class Initialized
INFO - 2023-06-28 10:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:21:07 --> Parser Class Initialized
INFO - 2023-06-28 10:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:21:07 --> Pagination Class Initialized
INFO - 2023-06-28 10:21:07 --> Form Validation Class Initialized
INFO - 2023-06-28 10:21:07 --> Controller Class Initialized
INFO - 2023-06-28 10:21:07 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:07 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:07 --> Model Class Initialized
INFO - 2023-06-28 10:21:07 --> Final output sent to browser
DEBUG - 2023-06-28 10:21:07 --> Total execution time: 0.0192
ERROR - 2023-06-28 10:21:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:21:28 --> Config Class Initialized
INFO - 2023-06-28 10:21:28 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:21:28 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:21:28 --> Utf8 Class Initialized
INFO - 2023-06-28 10:21:28 --> URI Class Initialized
INFO - 2023-06-28 10:21:28 --> Router Class Initialized
INFO - 2023-06-28 10:21:28 --> Output Class Initialized
INFO - 2023-06-28 10:21:28 --> Security Class Initialized
DEBUG - 2023-06-28 10:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:21:28 --> Input Class Initialized
INFO - 2023-06-28 10:21:28 --> Language Class Initialized
INFO - 2023-06-28 10:21:28 --> Loader Class Initialized
INFO - 2023-06-28 10:21:28 --> Helper loaded: url_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: file_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: html_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: text_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: form_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: security_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:21:28 --> Database Driver Class Initialized
INFO - 2023-06-28 10:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:21:28 --> Parser Class Initialized
INFO - 2023-06-28 10:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:21:28 --> Pagination Class Initialized
INFO - 2023-06-28 10:21:28 --> Form Validation Class Initialized
INFO - 2023-06-28 10:21:28 --> Controller Class Initialized
INFO - 2023-06-28 10:21:28 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:21:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:28 --> Model Class Initialized
INFO - 2023-06-28 10:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-28 10:21:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:21:28 --> Model Class Initialized
INFO - 2023-06-28 10:21:28 --> Model Class Initialized
INFO - 2023-06-28 10:21:28 --> Model Class Initialized
INFO - 2023-06-28 10:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:21:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:21:28 --> Final output sent to browser
DEBUG - 2023-06-28 10:21:28 --> Total execution time: 0.0637
ERROR - 2023-06-28 10:21:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:21:28 --> Config Class Initialized
INFO - 2023-06-28 10:21:28 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:21:28 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:21:28 --> Utf8 Class Initialized
INFO - 2023-06-28 10:21:28 --> URI Class Initialized
INFO - 2023-06-28 10:21:28 --> Router Class Initialized
INFO - 2023-06-28 10:21:28 --> Output Class Initialized
INFO - 2023-06-28 10:21:28 --> Security Class Initialized
DEBUG - 2023-06-28 10:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:21:28 --> Input Class Initialized
INFO - 2023-06-28 10:21:28 --> Language Class Initialized
INFO - 2023-06-28 10:21:28 --> Loader Class Initialized
INFO - 2023-06-28 10:21:28 --> Helper loaded: url_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: file_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: html_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: text_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: form_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: security_helper
INFO - 2023-06-28 10:21:28 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:21:28 --> Database Driver Class Initialized
INFO - 2023-06-28 10:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:21:28 --> Parser Class Initialized
INFO - 2023-06-28 10:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:21:28 --> Pagination Class Initialized
INFO - 2023-06-28 10:21:28 --> Form Validation Class Initialized
INFO - 2023-06-28 10:21:28 --> Controller Class Initialized
INFO - 2023-06-28 10:21:28 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:21:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:28 --> Model Class Initialized
INFO - 2023-06-28 10:21:28 --> Final output sent to browser
DEBUG - 2023-06-28 10:21:28 --> Total execution time: 0.0247
ERROR - 2023-06-28 10:21:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:21:56 --> Config Class Initialized
INFO - 2023-06-28 10:21:56 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:21:56 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:21:56 --> Utf8 Class Initialized
INFO - 2023-06-28 10:21:56 --> URI Class Initialized
INFO - 2023-06-28 10:21:56 --> Router Class Initialized
INFO - 2023-06-28 10:21:56 --> Output Class Initialized
INFO - 2023-06-28 10:21:56 --> Security Class Initialized
DEBUG - 2023-06-28 10:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:21:56 --> Input Class Initialized
INFO - 2023-06-28 10:21:56 --> Language Class Initialized
INFO - 2023-06-28 10:21:56 --> Loader Class Initialized
INFO - 2023-06-28 10:21:56 --> Helper loaded: url_helper
INFO - 2023-06-28 10:21:56 --> Helper loaded: file_helper
INFO - 2023-06-28 10:21:56 --> Helper loaded: html_helper
INFO - 2023-06-28 10:21:56 --> Helper loaded: text_helper
INFO - 2023-06-28 10:21:56 --> Helper loaded: form_helper
INFO - 2023-06-28 10:21:56 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:21:56 --> Helper loaded: security_helper
INFO - 2023-06-28 10:21:56 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:21:56 --> Database Driver Class Initialized
INFO - 2023-06-28 10:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:21:56 --> Parser Class Initialized
INFO - 2023-06-28 10:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:21:56 --> Pagination Class Initialized
INFO - 2023-06-28 10:21:56 --> Form Validation Class Initialized
INFO - 2023-06-28 10:21:56 --> Controller Class Initialized
INFO - 2023-06-28 10:21:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:21:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:21:56 --> Model Class Initialized
INFO - 2023-06-28 10:21:56 --> Final output sent to browser
DEBUG - 2023-06-28 10:21:56 --> Total execution time: 0.0269
ERROR - 2023-06-28 10:22:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:15 --> Config Class Initialized
INFO - 2023-06-28 10:22:15 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:15 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:15 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:15 --> URI Class Initialized
INFO - 2023-06-28 10:22:15 --> Router Class Initialized
INFO - 2023-06-28 10:22:15 --> Output Class Initialized
INFO - 2023-06-28 10:22:15 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:15 --> Input Class Initialized
INFO - 2023-06-28 10:22:15 --> Language Class Initialized
INFO - 2023-06-28 10:22:15 --> Loader Class Initialized
INFO - 2023-06-28 10:22:15 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:15 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:15 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:15 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:15 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:15 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:15 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:15 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:15 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:15 --> Parser Class Initialized
INFO - 2023-06-28 10:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:15 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:15 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:15 --> Controller Class Initialized
INFO - 2023-06-28 10:22:15 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:15 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:15 --> Model Class Initialized
INFO - 2023-06-28 10:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-28 10:22:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:22:15 --> Model Class Initialized
INFO - 2023-06-28 10:22:15 --> Model Class Initialized
INFO - 2023-06-28 10:22:15 --> Model Class Initialized
INFO - 2023-06-28 10:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:22:15 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:15 --> Total execution time: 0.0957
ERROR - 2023-06-28 10:22:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:21 --> Config Class Initialized
INFO - 2023-06-28 10:22:21 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:21 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:21 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:21 --> URI Class Initialized
INFO - 2023-06-28 10:22:21 --> Router Class Initialized
INFO - 2023-06-28 10:22:21 --> Output Class Initialized
INFO - 2023-06-28 10:22:21 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:21 --> Input Class Initialized
INFO - 2023-06-28 10:22:21 --> Language Class Initialized
INFO - 2023-06-28 10:22:21 --> Loader Class Initialized
INFO - 2023-06-28 10:22:21 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:21 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:21 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:21 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:21 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:21 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:21 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:21 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:21 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:21 --> Parser Class Initialized
INFO - 2023-06-28 10:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:21 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:21 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:21 --> Controller Class Initialized
INFO - 2023-06-28 10:22:21 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:21 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:21 --> Total execution time: 0.0181
ERROR - 2023-06-28 10:22:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:22 --> Config Class Initialized
INFO - 2023-06-28 10:22:22 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:22 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:22 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:22 --> URI Class Initialized
INFO - 2023-06-28 10:22:22 --> Router Class Initialized
INFO - 2023-06-28 10:22:22 --> Output Class Initialized
INFO - 2023-06-28 10:22:22 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:22 --> Input Class Initialized
INFO - 2023-06-28 10:22:22 --> Language Class Initialized
INFO - 2023-06-28 10:22:22 --> Loader Class Initialized
INFO - 2023-06-28 10:22:22 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:22 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:22 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:22 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:22 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:22 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:22 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:22 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:22 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:22 --> Parser Class Initialized
INFO - 2023-06-28 10:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:22 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:22 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:22 --> Controller Class Initialized
INFO - 2023-06-28 10:22:22 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:22 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:22 --> Total execution time: 0.0157
ERROR - 2023-06-28 10:22:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:23 --> Config Class Initialized
INFO - 2023-06-28 10:22:23 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:23 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:23 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:23 --> URI Class Initialized
INFO - 2023-06-28 10:22:23 --> Router Class Initialized
INFO - 2023-06-28 10:22:23 --> Output Class Initialized
INFO - 2023-06-28 10:22:23 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:23 --> Input Class Initialized
INFO - 2023-06-28 10:22:23 --> Language Class Initialized
INFO - 2023-06-28 10:22:23 --> Loader Class Initialized
INFO - 2023-06-28 10:22:23 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:23 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:23 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:23 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:23 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:23 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:23 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:23 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:23 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:23 --> Parser Class Initialized
INFO - 2023-06-28 10:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:23 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:23 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:23 --> Controller Class Initialized
INFO - 2023-06-28 10:22:23 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:23 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:23 --> Total execution time: 0.0159
ERROR - 2023-06-28 10:22:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:24 --> Config Class Initialized
INFO - 2023-06-28 10:22:24 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:24 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:24 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:24 --> URI Class Initialized
INFO - 2023-06-28 10:22:24 --> Router Class Initialized
INFO - 2023-06-28 10:22:24 --> Output Class Initialized
INFO - 2023-06-28 10:22:24 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:24 --> Input Class Initialized
INFO - 2023-06-28 10:22:24 --> Language Class Initialized
INFO - 2023-06-28 10:22:24 --> Loader Class Initialized
INFO - 2023-06-28 10:22:24 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:24 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:24 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:24 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:24 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:24 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:24 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:24 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:24 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:24 --> Parser Class Initialized
INFO - 2023-06-28 10:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:24 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:24 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:24 --> Controller Class Initialized
INFO - 2023-06-28 10:22:24 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:24 --> Total execution time: 0.0153
ERROR - 2023-06-28 10:22:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:28 --> Config Class Initialized
INFO - 2023-06-28 10:22:28 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:28 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:28 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:28 --> URI Class Initialized
INFO - 2023-06-28 10:22:28 --> Router Class Initialized
INFO - 2023-06-28 10:22:28 --> Output Class Initialized
INFO - 2023-06-28 10:22:28 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:28 --> Input Class Initialized
INFO - 2023-06-28 10:22:28 --> Language Class Initialized
INFO - 2023-06-28 10:22:28 --> Loader Class Initialized
INFO - 2023-06-28 10:22:28 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:28 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:28 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:28 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:28 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:28 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:28 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:28 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:28 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:28 --> Parser Class Initialized
INFO - 2023-06-28 10:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:28 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:28 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:28 --> Controller Class Initialized
INFO - 2023-06-28 10:22:28 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:28 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:28 --> Model Class Initialized
INFO - 2023-06-28 10:22:28 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:28 --> Total execution time: 0.0380
ERROR - 2023-06-28 10:22:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:30 --> Config Class Initialized
INFO - 2023-06-28 10:22:30 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:30 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:30 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:30 --> URI Class Initialized
INFO - 2023-06-28 10:22:30 --> Router Class Initialized
INFO - 2023-06-28 10:22:30 --> Output Class Initialized
INFO - 2023-06-28 10:22:30 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:30 --> Input Class Initialized
INFO - 2023-06-28 10:22:30 --> Language Class Initialized
INFO - 2023-06-28 10:22:30 --> Loader Class Initialized
INFO - 2023-06-28 10:22:30 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:30 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:30 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:30 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:30 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:30 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:30 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:30 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:30 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:30 --> Parser Class Initialized
INFO - 2023-06-28 10:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:30 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:30 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:30 --> Controller Class Initialized
INFO - 2023-06-28 10:22:30 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:30 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:30 --> Model Class Initialized
INFO - 2023-06-28 10:22:30 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:30 --> Total execution time: 0.0344
ERROR - 2023-06-28 10:22:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:31 --> Config Class Initialized
INFO - 2023-06-28 10:22:31 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:31 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:31 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:31 --> URI Class Initialized
INFO - 2023-06-28 10:22:31 --> Router Class Initialized
INFO - 2023-06-28 10:22:31 --> Output Class Initialized
INFO - 2023-06-28 10:22:31 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:31 --> Input Class Initialized
INFO - 2023-06-28 10:22:31 --> Language Class Initialized
INFO - 2023-06-28 10:22:31 --> Loader Class Initialized
INFO - 2023-06-28 10:22:31 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:31 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:31 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:31 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:31 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:31 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:31 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:31 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:31 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:31 --> Parser Class Initialized
INFO - 2023-06-28 10:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:31 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:31 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:31 --> Controller Class Initialized
INFO - 2023-06-28 10:22:31 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:31 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:31 --> Model Class Initialized
INFO - 2023-06-28 10:22:31 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:31 --> Total execution time: 0.0337
ERROR - 2023-06-28 10:22:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:35 --> Config Class Initialized
INFO - 2023-06-28 10:22:35 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:35 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:35 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:35 --> URI Class Initialized
INFO - 2023-06-28 10:22:35 --> Router Class Initialized
INFO - 2023-06-28 10:22:35 --> Output Class Initialized
INFO - 2023-06-28 10:22:35 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:35 --> Input Class Initialized
INFO - 2023-06-28 10:22:35 --> Language Class Initialized
INFO - 2023-06-28 10:22:35 --> Loader Class Initialized
INFO - 2023-06-28 10:22:35 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:35 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:35 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:35 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:35 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:35 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:35 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:35 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:35 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:35 --> Parser Class Initialized
INFO - 2023-06-28 10:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:35 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:35 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:35 --> Controller Class Initialized
INFO - 2023-06-28 10:22:35 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:35 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:35 --> Model Class Initialized
INFO - 2023-06-28 10:22:35 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:35 --> Total execution time: 0.0206
ERROR - 2023-06-28 10:22:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:37 --> Config Class Initialized
INFO - 2023-06-28 10:22:37 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:37 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:37 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:37 --> URI Class Initialized
INFO - 2023-06-28 10:22:37 --> Router Class Initialized
INFO - 2023-06-28 10:22:37 --> Output Class Initialized
INFO - 2023-06-28 10:22:37 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:37 --> Input Class Initialized
INFO - 2023-06-28 10:22:37 --> Language Class Initialized
INFO - 2023-06-28 10:22:37 --> Loader Class Initialized
INFO - 2023-06-28 10:22:37 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:37 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:37 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:37 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:37 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:37 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:37 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:37 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:37 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:37 --> Parser Class Initialized
INFO - 2023-06-28 10:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:37 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:37 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:37 --> Controller Class Initialized
INFO - 2023-06-28 10:22:37 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:37 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:37 --> Model Class Initialized
INFO - 2023-06-28 10:22:37 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:37 --> Total execution time: 0.0199
ERROR - 2023-06-28 10:22:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:38 --> Config Class Initialized
INFO - 2023-06-28 10:22:38 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:38 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:38 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:38 --> URI Class Initialized
INFO - 2023-06-28 10:22:38 --> Router Class Initialized
INFO - 2023-06-28 10:22:38 --> Output Class Initialized
INFO - 2023-06-28 10:22:38 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:38 --> Input Class Initialized
INFO - 2023-06-28 10:22:38 --> Language Class Initialized
INFO - 2023-06-28 10:22:38 --> Loader Class Initialized
INFO - 2023-06-28 10:22:38 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:38 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:38 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:38 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:38 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:38 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:38 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:38 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:38 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:38 --> Parser Class Initialized
INFO - 2023-06-28 10:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:38 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:38 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:38 --> Controller Class Initialized
INFO - 2023-06-28 10:22:38 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:38 --> Model Class Initialized
INFO - 2023-06-28 10:22:38 --> Model Class Initialized
INFO - 2023-06-28 10:22:38 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:38 --> Total execution time: 0.0207
ERROR - 2023-06-28 10:22:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:41 --> Config Class Initialized
INFO - 2023-06-28 10:22:41 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:41 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:41 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:41 --> URI Class Initialized
INFO - 2023-06-28 10:22:41 --> Router Class Initialized
INFO - 2023-06-28 10:22:41 --> Output Class Initialized
INFO - 2023-06-28 10:22:41 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:41 --> Input Class Initialized
INFO - 2023-06-28 10:22:41 --> Language Class Initialized
INFO - 2023-06-28 10:22:41 --> Loader Class Initialized
INFO - 2023-06-28 10:22:41 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:41 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:41 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:41 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:41 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:41 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:41 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:41 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:41 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:41 --> Parser Class Initialized
INFO - 2023-06-28 10:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:41 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:41 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:41 --> Controller Class Initialized
INFO - 2023-06-28 10:22:41 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:41 --> Model Class Initialized
INFO - 2023-06-28 10:22:41 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:41 --> Total execution time: 0.0201
ERROR - 2023-06-28 10:22:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:54 --> Config Class Initialized
INFO - 2023-06-28 10:22:54 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:54 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:54 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:54 --> URI Class Initialized
INFO - 2023-06-28 10:22:54 --> Router Class Initialized
INFO - 2023-06-28 10:22:54 --> Output Class Initialized
INFO - 2023-06-28 10:22:54 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:54 --> Input Class Initialized
INFO - 2023-06-28 10:22:54 --> Language Class Initialized
INFO - 2023-06-28 10:22:54 --> Loader Class Initialized
INFO - 2023-06-28 10:22:54 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:54 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:54 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:54 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:54 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:54 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:54 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:54 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:54 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:54 --> Parser Class Initialized
INFO - 2023-06-28 10:22:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:54 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:54 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:54 --> Controller Class Initialized
INFO - 2023-06-28 10:22:54 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:54 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:54 --> Model Class Initialized
INFO - 2023-06-28 10:22:55 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:55 --> Total execution time: 0.0360
ERROR - 2023-06-28 10:22:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:55 --> Config Class Initialized
INFO - 2023-06-28 10:22:55 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:55 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:55 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:55 --> URI Class Initialized
INFO - 2023-06-28 10:22:55 --> Router Class Initialized
INFO - 2023-06-28 10:22:55 --> Output Class Initialized
INFO - 2023-06-28 10:22:55 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:55 --> Input Class Initialized
INFO - 2023-06-28 10:22:55 --> Language Class Initialized
INFO - 2023-06-28 10:22:55 --> Loader Class Initialized
INFO - 2023-06-28 10:22:55 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:55 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:55 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:55 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:55 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:55 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:55 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:55 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:55 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:55 --> Parser Class Initialized
INFO - 2023-06-28 10:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:55 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:55 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:55 --> Controller Class Initialized
INFO - 2023-06-28 10:22:55 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:55 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:55 --> Model Class Initialized
INFO - 2023-06-28 10:22:55 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:55 --> Total execution time: 0.0323
ERROR - 2023-06-28 10:22:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:56 --> Config Class Initialized
INFO - 2023-06-28 10:22:56 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:56 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:56 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:56 --> URI Class Initialized
INFO - 2023-06-28 10:22:56 --> Router Class Initialized
INFO - 2023-06-28 10:22:56 --> Output Class Initialized
INFO - 2023-06-28 10:22:56 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:56 --> Input Class Initialized
INFO - 2023-06-28 10:22:56 --> Language Class Initialized
INFO - 2023-06-28 10:22:56 --> Loader Class Initialized
INFO - 2023-06-28 10:22:56 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:56 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:56 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:56 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:56 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:56 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:56 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:56 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:56 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:56 --> Parser Class Initialized
INFO - 2023-06-28 10:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:56 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:56 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:56 --> Controller Class Initialized
INFO - 2023-06-28 10:22:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:56 --> Model Class Initialized
INFO - 2023-06-28 10:22:56 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:56 --> Total execution time: 0.0183
ERROR - 2023-06-28 10:22:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:57 --> Config Class Initialized
INFO - 2023-06-28 10:22:57 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:57 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:57 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:57 --> URI Class Initialized
INFO - 2023-06-28 10:22:57 --> Router Class Initialized
INFO - 2023-06-28 10:22:57 --> Output Class Initialized
INFO - 2023-06-28 10:22:57 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:57 --> Input Class Initialized
INFO - 2023-06-28 10:22:57 --> Language Class Initialized
INFO - 2023-06-28 10:22:57 --> Loader Class Initialized
INFO - 2023-06-28 10:22:57 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:57 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:57 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:57 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:57 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:57 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:57 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:57 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:57 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:57 --> Parser Class Initialized
INFO - 2023-06-28 10:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:57 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:57 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:57 --> Controller Class Initialized
INFO - 2023-06-28 10:22:57 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:57 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:57 --> Model Class Initialized
INFO - 2023-06-28 10:22:57 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:57 --> Total execution time: 0.0218
ERROR - 2023-06-28 10:22:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:22:59 --> Config Class Initialized
INFO - 2023-06-28 10:22:59 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:22:59 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:22:59 --> Utf8 Class Initialized
INFO - 2023-06-28 10:22:59 --> URI Class Initialized
INFO - 2023-06-28 10:22:59 --> Router Class Initialized
INFO - 2023-06-28 10:22:59 --> Output Class Initialized
INFO - 2023-06-28 10:22:59 --> Security Class Initialized
DEBUG - 2023-06-28 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:22:59 --> Input Class Initialized
INFO - 2023-06-28 10:22:59 --> Language Class Initialized
INFO - 2023-06-28 10:22:59 --> Loader Class Initialized
INFO - 2023-06-28 10:22:59 --> Helper loaded: url_helper
INFO - 2023-06-28 10:22:59 --> Helper loaded: file_helper
INFO - 2023-06-28 10:22:59 --> Helper loaded: html_helper
INFO - 2023-06-28 10:22:59 --> Helper loaded: text_helper
INFO - 2023-06-28 10:22:59 --> Helper loaded: form_helper
INFO - 2023-06-28 10:22:59 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:22:59 --> Helper loaded: security_helper
INFO - 2023-06-28 10:22:59 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:22:59 --> Database Driver Class Initialized
INFO - 2023-06-28 10:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:22:59 --> Parser Class Initialized
INFO - 2023-06-28 10:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:22:59 --> Pagination Class Initialized
INFO - 2023-06-28 10:22:59 --> Form Validation Class Initialized
INFO - 2023-06-28 10:22:59 --> Controller Class Initialized
INFO - 2023-06-28 10:22:59 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:59 --> Model Class Initialized
DEBUG - 2023-06-28 10:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:22:59 --> Model Class Initialized
INFO - 2023-06-28 10:22:59 --> Final output sent to browser
DEBUG - 2023-06-28 10:22:59 --> Total execution time: 0.0219
ERROR - 2023-06-28 10:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:00 --> Config Class Initialized
INFO - 2023-06-28 10:23:00 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:00 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:00 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:00 --> URI Class Initialized
INFO - 2023-06-28 10:23:00 --> Router Class Initialized
INFO - 2023-06-28 10:23:00 --> Output Class Initialized
INFO - 2023-06-28 10:23:00 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:00 --> Input Class Initialized
INFO - 2023-06-28 10:23:00 --> Language Class Initialized
INFO - 2023-06-28 10:23:00 --> Loader Class Initialized
INFO - 2023-06-28 10:23:00 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:00 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:00 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:00 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:00 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:00 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:00 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:00 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:00 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:00 --> Parser Class Initialized
INFO - 2023-06-28 10:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:00 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:00 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:00 --> Controller Class Initialized
INFO - 2023-06-28 10:23:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:00 --> Model Class Initialized
INFO - 2023-06-28 10:23:00 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:00 --> Total execution time: 0.0340
ERROR - 2023-06-28 10:23:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:01 --> Config Class Initialized
INFO - 2023-06-28 10:23:01 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:01 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:01 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:01 --> URI Class Initialized
INFO - 2023-06-28 10:23:01 --> Router Class Initialized
INFO - 2023-06-28 10:23:01 --> Output Class Initialized
INFO - 2023-06-28 10:23:01 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:01 --> Input Class Initialized
INFO - 2023-06-28 10:23:01 --> Language Class Initialized
INFO - 2023-06-28 10:23:01 --> Loader Class Initialized
INFO - 2023-06-28 10:23:01 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:01 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:01 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:01 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:01 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:01 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:01 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:01 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:01 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:01 --> Parser Class Initialized
INFO - 2023-06-28 10:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:01 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:01 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:01 --> Controller Class Initialized
INFO - 2023-06-28 10:23:01 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:01 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:01 --> Model Class Initialized
INFO - 2023-06-28 10:23:01 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:01 --> Total execution time: 0.0335
ERROR - 2023-06-28 10:23:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:02 --> Config Class Initialized
INFO - 2023-06-28 10:23:02 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:02 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:02 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:02 --> URI Class Initialized
INFO - 2023-06-28 10:23:02 --> Router Class Initialized
INFO - 2023-06-28 10:23:02 --> Output Class Initialized
INFO - 2023-06-28 10:23:02 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:02 --> Input Class Initialized
INFO - 2023-06-28 10:23:02 --> Language Class Initialized
INFO - 2023-06-28 10:23:02 --> Loader Class Initialized
INFO - 2023-06-28 10:23:02 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:02 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:02 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:02 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:02 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:02 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:02 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:02 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:02 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:02 --> Parser Class Initialized
INFO - 2023-06-28 10:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:02 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:02 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:02 --> Controller Class Initialized
INFO - 2023-06-28 10:23:02 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:02 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:02 --> Model Class Initialized
INFO - 2023-06-28 10:23:02 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:02 --> Total execution time: 0.0180
ERROR - 2023-06-28 10:23:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:03 --> Config Class Initialized
INFO - 2023-06-28 10:23:03 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:03 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:03 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:03 --> URI Class Initialized
INFO - 2023-06-28 10:23:03 --> Router Class Initialized
INFO - 2023-06-28 10:23:03 --> Output Class Initialized
INFO - 2023-06-28 10:23:03 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:03 --> Input Class Initialized
INFO - 2023-06-28 10:23:03 --> Language Class Initialized
INFO - 2023-06-28 10:23:03 --> Loader Class Initialized
INFO - 2023-06-28 10:23:03 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:03 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:03 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:03 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:03 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:03 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:03 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:03 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:03 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:03 --> Parser Class Initialized
INFO - 2023-06-28 10:23:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:03 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:03 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:03 --> Controller Class Initialized
INFO - 2023-06-28 10:23:03 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:03 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:03 --> Model Class Initialized
INFO - 2023-06-28 10:23:03 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:03 --> Total execution time: 0.0192
ERROR - 2023-06-28 10:23:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:06 --> Config Class Initialized
INFO - 2023-06-28 10:23:06 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:06 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:06 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:06 --> URI Class Initialized
INFO - 2023-06-28 10:23:06 --> Router Class Initialized
INFO - 2023-06-28 10:23:06 --> Output Class Initialized
INFO - 2023-06-28 10:23:06 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:06 --> Input Class Initialized
INFO - 2023-06-28 10:23:06 --> Language Class Initialized
INFO - 2023-06-28 10:23:06 --> Loader Class Initialized
INFO - 2023-06-28 10:23:06 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:06 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:06 --> Parser Class Initialized
INFO - 2023-06-28 10:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:06 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:06 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:06 --> Controller Class Initialized
INFO - 2023-06-28 10:23:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:06 --> Model Class Initialized
INFO - 2023-06-28 10:23:06 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:06 --> Total execution time: 0.0387
ERROR - 2023-06-28 10:23:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:06 --> Config Class Initialized
INFO - 2023-06-28 10:23:06 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:06 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:06 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:06 --> URI Class Initialized
INFO - 2023-06-28 10:23:06 --> Router Class Initialized
INFO - 2023-06-28 10:23:06 --> Output Class Initialized
INFO - 2023-06-28 10:23:06 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:06 --> Input Class Initialized
INFO - 2023-06-28 10:23:06 --> Language Class Initialized
INFO - 2023-06-28 10:23:06 --> Loader Class Initialized
INFO - 2023-06-28 10:23:06 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:06 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:06 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:06 --> Parser Class Initialized
INFO - 2023-06-28 10:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:06 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:06 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:06 --> Controller Class Initialized
INFO - 2023-06-28 10:23:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:06 --> Model Class Initialized
INFO - 2023-06-28 10:23:06 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:06 --> Total execution time: 0.0350
ERROR - 2023-06-28 10:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:07 --> Config Class Initialized
INFO - 2023-06-28 10:23:07 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:07 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:07 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:07 --> URI Class Initialized
INFO - 2023-06-28 10:23:07 --> Router Class Initialized
INFO - 2023-06-28 10:23:07 --> Output Class Initialized
INFO - 2023-06-28 10:23:07 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:07 --> Input Class Initialized
INFO - 2023-06-28 10:23:07 --> Language Class Initialized
INFO - 2023-06-28 10:23:07 --> Loader Class Initialized
INFO - 2023-06-28 10:23:07 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:07 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:07 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:07 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:07 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:07 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:07 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:07 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:07 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:07 --> Parser Class Initialized
INFO - 2023-06-28 10:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:07 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:07 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:07 --> Controller Class Initialized
INFO - 2023-06-28 10:23:07 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:07 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:07 --> Model Class Initialized
INFO - 2023-06-28 10:23:07 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:07 --> Total execution time: 0.0173
ERROR - 2023-06-28 10:23:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:19 --> Config Class Initialized
INFO - 2023-06-28 10:23:19 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:19 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:19 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:19 --> URI Class Initialized
INFO - 2023-06-28 10:23:19 --> Router Class Initialized
INFO - 2023-06-28 10:23:19 --> Output Class Initialized
INFO - 2023-06-28 10:23:19 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:19 --> Input Class Initialized
INFO - 2023-06-28 10:23:19 --> Language Class Initialized
INFO - 2023-06-28 10:23:19 --> Loader Class Initialized
INFO - 2023-06-28 10:23:19 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:19 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:19 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:19 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:19 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:19 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:19 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:19 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:19 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:19 --> Parser Class Initialized
INFO - 2023-06-28 10:23:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:19 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:19 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:19 --> Controller Class Initialized
INFO - 2023-06-28 10:23:19 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:19 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:19 --> Model Class Initialized
INFO - 2023-06-28 10:23:19 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:19 --> Total execution time: 0.0211
ERROR - 2023-06-28 10:23:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:21 --> Config Class Initialized
INFO - 2023-06-28 10:23:21 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:21 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:21 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:21 --> URI Class Initialized
INFO - 2023-06-28 10:23:21 --> Router Class Initialized
INFO - 2023-06-28 10:23:21 --> Output Class Initialized
INFO - 2023-06-28 10:23:21 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:21 --> Input Class Initialized
INFO - 2023-06-28 10:23:21 --> Language Class Initialized
INFO - 2023-06-28 10:23:21 --> Loader Class Initialized
INFO - 2023-06-28 10:23:21 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:21 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:21 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:21 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:21 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:21 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:21 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:21 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:21 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:21 --> Parser Class Initialized
INFO - 2023-06-28 10:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:21 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:21 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:21 --> Controller Class Initialized
INFO - 2023-06-28 10:23:21 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:21 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:21 --> Model Class Initialized
INFO - 2023-06-28 10:23:21 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:21 --> Total execution time: 0.0184
ERROR - 2023-06-28 10:23:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:23 --> Config Class Initialized
INFO - 2023-06-28 10:23:23 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:23 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:23 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:23 --> URI Class Initialized
INFO - 2023-06-28 10:23:23 --> Router Class Initialized
INFO - 2023-06-28 10:23:23 --> Output Class Initialized
INFO - 2023-06-28 10:23:23 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:23 --> Input Class Initialized
INFO - 2023-06-28 10:23:23 --> Language Class Initialized
INFO - 2023-06-28 10:23:23 --> Loader Class Initialized
INFO - 2023-06-28 10:23:23 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:23 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:23 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:23 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:23 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:23 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:23 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:23 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:23 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:23 --> Parser Class Initialized
INFO - 2023-06-28 10:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:23 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:23 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:23 --> Controller Class Initialized
INFO - 2023-06-28 10:23:23 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:23 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:23 --> Model Class Initialized
INFO - 2023-06-28 10:23:23 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:23 --> Total execution time: 0.0185
ERROR - 2023-06-28 10:23:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:24 --> Config Class Initialized
INFO - 2023-06-28 10:23:24 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:24 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:24 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:24 --> URI Class Initialized
INFO - 2023-06-28 10:23:24 --> Router Class Initialized
INFO - 2023-06-28 10:23:24 --> Output Class Initialized
INFO - 2023-06-28 10:23:24 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:24 --> Input Class Initialized
INFO - 2023-06-28 10:23:24 --> Language Class Initialized
INFO - 2023-06-28 10:23:24 --> Loader Class Initialized
INFO - 2023-06-28 10:23:24 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:24 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:24 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:24 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:24 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:24 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:24 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:24 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:24 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:24 --> Parser Class Initialized
INFO - 2023-06-28 10:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:24 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:24 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:24 --> Controller Class Initialized
INFO - 2023-06-28 10:23:24 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:24 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:24 --> Model Class Initialized
INFO - 2023-06-28 10:23:24 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:24 --> Total execution time: 0.0351
ERROR - 2023-06-28 10:23:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:25 --> Config Class Initialized
INFO - 2023-06-28 10:23:25 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:25 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:25 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:25 --> URI Class Initialized
INFO - 2023-06-28 10:23:25 --> Router Class Initialized
INFO - 2023-06-28 10:23:25 --> Output Class Initialized
INFO - 2023-06-28 10:23:25 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:25 --> Input Class Initialized
INFO - 2023-06-28 10:23:25 --> Language Class Initialized
INFO - 2023-06-28 10:23:25 --> Loader Class Initialized
INFO - 2023-06-28 10:23:25 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:25 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:25 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:25 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:25 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:25 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:25 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:25 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:25 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:25 --> Parser Class Initialized
INFO - 2023-06-28 10:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:25 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:25 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:25 --> Controller Class Initialized
INFO - 2023-06-28 10:23:25 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:25 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:25 --> Model Class Initialized
INFO - 2023-06-28 10:23:25 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:25 --> Total execution time: 0.0338
ERROR - 2023-06-28 10:23:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:26 --> Config Class Initialized
INFO - 2023-06-28 10:23:26 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:26 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:26 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:26 --> URI Class Initialized
INFO - 2023-06-28 10:23:26 --> Router Class Initialized
INFO - 2023-06-28 10:23:26 --> Output Class Initialized
INFO - 2023-06-28 10:23:26 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:26 --> Input Class Initialized
INFO - 2023-06-28 10:23:26 --> Language Class Initialized
INFO - 2023-06-28 10:23:26 --> Loader Class Initialized
INFO - 2023-06-28 10:23:26 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:26 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:26 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:26 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:26 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:26 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:26 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:26 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:26 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:26 --> Parser Class Initialized
INFO - 2023-06-28 10:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:26 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:26 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:26 --> Controller Class Initialized
INFO - 2023-06-28 10:23:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:26 --> Model Class Initialized
INFO - 2023-06-28 10:23:26 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:26 --> Total execution time: 0.0347
ERROR - 2023-06-28 10:23:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:38 --> Config Class Initialized
INFO - 2023-06-28 10:23:38 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:38 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:38 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:38 --> URI Class Initialized
INFO - 2023-06-28 10:23:38 --> Router Class Initialized
INFO - 2023-06-28 10:23:38 --> Output Class Initialized
INFO - 2023-06-28 10:23:38 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:38 --> Input Class Initialized
INFO - 2023-06-28 10:23:38 --> Language Class Initialized
INFO - 2023-06-28 10:23:38 --> Loader Class Initialized
INFO - 2023-06-28 10:23:38 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:38 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:38 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:38 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:38 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:38 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:38 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:38 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:38 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:38 --> Parser Class Initialized
INFO - 2023-06-28 10:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:38 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:38 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:38 --> Controller Class Initialized
INFO - 2023-06-28 10:23:38 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:38 --> Model Class Initialized
INFO - 2023-06-28 10:23:38 --> Model Class Initialized
INFO - 2023-06-28 10:23:38 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:38 --> Total execution time: 0.0222
ERROR - 2023-06-28 10:23:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:41 --> Config Class Initialized
INFO - 2023-06-28 10:23:41 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:41 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:41 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:41 --> URI Class Initialized
INFO - 2023-06-28 10:23:41 --> Router Class Initialized
INFO - 2023-06-28 10:23:41 --> Output Class Initialized
INFO - 2023-06-28 10:23:41 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:41 --> Input Class Initialized
INFO - 2023-06-28 10:23:41 --> Language Class Initialized
INFO - 2023-06-28 10:23:41 --> Loader Class Initialized
INFO - 2023-06-28 10:23:41 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:41 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:41 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:41 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:41 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:41 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:41 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:41 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:41 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:41 --> Parser Class Initialized
INFO - 2023-06-28 10:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:41 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:41 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:41 --> Controller Class Initialized
INFO - 2023-06-28 10:23:41 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:41 --> Model Class Initialized
INFO - 2023-06-28 10:23:41 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:41 --> Total execution time: 0.0165
ERROR - 2023-06-28 10:23:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:51 --> Config Class Initialized
INFO - 2023-06-28 10:23:51 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:51 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:51 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:51 --> URI Class Initialized
INFO - 2023-06-28 10:23:51 --> Router Class Initialized
INFO - 2023-06-28 10:23:51 --> Output Class Initialized
INFO - 2023-06-28 10:23:51 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:51 --> Input Class Initialized
INFO - 2023-06-28 10:23:51 --> Language Class Initialized
INFO - 2023-06-28 10:23:51 --> Loader Class Initialized
INFO - 2023-06-28 10:23:51 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:51 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:51 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:51 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:51 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:51 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:51 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:51 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:51 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:51 --> Parser Class Initialized
INFO - 2023-06-28 10:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:51 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:51 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:51 --> Controller Class Initialized
INFO - 2023-06-28 10:23:51 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:51 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:51 --> Model Class Initialized
INFO - 2023-06-28 10:23:51 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:51 --> Total execution time: 0.0339
ERROR - 2023-06-28 10:23:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:52 --> Config Class Initialized
INFO - 2023-06-28 10:23:52 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:52 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:52 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:52 --> URI Class Initialized
INFO - 2023-06-28 10:23:52 --> Router Class Initialized
INFO - 2023-06-28 10:23:52 --> Output Class Initialized
INFO - 2023-06-28 10:23:52 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:52 --> Input Class Initialized
INFO - 2023-06-28 10:23:52 --> Language Class Initialized
INFO - 2023-06-28 10:23:52 --> Loader Class Initialized
INFO - 2023-06-28 10:23:52 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:52 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:52 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:52 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:52 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:52 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:52 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:52 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:52 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:52 --> Parser Class Initialized
INFO - 2023-06-28 10:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:52 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:52 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:52 --> Controller Class Initialized
INFO - 2023-06-28 10:23:52 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:52 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:52 --> Model Class Initialized
INFO - 2023-06-28 10:23:52 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:52 --> Total execution time: 0.0367
ERROR - 2023-06-28 10:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:53 --> Config Class Initialized
INFO - 2023-06-28 10:23:53 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:53 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:53 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:53 --> URI Class Initialized
INFO - 2023-06-28 10:23:53 --> Router Class Initialized
INFO - 2023-06-28 10:23:53 --> Output Class Initialized
INFO - 2023-06-28 10:23:53 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:53 --> Input Class Initialized
INFO - 2023-06-28 10:23:53 --> Language Class Initialized
INFO - 2023-06-28 10:23:53 --> Loader Class Initialized
INFO - 2023-06-28 10:23:53 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:53 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:53 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:53 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:53 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:53 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:53 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:53 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:53 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:53 --> Parser Class Initialized
INFO - 2023-06-28 10:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:53 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:53 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:53 --> Controller Class Initialized
INFO - 2023-06-28 10:23:53 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:53 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:53 --> Model Class Initialized
INFO - 2023-06-28 10:23:53 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:53 --> Total execution time: 0.0223
ERROR - 2023-06-28 10:23:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:58 --> Config Class Initialized
INFO - 2023-06-28 10:23:58 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:58 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:58 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:58 --> URI Class Initialized
INFO - 2023-06-28 10:23:58 --> Router Class Initialized
INFO - 2023-06-28 10:23:58 --> Output Class Initialized
INFO - 2023-06-28 10:23:58 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:58 --> Input Class Initialized
INFO - 2023-06-28 10:23:58 --> Language Class Initialized
INFO - 2023-06-28 10:23:58 --> Loader Class Initialized
INFO - 2023-06-28 10:23:58 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:58 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:58 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:58 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:58 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:58 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:58 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:58 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:58 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:58 --> Parser Class Initialized
INFO - 2023-06-28 10:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:58 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:58 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:58 --> Controller Class Initialized
INFO - 2023-06-28 10:23:58 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:58 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:58 --> Model Class Initialized
INFO - 2023-06-28 10:23:58 --> Final output sent to browser
DEBUG - 2023-06-28 10:23:58 --> Total execution time: 0.0346
ERROR - 2023-06-28 10:23:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:23:59 --> Config Class Initialized
INFO - 2023-06-28 10:23:59 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:23:59 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:23:59 --> Utf8 Class Initialized
INFO - 2023-06-28 10:23:59 --> URI Class Initialized
INFO - 2023-06-28 10:23:59 --> Router Class Initialized
INFO - 2023-06-28 10:23:59 --> Output Class Initialized
INFO - 2023-06-28 10:23:59 --> Security Class Initialized
DEBUG - 2023-06-28 10:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:23:59 --> Input Class Initialized
INFO - 2023-06-28 10:23:59 --> Language Class Initialized
INFO - 2023-06-28 10:23:59 --> Loader Class Initialized
INFO - 2023-06-28 10:23:59 --> Helper loaded: url_helper
INFO - 2023-06-28 10:23:59 --> Helper loaded: file_helper
INFO - 2023-06-28 10:23:59 --> Helper loaded: html_helper
INFO - 2023-06-28 10:23:59 --> Helper loaded: text_helper
INFO - 2023-06-28 10:23:59 --> Helper loaded: form_helper
INFO - 2023-06-28 10:23:59 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:23:59 --> Helper loaded: security_helper
INFO - 2023-06-28 10:23:59 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:23:59 --> Database Driver Class Initialized
INFO - 2023-06-28 10:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:23:59 --> Parser Class Initialized
INFO - 2023-06-28 10:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:23:59 --> Pagination Class Initialized
INFO - 2023-06-28 10:23:59 --> Form Validation Class Initialized
INFO - 2023-06-28 10:23:59 --> Controller Class Initialized
INFO - 2023-06-28 10:23:59 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:59 --> Model Class Initialized
DEBUG - 2023-06-28 10:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:23:59 --> Model Class Initialized
INFO - 2023-06-28 10:24:00 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:00 --> Total execution time: 0.0358
ERROR - 2023-06-28 10:24:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:00 --> Config Class Initialized
INFO - 2023-06-28 10:24:00 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:00 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:00 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:00 --> URI Class Initialized
INFO - 2023-06-28 10:24:00 --> Router Class Initialized
INFO - 2023-06-28 10:24:00 --> Output Class Initialized
INFO - 2023-06-28 10:24:00 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:00 --> Input Class Initialized
INFO - 2023-06-28 10:24:00 --> Language Class Initialized
INFO - 2023-06-28 10:24:00 --> Loader Class Initialized
INFO - 2023-06-28 10:24:00 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:00 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:00 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:00 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:00 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:00 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:00 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:00 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:00 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:00 --> Parser Class Initialized
INFO - 2023-06-28 10:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:00 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:00 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:00 --> Controller Class Initialized
INFO - 2023-06-28 10:24:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:00 --> Model Class Initialized
INFO - 2023-06-28 10:24:00 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:00 --> Total execution time: 0.0364
ERROR - 2023-06-28 10:24:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:03 --> Config Class Initialized
INFO - 2023-06-28 10:24:03 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:03 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:03 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:03 --> URI Class Initialized
INFO - 2023-06-28 10:24:03 --> Router Class Initialized
INFO - 2023-06-28 10:24:03 --> Output Class Initialized
INFO - 2023-06-28 10:24:03 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:03 --> Input Class Initialized
INFO - 2023-06-28 10:24:03 --> Language Class Initialized
INFO - 2023-06-28 10:24:03 --> Loader Class Initialized
INFO - 2023-06-28 10:24:03 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:03 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:03 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:03 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:03 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:03 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:03 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:03 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:03 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:03 --> Parser Class Initialized
INFO - 2023-06-28 10:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:03 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:03 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:03 --> Controller Class Initialized
INFO - 2023-06-28 10:24:03 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:03 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:03 --> Model Class Initialized
INFO - 2023-06-28 10:24:03 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:03 --> Total execution time: 0.0235
ERROR - 2023-06-28 10:24:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:06 --> Config Class Initialized
INFO - 2023-06-28 10:24:06 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:06 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:06 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:06 --> URI Class Initialized
INFO - 2023-06-28 10:24:06 --> Router Class Initialized
INFO - 2023-06-28 10:24:06 --> Output Class Initialized
INFO - 2023-06-28 10:24:06 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:06 --> Input Class Initialized
INFO - 2023-06-28 10:24:06 --> Language Class Initialized
INFO - 2023-06-28 10:24:06 --> Loader Class Initialized
INFO - 2023-06-28 10:24:06 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:06 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:06 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:06 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:06 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:06 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:06 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:06 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:06 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:06 --> Parser Class Initialized
INFO - 2023-06-28 10:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:06 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:06 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:06 --> Controller Class Initialized
INFO - 2023-06-28 10:24:06 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:06 --> Model Class Initialized
INFO - 2023-06-28 10:24:06 --> Model Class Initialized
INFO - 2023-06-28 10:24:06 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:06 --> Total execution time: 0.0189
ERROR - 2023-06-28 10:24:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:09 --> Config Class Initialized
INFO - 2023-06-28 10:24:09 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:09 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:09 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:09 --> URI Class Initialized
INFO - 2023-06-28 10:24:09 --> Router Class Initialized
INFO - 2023-06-28 10:24:09 --> Output Class Initialized
INFO - 2023-06-28 10:24:09 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:09 --> Input Class Initialized
INFO - 2023-06-28 10:24:09 --> Language Class Initialized
INFO - 2023-06-28 10:24:09 --> Loader Class Initialized
INFO - 2023-06-28 10:24:09 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:09 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:09 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:09 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:09 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:09 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:09 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:09 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:09 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:09 --> Parser Class Initialized
INFO - 2023-06-28 10:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:09 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:09 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:09 --> Controller Class Initialized
INFO - 2023-06-28 10:24:09 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:09 --> Model Class Initialized
INFO - 2023-06-28 10:24:09 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:09 --> Total execution time: 0.0164
ERROR - 2023-06-28 10:24:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:14 --> Config Class Initialized
INFO - 2023-06-28 10:24:14 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:14 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:14 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:14 --> URI Class Initialized
INFO - 2023-06-28 10:24:14 --> Router Class Initialized
INFO - 2023-06-28 10:24:14 --> Output Class Initialized
INFO - 2023-06-28 10:24:14 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:14 --> Input Class Initialized
INFO - 2023-06-28 10:24:14 --> Language Class Initialized
INFO - 2023-06-28 10:24:14 --> Loader Class Initialized
INFO - 2023-06-28 10:24:14 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:14 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:14 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:14 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:14 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:14 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:14 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:14 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:14 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:14 --> Parser Class Initialized
INFO - 2023-06-28 10:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:14 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:14 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:14 --> Controller Class Initialized
INFO - 2023-06-28 10:24:14 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:14 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:14 --> Model Class Initialized
INFO - 2023-06-28 10:24:14 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:14 --> Total execution time: 0.0382
ERROR - 2023-06-28 10:24:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:20 --> Config Class Initialized
INFO - 2023-06-28 10:24:20 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:20 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:20 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:20 --> URI Class Initialized
INFO - 2023-06-28 10:24:20 --> Router Class Initialized
INFO - 2023-06-28 10:24:20 --> Output Class Initialized
INFO - 2023-06-28 10:24:20 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:20 --> Input Class Initialized
INFO - 2023-06-28 10:24:20 --> Language Class Initialized
INFO - 2023-06-28 10:24:20 --> Loader Class Initialized
INFO - 2023-06-28 10:24:20 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:20 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:20 --> Parser Class Initialized
INFO - 2023-06-28 10:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:20 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:20 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:20 --> Controller Class Initialized
INFO - 2023-06-28 10:24:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:20 --> Model Class Initialized
INFO - 2023-06-28 10:24:20 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:20 --> Total execution time: 0.0358
ERROR - 2023-06-28 10:24:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:20 --> Config Class Initialized
INFO - 2023-06-28 10:24:20 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:20 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:20 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:20 --> URI Class Initialized
INFO - 2023-06-28 10:24:20 --> Router Class Initialized
INFO - 2023-06-28 10:24:20 --> Output Class Initialized
INFO - 2023-06-28 10:24:20 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:20 --> Input Class Initialized
INFO - 2023-06-28 10:24:20 --> Language Class Initialized
INFO - 2023-06-28 10:24:20 --> Loader Class Initialized
INFO - 2023-06-28 10:24:20 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:20 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:20 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:20 --> Parser Class Initialized
INFO - 2023-06-28 10:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:20 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:20 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:20 --> Controller Class Initialized
INFO - 2023-06-28 10:24:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:20 --> Model Class Initialized
INFO - 2023-06-28 10:24:20 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:20 --> Total execution time: 0.0347
ERROR - 2023-06-28 10:24:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:22 --> Config Class Initialized
INFO - 2023-06-28 10:24:22 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:22 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:22 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:22 --> URI Class Initialized
INFO - 2023-06-28 10:24:22 --> Router Class Initialized
INFO - 2023-06-28 10:24:22 --> Output Class Initialized
INFO - 2023-06-28 10:24:22 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:22 --> Input Class Initialized
INFO - 2023-06-28 10:24:22 --> Language Class Initialized
INFO - 2023-06-28 10:24:22 --> Loader Class Initialized
INFO - 2023-06-28 10:24:22 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:22 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:22 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:22 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:22 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:22 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:22 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:22 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:22 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:22 --> Parser Class Initialized
INFO - 2023-06-28 10:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:22 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:22 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:22 --> Controller Class Initialized
INFO - 2023-06-28 10:24:22 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:22 --> Model Class Initialized
INFO - 2023-06-28 10:24:22 --> Model Class Initialized
INFO - 2023-06-28 10:24:22 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:22 --> Total execution time: 0.0190
ERROR - 2023-06-28 10:24:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:25 --> Config Class Initialized
INFO - 2023-06-28 10:24:25 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:25 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:25 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:25 --> URI Class Initialized
INFO - 2023-06-28 10:24:25 --> Router Class Initialized
INFO - 2023-06-28 10:24:25 --> Output Class Initialized
INFO - 2023-06-28 10:24:25 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:25 --> Input Class Initialized
INFO - 2023-06-28 10:24:25 --> Language Class Initialized
INFO - 2023-06-28 10:24:25 --> Loader Class Initialized
INFO - 2023-06-28 10:24:25 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:25 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:25 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:25 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:25 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:25 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:25 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:25 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:25 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:25 --> Parser Class Initialized
INFO - 2023-06-28 10:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:25 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:25 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:25 --> Controller Class Initialized
INFO - 2023-06-28 10:24:25 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:25 --> Model Class Initialized
INFO - 2023-06-28 10:24:25 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:25 --> Total execution time: 0.0164
ERROR - 2023-06-28 10:24:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:35 --> Config Class Initialized
INFO - 2023-06-28 10:24:35 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:35 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:35 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:35 --> URI Class Initialized
INFO - 2023-06-28 10:24:35 --> Router Class Initialized
INFO - 2023-06-28 10:24:35 --> Output Class Initialized
INFO - 2023-06-28 10:24:35 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:35 --> Input Class Initialized
INFO - 2023-06-28 10:24:35 --> Language Class Initialized
INFO - 2023-06-28 10:24:35 --> Loader Class Initialized
INFO - 2023-06-28 10:24:35 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:35 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:35 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:35 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:35 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:35 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:35 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:35 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:35 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:35 --> Parser Class Initialized
INFO - 2023-06-28 10:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:35 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:35 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:35 --> Controller Class Initialized
INFO - 2023-06-28 10:24:35 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:35 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:35 --> Model Class Initialized
INFO - 2023-06-28 10:24:35 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:35 --> Total execution time: 0.0345
ERROR - 2023-06-28 10:24:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:36 --> Config Class Initialized
INFO - 2023-06-28 10:24:36 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:36 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:36 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:36 --> URI Class Initialized
INFO - 2023-06-28 10:24:36 --> Router Class Initialized
INFO - 2023-06-28 10:24:36 --> Output Class Initialized
INFO - 2023-06-28 10:24:36 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:36 --> Input Class Initialized
INFO - 2023-06-28 10:24:36 --> Language Class Initialized
INFO - 2023-06-28 10:24:36 --> Loader Class Initialized
INFO - 2023-06-28 10:24:36 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:36 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:36 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:36 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:36 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:36 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:36 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:36 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:36 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:36 --> Parser Class Initialized
INFO - 2023-06-28 10:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:36 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:36 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:36 --> Controller Class Initialized
INFO - 2023-06-28 10:24:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:36 --> Model Class Initialized
INFO - 2023-06-28 10:24:36 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:36 --> Total execution time: 0.0346
ERROR - 2023-06-28 10:24:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:37 --> Config Class Initialized
INFO - 2023-06-28 10:24:37 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:37 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:37 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:37 --> URI Class Initialized
INFO - 2023-06-28 10:24:37 --> Router Class Initialized
INFO - 2023-06-28 10:24:37 --> Output Class Initialized
INFO - 2023-06-28 10:24:37 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:37 --> Input Class Initialized
INFO - 2023-06-28 10:24:37 --> Language Class Initialized
INFO - 2023-06-28 10:24:37 --> Loader Class Initialized
INFO - 2023-06-28 10:24:37 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:37 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:37 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:37 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:37 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:37 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:37 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:37 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:37 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:37 --> Parser Class Initialized
INFO - 2023-06-28 10:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:37 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:37 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:37 --> Controller Class Initialized
INFO - 2023-06-28 10:24:37 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:37 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:37 --> Model Class Initialized
INFO - 2023-06-28 10:24:37 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:37 --> Total execution time: 0.0219
ERROR - 2023-06-28 10:24:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:39 --> Config Class Initialized
INFO - 2023-06-28 10:24:39 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:39 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:39 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:39 --> URI Class Initialized
INFO - 2023-06-28 10:24:39 --> Router Class Initialized
INFO - 2023-06-28 10:24:39 --> Output Class Initialized
INFO - 2023-06-28 10:24:39 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:39 --> Input Class Initialized
INFO - 2023-06-28 10:24:39 --> Language Class Initialized
INFO - 2023-06-28 10:24:39 --> Loader Class Initialized
INFO - 2023-06-28 10:24:39 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:39 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:39 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:39 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:39 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:39 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:39 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:39 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:39 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:39 --> Parser Class Initialized
INFO - 2023-06-28 10:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:39 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:39 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:39 --> Controller Class Initialized
INFO - 2023-06-28 10:24:39 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:39 --> Model Class Initialized
INFO - 2023-06-28 10:24:39 --> Model Class Initialized
INFO - 2023-06-28 10:24:39 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:39 --> Total execution time: 0.0204
ERROR - 2023-06-28 10:24:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:24:41 --> Config Class Initialized
INFO - 2023-06-28 10:24:41 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:24:41 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:24:41 --> Utf8 Class Initialized
INFO - 2023-06-28 10:24:41 --> URI Class Initialized
INFO - 2023-06-28 10:24:41 --> Router Class Initialized
INFO - 2023-06-28 10:24:41 --> Output Class Initialized
INFO - 2023-06-28 10:24:41 --> Security Class Initialized
DEBUG - 2023-06-28 10:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:24:41 --> Input Class Initialized
INFO - 2023-06-28 10:24:41 --> Language Class Initialized
INFO - 2023-06-28 10:24:41 --> Loader Class Initialized
INFO - 2023-06-28 10:24:41 --> Helper loaded: url_helper
INFO - 2023-06-28 10:24:41 --> Helper loaded: file_helper
INFO - 2023-06-28 10:24:41 --> Helper loaded: html_helper
INFO - 2023-06-28 10:24:41 --> Helper loaded: text_helper
INFO - 2023-06-28 10:24:41 --> Helper loaded: form_helper
INFO - 2023-06-28 10:24:41 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:24:41 --> Helper loaded: security_helper
INFO - 2023-06-28 10:24:41 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:24:41 --> Database Driver Class Initialized
INFO - 2023-06-28 10:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:24:41 --> Parser Class Initialized
INFO - 2023-06-28 10:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:24:41 --> Pagination Class Initialized
INFO - 2023-06-28 10:24:41 --> Form Validation Class Initialized
INFO - 2023-06-28 10:24:41 --> Controller Class Initialized
INFO - 2023-06-28 10:24:41 --> Model Class Initialized
DEBUG - 2023-06-28 10:24:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:24:41 --> Model Class Initialized
INFO - 2023-06-28 10:24:41 --> Final output sent to browser
DEBUG - 2023-06-28 10:24:41 --> Total execution time: 0.0162
ERROR - 2023-06-28 10:25:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:12 --> Config Class Initialized
INFO - 2023-06-28 10:25:12 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:12 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:12 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:12 --> URI Class Initialized
INFO - 2023-06-28 10:25:12 --> Router Class Initialized
INFO - 2023-06-28 10:25:12 --> Output Class Initialized
INFO - 2023-06-28 10:25:12 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:12 --> Input Class Initialized
INFO - 2023-06-28 10:25:12 --> Language Class Initialized
INFO - 2023-06-28 10:25:12 --> Loader Class Initialized
INFO - 2023-06-28 10:25:12 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:12 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:12 --> Parser Class Initialized
INFO - 2023-06-28 10:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:12 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:12 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:12 --> Controller Class Initialized
INFO - 2023-06-28 10:25:12 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:12 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:12 --> Model Class Initialized
INFO - 2023-06-28 10:25:12 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:12 --> Total execution time: 0.0341
ERROR - 2023-06-28 10:25:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:12 --> Config Class Initialized
INFO - 2023-06-28 10:25:12 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:12 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:12 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:12 --> URI Class Initialized
INFO - 2023-06-28 10:25:12 --> Router Class Initialized
INFO - 2023-06-28 10:25:12 --> Output Class Initialized
INFO - 2023-06-28 10:25:12 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:12 --> Input Class Initialized
INFO - 2023-06-28 10:25:12 --> Language Class Initialized
INFO - 2023-06-28 10:25:12 --> Loader Class Initialized
INFO - 2023-06-28 10:25:12 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:12 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:12 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:12 --> Parser Class Initialized
INFO - 2023-06-28 10:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:12 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:12 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:12 --> Controller Class Initialized
INFO - 2023-06-28 10:25:12 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:12 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:12 --> Model Class Initialized
INFO - 2023-06-28 10:25:12 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:12 --> Total execution time: 0.0334
ERROR - 2023-06-28 10:25:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:13 --> Config Class Initialized
INFO - 2023-06-28 10:25:13 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:13 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:13 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:13 --> URI Class Initialized
INFO - 2023-06-28 10:25:13 --> Router Class Initialized
INFO - 2023-06-28 10:25:13 --> Output Class Initialized
INFO - 2023-06-28 10:25:13 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:13 --> Input Class Initialized
INFO - 2023-06-28 10:25:13 --> Language Class Initialized
INFO - 2023-06-28 10:25:13 --> Loader Class Initialized
INFO - 2023-06-28 10:25:13 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:13 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:13 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:13 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:13 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:13 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:13 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:13 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:13 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:13 --> Parser Class Initialized
INFO - 2023-06-28 10:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:13 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:13 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:13 --> Controller Class Initialized
INFO - 2023-06-28 10:25:13 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:13 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:13 --> Model Class Initialized
INFO - 2023-06-28 10:25:13 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:13 --> Total execution time: 0.0201
ERROR - 2023-06-28 10:25:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:14 --> Config Class Initialized
INFO - 2023-06-28 10:25:14 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:14 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:14 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:14 --> URI Class Initialized
INFO - 2023-06-28 10:25:14 --> Router Class Initialized
INFO - 2023-06-28 10:25:14 --> Output Class Initialized
INFO - 2023-06-28 10:25:14 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:14 --> Input Class Initialized
INFO - 2023-06-28 10:25:14 --> Language Class Initialized
INFO - 2023-06-28 10:25:14 --> Loader Class Initialized
INFO - 2023-06-28 10:25:14 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:14 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:14 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:14 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:14 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:14 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:14 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:14 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:14 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:14 --> Parser Class Initialized
INFO - 2023-06-28 10:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:14 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:14 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:14 --> Controller Class Initialized
INFO - 2023-06-28 10:25:14 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:14 --> Model Class Initialized
INFO - 2023-06-28 10:25:14 --> Model Class Initialized
INFO - 2023-06-28 10:25:14 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:14 --> Total execution time: 0.0182
ERROR - 2023-06-28 10:25:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:17 --> Config Class Initialized
INFO - 2023-06-28 10:25:17 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:17 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:17 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:17 --> URI Class Initialized
INFO - 2023-06-28 10:25:17 --> Router Class Initialized
INFO - 2023-06-28 10:25:17 --> Output Class Initialized
INFO - 2023-06-28 10:25:17 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:17 --> Input Class Initialized
INFO - 2023-06-28 10:25:17 --> Language Class Initialized
INFO - 2023-06-28 10:25:17 --> Loader Class Initialized
INFO - 2023-06-28 10:25:17 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:17 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:17 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:17 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:17 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:17 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:17 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:17 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:17 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:17 --> Parser Class Initialized
INFO - 2023-06-28 10:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:17 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:17 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:17 --> Controller Class Initialized
INFO - 2023-06-28 10:25:17 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:17 --> Model Class Initialized
INFO - 2023-06-28 10:25:17 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:17 --> Total execution time: 0.0165
ERROR - 2023-06-28 10:25:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:25 --> Config Class Initialized
INFO - 2023-06-28 10:25:25 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:25 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:25 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:25 --> URI Class Initialized
INFO - 2023-06-28 10:25:25 --> Router Class Initialized
INFO - 2023-06-28 10:25:25 --> Output Class Initialized
INFO - 2023-06-28 10:25:25 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:25 --> Input Class Initialized
INFO - 2023-06-28 10:25:25 --> Language Class Initialized
INFO - 2023-06-28 10:25:25 --> Loader Class Initialized
INFO - 2023-06-28 10:25:25 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:25 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:25 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:25 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:25 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:25 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:25 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:25 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:25 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:25 --> Parser Class Initialized
INFO - 2023-06-28 10:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:25 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:25 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:25 --> Controller Class Initialized
INFO - 2023-06-28 10:25:25 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:25 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:25 --> Model Class Initialized
INFO - 2023-06-28 10:25:25 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:25 --> Total execution time: 0.0347
ERROR - 2023-06-28 10:25:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:26 --> Config Class Initialized
INFO - 2023-06-28 10:25:26 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:26 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:26 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:26 --> URI Class Initialized
INFO - 2023-06-28 10:25:26 --> Router Class Initialized
INFO - 2023-06-28 10:25:26 --> Output Class Initialized
INFO - 2023-06-28 10:25:26 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:26 --> Input Class Initialized
INFO - 2023-06-28 10:25:26 --> Language Class Initialized
INFO - 2023-06-28 10:25:26 --> Loader Class Initialized
INFO - 2023-06-28 10:25:26 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:26 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:26 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:26 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:26 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:26 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:26 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:26 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:26 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:26 --> Parser Class Initialized
INFO - 2023-06-28 10:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:26 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:26 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:26 --> Controller Class Initialized
INFO - 2023-06-28 10:25:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:26 --> Model Class Initialized
INFO - 2023-06-28 10:25:26 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:26 --> Total execution time: 0.0210
ERROR - 2023-06-28 10:25:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:27 --> Config Class Initialized
INFO - 2023-06-28 10:25:27 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:27 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:27 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:27 --> URI Class Initialized
INFO - 2023-06-28 10:25:27 --> Router Class Initialized
INFO - 2023-06-28 10:25:27 --> Output Class Initialized
INFO - 2023-06-28 10:25:27 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:27 --> Input Class Initialized
INFO - 2023-06-28 10:25:27 --> Language Class Initialized
INFO - 2023-06-28 10:25:27 --> Loader Class Initialized
INFO - 2023-06-28 10:25:27 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:27 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:27 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:27 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:27 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:27 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:27 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:27 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:27 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:27 --> Parser Class Initialized
INFO - 2023-06-28 10:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:27 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:27 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:27 --> Controller Class Initialized
INFO - 2023-06-28 10:25:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:27 --> Model Class Initialized
INFO - 2023-06-28 10:25:27 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:27 --> Total execution time: 0.0192
ERROR - 2023-06-28 10:25:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:30 --> Config Class Initialized
INFO - 2023-06-28 10:25:30 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:30 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:30 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:30 --> URI Class Initialized
INFO - 2023-06-28 10:25:30 --> Router Class Initialized
INFO - 2023-06-28 10:25:30 --> Output Class Initialized
INFO - 2023-06-28 10:25:30 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:30 --> Input Class Initialized
INFO - 2023-06-28 10:25:30 --> Language Class Initialized
INFO - 2023-06-28 10:25:30 --> Loader Class Initialized
INFO - 2023-06-28 10:25:30 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:30 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:30 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:30 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:30 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:30 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:30 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:30 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:30 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:30 --> Parser Class Initialized
INFO - 2023-06-28 10:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:30 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:30 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:30 --> Controller Class Initialized
INFO - 2023-06-28 10:25:30 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:30 --> Model Class Initialized
INFO - 2023-06-28 10:25:30 --> Model Class Initialized
INFO - 2023-06-28 10:25:30 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:30 --> Total execution time: 0.0189
ERROR - 2023-06-28 10:25:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:34 --> Config Class Initialized
INFO - 2023-06-28 10:25:34 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:34 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:34 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:34 --> URI Class Initialized
INFO - 2023-06-28 10:25:34 --> Router Class Initialized
INFO - 2023-06-28 10:25:34 --> Output Class Initialized
INFO - 2023-06-28 10:25:34 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:34 --> Input Class Initialized
INFO - 2023-06-28 10:25:34 --> Language Class Initialized
INFO - 2023-06-28 10:25:34 --> Loader Class Initialized
INFO - 2023-06-28 10:25:34 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:34 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:34 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:34 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:34 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:34 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:34 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:34 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:34 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:34 --> Parser Class Initialized
INFO - 2023-06-28 10:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:34 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:34 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:34 --> Controller Class Initialized
INFO - 2023-06-28 10:25:34 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:34 --> Model Class Initialized
INFO - 2023-06-28 10:25:34 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:34 --> Total execution time: 0.0154
ERROR - 2023-06-28 10:25:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:50 --> Config Class Initialized
INFO - 2023-06-28 10:25:50 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:50 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:50 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:50 --> URI Class Initialized
INFO - 2023-06-28 10:25:50 --> Router Class Initialized
INFO - 2023-06-28 10:25:50 --> Output Class Initialized
INFO - 2023-06-28 10:25:50 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:50 --> Input Class Initialized
INFO - 2023-06-28 10:25:50 --> Language Class Initialized
INFO - 2023-06-28 10:25:50 --> Loader Class Initialized
INFO - 2023-06-28 10:25:50 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:50 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:50 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:50 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:50 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:50 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:50 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:50 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:50 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:50 --> Parser Class Initialized
INFO - 2023-06-28 10:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:50 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:50 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:50 --> Controller Class Initialized
INFO - 2023-06-28 10:25:50 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:50 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:50 --> Model Class Initialized
INFO - 2023-06-28 10:25:50 --> Email Class Initialized
DEBUG - 2023-06-28 10:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-28 10:25:50 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-06-28 10:25:51 --> Language file loaded: language/english/email_lang.php
INFO - 2023-06-28 10:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-06-28 10:25:51 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:51 --> Total execution time: 0.5485
ERROR - 2023-06-28 10:25:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:53 --> Config Class Initialized
INFO - 2023-06-28 10:25:53 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:53 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:53 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:53 --> URI Class Initialized
INFO - 2023-06-28 10:25:53 --> Router Class Initialized
INFO - 2023-06-28 10:25:53 --> Output Class Initialized
INFO - 2023-06-28 10:25:53 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:53 --> Input Class Initialized
INFO - 2023-06-28 10:25:53 --> Language Class Initialized
INFO - 2023-06-28 10:25:53 --> Loader Class Initialized
INFO - 2023-06-28 10:25:53 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:53 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:53 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:53 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:53 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:53 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:53 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:53 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:53 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:53 --> Parser Class Initialized
INFO - 2023-06-28 10:25:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:53 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:53 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:53 --> Controller Class Initialized
INFO - 2023-06-28 10:25:53 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:53 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:53 --> Model Class Initialized
INFO - 2023-06-28 10:25:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-28 10:25:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:25:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:25:53 --> Model Class Initialized
INFO - 2023-06-28 10:25:53 --> Model Class Initialized
INFO - 2023-06-28 10:25:53 --> Model Class Initialized
INFO - 2023-06-28 10:25:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:25:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:25:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:25:53 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:53 --> Total execution time: 0.0869
ERROR - 2023-06-28 10:25:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:56 --> Config Class Initialized
INFO - 2023-06-28 10:25:56 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:56 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:56 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:56 --> URI Class Initialized
INFO - 2023-06-28 10:25:56 --> Router Class Initialized
INFO - 2023-06-28 10:25:56 --> Output Class Initialized
INFO - 2023-06-28 10:25:56 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:56 --> Input Class Initialized
INFO - 2023-06-28 10:25:56 --> Language Class Initialized
INFO - 2023-06-28 10:25:56 --> Loader Class Initialized
INFO - 2023-06-28 10:25:56 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:56 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:56 --> Parser Class Initialized
INFO - 2023-06-28 10:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:56 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:56 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:56 --> Controller Class Initialized
INFO - 2023-06-28 10:25:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:56 --> Model Class Initialized
INFO - 2023-06-28 10:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:25:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:25:56 --> Model Class Initialized
INFO - 2023-06-28 10:25:56 --> Model Class Initialized
INFO - 2023-06-28 10:25:56 --> Model Class Initialized
INFO - 2023-06-28 10:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:25:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:25:56 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:56 --> Total execution time: 0.0705
ERROR - 2023-06-28 10:25:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:25:56 --> Config Class Initialized
INFO - 2023-06-28 10:25:56 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:25:56 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:25:56 --> Utf8 Class Initialized
INFO - 2023-06-28 10:25:56 --> URI Class Initialized
INFO - 2023-06-28 10:25:56 --> Router Class Initialized
INFO - 2023-06-28 10:25:56 --> Output Class Initialized
INFO - 2023-06-28 10:25:56 --> Security Class Initialized
DEBUG - 2023-06-28 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:25:56 --> Input Class Initialized
INFO - 2023-06-28 10:25:56 --> Language Class Initialized
INFO - 2023-06-28 10:25:56 --> Loader Class Initialized
INFO - 2023-06-28 10:25:56 --> Helper loaded: url_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: file_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: html_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: text_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: form_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: security_helper
INFO - 2023-06-28 10:25:56 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:25:56 --> Database Driver Class Initialized
INFO - 2023-06-28 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:25:56 --> Parser Class Initialized
INFO - 2023-06-28 10:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:25:56 --> Pagination Class Initialized
INFO - 2023-06-28 10:25:56 --> Form Validation Class Initialized
INFO - 2023-06-28 10:25:56 --> Controller Class Initialized
INFO - 2023-06-28 10:25:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:25:56 --> Model Class Initialized
INFO - 2023-06-28 10:25:56 --> Final output sent to browser
DEBUG - 2023-06-28 10:25:56 --> Total execution time: 0.0331
ERROR - 2023-06-28 10:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:26:01 --> Config Class Initialized
INFO - 2023-06-28 10:26:01 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:26:01 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:26:01 --> Utf8 Class Initialized
INFO - 2023-06-28 10:26:01 --> URI Class Initialized
INFO - 2023-06-28 10:26:01 --> Router Class Initialized
INFO - 2023-06-28 10:26:01 --> Output Class Initialized
INFO - 2023-06-28 10:26:01 --> Security Class Initialized
DEBUG - 2023-06-28 10:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:26:01 --> Input Class Initialized
INFO - 2023-06-28 10:26:01 --> Language Class Initialized
INFO - 2023-06-28 10:26:01 --> Loader Class Initialized
INFO - 2023-06-28 10:26:01 --> Helper loaded: url_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: file_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: html_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: text_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: form_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: security_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:26:01 --> Database Driver Class Initialized
INFO - 2023-06-28 10:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:26:01 --> Parser Class Initialized
INFO - 2023-06-28 10:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:26:01 --> Pagination Class Initialized
INFO - 2023-06-28 10:26:01 --> Form Validation Class Initialized
INFO - 2023-06-28 10:26:01 --> Controller Class Initialized
INFO - 2023-06-28 10:26:01 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:01 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:01 --> Model Class Initialized
INFO - 2023-06-28 10:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:26:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:26:01 --> Model Class Initialized
INFO - 2023-06-28 10:26:01 --> Model Class Initialized
INFO - 2023-06-28 10:26:01 --> Model Class Initialized
INFO - 2023-06-28 10:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:26:01 --> Final output sent to browser
DEBUG - 2023-06-28 10:26:01 --> Total execution time: 0.0692
ERROR - 2023-06-28 10:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:26:01 --> Config Class Initialized
INFO - 2023-06-28 10:26:01 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:26:01 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:26:01 --> Utf8 Class Initialized
INFO - 2023-06-28 10:26:01 --> URI Class Initialized
INFO - 2023-06-28 10:26:01 --> Router Class Initialized
INFO - 2023-06-28 10:26:01 --> Output Class Initialized
INFO - 2023-06-28 10:26:01 --> Security Class Initialized
DEBUG - 2023-06-28 10:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:26:01 --> Input Class Initialized
INFO - 2023-06-28 10:26:01 --> Language Class Initialized
INFO - 2023-06-28 10:26:01 --> Loader Class Initialized
INFO - 2023-06-28 10:26:01 --> Helper loaded: url_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: file_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: html_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: text_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: form_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: security_helper
INFO - 2023-06-28 10:26:01 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:26:01 --> Database Driver Class Initialized
INFO - 2023-06-28 10:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:26:01 --> Parser Class Initialized
INFO - 2023-06-28 10:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:26:01 --> Pagination Class Initialized
INFO - 2023-06-28 10:26:01 --> Form Validation Class Initialized
INFO - 2023-06-28 10:26:01 --> Controller Class Initialized
INFO - 2023-06-28 10:26:01 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:01 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:01 --> Model Class Initialized
INFO - 2023-06-28 10:26:01 --> Final output sent to browser
DEBUG - 2023-06-28 10:26:01 --> Total execution time: 0.0359
ERROR - 2023-06-28 10:26:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:26:04 --> Config Class Initialized
INFO - 2023-06-28 10:26:04 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:26:04 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:26:04 --> Utf8 Class Initialized
INFO - 2023-06-28 10:26:04 --> URI Class Initialized
INFO - 2023-06-28 10:26:04 --> Router Class Initialized
INFO - 2023-06-28 10:26:04 --> Output Class Initialized
INFO - 2023-06-28 10:26:04 --> Security Class Initialized
DEBUG - 2023-06-28 10:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:26:04 --> Input Class Initialized
INFO - 2023-06-28 10:26:04 --> Language Class Initialized
INFO - 2023-06-28 10:26:04 --> Loader Class Initialized
INFO - 2023-06-28 10:26:04 --> Helper loaded: url_helper
INFO - 2023-06-28 10:26:04 --> Helper loaded: file_helper
INFO - 2023-06-28 10:26:04 --> Helper loaded: html_helper
INFO - 2023-06-28 10:26:04 --> Helper loaded: text_helper
INFO - 2023-06-28 10:26:04 --> Helper loaded: form_helper
INFO - 2023-06-28 10:26:04 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:26:04 --> Helper loaded: security_helper
INFO - 2023-06-28 10:26:04 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:26:04 --> Database Driver Class Initialized
INFO - 2023-06-28 10:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:26:04 --> Parser Class Initialized
INFO - 2023-06-28 10:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:26:04 --> Pagination Class Initialized
INFO - 2023-06-28 10:26:04 --> Form Validation Class Initialized
INFO - 2023-06-28 10:26:04 --> Controller Class Initialized
INFO - 2023-06-28 10:26:04 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:04 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:04 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-28 10:26:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:26:04 --> Model Class Initialized
INFO - 2023-06-28 10:26:04 --> Model Class Initialized
INFO - 2023-06-28 10:26:04 --> Model Class Initialized
INFO - 2023-06-28 10:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:26:04 --> Final output sent to browser
DEBUG - 2023-06-28 10:26:04 --> Total execution time: 0.0793
ERROR - 2023-06-28 10:26:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:26:31 --> Config Class Initialized
INFO - 2023-06-28 10:26:31 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:26:31 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:26:31 --> Utf8 Class Initialized
INFO - 2023-06-28 10:26:31 --> URI Class Initialized
DEBUG - 2023-06-28 10:26:31 --> No URI present. Default controller set.
INFO - 2023-06-28 10:26:31 --> Router Class Initialized
INFO - 2023-06-28 10:26:31 --> Output Class Initialized
INFO - 2023-06-28 10:26:31 --> Security Class Initialized
DEBUG - 2023-06-28 10:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:26:31 --> Input Class Initialized
INFO - 2023-06-28 10:26:31 --> Language Class Initialized
INFO - 2023-06-28 10:26:31 --> Loader Class Initialized
INFO - 2023-06-28 10:26:31 --> Helper loaded: url_helper
INFO - 2023-06-28 10:26:31 --> Helper loaded: file_helper
INFO - 2023-06-28 10:26:31 --> Helper loaded: html_helper
INFO - 2023-06-28 10:26:31 --> Helper loaded: text_helper
INFO - 2023-06-28 10:26:31 --> Helper loaded: form_helper
INFO - 2023-06-28 10:26:31 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:26:31 --> Helper loaded: security_helper
INFO - 2023-06-28 10:26:31 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:26:31 --> Database Driver Class Initialized
INFO - 2023-06-28 10:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:26:31 --> Parser Class Initialized
INFO - 2023-06-28 10:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:26:31 --> Pagination Class Initialized
INFO - 2023-06-28 10:26:31 --> Form Validation Class Initialized
INFO - 2023-06-28 10:26:31 --> Controller Class Initialized
INFO - 2023-06-28 10:26:31 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 10:26:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:26:32 --> Config Class Initialized
INFO - 2023-06-28 10:26:32 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:26:32 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:26:32 --> Utf8 Class Initialized
INFO - 2023-06-28 10:26:32 --> URI Class Initialized
INFO - 2023-06-28 10:26:32 --> Router Class Initialized
INFO - 2023-06-28 10:26:32 --> Output Class Initialized
INFO - 2023-06-28 10:26:32 --> Security Class Initialized
DEBUG - 2023-06-28 10:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:26:32 --> Input Class Initialized
INFO - 2023-06-28 10:26:32 --> Language Class Initialized
INFO - 2023-06-28 10:26:32 --> Loader Class Initialized
INFO - 2023-06-28 10:26:32 --> Helper loaded: url_helper
INFO - 2023-06-28 10:26:32 --> Helper loaded: file_helper
INFO - 2023-06-28 10:26:32 --> Helper loaded: html_helper
INFO - 2023-06-28 10:26:32 --> Helper loaded: text_helper
INFO - 2023-06-28 10:26:32 --> Helper loaded: form_helper
INFO - 2023-06-28 10:26:32 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:26:32 --> Helper loaded: security_helper
INFO - 2023-06-28 10:26:32 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:26:32 --> Database Driver Class Initialized
INFO - 2023-06-28 10:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:26:32 --> Parser Class Initialized
INFO - 2023-06-28 10:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:26:32 --> Pagination Class Initialized
INFO - 2023-06-28 10:26:32 --> Form Validation Class Initialized
INFO - 2023-06-28 10:26:32 --> Controller Class Initialized
INFO - 2023-06-28 10:26:32 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 10:26:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:26:32 --> Model Class Initialized
INFO - 2023-06-28 10:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:26:32 --> Final output sent to browser
DEBUG - 2023-06-28 10:26:32 --> Total execution time: 0.0316
ERROR - 2023-06-28 10:26:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:26:37 --> Config Class Initialized
INFO - 2023-06-28 10:26:37 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:26:37 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:26:37 --> Utf8 Class Initialized
INFO - 2023-06-28 10:26:37 --> URI Class Initialized
DEBUG - 2023-06-28 10:26:37 --> No URI present. Default controller set.
INFO - 2023-06-28 10:26:37 --> Router Class Initialized
INFO - 2023-06-28 10:26:37 --> Output Class Initialized
INFO - 2023-06-28 10:26:37 --> Security Class Initialized
DEBUG - 2023-06-28 10:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:26:37 --> Input Class Initialized
INFO - 2023-06-28 10:26:37 --> Language Class Initialized
INFO - 2023-06-28 10:26:37 --> Loader Class Initialized
INFO - 2023-06-28 10:26:37 --> Helper loaded: url_helper
INFO - 2023-06-28 10:26:37 --> Helper loaded: file_helper
INFO - 2023-06-28 10:26:37 --> Helper loaded: html_helper
INFO - 2023-06-28 10:26:37 --> Helper loaded: text_helper
INFO - 2023-06-28 10:26:37 --> Helper loaded: form_helper
INFO - 2023-06-28 10:26:37 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:26:37 --> Helper loaded: security_helper
INFO - 2023-06-28 10:26:37 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:26:37 --> Database Driver Class Initialized
INFO - 2023-06-28 10:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:26:37 --> Parser Class Initialized
INFO - 2023-06-28 10:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:26:37 --> Pagination Class Initialized
INFO - 2023-06-28 10:26:37 --> Form Validation Class Initialized
INFO - 2023-06-28 10:26:37 --> Controller Class Initialized
INFO - 2023-06-28 10:26:37 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 10:26:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:26:38 --> Config Class Initialized
INFO - 2023-06-28 10:26:38 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:26:38 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:26:38 --> Utf8 Class Initialized
INFO - 2023-06-28 10:26:38 --> URI Class Initialized
INFO - 2023-06-28 10:26:38 --> Router Class Initialized
INFO - 2023-06-28 10:26:38 --> Output Class Initialized
INFO - 2023-06-28 10:26:38 --> Security Class Initialized
DEBUG - 2023-06-28 10:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:26:38 --> Input Class Initialized
INFO - 2023-06-28 10:26:38 --> Language Class Initialized
INFO - 2023-06-28 10:26:38 --> Loader Class Initialized
INFO - 2023-06-28 10:26:38 --> Helper loaded: url_helper
INFO - 2023-06-28 10:26:38 --> Helper loaded: file_helper
INFO - 2023-06-28 10:26:38 --> Helper loaded: html_helper
INFO - 2023-06-28 10:26:38 --> Helper loaded: text_helper
INFO - 2023-06-28 10:26:38 --> Helper loaded: form_helper
INFO - 2023-06-28 10:26:38 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:26:38 --> Helper loaded: security_helper
INFO - 2023-06-28 10:26:38 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:26:38 --> Database Driver Class Initialized
INFO - 2023-06-28 10:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:26:38 --> Parser Class Initialized
INFO - 2023-06-28 10:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:26:38 --> Pagination Class Initialized
INFO - 2023-06-28 10:26:38 --> Form Validation Class Initialized
INFO - 2023-06-28 10:26:38 --> Controller Class Initialized
INFO - 2023-06-28 10:26:38 --> Model Class Initialized
DEBUG - 2023-06-28 10:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 10:26:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:26:38 --> Model Class Initialized
INFO - 2023-06-28 10:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:26:38 --> Final output sent to browser
DEBUG - 2023-06-28 10:26:38 --> Total execution time: 0.0311
ERROR - 2023-06-28 10:27:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:27:14 --> Config Class Initialized
INFO - 2023-06-28 10:27:14 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:27:14 --> Utf8 Class Initialized
INFO - 2023-06-28 10:27:14 --> URI Class Initialized
INFO - 2023-06-28 10:27:14 --> Router Class Initialized
INFO - 2023-06-28 10:27:14 --> Output Class Initialized
INFO - 2023-06-28 10:27:14 --> Security Class Initialized
DEBUG - 2023-06-28 10:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:27:14 --> Input Class Initialized
INFO - 2023-06-28 10:27:14 --> Language Class Initialized
INFO - 2023-06-28 10:27:14 --> Loader Class Initialized
INFO - 2023-06-28 10:27:14 --> Helper loaded: url_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: file_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: html_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: text_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: form_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: security_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:27:14 --> Database Driver Class Initialized
INFO - 2023-06-28 10:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:27:14 --> Parser Class Initialized
INFO - 2023-06-28 10:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:27:14 --> Pagination Class Initialized
INFO - 2023-06-28 10:27:14 --> Form Validation Class Initialized
INFO - 2023-06-28 10:27:14 --> Controller Class Initialized
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
INFO - 2023-06-28 10:27:14 --> Final output sent to browser
DEBUG - 2023-06-28 10:27:14 --> Total execution time: 0.0195
ERROR - 2023-06-28 10:27:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:27:14 --> Config Class Initialized
INFO - 2023-06-28 10:27:14 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:27:14 --> Utf8 Class Initialized
INFO - 2023-06-28 10:27:14 --> URI Class Initialized
DEBUG - 2023-06-28 10:27:14 --> No URI present. Default controller set.
INFO - 2023-06-28 10:27:14 --> Router Class Initialized
INFO - 2023-06-28 10:27:14 --> Output Class Initialized
INFO - 2023-06-28 10:27:14 --> Security Class Initialized
DEBUG - 2023-06-28 10:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:27:14 --> Input Class Initialized
INFO - 2023-06-28 10:27:14 --> Language Class Initialized
INFO - 2023-06-28 10:27:14 --> Loader Class Initialized
INFO - 2023-06-28 10:27:14 --> Helper loaded: url_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: file_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: html_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: text_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: form_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: security_helper
INFO - 2023-06-28 10:27:14 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:27:14 --> Database Driver Class Initialized
INFO - 2023-06-28 10:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:27:14 --> Parser Class Initialized
INFO - 2023-06-28 10:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:27:14 --> Pagination Class Initialized
INFO - 2023-06-28 10:27:14 --> Form Validation Class Initialized
INFO - 2023-06-28 10:27:14 --> Controller Class Initialized
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
INFO - 2023-06-28 10:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:27:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:27:14 --> Model Class Initialized
INFO - 2023-06-28 10:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:27:14 --> Final output sent to browser
DEBUG - 2023-06-28 10:27:14 --> Total execution time: 0.0694
ERROR - 2023-06-28 10:27:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:27:26 --> Config Class Initialized
INFO - 2023-06-28 10:27:26 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:27:26 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:27:26 --> Utf8 Class Initialized
INFO - 2023-06-28 10:27:26 --> URI Class Initialized
INFO - 2023-06-28 10:27:26 --> Router Class Initialized
INFO - 2023-06-28 10:27:26 --> Output Class Initialized
INFO - 2023-06-28 10:27:26 --> Security Class Initialized
DEBUG - 2023-06-28 10:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:27:26 --> Input Class Initialized
INFO - 2023-06-28 10:27:26 --> Language Class Initialized
INFO - 2023-06-28 10:27:26 --> Loader Class Initialized
INFO - 2023-06-28 10:27:26 --> Helper loaded: url_helper
INFO - 2023-06-28 10:27:26 --> Helper loaded: file_helper
INFO - 2023-06-28 10:27:26 --> Helper loaded: html_helper
INFO - 2023-06-28 10:27:26 --> Helper loaded: text_helper
INFO - 2023-06-28 10:27:26 --> Helper loaded: form_helper
INFO - 2023-06-28 10:27:26 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:27:26 --> Helper loaded: security_helper
INFO - 2023-06-28 10:27:26 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:27:26 --> Database Driver Class Initialized
INFO - 2023-06-28 10:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:27:26 --> Parser Class Initialized
INFO - 2023-06-28 10:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:27:26 --> Pagination Class Initialized
INFO - 2023-06-28 10:27:26 --> Form Validation Class Initialized
INFO - 2023-06-28 10:27:26 --> Controller Class Initialized
INFO - 2023-06-28 10:27:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:26 --> Model Class Initialized
INFO - 2023-06-28 10:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:27:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:27:26 --> Model Class Initialized
INFO - 2023-06-28 10:27:26 --> Model Class Initialized
INFO - 2023-06-28 10:27:26 --> Model Class Initialized
INFO - 2023-06-28 10:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:27:26 --> Final output sent to browser
DEBUG - 2023-06-28 10:27:26 --> Total execution time: 0.0617
ERROR - 2023-06-28 10:27:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:27:27 --> Config Class Initialized
INFO - 2023-06-28 10:27:27 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:27:27 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:27:27 --> Utf8 Class Initialized
INFO - 2023-06-28 10:27:27 --> URI Class Initialized
INFO - 2023-06-28 10:27:27 --> Router Class Initialized
INFO - 2023-06-28 10:27:27 --> Output Class Initialized
INFO - 2023-06-28 10:27:27 --> Security Class Initialized
DEBUG - 2023-06-28 10:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:27:27 --> Input Class Initialized
INFO - 2023-06-28 10:27:27 --> Language Class Initialized
INFO - 2023-06-28 10:27:27 --> Loader Class Initialized
INFO - 2023-06-28 10:27:27 --> Helper loaded: url_helper
INFO - 2023-06-28 10:27:27 --> Helper loaded: file_helper
INFO - 2023-06-28 10:27:27 --> Helper loaded: html_helper
INFO - 2023-06-28 10:27:27 --> Helper loaded: text_helper
INFO - 2023-06-28 10:27:27 --> Helper loaded: form_helper
INFO - 2023-06-28 10:27:27 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:27:27 --> Helper loaded: security_helper
INFO - 2023-06-28 10:27:27 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:27:27 --> Database Driver Class Initialized
INFO - 2023-06-28 10:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:27:27 --> Parser Class Initialized
INFO - 2023-06-28 10:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:27:27 --> Pagination Class Initialized
INFO - 2023-06-28 10:27:27 --> Form Validation Class Initialized
INFO - 2023-06-28 10:27:27 --> Controller Class Initialized
INFO - 2023-06-28 10:27:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:27 --> Model Class Initialized
INFO - 2023-06-28 10:27:27 --> Final output sent to browser
DEBUG - 2023-06-28 10:27:27 --> Total execution time: 0.0252
ERROR - 2023-06-28 10:27:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:27:45 --> Config Class Initialized
INFO - 2023-06-28 10:27:45 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:27:45 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:27:45 --> Utf8 Class Initialized
INFO - 2023-06-28 10:27:45 --> URI Class Initialized
DEBUG - 2023-06-28 10:27:45 --> No URI present. Default controller set.
INFO - 2023-06-28 10:27:45 --> Router Class Initialized
INFO - 2023-06-28 10:27:45 --> Output Class Initialized
INFO - 2023-06-28 10:27:45 --> Security Class Initialized
DEBUG - 2023-06-28 10:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:27:45 --> Input Class Initialized
INFO - 2023-06-28 10:27:45 --> Language Class Initialized
INFO - 2023-06-28 10:27:45 --> Loader Class Initialized
INFO - 2023-06-28 10:27:45 --> Helper loaded: url_helper
INFO - 2023-06-28 10:27:45 --> Helper loaded: file_helper
INFO - 2023-06-28 10:27:45 --> Helper loaded: html_helper
INFO - 2023-06-28 10:27:45 --> Helper loaded: text_helper
INFO - 2023-06-28 10:27:45 --> Helper loaded: form_helper
INFO - 2023-06-28 10:27:45 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:27:45 --> Helper loaded: security_helper
INFO - 2023-06-28 10:27:45 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:27:45 --> Database Driver Class Initialized
INFO - 2023-06-28 10:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:27:45 --> Parser Class Initialized
INFO - 2023-06-28 10:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:27:45 --> Pagination Class Initialized
INFO - 2023-06-28 10:27:45 --> Form Validation Class Initialized
INFO - 2023-06-28 10:27:45 --> Controller Class Initialized
INFO - 2023-06-28 10:27:45 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:45 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:45 --> Model Class Initialized
INFO - 2023-06-28 10:27:45 --> Model Class Initialized
INFO - 2023-06-28 10:27:45 --> Model Class Initialized
INFO - 2023-06-28 10:27:45 --> Model Class Initialized
DEBUG - 2023-06-28 10:27:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:45 --> Model Class Initialized
INFO - 2023-06-28 10:27:45 --> Model Class Initialized
INFO - 2023-06-28 10:27:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:27:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:27:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:27:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:27:45 --> Model Class Initialized
INFO - 2023-06-28 10:27:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:27:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:27:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:27:45 --> Final output sent to browser
DEBUG - 2023-06-28 10:27:45 --> Total execution time: 0.0822
ERROR - 2023-06-28 10:28:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:28:11 --> Config Class Initialized
INFO - 2023-06-28 10:28:11 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:28:11 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:28:11 --> Utf8 Class Initialized
INFO - 2023-06-28 10:28:11 --> URI Class Initialized
INFO - 2023-06-28 10:28:11 --> Router Class Initialized
INFO - 2023-06-28 10:28:11 --> Output Class Initialized
INFO - 2023-06-28 10:28:11 --> Security Class Initialized
DEBUG - 2023-06-28 10:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:28:11 --> Input Class Initialized
INFO - 2023-06-28 10:28:11 --> Language Class Initialized
INFO - 2023-06-28 10:28:11 --> Loader Class Initialized
INFO - 2023-06-28 10:28:11 --> Helper loaded: url_helper
INFO - 2023-06-28 10:28:11 --> Helper loaded: file_helper
INFO - 2023-06-28 10:28:11 --> Helper loaded: html_helper
INFO - 2023-06-28 10:28:11 --> Helper loaded: text_helper
INFO - 2023-06-28 10:28:11 --> Helper loaded: form_helper
INFO - 2023-06-28 10:28:11 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:28:11 --> Helper loaded: security_helper
INFO - 2023-06-28 10:28:11 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:28:11 --> Database Driver Class Initialized
INFO - 2023-06-28 10:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:28:11 --> Parser Class Initialized
INFO - 2023-06-28 10:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:28:11 --> Pagination Class Initialized
INFO - 2023-06-28 10:28:11 --> Form Validation Class Initialized
INFO - 2023-06-28 10:28:11 --> Controller Class Initialized
INFO - 2023-06-28 10:28:11 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:11 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-06-28 10:28:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:28:11 --> Model Class Initialized
INFO - 2023-06-28 10:28:11 --> Model Class Initialized
INFO - 2023-06-28 10:28:11 --> Model Class Initialized
INFO - 2023-06-28 10:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:28:11 --> Final output sent to browser
DEBUG - 2023-06-28 10:28:11 --> Total execution time: 0.0636
ERROR - 2023-06-28 10:28:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:28:17 --> Config Class Initialized
INFO - 2023-06-28 10:28:17 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:28:17 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:28:17 --> Utf8 Class Initialized
INFO - 2023-06-28 10:28:17 --> URI Class Initialized
INFO - 2023-06-28 10:28:17 --> Router Class Initialized
INFO - 2023-06-28 10:28:17 --> Output Class Initialized
INFO - 2023-06-28 10:28:17 --> Security Class Initialized
DEBUG - 2023-06-28 10:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:28:17 --> Input Class Initialized
INFO - 2023-06-28 10:28:17 --> Language Class Initialized
INFO - 2023-06-28 10:28:17 --> Loader Class Initialized
INFO - 2023-06-28 10:28:17 --> Helper loaded: url_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: file_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: html_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: text_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: form_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: security_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:28:17 --> Database Driver Class Initialized
INFO - 2023-06-28 10:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:28:17 --> Parser Class Initialized
INFO - 2023-06-28 10:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:28:17 --> Pagination Class Initialized
INFO - 2023-06-28 10:28:17 --> Form Validation Class Initialized
INFO - 2023-06-28 10:28:17 --> Controller Class Initialized
INFO - 2023-06-28 10:28:17 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:17 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:17 --> Model Class Initialized
INFO - 2023-06-28 10:28:17 --> Final output sent to browser
DEBUG - 2023-06-28 10:28:17 --> Total execution time: 0.0184
ERROR - 2023-06-28 10:28:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:28:17 --> Config Class Initialized
INFO - 2023-06-28 10:28:17 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:28:17 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:28:17 --> Utf8 Class Initialized
INFO - 2023-06-28 10:28:17 --> URI Class Initialized
INFO - 2023-06-28 10:28:17 --> Router Class Initialized
INFO - 2023-06-28 10:28:17 --> Output Class Initialized
INFO - 2023-06-28 10:28:17 --> Security Class Initialized
DEBUG - 2023-06-28 10:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:28:17 --> Input Class Initialized
INFO - 2023-06-28 10:28:17 --> Language Class Initialized
INFO - 2023-06-28 10:28:17 --> Loader Class Initialized
INFO - 2023-06-28 10:28:17 --> Helper loaded: url_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: file_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: html_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: text_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: form_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: security_helper
INFO - 2023-06-28 10:28:17 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:28:17 --> Database Driver Class Initialized
INFO - 2023-06-28 10:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:28:17 --> Parser Class Initialized
INFO - 2023-06-28 10:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:28:17 --> Pagination Class Initialized
INFO - 2023-06-28 10:28:17 --> Form Validation Class Initialized
INFO - 2023-06-28 10:28:17 --> Controller Class Initialized
INFO - 2023-06-28 10:28:17 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:17 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:17 --> Model Class Initialized
INFO - 2023-06-28 10:28:17 --> Final output sent to browser
DEBUG - 2023-06-28 10:28:17 --> Total execution time: 0.0196
ERROR - 2023-06-28 10:28:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:28:18 --> Config Class Initialized
INFO - 2023-06-28 10:28:18 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:28:18 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:28:18 --> Utf8 Class Initialized
INFO - 2023-06-28 10:28:18 --> URI Class Initialized
INFO - 2023-06-28 10:28:18 --> Router Class Initialized
INFO - 2023-06-28 10:28:18 --> Output Class Initialized
INFO - 2023-06-28 10:28:18 --> Security Class Initialized
DEBUG - 2023-06-28 10:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:28:18 --> Input Class Initialized
INFO - 2023-06-28 10:28:18 --> Language Class Initialized
INFO - 2023-06-28 10:28:18 --> Loader Class Initialized
INFO - 2023-06-28 10:28:18 --> Helper loaded: url_helper
INFO - 2023-06-28 10:28:18 --> Helper loaded: file_helper
INFO - 2023-06-28 10:28:18 --> Helper loaded: html_helper
INFO - 2023-06-28 10:28:18 --> Helper loaded: text_helper
INFO - 2023-06-28 10:28:18 --> Helper loaded: form_helper
INFO - 2023-06-28 10:28:18 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:28:18 --> Helper loaded: security_helper
INFO - 2023-06-28 10:28:18 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:28:18 --> Database Driver Class Initialized
INFO - 2023-06-28 10:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:28:18 --> Parser Class Initialized
INFO - 2023-06-28 10:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:28:18 --> Pagination Class Initialized
INFO - 2023-06-28 10:28:18 --> Form Validation Class Initialized
INFO - 2023-06-28 10:28:18 --> Controller Class Initialized
INFO - 2023-06-28 10:28:18 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:18 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:18 --> Model Class Initialized
INFO - 2023-06-28 10:28:18 --> Final output sent to browser
DEBUG - 2023-06-28 10:28:18 --> Total execution time: 0.0185
ERROR - 2023-06-28 10:28:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:28:19 --> Config Class Initialized
INFO - 2023-06-28 10:28:19 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:28:19 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:28:19 --> Utf8 Class Initialized
INFO - 2023-06-28 10:28:19 --> URI Class Initialized
INFO - 2023-06-28 10:28:19 --> Router Class Initialized
INFO - 2023-06-28 10:28:19 --> Output Class Initialized
INFO - 2023-06-28 10:28:19 --> Security Class Initialized
DEBUG - 2023-06-28 10:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:28:19 --> Input Class Initialized
INFO - 2023-06-28 10:28:19 --> Language Class Initialized
INFO - 2023-06-28 10:28:19 --> Loader Class Initialized
INFO - 2023-06-28 10:28:19 --> Helper loaded: url_helper
INFO - 2023-06-28 10:28:19 --> Helper loaded: file_helper
INFO - 2023-06-28 10:28:19 --> Helper loaded: html_helper
INFO - 2023-06-28 10:28:19 --> Helper loaded: text_helper
INFO - 2023-06-28 10:28:19 --> Helper loaded: form_helper
INFO - 2023-06-28 10:28:19 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:28:19 --> Helper loaded: security_helper
INFO - 2023-06-28 10:28:19 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:28:19 --> Database Driver Class Initialized
INFO - 2023-06-28 10:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:28:19 --> Parser Class Initialized
INFO - 2023-06-28 10:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:28:19 --> Pagination Class Initialized
INFO - 2023-06-28 10:28:19 --> Form Validation Class Initialized
INFO - 2023-06-28 10:28:19 --> Controller Class Initialized
INFO - 2023-06-28 10:28:19 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:19 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:19 --> Model Class Initialized
INFO - 2023-06-28 10:28:19 --> Final output sent to browser
DEBUG - 2023-06-28 10:28:19 --> Total execution time: 0.0191
ERROR - 2023-06-28 10:28:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:28:20 --> Config Class Initialized
INFO - 2023-06-28 10:28:20 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:28:20 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:28:20 --> Utf8 Class Initialized
INFO - 2023-06-28 10:28:20 --> URI Class Initialized
INFO - 2023-06-28 10:28:20 --> Router Class Initialized
INFO - 2023-06-28 10:28:20 --> Output Class Initialized
INFO - 2023-06-28 10:28:20 --> Security Class Initialized
DEBUG - 2023-06-28 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:28:20 --> Input Class Initialized
INFO - 2023-06-28 10:28:20 --> Language Class Initialized
INFO - 2023-06-28 10:28:20 --> Loader Class Initialized
INFO - 2023-06-28 10:28:20 --> Helper loaded: url_helper
INFO - 2023-06-28 10:28:20 --> Helper loaded: file_helper
INFO - 2023-06-28 10:28:20 --> Helper loaded: html_helper
INFO - 2023-06-28 10:28:20 --> Helper loaded: text_helper
INFO - 2023-06-28 10:28:20 --> Helper loaded: form_helper
INFO - 2023-06-28 10:28:20 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:28:20 --> Helper loaded: security_helper
INFO - 2023-06-28 10:28:20 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:28:20 --> Database Driver Class Initialized
INFO - 2023-06-28 10:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:28:20 --> Parser Class Initialized
INFO - 2023-06-28 10:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:28:20 --> Pagination Class Initialized
INFO - 2023-06-28 10:28:20 --> Form Validation Class Initialized
INFO - 2023-06-28 10:28:20 --> Controller Class Initialized
INFO - 2023-06-28 10:28:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:20 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:20 --> Model Class Initialized
INFO - 2023-06-28 10:28:20 --> Final output sent to browser
DEBUG - 2023-06-28 10:28:20 --> Total execution time: 0.0184
ERROR - 2023-06-28 10:28:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:28:21 --> Config Class Initialized
INFO - 2023-06-28 10:28:21 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:28:21 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:28:21 --> Utf8 Class Initialized
INFO - 2023-06-28 10:28:21 --> URI Class Initialized
INFO - 2023-06-28 10:28:21 --> Router Class Initialized
INFO - 2023-06-28 10:28:21 --> Output Class Initialized
INFO - 2023-06-28 10:28:21 --> Security Class Initialized
DEBUG - 2023-06-28 10:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:28:21 --> Input Class Initialized
INFO - 2023-06-28 10:28:21 --> Language Class Initialized
INFO - 2023-06-28 10:28:21 --> Loader Class Initialized
INFO - 2023-06-28 10:28:21 --> Helper loaded: url_helper
INFO - 2023-06-28 10:28:21 --> Helper loaded: file_helper
INFO - 2023-06-28 10:28:21 --> Helper loaded: html_helper
INFO - 2023-06-28 10:28:21 --> Helper loaded: text_helper
INFO - 2023-06-28 10:28:21 --> Helper loaded: form_helper
INFO - 2023-06-28 10:28:21 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:28:21 --> Helper loaded: security_helper
INFO - 2023-06-28 10:28:21 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:28:21 --> Database Driver Class Initialized
INFO - 2023-06-28 10:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:28:21 --> Parser Class Initialized
INFO - 2023-06-28 10:28:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:28:21 --> Pagination Class Initialized
INFO - 2023-06-28 10:28:21 --> Form Validation Class Initialized
INFO - 2023-06-28 10:28:21 --> Controller Class Initialized
INFO - 2023-06-28 10:28:21 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:28:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:21 --> Model Class Initialized
INFO - 2023-06-28 10:28:21 --> Model Class Initialized
INFO - 2023-06-28 10:28:21 --> Final output sent to browser
DEBUG - 2023-06-28 10:28:21 --> Total execution time: 0.0189
ERROR - 2023-06-28 10:28:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:28:27 --> Config Class Initialized
INFO - 2023-06-28 10:28:27 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:28:27 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:28:27 --> Utf8 Class Initialized
INFO - 2023-06-28 10:28:27 --> URI Class Initialized
INFO - 2023-06-28 10:28:27 --> Router Class Initialized
INFO - 2023-06-28 10:28:27 --> Output Class Initialized
INFO - 2023-06-28 10:28:27 --> Security Class Initialized
DEBUG - 2023-06-28 10:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:28:27 --> Input Class Initialized
INFO - 2023-06-28 10:28:27 --> Language Class Initialized
INFO - 2023-06-28 10:28:27 --> Loader Class Initialized
INFO - 2023-06-28 10:28:27 --> Helper loaded: url_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: file_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: html_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: text_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: form_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: security_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:28:27 --> Database Driver Class Initialized
INFO - 2023-06-28 10:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:28:27 --> Parser Class Initialized
INFO - 2023-06-28 10:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:28:27 --> Pagination Class Initialized
INFO - 2023-06-28 10:28:27 --> Form Validation Class Initialized
INFO - 2023-06-28 10:28:27 --> Controller Class Initialized
INFO - 2023-06-28 10:28:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:27 --> Model Class Initialized
INFO - 2023-06-28 10:28:27 --> Email Class Initialized
INFO - 2023-06-28 10:28:27 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-06-28 10:28:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:28:27 --> Config Class Initialized
INFO - 2023-06-28 10:28:27 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:28:27 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:28:27 --> Utf8 Class Initialized
INFO - 2023-06-28 10:28:27 --> URI Class Initialized
INFO - 2023-06-28 10:28:27 --> Router Class Initialized
INFO - 2023-06-28 10:28:27 --> Output Class Initialized
INFO - 2023-06-28 10:28:27 --> Security Class Initialized
DEBUG - 2023-06-28 10:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:28:27 --> Input Class Initialized
INFO - 2023-06-28 10:28:27 --> Language Class Initialized
INFO - 2023-06-28 10:28:27 --> Loader Class Initialized
INFO - 2023-06-28 10:28:27 --> Helper loaded: url_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: file_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: html_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: text_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: form_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: security_helper
INFO - 2023-06-28 10:28:27 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:28:27 --> Database Driver Class Initialized
INFO - 2023-06-28 10:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:28:27 --> Parser Class Initialized
INFO - 2023-06-28 10:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:28:27 --> Pagination Class Initialized
INFO - 2023-06-28 10:28:27 --> Form Validation Class Initialized
INFO - 2023-06-28 10:28:27 --> Controller Class Initialized
INFO - 2023-06-28 10:28:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-06-28 10:28:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:28:27 --> Model Class Initialized
INFO - 2023-06-28 10:28:28 --> Model Class Initialized
INFO - 2023-06-28 10:28:28 --> Model Class Initialized
INFO - 2023-06-28 10:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:28:28 --> Final output sent to browser
DEBUG - 2023-06-28 10:28:28 --> Total execution time: 0.0620
ERROR - 2023-06-28 10:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:29:15 --> Config Class Initialized
INFO - 2023-06-28 10:29:15 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:29:15 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:29:15 --> Utf8 Class Initialized
INFO - 2023-06-28 10:29:15 --> URI Class Initialized
INFO - 2023-06-28 10:29:15 --> Router Class Initialized
INFO - 2023-06-28 10:29:15 --> Output Class Initialized
INFO - 2023-06-28 10:29:15 --> Security Class Initialized
DEBUG - 2023-06-28 10:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:29:15 --> Input Class Initialized
INFO - 2023-06-28 10:29:15 --> Language Class Initialized
INFO - 2023-06-28 10:29:15 --> Loader Class Initialized
INFO - 2023-06-28 10:29:15 --> Helper loaded: url_helper
INFO - 2023-06-28 10:29:15 --> Helper loaded: file_helper
INFO - 2023-06-28 10:29:15 --> Helper loaded: html_helper
INFO - 2023-06-28 10:29:15 --> Helper loaded: text_helper
INFO - 2023-06-28 10:29:15 --> Helper loaded: form_helper
INFO - 2023-06-28 10:29:15 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:29:15 --> Helper loaded: security_helper
INFO - 2023-06-28 10:29:15 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:29:15 --> Database Driver Class Initialized
INFO - 2023-06-28 10:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:29:15 --> Parser Class Initialized
INFO - 2023-06-28 10:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:29:15 --> Pagination Class Initialized
INFO - 2023-06-28 10:29:15 --> Form Validation Class Initialized
INFO - 2023-06-28 10:29:15 --> Controller Class Initialized
INFO - 2023-06-28 10:29:15 --> Model Class Initialized
DEBUG - 2023-06-28 10:29:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:29:15 --> Model Class Initialized
DEBUG - 2023-06-28 10:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:29:15 --> Model Class Initialized
INFO - 2023-06-28 10:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:29:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:29:15 --> Model Class Initialized
INFO - 2023-06-28 10:29:15 --> Model Class Initialized
INFO - 2023-06-28 10:29:15 --> Model Class Initialized
INFO - 2023-06-28 10:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:29:15 --> Final output sent to browser
DEBUG - 2023-06-28 10:29:15 --> Total execution time: 0.0766
ERROR - 2023-06-28 10:29:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:29:16 --> Config Class Initialized
INFO - 2023-06-28 10:29:16 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:29:16 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:29:16 --> Utf8 Class Initialized
INFO - 2023-06-28 10:29:16 --> URI Class Initialized
INFO - 2023-06-28 10:29:16 --> Router Class Initialized
INFO - 2023-06-28 10:29:16 --> Output Class Initialized
INFO - 2023-06-28 10:29:16 --> Security Class Initialized
DEBUG - 2023-06-28 10:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:29:16 --> Input Class Initialized
INFO - 2023-06-28 10:29:16 --> Language Class Initialized
INFO - 2023-06-28 10:29:16 --> Loader Class Initialized
INFO - 2023-06-28 10:29:16 --> Helper loaded: url_helper
INFO - 2023-06-28 10:29:16 --> Helper loaded: file_helper
INFO - 2023-06-28 10:29:16 --> Helper loaded: html_helper
INFO - 2023-06-28 10:29:16 --> Helper loaded: text_helper
INFO - 2023-06-28 10:29:16 --> Helper loaded: form_helper
INFO - 2023-06-28 10:29:16 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:29:16 --> Helper loaded: security_helper
INFO - 2023-06-28 10:29:16 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:29:16 --> Database Driver Class Initialized
INFO - 2023-06-28 10:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:29:16 --> Parser Class Initialized
INFO - 2023-06-28 10:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:29:16 --> Pagination Class Initialized
INFO - 2023-06-28 10:29:16 --> Form Validation Class Initialized
INFO - 2023-06-28 10:29:16 --> Controller Class Initialized
INFO - 2023-06-28 10:29:16 --> Model Class Initialized
DEBUG - 2023-06-28 10:29:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:29:16 --> Model Class Initialized
DEBUG - 2023-06-28 10:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:29:16 --> Model Class Initialized
INFO - 2023-06-28 10:29:16 --> Final output sent to browser
DEBUG - 2023-06-28 10:29:16 --> Total execution time: 0.0226
ERROR - 2023-06-28 10:29:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:29:30 --> Config Class Initialized
INFO - 2023-06-28 10:29:30 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:29:30 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:29:30 --> Utf8 Class Initialized
INFO - 2023-06-28 10:29:30 --> URI Class Initialized
INFO - 2023-06-28 10:29:30 --> Router Class Initialized
INFO - 2023-06-28 10:29:30 --> Output Class Initialized
INFO - 2023-06-28 10:29:30 --> Security Class Initialized
DEBUG - 2023-06-28 10:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:29:30 --> Input Class Initialized
INFO - 2023-06-28 10:29:30 --> Language Class Initialized
INFO - 2023-06-28 10:29:30 --> Loader Class Initialized
INFO - 2023-06-28 10:29:30 --> Helper loaded: url_helper
INFO - 2023-06-28 10:29:30 --> Helper loaded: file_helper
INFO - 2023-06-28 10:29:30 --> Helper loaded: html_helper
INFO - 2023-06-28 10:29:30 --> Helper loaded: text_helper
INFO - 2023-06-28 10:29:30 --> Helper loaded: form_helper
INFO - 2023-06-28 10:29:30 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:29:30 --> Helper loaded: security_helper
INFO - 2023-06-28 10:29:30 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:29:30 --> Database Driver Class Initialized
INFO - 2023-06-28 10:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:29:30 --> Parser Class Initialized
INFO - 2023-06-28 10:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:29:30 --> Pagination Class Initialized
INFO - 2023-06-28 10:29:30 --> Form Validation Class Initialized
INFO - 2023-06-28 10:29:30 --> Controller Class Initialized
INFO - 2023-06-28 10:29:30 --> Model Class Initialized
DEBUG - 2023-06-28 10:29:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:29:30 --> Model Class Initialized
DEBUG - 2023-06-28 10:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:29:30 --> Model Class Initialized
INFO - 2023-06-28 10:29:30 --> Final output sent to browser
DEBUG - 2023-06-28 10:29:30 --> Total execution time: 0.0257
ERROR - 2023-06-28 10:29:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:29:32 --> Config Class Initialized
INFO - 2023-06-28 10:29:32 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:29:32 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:29:32 --> Utf8 Class Initialized
INFO - 2023-06-28 10:29:32 --> URI Class Initialized
INFO - 2023-06-28 10:29:32 --> Router Class Initialized
INFO - 2023-06-28 10:29:32 --> Output Class Initialized
INFO - 2023-06-28 10:29:32 --> Security Class Initialized
DEBUG - 2023-06-28 10:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:29:32 --> Input Class Initialized
INFO - 2023-06-28 10:29:32 --> Language Class Initialized
INFO - 2023-06-28 10:29:32 --> Loader Class Initialized
INFO - 2023-06-28 10:29:32 --> Helper loaded: url_helper
INFO - 2023-06-28 10:29:32 --> Helper loaded: file_helper
INFO - 2023-06-28 10:29:32 --> Helper loaded: html_helper
INFO - 2023-06-28 10:29:32 --> Helper loaded: text_helper
INFO - 2023-06-28 10:29:32 --> Helper loaded: form_helper
INFO - 2023-06-28 10:29:32 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:29:32 --> Helper loaded: security_helper
INFO - 2023-06-28 10:29:32 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:29:32 --> Database Driver Class Initialized
INFO - 2023-06-28 10:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:29:32 --> Parser Class Initialized
INFO - 2023-06-28 10:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:29:32 --> Pagination Class Initialized
INFO - 2023-06-28 10:29:32 --> Form Validation Class Initialized
INFO - 2023-06-28 10:29:32 --> Controller Class Initialized
INFO - 2023-06-28 10:29:32 --> Model Class Initialized
DEBUG - 2023-06-28 10:29:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:29:32 --> Model Class Initialized
DEBUG - 2023-06-28 10:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:29:32 --> Model Class Initialized
INFO - 2023-06-28 10:29:32 --> Final output sent to browser
DEBUG - 2023-06-28 10:29:32 --> Total execution time: 0.0213
ERROR - 2023-06-28 10:31:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:31:38 --> Config Class Initialized
INFO - 2023-06-28 10:31:38 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:31:38 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:31:38 --> Utf8 Class Initialized
INFO - 2023-06-28 10:31:38 --> URI Class Initialized
DEBUG - 2023-06-28 10:31:38 --> No URI present. Default controller set.
INFO - 2023-06-28 10:31:38 --> Router Class Initialized
INFO - 2023-06-28 10:31:38 --> Output Class Initialized
INFO - 2023-06-28 10:31:38 --> Security Class Initialized
DEBUG - 2023-06-28 10:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:31:38 --> Input Class Initialized
INFO - 2023-06-28 10:31:38 --> Language Class Initialized
INFO - 2023-06-28 10:31:38 --> Loader Class Initialized
INFO - 2023-06-28 10:31:38 --> Helper loaded: url_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: file_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: html_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: text_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: form_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: security_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:31:38 --> Database Driver Class Initialized
INFO - 2023-06-28 10:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:31:38 --> Parser Class Initialized
INFO - 2023-06-28 10:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:31:38 --> Pagination Class Initialized
INFO - 2023-06-28 10:31:38 --> Form Validation Class Initialized
INFO - 2023-06-28 10:31:38 --> Controller Class Initialized
INFO - 2023-06-28 10:31:38 --> Model Class Initialized
DEBUG - 2023-06-28 10:31:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 10:31:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:31:38 --> Config Class Initialized
INFO - 2023-06-28 10:31:38 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:31:38 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:31:38 --> Utf8 Class Initialized
INFO - 2023-06-28 10:31:38 --> URI Class Initialized
INFO - 2023-06-28 10:31:38 --> Router Class Initialized
INFO - 2023-06-28 10:31:38 --> Output Class Initialized
INFO - 2023-06-28 10:31:38 --> Security Class Initialized
DEBUG - 2023-06-28 10:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:31:38 --> Input Class Initialized
INFO - 2023-06-28 10:31:38 --> Language Class Initialized
INFO - 2023-06-28 10:31:38 --> Loader Class Initialized
INFO - 2023-06-28 10:31:38 --> Helper loaded: url_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: file_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: html_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: text_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: form_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: security_helper
INFO - 2023-06-28 10:31:38 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:31:38 --> Database Driver Class Initialized
INFO - 2023-06-28 10:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:31:38 --> Parser Class Initialized
INFO - 2023-06-28 10:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:31:38 --> Pagination Class Initialized
INFO - 2023-06-28 10:31:38 --> Form Validation Class Initialized
INFO - 2023-06-28 10:31:38 --> Controller Class Initialized
INFO - 2023-06-28 10:31:38 --> Model Class Initialized
DEBUG - 2023-06-28 10:31:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 10:31:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:31:38 --> Model Class Initialized
INFO - 2023-06-28 10:31:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:31:38 --> Final output sent to browser
DEBUG - 2023-06-28 10:31:38 --> Total execution time: 0.0327
ERROR - 2023-06-28 10:32:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:32:33 --> Config Class Initialized
INFO - 2023-06-28 10:32:33 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:32:33 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:32:33 --> Utf8 Class Initialized
INFO - 2023-06-28 10:32:33 --> URI Class Initialized
INFO - 2023-06-28 10:32:33 --> Router Class Initialized
INFO - 2023-06-28 10:32:33 --> Output Class Initialized
INFO - 2023-06-28 10:32:33 --> Security Class Initialized
DEBUG - 2023-06-28 10:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:32:33 --> Input Class Initialized
INFO - 2023-06-28 10:32:33 --> Language Class Initialized
INFO - 2023-06-28 10:32:33 --> Loader Class Initialized
INFO - 2023-06-28 10:32:33 --> Helper loaded: url_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: file_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: html_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: text_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: form_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: security_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:32:33 --> Database Driver Class Initialized
INFO - 2023-06-28 10:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:32:33 --> Parser Class Initialized
INFO - 2023-06-28 10:32:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:32:33 --> Pagination Class Initialized
INFO - 2023-06-28 10:32:33 --> Form Validation Class Initialized
INFO - 2023-06-28 10:32:33 --> Controller Class Initialized
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
DEBUG - 2023-06-28 10:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
INFO - 2023-06-28 10:32:33 --> Final output sent to browser
DEBUG - 2023-06-28 10:32:33 --> Total execution time: 0.0192
ERROR - 2023-06-28 10:32:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:32:33 --> Config Class Initialized
INFO - 2023-06-28 10:32:33 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:32:33 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:32:33 --> Utf8 Class Initialized
INFO - 2023-06-28 10:32:33 --> URI Class Initialized
DEBUG - 2023-06-28 10:32:33 --> No URI present. Default controller set.
INFO - 2023-06-28 10:32:33 --> Router Class Initialized
INFO - 2023-06-28 10:32:33 --> Output Class Initialized
INFO - 2023-06-28 10:32:33 --> Security Class Initialized
DEBUG - 2023-06-28 10:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:32:33 --> Input Class Initialized
INFO - 2023-06-28 10:32:33 --> Language Class Initialized
INFO - 2023-06-28 10:32:33 --> Loader Class Initialized
INFO - 2023-06-28 10:32:33 --> Helper loaded: url_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: file_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: html_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: text_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: form_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: security_helper
INFO - 2023-06-28 10:32:33 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:32:33 --> Database Driver Class Initialized
INFO - 2023-06-28 10:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:32:33 --> Parser Class Initialized
INFO - 2023-06-28 10:32:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:32:33 --> Pagination Class Initialized
INFO - 2023-06-28 10:32:33 --> Form Validation Class Initialized
INFO - 2023-06-28 10:32:33 --> Controller Class Initialized
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
DEBUG - 2023-06-28 10:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
DEBUG - 2023-06-28 10:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
DEBUG - 2023-06-28 10:32:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
INFO - 2023-06-28 10:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:32:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:32:33 --> Model Class Initialized
INFO - 2023-06-28 10:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:32:33 --> Final output sent to browser
DEBUG - 2023-06-28 10:32:33 --> Total execution time: 0.0653
ERROR - 2023-06-28 10:32:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:32:39 --> Config Class Initialized
INFO - 2023-06-28 10:32:39 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:32:39 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:32:39 --> Utf8 Class Initialized
INFO - 2023-06-28 10:32:39 --> URI Class Initialized
INFO - 2023-06-28 10:32:39 --> Router Class Initialized
INFO - 2023-06-28 10:32:39 --> Output Class Initialized
INFO - 2023-06-28 10:32:39 --> Security Class Initialized
DEBUG - 2023-06-28 10:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:32:39 --> Input Class Initialized
INFO - 2023-06-28 10:32:39 --> Language Class Initialized
INFO - 2023-06-28 10:32:39 --> Loader Class Initialized
INFO - 2023-06-28 10:32:39 --> Helper loaded: url_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: file_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: html_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: text_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: form_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: security_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:32:39 --> Database Driver Class Initialized
INFO - 2023-06-28 10:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:32:39 --> Parser Class Initialized
INFO - 2023-06-28 10:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:32:39 --> Pagination Class Initialized
INFO - 2023-06-28 10:32:39 --> Form Validation Class Initialized
INFO - 2023-06-28 10:32:39 --> Controller Class Initialized
INFO - 2023-06-28 10:32:39 --> Model Class Initialized
DEBUG - 2023-06-28 10:32:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:39 --> Model Class Initialized
DEBUG - 2023-06-28 10:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:39 --> Model Class Initialized
INFO - 2023-06-28 10:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:32:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:32:39 --> Model Class Initialized
INFO - 2023-06-28 10:32:39 --> Model Class Initialized
INFO - 2023-06-28 10:32:39 --> Model Class Initialized
INFO - 2023-06-28 10:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:32:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:32:39 --> Final output sent to browser
DEBUG - 2023-06-28 10:32:39 --> Total execution time: 0.0580
ERROR - 2023-06-28 10:32:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:32:39 --> Config Class Initialized
INFO - 2023-06-28 10:32:39 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:32:39 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:32:39 --> Utf8 Class Initialized
INFO - 2023-06-28 10:32:39 --> URI Class Initialized
INFO - 2023-06-28 10:32:39 --> Router Class Initialized
INFO - 2023-06-28 10:32:39 --> Output Class Initialized
INFO - 2023-06-28 10:32:39 --> Security Class Initialized
DEBUG - 2023-06-28 10:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:32:39 --> Input Class Initialized
INFO - 2023-06-28 10:32:39 --> Language Class Initialized
INFO - 2023-06-28 10:32:39 --> Loader Class Initialized
INFO - 2023-06-28 10:32:39 --> Helper loaded: url_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: file_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: html_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: text_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: form_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: security_helper
INFO - 2023-06-28 10:32:39 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:32:39 --> Database Driver Class Initialized
INFO - 2023-06-28 10:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:32:39 --> Parser Class Initialized
INFO - 2023-06-28 10:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:32:39 --> Pagination Class Initialized
INFO - 2023-06-28 10:32:39 --> Form Validation Class Initialized
INFO - 2023-06-28 10:32:39 --> Controller Class Initialized
INFO - 2023-06-28 10:32:39 --> Model Class Initialized
DEBUG - 2023-06-28 10:32:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:39 --> Model Class Initialized
DEBUG - 2023-06-28 10:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:32:39 --> Model Class Initialized
INFO - 2023-06-28 10:32:39 --> Final output sent to browser
DEBUG - 2023-06-28 10:32:39 --> Total execution time: 0.0220
ERROR - 2023-06-28 10:33:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:33:00 --> Config Class Initialized
INFO - 2023-06-28 10:33:00 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:33:00 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:33:00 --> Utf8 Class Initialized
INFO - 2023-06-28 10:33:00 --> URI Class Initialized
INFO - 2023-06-28 10:33:00 --> Router Class Initialized
INFO - 2023-06-28 10:33:00 --> Output Class Initialized
INFO - 2023-06-28 10:33:00 --> Security Class Initialized
DEBUG - 2023-06-28 10:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:33:00 --> Input Class Initialized
INFO - 2023-06-28 10:33:00 --> Language Class Initialized
INFO - 2023-06-28 10:33:00 --> Loader Class Initialized
INFO - 2023-06-28 10:33:00 --> Helper loaded: url_helper
INFO - 2023-06-28 10:33:00 --> Helper loaded: file_helper
INFO - 2023-06-28 10:33:00 --> Helper loaded: html_helper
INFO - 2023-06-28 10:33:00 --> Helper loaded: text_helper
INFO - 2023-06-28 10:33:00 --> Helper loaded: form_helper
INFO - 2023-06-28 10:33:00 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:33:00 --> Helper loaded: security_helper
INFO - 2023-06-28 10:33:00 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:33:00 --> Database Driver Class Initialized
INFO - 2023-06-28 10:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:33:00 --> Parser Class Initialized
INFO - 2023-06-28 10:33:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:33:00 --> Pagination Class Initialized
INFO - 2023-06-28 10:33:00 --> Form Validation Class Initialized
INFO - 2023-06-28 10:33:00 --> Controller Class Initialized
INFO - 2023-06-28 10:33:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:33:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:33:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:33:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:33:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:33:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:33:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:33:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-28 10:33:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:33:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:33:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:33:00 --> Model Class Initialized
INFO - 2023-06-28 10:33:00 --> Model Class Initialized
INFO - 2023-06-28 10:33:00 --> Model Class Initialized
INFO - 2023-06-28 10:33:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:33:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:33:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:33:00 --> Final output sent to browser
DEBUG - 2023-06-28 10:33:00 --> Total execution time: 0.0799
ERROR - 2023-06-28 10:36:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:03 --> Config Class Initialized
INFO - 2023-06-28 10:36:03 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:03 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:03 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:03 --> URI Class Initialized
DEBUG - 2023-06-28 10:36:03 --> No URI present. Default controller set.
INFO - 2023-06-28 10:36:03 --> Router Class Initialized
INFO - 2023-06-28 10:36:03 --> Output Class Initialized
INFO - 2023-06-28 10:36:03 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:03 --> Input Class Initialized
INFO - 2023-06-28 10:36:03 --> Language Class Initialized
INFO - 2023-06-28 10:36:03 --> Loader Class Initialized
INFO - 2023-06-28 10:36:03 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:03 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:03 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:03 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:03 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:03 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:03 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:03 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:03 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:03 --> Parser Class Initialized
INFO - 2023-06-28 10:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:03 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:03 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:03 --> Controller Class Initialized
INFO - 2023-06-28 10:36:03 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:03 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:03 --> Model Class Initialized
INFO - 2023-06-28 10:36:03 --> Model Class Initialized
INFO - 2023-06-28 10:36:03 --> Model Class Initialized
INFO - 2023-06-28 10:36:03 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:03 --> Model Class Initialized
INFO - 2023-06-28 10:36:03 --> Model Class Initialized
INFO - 2023-06-28 10:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:36:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:36:03 --> Model Class Initialized
INFO - 2023-06-28 10:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:36:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:36:03 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:03 --> Total execution time: 0.0961
ERROR - 2023-06-28 10:36:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:09 --> Config Class Initialized
INFO - 2023-06-28 10:36:09 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:09 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:09 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:09 --> URI Class Initialized
INFO - 2023-06-28 10:36:09 --> Router Class Initialized
INFO - 2023-06-28 10:36:09 --> Output Class Initialized
INFO - 2023-06-28 10:36:09 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:09 --> Input Class Initialized
INFO - 2023-06-28 10:36:09 --> Language Class Initialized
INFO - 2023-06-28 10:36:09 --> Loader Class Initialized
INFO - 2023-06-28 10:36:09 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:09 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:09 --> Parser Class Initialized
INFO - 2023-06-28 10:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:09 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:09 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:09 --> Controller Class Initialized
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:36:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:36:09 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:09 --> Total execution time: 0.0665
ERROR - 2023-06-28 10:36:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:09 --> Config Class Initialized
INFO - 2023-06-28 10:36:09 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:09 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:09 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:09 --> URI Class Initialized
INFO - 2023-06-28 10:36:09 --> Router Class Initialized
INFO - 2023-06-28 10:36:09 --> Output Class Initialized
INFO - 2023-06-28 10:36:09 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:09 --> Input Class Initialized
INFO - 2023-06-28 10:36:09 --> Language Class Initialized
INFO - 2023-06-28 10:36:09 --> Loader Class Initialized
INFO - 2023-06-28 10:36:09 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:09 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:09 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:09 --> Parser Class Initialized
INFO - 2023-06-28 10:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:09 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:09 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:09 --> Controller Class Initialized
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:36:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
INFO - 2023-06-28 10:36:09 --> Model Class Initialized
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:36:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:36:09 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:09 --> Total execution time: 0.0743
ERROR - 2023-06-28 10:36:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:10 --> Config Class Initialized
INFO - 2023-06-28 10:36:10 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:10 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:10 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:10 --> URI Class Initialized
INFO - 2023-06-28 10:36:10 --> Router Class Initialized
INFO - 2023-06-28 10:36:10 --> Output Class Initialized
INFO - 2023-06-28 10:36:10 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:10 --> Input Class Initialized
INFO - 2023-06-28 10:36:10 --> Language Class Initialized
INFO - 2023-06-28 10:36:10 --> Loader Class Initialized
INFO - 2023-06-28 10:36:10 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:10 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:10 --> Parser Class Initialized
INFO - 2023-06-28 10:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:10 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:10 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:10 --> Controller Class Initialized
INFO - 2023-06-28 10:36:10 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:10 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:10 --> Model Class Initialized
INFO - 2023-06-28 10:36:10 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:10 --> Total execution time: 0.0222
ERROR - 2023-06-28 10:36:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:10 --> Config Class Initialized
INFO - 2023-06-28 10:36:10 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:10 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:10 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:10 --> URI Class Initialized
INFO - 2023-06-28 10:36:10 --> Router Class Initialized
INFO - 2023-06-28 10:36:10 --> Output Class Initialized
INFO - 2023-06-28 10:36:10 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:10 --> Input Class Initialized
INFO - 2023-06-28 10:36:10 --> Language Class Initialized
INFO - 2023-06-28 10:36:10 --> Loader Class Initialized
INFO - 2023-06-28 10:36:10 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:10 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:10 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:10 --> Parser Class Initialized
INFO - 2023-06-28 10:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:10 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:10 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:10 --> Controller Class Initialized
INFO - 2023-06-28 10:36:10 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:10 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:10 --> Model Class Initialized
INFO - 2023-06-28 10:36:10 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:10 --> Total execution time: 0.0325
ERROR - 2023-06-28 10:36:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:15 --> Config Class Initialized
INFO - 2023-06-28 10:36:15 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:15 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:15 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:15 --> URI Class Initialized
INFO - 2023-06-28 10:36:15 --> Router Class Initialized
INFO - 2023-06-28 10:36:15 --> Output Class Initialized
INFO - 2023-06-28 10:36:15 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:15 --> Input Class Initialized
INFO - 2023-06-28 10:36:15 --> Language Class Initialized
INFO - 2023-06-28 10:36:15 --> Loader Class Initialized
INFO - 2023-06-28 10:36:15 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:15 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:15 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:15 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:15 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:15 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:15 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:15 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:15 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:15 --> Parser Class Initialized
INFO - 2023-06-28 10:36:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:15 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:15 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:15 --> Controller Class Initialized
INFO - 2023-06-28 10:36:15 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:15 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:15 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-28 10:36:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:36:15 --> Model Class Initialized
INFO - 2023-06-28 10:36:15 --> Model Class Initialized
INFO - 2023-06-28 10:36:15 --> Model Class Initialized
INFO - 2023-06-28 10:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:36:15 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:15 --> Total execution time: 0.0735
ERROR - 2023-06-28 10:36:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:46 --> Config Class Initialized
INFO - 2023-06-28 10:36:46 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:46 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:46 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:46 --> URI Class Initialized
DEBUG - 2023-06-28 10:36:46 --> No URI present. Default controller set.
INFO - 2023-06-28 10:36:46 --> Router Class Initialized
INFO - 2023-06-28 10:36:46 --> Output Class Initialized
INFO - 2023-06-28 10:36:46 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:46 --> Input Class Initialized
INFO - 2023-06-28 10:36:46 --> Language Class Initialized
INFO - 2023-06-28 10:36:46 --> Loader Class Initialized
INFO - 2023-06-28 10:36:46 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:46 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:46 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:46 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:46 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:46 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:46 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:46 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:46 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:46 --> Parser Class Initialized
INFO - 2023-06-28 10:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:46 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:46 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:46 --> Controller Class Initialized
INFO - 2023-06-28 10:36:46 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:46 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:46 --> Model Class Initialized
INFO - 2023-06-28 10:36:46 --> Model Class Initialized
INFO - 2023-06-28 10:36:46 --> Model Class Initialized
INFO - 2023-06-28 10:36:46 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:46 --> Model Class Initialized
INFO - 2023-06-28 10:36:46 --> Model Class Initialized
INFO - 2023-06-28 10:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:36:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:36:46 --> Model Class Initialized
INFO - 2023-06-28 10:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:36:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:36:46 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:46 --> Total execution time: 0.1583
ERROR - 2023-06-28 10:36:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:52 --> Config Class Initialized
INFO - 2023-06-28 10:36:52 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:52 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:52 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:52 --> URI Class Initialized
INFO - 2023-06-28 10:36:52 --> Router Class Initialized
INFO - 2023-06-28 10:36:52 --> Output Class Initialized
INFO - 2023-06-28 10:36:52 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:52 --> Input Class Initialized
INFO - 2023-06-28 10:36:52 --> Language Class Initialized
INFO - 2023-06-28 10:36:52 --> Loader Class Initialized
INFO - 2023-06-28 10:36:52 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:52 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:52 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:52 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:52 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:52 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:52 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:52 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:52 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:52 --> Parser Class Initialized
INFO - 2023-06-28 10:36:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:52 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:52 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:52 --> Controller Class Initialized
INFO - 2023-06-28 10:36:52 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:52 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:52 --> Model Class Initialized
INFO - 2023-06-28 10:36:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:36:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:36:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:36:52 --> Model Class Initialized
INFO - 2023-06-28 10:36:52 --> Model Class Initialized
INFO - 2023-06-28 10:36:52 --> Model Class Initialized
INFO - 2023-06-28 10:36:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:36:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:36:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:36:53 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:53 --> Total execution time: 0.1364
ERROR - 2023-06-28 10:36:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:53 --> Config Class Initialized
INFO - 2023-06-28 10:36:53 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:53 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:53 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:53 --> URI Class Initialized
INFO - 2023-06-28 10:36:53 --> Router Class Initialized
INFO - 2023-06-28 10:36:53 --> Output Class Initialized
INFO - 2023-06-28 10:36:53 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:53 --> Input Class Initialized
INFO - 2023-06-28 10:36:53 --> Language Class Initialized
INFO - 2023-06-28 10:36:53 --> Loader Class Initialized
INFO - 2023-06-28 10:36:53 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:53 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:53 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:53 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:53 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:53 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:53 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:53 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:53 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:53 --> Parser Class Initialized
INFO - 2023-06-28 10:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:53 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:53 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:53 --> Controller Class Initialized
INFO - 2023-06-28 10:36:53 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:53 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:53 --> Model Class Initialized
INFO - 2023-06-28 10:36:53 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:53 --> Total execution time: 0.0529
ERROR - 2023-06-28 10:36:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:56 --> Config Class Initialized
INFO - 2023-06-28 10:36:56 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:56 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:56 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:56 --> URI Class Initialized
DEBUG - 2023-06-28 10:36:56 --> No URI present. Default controller set.
INFO - 2023-06-28 10:36:56 --> Router Class Initialized
INFO - 2023-06-28 10:36:56 --> Output Class Initialized
INFO - 2023-06-28 10:36:56 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:56 --> Input Class Initialized
INFO - 2023-06-28 10:36:56 --> Language Class Initialized
INFO - 2023-06-28 10:36:56 --> Loader Class Initialized
INFO - 2023-06-28 10:36:56 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:56 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:56 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:56 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:56 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:56 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:56 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:56 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:56 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:56 --> Parser Class Initialized
INFO - 2023-06-28 10:36:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:56 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:56 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:56 --> Controller Class Initialized
INFO - 2023-06-28 10:36:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:56 --> Model Class Initialized
INFO - 2023-06-28 10:36:56 --> Model Class Initialized
INFO - 2023-06-28 10:36:56 --> Model Class Initialized
INFO - 2023-06-28 10:36:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:56 --> Model Class Initialized
INFO - 2023-06-28 10:36:56 --> Model Class Initialized
INFO - 2023-06-28 10:36:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:36:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:36:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:36:56 --> Model Class Initialized
INFO - 2023-06-28 10:36:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:36:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:36:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:36:56 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:56 --> Total execution time: 0.0640
ERROR - 2023-06-28 10:36:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:57 --> Config Class Initialized
INFO - 2023-06-28 10:36:57 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:57 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:57 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:57 --> URI Class Initialized
INFO - 2023-06-28 10:36:57 --> Router Class Initialized
INFO - 2023-06-28 10:36:57 --> Output Class Initialized
INFO - 2023-06-28 10:36:57 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:57 --> Input Class Initialized
INFO - 2023-06-28 10:36:57 --> Language Class Initialized
INFO - 2023-06-28 10:36:57 --> Loader Class Initialized
INFO - 2023-06-28 10:36:57 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:57 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:57 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:57 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:57 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:57 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:57 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:57 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:57 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:57 --> Parser Class Initialized
INFO - 2023-06-28 10:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:57 --> Pagination Class Initialized
INFO - 2023-06-28 10:36:57 --> Form Validation Class Initialized
INFO - 2023-06-28 10:36:57 --> Controller Class Initialized
INFO - 2023-06-28 10:36:57 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:57 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:57 --> Model Class Initialized
DEBUG - 2023-06-28 10:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-28 10:36:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:36:57 --> Model Class Initialized
INFO - 2023-06-28 10:36:57 --> Model Class Initialized
INFO - 2023-06-28 10:36:57 --> Model Class Initialized
INFO - 2023-06-28 10:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:36:57 --> Final output sent to browser
DEBUG - 2023-06-28 10:36:57 --> Total execution time: 0.1370
ERROR - 2023-06-28 10:36:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:36:59 --> Config Class Initialized
INFO - 2023-06-28 10:36:59 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:36:59 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:36:59 --> Utf8 Class Initialized
INFO - 2023-06-28 10:36:59 --> URI Class Initialized
INFO - 2023-06-28 10:36:59 --> Router Class Initialized
INFO - 2023-06-28 10:36:59 --> Output Class Initialized
INFO - 2023-06-28 10:36:59 --> Security Class Initialized
DEBUG - 2023-06-28 10:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:36:59 --> Input Class Initialized
INFO - 2023-06-28 10:36:59 --> Language Class Initialized
INFO - 2023-06-28 10:36:59 --> Loader Class Initialized
INFO - 2023-06-28 10:36:59 --> Helper loaded: url_helper
INFO - 2023-06-28 10:36:59 --> Helper loaded: file_helper
INFO - 2023-06-28 10:36:59 --> Helper loaded: html_helper
INFO - 2023-06-28 10:36:59 --> Helper loaded: text_helper
INFO - 2023-06-28 10:36:59 --> Helper loaded: form_helper
INFO - 2023-06-28 10:36:59 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:36:59 --> Helper loaded: security_helper
INFO - 2023-06-28 10:36:59 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:36:59 --> Database Driver Class Initialized
INFO - 2023-06-28 10:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:36:59 --> Parser Class Initialized
INFO - 2023-06-28 10:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:36:59 --> Pagination Class Initialized
INFO - 2023-06-28 10:37:00 --> Form Validation Class Initialized
INFO - 2023-06-28 10:37:00 --> Controller Class Initialized
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 10:37:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:37:00 --> Final output sent to browser
DEBUG - 2023-06-28 10:37:00 --> Total execution time: 0.0275
ERROR - 2023-06-28 10:37:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:37:00 --> Config Class Initialized
INFO - 2023-06-28 10:37:00 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:37:00 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:37:00 --> Utf8 Class Initialized
INFO - 2023-06-28 10:37:00 --> URI Class Initialized
INFO - 2023-06-28 10:37:00 --> Router Class Initialized
INFO - 2023-06-28 10:37:00 --> Output Class Initialized
INFO - 2023-06-28 10:37:00 --> Security Class Initialized
DEBUG - 2023-06-28 10:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:37:00 --> Input Class Initialized
INFO - 2023-06-28 10:37:00 --> Language Class Initialized
INFO - 2023-06-28 10:37:00 --> Loader Class Initialized
INFO - 2023-06-28 10:37:00 --> Helper loaded: url_helper
INFO - 2023-06-28 10:37:00 --> Helper loaded: file_helper
INFO - 2023-06-28 10:37:00 --> Helper loaded: html_helper
INFO - 2023-06-28 10:37:00 --> Helper loaded: text_helper
INFO - 2023-06-28 10:37:00 --> Helper loaded: form_helper
INFO - 2023-06-28 10:37:00 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:37:00 --> Helper loaded: security_helper
INFO - 2023-06-28 10:37:00 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:37:00 --> Database Driver Class Initialized
INFO - 2023-06-28 10:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:37:00 --> Parser Class Initialized
INFO - 2023-06-28 10:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:37:00 --> Pagination Class Initialized
INFO - 2023-06-28 10:37:00 --> Form Validation Class Initialized
INFO - 2023-06-28 10:37:00 --> Controller Class Initialized
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
DEBUG - 2023-06-28 10:37:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:37:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:37:00 --> Model Class Initialized
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:37:00 --> Final output sent to browser
DEBUG - 2023-06-28 10:37:00 --> Total execution time: 0.0609
ERROR - 2023-06-28 10:38:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:38:08 --> Config Class Initialized
INFO - 2023-06-28 10:38:08 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:38:08 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:38:08 --> Utf8 Class Initialized
INFO - 2023-06-28 10:38:08 --> URI Class Initialized
DEBUG - 2023-06-28 10:38:08 --> No URI present. Default controller set.
INFO - 2023-06-28 10:38:08 --> Router Class Initialized
INFO - 2023-06-28 10:38:08 --> Output Class Initialized
INFO - 2023-06-28 10:38:08 --> Security Class Initialized
DEBUG - 2023-06-28 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:38:08 --> Input Class Initialized
INFO - 2023-06-28 10:38:08 --> Language Class Initialized
INFO - 2023-06-28 10:38:08 --> Loader Class Initialized
INFO - 2023-06-28 10:38:08 --> Helper loaded: url_helper
INFO - 2023-06-28 10:38:08 --> Helper loaded: file_helper
INFO - 2023-06-28 10:38:08 --> Helper loaded: html_helper
INFO - 2023-06-28 10:38:08 --> Helper loaded: text_helper
INFO - 2023-06-28 10:38:08 --> Helper loaded: form_helper
INFO - 2023-06-28 10:38:08 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:38:08 --> Helper loaded: security_helper
INFO - 2023-06-28 10:38:08 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:38:08 --> Database Driver Class Initialized
INFO - 2023-06-28 10:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:38:08 --> Parser Class Initialized
INFO - 2023-06-28 10:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:38:08 --> Pagination Class Initialized
INFO - 2023-06-28 10:38:08 --> Form Validation Class Initialized
INFO - 2023-06-28 10:38:08 --> Controller Class Initialized
INFO - 2023-06-28 10:38:08 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:08 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:08 --> Model Class Initialized
INFO - 2023-06-28 10:38:08 --> Model Class Initialized
INFO - 2023-06-28 10:38:08 --> Model Class Initialized
INFO - 2023-06-28 10:38:08 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:08 --> Model Class Initialized
INFO - 2023-06-28 10:38:08 --> Model Class Initialized
INFO - 2023-06-28 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:38:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:38:08 --> Model Class Initialized
INFO - 2023-06-28 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:38:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:38:08 --> Final output sent to browser
DEBUG - 2023-06-28 10:38:08 --> Total execution time: 0.0755
ERROR - 2023-06-28 10:38:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:38:36 --> Config Class Initialized
INFO - 2023-06-28 10:38:36 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:38:36 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:38:36 --> Utf8 Class Initialized
INFO - 2023-06-28 10:38:36 --> URI Class Initialized
DEBUG - 2023-06-28 10:38:36 --> No URI present. Default controller set.
INFO - 2023-06-28 10:38:36 --> Router Class Initialized
INFO - 2023-06-28 10:38:36 --> Output Class Initialized
INFO - 2023-06-28 10:38:36 --> Security Class Initialized
DEBUG - 2023-06-28 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:38:36 --> Input Class Initialized
INFO - 2023-06-28 10:38:36 --> Language Class Initialized
INFO - 2023-06-28 10:38:36 --> Loader Class Initialized
INFO - 2023-06-28 10:38:36 --> Helper loaded: url_helper
INFO - 2023-06-28 10:38:36 --> Helper loaded: file_helper
INFO - 2023-06-28 10:38:36 --> Helper loaded: html_helper
INFO - 2023-06-28 10:38:36 --> Helper loaded: text_helper
INFO - 2023-06-28 10:38:36 --> Helper loaded: form_helper
INFO - 2023-06-28 10:38:36 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:38:36 --> Helper loaded: security_helper
INFO - 2023-06-28 10:38:36 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:38:36 --> Database Driver Class Initialized
INFO - 2023-06-28 10:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:38:36 --> Parser Class Initialized
INFO - 2023-06-28 10:38:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:38:36 --> Pagination Class Initialized
INFO - 2023-06-28 10:38:36 --> Form Validation Class Initialized
INFO - 2023-06-28 10:38:36 --> Controller Class Initialized
INFO - 2023-06-28 10:38:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:36 --> Model Class Initialized
INFO - 2023-06-28 10:38:36 --> Model Class Initialized
INFO - 2023-06-28 10:38:36 --> Model Class Initialized
INFO - 2023-06-28 10:38:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:36 --> Model Class Initialized
INFO - 2023-06-28 10:38:36 --> Model Class Initialized
INFO - 2023-06-28 10:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:38:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:38:36 --> Model Class Initialized
INFO - 2023-06-28 10:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:38:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:38:36 --> Final output sent to browser
DEBUG - 2023-06-28 10:38:36 --> Total execution time: 0.0646
ERROR - 2023-06-28 10:38:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:38:58 --> Config Class Initialized
INFO - 2023-06-28 10:38:58 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:38:58 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:38:58 --> Utf8 Class Initialized
INFO - 2023-06-28 10:38:58 --> URI Class Initialized
INFO - 2023-06-28 10:38:58 --> Router Class Initialized
INFO - 2023-06-28 10:38:58 --> Output Class Initialized
INFO - 2023-06-28 10:38:58 --> Security Class Initialized
DEBUG - 2023-06-28 10:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:38:58 --> Input Class Initialized
INFO - 2023-06-28 10:38:58 --> Language Class Initialized
INFO - 2023-06-28 10:38:58 --> Loader Class Initialized
INFO - 2023-06-28 10:38:58 --> Helper loaded: url_helper
INFO - 2023-06-28 10:38:58 --> Helper loaded: file_helper
INFO - 2023-06-28 10:38:58 --> Helper loaded: html_helper
INFO - 2023-06-28 10:38:58 --> Helper loaded: text_helper
INFO - 2023-06-28 10:38:58 --> Helper loaded: form_helper
INFO - 2023-06-28 10:38:58 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:38:58 --> Helper loaded: security_helper
INFO - 2023-06-28 10:38:58 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:38:58 --> Database Driver Class Initialized
INFO - 2023-06-28 10:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:38:58 --> Parser Class Initialized
INFO - 2023-06-28 10:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:38:58 --> Pagination Class Initialized
INFO - 2023-06-28 10:38:58 --> Form Validation Class Initialized
INFO - 2023-06-28 10:38:58 --> Controller Class Initialized
INFO - 2023-06-28 10:38:58 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:58 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:58 --> Model Class Initialized
INFO - 2023-06-28 10:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:38:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:38:58 --> Model Class Initialized
INFO - 2023-06-28 10:38:58 --> Model Class Initialized
INFO - 2023-06-28 10:38:58 --> Model Class Initialized
INFO - 2023-06-28 10:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:38:58 --> Final output sent to browser
DEBUG - 2023-06-28 10:38:58 --> Total execution time: 0.0644
ERROR - 2023-06-28 10:38:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:38:59 --> Config Class Initialized
INFO - 2023-06-28 10:38:59 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:38:59 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:38:59 --> Utf8 Class Initialized
INFO - 2023-06-28 10:38:59 --> URI Class Initialized
INFO - 2023-06-28 10:38:59 --> Router Class Initialized
INFO - 2023-06-28 10:38:59 --> Output Class Initialized
INFO - 2023-06-28 10:38:59 --> Security Class Initialized
DEBUG - 2023-06-28 10:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:38:59 --> Input Class Initialized
INFO - 2023-06-28 10:38:59 --> Language Class Initialized
INFO - 2023-06-28 10:38:59 --> Loader Class Initialized
INFO - 2023-06-28 10:38:59 --> Helper loaded: url_helper
INFO - 2023-06-28 10:38:59 --> Helper loaded: file_helper
INFO - 2023-06-28 10:38:59 --> Helper loaded: html_helper
INFO - 2023-06-28 10:38:59 --> Helper loaded: text_helper
INFO - 2023-06-28 10:38:59 --> Helper loaded: form_helper
INFO - 2023-06-28 10:38:59 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:38:59 --> Helper loaded: security_helper
INFO - 2023-06-28 10:38:59 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:38:59 --> Database Driver Class Initialized
INFO - 2023-06-28 10:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:38:59 --> Parser Class Initialized
INFO - 2023-06-28 10:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:38:59 --> Pagination Class Initialized
INFO - 2023-06-28 10:38:59 --> Form Validation Class Initialized
INFO - 2023-06-28 10:38:59 --> Controller Class Initialized
INFO - 2023-06-28 10:38:59 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:59 --> Model Class Initialized
DEBUG - 2023-06-28 10:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:38:59 --> Model Class Initialized
INFO - 2023-06-28 10:38:59 --> Final output sent to browser
DEBUG - 2023-06-28 10:38:59 --> Total execution time: 0.0250
ERROR - 2023-06-28 10:39:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:39:05 --> Config Class Initialized
INFO - 2023-06-28 10:39:05 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:39:05 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:39:05 --> Utf8 Class Initialized
INFO - 2023-06-28 10:39:05 --> URI Class Initialized
INFO - 2023-06-28 10:39:05 --> Router Class Initialized
INFO - 2023-06-28 10:39:05 --> Output Class Initialized
INFO - 2023-06-28 10:39:05 --> Security Class Initialized
DEBUG - 2023-06-28 10:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:39:05 --> Input Class Initialized
INFO - 2023-06-28 10:39:05 --> Language Class Initialized
INFO - 2023-06-28 10:39:05 --> Loader Class Initialized
INFO - 2023-06-28 10:39:05 --> Helper loaded: url_helper
INFO - 2023-06-28 10:39:05 --> Helper loaded: file_helper
INFO - 2023-06-28 10:39:05 --> Helper loaded: html_helper
INFO - 2023-06-28 10:39:05 --> Helper loaded: text_helper
INFO - 2023-06-28 10:39:05 --> Helper loaded: form_helper
INFO - 2023-06-28 10:39:05 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:39:05 --> Helper loaded: security_helper
INFO - 2023-06-28 10:39:05 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:39:05 --> Database Driver Class Initialized
INFO - 2023-06-28 10:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:39:05 --> Parser Class Initialized
INFO - 2023-06-28 10:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:39:05 --> Pagination Class Initialized
INFO - 2023-06-28 10:39:05 --> Form Validation Class Initialized
INFO - 2023-06-28 10:39:05 --> Controller Class Initialized
INFO - 2023-06-28 10:39:05 --> Model Class Initialized
DEBUG - 2023-06-28 10:39:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:39:05 --> Model Class Initialized
DEBUG - 2023-06-28 10:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:39:05 --> Model Class Initialized
DEBUG - 2023-06-28 10:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-28 10:39:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:39:05 --> Model Class Initialized
INFO - 2023-06-28 10:39:05 --> Model Class Initialized
INFO - 2023-06-28 10:39:05 --> Model Class Initialized
INFO - 2023-06-28 10:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:39:05 --> Final output sent to browser
DEBUG - 2023-06-28 10:39:05 --> Total execution time: 0.0756
ERROR - 2023-06-28 10:46:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:46:22 --> Config Class Initialized
INFO - 2023-06-28 10:46:22 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:46:22 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:46:22 --> Utf8 Class Initialized
INFO - 2023-06-28 10:46:22 --> URI Class Initialized
DEBUG - 2023-06-28 10:46:22 --> No URI present. Default controller set.
INFO - 2023-06-28 10:46:22 --> Router Class Initialized
INFO - 2023-06-28 10:46:22 --> Output Class Initialized
INFO - 2023-06-28 10:46:22 --> Security Class Initialized
DEBUG - 2023-06-28 10:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:46:22 --> Input Class Initialized
INFO - 2023-06-28 10:46:22 --> Language Class Initialized
INFO - 2023-06-28 10:46:22 --> Loader Class Initialized
INFO - 2023-06-28 10:46:22 --> Helper loaded: url_helper
INFO - 2023-06-28 10:46:22 --> Helper loaded: file_helper
INFO - 2023-06-28 10:46:22 --> Helper loaded: html_helper
INFO - 2023-06-28 10:46:22 --> Helper loaded: text_helper
INFO - 2023-06-28 10:46:22 --> Helper loaded: form_helper
INFO - 2023-06-28 10:46:22 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:46:22 --> Helper loaded: security_helper
INFO - 2023-06-28 10:46:22 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:46:22 --> Database Driver Class Initialized
INFO - 2023-06-28 10:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:46:22 --> Parser Class Initialized
INFO - 2023-06-28 10:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:46:22 --> Pagination Class Initialized
INFO - 2023-06-28 10:46:22 --> Form Validation Class Initialized
INFO - 2023-06-28 10:46:22 --> Controller Class Initialized
INFO - 2023-06-28 10:46:22 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:22 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:22 --> Model Class Initialized
INFO - 2023-06-28 10:46:22 --> Model Class Initialized
INFO - 2023-06-28 10:46:22 --> Model Class Initialized
INFO - 2023-06-28 10:46:22 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:22 --> Model Class Initialized
INFO - 2023-06-28 10:46:22 --> Model Class Initialized
INFO - 2023-06-28 10:46:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:46:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:46:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:46:23 --> Model Class Initialized
INFO - 2023-06-28 10:46:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:46:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:46:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:46:23 --> Final output sent to browser
DEBUG - 2023-06-28 10:46:23 --> Total execution time: 0.0704
ERROR - 2023-06-28 10:46:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:46:36 --> Config Class Initialized
INFO - 2023-06-28 10:46:36 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:46:36 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:46:36 --> Utf8 Class Initialized
INFO - 2023-06-28 10:46:36 --> URI Class Initialized
DEBUG - 2023-06-28 10:46:36 --> No URI present. Default controller set.
INFO - 2023-06-28 10:46:36 --> Router Class Initialized
INFO - 2023-06-28 10:46:36 --> Output Class Initialized
INFO - 2023-06-28 10:46:36 --> Security Class Initialized
DEBUG - 2023-06-28 10:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:46:36 --> Input Class Initialized
INFO - 2023-06-28 10:46:36 --> Language Class Initialized
INFO - 2023-06-28 10:46:36 --> Loader Class Initialized
INFO - 2023-06-28 10:46:36 --> Helper loaded: url_helper
INFO - 2023-06-28 10:46:36 --> Helper loaded: file_helper
INFO - 2023-06-28 10:46:36 --> Helper loaded: html_helper
INFO - 2023-06-28 10:46:36 --> Helper loaded: text_helper
INFO - 2023-06-28 10:46:36 --> Helper loaded: form_helper
INFO - 2023-06-28 10:46:36 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:46:36 --> Helper loaded: security_helper
INFO - 2023-06-28 10:46:36 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:46:36 --> Database Driver Class Initialized
INFO - 2023-06-28 10:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:46:36 --> Parser Class Initialized
INFO - 2023-06-28 10:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:46:36 --> Pagination Class Initialized
INFO - 2023-06-28 10:46:36 --> Form Validation Class Initialized
INFO - 2023-06-28 10:46:36 --> Controller Class Initialized
INFO - 2023-06-28 10:46:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:36 --> Model Class Initialized
INFO - 2023-06-28 10:46:36 --> Model Class Initialized
INFO - 2023-06-28 10:46:36 --> Model Class Initialized
INFO - 2023-06-28 10:46:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:36 --> Model Class Initialized
INFO - 2023-06-28 10:46:36 --> Model Class Initialized
INFO - 2023-06-28 10:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:46:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:46:36 --> Model Class Initialized
INFO - 2023-06-28 10:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:46:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:46:36 --> Final output sent to browser
DEBUG - 2023-06-28 10:46:36 --> Total execution time: 0.0680
ERROR - 2023-06-28 10:46:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:46:55 --> Config Class Initialized
INFO - 2023-06-28 10:46:55 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:46:55 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:46:55 --> Utf8 Class Initialized
INFO - 2023-06-28 10:46:55 --> URI Class Initialized
INFO - 2023-06-28 10:46:55 --> Router Class Initialized
INFO - 2023-06-28 10:46:55 --> Output Class Initialized
INFO - 2023-06-28 10:46:55 --> Security Class Initialized
DEBUG - 2023-06-28 10:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:46:55 --> Input Class Initialized
INFO - 2023-06-28 10:46:55 --> Language Class Initialized
INFO - 2023-06-28 10:46:55 --> Loader Class Initialized
INFO - 2023-06-28 10:46:55 --> Helper loaded: url_helper
INFO - 2023-06-28 10:46:55 --> Helper loaded: file_helper
INFO - 2023-06-28 10:46:55 --> Helper loaded: html_helper
INFO - 2023-06-28 10:46:55 --> Helper loaded: text_helper
INFO - 2023-06-28 10:46:55 --> Helper loaded: form_helper
INFO - 2023-06-28 10:46:55 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:46:55 --> Helper loaded: security_helper
INFO - 2023-06-28 10:46:55 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:46:55 --> Database Driver Class Initialized
INFO - 2023-06-28 10:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:46:55 --> Parser Class Initialized
INFO - 2023-06-28 10:46:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:46:55 --> Pagination Class Initialized
INFO - 2023-06-28 10:46:55 --> Form Validation Class Initialized
INFO - 2023-06-28 10:46:55 --> Controller Class Initialized
INFO - 2023-06-28 10:46:55 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:46:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:55 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:55 --> Model Class Initialized
INFO - 2023-06-28 10:46:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-28 10:46:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:46:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:46:55 --> Model Class Initialized
INFO - 2023-06-28 10:46:55 --> Model Class Initialized
INFO - 2023-06-28 10:46:55 --> Model Class Initialized
INFO - 2023-06-28 10:46:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:46:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:46:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:46:55 --> Final output sent to browser
DEBUG - 2023-06-28 10:46:55 --> Total execution time: 0.0720
ERROR - 2023-06-28 10:46:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:46:56 --> Config Class Initialized
INFO - 2023-06-28 10:46:56 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:46:56 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:46:56 --> Utf8 Class Initialized
INFO - 2023-06-28 10:46:56 --> URI Class Initialized
INFO - 2023-06-28 10:46:56 --> Router Class Initialized
INFO - 2023-06-28 10:46:56 --> Output Class Initialized
INFO - 2023-06-28 10:46:56 --> Security Class Initialized
DEBUG - 2023-06-28 10:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:46:56 --> Input Class Initialized
INFO - 2023-06-28 10:46:56 --> Language Class Initialized
INFO - 2023-06-28 10:46:56 --> Loader Class Initialized
INFO - 2023-06-28 10:46:56 --> Helper loaded: url_helper
INFO - 2023-06-28 10:46:56 --> Helper loaded: file_helper
INFO - 2023-06-28 10:46:56 --> Helper loaded: html_helper
INFO - 2023-06-28 10:46:56 --> Helper loaded: text_helper
INFO - 2023-06-28 10:46:56 --> Helper loaded: form_helper
INFO - 2023-06-28 10:46:56 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:46:56 --> Helper loaded: security_helper
INFO - 2023-06-28 10:46:56 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:46:56 --> Database Driver Class Initialized
INFO - 2023-06-28 10:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:46:56 --> Parser Class Initialized
INFO - 2023-06-28 10:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:46:56 --> Pagination Class Initialized
INFO - 2023-06-28 10:46:56 --> Form Validation Class Initialized
INFO - 2023-06-28 10:46:56 --> Controller Class Initialized
INFO - 2023-06-28 10:46:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:56 --> Model Class Initialized
DEBUG - 2023-06-28 10:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:46:56 --> Model Class Initialized
INFO - 2023-06-28 10:46:56 --> Final output sent to browser
DEBUG - 2023-06-28 10:46:56 --> Total execution time: 0.0202
ERROR - 2023-06-28 10:47:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:47:09 --> Config Class Initialized
INFO - 2023-06-28 10:47:09 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:47:09 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:47:09 --> Utf8 Class Initialized
INFO - 2023-06-28 10:47:09 --> URI Class Initialized
INFO - 2023-06-28 10:47:09 --> Router Class Initialized
INFO - 2023-06-28 10:47:09 --> Output Class Initialized
INFO - 2023-06-28 10:47:09 --> Security Class Initialized
DEBUG - 2023-06-28 10:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:47:09 --> Input Class Initialized
INFO - 2023-06-28 10:47:09 --> Language Class Initialized
INFO - 2023-06-28 10:47:09 --> Loader Class Initialized
INFO - 2023-06-28 10:47:09 --> Helper loaded: url_helper
INFO - 2023-06-28 10:47:09 --> Helper loaded: file_helper
INFO - 2023-06-28 10:47:09 --> Helper loaded: html_helper
INFO - 2023-06-28 10:47:09 --> Helper loaded: text_helper
INFO - 2023-06-28 10:47:09 --> Helper loaded: form_helper
INFO - 2023-06-28 10:47:09 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:47:09 --> Helper loaded: security_helper
INFO - 2023-06-28 10:47:09 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:47:09 --> Database Driver Class Initialized
INFO - 2023-06-28 10:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:47:09 --> Parser Class Initialized
INFO - 2023-06-28 10:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:47:09 --> Pagination Class Initialized
INFO - 2023-06-28 10:47:09 --> Form Validation Class Initialized
INFO - 2023-06-28 10:47:09 --> Controller Class Initialized
INFO - 2023-06-28 10:47:09 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:47:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:09 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:09 --> Model Class Initialized
INFO - 2023-06-28 10:47:09 --> Final output sent to browser
DEBUG - 2023-06-28 10:47:09 --> Total execution time: 0.0232
ERROR - 2023-06-28 10:47:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:47:30 --> Config Class Initialized
INFO - 2023-06-28 10:47:30 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:47:30 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:47:30 --> Utf8 Class Initialized
INFO - 2023-06-28 10:47:30 --> URI Class Initialized
DEBUG - 2023-06-28 10:47:30 --> No URI present. Default controller set.
INFO - 2023-06-28 10:47:30 --> Router Class Initialized
INFO - 2023-06-28 10:47:30 --> Output Class Initialized
INFO - 2023-06-28 10:47:30 --> Security Class Initialized
DEBUG - 2023-06-28 10:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:47:30 --> Input Class Initialized
INFO - 2023-06-28 10:47:30 --> Language Class Initialized
INFO - 2023-06-28 10:47:30 --> Loader Class Initialized
INFO - 2023-06-28 10:47:30 --> Helper loaded: url_helper
INFO - 2023-06-28 10:47:30 --> Helper loaded: file_helper
INFO - 2023-06-28 10:47:30 --> Helper loaded: html_helper
INFO - 2023-06-28 10:47:30 --> Helper loaded: text_helper
INFO - 2023-06-28 10:47:30 --> Helper loaded: form_helper
INFO - 2023-06-28 10:47:30 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:47:30 --> Helper loaded: security_helper
INFO - 2023-06-28 10:47:30 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:47:30 --> Database Driver Class Initialized
INFO - 2023-06-28 10:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:47:30 --> Parser Class Initialized
INFO - 2023-06-28 10:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:47:30 --> Pagination Class Initialized
INFO - 2023-06-28 10:47:30 --> Form Validation Class Initialized
INFO - 2023-06-28 10:47:30 --> Controller Class Initialized
INFO - 2023-06-28 10:47:30 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:30 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:30 --> Model Class Initialized
INFO - 2023-06-28 10:47:30 --> Model Class Initialized
INFO - 2023-06-28 10:47:30 --> Model Class Initialized
INFO - 2023-06-28 10:47:30 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:30 --> Model Class Initialized
INFO - 2023-06-28 10:47:30 --> Model Class Initialized
INFO - 2023-06-28 10:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:47:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:47:30 --> Model Class Initialized
INFO - 2023-06-28 10:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:47:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:47:30 --> Final output sent to browser
DEBUG - 2023-06-28 10:47:30 --> Total execution time: 0.0696
ERROR - 2023-06-28 10:47:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:47:36 --> Config Class Initialized
INFO - 2023-06-28 10:47:36 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:47:36 --> Utf8 Class Initialized
INFO - 2023-06-28 10:47:36 --> URI Class Initialized
DEBUG - 2023-06-28 10:47:36 --> No URI present. Default controller set.
INFO - 2023-06-28 10:47:36 --> Router Class Initialized
INFO - 2023-06-28 10:47:36 --> Output Class Initialized
INFO - 2023-06-28 10:47:36 --> Security Class Initialized
DEBUG - 2023-06-28 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:47:36 --> Input Class Initialized
INFO - 2023-06-28 10:47:36 --> Language Class Initialized
INFO - 2023-06-28 10:47:36 --> Loader Class Initialized
INFO - 2023-06-28 10:47:36 --> Helper loaded: url_helper
INFO - 2023-06-28 10:47:36 --> Helper loaded: file_helper
INFO - 2023-06-28 10:47:36 --> Helper loaded: html_helper
INFO - 2023-06-28 10:47:36 --> Helper loaded: text_helper
INFO - 2023-06-28 10:47:36 --> Helper loaded: form_helper
INFO - 2023-06-28 10:47:36 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:47:36 --> Helper loaded: security_helper
INFO - 2023-06-28 10:47:36 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:47:36 --> Database Driver Class Initialized
INFO - 2023-06-28 10:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:47:36 --> Parser Class Initialized
INFO - 2023-06-28 10:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:47:36 --> Pagination Class Initialized
INFO - 2023-06-28 10:47:36 --> Form Validation Class Initialized
INFO - 2023-06-28 10:47:36 --> Controller Class Initialized
INFO - 2023-06-28 10:47:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:36 --> Model Class Initialized
INFO - 2023-06-28 10:47:36 --> Model Class Initialized
INFO - 2023-06-28 10:47:36 --> Model Class Initialized
INFO - 2023-06-28 10:47:36 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:36 --> Model Class Initialized
INFO - 2023-06-28 10:47:36 --> Model Class Initialized
INFO - 2023-06-28 10:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:47:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:47:36 --> Model Class Initialized
INFO - 2023-06-28 10:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:47:36 --> Final output sent to browser
DEBUG - 2023-06-28 10:47:36 --> Total execution time: 0.0630
ERROR - 2023-06-28 10:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:47:44 --> Config Class Initialized
INFO - 2023-06-28 10:47:44 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:47:44 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:47:44 --> Utf8 Class Initialized
INFO - 2023-06-28 10:47:44 --> URI Class Initialized
INFO - 2023-06-28 10:47:44 --> Router Class Initialized
INFO - 2023-06-28 10:47:44 --> Output Class Initialized
INFO - 2023-06-28 10:47:44 --> Security Class Initialized
DEBUG - 2023-06-28 10:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:47:44 --> Input Class Initialized
INFO - 2023-06-28 10:47:44 --> Language Class Initialized
INFO - 2023-06-28 10:47:44 --> Loader Class Initialized
INFO - 2023-06-28 10:47:44 --> Helper loaded: url_helper
INFO - 2023-06-28 10:47:44 --> Helper loaded: file_helper
INFO - 2023-06-28 10:47:44 --> Helper loaded: html_helper
INFO - 2023-06-28 10:47:44 --> Helper loaded: text_helper
INFO - 2023-06-28 10:47:44 --> Helper loaded: form_helper
INFO - 2023-06-28 10:47:44 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:47:44 --> Helper loaded: security_helper
INFO - 2023-06-28 10:47:44 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:47:44 --> Database Driver Class Initialized
INFO - 2023-06-28 10:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:47:44 --> Parser Class Initialized
INFO - 2023-06-28 10:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:47:44 --> Pagination Class Initialized
INFO - 2023-06-28 10:47:44 --> Form Validation Class Initialized
INFO - 2023-06-28 10:47:44 --> Controller Class Initialized
INFO - 2023-06-28 10:47:44 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:44 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:44 --> Model Class Initialized
INFO - 2023-06-28 10:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-28 10:47:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:47:44 --> Model Class Initialized
INFO - 2023-06-28 10:47:44 --> Model Class Initialized
INFO - 2023-06-28 10:47:44 --> Model Class Initialized
INFO - 2023-06-28 10:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:47:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:47:44 --> Final output sent to browser
DEBUG - 2023-06-28 10:47:44 --> Total execution time: 0.0615
ERROR - 2023-06-28 10:47:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:47:45 --> Config Class Initialized
INFO - 2023-06-28 10:47:45 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:47:45 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:47:45 --> Utf8 Class Initialized
INFO - 2023-06-28 10:47:45 --> URI Class Initialized
INFO - 2023-06-28 10:47:45 --> Router Class Initialized
INFO - 2023-06-28 10:47:45 --> Output Class Initialized
INFO - 2023-06-28 10:47:45 --> Security Class Initialized
DEBUG - 2023-06-28 10:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:47:45 --> Input Class Initialized
INFO - 2023-06-28 10:47:45 --> Language Class Initialized
INFO - 2023-06-28 10:47:45 --> Loader Class Initialized
INFO - 2023-06-28 10:47:45 --> Helper loaded: url_helper
INFO - 2023-06-28 10:47:45 --> Helper loaded: file_helper
INFO - 2023-06-28 10:47:45 --> Helper loaded: html_helper
INFO - 2023-06-28 10:47:45 --> Helper loaded: text_helper
INFO - 2023-06-28 10:47:45 --> Helper loaded: form_helper
INFO - 2023-06-28 10:47:45 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:47:45 --> Helper loaded: security_helper
INFO - 2023-06-28 10:47:45 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:47:45 --> Database Driver Class Initialized
INFO - 2023-06-28 10:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:47:45 --> Parser Class Initialized
INFO - 2023-06-28 10:47:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:47:45 --> Pagination Class Initialized
INFO - 2023-06-28 10:47:45 --> Form Validation Class Initialized
INFO - 2023-06-28 10:47:45 --> Controller Class Initialized
INFO - 2023-06-28 10:47:45 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:45 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:45 --> Model Class Initialized
INFO - 2023-06-28 10:47:45 --> Final output sent to browser
DEBUG - 2023-06-28 10:47:45 --> Total execution time: 0.0229
ERROR - 2023-06-28 10:47:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:47:54 --> Config Class Initialized
INFO - 2023-06-28 10:47:54 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:47:54 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:47:54 --> Utf8 Class Initialized
INFO - 2023-06-28 10:47:54 --> URI Class Initialized
INFO - 2023-06-28 10:47:54 --> Router Class Initialized
INFO - 2023-06-28 10:47:54 --> Output Class Initialized
INFO - 2023-06-28 10:47:54 --> Security Class Initialized
DEBUG - 2023-06-28 10:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:47:54 --> Input Class Initialized
INFO - 2023-06-28 10:47:54 --> Language Class Initialized
INFO - 2023-06-28 10:47:54 --> Loader Class Initialized
INFO - 2023-06-28 10:47:54 --> Helper loaded: url_helper
INFO - 2023-06-28 10:47:54 --> Helper loaded: file_helper
INFO - 2023-06-28 10:47:54 --> Helper loaded: html_helper
INFO - 2023-06-28 10:47:54 --> Helper loaded: text_helper
INFO - 2023-06-28 10:47:54 --> Helper loaded: form_helper
INFO - 2023-06-28 10:47:54 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:47:54 --> Helper loaded: security_helper
INFO - 2023-06-28 10:47:54 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:47:54 --> Database Driver Class Initialized
INFO - 2023-06-28 10:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:47:54 --> Parser Class Initialized
INFO - 2023-06-28 10:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:47:54 --> Pagination Class Initialized
INFO - 2023-06-28 10:47:54 --> Form Validation Class Initialized
INFO - 2023-06-28 10:47:54 --> Controller Class Initialized
INFO - 2023-06-28 10:47:54 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:54 --> Model Class Initialized
DEBUG - 2023-06-28 10:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:47:54 --> Model Class Initialized
INFO - 2023-06-28 10:47:54 --> Final output sent to browser
DEBUG - 2023-06-28 10:47:54 --> Total execution time: 0.0212
ERROR - 2023-06-28 10:48:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:48:26 --> Config Class Initialized
INFO - 2023-06-28 10:48:26 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:48:26 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:48:26 --> Utf8 Class Initialized
INFO - 2023-06-28 10:48:26 --> URI Class Initialized
INFO - 2023-06-28 10:48:26 --> Router Class Initialized
INFO - 2023-06-28 10:48:26 --> Output Class Initialized
INFO - 2023-06-28 10:48:26 --> Security Class Initialized
DEBUG - 2023-06-28 10:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:48:26 --> Input Class Initialized
INFO - 2023-06-28 10:48:26 --> Language Class Initialized
INFO - 2023-06-28 10:48:26 --> Loader Class Initialized
INFO - 2023-06-28 10:48:26 --> Helper loaded: url_helper
INFO - 2023-06-28 10:48:26 --> Helper loaded: file_helper
INFO - 2023-06-28 10:48:26 --> Helper loaded: html_helper
INFO - 2023-06-28 10:48:26 --> Helper loaded: text_helper
INFO - 2023-06-28 10:48:26 --> Helper loaded: form_helper
INFO - 2023-06-28 10:48:26 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:48:26 --> Helper loaded: security_helper
INFO - 2023-06-28 10:48:26 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:48:26 --> Database Driver Class Initialized
INFO - 2023-06-28 10:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:48:26 --> Parser Class Initialized
INFO - 2023-06-28 10:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:48:26 --> Pagination Class Initialized
INFO - 2023-06-28 10:48:26 --> Form Validation Class Initialized
INFO - 2023-06-28 10:48:26 --> Controller Class Initialized
INFO - 2023-06-28 10:48:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:26 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:26 --> Model Class Initialized
INFO - 2023-06-28 10:48:26 --> Final output sent to browser
DEBUG - 2023-06-28 10:48:26 --> Total execution time: 0.0228
ERROR - 2023-06-28 10:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:48:27 --> Config Class Initialized
INFO - 2023-06-28 10:48:27 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:48:27 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:48:27 --> Utf8 Class Initialized
INFO - 2023-06-28 10:48:27 --> URI Class Initialized
INFO - 2023-06-28 10:48:27 --> Router Class Initialized
INFO - 2023-06-28 10:48:27 --> Output Class Initialized
INFO - 2023-06-28 10:48:27 --> Security Class Initialized
DEBUG - 2023-06-28 10:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:48:27 --> Input Class Initialized
INFO - 2023-06-28 10:48:27 --> Language Class Initialized
INFO - 2023-06-28 10:48:27 --> Loader Class Initialized
INFO - 2023-06-28 10:48:27 --> Helper loaded: url_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: file_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: html_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: text_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: form_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: security_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:48:27 --> Database Driver Class Initialized
INFO - 2023-06-28 10:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:48:27 --> Parser Class Initialized
INFO - 2023-06-28 10:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:48:27 --> Pagination Class Initialized
INFO - 2023-06-28 10:48:27 --> Form Validation Class Initialized
INFO - 2023-06-28 10:48:27 --> Controller Class Initialized
INFO - 2023-06-28 10:48:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:27 --> Model Class Initialized
INFO - 2023-06-28 10:48:27 --> Final output sent to browser
DEBUG - 2023-06-28 10:48:27 --> Total execution time: 0.0192
ERROR - 2023-06-28 10:48:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:48:27 --> Config Class Initialized
INFO - 2023-06-28 10:48:27 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:48:27 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:48:27 --> Utf8 Class Initialized
INFO - 2023-06-28 10:48:27 --> URI Class Initialized
INFO - 2023-06-28 10:48:27 --> Router Class Initialized
INFO - 2023-06-28 10:48:27 --> Output Class Initialized
INFO - 2023-06-28 10:48:27 --> Security Class Initialized
DEBUG - 2023-06-28 10:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:48:27 --> Input Class Initialized
INFO - 2023-06-28 10:48:27 --> Language Class Initialized
INFO - 2023-06-28 10:48:27 --> Loader Class Initialized
INFO - 2023-06-28 10:48:27 --> Helper loaded: url_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: file_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: html_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: text_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: form_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: security_helper
INFO - 2023-06-28 10:48:27 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:48:27 --> Database Driver Class Initialized
INFO - 2023-06-28 10:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:48:27 --> Parser Class Initialized
INFO - 2023-06-28 10:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:48:27 --> Pagination Class Initialized
INFO - 2023-06-28 10:48:27 --> Form Validation Class Initialized
INFO - 2023-06-28 10:48:27 --> Controller Class Initialized
INFO - 2023-06-28 10:48:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:27 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:27 --> Model Class Initialized
INFO - 2023-06-28 10:48:27 --> Final output sent to browser
DEBUG - 2023-06-28 10:48:27 --> Total execution time: 0.0203
ERROR - 2023-06-28 10:48:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:48:29 --> Config Class Initialized
INFO - 2023-06-28 10:48:29 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:48:29 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:48:29 --> Utf8 Class Initialized
INFO - 2023-06-28 10:48:29 --> URI Class Initialized
INFO - 2023-06-28 10:48:29 --> Router Class Initialized
INFO - 2023-06-28 10:48:29 --> Output Class Initialized
INFO - 2023-06-28 10:48:29 --> Security Class Initialized
DEBUG - 2023-06-28 10:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:48:29 --> Input Class Initialized
INFO - 2023-06-28 10:48:29 --> Language Class Initialized
INFO - 2023-06-28 10:48:29 --> Loader Class Initialized
INFO - 2023-06-28 10:48:29 --> Helper loaded: url_helper
INFO - 2023-06-28 10:48:29 --> Helper loaded: file_helper
INFO - 2023-06-28 10:48:29 --> Helper loaded: html_helper
INFO - 2023-06-28 10:48:29 --> Helper loaded: text_helper
INFO - 2023-06-28 10:48:29 --> Helper loaded: form_helper
INFO - 2023-06-28 10:48:29 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:48:29 --> Helper loaded: security_helper
INFO - 2023-06-28 10:48:29 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:48:29 --> Database Driver Class Initialized
INFO - 2023-06-28 10:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:48:29 --> Parser Class Initialized
INFO - 2023-06-28 10:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:48:29 --> Pagination Class Initialized
INFO - 2023-06-28 10:48:29 --> Form Validation Class Initialized
INFO - 2023-06-28 10:48:29 --> Controller Class Initialized
INFO - 2023-06-28 10:48:29 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:29 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:29 --> Model Class Initialized
INFO - 2023-06-28 10:48:29 --> Final output sent to browser
DEBUG - 2023-06-28 10:48:29 --> Total execution time: 0.0198
ERROR - 2023-06-28 10:48:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:48:34 --> Config Class Initialized
INFO - 2023-06-28 10:48:34 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:48:34 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:48:34 --> Utf8 Class Initialized
INFO - 2023-06-28 10:48:34 --> URI Class Initialized
INFO - 2023-06-28 10:48:34 --> Router Class Initialized
INFO - 2023-06-28 10:48:34 --> Output Class Initialized
INFO - 2023-06-28 10:48:34 --> Security Class Initialized
DEBUG - 2023-06-28 10:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:48:34 --> Input Class Initialized
INFO - 2023-06-28 10:48:34 --> Language Class Initialized
INFO - 2023-06-28 10:48:34 --> Loader Class Initialized
INFO - 2023-06-28 10:48:34 --> Helper loaded: url_helper
INFO - 2023-06-28 10:48:34 --> Helper loaded: file_helper
INFO - 2023-06-28 10:48:34 --> Helper loaded: html_helper
INFO - 2023-06-28 10:48:34 --> Helper loaded: text_helper
INFO - 2023-06-28 10:48:34 --> Helper loaded: form_helper
INFO - 2023-06-28 10:48:34 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:48:34 --> Helper loaded: security_helper
INFO - 2023-06-28 10:48:34 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:48:34 --> Database Driver Class Initialized
INFO - 2023-06-28 10:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:48:34 --> Parser Class Initialized
INFO - 2023-06-28 10:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:48:34 --> Pagination Class Initialized
INFO - 2023-06-28 10:48:34 --> Form Validation Class Initialized
INFO - 2023-06-28 10:48:34 --> Controller Class Initialized
INFO - 2023-06-28 10:48:34 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:34 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:34 --> Model Class Initialized
INFO - 2023-06-28 10:48:34 --> Final output sent to browser
DEBUG - 2023-06-28 10:48:34 --> Total execution time: 0.0242
ERROR - 2023-06-28 10:48:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:48:44 --> Config Class Initialized
INFO - 2023-06-28 10:48:44 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:48:44 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:48:44 --> Utf8 Class Initialized
INFO - 2023-06-28 10:48:44 --> URI Class Initialized
DEBUG - 2023-06-28 10:48:44 --> No URI present. Default controller set.
INFO - 2023-06-28 10:48:44 --> Router Class Initialized
INFO - 2023-06-28 10:48:44 --> Output Class Initialized
INFO - 2023-06-28 10:48:44 --> Security Class Initialized
DEBUG - 2023-06-28 10:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:48:44 --> Input Class Initialized
INFO - 2023-06-28 10:48:44 --> Language Class Initialized
INFO - 2023-06-28 10:48:44 --> Loader Class Initialized
INFO - 2023-06-28 10:48:44 --> Helper loaded: url_helper
INFO - 2023-06-28 10:48:44 --> Helper loaded: file_helper
INFO - 2023-06-28 10:48:44 --> Helper loaded: html_helper
INFO - 2023-06-28 10:48:44 --> Helper loaded: text_helper
INFO - 2023-06-28 10:48:44 --> Helper loaded: form_helper
INFO - 2023-06-28 10:48:44 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:48:44 --> Helper loaded: security_helper
INFO - 2023-06-28 10:48:44 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:48:44 --> Database Driver Class Initialized
INFO - 2023-06-28 10:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:48:44 --> Parser Class Initialized
INFO - 2023-06-28 10:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:48:44 --> Pagination Class Initialized
INFO - 2023-06-28 10:48:44 --> Form Validation Class Initialized
INFO - 2023-06-28 10:48:44 --> Controller Class Initialized
INFO - 2023-06-28 10:48:44 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:44 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:44 --> Model Class Initialized
INFO - 2023-06-28 10:48:44 --> Model Class Initialized
INFO - 2023-06-28 10:48:44 --> Model Class Initialized
INFO - 2023-06-28 10:48:44 --> Model Class Initialized
DEBUG - 2023-06-28 10:48:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:44 --> Model Class Initialized
INFO - 2023-06-28 10:48:44 --> Model Class Initialized
INFO - 2023-06-28 10:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:48:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:48:44 --> Model Class Initialized
INFO - 2023-06-28 10:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:48:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:48:44 --> Final output sent to browser
DEBUG - 2023-06-28 10:48:44 --> Total execution time: 0.0634
ERROR - 2023-06-28 10:49:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:49:04 --> Config Class Initialized
INFO - 2023-06-28 10:49:04 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:49:04 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:49:04 --> Utf8 Class Initialized
INFO - 2023-06-28 10:49:04 --> URI Class Initialized
INFO - 2023-06-28 10:49:04 --> Router Class Initialized
INFO - 2023-06-28 10:49:04 --> Output Class Initialized
INFO - 2023-06-28 10:49:04 --> Security Class Initialized
DEBUG - 2023-06-28 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:49:04 --> Input Class Initialized
INFO - 2023-06-28 10:49:04 --> Language Class Initialized
INFO - 2023-06-28 10:49:04 --> Loader Class Initialized
INFO - 2023-06-28 10:49:04 --> Helper loaded: url_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: file_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: html_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: text_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: form_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: security_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:49:04 --> Database Driver Class Initialized
INFO - 2023-06-28 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:49:04 --> Parser Class Initialized
INFO - 2023-06-28 10:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:49:04 --> Pagination Class Initialized
INFO - 2023-06-28 10:49:04 --> Form Validation Class Initialized
INFO - 2023-06-28 10:49:04 --> Controller Class Initialized
INFO - 2023-06-28 10:49:04 --> Model Class Initialized
DEBUG - 2023-06-28 10:49:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:49:04 --> Model Class Initialized
DEBUG - 2023-06-28 10:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:49:04 --> Model Class Initialized
INFO - 2023-06-28 10:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-28 10:49:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:49:04 --> Model Class Initialized
INFO - 2023-06-28 10:49:04 --> Model Class Initialized
INFO - 2023-06-28 10:49:04 --> Model Class Initialized
INFO - 2023-06-28 10:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:49:04 --> Final output sent to browser
DEBUG - 2023-06-28 10:49:04 --> Total execution time: 0.0628
ERROR - 2023-06-28 10:49:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:49:04 --> Config Class Initialized
INFO - 2023-06-28 10:49:04 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:49:04 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:49:04 --> Utf8 Class Initialized
INFO - 2023-06-28 10:49:04 --> URI Class Initialized
INFO - 2023-06-28 10:49:04 --> Router Class Initialized
INFO - 2023-06-28 10:49:04 --> Output Class Initialized
INFO - 2023-06-28 10:49:04 --> Security Class Initialized
DEBUG - 2023-06-28 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:49:04 --> Input Class Initialized
INFO - 2023-06-28 10:49:04 --> Language Class Initialized
INFO - 2023-06-28 10:49:04 --> Loader Class Initialized
INFO - 2023-06-28 10:49:04 --> Helper loaded: url_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: file_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: html_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: text_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: form_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: security_helper
INFO - 2023-06-28 10:49:04 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:49:04 --> Database Driver Class Initialized
INFO - 2023-06-28 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:49:04 --> Parser Class Initialized
INFO - 2023-06-28 10:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:49:04 --> Pagination Class Initialized
INFO - 2023-06-28 10:49:04 --> Form Validation Class Initialized
INFO - 2023-06-28 10:49:04 --> Controller Class Initialized
INFO - 2023-06-28 10:49:04 --> Model Class Initialized
DEBUG - 2023-06-28 10:49:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:49:04 --> Model Class Initialized
DEBUG - 2023-06-28 10:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:49:04 --> Model Class Initialized
INFO - 2023-06-28 10:49:04 --> Final output sent to browser
DEBUG - 2023-06-28 10:49:04 --> Total execution time: 0.0228
ERROR - 2023-06-28 10:50:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:50:22 --> Config Class Initialized
INFO - 2023-06-28 10:50:22 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:50:22 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:50:22 --> Utf8 Class Initialized
INFO - 2023-06-28 10:50:22 --> URI Class Initialized
INFO - 2023-06-28 10:50:22 --> Router Class Initialized
INFO - 2023-06-28 10:50:22 --> Output Class Initialized
INFO - 2023-06-28 10:50:22 --> Security Class Initialized
DEBUG - 2023-06-28 10:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:50:22 --> Input Class Initialized
INFO - 2023-06-28 10:50:22 --> Language Class Initialized
INFO - 2023-06-28 10:50:22 --> Loader Class Initialized
INFO - 2023-06-28 10:50:22 --> Helper loaded: url_helper
INFO - 2023-06-28 10:50:22 --> Helper loaded: file_helper
INFO - 2023-06-28 10:50:22 --> Helper loaded: html_helper
INFO - 2023-06-28 10:50:22 --> Helper loaded: text_helper
INFO - 2023-06-28 10:50:22 --> Helper loaded: form_helper
INFO - 2023-06-28 10:50:22 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:50:22 --> Helper loaded: security_helper
INFO - 2023-06-28 10:50:22 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:50:22 --> Database Driver Class Initialized
INFO - 2023-06-28 10:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:50:22 --> Parser Class Initialized
INFO - 2023-06-28 10:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:50:22 --> Pagination Class Initialized
INFO - 2023-06-28 10:50:22 --> Form Validation Class Initialized
INFO - 2023-06-28 10:50:22 --> Controller Class Initialized
INFO - 2023-06-28 10:50:22 --> Model Class Initialized
DEBUG - 2023-06-28 10:50:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:50:22 --> Model Class Initialized
DEBUG - 2023-06-28 10:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:50:22 --> Model Class Initialized
INFO - 2023-06-28 10:50:22 --> Final output sent to browser
DEBUG - 2023-06-28 10:50:22 --> Total execution time: 0.0229
ERROR - 2023-06-28 10:51:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:51:24 --> Config Class Initialized
INFO - 2023-06-28 10:51:24 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:51:24 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:51:24 --> Utf8 Class Initialized
INFO - 2023-06-28 10:51:24 --> URI Class Initialized
DEBUG - 2023-06-28 10:51:24 --> No URI present. Default controller set.
INFO - 2023-06-28 10:51:24 --> Router Class Initialized
INFO - 2023-06-28 10:51:24 --> Output Class Initialized
INFO - 2023-06-28 10:51:24 --> Security Class Initialized
DEBUG - 2023-06-28 10:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:51:24 --> Input Class Initialized
INFO - 2023-06-28 10:51:24 --> Language Class Initialized
INFO - 2023-06-28 10:51:24 --> Loader Class Initialized
INFO - 2023-06-28 10:51:24 --> Helper loaded: url_helper
INFO - 2023-06-28 10:51:24 --> Helper loaded: file_helper
INFO - 2023-06-28 10:51:24 --> Helper loaded: html_helper
INFO - 2023-06-28 10:51:24 --> Helper loaded: text_helper
INFO - 2023-06-28 10:51:24 --> Helper loaded: form_helper
INFO - 2023-06-28 10:51:24 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:51:24 --> Helper loaded: security_helper
INFO - 2023-06-28 10:51:24 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:51:24 --> Database Driver Class Initialized
INFO - 2023-06-28 10:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:51:24 --> Parser Class Initialized
INFO - 2023-06-28 10:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:51:24 --> Pagination Class Initialized
INFO - 2023-06-28 10:51:24 --> Form Validation Class Initialized
INFO - 2023-06-28 10:51:24 --> Controller Class Initialized
INFO - 2023-06-28 10:51:24 --> Model Class Initialized
DEBUG - 2023-06-28 10:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:51:24 --> Model Class Initialized
DEBUG - 2023-06-28 10:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:51:24 --> Model Class Initialized
INFO - 2023-06-28 10:51:24 --> Model Class Initialized
INFO - 2023-06-28 10:51:24 --> Model Class Initialized
INFO - 2023-06-28 10:51:24 --> Model Class Initialized
DEBUG - 2023-06-28 10:51:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:51:24 --> Model Class Initialized
INFO - 2023-06-28 10:51:24 --> Model Class Initialized
INFO - 2023-06-28 10:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:51:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:51:24 --> Model Class Initialized
INFO - 2023-06-28 10:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:51:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:51:24 --> Final output sent to browser
DEBUG - 2023-06-28 10:51:24 --> Total execution time: 0.0684
ERROR - 2023-06-28 10:51:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:51:32 --> Config Class Initialized
INFO - 2023-06-28 10:51:32 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:51:32 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:51:32 --> Utf8 Class Initialized
INFO - 2023-06-28 10:51:32 --> URI Class Initialized
INFO - 2023-06-28 10:51:32 --> Router Class Initialized
INFO - 2023-06-28 10:51:32 --> Output Class Initialized
INFO - 2023-06-28 10:51:32 --> Security Class Initialized
DEBUG - 2023-06-28 10:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:51:32 --> Input Class Initialized
INFO - 2023-06-28 10:51:32 --> Language Class Initialized
INFO - 2023-06-28 10:51:32 --> Loader Class Initialized
INFO - 2023-06-28 10:51:32 --> Helper loaded: url_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: file_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: html_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: text_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: form_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: security_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:51:32 --> Database Driver Class Initialized
INFO - 2023-06-28 10:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:51:32 --> Parser Class Initialized
INFO - 2023-06-28 10:51:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:51:32 --> Pagination Class Initialized
INFO - 2023-06-28 10:51:32 --> Form Validation Class Initialized
INFO - 2023-06-28 10:51:32 --> Controller Class Initialized
INFO - 2023-06-28 10:51:32 --> Model Class Initialized
DEBUG - 2023-06-28 10:51:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:51:32 --> Model Class Initialized
DEBUG - 2023-06-28 10:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:51:32 --> Model Class Initialized
INFO - 2023-06-28 10:51:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:51:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:51:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:51:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:51:32 --> Model Class Initialized
INFO - 2023-06-28 10:51:32 --> Model Class Initialized
INFO - 2023-06-28 10:51:32 --> Model Class Initialized
INFO - 2023-06-28 10:51:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:51:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:51:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:51:32 --> Final output sent to browser
DEBUG - 2023-06-28 10:51:32 --> Total execution time: 0.0615
ERROR - 2023-06-28 10:51:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:51:32 --> Config Class Initialized
INFO - 2023-06-28 10:51:32 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:51:32 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:51:32 --> Utf8 Class Initialized
INFO - 2023-06-28 10:51:32 --> URI Class Initialized
INFO - 2023-06-28 10:51:32 --> Router Class Initialized
INFO - 2023-06-28 10:51:32 --> Output Class Initialized
INFO - 2023-06-28 10:51:32 --> Security Class Initialized
DEBUG - 2023-06-28 10:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:51:32 --> Input Class Initialized
INFO - 2023-06-28 10:51:32 --> Language Class Initialized
INFO - 2023-06-28 10:51:32 --> Loader Class Initialized
INFO - 2023-06-28 10:51:32 --> Helper loaded: url_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: file_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: html_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: text_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: form_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: security_helper
INFO - 2023-06-28 10:51:32 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:51:32 --> Database Driver Class Initialized
INFO - 2023-06-28 10:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:51:32 --> Parser Class Initialized
INFO - 2023-06-28 10:51:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:51:32 --> Pagination Class Initialized
INFO - 2023-06-28 10:51:32 --> Form Validation Class Initialized
INFO - 2023-06-28 10:51:32 --> Controller Class Initialized
INFO - 2023-06-28 10:51:32 --> Model Class Initialized
DEBUG - 2023-06-28 10:51:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:51:32 --> Model Class Initialized
DEBUG - 2023-06-28 10:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:51:32 --> Model Class Initialized
INFO - 2023-06-28 10:51:32 --> Final output sent to browser
DEBUG - 2023-06-28 10:51:32 --> Total execution time: 0.0249
ERROR - 2023-06-28 10:52:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:52:08 --> Config Class Initialized
INFO - 2023-06-28 10:52:08 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:52:08 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:52:08 --> Utf8 Class Initialized
INFO - 2023-06-28 10:52:08 --> URI Class Initialized
DEBUG - 2023-06-28 10:52:08 --> No URI present. Default controller set.
INFO - 2023-06-28 10:52:08 --> Router Class Initialized
INFO - 2023-06-28 10:52:08 --> Output Class Initialized
INFO - 2023-06-28 10:52:08 --> Security Class Initialized
DEBUG - 2023-06-28 10:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:52:08 --> Input Class Initialized
INFO - 2023-06-28 10:52:08 --> Language Class Initialized
INFO - 2023-06-28 10:52:08 --> Loader Class Initialized
INFO - 2023-06-28 10:52:08 --> Helper loaded: url_helper
INFO - 2023-06-28 10:52:08 --> Helper loaded: file_helper
INFO - 2023-06-28 10:52:08 --> Helper loaded: html_helper
INFO - 2023-06-28 10:52:08 --> Helper loaded: text_helper
INFO - 2023-06-28 10:52:08 --> Helper loaded: form_helper
INFO - 2023-06-28 10:52:08 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:52:08 --> Helper loaded: security_helper
INFO - 2023-06-28 10:52:08 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:52:08 --> Database Driver Class Initialized
INFO - 2023-06-28 10:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:52:08 --> Parser Class Initialized
INFO - 2023-06-28 10:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:52:08 --> Pagination Class Initialized
INFO - 2023-06-28 10:52:08 --> Form Validation Class Initialized
INFO - 2023-06-28 10:52:08 --> Controller Class Initialized
INFO - 2023-06-28 10:52:08 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:08 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:08 --> Model Class Initialized
INFO - 2023-06-28 10:52:08 --> Model Class Initialized
INFO - 2023-06-28 10:52:08 --> Model Class Initialized
INFO - 2023-06-28 10:52:08 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:08 --> Model Class Initialized
INFO - 2023-06-28 10:52:08 --> Model Class Initialized
INFO - 2023-06-28 10:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:52:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:52:08 --> Model Class Initialized
INFO - 2023-06-28 10:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:52:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:52:08 --> Final output sent to browser
DEBUG - 2023-06-28 10:52:08 --> Total execution time: 0.0669
ERROR - 2023-06-28 10:52:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:52:22 --> Config Class Initialized
INFO - 2023-06-28 10:52:22 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:52:22 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:52:22 --> Utf8 Class Initialized
INFO - 2023-06-28 10:52:22 --> URI Class Initialized
INFO - 2023-06-28 10:52:22 --> Router Class Initialized
INFO - 2023-06-28 10:52:22 --> Output Class Initialized
INFO - 2023-06-28 10:52:22 --> Security Class Initialized
DEBUG - 2023-06-28 10:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:52:22 --> Input Class Initialized
INFO - 2023-06-28 10:52:22 --> Language Class Initialized
INFO - 2023-06-28 10:52:22 --> Loader Class Initialized
INFO - 2023-06-28 10:52:22 --> Helper loaded: url_helper
INFO - 2023-06-28 10:52:22 --> Helper loaded: file_helper
INFO - 2023-06-28 10:52:22 --> Helper loaded: html_helper
INFO - 2023-06-28 10:52:22 --> Helper loaded: text_helper
INFO - 2023-06-28 10:52:22 --> Helper loaded: form_helper
INFO - 2023-06-28 10:52:22 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:52:22 --> Helper loaded: security_helper
INFO - 2023-06-28 10:52:22 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:52:22 --> Database Driver Class Initialized
INFO - 2023-06-28 10:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:52:22 --> Parser Class Initialized
INFO - 2023-06-28 10:52:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:52:22 --> Pagination Class Initialized
INFO - 2023-06-28 10:52:22 --> Form Validation Class Initialized
INFO - 2023-06-28 10:52:22 --> Controller Class Initialized
INFO - 2023-06-28 10:52:22 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:22 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:22 --> Model Class Initialized
INFO - 2023-06-28 10:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-28 10:52:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:52:22 --> Model Class Initialized
INFO - 2023-06-28 10:52:22 --> Model Class Initialized
INFO - 2023-06-28 10:52:22 --> Model Class Initialized
INFO - 2023-06-28 10:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:52:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:52:22 --> Final output sent to browser
DEBUG - 2023-06-28 10:52:22 --> Total execution time: 0.0702
ERROR - 2023-06-28 10:52:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:52:23 --> Config Class Initialized
INFO - 2023-06-28 10:52:23 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:52:23 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:52:23 --> Utf8 Class Initialized
INFO - 2023-06-28 10:52:23 --> URI Class Initialized
INFO - 2023-06-28 10:52:23 --> Router Class Initialized
INFO - 2023-06-28 10:52:23 --> Output Class Initialized
INFO - 2023-06-28 10:52:23 --> Security Class Initialized
DEBUG - 2023-06-28 10:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:52:23 --> Input Class Initialized
INFO - 2023-06-28 10:52:23 --> Language Class Initialized
INFO - 2023-06-28 10:52:23 --> Loader Class Initialized
INFO - 2023-06-28 10:52:23 --> Helper loaded: url_helper
INFO - 2023-06-28 10:52:23 --> Helper loaded: file_helper
INFO - 2023-06-28 10:52:23 --> Helper loaded: html_helper
INFO - 2023-06-28 10:52:23 --> Helper loaded: text_helper
INFO - 2023-06-28 10:52:23 --> Helper loaded: form_helper
INFO - 2023-06-28 10:52:23 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:52:23 --> Helper loaded: security_helper
INFO - 2023-06-28 10:52:23 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:52:23 --> Database Driver Class Initialized
INFO - 2023-06-28 10:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:52:23 --> Parser Class Initialized
INFO - 2023-06-28 10:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:52:23 --> Pagination Class Initialized
INFO - 2023-06-28 10:52:23 --> Form Validation Class Initialized
INFO - 2023-06-28 10:52:23 --> Controller Class Initialized
INFO - 2023-06-28 10:52:23 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:23 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:23 --> Model Class Initialized
INFO - 2023-06-28 10:52:23 --> Final output sent to browser
DEBUG - 2023-06-28 10:52:23 --> Total execution time: 0.0232
ERROR - 2023-06-28 10:52:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 10:52:48 --> Config Class Initialized
INFO - 2023-06-28 10:52:48 --> Hooks Class Initialized
DEBUG - 2023-06-28 10:52:48 --> UTF-8 Support Enabled
INFO - 2023-06-28 10:52:48 --> Utf8 Class Initialized
INFO - 2023-06-28 10:52:48 --> URI Class Initialized
DEBUG - 2023-06-28 10:52:48 --> No URI present. Default controller set.
INFO - 2023-06-28 10:52:48 --> Router Class Initialized
INFO - 2023-06-28 10:52:48 --> Output Class Initialized
INFO - 2023-06-28 10:52:48 --> Security Class Initialized
DEBUG - 2023-06-28 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 10:52:48 --> Input Class Initialized
INFO - 2023-06-28 10:52:48 --> Language Class Initialized
INFO - 2023-06-28 10:52:48 --> Loader Class Initialized
INFO - 2023-06-28 10:52:48 --> Helper loaded: url_helper
INFO - 2023-06-28 10:52:48 --> Helper loaded: file_helper
INFO - 2023-06-28 10:52:48 --> Helper loaded: html_helper
INFO - 2023-06-28 10:52:48 --> Helper loaded: text_helper
INFO - 2023-06-28 10:52:48 --> Helper loaded: form_helper
INFO - 2023-06-28 10:52:48 --> Helper loaded: lang_helper
INFO - 2023-06-28 10:52:48 --> Helper loaded: security_helper
INFO - 2023-06-28 10:52:48 --> Helper loaded: cookie_helper
INFO - 2023-06-28 10:52:48 --> Database Driver Class Initialized
INFO - 2023-06-28 10:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 10:52:48 --> Parser Class Initialized
INFO - 2023-06-28 10:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 10:52:48 --> Pagination Class Initialized
INFO - 2023-06-28 10:52:48 --> Form Validation Class Initialized
INFO - 2023-06-28 10:52:48 --> Controller Class Initialized
INFO - 2023-06-28 10:52:48 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:48 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:48 --> Model Class Initialized
INFO - 2023-06-28 10:52:48 --> Model Class Initialized
INFO - 2023-06-28 10:52:48 --> Model Class Initialized
INFO - 2023-06-28 10:52:48 --> Model Class Initialized
DEBUG - 2023-06-28 10:52:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 10:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:48 --> Model Class Initialized
INFO - 2023-06-28 10:52:48 --> Model Class Initialized
INFO - 2023-06-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 10:52:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 10:52:48 --> Model Class Initialized
INFO - 2023-06-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 10:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 10:52:48 --> Final output sent to browser
DEBUG - 2023-06-28 10:52:48 --> Total execution time: 0.0644
ERROR - 2023-06-28 11:17:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 11:17:13 --> Config Class Initialized
INFO - 2023-06-28 11:17:13 --> Hooks Class Initialized
DEBUG - 2023-06-28 11:17:13 --> UTF-8 Support Enabled
INFO - 2023-06-28 11:17:13 --> Utf8 Class Initialized
INFO - 2023-06-28 11:17:13 --> URI Class Initialized
INFO - 2023-06-28 11:17:13 --> Router Class Initialized
INFO - 2023-06-28 11:17:13 --> Output Class Initialized
INFO - 2023-06-28 11:17:13 --> Security Class Initialized
DEBUG - 2023-06-28 11:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 11:17:13 --> Input Class Initialized
INFO - 2023-06-28 11:17:13 --> Language Class Initialized
INFO - 2023-06-28 11:17:13 --> Loader Class Initialized
INFO - 2023-06-28 11:17:13 --> Helper loaded: url_helper
INFO - 2023-06-28 11:17:13 --> Helper loaded: file_helper
INFO - 2023-06-28 11:17:13 --> Helper loaded: html_helper
INFO - 2023-06-28 11:17:13 --> Helper loaded: text_helper
INFO - 2023-06-28 11:17:13 --> Helper loaded: form_helper
INFO - 2023-06-28 11:17:13 --> Helper loaded: lang_helper
INFO - 2023-06-28 11:17:13 --> Helper loaded: security_helper
INFO - 2023-06-28 11:17:13 --> Helper loaded: cookie_helper
INFO - 2023-06-28 11:17:13 --> Database Driver Class Initialized
INFO - 2023-06-28 11:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 11:17:13 --> Parser Class Initialized
INFO - 2023-06-28 11:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 11:17:13 --> Pagination Class Initialized
INFO - 2023-06-28 11:17:13 --> Form Validation Class Initialized
INFO - 2023-06-28 11:17:13 --> Controller Class Initialized
INFO - 2023-06-28 11:17:13 --> Model Class Initialized
DEBUG - 2023-06-28 11:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 11:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 11:17:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 11:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 11:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 11:17:13 --> Model Class Initialized
INFO - 2023-06-28 11:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 11:17:13 --> Final output sent to browser
DEBUG - 2023-06-28 11:17:13 --> Total execution time: 0.0292
ERROR - 2023-06-28 11:19:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 11:19:56 --> Config Class Initialized
INFO - 2023-06-28 11:19:56 --> Hooks Class Initialized
DEBUG - 2023-06-28 11:19:56 --> UTF-8 Support Enabled
INFO - 2023-06-28 11:19:56 --> Utf8 Class Initialized
INFO - 2023-06-28 11:19:56 --> URI Class Initialized
INFO - 2023-06-28 11:19:56 --> Router Class Initialized
INFO - 2023-06-28 11:19:56 --> Output Class Initialized
INFO - 2023-06-28 11:19:56 --> Security Class Initialized
DEBUG - 2023-06-28 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 11:19:56 --> Input Class Initialized
INFO - 2023-06-28 11:19:56 --> Language Class Initialized
INFO - 2023-06-28 11:19:56 --> Loader Class Initialized
INFO - 2023-06-28 11:19:56 --> Helper loaded: url_helper
INFO - 2023-06-28 11:19:56 --> Helper loaded: file_helper
INFO - 2023-06-28 11:19:56 --> Helper loaded: html_helper
INFO - 2023-06-28 11:19:56 --> Helper loaded: text_helper
INFO - 2023-06-28 11:19:56 --> Helper loaded: form_helper
INFO - 2023-06-28 11:19:56 --> Helper loaded: lang_helper
INFO - 2023-06-28 11:19:56 --> Helper loaded: security_helper
INFO - 2023-06-28 11:19:56 --> Helper loaded: cookie_helper
INFO - 2023-06-28 11:19:56 --> Database Driver Class Initialized
INFO - 2023-06-28 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 11:19:56 --> Parser Class Initialized
INFO - 2023-06-28 11:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 11:19:56 --> Pagination Class Initialized
INFO - 2023-06-28 11:19:56 --> Form Validation Class Initialized
INFO - 2023-06-28 11:19:56 --> Controller Class Initialized
ERROR - 2023-06-28 11:29:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 11:29:42 --> Config Class Initialized
INFO - 2023-06-28 11:29:42 --> Hooks Class Initialized
DEBUG - 2023-06-28 11:29:42 --> UTF-8 Support Enabled
INFO - 2023-06-28 11:29:42 --> Utf8 Class Initialized
INFO - 2023-06-28 11:29:42 --> URI Class Initialized
INFO - 2023-06-28 11:29:42 --> Router Class Initialized
INFO - 2023-06-28 11:29:42 --> Output Class Initialized
INFO - 2023-06-28 11:29:42 --> Security Class Initialized
DEBUG - 2023-06-28 11:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 11:29:42 --> Input Class Initialized
INFO - 2023-06-28 11:29:42 --> Language Class Initialized
INFO - 2023-06-28 11:29:42 --> Loader Class Initialized
INFO - 2023-06-28 11:29:42 --> Helper loaded: url_helper
INFO - 2023-06-28 11:29:42 --> Helper loaded: file_helper
INFO - 2023-06-28 11:29:42 --> Helper loaded: html_helper
INFO - 2023-06-28 11:29:42 --> Helper loaded: text_helper
INFO - 2023-06-28 11:29:42 --> Helper loaded: form_helper
INFO - 2023-06-28 11:29:42 --> Helper loaded: lang_helper
INFO - 2023-06-28 11:29:42 --> Helper loaded: security_helper
INFO - 2023-06-28 11:29:42 --> Helper loaded: cookie_helper
INFO - 2023-06-28 11:29:42 --> Database Driver Class Initialized
INFO - 2023-06-28 11:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 11:29:42 --> Parser Class Initialized
INFO - 2023-06-28 11:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 11:29:42 --> Pagination Class Initialized
INFO - 2023-06-28 11:29:42 --> Form Validation Class Initialized
INFO - 2023-06-28 11:29:42 --> Controller Class Initialized
ERROR - 2023-06-28 13:16:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-06-28 13:16:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 13:16:30 --> Config Class Initialized
INFO - 2023-06-28 13:16:30 --> Config Class Initialized
INFO - 2023-06-28 13:16:30 --> Hooks Class Initialized
INFO - 2023-06-28 13:16:30 --> Hooks Class Initialized
DEBUG - 2023-06-28 13:16:30 --> UTF-8 Support Enabled
DEBUG - 2023-06-28 13:16:30 --> UTF-8 Support Enabled
INFO - 2023-06-28 13:16:30 --> Utf8 Class Initialized
INFO - 2023-06-28 13:16:30 --> Utf8 Class Initialized
INFO - 2023-06-28 13:16:30 --> URI Class Initialized
INFO - 2023-06-28 13:16:30 --> URI Class Initialized
DEBUG - 2023-06-28 13:16:30 --> No URI present. Default controller set.
DEBUG - 2023-06-28 13:16:30 --> No URI present. Default controller set.
INFO - 2023-06-28 13:16:30 --> Router Class Initialized
INFO - 2023-06-28 13:16:30 --> Router Class Initialized
INFO - 2023-06-28 13:16:30 --> Output Class Initialized
INFO - 2023-06-28 13:16:30 --> Output Class Initialized
INFO - 2023-06-28 13:16:30 --> Security Class Initialized
INFO - 2023-06-28 13:16:30 --> Security Class Initialized
DEBUG - 2023-06-28 13:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-28 13:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 13:16:30 --> Input Class Initialized
INFO - 2023-06-28 13:16:30 --> Input Class Initialized
INFO - 2023-06-28 13:16:30 --> Language Class Initialized
INFO - 2023-06-28 13:16:30 --> Language Class Initialized
INFO - 2023-06-28 13:16:30 --> Loader Class Initialized
INFO - 2023-06-28 13:16:30 --> Helper loaded: url_helper
INFO - 2023-06-28 13:16:30 --> Loader Class Initialized
INFO - 2023-06-28 13:16:30 --> Helper loaded: file_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: html_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: url_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: text_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: file_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: form_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: html_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: lang_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: security_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: cookie_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: text_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: form_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: lang_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: security_helper
INFO - 2023-06-28 13:16:30 --> Helper loaded: cookie_helper
INFO - 2023-06-28 13:16:30 --> Database Driver Class Initialized
INFO - 2023-06-28 13:16:30 --> Database Driver Class Initialized
INFO - 2023-06-28 13:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 13:16:30 --> Parser Class Initialized
INFO - 2023-06-28 13:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 13:16:30 --> Pagination Class Initialized
INFO - 2023-06-28 13:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 13:16:30 --> Parser Class Initialized
INFO - 2023-06-28 13:16:30 --> Form Validation Class Initialized
INFO - 2023-06-28 13:16:30 --> Controller Class Initialized
INFO - 2023-06-28 13:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 13:16:30 --> Model Class Initialized
INFO - 2023-06-28 13:16:30 --> Pagination Class Initialized
DEBUG - 2023-06-28 13:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 13:16:30 --> Form Validation Class Initialized
INFO - 2023-06-28 13:16:30 --> Controller Class Initialized
INFO - 2023-06-28 13:16:30 --> Model Class Initialized
DEBUG - 2023-06-28 13:16:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 13:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 13:16:31 --> Config Class Initialized
INFO - 2023-06-28 13:16:31 --> Hooks Class Initialized
DEBUG - 2023-06-28 13:16:31 --> UTF-8 Support Enabled
INFO - 2023-06-28 13:16:31 --> Utf8 Class Initialized
INFO - 2023-06-28 13:16:31 --> URI Class Initialized
DEBUG - 2023-06-28 13:16:31 --> No URI present. Default controller set.
INFO - 2023-06-28 13:16:31 --> Router Class Initialized
INFO - 2023-06-28 13:16:31 --> Output Class Initialized
INFO - 2023-06-28 13:16:31 --> Security Class Initialized
DEBUG - 2023-06-28 13:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 13:16:31 --> Input Class Initialized
INFO - 2023-06-28 13:16:31 --> Language Class Initialized
INFO - 2023-06-28 13:16:31 --> Loader Class Initialized
INFO - 2023-06-28 13:16:31 --> Helper loaded: url_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: file_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: html_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: text_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: form_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: lang_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: security_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: cookie_helper
INFO - 2023-06-28 13:16:31 --> Database Driver Class Initialized
INFO - 2023-06-28 13:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 13:16:31 --> Parser Class Initialized
INFO - 2023-06-28 13:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 13:16:31 --> Pagination Class Initialized
INFO - 2023-06-28 13:16:31 --> Form Validation Class Initialized
INFO - 2023-06-28 13:16:31 --> Controller Class Initialized
INFO - 2023-06-28 13:16:31 --> Model Class Initialized
DEBUG - 2023-06-28 13:16:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 13:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 13:16:31 --> Config Class Initialized
INFO - 2023-06-28 13:16:31 --> Hooks Class Initialized
DEBUG - 2023-06-28 13:16:31 --> UTF-8 Support Enabled
INFO - 2023-06-28 13:16:31 --> Utf8 Class Initialized
INFO - 2023-06-28 13:16:31 --> URI Class Initialized
DEBUG - 2023-06-28 13:16:31 --> No URI present. Default controller set.
INFO - 2023-06-28 13:16:31 --> Router Class Initialized
INFO - 2023-06-28 13:16:31 --> Output Class Initialized
INFO - 2023-06-28 13:16:31 --> Security Class Initialized
DEBUG - 2023-06-28 13:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 13:16:31 --> Input Class Initialized
INFO - 2023-06-28 13:16:31 --> Language Class Initialized
INFO - 2023-06-28 13:16:31 --> Loader Class Initialized
INFO - 2023-06-28 13:16:31 --> Helper loaded: url_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: file_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: html_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: text_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: form_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: lang_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: security_helper
INFO - 2023-06-28 13:16:31 --> Helper loaded: cookie_helper
INFO - 2023-06-28 13:16:31 --> Database Driver Class Initialized
INFO - 2023-06-28 13:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 13:16:31 --> Parser Class Initialized
INFO - 2023-06-28 13:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 13:16:31 --> Pagination Class Initialized
INFO - 2023-06-28 13:16:31 --> Form Validation Class Initialized
INFO - 2023-06-28 13:16:31 --> Controller Class Initialized
INFO - 2023-06-28 13:16:31 --> Model Class Initialized
DEBUG - 2023-06-28 13:16:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 13:16:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 13:16:32 --> Config Class Initialized
INFO - 2023-06-28 13:16:32 --> Hooks Class Initialized
DEBUG - 2023-06-28 13:16:32 --> UTF-8 Support Enabled
INFO - 2023-06-28 13:16:32 --> Utf8 Class Initialized
INFO - 2023-06-28 13:16:32 --> URI Class Initialized
DEBUG - 2023-06-28 13:16:32 --> No URI present. Default controller set.
INFO - 2023-06-28 13:16:32 --> Router Class Initialized
INFO - 2023-06-28 13:16:32 --> Output Class Initialized
INFO - 2023-06-28 13:16:32 --> Security Class Initialized
DEBUG - 2023-06-28 13:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 13:16:32 --> Input Class Initialized
INFO - 2023-06-28 13:16:32 --> Language Class Initialized
INFO - 2023-06-28 13:16:32 --> Loader Class Initialized
INFO - 2023-06-28 13:16:32 --> Helper loaded: url_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: file_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: html_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: text_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: form_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: lang_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: security_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: cookie_helper
INFO - 2023-06-28 13:16:32 --> Database Driver Class Initialized
INFO - 2023-06-28 13:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 13:16:32 --> Parser Class Initialized
INFO - 2023-06-28 13:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 13:16:32 --> Pagination Class Initialized
INFO - 2023-06-28 13:16:32 --> Form Validation Class Initialized
INFO - 2023-06-28 13:16:32 --> Controller Class Initialized
INFO - 2023-06-28 13:16:32 --> Model Class Initialized
DEBUG - 2023-06-28 13:16:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 13:16:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 13:16:32 --> Config Class Initialized
INFO - 2023-06-28 13:16:32 --> Hooks Class Initialized
DEBUG - 2023-06-28 13:16:32 --> UTF-8 Support Enabled
INFO - 2023-06-28 13:16:32 --> Utf8 Class Initialized
INFO - 2023-06-28 13:16:32 --> URI Class Initialized
DEBUG - 2023-06-28 13:16:32 --> No URI present. Default controller set.
INFO - 2023-06-28 13:16:32 --> Router Class Initialized
INFO - 2023-06-28 13:16:32 --> Output Class Initialized
INFO - 2023-06-28 13:16:32 --> Security Class Initialized
DEBUG - 2023-06-28 13:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 13:16:32 --> Input Class Initialized
INFO - 2023-06-28 13:16:32 --> Language Class Initialized
INFO - 2023-06-28 13:16:32 --> Loader Class Initialized
INFO - 2023-06-28 13:16:32 --> Helper loaded: url_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: file_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: html_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: text_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: form_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: lang_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: security_helper
INFO - 2023-06-28 13:16:32 --> Helper loaded: cookie_helper
INFO - 2023-06-28 13:16:32 --> Database Driver Class Initialized
INFO - 2023-06-28 13:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 13:16:32 --> Parser Class Initialized
INFO - 2023-06-28 13:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 13:16:32 --> Pagination Class Initialized
INFO - 2023-06-28 13:16:32 --> Form Validation Class Initialized
INFO - 2023-06-28 13:16:32 --> Controller Class Initialized
INFO - 2023-06-28 13:16:32 --> Model Class Initialized
DEBUG - 2023-06-28 13:16:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 13:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 13:16:33 --> Config Class Initialized
INFO - 2023-06-28 13:16:33 --> Hooks Class Initialized
DEBUG - 2023-06-28 13:16:33 --> UTF-8 Support Enabled
INFO - 2023-06-28 13:16:33 --> Utf8 Class Initialized
INFO - 2023-06-28 13:16:33 --> URI Class Initialized
DEBUG - 2023-06-28 13:16:33 --> No URI present. Default controller set.
INFO - 2023-06-28 13:16:33 --> Router Class Initialized
INFO - 2023-06-28 13:16:33 --> Output Class Initialized
INFO - 2023-06-28 13:16:33 --> Security Class Initialized
DEBUG - 2023-06-28 13:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 13:16:33 --> Input Class Initialized
INFO - 2023-06-28 13:16:33 --> Language Class Initialized
INFO - 2023-06-28 13:16:33 --> Loader Class Initialized
INFO - 2023-06-28 13:16:33 --> Helper loaded: url_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: file_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: html_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: text_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: form_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: lang_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: security_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: cookie_helper
INFO - 2023-06-28 13:16:33 --> Database Driver Class Initialized
INFO - 2023-06-28 13:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 13:16:33 --> Parser Class Initialized
INFO - 2023-06-28 13:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 13:16:33 --> Pagination Class Initialized
INFO - 2023-06-28 13:16:33 --> Form Validation Class Initialized
INFO - 2023-06-28 13:16:33 --> Controller Class Initialized
INFO - 2023-06-28 13:16:33 --> Model Class Initialized
DEBUG - 2023-06-28 13:16:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 13:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 13:16:33 --> Config Class Initialized
INFO - 2023-06-28 13:16:33 --> Hooks Class Initialized
DEBUG - 2023-06-28 13:16:33 --> UTF-8 Support Enabled
INFO - 2023-06-28 13:16:33 --> Utf8 Class Initialized
INFO - 2023-06-28 13:16:33 --> URI Class Initialized
DEBUG - 2023-06-28 13:16:33 --> No URI present. Default controller set.
INFO - 2023-06-28 13:16:33 --> Router Class Initialized
INFO - 2023-06-28 13:16:33 --> Output Class Initialized
INFO - 2023-06-28 13:16:33 --> Security Class Initialized
DEBUG - 2023-06-28 13:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 13:16:33 --> Input Class Initialized
INFO - 2023-06-28 13:16:33 --> Language Class Initialized
INFO - 2023-06-28 13:16:33 --> Loader Class Initialized
INFO - 2023-06-28 13:16:33 --> Helper loaded: url_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: file_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: html_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: text_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: form_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: lang_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: security_helper
INFO - 2023-06-28 13:16:33 --> Helper loaded: cookie_helper
INFO - 2023-06-28 13:16:33 --> Database Driver Class Initialized
INFO - 2023-06-28 13:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 13:16:33 --> Parser Class Initialized
INFO - 2023-06-28 13:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 13:16:33 --> Pagination Class Initialized
INFO - 2023-06-28 13:16:33 --> Form Validation Class Initialized
INFO - 2023-06-28 13:16:33 --> Controller Class Initialized
INFO - 2023-06-28 13:16:33 --> Model Class Initialized
DEBUG - 2023-06-28 13:16:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 16:14:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 16:14:33 --> Config Class Initialized
INFO - 2023-06-28 16:14:33 --> Hooks Class Initialized
DEBUG - 2023-06-28 16:14:33 --> UTF-8 Support Enabled
INFO - 2023-06-28 16:14:33 --> Utf8 Class Initialized
INFO - 2023-06-28 16:14:33 --> URI Class Initialized
DEBUG - 2023-06-28 16:14:33 --> No URI present. Default controller set.
INFO - 2023-06-28 16:14:33 --> Router Class Initialized
INFO - 2023-06-28 16:14:33 --> Output Class Initialized
INFO - 2023-06-28 16:14:33 --> Security Class Initialized
DEBUG - 2023-06-28 16:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 16:14:33 --> Input Class Initialized
INFO - 2023-06-28 16:14:33 --> Language Class Initialized
INFO - 2023-06-28 16:14:33 --> Loader Class Initialized
INFO - 2023-06-28 16:14:33 --> Helper loaded: url_helper
INFO - 2023-06-28 16:14:33 --> Helper loaded: file_helper
INFO - 2023-06-28 16:14:33 --> Helper loaded: html_helper
INFO - 2023-06-28 16:14:33 --> Helper loaded: text_helper
INFO - 2023-06-28 16:14:33 --> Helper loaded: form_helper
INFO - 2023-06-28 16:14:33 --> Helper loaded: lang_helper
INFO - 2023-06-28 16:14:33 --> Helper loaded: security_helper
INFO - 2023-06-28 16:14:33 --> Helper loaded: cookie_helper
INFO - 2023-06-28 16:14:33 --> Database Driver Class Initialized
INFO - 2023-06-28 16:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 16:14:33 --> Parser Class Initialized
INFO - 2023-06-28 16:14:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 16:14:33 --> Pagination Class Initialized
INFO - 2023-06-28 16:14:33 --> Form Validation Class Initialized
INFO - 2023-06-28 16:14:33 --> Controller Class Initialized
INFO - 2023-06-28 16:14:33 --> Model Class Initialized
DEBUG - 2023-06-28 16:14:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-28 16:14:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 16:14:34 --> Config Class Initialized
INFO - 2023-06-28 16:14:34 --> Hooks Class Initialized
DEBUG - 2023-06-28 16:14:34 --> UTF-8 Support Enabled
INFO - 2023-06-28 16:14:34 --> Utf8 Class Initialized
INFO - 2023-06-28 16:14:34 --> URI Class Initialized
INFO - 2023-06-28 16:14:34 --> Router Class Initialized
INFO - 2023-06-28 16:14:34 --> Output Class Initialized
INFO - 2023-06-28 16:14:34 --> Security Class Initialized
DEBUG - 2023-06-28 16:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 16:14:34 --> Input Class Initialized
INFO - 2023-06-28 16:14:34 --> Language Class Initialized
INFO - 2023-06-28 16:14:34 --> Loader Class Initialized
INFO - 2023-06-28 16:14:34 --> Helper loaded: url_helper
INFO - 2023-06-28 16:14:34 --> Helper loaded: file_helper
INFO - 2023-06-28 16:14:34 --> Helper loaded: html_helper
INFO - 2023-06-28 16:14:34 --> Helper loaded: text_helper
INFO - 2023-06-28 16:14:34 --> Helper loaded: form_helper
INFO - 2023-06-28 16:14:34 --> Helper loaded: lang_helper
INFO - 2023-06-28 16:14:34 --> Helper loaded: security_helper
INFO - 2023-06-28 16:14:34 --> Helper loaded: cookie_helper
INFO - 2023-06-28 16:14:34 --> Database Driver Class Initialized
INFO - 2023-06-28 16:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 16:14:34 --> Parser Class Initialized
INFO - 2023-06-28 16:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 16:14:34 --> Pagination Class Initialized
INFO - 2023-06-28 16:14:34 --> Form Validation Class Initialized
INFO - 2023-06-28 16:14:34 --> Controller Class Initialized
INFO - 2023-06-28 16:14:34 --> Model Class Initialized
DEBUG - 2023-06-28 16:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:14:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-28 16:14:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:14:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 16:14:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 16:14:34 --> Model Class Initialized
INFO - 2023-06-28 16:14:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 16:14:34 --> Final output sent to browser
DEBUG - 2023-06-28 16:14:34 --> Total execution time: 0.0362
ERROR - 2023-06-28 16:14:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 16:14:36 --> Config Class Initialized
INFO - 2023-06-28 16:14:36 --> Hooks Class Initialized
DEBUG - 2023-06-28 16:14:36 --> UTF-8 Support Enabled
INFO - 2023-06-28 16:14:36 --> Utf8 Class Initialized
INFO - 2023-06-28 16:14:36 --> URI Class Initialized
INFO - 2023-06-28 16:14:36 --> Router Class Initialized
INFO - 2023-06-28 16:14:36 --> Output Class Initialized
INFO - 2023-06-28 16:14:36 --> Security Class Initialized
DEBUG - 2023-06-28 16:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 16:14:36 --> Input Class Initialized
INFO - 2023-06-28 16:14:36 --> Language Class Initialized
INFO - 2023-06-28 16:14:36 --> Loader Class Initialized
INFO - 2023-06-28 16:14:36 --> Helper loaded: url_helper
INFO - 2023-06-28 16:14:36 --> Helper loaded: file_helper
INFO - 2023-06-28 16:14:36 --> Helper loaded: html_helper
INFO - 2023-06-28 16:14:36 --> Helper loaded: text_helper
INFO - 2023-06-28 16:14:36 --> Helper loaded: form_helper
INFO - 2023-06-28 16:14:36 --> Helper loaded: lang_helper
INFO - 2023-06-28 16:14:36 --> Helper loaded: security_helper
INFO - 2023-06-28 16:14:36 --> Helper loaded: cookie_helper
INFO - 2023-06-28 16:14:36 --> Database Driver Class Initialized
INFO - 2023-06-28 16:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 16:14:36 --> Parser Class Initialized
INFO - 2023-06-28 16:14:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 16:14:36 --> Pagination Class Initialized
INFO - 2023-06-28 16:14:36 --> Form Validation Class Initialized
INFO - 2023-06-28 16:14:36 --> Controller Class Initialized
INFO - 2023-06-28 16:14:36 --> Model Class Initialized
DEBUG - 2023-06-28 16:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:14:36 --> Model Class Initialized
INFO - 2023-06-28 16:14:36 --> Final output sent to browser
DEBUG - 2023-06-28 16:14:36 --> Total execution time: 0.0177
ERROR - 2023-06-28 16:14:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 16:14:37 --> Config Class Initialized
INFO - 2023-06-28 16:14:37 --> Hooks Class Initialized
DEBUG - 2023-06-28 16:14:37 --> UTF-8 Support Enabled
INFO - 2023-06-28 16:14:37 --> Utf8 Class Initialized
INFO - 2023-06-28 16:14:37 --> URI Class Initialized
DEBUG - 2023-06-28 16:14:37 --> No URI present. Default controller set.
INFO - 2023-06-28 16:14:37 --> Router Class Initialized
INFO - 2023-06-28 16:14:37 --> Output Class Initialized
INFO - 2023-06-28 16:14:37 --> Security Class Initialized
DEBUG - 2023-06-28 16:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 16:14:37 --> Input Class Initialized
INFO - 2023-06-28 16:14:37 --> Language Class Initialized
INFO - 2023-06-28 16:14:37 --> Loader Class Initialized
INFO - 2023-06-28 16:14:37 --> Helper loaded: url_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: file_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: html_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: text_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: form_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: lang_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: security_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: cookie_helper
INFO - 2023-06-28 16:14:37 --> Database Driver Class Initialized
INFO - 2023-06-28 16:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 16:14:37 --> Parser Class Initialized
INFO - 2023-06-28 16:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 16:14:37 --> Pagination Class Initialized
INFO - 2023-06-28 16:14:37 --> Form Validation Class Initialized
INFO - 2023-06-28 16:14:37 --> Controller Class Initialized
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
DEBUG - 2023-06-28 16:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
DEBUG - 2023-06-28 16:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
DEBUG - 2023-06-28 16:14:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 16:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
INFO - 2023-06-28 16:14:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-28 16:14:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:14:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 16:14:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
INFO - 2023-06-28 16:14:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 16:14:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 16:14:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 16:14:37 --> Final output sent to browser
DEBUG - 2023-06-28 16:14:37 --> Total execution time: 0.1715
ERROR - 2023-06-28 16:14:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 16:14:37 --> Config Class Initialized
INFO - 2023-06-28 16:14:37 --> Hooks Class Initialized
DEBUG - 2023-06-28 16:14:37 --> UTF-8 Support Enabled
INFO - 2023-06-28 16:14:37 --> Utf8 Class Initialized
INFO - 2023-06-28 16:14:37 --> URI Class Initialized
INFO - 2023-06-28 16:14:37 --> Router Class Initialized
INFO - 2023-06-28 16:14:37 --> Output Class Initialized
INFO - 2023-06-28 16:14:37 --> Security Class Initialized
DEBUG - 2023-06-28 16:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 16:14:37 --> Input Class Initialized
INFO - 2023-06-28 16:14:37 --> Language Class Initialized
INFO - 2023-06-28 16:14:37 --> Loader Class Initialized
INFO - 2023-06-28 16:14:37 --> Helper loaded: url_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: file_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: html_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: text_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: form_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: lang_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: security_helper
INFO - 2023-06-28 16:14:37 --> Helper loaded: cookie_helper
INFO - 2023-06-28 16:14:37 --> Database Driver Class Initialized
INFO - 2023-06-28 16:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 16:14:37 --> Parser Class Initialized
INFO - 2023-06-28 16:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 16:14:37 --> Pagination Class Initialized
INFO - 2023-06-28 16:14:37 --> Form Validation Class Initialized
INFO - 2023-06-28 16:14:37 --> Controller Class Initialized
DEBUG - 2023-06-28 16:14:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 16:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:14:37 --> Model Class Initialized
INFO - 2023-06-28 16:14:37 --> Final output sent to browser
DEBUG - 2023-06-28 16:14:37 --> Total execution time: 0.0136
ERROR - 2023-06-28 16:14:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 16:14:55 --> Config Class Initialized
INFO - 2023-06-28 16:14:55 --> Hooks Class Initialized
DEBUG - 2023-06-28 16:14:55 --> UTF-8 Support Enabled
INFO - 2023-06-28 16:14:55 --> Utf8 Class Initialized
INFO - 2023-06-28 16:14:55 --> URI Class Initialized
INFO - 2023-06-28 16:14:55 --> Router Class Initialized
INFO - 2023-06-28 16:14:55 --> Output Class Initialized
INFO - 2023-06-28 16:14:55 --> Security Class Initialized
DEBUG - 2023-06-28 16:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 16:14:55 --> Input Class Initialized
INFO - 2023-06-28 16:14:55 --> Language Class Initialized
INFO - 2023-06-28 16:14:55 --> Loader Class Initialized
INFO - 2023-06-28 16:14:55 --> Helper loaded: url_helper
INFO - 2023-06-28 16:14:55 --> Helper loaded: file_helper
INFO - 2023-06-28 16:14:55 --> Helper loaded: html_helper
INFO - 2023-06-28 16:14:55 --> Helper loaded: text_helper
INFO - 2023-06-28 16:14:55 --> Helper loaded: form_helper
INFO - 2023-06-28 16:14:55 --> Helper loaded: lang_helper
INFO - 2023-06-28 16:14:55 --> Helper loaded: security_helper
INFO - 2023-06-28 16:14:55 --> Helper loaded: cookie_helper
INFO - 2023-06-28 16:14:55 --> Database Driver Class Initialized
INFO - 2023-06-28 16:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 16:14:55 --> Parser Class Initialized
INFO - 2023-06-28 16:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 16:14:55 --> Pagination Class Initialized
INFO - 2023-06-28 16:14:55 --> Form Validation Class Initialized
INFO - 2023-06-28 16:14:55 --> Controller Class Initialized
DEBUG - 2023-06-28 16:14:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 16:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:14:55 --> Model Class Initialized
INFO - 2023-06-28 16:14:55 --> Model Class Initialized
INFO - 2023-06-28 22:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/customer_search.php
DEBUG - 2023-06-28 22:14:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 22:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 22:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 22:14:55 --> Model Class Initialized
INFO - 2023-06-28 22:14:55 --> Model Class Initialized
INFO - 2023-06-28 22:14:55 --> Model Class Initialized
INFO - 2023-06-28 22:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 22:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 22:14:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 22:14:55 --> Final output sent to browser
DEBUG - 2023-06-28 22:14:55 --> Total execution time: 0.1452
ERROR - 2023-06-28 16:15:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 16:15:10 --> Config Class Initialized
INFO - 2023-06-28 16:15:10 --> Hooks Class Initialized
DEBUG - 2023-06-28 16:15:10 --> UTF-8 Support Enabled
INFO - 2023-06-28 16:15:10 --> Utf8 Class Initialized
INFO - 2023-06-28 16:15:10 --> URI Class Initialized
INFO - 2023-06-28 16:15:10 --> Router Class Initialized
INFO - 2023-06-28 16:15:10 --> Output Class Initialized
INFO - 2023-06-28 16:15:10 --> Security Class Initialized
DEBUG - 2023-06-28 16:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 16:15:10 --> Input Class Initialized
INFO - 2023-06-28 16:15:10 --> Language Class Initialized
INFO - 2023-06-28 16:15:10 --> Loader Class Initialized
INFO - 2023-06-28 16:15:10 --> Helper loaded: url_helper
INFO - 2023-06-28 16:15:10 --> Helper loaded: file_helper
INFO - 2023-06-28 16:15:10 --> Helper loaded: html_helper
INFO - 2023-06-28 16:15:10 --> Helper loaded: text_helper
INFO - 2023-06-28 16:15:10 --> Helper loaded: form_helper
INFO - 2023-06-28 16:15:10 --> Helper loaded: lang_helper
INFO - 2023-06-28 16:15:10 --> Helper loaded: security_helper
INFO - 2023-06-28 16:15:10 --> Helper loaded: cookie_helper
INFO - 2023-06-28 16:15:10 --> Database Driver Class Initialized
INFO - 2023-06-28 16:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 16:15:10 --> Parser Class Initialized
INFO - 2023-06-28 16:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 16:15:10 --> Pagination Class Initialized
INFO - 2023-06-28 16:15:10 --> Form Validation Class Initialized
INFO - 2023-06-28 16:15:10 --> Controller Class Initialized
DEBUG - 2023-06-28 16:15:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 16:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:15:10 --> Model Class Initialized
INFO - 2023-06-28 16:15:10 --> Model Class Initialized
INFO - 2023-06-28 22:15:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/search/customer_search.php
DEBUG - 2023-06-28 22:15:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 22:15:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 22:15:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 22:15:10 --> Model Class Initialized
INFO - 2023-06-28 22:15:10 --> Model Class Initialized
INFO - 2023-06-28 22:15:10 --> Model Class Initialized
INFO - 2023-06-28 22:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 22:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 22:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 22:15:11 --> Final output sent to browser
DEBUG - 2023-06-28 22:15:11 --> Total execution time: 0.1378
ERROR - 2023-06-28 16:15:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 16:15:49 --> Config Class Initialized
INFO - 2023-06-28 16:15:49 --> Hooks Class Initialized
DEBUG - 2023-06-28 16:15:49 --> UTF-8 Support Enabled
INFO - 2023-06-28 16:15:49 --> Utf8 Class Initialized
INFO - 2023-06-28 16:15:49 --> URI Class Initialized
INFO - 2023-06-28 16:15:49 --> Router Class Initialized
INFO - 2023-06-28 16:15:49 --> Output Class Initialized
INFO - 2023-06-28 16:15:49 --> Security Class Initialized
DEBUG - 2023-06-28 16:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 16:15:49 --> Input Class Initialized
INFO - 2023-06-28 16:15:49 --> Language Class Initialized
INFO - 2023-06-28 16:15:49 --> Loader Class Initialized
INFO - 2023-06-28 16:15:49 --> Helper loaded: url_helper
INFO - 2023-06-28 16:15:49 --> Helper loaded: file_helper
INFO - 2023-06-28 16:15:49 --> Helper loaded: html_helper
INFO - 2023-06-28 16:15:49 --> Helper loaded: text_helper
INFO - 2023-06-28 16:15:49 --> Helper loaded: form_helper
INFO - 2023-06-28 16:15:49 --> Helper loaded: lang_helper
INFO - 2023-06-28 16:15:49 --> Helper loaded: security_helper
INFO - 2023-06-28 16:15:49 --> Helper loaded: cookie_helper
INFO - 2023-06-28 16:15:49 --> Database Driver Class Initialized
INFO - 2023-06-28 16:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 16:15:49 --> Parser Class Initialized
INFO - 2023-06-28 16:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 16:15:49 --> Pagination Class Initialized
INFO - 2023-06-28 16:15:49 --> Form Validation Class Initialized
INFO - 2023-06-28 16:15:49 --> Controller Class Initialized
DEBUG - 2023-06-28 16:15:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-28 16:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:15:49 --> Model Class Initialized
DEBUG - 2023-06-28 16:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:15:49 --> Model Class Initialized
INFO - 2023-06-28 16:15:49 --> Model Class Initialized
INFO - 2023-06-28 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer_ledger.php
DEBUG - 2023-06-28 16:15:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-28 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-28 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-28 16:15:49 --> Model Class Initialized
INFO - 2023-06-28 16:15:49 --> Model Class Initialized
INFO - 2023-06-28 16:15:49 --> Model Class Initialized
INFO - 2023-06-28 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-28 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-28 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-28 16:15:49 --> Final output sent to browser
DEBUG - 2023-06-28 16:15:49 --> Total execution time: 0.1501
ERROR - 2023-06-28 20:36:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 20:36:04 --> Config Class Initialized
INFO - 2023-06-28 20:36:04 --> Hooks Class Initialized
DEBUG - 2023-06-28 20:36:04 --> UTF-8 Support Enabled
INFO - 2023-06-28 20:36:04 --> Utf8 Class Initialized
INFO - 2023-06-28 20:36:04 --> URI Class Initialized
INFO - 2023-06-28 20:36:04 --> Router Class Initialized
INFO - 2023-06-28 20:36:04 --> Output Class Initialized
INFO - 2023-06-28 20:36:04 --> Security Class Initialized
DEBUG - 2023-06-28 20:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 20:36:04 --> Input Class Initialized
INFO - 2023-06-28 20:36:04 --> Language Class Initialized
ERROR - 2023-06-28 20:36:04 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-06-28 20:36:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-28 20:36:05 --> Config Class Initialized
INFO - 2023-06-28 20:36:05 --> Hooks Class Initialized
DEBUG - 2023-06-28 20:36:05 --> UTF-8 Support Enabled
INFO - 2023-06-28 20:36:05 --> Utf8 Class Initialized
INFO - 2023-06-28 20:36:05 --> URI Class Initialized
DEBUG - 2023-06-28 20:36:05 --> No URI present. Default controller set.
INFO - 2023-06-28 20:36:05 --> Router Class Initialized
INFO - 2023-06-28 20:36:05 --> Output Class Initialized
INFO - 2023-06-28 20:36:05 --> Security Class Initialized
DEBUG - 2023-06-28 20:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-28 20:36:05 --> Input Class Initialized
INFO - 2023-06-28 20:36:05 --> Language Class Initialized
INFO - 2023-06-28 20:36:05 --> Loader Class Initialized
INFO - 2023-06-28 20:36:05 --> Helper loaded: url_helper
INFO - 2023-06-28 20:36:05 --> Helper loaded: file_helper
INFO - 2023-06-28 20:36:05 --> Helper loaded: html_helper
INFO - 2023-06-28 20:36:05 --> Helper loaded: text_helper
INFO - 2023-06-28 20:36:05 --> Helper loaded: form_helper
INFO - 2023-06-28 20:36:05 --> Helper loaded: lang_helper
INFO - 2023-06-28 20:36:05 --> Helper loaded: security_helper
INFO - 2023-06-28 20:36:05 --> Helper loaded: cookie_helper
INFO - 2023-06-28 20:36:05 --> Database Driver Class Initialized
INFO - 2023-06-28 20:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-28 20:36:05 --> Parser Class Initialized
INFO - 2023-06-28 20:36:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-28 20:36:05 --> Pagination Class Initialized
INFO - 2023-06-28 20:36:05 --> Form Validation Class Initialized
INFO - 2023-06-28 20:36:05 --> Controller Class Initialized
INFO - 2023-06-28 20:36:05 --> Model Class Initialized
DEBUG - 2023-06-28 20:36:05 --> Session class already loaded. Second attempt ignored.
