<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-03 03:43:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:43:31 --> Config Class Initialized
INFO - 2023-06-03 03:43:31 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:43:31 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:43:31 --> Utf8 Class Initialized
INFO - 2023-06-03 03:43:31 --> URI Class Initialized
DEBUG - 2023-06-03 03:43:31 --> No URI present. Default controller set.
INFO - 2023-06-03 03:43:31 --> Router Class Initialized
INFO - 2023-06-03 03:43:31 --> Output Class Initialized
INFO - 2023-06-03 03:43:31 --> Security Class Initialized
DEBUG - 2023-06-03 03:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:43:31 --> Input Class Initialized
INFO - 2023-06-03 03:43:31 --> Language Class Initialized
INFO - 2023-06-03 03:43:31 --> Loader Class Initialized
INFO - 2023-06-03 03:43:31 --> Helper loaded: url_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: file_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: html_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: text_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: form_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: security_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:43:31 --> Database Driver Class Initialized
INFO - 2023-06-03 03:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:43:31 --> Parser Class Initialized
INFO - 2023-06-03 03:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:43:31 --> Pagination Class Initialized
INFO - 2023-06-03 03:43:31 --> Form Validation Class Initialized
INFO - 2023-06-03 03:43:31 --> Controller Class Initialized
INFO - 2023-06-03 03:43:31 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 03:43:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:43:31 --> Config Class Initialized
INFO - 2023-06-03 03:43:31 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:43:31 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:43:31 --> Utf8 Class Initialized
INFO - 2023-06-03 03:43:31 --> URI Class Initialized
INFO - 2023-06-03 03:43:31 --> Router Class Initialized
INFO - 2023-06-03 03:43:31 --> Output Class Initialized
INFO - 2023-06-03 03:43:31 --> Security Class Initialized
DEBUG - 2023-06-03 03:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:43:31 --> Input Class Initialized
INFO - 2023-06-03 03:43:31 --> Language Class Initialized
INFO - 2023-06-03 03:43:31 --> Loader Class Initialized
INFO - 2023-06-03 03:43:31 --> Helper loaded: url_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: file_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: html_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: text_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: form_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: security_helper
INFO - 2023-06-03 03:43:31 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:43:31 --> Database Driver Class Initialized
INFO - 2023-06-03 03:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:43:31 --> Parser Class Initialized
INFO - 2023-06-03 03:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:43:31 --> Pagination Class Initialized
INFO - 2023-06-03 03:43:31 --> Form Validation Class Initialized
INFO - 2023-06-03 03:43:31 --> Controller Class Initialized
INFO - 2023-06-03 03:43:31 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 03:43:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 03:43:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 03:43:31 --> Model Class Initialized
INFO - 2023-06-03 03:43:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 03:43:31 --> Final output sent to browser
DEBUG - 2023-06-03 03:43:31 --> Total execution time: 0.0312
ERROR - 2023-06-03 03:43:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:43:40 --> Config Class Initialized
INFO - 2023-06-03 03:43:40 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:43:40 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:43:40 --> Utf8 Class Initialized
INFO - 2023-06-03 03:43:40 --> URI Class Initialized
INFO - 2023-06-03 03:43:40 --> Router Class Initialized
INFO - 2023-06-03 03:43:40 --> Output Class Initialized
INFO - 2023-06-03 03:43:40 --> Security Class Initialized
DEBUG - 2023-06-03 03:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:43:40 --> Input Class Initialized
INFO - 2023-06-03 03:43:40 --> Language Class Initialized
INFO - 2023-06-03 03:43:40 --> Loader Class Initialized
INFO - 2023-06-03 03:43:40 --> Helper loaded: url_helper
INFO - 2023-06-03 03:43:40 --> Helper loaded: file_helper
INFO - 2023-06-03 03:43:40 --> Helper loaded: html_helper
INFO - 2023-06-03 03:43:40 --> Helper loaded: text_helper
INFO - 2023-06-03 03:43:40 --> Helper loaded: form_helper
INFO - 2023-06-03 03:43:40 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:43:40 --> Helper loaded: security_helper
INFO - 2023-06-03 03:43:40 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:43:40 --> Database Driver Class Initialized
INFO - 2023-06-03 03:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:43:40 --> Parser Class Initialized
INFO - 2023-06-03 03:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:43:40 --> Pagination Class Initialized
INFO - 2023-06-03 03:43:40 --> Form Validation Class Initialized
INFO - 2023-06-03 03:43:40 --> Controller Class Initialized
INFO - 2023-06-03 03:43:40 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:40 --> Model Class Initialized
INFO - 2023-06-03 03:43:40 --> Final output sent to browser
DEBUG - 2023-06-03 03:43:40 --> Total execution time: 0.0189
ERROR - 2023-06-03 03:43:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:43:41 --> Config Class Initialized
INFO - 2023-06-03 03:43:41 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:43:41 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:43:41 --> Utf8 Class Initialized
INFO - 2023-06-03 03:43:41 --> URI Class Initialized
DEBUG - 2023-06-03 03:43:41 --> No URI present. Default controller set.
INFO - 2023-06-03 03:43:41 --> Router Class Initialized
INFO - 2023-06-03 03:43:41 --> Output Class Initialized
INFO - 2023-06-03 03:43:41 --> Security Class Initialized
DEBUG - 2023-06-03 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:43:41 --> Input Class Initialized
INFO - 2023-06-03 03:43:41 --> Language Class Initialized
INFO - 2023-06-03 03:43:41 --> Loader Class Initialized
INFO - 2023-06-03 03:43:41 --> Helper loaded: url_helper
INFO - 2023-06-03 03:43:41 --> Helper loaded: file_helper
INFO - 2023-06-03 03:43:41 --> Helper loaded: html_helper
INFO - 2023-06-03 03:43:41 --> Helper loaded: text_helper
INFO - 2023-06-03 03:43:41 --> Helper loaded: form_helper
INFO - 2023-06-03 03:43:41 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:43:41 --> Helper loaded: security_helper
INFO - 2023-06-03 03:43:41 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:43:41 --> Database Driver Class Initialized
INFO - 2023-06-03 03:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:43:41 --> Parser Class Initialized
INFO - 2023-06-03 03:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:43:41 --> Pagination Class Initialized
INFO - 2023-06-03 03:43:41 --> Form Validation Class Initialized
INFO - 2023-06-03 03:43:41 --> Controller Class Initialized
INFO - 2023-06-03 03:43:41 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:41 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:41 --> Model Class Initialized
INFO - 2023-06-03 03:43:41 --> Model Class Initialized
INFO - 2023-06-03 03:43:41 --> Model Class Initialized
INFO - 2023-06-03 03:43:41 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 03:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:41 --> Model Class Initialized
INFO - 2023-06-03 03:43:41 --> Model Class Initialized
INFO - 2023-06-03 03:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 03:43:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 03:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 03:43:41 --> Model Class Initialized
INFO - 2023-06-03 03:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 03:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 03:43:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 03:43:41 --> Final output sent to browser
DEBUG - 2023-06-03 03:43:41 --> Total execution time: 0.0832
ERROR - 2023-06-03 03:43:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:43:55 --> Config Class Initialized
INFO - 2023-06-03 03:43:55 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:43:55 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:43:55 --> Utf8 Class Initialized
INFO - 2023-06-03 03:43:55 --> URI Class Initialized
INFO - 2023-06-03 03:43:55 --> Router Class Initialized
INFO - 2023-06-03 03:43:55 --> Output Class Initialized
INFO - 2023-06-03 03:43:55 --> Security Class Initialized
DEBUG - 2023-06-03 03:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:43:55 --> Input Class Initialized
INFO - 2023-06-03 03:43:55 --> Language Class Initialized
INFO - 2023-06-03 03:43:55 --> Loader Class Initialized
INFO - 2023-06-03 03:43:55 --> Helper loaded: url_helper
INFO - 2023-06-03 03:43:55 --> Helper loaded: file_helper
INFO - 2023-06-03 03:43:55 --> Helper loaded: html_helper
INFO - 2023-06-03 03:43:55 --> Helper loaded: text_helper
INFO - 2023-06-03 03:43:55 --> Helper loaded: form_helper
INFO - 2023-06-03 03:43:55 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:43:55 --> Helper loaded: security_helper
INFO - 2023-06-03 03:43:55 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:43:55 --> Database Driver Class Initialized
INFO - 2023-06-03 03:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:43:55 --> Parser Class Initialized
INFO - 2023-06-03 03:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:43:55 --> Pagination Class Initialized
INFO - 2023-06-03 03:43:55 --> Form Validation Class Initialized
INFO - 2023-06-03 03:43:55 --> Controller Class Initialized
INFO - 2023-06-03 03:43:55 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 03:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:55 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:55 --> Model Class Initialized
INFO - 2023-06-03 03:43:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-03 03:43:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 03:43:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 03:43:55 --> Model Class Initialized
INFO - 2023-06-03 03:43:56 --> Model Class Initialized
INFO - 2023-06-03 03:43:56 --> Model Class Initialized
INFO - 2023-06-03 03:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 03:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 03:43:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 03:43:56 --> Final output sent to browser
DEBUG - 2023-06-03 03:43:56 --> Total execution time: 0.0675
ERROR - 2023-06-03 03:43:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:43:56 --> Config Class Initialized
INFO - 2023-06-03 03:43:56 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:43:56 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:43:56 --> Utf8 Class Initialized
INFO - 2023-06-03 03:43:56 --> URI Class Initialized
INFO - 2023-06-03 03:43:56 --> Router Class Initialized
INFO - 2023-06-03 03:43:56 --> Output Class Initialized
INFO - 2023-06-03 03:43:56 --> Security Class Initialized
DEBUG - 2023-06-03 03:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:43:56 --> Input Class Initialized
INFO - 2023-06-03 03:43:56 --> Language Class Initialized
INFO - 2023-06-03 03:43:56 --> Loader Class Initialized
INFO - 2023-06-03 03:43:56 --> Helper loaded: url_helper
INFO - 2023-06-03 03:43:56 --> Helper loaded: file_helper
INFO - 2023-06-03 03:43:56 --> Helper loaded: html_helper
INFO - 2023-06-03 03:43:56 --> Helper loaded: text_helper
INFO - 2023-06-03 03:43:56 --> Helper loaded: form_helper
INFO - 2023-06-03 03:43:56 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:43:56 --> Helper loaded: security_helper
INFO - 2023-06-03 03:43:56 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:43:56 --> Database Driver Class Initialized
INFO - 2023-06-03 03:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:43:56 --> Parser Class Initialized
INFO - 2023-06-03 03:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:43:56 --> Pagination Class Initialized
INFO - 2023-06-03 03:43:56 --> Form Validation Class Initialized
INFO - 2023-06-03 03:43:56 --> Controller Class Initialized
INFO - 2023-06-03 03:43:56 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 03:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:56 --> Model Class Initialized
DEBUG - 2023-06-03 03:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:43:56 --> Model Class Initialized
INFO - 2023-06-03 03:43:56 --> Final output sent to browser
DEBUG - 2023-06-03 03:43:56 --> Total execution time: 0.0242
ERROR - 2023-06-03 03:44:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:44:04 --> Config Class Initialized
INFO - 2023-06-03 03:44:04 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:44:04 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:44:04 --> Utf8 Class Initialized
INFO - 2023-06-03 03:44:04 --> URI Class Initialized
DEBUG - 2023-06-03 03:44:04 --> No URI present. Default controller set.
INFO - 2023-06-03 03:44:04 --> Router Class Initialized
INFO - 2023-06-03 03:44:04 --> Output Class Initialized
INFO - 2023-06-03 03:44:04 --> Security Class Initialized
DEBUG - 2023-06-03 03:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:44:04 --> Input Class Initialized
INFO - 2023-06-03 03:44:04 --> Language Class Initialized
INFO - 2023-06-03 03:44:04 --> Loader Class Initialized
INFO - 2023-06-03 03:44:04 --> Helper loaded: url_helper
INFO - 2023-06-03 03:44:04 --> Helper loaded: file_helper
INFO - 2023-06-03 03:44:04 --> Helper loaded: html_helper
INFO - 2023-06-03 03:44:04 --> Helper loaded: text_helper
INFO - 2023-06-03 03:44:04 --> Helper loaded: form_helper
INFO - 2023-06-03 03:44:04 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:44:04 --> Helper loaded: security_helper
INFO - 2023-06-03 03:44:04 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:44:04 --> Database Driver Class Initialized
INFO - 2023-06-03 03:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:44:04 --> Parser Class Initialized
INFO - 2023-06-03 03:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:44:04 --> Pagination Class Initialized
INFO - 2023-06-03 03:44:04 --> Form Validation Class Initialized
INFO - 2023-06-03 03:44:04 --> Controller Class Initialized
INFO - 2023-06-03 03:44:04 --> Model Class Initialized
DEBUG - 2023-06-03 03:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:04 --> Model Class Initialized
DEBUG - 2023-06-03 03:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:04 --> Model Class Initialized
INFO - 2023-06-03 03:44:04 --> Model Class Initialized
INFO - 2023-06-03 03:44:04 --> Model Class Initialized
INFO - 2023-06-03 03:44:04 --> Model Class Initialized
DEBUG - 2023-06-03 03:44:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 03:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:04 --> Model Class Initialized
INFO - 2023-06-03 03:44:04 --> Model Class Initialized
INFO - 2023-06-03 03:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 03:44:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 03:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 03:44:04 --> Model Class Initialized
INFO - 2023-06-03 03:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 03:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 03:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 03:44:04 --> Final output sent to browser
DEBUG - 2023-06-03 03:44:04 --> Total execution time: 0.0642
ERROR - 2023-06-03 03:44:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:44:13 --> Config Class Initialized
INFO - 2023-06-03 03:44:13 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:44:13 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:44:13 --> Utf8 Class Initialized
INFO - 2023-06-03 03:44:13 --> URI Class Initialized
INFO - 2023-06-03 03:44:13 --> Router Class Initialized
INFO - 2023-06-03 03:44:13 --> Output Class Initialized
INFO - 2023-06-03 03:44:13 --> Security Class Initialized
DEBUG - 2023-06-03 03:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:44:13 --> Input Class Initialized
INFO - 2023-06-03 03:44:13 --> Language Class Initialized
INFO - 2023-06-03 03:44:13 --> Loader Class Initialized
INFO - 2023-06-03 03:44:13 --> Helper loaded: url_helper
INFO - 2023-06-03 03:44:13 --> Helper loaded: file_helper
INFO - 2023-06-03 03:44:13 --> Helper loaded: html_helper
INFO - 2023-06-03 03:44:13 --> Helper loaded: text_helper
INFO - 2023-06-03 03:44:13 --> Helper loaded: form_helper
INFO - 2023-06-03 03:44:13 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:44:13 --> Helper loaded: security_helper
INFO - 2023-06-03 03:44:13 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:44:13 --> Database Driver Class Initialized
INFO - 2023-06-03 03:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:44:13 --> Parser Class Initialized
INFO - 2023-06-03 03:44:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:44:13 --> Pagination Class Initialized
INFO - 2023-06-03 03:44:13 --> Form Validation Class Initialized
INFO - 2023-06-03 03:44:13 --> Controller Class Initialized
INFO - 2023-06-03 03:44:13 --> Model Class Initialized
INFO - 2023-06-03 03:44:13 --> Model Class Initialized
INFO - 2023-06-03 03:44:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-03 03:44:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 03:44:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 03:44:13 --> Model Class Initialized
INFO - 2023-06-03 03:44:13 --> Model Class Initialized
INFO - 2023-06-03 03:44:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 03:44:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 03:44:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 03:44:13 --> Final output sent to browser
DEBUG - 2023-06-03 03:44:13 --> Total execution time: 0.0565
ERROR - 2023-06-03 03:44:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:44:14 --> Config Class Initialized
INFO - 2023-06-03 03:44:14 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:44:14 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:44:14 --> Utf8 Class Initialized
INFO - 2023-06-03 03:44:14 --> URI Class Initialized
INFO - 2023-06-03 03:44:14 --> Router Class Initialized
INFO - 2023-06-03 03:44:14 --> Output Class Initialized
INFO - 2023-06-03 03:44:14 --> Security Class Initialized
DEBUG - 2023-06-03 03:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:44:14 --> Input Class Initialized
INFO - 2023-06-03 03:44:14 --> Language Class Initialized
INFO - 2023-06-03 03:44:14 --> Loader Class Initialized
INFO - 2023-06-03 03:44:14 --> Helper loaded: url_helper
INFO - 2023-06-03 03:44:14 --> Helper loaded: file_helper
INFO - 2023-06-03 03:44:14 --> Helper loaded: html_helper
INFO - 2023-06-03 03:44:14 --> Helper loaded: text_helper
INFO - 2023-06-03 03:44:14 --> Helper loaded: form_helper
INFO - 2023-06-03 03:44:14 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:44:14 --> Helper loaded: security_helper
INFO - 2023-06-03 03:44:14 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:44:14 --> Database Driver Class Initialized
INFO - 2023-06-03 03:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:44:14 --> Parser Class Initialized
INFO - 2023-06-03 03:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:44:14 --> Pagination Class Initialized
INFO - 2023-06-03 03:44:14 --> Form Validation Class Initialized
INFO - 2023-06-03 03:44:14 --> Controller Class Initialized
INFO - 2023-06-03 03:44:14 --> Model Class Initialized
INFO - 2023-06-03 03:44:14 --> Model Class Initialized
INFO - 2023-06-03 03:44:14 --> Final output sent to browser
DEBUG - 2023-06-03 03:44:14 --> Total execution time: 0.0301
ERROR - 2023-06-03 03:44:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:44:23 --> Config Class Initialized
INFO - 2023-06-03 03:44:23 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:44:23 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:44:23 --> Utf8 Class Initialized
INFO - 2023-06-03 03:44:23 --> URI Class Initialized
INFO - 2023-06-03 03:44:23 --> Router Class Initialized
INFO - 2023-06-03 03:44:23 --> Output Class Initialized
INFO - 2023-06-03 03:44:23 --> Security Class Initialized
DEBUG - 2023-06-03 03:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:44:23 --> Input Class Initialized
INFO - 2023-06-03 03:44:23 --> Language Class Initialized
INFO - 2023-06-03 03:44:23 --> Loader Class Initialized
INFO - 2023-06-03 03:44:23 --> Helper loaded: url_helper
INFO - 2023-06-03 03:44:23 --> Helper loaded: file_helper
INFO - 2023-06-03 03:44:23 --> Helper loaded: html_helper
INFO - 2023-06-03 03:44:23 --> Helper loaded: text_helper
INFO - 2023-06-03 03:44:23 --> Helper loaded: form_helper
INFO - 2023-06-03 03:44:23 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:44:23 --> Helper loaded: security_helper
INFO - 2023-06-03 03:44:23 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:44:23 --> Database Driver Class Initialized
INFO - 2023-06-03 03:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:44:23 --> Parser Class Initialized
INFO - 2023-06-03 03:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:44:23 --> Pagination Class Initialized
INFO - 2023-06-03 03:44:23 --> Form Validation Class Initialized
INFO - 2023-06-03 03:44:23 --> Controller Class Initialized
INFO - 2023-06-03 03:44:23 --> Model Class Initialized
INFO - 2023-06-03 03:44:23 --> Model Class Initialized
INFO - 2023-06-03 03:44:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-03 03:44:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 03:44:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 03:44:23 --> Model Class Initialized
INFO - 2023-06-03 03:44:23 --> Model Class Initialized
INFO - 2023-06-03 03:44:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 03:44:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 03:44:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 03:44:23 --> Final output sent to browser
DEBUG - 2023-06-03 03:44:23 --> Total execution time: 0.0536
ERROR - 2023-06-03 03:44:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:44:24 --> Config Class Initialized
INFO - 2023-06-03 03:44:24 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:44:24 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:44:24 --> Utf8 Class Initialized
INFO - 2023-06-03 03:44:24 --> URI Class Initialized
INFO - 2023-06-03 03:44:24 --> Router Class Initialized
INFO - 2023-06-03 03:44:24 --> Output Class Initialized
INFO - 2023-06-03 03:44:24 --> Security Class Initialized
DEBUG - 2023-06-03 03:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:44:24 --> Input Class Initialized
INFO - 2023-06-03 03:44:24 --> Language Class Initialized
INFO - 2023-06-03 03:44:24 --> Loader Class Initialized
INFO - 2023-06-03 03:44:24 --> Helper loaded: url_helper
INFO - 2023-06-03 03:44:24 --> Helper loaded: file_helper
INFO - 2023-06-03 03:44:24 --> Helper loaded: html_helper
INFO - 2023-06-03 03:44:24 --> Helper loaded: text_helper
INFO - 2023-06-03 03:44:24 --> Helper loaded: form_helper
INFO - 2023-06-03 03:44:24 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:44:24 --> Helper loaded: security_helper
INFO - 2023-06-03 03:44:24 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:44:24 --> Database Driver Class Initialized
INFO - 2023-06-03 03:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:44:24 --> Parser Class Initialized
INFO - 2023-06-03 03:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:44:24 --> Pagination Class Initialized
INFO - 2023-06-03 03:44:24 --> Form Validation Class Initialized
INFO - 2023-06-03 03:44:24 --> Controller Class Initialized
INFO - 2023-06-03 03:44:24 --> Model Class Initialized
INFO - 2023-06-03 03:44:24 --> Model Class Initialized
INFO - 2023-06-03 03:44:24 --> Final output sent to browser
DEBUG - 2023-06-03 03:44:24 --> Total execution time: 0.0172
ERROR - 2023-06-03 03:44:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:44:28 --> Config Class Initialized
INFO - 2023-06-03 03:44:28 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:44:28 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:44:28 --> Utf8 Class Initialized
INFO - 2023-06-03 03:44:28 --> URI Class Initialized
INFO - 2023-06-03 03:44:28 --> Router Class Initialized
INFO - 2023-06-03 03:44:28 --> Output Class Initialized
INFO - 2023-06-03 03:44:28 --> Security Class Initialized
DEBUG - 2023-06-03 03:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:44:28 --> Input Class Initialized
INFO - 2023-06-03 03:44:28 --> Language Class Initialized
INFO - 2023-06-03 03:44:28 --> Loader Class Initialized
INFO - 2023-06-03 03:44:28 --> Helper loaded: url_helper
INFO - 2023-06-03 03:44:28 --> Helper loaded: file_helper
INFO - 2023-06-03 03:44:28 --> Helper loaded: html_helper
INFO - 2023-06-03 03:44:28 --> Helper loaded: text_helper
INFO - 2023-06-03 03:44:28 --> Helper loaded: form_helper
INFO - 2023-06-03 03:44:28 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:44:28 --> Helper loaded: security_helper
INFO - 2023-06-03 03:44:28 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:44:28 --> Database Driver Class Initialized
INFO - 2023-06-03 03:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:44:28 --> Parser Class Initialized
INFO - 2023-06-03 03:44:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:44:28 --> Pagination Class Initialized
INFO - 2023-06-03 03:44:28 --> Form Validation Class Initialized
INFO - 2023-06-03 03:44:28 --> Controller Class Initialized
INFO - 2023-06-03 03:44:28 --> Model Class Initialized
INFO - 2023-06-03 03:44:28 --> Model Class Initialized
INFO - 2023-06-03 03:44:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-03 03:44:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 03:44:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 03:44:28 --> Model Class Initialized
INFO - 2023-06-03 03:44:28 --> Model Class Initialized
INFO - 2023-06-03 03:44:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 03:44:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 03:44:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 03:44:28 --> Final output sent to browser
DEBUG - 2023-06-03 03:44:28 --> Total execution time: 0.0584
ERROR - 2023-06-03 03:44:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:44:29 --> Config Class Initialized
INFO - 2023-06-03 03:44:29 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:44:29 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:44:29 --> Utf8 Class Initialized
INFO - 2023-06-03 03:44:29 --> URI Class Initialized
INFO - 2023-06-03 03:44:29 --> Router Class Initialized
INFO - 2023-06-03 03:44:29 --> Output Class Initialized
INFO - 2023-06-03 03:44:29 --> Security Class Initialized
DEBUG - 2023-06-03 03:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:44:29 --> Input Class Initialized
INFO - 2023-06-03 03:44:29 --> Language Class Initialized
INFO - 2023-06-03 03:44:29 --> Loader Class Initialized
INFO - 2023-06-03 03:44:29 --> Helper loaded: url_helper
INFO - 2023-06-03 03:44:29 --> Helper loaded: file_helper
INFO - 2023-06-03 03:44:29 --> Helper loaded: html_helper
INFO - 2023-06-03 03:44:29 --> Helper loaded: text_helper
INFO - 2023-06-03 03:44:29 --> Helper loaded: form_helper
INFO - 2023-06-03 03:44:29 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:44:29 --> Helper loaded: security_helper
INFO - 2023-06-03 03:44:29 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:44:29 --> Database Driver Class Initialized
INFO - 2023-06-03 03:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:44:29 --> Parser Class Initialized
INFO - 2023-06-03 03:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:44:29 --> Pagination Class Initialized
INFO - 2023-06-03 03:44:29 --> Form Validation Class Initialized
INFO - 2023-06-03 03:44:29 --> Controller Class Initialized
INFO - 2023-06-03 03:44:29 --> Model Class Initialized
INFO - 2023-06-03 03:44:29 --> Model Class Initialized
INFO - 2023-06-03 03:44:29 --> Final output sent to browser
DEBUG - 2023-06-03 03:44:29 --> Total execution time: 0.0325
ERROR - 2023-06-03 03:44:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 03:44:30 --> Config Class Initialized
INFO - 2023-06-03 03:44:30 --> Hooks Class Initialized
DEBUG - 2023-06-03 03:44:30 --> UTF-8 Support Enabled
INFO - 2023-06-03 03:44:30 --> Utf8 Class Initialized
INFO - 2023-06-03 03:44:30 --> URI Class Initialized
DEBUG - 2023-06-03 03:44:30 --> No URI present. Default controller set.
INFO - 2023-06-03 03:44:30 --> Router Class Initialized
INFO - 2023-06-03 03:44:30 --> Output Class Initialized
INFO - 2023-06-03 03:44:30 --> Security Class Initialized
DEBUG - 2023-06-03 03:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 03:44:30 --> Input Class Initialized
INFO - 2023-06-03 03:44:30 --> Language Class Initialized
INFO - 2023-06-03 03:44:30 --> Loader Class Initialized
INFO - 2023-06-03 03:44:30 --> Helper loaded: url_helper
INFO - 2023-06-03 03:44:30 --> Helper loaded: file_helper
INFO - 2023-06-03 03:44:30 --> Helper loaded: html_helper
INFO - 2023-06-03 03:44:30 --> Helper loaded: text_helper
INFO - 2023-06-03 03:44:30 --> Helper loaded: form_helper
INFO - 2023-06-03 03:44:30 --> Helper loaded: lang_helper
INFO - 2023-06-03 03:44:30 --> Helper loaded: security_helper
INFO - 2023-06-03 03:44:30 --> Helper loaded: cookie_helper
INFO - 2023-06-03 03:44:30 --> Database Driver Class Initialized
INFO - 2023-06-03 03:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 03:44:30 --> Parser Class Initialized
INFO - 2023-06-03 03:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 03:44:30 --> Pagination Class Initialized
INFO - 2023-06-03 03:44:30 --> Form Validation Class Initialized
INFO - 2023-06-03 03:44:30 --> Controller Class Initialized
INFO - 2023-06-03 03:44:30 --> Model Class Initialized
DEBUG - 2023-06-03 03:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:30 --> Model Class Initialized
DEBUG - 2023-06-03 03:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:30 --> Model Class Initialized
INFO - 2023-06-03 03:44:30 --> Model Class Initialized
INFO - 2023-06-03 03:44:30 --> Model Class Initialized
INFO - 2023-06-03 03:44:30 --> Model Class Initialized
DEBUG - 2023-06-03 03:44:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 03:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:30 --> Model Class Initialized
INFO - 2023-06-03 03:44:30 --> Model Class Initialized
INFO - 2023-06-03 03:44:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 03:44:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 03:44:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 03:44:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 03:44:30 --> Model Class Initialized
INFO - 2023-06-03 03:44:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 03:44:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 03:44:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 03:44:30 --> Final output sent to browser
DEBUG - 2023-06-03 03:44:30 --> Total execution time: 0.0641
ERROR - 2023-06-03 04:33:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 04:33:35 --> Config Class Initialized
INFO - 2023-06-03 04:33:35 --> Hooks Class Initialized
DEBUG - 2023-06-03 04:33:35 --> UTF-8 Support Enabled
INFO - 2023-06-03 04:33:35 --> Utf8 Class Initialized
INFO - 2023-06-03 04:33:35 --> URI Class Initialized
DEBUG - 2023-06-03 04:33:35 --> No URI present. Default controller set.
INFO - 2023-06-03 04:33:35 --> Router Class Initialized
INFO - 2023-06-03 04:33:35 --> Output Class Initialized
INFO - 2023-06-03 04:33:35 --> Security Class Initialized
DEBUG - 2023-06-03 04:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 04:33:35 --> Input Class Initialized
INFO - 2023-06-03 04:33:35 --> Language Class Initialized
INFO - 2023-06-03 04:33:35 --> Loader Class Initialized
INFO - 2023-06-03 04:33:35 --> Helper loaded: url_helper
INFO - 2023-06-03 04:33:35 --> Helper loaded: file_helper
INFO - 2023-06-03 04:33:35 --> Helper loaded: html_helper
INFO - 2023-06-03 04:33:35 --> Helper loaded: text_helper
INFO - 2023-06-03 04:33:35 --> Helper loaded: form_helper
INFO - 2023-06-03 04:33:35 --> Helper loaded: lang_helper
INFO - 2023-06-03 04:33:35 --> Helper loaded: security_helper
INFO - 2023-06-03 04:33:35 --> Helper loaded: cookie_helper
INFO - 2023-06-03 04:33:35 --> Database Driver Class Initialized
INFO - 2023-06-03 04:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 04:33:35 --> Parser Class Initialized
INFO - 2023-06-03 04:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 04:33:35 --> Pagination Class Initialized
INFO - 2023-06-03 04:33:35 --> Form Validation Class Initialized
INFO - 2023-06-03 04:33:35 --> Controller Class Initialized
INFO - 2023-06-03 04:33:35 --> Model Class Initialized
DEBUG - 2023-06-03 04:33:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 08:04:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:04:25 --> Config Class Initialized
INFO - 2023-06-03 08:04:25 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:04:25 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:04:25 --> Utf8 Class Initialized
INFO - 2023-06-03 08:04:25 --> URI Class Initialized
DEBUG - 2023-06-03 08:04:25 --> No URI present. Default controller set.
INFO - 2023-06-03 08:04:25 --> Router Class Initialized
INFO - 2023-06-03 08:04:25 --> Output Class Initialized
INFO - 2023-06-03 08:04:25 --> Security Class Initialized
DEBUG - 2023-06-03 08:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:04:25 --> Input Class Initialized
INFO - 2023-06-03 08:04:25 --> Language Class Initialized
INFO - 2023-06-03 08:04:25 --> Loader Class Initialized
INFO - 2023-06-03 08:04:25 --> Helper loaded: url_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: file_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: html_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: text_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: form_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: security_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:04:25 --> Database Driver Class Initialized
INFO - 2023-06-03 08:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:04:25 --> Parser Class Initialized
INFO - 2023-06-03 08:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:04:25 --> Pagination Class Initialized
INFO - 2023-06-03 08:04:25 --> Form Validation Class Initialized
INFO - 2023-06-03 08:04:25 --> Controller Class Initialized
INFO - 2023-06-03 08:04:25 --> Model Class Initialized
DEBUG - 2023-06-03 08:04:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 08:04:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:04:25 --> Config Class Initialized
INFO - 2023-06-03 08:04:25 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:04:25 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:04:25 --> Utf8 Class Initialized
INFO - 2023-06-03 08:04:25 --> URI Class Initialized
INFO - 2023-06-03 08:04:25 --> Router Class Initialized
INFO - 2023-06-03 08:04:25 --> Output Class Initialized
INFO - 2023-06-03 08:04:25 --> Security Class Initialized
DEBUG - 2023-06-03 08:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:04:25 --> Input Class Initialized
INFO - 2023-06-03 08:04:25 --> Language Class Initialized
INFO - 2023-06-03 08:04:25 --> Loader Class Initialized
INFO - 2023-06-03 08:04:25 --> Helper loaded: url_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: file_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: html_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: text_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: form_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: security_helper
INFO - 2023-06-03 08:04:25 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:04:25 --> Database Driver Class Initialized
INFO - 2023-06-03 08:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:04:25 --> Parser Class Initialized
INFO - 2023-06-03 08:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:04:25 --> Pagination Class Initialized
INFO - 2023-06-03 08:04:25 --> Form Validation Class Initialized
INFO - 2023-06-03 08:04:25 --> Controller Class Initialized
INFO - 2023-06-03 08:04:25 --> Model Class Initialized
DEBUG - 2023-06-03 08:04:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 08:04:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:04:25 --> Model Class Initialized
INFO - 2023-06-03 08:04:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:04:25 --> Final output sent to browser
DEBUG - 2023-06-03 08:04:25 --> Total execution time: 0.0318
ERROR - 2023-06-03 08:05:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:05:10 --> Config Class Initialized
INFO - 2023-06-03 08:05:10 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:05:10 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:05:10 --> Utf8 Class Initialized
INFO - 2023-06-03 08:05:10 --> URI Class Initialized
INFO - 2023-06-03 08:05:10 --> Router Class Initialized
INFO - 2023-06-03 08:05:10 --> Output Class Initialized
INFO - 2023-06-03 08:05:10 --> Security Class Initialized
DEBUG - 2023-06-03 08:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:05:10 --> Input Class Initialized
INFO - 2023-06-03 08:05:10 --> Language Class Initialized
INFO - 2023-06-03 08:05:10 --> Loader Class Initialized
INFO - 2023-06-03 08:05:10 --> Helper loaded: url_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: file_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: html_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: text_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: form_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: security_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:05:10 --> Database Driver Class Initialized
INFO - 2023-06-03 08:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:05:10 --> Parser Class Initialized
INFO - 2023-06-03 08:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:05:10 --> Pagination Class Initialized
INFO - 2023-06-03 08:05:10 --> Form Validation Class Initialized
INFO - 2023-06-03 08:05:10 --> Controller Class Initialized
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
DEBUG - 2023-06-03 08:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
INFO - 2023-06-03 08:05:10 --> Final output sent to browser
DEBUG - 2023-06-03 08:05:10 --> Total execution time: 0.0206
ERROR - 2023-06-03 08:05:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:05:10 --> Config Class Initialized
INFO - 2023-06-03 08:05:10 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:05:10 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:05:10 --> Utf8 Class Initialized
INFO - 2023-06-03 08:05:10 --> URI Class Initialized
DEBUG - 2023-06-03 08:05:10 --> No URI present. Default controller set.
INFO - 2023-06-03 08:05:10 --> Router Class Initialized
INFO - 2023-06-03 08:05:10 --> Output Class Initialized
INFO - 2023-06-03 08:05:10 --> Security Class Initialized
DEBUG - 2023-06-03 08:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:05:10 --> Input Class Initialized
INFO - 2023-06-03 08:05:10 --> Language Class Initialized
INFO - 2023-06-03 08:05:10 --> Loader Class Initialized
INFO - 2023-06-03 08:05:10 --> Helper loaded: url_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: file_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: html_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: text_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: form_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: security_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:05:10 --> Database Driver Class Initialized
INFO - 2023-06-03 08:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:05:10 --> Parser Class Initialized
INFO - 2023-06-03 08:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:05:10 --> Pagination Class Initialized
INFO - 2023-06-03 08:05:10 --> Form Validation Class Initialized
INFO - 2023-06-03 08:05:10 --> Controller Class Initialized
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
DEBUG - 2023-06-03 08:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
DEBUG - 2023-06-03 08:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
DEBUG - 2023-06-03 08:05:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
INFO - 2023-06-03 08:05:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 08:05:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:05:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
INFO - 2023-06-03 08:05:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:05:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:05:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:05:10 --> Final output sent to browser
DEBUG - 2023-06-03 08:05:10 --> Total execution time: 0.0852
ERROR - 2023-06-03 08:05:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:05:10 --> Config Class Initialized
INFO - 2023-06-03 08:05:10 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:05:10 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:05:10 --> Utf8 Class Initialized
INFO - 2023-06-03 08:05:10 --> URI Class Initialized
INFO - 2023-06-03 08:05:10 --> Router Class Initialized
INFO - 2023-06-03 08:05:10 --> Output Class Initialized
INFO - 2023-06-03 08:05:10 --> Security Class Initialized
DEBUG - 2023-06-03 08:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:05:10 --> Input Class Initialized
INFO - 2023-06-03 08:05:10 --> Language Class Initialized
INFO - 2023-06-03 08:05:10 --> Loader Class Initialized
INFO - 2023-06-03 08:05:10 --> Helper loaded: url_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: file_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: html_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: text_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: form_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: security_helper
INFO - 2023-06-03 08:05:10 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:05:10 --> Database Driver Class Initialized
INFO - 2023-06-03 08:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:05:10 --> Parser Class Initialized
INFO - 2023-06-03 08:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:05:10 --> Pagination Class Initialized
INFO - 2023-06-03 08:05:10 --> Form Validation Class Initialized
INFO - 2023-06-03 08:05:10 --> Controller Class Initialized
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
DEBUG - 2023-06-03 08:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:10 --> Model Class Initialized
INFO - 2023-06-03 08:05:10 --> Final output sent to browser
DEBUG - 2023-06-03 08:05:10 --> Total execution time: 0.0193
ERROR - 2023-06-03 08:05:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:05:11 --> Config Class Initialized
INFO - 2023-06-03 08:05:11 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:05:11 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:05:11 --> Utf8 Class Initialized
INFO - 2023-06-03 08:05:11 --> URI Class Initialized
DEBUG - 2023-06-03 08:05:11 --> No URI present. Default controller set.
INFO - 2023-06-03 08:05:11 --> Router Class Initialized
INFO - 2023-06-03 08:05:11 --> Output Class Initialized
INFO - 2023-06-03 08:05:11 --> Security Class Initialized
DEBUG - 2023-06-03 08:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:05:11 --> Input Class Initialized
INFO - 2023-06-03 08:05:11 --> Language Class Initialized
INFO - 2023-06-03 08:05:11 --> Loader Class Initialized
INFO - 2023-06-03 08:05:11 --> Helper loaded: url_helper
INFO - 2023-06-03 08:05:11 --> Helper loaded: file_helper
INFO - 2023-06-03 08:05:11 --> Helper loaded: html_helper
INFO - 2023-06-03 08:05:11 --> Helper loaded: text_helper
INFO - 2023-06-03 08:05:11 --> Helper loaded: form_helper
INFO - 2023-06-03 08:05:11 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:05:11 --> Helper loaded: security_helper
INFO - 2023-06-03 08:05:11 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:05:11 --> Database Driver Class Initialized
INFO - 2023-06-03 08:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:05:11 --> Parser Class Initialized
INFO - 2023-06-03 08:05:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:05:11 --> Pagination Class Initialized
INFO - 2023-06-03 08:05:11 --> Form Validation Class Initialized
INFO - 2023-06-03 08:05:11 --> Controller Class Initialized
INFO - 2023-06-03 08:05:11 --> Model Class Initialized
DEBUG - 2023-06-03 08:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:11 --> Model Class Initialized
DEBUG - 2023-06-03 08:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:11 --> Model Class Initialized
INFO - 2023-06-03 08:05:11 --> Model Class Initialized
INFO - 2023-06-03 08:05:11 --> Model Class Initialized
INFO - 2023-06-03 08:05:11 --> Model Class Initialized
DEBUG - 2023-06-03 08:05:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:11 --> Model Class Initialized
INFO - 2023-06-03 08:05:11 --> Model Class Initialized
INFO - 2023-06-03 08:05:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 08:05:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:05:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:05:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:05:11 --> Model Class Initialized
INFO - 2023-06-03 08:05:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:05:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:05:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:05:11 --> Final output sent to browser
DEBUG - 2023-06-03 08:05:11 --> Total execution time: 0.0815
ERROR - 2023-06-03 08:07:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:07:49 --> Config Class Initialized
INFO - 2023-06-03 08:07:49 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:07:49 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:07:49 --> Utf8 Class Initialized
INFO - 2023-06-03 08:07:49 --> URI Class Initialized
INFO - 2023-06-03 08:07:49 --> Router Class Initialized
INFO - 2023-06-03 08:07:49 --> Output Class Initialized
INFO - 2023-06-03 08:07:49 --> Security Class Initialized
DEBUG - 2023-06-03 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:07:49 --> Input Class Initialized
INFO - 2023-06-03 08:07:49 --> Language Class Initialized
INFO - 2023-06-03 08:07:49 --> Loader Class Initialized
INFO - 2023-06-03 08:07:49 --> Helper loaded: url_helper
INFO - 2023-06-03 08:07:49 --> Helper loaded: file_helper
INFO - 2023-06-03 08:07:49 --> Helper loaded: html_helper
INFO - 2023-06-03 08:07:49 --> Helper loaded: text_helper
INFO - 2023-06-03 08:07:49 --> Helper loaded: form_helper
INFO - 2023-06-03 08:07:49 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:07:49 --> Helper loaded: security_helper
INFO - 2023-06-03 08:07:49 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:07:49 --> Database Driver Class Initialized
INFO - 2023-06-03 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:07:49 --> Parser Class Initialized
INFO - 2023-06-03 08:07:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:07:49 --> Pagination Class Initialized
INFO - 2023-06-03 08:07:49 --> Form Validation Class Initialized
INFO - 2023-06-03 08:07:49 --> Controller Class Initialized
INFO - 2023-06-03 08:07:49 --> Model Class Initialized
DEBUG - 2023-06-03 08:07:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:49 --> Model Class Initialized
DEBUG - 2023-06-03 08:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:49 --> Model Class Initialized
INFO - 2023-06-03 08:07:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-03 08:07:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:07:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:07:50 --> Model Class Initialized
INFO - 2023-06-03 08:07:50 --> Model Class Initialized
INFO - 2023-06-03 08:07:50 --> Model Class Initialized
INFO - 2023-06-03 08:07:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:07:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:07:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:07:50 --> Final output sent to browser
DEBUG - 2023-06-03 08:07:50 --> Total execution time: 0.1008
ERROR - 2023-06-03 08:07:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:07:54 --> Config Class Initialized
INFO - 2023-06-03 08:07:54 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:07:54 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:07:54 --> Utf8 Class Initialized
INFO - 2023-06-03 08:07:54 --> URI Class Initialized
INFO - 2023-06-03 08:07:54 --> Router Class Initialized
INFO - 2023-06-03 08:07:54 --> Output Class Initialized
INFO - 2023-06-03 08:07:54 --> Security Class Initialized
DEBUG - 2023-06-03 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:07:54 --> Input Class Initialized
INFO - 2023-06-03 08:07:54 --> Language Class Initialized
INFO - 2023-06-03 08:07:54 --> Loader Class Initialized
INFO - 2023-06-03 08:07:54 --> Helper loaded: url_helper
INFO - 2023-06-03 08:07:54 --> Helper loaded: file_helper
INFO - 2023-06-03 08:07:54 --> Helper loaded: html_helper
INFO - 2023-06-03 08:07:54 --> Helper loaded: text_helper
INFO - 2023-06-03 08:07:54 --> Helper loaded: form_helper
INFO - 2023-06-03 08:07:54 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:07:54 --> Helper loaded: security_helper
INFO - 2023-06-03 08:07:54 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:07:54 --> Database Driver Class Initialized
INFO - 2023-06-03 08:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:07:54 --> Parser Class Initialized
INFO - 2023-06-03 08:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:07:54 --> Pagination Class Initialized
INFO - 2023-06-03 08:07:54 --> Form Validation Class Initialized
INFO - 2023-06-03 08:07:54 --> Controller Class Initialized
INFO - 2023-06-03 08:07:54 --> Model Class Initialized
DEBUG - 2023-06-03 08:07:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:54 --> Model Class Initialized
DEBUG - 2023-06-03 08:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:54 --> Model Class Initialized
INFO - 2023-06-03 08:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-03 08:07:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:07:54 --> Model Class Initialized
INFO - 2023-06-03 08:07:54 --> Model Class Initialized
INFO - 2023-06-03 08:07:54 --> Model Class Initialized
INFO - 2023-06-03 08:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:07:54 --> Final output sent to browser
DEBUG - 2023-06-03 08:07:54 --> Total execution time: 0.0721
ERROR - 2023-06-03 08:07:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:07:55 --> Config Class Initialized
INFO - 2023-06-03 08:07:55 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:07:55 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:07:55 --> Utf8 Class Initialized
INFO - 2023-06-03 08:07:55 --> URI Class Initialized
INFO - 2023-06-03 08:07:55 --> Router Class Initialized
INFO - 2023-06-03 08:07:55 --> Output Class Initialized
INFO - 2023-06-03 08:07:55 --> Security Class Initialized
DEBUG - 2023-06-03 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:07:55 --> Input Class Initialized
INFO - 2023-06-03 08:07:55 --> Language Class Initialized
INFO - 2023-06-03 08:07:55 --> Loader Class Initialized
INFO - 2023-06-03 08:07:55 --> Helper loaded: url_helper
INFO - 2023-06-03 08:07:55 --> Helper loaded: file_helper
INFO - 2023-06-03 08:07:55 --> Helper loaded: html_helper
INFO - 2023-06-03 08:07:55 --> Helper loaded: text_helper
INFO - 2023-06-03 08:07:55 --> Helper loaded: form_helper
INFO - 2023-06-03 08:07:55 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:07:55 --> Helper loaded: security_helper
INFO - 2023-06-03 08:07:55 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:07:55 --> Database Driver Class Initialized
INFO - 2023-06-03 08:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:07:55 --> Parser Class Initialized
INFO - 2023-06-03 08:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:07:55 --> Pagination Class Initialized
INFO - 2023-06-03 08:07:55 --> Form Validation Class Initialized
INFO - 2023-06-03 08:07:55 --> Controller Class Initialized
INFO - 2023-06-03 08:07:55 --> Model Class Initialized
DEBUG - 2023-06-03 08:07:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:55 --> Model Class Initialized
DEBUG - 2023-06-03 08:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:55 --> Model Class Initialized
INFO - 2023-06-03 08:07:55 --> Final output sent to browser
DEBUG - 2023-06-03 08:07:55 --> Total execution time: 0.0406
ERROR - 2023-06-03 08:07:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:07:58 --> Config Class Initialized
INFO - 2023-06-03 08:07:58 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:07:58 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:07:58 --> Utf8 Class Initialized
INFO - 2023-06-03 08:07:58 --> URI Class Initialized
INFO - 2023-06-03 08:07:58 --> Router Class Initialized
INFO - 2023-06-03 08:07:58 --> Output Class Initialized
INFO - 2023-06-03 08:07:58 --> Security Class Initialized
DEBUG - 2023-06-03 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:07:58 --> Input Class Initialized
INFO - 2023-06-03 08:07:58 --> Language Class Initialized
INFO - 2023-06-03 08:07:58 --> Loader Class Initialized
INFO - 2023-06-03 08:07:58 --> Helper loaded: url_helper
INFO - 2023-06-03 08:07:58 --> Helper loaded: file_helper
INFO - 2023-06-03 08:07:58 --> Helper loaded: html_helper
INFO - 2023-06-03 08:07:58 --> Helper loaded: text_helper
INFO - 2023-06-03 08:07:58 --> Helper loaded: form_helper
INFO - 2023-06-03 08:07:58 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:07:58 --> Helper loaded: security_helper
INFO - 2023-06-03 08:07:58 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:07:58 --> Database Driver Class Initialized
INFO - 2023-06-03 08:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:07:58 --> Parser Class Initialized
INFO - 2023-06-03 08:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:07:58 --> Pagination Class Initialized
INFO - 2023-06-03 08:07:58 --> Form Validation Class Initialized
INFO - 2023-06-03 08:07:58 --> Controller Class Initialized
INFO - 2023-06-03 08:07:58 --> Model Class Initialized
DEBUG - 2023-06-03 08:07:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:58 --> Model Class Initialized
DEBUG - 2023-06-03 08:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:07:58 --> Model Class Initialized
INFO - 2023-06-03 08:07:58 --> Final output sent to browser
DEBUG - 2023-06-03 08:07:58 --> Total execution time: 0.0402
ERROR - 2023-06-03 08:08:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:08:08 --> Config Class Initialized
INFO - 2023-06-03 08:08:08 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:08:08 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:08:08 --> Utf8 Class Initialized
INFO - 2023-06-03 08:08:08 --> URI Class Initialized
INFO - 2023-06-03 08:08:08 --> Router Class Initialized
INFO - 2023-06-03 08:08:08 --> Output Class Initialized
INFO - 2023-06-03 08:08:08 --> Security Class Initialized
DEBUG - 2023-06-03 08:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:08:08 --> Input Class Initialized
INFO - 2023-06-03 08:08:08 --> Language Class Initialized
INFO - 2023-06-03 08:08:08 --> Loader Class Initialized
INFO - 2023-06-03 08:08:08 --> Helper loaded: url_helper
INFO - 2023-06-03 08:08:08 --> Helper loaded: file_helper
INFO - 2023-06-03 08:08:08 --> Helper loaded: html_helper
INFO - 2023-06-03 08:08:08 --> Helper loaded: text_helper
INFO - 2023-06-03 08:08:08 --> Helper loaded: form_helper
INFO - 2023-06-03 08:08:08 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:08:08 --> Helper loaded: security_helper
INFO - 2023-06-03 08:08:08 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:08:08 --> Database Driver Class Initialized
INFO - 2023-06-03 08:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:08:08 --> Parser Class Initialized
INFO - 2023-06-03 08:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:08:08 --> Pagination Class Initialized
INFO - 2023-06-03 08:08:08 --> Form Validation Class Initialized
INFO - 2023-06-03 08:08:08 --> Controller Class Initialized
INFO - 2023-06-03 08:08:08 --> Model Class Initialized
DEBUG - 2023-06-03 08:08:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:08:08 --> Model Class Initialized
DEBUG - 2023-06-03 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:08:08 --> Model Class Initialized
DEBUG - 2023-06-03 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-03 08:08:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:08:08 --> Model Class Initialized
INFO - 2023-06-03 08:08:08 --> Model Class Initialized
INFO - 2023-06-03 08:08:08 --> Model Class Initialized
INFO - 2023-06-03 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:08:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:08:08 --> Final output sent to browser
DEBUG - 2023-06-03 08:08:08 --> Total execution time: 0.0738
ERROR - 2023-06-03 08:08:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:08:16 --> Config Class Initialized
INFO - 2023-06-03 08:08:16 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:08:16 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:08:16 --> Utf8 Class Initialized
INFO - 2023-06-03 08:08:16 --> URI Class Initialized
INFO - 2023-06-03 08:08:16 --> Router Class Initialized
INFO - 2023-06-03 08:08:16 --> Output Class Initialized
INFO - 2023-06-03 08:08:16 --> Security Class Initialized
DEBUG - 2023-06-03 08:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:08:16 --> Input Class Initialized
INFO - 2023-06-03 08:08:16 --> Language Class Initialized
INFO - 2023-06-03 08:08:16 --> Loader Class Initialized
INFO - 2023-06-03 08:08:16 --> Helper loaded: url_helper
INFO - 2023-06-03 08:08:16 --> Helper loaded: file_helper
INFO - 2023-06-03 08:08:16 --> Helper loaded: html_helper
INFO - 2023-06-03 08:08:16 --> Helper loaded: text_helper
INFO - 2023-06-03 08:08:16 --> Helper loaded: form_helper
INFO - 2023-06-03 08:08:16 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:08:16 --> Helper loaded: security_helper
INFO - 2023-06-03 08:08:16 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:08:16 --> Database Driver Class Initialized
INFO - 2023-06-03 08:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:08:16 --> Parser Class Initialized
INFO - 2023-06-03 08:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:08:16 --> Pagination Class Initialized
INFO - 2023-06-03 08:08:16 --> Form Validation Class Initialized
INFO - 2023-06-03 08:08:16 --> Controller Class Initialized
INFO - 2023-06-03 08:08:16 --> Model Class Initialized
DEBUG - 2023-06-03 08:08:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:08:16 --> Model Class Initialized
DEBUG - 2023-06-03 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:08:16 --> Model Class Initialized
INFO - 2023-06-03 08:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-03 08:08:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:08:16 --> Model Class Initialized
INFO - 2023-06-03 08:08:16 --> Model Class Initialized
INFO - 2023-06-03 08:08:16 --> Model Class Initialized
INFO - 2023-06-03 08:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:08:16 --> Final output sent to browser
DEBUG - 2023-06-03 08:08:16 --> Total execution time: 0.0858
ERROR - 2023-06-03 08:08:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:08:17 --> Config Class Initialized
INFO - 2023-06-03 08:08:17 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:08:17 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:08:17 --> Utf8 Class Initialized
INFO - 2023-06-03 08:08:17 --> URI Class Initialized
INFO - 2023-06-03 08:08:17 --> Router Class Initialized
INFO - 2023-06-03 08:08:17 --> Output Class Initialized
INFO - 2023-06-03 08:08:17 --> Security Class Initialized
DEBUG - 2023-06-03 08:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:08:17 --> Input Class Initialized
INFO - 2023-06-03 08:08:17 --> Language Class Initialized
INFO - 2023-06-03 08:08:17 --> Loader Class Initialized
INFO - 2023-06-03 08:08:17 --> Helper loaded: url_helper
INFO - 2023-06-03 08:08:17 --> Helper loaded: file_helper
INFO - 2023-06-03 08:08:17 --> Helper loaded: html_helper
INFO - 2023-06-03 08:08:17 --> Helper loaded: text_helper
INFO - 2023-06-03 08:08:17 --> Helper loaded: form_helper
INFO - 2023-06-03 08:08:17 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:08:17 --> Helper loaded: security_helper
INFO - 2023-06-03 08:08:17 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:08:17 --> Database Driver Class Initialized
INFO - 2023-06-03 08:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:08:17 --> Parser Class Initialized
INFO - 2023-06-03 08:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:08:17 --> Pagination Class Initialized
INFO - 2023-06-03 08:08:17 --> Form Validation Class Initialized
INFO - 2023-06-03 08:08:17 --> Controller Class Initialized
INFO - 2023-06-03 08:08:17 --> Model Class Initialized
DEBUG - 2023-06-03 08:08:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:08:17 --> Model Class Initialized
DEBUG - 2023-06-03 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:08:17 --> Model Class Initialized
INFO - 2023-06-03 08:08:17 --> Final output sent to browser
DEBUG - 2023-06-03 08:08:17 --> Total execution time: 0.0461
ERROR - 2023-06-03 08:38:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:19 --> Config Class Initialized
INFO - 2023-06-03 08:38:19 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:19 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:19 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:19 --> URI Class Initialized
DEBUG - 2023-06-03 08:38:19 --> No URI present. Default controller set.
INFO - 2023-06-03 08:38:19 --> Router Class Initialized
INFO - 2023-06-03 08:38:19 --> Output Class Initialized
INFO - 2023-06-03 08:38:19 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:19 --> Input Class Initialized
INFO - 2023-06-03 08:38:19 --> Language Class Initialized
INFO - 2023-06-03 08:38:19 --> Loader Class Initialized
INFO - 2023-06-03 08:38:19 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:19 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:19 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:19 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:19 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:19 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:19 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:19 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:19 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:19 --> Parser Class Initialized
INFO - 2023-06-03 08:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:19 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:19 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:19 --> Controller Class Initialized
INFO - 2023-06-03 08:38:19 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 08:38:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:20 --> Config Class Initialized
INFO - 2023-06-03 08:38:20 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:20 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:20 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:20 --> URI Class Initialized
INFO - 2023-06-03 08:38:20 --> Router Class Initialized
INFO - 2023-06-03 08:38:20 --> Output Class Initialized
INFO - 2023-06-03 08:38:20 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:20 --> Input Class Initialized
INFO - 2023-06-03 08:38:20 --> Language Class Initialized
INFO - 2023-06-03 08:38:20 --> Loader Class Initialized
INFO - 2023-06-03 08:38:20 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:20 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:20 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:20 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:20 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:20 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:20 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:20 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:20 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:20 --> Parser Class Initialized
INFO - 2023-06-03 08:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:20 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:20 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:20 --> Controller Class Initialized
INFO - 2023-06-03 08:38:20 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 08:38:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:38:20 --> Model Class Initialized
INFO - 2023-06-03 08:38:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:38:20 --> Final output sent to browser
DEBUG - 2023-06-03 08:38:20 --> Total execution time: 0.0351
ERROR - 2023-06-03 08:38:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:28 --> Config Class Initialized
INFO - 2023-06-03 08:38:28 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:28 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:28 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:28 --> URI Class Initialized
DEBUG - 2023-06-03 08:38:28 --> No URI present. Default controller set.
INFO - 2023-06-03 08:38:28 --> Router Class Initialized
INFO - 2023-06-03 08:38:28 --> Output Class Initialized
INFO - 2023-06-03 08:38:28 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:28 --> Input Class Initialized
INFO - 2023-06-03 08:38:28 --> Language Class Initialized
INFO - 2023-06-03 08:38:28 --> Loader Class Initialized
INFO - 2023-06-03 08:38:28 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:28 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:28 --> Parser Class Initialized
INFO - 2023-06-03 08:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:28 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:28 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:28 --> Controller Class Initialized
INFO - 2023-06-03 08:38:28 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 08:38:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:28 --> Config Class Initialized
INFO - 2023-06-03 08:38:28 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:28 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:28 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:28 --> URI Class Initialized
INFO - 2023-06-03 08:38:28 --> Router Class Initialized
INFO - 2023-06-03 08:38:28 --> Output Class Initialized
INFO - 2023-06-03 08:38:28 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:28 --> Input Class Initialized
INFO - 2023-06-03 08:38:28 --> Language Class Initialized
INFO - 2023-06-03 08:38:28 --> Loader Class Initialized
INFO - 2023-06-03 08:38:28 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:28 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:28 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:28 --> Parser Class Initialized
INFO - 2023-06-03 08:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:28 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:28 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:28 --> Controller Class Initialized
INFO - 2023-06-03 08:38:28 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 08:38:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:38:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:38:28 --> Model Class Initialized
INFO - 2023-06-03 08:38:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:38:28 --> Final output sent to browser
DEBUG - 2023-06-03 08:38:28 --> Total execution time: 0.0323
ERROR - 2023-06-03 08:38:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:29 --> Config Class Initialized
INFO - 2023-06-03 08:38:29 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:29 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:29 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:29 --> URI Class Initialized
INFO - 2023-06-03 08:38:29 --> Router Class Initialized
INFO - 2023-06-03 08:38:29 --> Output Class Initialized
INFO - 2023-06-03 08:38:29 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:29 --> Input Class Initialized
INFO - 2023-06-03 08:38:29 --> Language Class Initialized
ERROR - 2023-06-03 08:38:29 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-06-03 08:38:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:29 --> Config Class Initialized
INFO - 2023-06-03 08:38:29 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:29 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:29 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:29 --> URI Class Initialized
INFO - 2023-06-03 08:38:29 --> Router Class Initialized
INFO - 2023-06-03 08:38:29 --> Output Class Initialized
INFO - 2023-06-03 08:38:29 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:29 --> Input Class Initialized
INFO - 2023-06-03 08:38:29 --> Language Class Initialized
ERROR - 2023-06-03 08:38:29 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-06-03 08:38:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:33 --> Config Class Initialized
INFO - 2023-06-03 08:38:33 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:33 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:33 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:33 --> URI Class Initialized
INFO - 2023-06-03 08:38:33 --> Router Class Initialized
INFO - 2023-06-03 08:38:33 --> Output Class Initialized
INFO - 2023-06-03 08:38:33 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:33 --> Input Class Initialized
INFO - 2023-06-03 08:38:33 --> Language Class Initialized
INFO - 2023-06-03 08:38:33 --> Loader Class Initialized
INFO - 2023-06-03 08:38:33 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:33 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:33 --> Parser Class Initialized
INFO - 2023-06-03 08:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:33 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:33 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:33 --> Controller Class Initialized
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
INFO - 2023-06-03 08:38:33 --> Final output sent to browser
DEBUG - 2023-06-03 08:38:33 --> Total execution time: 0.0166
ERROR - 2023-06-03 08:38:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:33 --> Config Class Initialized
INFO - 2023-06-03 08:38:33 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:33 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:33 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:33 --> URI Class Initialized
DEBUG - 2023-06-03 08:38:33 --> No URI present. Default controller set.
INFO - 2023-06-03 08:38:33 --> Router Class Initialized
INFO - 2023-06-03 08:38:33 --> Output Class Initialized
INFO - 2023-06-03 08:38:33 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:33 --> Input Class Initialized
INFO - 2023-06-03 08:38:33 --> Language Class Initialized
INFO - 2023-06-03 08:38:33 --> Loader Class Initialized
INFO - 2023-06-03 08:38:33 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:33 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:33 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:33 --> Parser Class Initialized
INFO - 2023-06-03 08:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:33 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:33 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:33 --> Controller Class Initialized
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
INFO - 2023-06-03 08:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 08:38:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:38:33 --> Model Class Initialized
INFO - 2023-06-03 08:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:38:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:38:34 --> Final output sent to browser
DEBUG - 2023-06-03 08:38:34 --> Total execution time: 0.0772
ERROR - 2023-06-03 08:38:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:40 --> Config Class Initialized
INFO - 2023-06-03 08:38:40 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:40 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:40 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:40 --> URI Class Initialized
INFO - 2023-06-03 08:38:40 --> Router Class Initialized
INFO - 2023-06-03 08:38:40 --> Output Class Initialized
INFO - 2023-06-03 08:38:40 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:40 --> Input Class Initialized
INFO - 2023-06-03 08:38:40 --> Language Class Initialized
INFO - 2023-06-03 08:38:40 --> Loader Class Initialized
INFO - 2023-06-03 08:38:40 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:40 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:40 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:40 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:40 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:40 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:40 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:40 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:40 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:40 --> Parser Class Initialized
INFO - 2023-06-03 08:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:40 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:40 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:40 --> Controller Class Initialized
INFO - 2023-06-03 08:38:40 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:40 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:40 --> Model Class Initialized
INFO - 2023-06-03 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-03 08:38:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:38:40 --> Model Class Initialized
INFO - 2023-06-03 08:38:40 --> Model Class Initialized
INFO - 2023-06-03 08:38:40 --> Model Class Initialized
INFO - 2023-06-03 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:38:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:38:40 --> Final output sent to browser
DEBUG - 2023-06-03 08:38:40 --> Total execution time: 0.1040
ERROR - 2023-06-03 08:38:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:46 --> Config Class Initialized
INFO - 2023-06-03 08:38:46 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:46 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:46 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:46 --> URI Class Initialized
INFO - 2023-06-03 08:38:46 --> Router Class Initialized
INFO - 2023-06-03 08:38:46 --> Output Class Initialized
INFO - 2023-06-03 08:38:46 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:46 --> Input Class Initialized
INFO - 2023-06-03 08:38:46 --> Language Class Initialized
INFO - 2023-06-03 08:38:46 --> Loader Class Initialized
INFO - 2023-06-03 08:38:46 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:46 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:46 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:46 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:46 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:46 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:46 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:46 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:46 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:46 --> Parser Class Initialized
INFO - 2023-06-03 08:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:46 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:46 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:46 --> Controller Class Initialized
INFO - 2023-06-03 08:38:46 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:46 --> Final output sent to browser
DEBUG - 2023-06-03 08:38:46 --> Total execution time: 0.0158
ERROR - 2023-06-03 08:38:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:57 --> Config Class Initialized
INFO - 2023-06-03 08:38:57 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:57 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:57 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:57 --> URI Class Initialized
INFO - 2023-06-03 08:38:57 --> Router Class Initialized
INFO - 2023-06-03 08:38:57 --> Output Class Initialized
INFO - 2023-06-03 08:38:57 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:57 --> Input Class Initialized
INFO - 2023-06-03 08:38:57 --> Language Class Initialized
INFO - 2023-06-03 08:38:57 --> Loader Class Initialized
INFO - 2023-06-03 08:38:57 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:57 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:57 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:57 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:57 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:57 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:57 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:57 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:57 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:57 --> Parser Class Initialized
INFO - 2023-06-03 08:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:57 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:57 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:57 --> Controller Class Initialized
INFO - 2023-06-03 08:38:57 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:57 --> Final output sent to browser
DEBUG - 2023-06-03 08:38:57 --> Total execution time: 0.0199
ERROR - 2023-06-03 08:38:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:38:58 --> Config Class Initialized
INFO - 2023-06-03 08:38:58 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:38:58 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:38:58 --> Utf8 Class Initialized
INFO - 2023-06-03 08:38:58 --> URI Class Initialized
INFO - 2023-06-03 08:38:58 --> Router Class Initialized
INFO - 2023-06-03 08:38:58 --> Output Class Initialized
INFO - 2023-06-03 08:38:58 --> Security Class Initialized
DEBUG - 2023-06-03 08:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:38:58 --> Input Class Initialized
INFO - 2023-06-03 08:38:58 --> Language Class Initialized
INFO - 2023-06-03 08:38:58 --> Loader Class Initialized
INFO - 2023-06-03 08:38:58 --> Helper loaded: url_helper
INFO - 2023-06-03 08:38:58 --> Helper loaded: file_helper
INFO - 2023-06-03 08:38:58 --> Helper loaded: html_helper
INFO - 2023-06-03 08:38:58 --> Helper loaded: text_helper
INFO - 2023-06-03 08:38:58 --> Helper loaded: form_helper
INFO - 2023-06-03 08:38:58 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:38:58 --> Helper loaded: security_helper
INFO - 2023-06-03 08:38:58 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:38:58 --> Database Driver Class Initialized
INFO - 2023-06-03 08:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:38:58 --> Parser Class Initialized
INFO - 2023-06-03 08:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:38:58 --> Pagination Class Initialized
INFO - 2023-06-03 08:38:58 --> Form Validation Class Initialized
INFO - 2023-06-03 08:38:58 --> Controller Class Initialized
INFO - 2023-06-03 08:38:58 --> Model Class Initialized
DEBUG - 2023-06-03 08:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:38:58 --> Final output sent to browser
DEBUG - 2023-06-03 08:38:58 --> Total execution time: 0.0218
ERROR - 2023-06-03 08:39:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:01 --> Config Class Initialized
INFO - 2023-06-03 08:39:01 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:01 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:01 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:01 --> URI Class Initialized
INFO - 2023-06-03 08:39:01 --> Router Class Initialized
INFO - 2023-06-03 08:39:01 --> Output Class Initialized
INFO - 2023-06-03 08:39:01 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:01 --> Input Class Initialized
INFO - 2023-06-03 08:39:01 --> Language Class Initialized
INFO - 2023-06-03 08:39:01 --> Loader Class Initialized
INFO - 2023-06-03 08:39:01 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:01 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:01 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:01 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:01 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:01 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:01 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:01 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:01 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:01 --> Parser Class Initialized
INFO - 2023-06-03 08:39:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:01 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:01 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:01 --> Controller Class Initialized
INFO - 2023-06-03 08:39:01 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:01 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:01 --> Total execution time: 0.0150
ERROR - 2023-06-03 08:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:06 --> Config Class Initialized
INFO - 2023-06-03 08:39:06 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:06 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:06 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:06 --> URI Class Initialized
INFO - 2023-06-03 08:39:06 --> Router Class Initialized
INFO - 2023-06-03 08:39:06 --> Output Class Initialized
INFO - 2023-06-03 08:39:06 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:06 --> Input Class Initialized
INFO - 2023-06-03 08:39:06 --> Language Class Initialized
INFO - 2023-06-03 08:39:06 --> Loader Class Initialized
INFO - 2023-06-03 08:39:06 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:06 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:06 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:06 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:06 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:06 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:06 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:06 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:06 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:06 --> Parser Class Initialized
INFO - 2023-06-03 08:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:06 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:06 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:06 --> Controller Class Initialized
INFO - 2023-06-03 08:39:06 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:06 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:06 --> Total execution time: 0.0152
ERROR - 2023-06-03 08:39:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:07 --> Config Class Initialized
INFO - 2023-06-03 08:39:07 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:07 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:07 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:07 --> URI Class Initialized
INFO - 2023-06-03 08:39:07 --> Router Class Initialized
INFO - 2023-06-03 08:39:07 --> Output Class Initialized
INFO - 2023-06-03 08:39:07 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:07 --> Input Class Initialized
INFO - 2023-06-03 08:39:07 --> Language Class Initialized
INFO - 2023-06-03 08:39:07 --> Loader Class Initialized
INFO - 2023-06-03 08:39:07 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:07 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:07 --> Parser Class Initialized
INFO - 2023-06-03 08:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:07 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:07 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:07 --> Controller Class Initialized
INFO - 2023-06-03 08:39:07 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:07 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:07 --> Total execution time: 0.0154
ERROR - 2023-06-03 08:39:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:07 --> Config Class Initialized
INFO - 2023-06-03 08:39:07 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:07 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:07 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:07 --> URI Class Initialized
INFO - 2023-06-03 08:39:07 --> Router Class Initialized
INFO - 2023-06-03 08:39:07 --> Output Class Initialized
INFO - 2023-06-03 08:39:07 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:07 --> Input Class Initialized
INFO - 2023-06-03 08:39:07 --> Language Class Initialized
INFO - 2023-06-03 08:39:07 --> Loader Class Initialized
INFO - 2023-06-03 08:39:07 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:07 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:07 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:07 --> Parser Class Initialized
INFO - 2023-06-03 08:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:07 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:07 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:07 --> Controller Class Initialized
INFO - 2023-06-03 08:39:07 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:07 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:07 --> Total execution time: 0.0155
ERROR - 2023-06-03 08:39:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:13 --> Config Class Initialized
INFO - 2023-06-03 08:39:13 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:13 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:13 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:13 --> URI Class Initialized
INFO - 2023-06-03 08:39:13 --> Router Class Initialized
INFO - 2023-06-03 08:39:13 --> Output Class Initialized
INFO - 2023-06-03 08:39:13 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:13 --> Input Class Initialized
INFO - 2023-06-03 08:39:13 --> Language Class Initialized
INFO - 2023-06-03 08:39:13 --> Loader Class Initialized
INFO - 2023-06-03 08:39:13 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:13 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:13 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:13 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:13 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:13 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:13 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:13 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:13 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:13 --> Parser Class Initialized
INFO - 2023-06-03 08:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:13 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:13 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:13 --> Controller Class Initialized
INFO - 2023-06-03 08:39:13 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:13 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:13 --> Total execution time: 0.0146
ERROR - 2023-06-03 08:39:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:16 --> Config Class Initialized
INFO - 2023-06-03 08:39:16 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:16 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:16 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:16 --> URI Class Initialized
INFO - 2023-06-03 08:39:16 --> Router Class Initialized
INFO - 2023-06-03 08:39:16 --> Output Class Initialized
INFO - 2023-06-03 08:39:16 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:16 --> Input Class Initialized
INFO - 2023-06-03 08:39:16 --> Language Class Initialized
INFO - 2023-06-03 08:39:16 --> Loader Class Initialized
INFO - 2023-06-03 08:39:16 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:16 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:16 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:16 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:16 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:16 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:16 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:16 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:16 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:16 --> Parser Class Initialized
INFO - 2023-06-03 08:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:16 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:16 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:16 --> Controller Class Initialized
INFO - 2023-06-03 08:39:16 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:16 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:16 --> Total execution time: 0.0152
ERROR - 2023-06-03 08:39:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:26 --> Config Class Initialized
INFO - 2023-06-03 08:39:26 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:26 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:26 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:26 --> URI Class Initialized
INFO - 2023-06-03 08:39:26 --> Router Class Initialized
INFO - 2023-06-03 08:39:26 --> Output Class Initialized
INFO - 2023-06-03 08:39:26 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:26 --> Input Class Initialized
INFO - 2023-06-03 08:39:26 --> Language Class Initialized
INFO - 2023-06-03 08:39:26 --> Loader Class Initialized
INFO - 2023-06-03 08:39:26 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:26 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:26 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:26 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:26 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:26 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:26 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:26 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:26 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:26 --> Parser Class Initialized
INFO - 2023-06-03 08:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:26 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:26 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:26 --> Controller Class Initialized
INFO - 2023-06-03 08:39:26 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:26 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:26 --> Total execution time: 0.0154
ERROR - 2023-06-03 08:39:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:30 --> Config Class Initialized
INFO - 2023-06-03 08:39:30 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:30 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:30 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:30 --> URI Class Initialized
INFO - 2023-06-03 08:39:30 --> Router Class Initialized
INFO - 2023-06-03 08:39:30 --> Output Class Initialized
INFO - 2023-06-03 08:39:30 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:30 --> Input Class Initialized
INFO - 2023-06-03 08:39:30 --> Language Class Initialized
INFO - 2023-06-03 08:39:30 --> Loader Class Initialized
INFO - 2023-06-03 08:39:30 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:30 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:30 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:30 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:30 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:30 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:30 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:30 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:30 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:30 --> Parser Class Initialized
INFO - 2023-06-03 08:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:30 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:30 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:30 --> Controller Class Initialized
INFO - 2023-06-03 08:39:30 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:30 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:30 --> Total execution time: 0.0153
ERROR - 2023-06-03 08:39:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:31 --> Config Class Initialized
INFO - 2023-06-03 08:39:31 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:31 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:31 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:31 --> URI Class Initialized
INFO - 2023-06-03 08:39:31 --> Router Class Initialized
INFO - 2023-06-03 08:39:31 --> Output Class Initialized
INFO - 2023-06-03 08:39:31 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:31 --> Input Class Initialized
INFO - 2023-06-03 08:39:31 --> Language Class Initialized
INFO - 2023-06-03 08:39:31 --> Loader Class Initialized
INFO - 2023-06-03 08:39:31 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:31 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:31 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:31 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:31 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:31 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:31 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:31 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:31 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:31 --> Parser Class Initialized
INFO - 2023-06-03 08:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:31 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:31 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:31 --> Controller Class Initialized
INFO - 2023-06-03 08:39:31 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:31 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:31 --> Total execution time: 0.0154
ERROR - 2023-06-03 08:39:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:37 --> Config Class Initialized
INFO - 2023-06-03 08:39:37 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:37 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:37 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:37 --> URI Class Initialized
INFO - 2023-06-03 08:39:37 --> Router Class Initialized
INFO - 2023-06-03 08:39:37 --> Output Class Initialized
INFO - 2023-06-03 08:39:37 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:37 --> Input Class Initialized
INFO - 2023-06-03 08:39:37 --> Language Class Initialized
INFO - 2023-06-03 08:39:37 --> Loader Class Initialized
INFO - 2023-06-03 08:39:37 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:37 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:37 --> Parser Class Initialized
INFO - 2023-06-03 08:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:37 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:37 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:37 --> Controller Class Initialized
INFO - 2023-06-03 08:39:37 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:37 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:37 --> Total execution time: 0.0189
ERROR - 2023-06-03 08:39:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:37 --> Config Class Initialized
INFO - 2023-06-03 08:39:37 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:37 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:37 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:37 --> URI Class Initialized
INFO - 2023-06-03 08:39:37 --> Router Class Initialized
INFO - 2023-06-03 08:39:37 --> Output Class Initialized
INFO - 2023-06-03 08:39:37 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:37 --> Input Class Initialized
INFO - 2023-06-03 08:39:37 --> Language Class Initialized
INFO - 2023-06-03 08:39:37 --> Loader Class Initialized
INFO - 2023-06-03 08:39:37 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:37 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:37 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:37 --> Parser Class Initialized
INFO - 2023-06-03 08:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:37 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:37 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:37 --> Controller Class Initialized
INFO - 2023-06-03 08:39:37 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:37 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:37 --> Total execution time: 0.0162
ERROR - 2023-06-03 08:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:41 --> Config Class Initialized
INFO - 2023-06-03 08:39:41 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:41 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:41 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:41 --> URI Class Initialized
INFO - 2023-06-03 08:39:41 --> Router Class Initialized
INFO - 2023-06-03 08:39:41 --> Output Class Initialized
INFO - 2023-06-03 08:39:41 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:41 --> Input Class Initialized
INFO - 2023-06-03 08:39:41 --> Language Class Initialized
INFO - 2023-06-03 08:39:41 --> Loader Class Initialized
INFO - 2023-06-03 08:39:41 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:41 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:41 --> Parser Class Initialized
INFO - 2023-06-03 08:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:41 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:41 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:41 --> Controller Class Initialized
INFO - 2023-06-03 08:39:41 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:41 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:41 --> Total execution time: 0.0162
ERROR - 2023-06-03 08:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:41 --> Config Class Initialized
INFO - 2023-06-03 08:39:41 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:41 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:41 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:41 --> URI Class Initialized
INFO - 2023-06-03 08:39:41 --> Router Class Initialized
INFO - 2023-06-03 08:39:41 --> Output Class Initialized
INFO - 2023-06-03 08:39:41 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:41 --> Input Class Initialized
INFO - 2023-06-03 08:39:41 --> Language Class Initialized
INFO - 2023-06-03 08:39:41 --> Loader Class Initialized
INFO - 2023-06-03 08:39:41 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:41 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:41 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:41 --> Parser Class Initialized
INFO - 2023-06-03 08:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:41 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:41 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:41 --> Controller Class Initialized
INFO - 2023-06-03 08:39:41 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:41 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:41 --> Total execution time: 0.0181
ERROR - 2023-06-03 08:39:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:46 --> Config Class Initialized
INFO - 2023-06-03 08:39:46 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:46 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:46 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:46 --> URI Class Initialized
INFO - 2023-06-03 08:39:46 --> Router Class Initialized
INFO - 2023-06-03 08:39:46 --> Output Class Initialized
INFO - 2023-06-03 08:39:46 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:46 --> Input Class Initialized
INFO - 2023-06-03 08:39:46 --> Language Class Initialized
INFO - 2023-06-03 08:39:46 --> Loader Class Initialized
INFO - 2023-06-03 08:39:46 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:46 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:46 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:46 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:46 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:46 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:46 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:46 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:46 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:46 --> Parser Class Initialized
INFO - 2023-06-03 08:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:46 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:46 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:46 --> Controller Class Initialized
INFO - 2023-06-03 08:39:46 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:46 --> Total execution time: 0.0133
ERROR - 2023-06-03 08:39:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:48 --> Config Class Initialized
INFO - 2023-06-03 08:39:48 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:48 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:48 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:48 --> URI Class Initialized
INFO - 2023-06-03 08:39:48 --> Router Class Initialized
INFO - 2023-06-03 08:39:48 --> Output Class Initialized
INFO - 2023-06-03 08:39:48 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:48 --> Input Class Initialized
INFO - 2023-06-03 08:39:48 --> Language Class Initialized
INFO - 2023-06-03 08:39:48 --> Loader Class Initialized
INFO - 2023-06-03 08:39:48 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:48 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:48 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:48 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:48 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:48 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:48 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:48 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:48 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:48 --> Parser Class Initialized
INFO - 2023-06-03 08:39:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:48 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:48 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:48 --> Controller Class Initialized
INFO - 2023-06-03 08:39:48 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:48 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:48 --> Total execution time: 0.0206
ERROR - 2023-06-03 08:39:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:50 --> Config Class Initialized
INFO - 2023-06-03 08:39:50 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:50 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:50 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:50 --> URI Class Initialized
INFO - 2023-06-03 08:39:50 --> Router Class Initialized
INFO - 2023-06-03 08:39:50 --> Output Class Initialized
INFO - 2023-06-03 08:39:50 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:50 --> Input Class Initialized
INFO - 2023-06-03 08:39:50 --> Language Class Initialized
INFO - 2023-06-03 08:39:50 --> Loader Class Initialized
INFO - 2023-06-03 08:39:50 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:50 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:50 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:50 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:50 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:50 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:50 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:50 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:50 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:50 --> Parser Class Initialized
INFO - 2023-06-03 08:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:50 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:50 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:50 --> Controller Class Initialized
INFO - 2023-06-03 08:39:50 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:50 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:50 --> Total execution time: 0.0229
ERROR - 2023-06-03 08:39:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:51 --> Config Class Initialized
INFO - 2023-06-03 08:39:51 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:51 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:51 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:51 --> URI Class Initialized
INFO - 2023-06-03 08:39:51 --> Router Class Initialized
INFO - 2023-06-03 08:39:51 --> Output Class Initialized
INFO - 2023-06-03 08:39:51 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:51 --> Input Class Initialized
INFO - 2023-06-03 08:39:51 --> Language Class Initialized
INFO - 2023-06-03 08:39:51 --> Loader Class Initialized
INFO - 2023-06-03 08:39:51 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:51 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:51 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:51 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:51 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:51 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:51 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:51 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:51 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:51 --> Parser Class Initialized
INFO - 2023-06-03 08:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:51 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:51 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:51 --> Controller Class Initialized
INFO - 2023-06-03 08:39:51 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:51 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:51 --> Total execution time: 0.0160
ERROR - 2023-06-03 08:39:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:39:54 --> Config Class Initialized
INFO - 2023-06-03 08:39:54 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:39:54 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:39:54 --> Utf8 Class Initialized
INFO - 2023-06-03 08:39:54 --> URI Class Initialized
INFO - 2023-06-03 08:39:54 --> Router Class Initialized
INFO - 2023-06-03 08:39:54 --> Output Class Initialized
INFO - 2023-06-03 08:39:54 --> Security Class Initialized
DEBUG - 2023-06-03 08:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:39:54 --> Input Class Initialized
INFO - 2023-06-03 08:39:54 --> Language Class Initialized
INFO - 2023-06-03 08:39:54 --> Loader Class Initialized
INFO - 2023-06-03 08:39:54 --> Helper loaded: url_helper
INFO - 2023-06-03 08:39:54 --> Helper loaded: file_helper
INFO - 2023-06-03 08:39:54 --> Helper loaded: html_helper
INFO - 2023-06-03 08:39:54 --> Helper loaded: text_helper
INFO - 2023-06-03 08:39:54 --> Helper loaded: form_helper
INFO - 2023-06-03 08:39:54 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:39:54 --> Helper loaded: security_helper
INFO - 2023-06-03 08:39:54 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:39:54 --> Database Driver Class Initialized
INFO - 2023-06-03 08:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:39:54 --> Parser Class Initialized
INFO - 2023-06-03 08:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:39:54 --> Pagination Class Initialized
INFO - 2023-06-03 08:39:54 --> Form Validation Class Initialized
INFO - 2023-06-03 08:39:54 --> Controller Class Initialized
INFO - 2023-06-03 08:39:54 --> Model Class Initialized
DEBUG - 2023-06-03 08:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:39:54 --> Final output sent to browser
DEBUG - 2023-06-03 08:39:54 --> Total execution time: 0.0156
ERROR - 2023-06-03 08:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:03 --> Config Class Initialized
INFO - 2023-06-03 08:40:03 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:03 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:03 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:03 --> URI Class Initialized
INFO - 2023-06-03 08:40:03 --> Router Class Initialized
INFO - 2023-06-03 08:40:03 --> Output Class Initialized
INFO - 2023-06-03 08:40:03 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:03 --> Input Class Initialized
INFO - 2023-06-03 08:40:03 --> Language Class Initialized
INFO - 2023-06-03 08:40:03 --> Loader Class Initialized
INFO - 2023-06-03 08:40:03 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:03 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:03 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:03 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:03 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:03 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:03 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:03 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:03 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:03 --> Parser Class Initialized
INFO - 2023-06-03 08:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:03 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:03 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:03 --> Controller Class Initialized
INFO - 2023-06-03 08:40:03 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:03 --> Total execution time: 0.0185
ERROR - 2023-06-03 08:40:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:05 --> Config Class Initialized
INFO - 2023-06-03 08:40:05 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:05 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:05 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:05 --> URI Class Initialized
INFO - 2023-06-03 08:40:05 --> Router Class Initialized
INFO - 2023-06-03 08:40:05 --> Output Class Initialized
INFO - 2023-06-03 08:40:05 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:05 --> Input Class Initialized
INFO - 2023-06-03 08:40:05 --> Language Class Initialized
INFO - 2023-06-03 08:40:05 --> Loader Class Initialized
INFO - 2023-06-03 08:40:05 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:05 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:05 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:05 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:05 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:05 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:05 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:05 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:05 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:05 --> Parser Class Initialized
INFO - 2023-06-03 08:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:05 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:05 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:05 --> Controller Class Initialized
INFO - 2023-06-03 08:40:05 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:05 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:05 --> Model Class Initialized
INFO - 2023-06-03 08:40:05 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:05 --> Total execution time: 0.0454
ERROR - 2023-06-03 08:40:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:07 --> Config Class Initialized
INFO - 2023-06-03 08:40:07 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:07 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:07 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:07 --> URI Class Initialized
INFO - 2023-06-03 08:40:07 --> Router Class Initialized
INFO - 2023-06-03 08:40:07 --> Output Class Initialized
INFO - 2023-06-03 08:40:07 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:07 --> Input Class Initialized
INFO - 2023-06-03 08:40:07 --> Language Class Initialized
INFO - 2023-06-03 08:40:07 --> Loader Class Initialized
INFO - 2023-06-03 08:40:07 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:07 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:07 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:07 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:07 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:07 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:07 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:07 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:07 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:07 --> Parser Class Initialized
INFO - 2023-06-03 08:40:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:07 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:07 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:07 --> Controller Class Initialized
INFO - 2023-06-03 08:40:07 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:07 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:07 --> Model Class Initialized
INFO - 2023-06-03 08:40:07 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:07 --> Total execution time: 0.0444
ERROR - 2023-06-03 08:40:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:08 --> Config Class Initialized
INFO - 2023-06-03 08:40:08 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:08 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:08 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:08 --> URI Class Initialized
INFO - 2023-06-03 08:40:08 --> Router Class Initialized
INFO - 2023-06-03 08:40:08 --> Output Class Initialized
INFO - 2023-06-03 08:40:08 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:08 --> Input Class Initialized
INFO - 2023-06-03 08:40:08 --> Language Class Initialized
INFO - 2023-06-03 08:40:08 --> Loader Class Initialized
INFO - 2023-06-03 08:40:08 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:08 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:08 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:08 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:08 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:08 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:08 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:08 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:08 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:08 --> Parser Class Initialized
INFO - 2023-06-03 08:40:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:08 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:08 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:08 --> Controller Class Initialized
INFO - 2023-06-03 08:40:08 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:08 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:08 --> Model Class Initialized
INFO - 2023-06-03 08:40:08 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:08 --> Total execution time: 0.0269
ERROR - 2023-06-03 08:40:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:10 --> Config Class Initialized
INFO - 2023-06-03 08:40:10 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:10 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:10 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:10 --> URI Class Initialized
INFO - 2023-06-03 08:40:10 --> Router Class Initialized
INFO - 2023-06-03 08:40:10 --> Output Class Initialized
INFO - 2023-06-03 08:40:10 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:10 --> Input Class Initialized
INFO - 2023-06-03 08:40:10 --> Language Class Initialized
INFO - 2023-06-03 08:40:10 --> Loader Class Initialized
INFO - 2023-06-03 08:40:10 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:10 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:10 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:10 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:10 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:10 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:10 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:10 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:10 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:10 --> Parser Class Initialized
INFO - 2023-06-03 08:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:10 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:10 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:10 --> Controller Class Initialized
INFO - 2023-06-03 08:40:10 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:10 --> Model Class Initialized
INFO - 2023-06-03 08:40:10 --> Model Class Initialized
INFO - 2023-06-03 08:40:10 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:10 --> Total execution time: 0.0193
ERROR - 2023-06-03 08:40:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:12 --> Config Class Initialized
INFO - 2023-06-03 08:40:12 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:12 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:12 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:12 --> URI Class Initialized
INFO - 2023-06-03 08:40:12 --> Router Class Initialized
INFO - 2023-06-03 08:40:12 --> Output Class Initialized
INFO - 2023-06-03 08:40:12 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:12 --> Input Class Initialized
INFO - 2023-06-03 08:40:12 --> Language Class Initialized
INFO - 2023-06-03 08:40:12 --> Loader Class Initialized
INFO - 2023-06-03 08:40:12 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:12 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:12 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:12 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:12 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:12 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:12 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:12 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:12 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:12 --> Parser Class Initialized
INFO - 2023-06-03 08:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:12 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:12 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:12 --> Controller Class Initialized
INFO - 2023-06-03 08:40:12 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:12 --> Model Class Initialized
INFO - 2023-06-03 08:40:12 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:12 --> Total execution time: 0.0161
ERROR - 2023-06-03 08:40:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:17 --> Config Class Initialized
INFO - 2023-06-03 08:40:17 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:17 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:17 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:17 --> URI Class Initialized
INFO - 2023-06-03 08:40:17 --> Router Class Initialized
INFO - 2023-06-03 08:40:17 --> Output Class Initialized
INFO - 2023-06-03 08:40:17 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:17 --> Input Class Initialized
INFO - 2023-06-03 08:40:17 --> Language Class Initialized
INFO - 2023-06-03 08:40:17 --> Loader Class Initialized
INFO - 2023-06-03 08:40:17 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:17 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:17 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:17 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:17 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:17 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:17 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:17 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:17 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:17 --> Parser Class Initialized
INFO - 2023-06-03 08:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:17 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:17 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:17 --> Controller Class Initialized
INFO - 2023-06-03 08:40:17 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:17 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:17 --> Model Class Initialized
INFO - 2023-06-03 08:40:17 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:17 --> Total execution time: 0.0440
ERROR - 2023-06-03 08:40:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:18 --> Config Class Initialized
INFO - 2023-06-03 08:40:18 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:18 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:18 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:18 --> URI Class Initialized
INFO - 2023-06-03 08:40:18 --> Router Class Initialized
INFO - 2023-06-03 08:40:18 --> Output Class Initialized
INFO - 2023-06-03 08:40:18 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:18 --> Input Class Initialized
INFO - 2023-06-03 08:40:18 --> Language Class Initialized
INFO - 2023-06-03 08:40:18 --> Loader Class Initialized
INFO - 2023-06-03 08:40:18 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:18 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:18 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:18 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:18 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:18 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:18 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:18 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:18 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:18 --> Parser Class Initialized
INFO - 2023-06-03 08:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:18 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:18 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:18 --> Controller Class Initialized
INFO - 2023-06-03 08:40:18 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:18 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:18 --> Model Class Initialized
INFO - 2023-06-03 08:40:18 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:18 --> Total execution time: 0.0190
ERROR - 2023-06-03 08:40:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:20 --> Config Class Initialized
INFO - 2023-06-03 08:40:20 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:20 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:20 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:20 --> URI Class Initialized
INFO - 2023-06-03 08:40:20 --> Router Class Initialized
INFO - 2023-06-03 08:40:20 --> Output Class Initialized
INFO - 2023-06-03 08:40:20 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:20 --> Input Class Initialized
INFO - 2023-06-03 08:40:20 --> Language Class Initialized
INFO - 2023-06-03 08:40:20 --> Loader Class Initialized
INFO - 2023-06-03 08:40:20 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:20 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:20 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:20 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:20 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:20 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:20 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:20 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:20 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:20 --> Parser Class Initialized
INFO - 2023-06-03 08:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:20 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:20 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:20 --> Controller Class Initialized
INFO - 2023-06-03 08:40:20 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:20 --> Model Class Initialized
INFO - 2023-06-03 08:40:20 --> Model Class Initialized
INFO - 2023-06-03 08:40:20 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:20 --> Total execution time: 0.0216
ERROR - 2023-06-03 08:40:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:22 --> Config Class Initialized
INFO - 2023-06-03 08:40:22 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:22 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:22 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:22 --> URI Class Initialized
INFO - 2023-06-03 08:40:22 --> Router Class Initialized
INFO - 2023-06-03 08:40:22 --> Output Class Initialized
INFO - 2023-06-03 08:40:22 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:22 --> Input Class Initialized
INFO - 2023-06-03 08:40:22 --> Language Class Initialized
INFO - 2023-06-03 08:40:22 --> Loader Class Initialized
INFO - 2023-06-03 08:40:22 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:22 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:22 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:22 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:22 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:22 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:22 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:22 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:22 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:22 --> Parser Class Initialized
INFO - 2023-06-03 08:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:22 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:22 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:22 --> Controller Class Initialized
INFO - 2023-06-03 08:40:22 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:22 --> Model Class Initialized
INFO - 2023-06-03 08:40:22 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:22 --> Total execution time: 0.0169
ERROR - 2023-06-03 08:40:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:33 --> Config Class Initialized
INFO - 2023-06-03 08:40:33 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:33 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:33 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:33 --> URI Class Initialized
INFO - 2023-06-03 08:40:33 --> Router Class Initialized
INFO - 2023-06-03 08:40:33 --> Output Class Initialized
INFO - 2023-06-03 08:40:33 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:33 --> Input Class Initialized
INFO - 2023-06-03 08:40:33 --> Language Class Initialized
INFO - 2023-06-03 08:40:33 --> Loader Class Initialized
INFO - 2023-06-03 08:40:33 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:33 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:33 --> Parser Class Initialized
INFO - 2023-06-03 08:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:33 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:33 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:33 --> Controller Class Initialized
INFO - 2023-06-03 08:40:33 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:33 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:33 --> Model Class Initialized
INFO - 2023-06-03 08:40:33 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:33 --> Total execution time: 0.0431
ERROR - 2023-06-03 08:40:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:33 --> Config Class Initialized
INFO - 2023-06-03 08:40:33 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:33 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:33 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:33 --> URI Class Initialized
INFO - 2023-06-03 08:40:33 --> Router Class Initialized
INFO - 2023-06-03 08:40:33 --> Output Class Initialized
INFO - 2023-06-03 08:40:33 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:33 --> Input Class Initialized
INFO - 2023-06-03 08:40:33 --> Language Class Initialized
INFO - 2023-06-03 08:40:33 --> Loader Class Initialized
INFO - 2023-06-03 08:40:33 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:33 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:33 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:33 --> Parser Class Initialized
INFO - 2023-06-03 08:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:33 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:33 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:33 --> Controller Class Initialized
INFO - 2023-06-03 08:40:33 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:33 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:33 --> Model Class Initialized
INFO - 2023-06-03 08:40:33 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:33 --> Total execution time: 0.0429
ERROR - 2023-06-03 08:40:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:34 --> Config Class Initialized
INFO - 2023-06-03 08:40:34 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:34 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:34 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:34 --> URI Class Initialized
INFO - 2023-06-03 08:40:34 --> Router Class Initialized
INFO - 2023-06-03 08:40:34 --> Output Class Initialized
INFO - 2023-06-03 08:40:34 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:34 --> Input Class Initialized
INFO - 2023-06-03 08:40:34 --> Language Class Initialized
INFO - 2023-06-03 08:40:34 --> Loader Class Initialized
INFO - 2023-06-03 08:40:34 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:34 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:34 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:34 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:34 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:34 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:34 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:34 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:34 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:34 --> Parser Class Initialized
INFO - 2023-06-03 08:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:34 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:34 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:34 --> Controller Class Initialized
INFO - 2023-06-03 08:40:34 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:34 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:34 --> Model Class Initialized
INFO - 2023-06-03 08:40:34 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:34 --> Total execution time: 0.0297
ERROR - 2023-06-03 08:40:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:36 --> Config Class Initialized
INFO - 2023-06-03 08:40:36 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:36 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:36 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:36 --> URI Class Initialized
INFO - 2023-06-03 08:40:36 --> Router Class Initialized
INFO - 2023-06-03 08:40:36 --> Output Class Initialized
INFO - 2023-06-03 08:40:36 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:36 --> Input Class Initialized
INFO - 2023-06-03 08:40:36 --> Language Class Initialized
INFO - 2023-06-03 08:40:36 --> Loader Class Initialized
INFO - 2023-06-03 08:40:36 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:36 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:36 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:36 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:36 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:36 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:36 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:36 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:36 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:36 --> Parser Class Initialized
INFO - 2023-06-03 08:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:36 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:36 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:36 --> Controller Class Initialized
INFO - 2023-06-03 08:40:36 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:36 --> Model Class Initialized
INFO - 2023-06-03 08:40:36 --> Model Class Initialized
INFO - 2023-06-03 08:40:36 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:36 --> Total execution time: 0.0231
ERROR - 2023-06-03 08:40:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:40:43 --> Config Class Initialized
INFO - 2023-06-03 08:40:43 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:40:43 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:40:43 --> Utf8 Class Initialized
INFO - 2023-06-03 08:40:43 --> URI Class Initialized
INFO - 2023-06-03 08:40:43 --> Router Class Initialized
INFO - 2023-06-03 08:40:43 --> Output Class Initialized
INFO - 2023-06-03 08:40:43 --> Security Class Initialized
DEBUG - 2023-06-03 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:40:43 --> Input Class Initialized
INFO - 2023-06-03 08:40:43 --> Language Class Initialized
INFO - 2023-06-03 08:40:43 --> Loader Class Initialized
INFO - 2023-06-03 08:40:43 --> Helper loaded: url_helper
INFO - 2023-06-03 08:40:43 --> Helper loaded: file_helper
INFO - 2023-06-03 08:40:43 --> Helper loaded: html_helper
INFO - 2023-06-03 08:40:43 --> Helper loaded: text_helper
INFO - 2023-06-03 08:40:43 --> Helper loaded: form_helper
INFO - 2023-06-03 08:40:43 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:40:43 --> Helper loaded: security_helper
INFO - 2023-06-03 08:40:43 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:40:43 --> Database Driver Class Initialized
INFO - 2023-06-03 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:40:43 --> Parser Class Initialized
INFO - 2023-06-03 08:40:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:40:43 --> Pagination Class Initialized
INFO - 2023-06-03 08:40:43 --> Form Validation Class Initialized
INFO - 2023-06-03 08:40:43 --> Controller Class Initialized
INFO - 2023-06-03 08:40:43 --> Model Class Initialized
DEBUG - 2023-06-03 08:40:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:40:43 --> Model Class Initialized
INFO - 2023-06-03 08:40:43 --> Final output sent to browser
DEBUG - 2023-06-03 08:40:43 --> Total execution time: 0.0168
ERROR - 2023-06-03 08:41:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:41:24 --> Config Class Initialized
INFO - 2023-06-03 08:41:24 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:41:24 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:41:24 --> Utf8 Class Initialized
INFO - 2023-06-03 08:41:24 --> URI Class Initialized
INFO - 2023-06-03 08:41:24 --> Router Class Initialized
INFO - 2023-06-03 08:41:24 --> Output Class Initialized
INFO - 2023-06-03 08:41:24 --> Security Class Initialized
DEBUG - 2023-06-03 08:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:41:24 --> Input Class Initialized
INFO - 2023-06-03 08:41:24 --> Language Class Initialized
INFO - 2023-06-03 08:41:24 --> Loader Class Initialized
INFO - 2023-06-03 08:41:24 --> Helper loaded: url_helper
INFO - 2023-06-03 08:41:24 --> Helper loaded: file_helper
INFO - 2023-06-03 08:41:24 --> Helper loaded: html_helper
INFO - 2023-06-03 08:41:24 --> Helper loaded: text_helper
INFO - 2023-06-03 08:41:24 --> Helper loaded: form_helper
INFO - 2023-06-03 08:41:24 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:41:24 --> Helper loaded: security_helper
INFO - 2023-06-03 08:41:24 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:41:24 --> Database Driver Class Initialized
INFO - 2023-06-03 08:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:41:24 --> Parser Class Initialized
INFO - 2023-06-03 08:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:41:24 --> Pagination Class Initialized
INFO - 2023-06-03 08:41:24 --> Form Validation Class Initialized
INFO - 2023-06-03 08:41:24 --> Controller Class Initialized
INFO - 2023-06-03 08:41:24 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:24 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:24 --> Model Class Initialized
INFO - 2023-06-03 08:41:24 --> Final output sent to browser
DEBUG - 2023-06-03 08:41:24 --> Total execution time: 0.0448
ERROR - 2023-06-03 08:41:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:41:25 --> Config Class Initialized
INFO - 2023-06-03 08:41:25 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:41:25 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:41:25 --> Utf8 Class Initialized
INFO - 2023-06-03 08:41:25 --> URI Class Initialized
INFO - 2023-06-03 08:41:25 --> Router Class Initialized
INFO - 2023-06-03 08:41:25 --> Output Class Initialized
INFO - 2023-06-03 08:41:25 --> Security Class Initialized
DEBUG - 2023-06-03 08:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:41:25 --> Input Class Initialized
INFO - 2023-06-03 08:41:25 --> Language Class Initialized
INFO - 2023-06-03 08:41:25 --> Loader Class Initialized
INFO - 2023-06-03 08:41:25 --> Helper loaded: url_helper
INFO - 2023-06-03 08:41:25 --> Helper loaded: file_helper
INFO - 2023-06-03 08:41:25 --> Helper loaded: html_helper
INFO - 2023-06-03 08:41:25 --> Helper loaded: text_helper
INFO - 2023-06-03 08:41:25 --> Helper loaded: form_helper
INFO - 2023-06-03 08:41:25 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:41:25 --> Helper loaded: security_helper
INFO - 2023-06-03 08:41:25 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:41:25 --> Database Driver Class Initialized
INFO - 2023-06-03 08:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:41:25 --> Parser Class Initialized
INFO - 2023-06-03 08:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:41:25 --> Pagination Class Initialized
INFO - 2023-06-03 08:41:25 --> Form Validation Class Initialized
INFO - 2023-06-03 08:41:25 --> Controller Class Initialized
INFO - 2023-06-03 08:41:25 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:25 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:25 --> Model Class Initialized
INFO - 2023-06-03 08:41:25 --> Final output sent to browser
DEBUG - 2023-06-03 08:41:25 --> Total execution time: 0.0423
ERROR - 2023-06-03 08:41:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:41:27 --> Config Class Initialized
INFO - 2023-06-03 08:41:27 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:41:27 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:41:27 --> Utf8 Class Initialized
INFO - 2023-06-03 08:41:27 --> URI Class Initialized
INFO - 2023-06-03 08:41:27 --> Router Class Initialized
INFO - 2023-06-03 08:41:27 --> Output Class Initialized
INFO - 2023-06-03 08:41:27 --> Security Class Initialized
DEBUG - 2023-06-03 08:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:41:27 --> Input Class Initialized
INFO - 2023-06-03 08:41:27 --> Language Class Initialized
INFO - 2023-06-03 08:41:27 --> Loader Class Initialized
INFO - 2023-06-03 08:41:27 --> Helper loaded: url_helper
INFO - 2023-06-03 08:41:27 --> Helper loaded: file_helper
INFO - 2023-06-03 08:41:27 --> Helper loaded: html_helper
INFO - 2023-06-03 08:41:27 --> Helper loaded: text_helper
INFO - 2023-06-03 08:41:27 --> Helper loaded: form_helper
INFO - 2023-06-03 08:41:27 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:41:27 --> Helper loaded: security_helper
INFO - 2023-06-03 08:41:27 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:41:27 --> Database Driver Class Initialized
INFO - 2023-06-03 08:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:41:27 --> Parser Class Initialized
INFO - 2023-06-03 08:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:41:27 --> Pagination Class Initialized
INFO - 2023-06-03 08:41:27 --> Form Validation Class Initialized
INFO - 2023-06-03 08:41:27 --> Controller Class Initialized
INFO - 2023-06-03 08:41:27 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:27 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:27 --> Model Class Initialized
INFO - 2023-06-03 08:41:27 --> Final output sent to browser
DEBUG - 2023-06-03 08:41:27 --> Total execution time: 0.0279
ERROR - 2023-06-03 08:41:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:41:30 --> Config Class Initialized
INFO - 2023-06-03 08:41:30 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:41:30 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:41:30 --> Utf8 Class Initialized
INFO - 2023-06-03 08:41:30 --> URI Class Initialized
INFO - 2023-06-03 08:41:30 --> Router Class Initialized
INFO - 2023-06-03 08:41:30 --> Output Class Initialized
INFO - 2023-06-03 08:41:30 --> Security Class Initialized
DEBUG - 2023-06-03 08:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:41:30 --> Input Class Initialized
INFO - 2023-06-03 08:41:30 --> Language Class Initialized
INFO - 2023-06-03 08:41:30 --> Loader Class Initialized
INFO - 2023-06-03 08:41:30 --> Helper loaded: url_helper
INFO - 2023-06-03 08:41:30 --> Helper loaded: file_helper
INFO - 2023-06-03 08:41:30 --> Helper loaded: html_helper
INFO - 2023-06-03 08:41:30 --> Helper loaded: text_helper
INFO - 2023-06-03 08:41:30 --> Helper loaded: form_helper
INFO - 2023-06-03 08:41:30 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:41:30 --> Helper loaded: security_helper
INFO - 2023-06-03 08:41:30 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:41:30 --> Database Driver Class Initialized
INFO - 2023-06-03 08:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:41:30 --> Parser Class Initialized
INFO - 2023-06-03 08:41:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:41:30 --> Pagination Class Initialized
INFO - 2023-06-03 08:41:30 --> Form Validation Class Initialized
INFO - 2023-06-03 08:41:30 --> Controller Class Initialized
INFO - 2023-06-03 08:41:30 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:30 --> Model Class Initialized
INFO - 2023-06-03 08:41:30 --> Model Class Initialized
INFO - 2023-06-03 08:41:30 --> Final output sent to browser
DEBUG - 2023-06-03 08:41:30 --> Total execution time: 0.0207
ERROR - 2023-06-03 08:41:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:41:34 --> Config Class Initialized
INFO - 2023-06-03 08:41:34 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:41:34 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:41:34 --> Utf8 Class Initialized
INFO - 2023-06-03 08:41:34 --> URI Class Initialized
INFO - 2023-06-03 08:41:34 --> Router Class Initialized
INFO - 2023-06-03 08:41:34 --> Output Class Initialized
INFO - 2023-06-03 08:41:34 --> Security Class Initialized
DEBUG - 2023-06-03 08:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:41:34 --> Input Class Initialized
INFO - 2023-06-03 08:41:34 --> Language Class Initialized
INFO - 2023-06-03 08:41:34 --> Loader Class Initialized
INFO - 2023-06-03 08:41:34 --> Helper loaded: url_helper
INFO - 2023-06-03 08:41:34 --> Helper loaded: file_helper
INFO - 2023-06-03 08:41:34 --> Helper loaded: html_helper
INFO - 2023-06-03 08:41:34 --> Helper loaded: text_helper
INFO - 2023-06-03 08:41:34 --> Helper loaded: form_helper
INFO - 2023-06-03 08:41:34 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:41:34 --> Helper loaded: security_helper
INFO - 2023-06-03 08:41:34 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:41:34 --> Database Driver Class Initialized
INFO - 2023-06-03 08:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:41:34 --> Parser Class Initialized
INFO - 2023-06-03 08:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:41:34 --> Pagination Class Initialized
INFO - 2023-06-03 08:41:34 --> Form Validation Class Initialized
INFO - 2023-06-03 08:41:34 --> Controller Class Initialized
INFO - 2023-06-03 08:41:34 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:34 --> Model Class Initialized
INFO - 2023-06-03 08:41:34 --> Final output sent to browser
DEBUG - 2023-06-03 08:41:34 --> Total execution time: 0.0198
ERROR - 2023-06-03 08:41:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:41:45 --> Config Class Initialized
INFO - 2023-06-03 08:41:45 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:41:45 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:41:45 --> Utf8 Class Initialized
INFO - 2023-06-03 08:41:45 --> URI Class Initialized
INFO - 2023-06-03 08:41:45 --> Router Class Initialized
INFO - 2023-06-03 08:41:45 --> Output Class Initialized
INFO - 2023-06-03 08:41:45 --> Security Class Initialized
DEBUG - 2023-06-03 08:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:41:45 --> Input Class Initialized
INFO - 2023-06-03 08:41:45 --> Language Class Initialized
INFO - 2023-06-03 08:41:45 --> Loader Class Initialized
INFO - 2023-06-03 08:41:45 --> Helper loaded: url_helper
INFO - 2023-06-03 08:41:45 --> Helper loaded: file_helper
INFO - 2023-06-03 08:41:45 --> Helper loaded: html_helper
INFO - 2023-06-03 08:41:45 --> Helper loaded: text_helper
INFO - 2023-06-03 08:41:45 --> Helper loaded: form_helper
INFO - 2023-06-03 08:41:45 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:41:45 --> Helper loaded: security_helper
INFO - 2023-06-03 08:41:45 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:41:45 --> Database Driver Class Initialized
INFO - 2023-06-03 08:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:41:45 --> Parser Class Initialized
INFO - 2023-06-03 08:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:41:45 --> Pagination Class Initialized
INFO - 2023-06-03 08:41:45 --> Form Validation Class Initialized
INFO - 2023-06-03 08:41:45 --> Controller Class Initialized
INFO - 2023-06-03 08:41:45 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:45 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:45 --> Model Class Initialized
INFO - 2023-06-03 08:41:45 --> Final output sent to browser
DEBUG - 2023-06-03 08:41:45 --> Total execution time: 0.0447
ERROR - 2023-06-03 08:41:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:41:46 --> Config Class Initialized
INFO - 2023-06-03 08:41:46 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:41:46 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:41:46 --> Utf8 Class Initialized
INFO - 2023-06-03 08:41:46 --> URI Class Initialized
INFO - 2023-06-03 08:41:46 --> Router Class Initialized
INFO - 2023-06-03 08:41:46 --> Output Class Initialized
INFO - 2023-06-03 08:41:46 --> Security Class Initialized
DEBUG - 2023-06-03 08:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:41:46 --> Input Class Initialized
INFO - 2023-06-03 08:41:46 --> Language Class Initialized
INFO - 2023-06-03 08:41:46 --> Loader Class Initialized
INFO - 2023-06-03 08:41:46 --> Helper loaded: url_helper
INFO - 2023-06-03 08:41:46 --> Helper loaded: file_helper
INFO - 2023-06-03 08:41:46 --> Helper loaded: html_helper
INFO - 2023-06-03 08:41:46 --> Helper loaded: text_helper
INFO - 2023-06-03 08:41:46 --> Helper loaded: form_helper
INFO - 2023-06-03 08:41:46 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:41:46 --> Helper loaded: security_helper
INFO - 2023-06-03 08:41:46 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:41:46 --> Database Driver Class Initialized
INFO - 2023-06-03 08:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:41:46 --> Parser Class Initialized
INFO - 2023-06-03 08:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:41:46 --> Pagination Class Initialized
INFO - 2023-06-03 08:41:46 --> Form Validation Class Initialized
INFO - 2023-06-03 08:41:46 --> Controller Class Initialized
INFO - 2023-06-03 08:41:46 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:46 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:46 --> Model Class Initialized
INFO - 2023-06-03 08:41:46 --> Final output sent to browser
DEBUG - 2023-06-03 08:41:46 --> Total execution time: 0.0458
ERROR - 2023-06-03 08:41:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:41:47 --> Config Class Initialized
INFO - 2023-06-03 08:41:47 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:41:47 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:41:47 --> Utf8 Class Initialized
INFO - 2023-06-03 08:41:47 --> URI Class Initialized
INFO - 2023-06-03 08:41:47 --> Router Class Initialized
INFO - 2023-06-03 08:41:47 --> Output Class Initialized
INFO - 2023-06-03 08:41:47 --> Security Class Initialized
DEBUG - 2023-06-03 08:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:41:47 --> Input Class Initialized
INFO - 2023-06-03 08:41:47 --> Language Class Initialized
INFO - 2023-06-03 08:41:47 --> Loader Class Initialized
INFO - 2023-06-03 08:41:47 --> Helper loaded: url_helper
INFO - 2023-06-03 08:41:47 --> Helper loaded: file_helper
INFO - 2023-06-03 08:41:47 --> Helper loaded: html_helper
INFO - 2023-06-03 08:41:47 --> Helper loaded: text_helper
INFO - 2023-06-03 08:41:47 --> Helper loaded: form_helper
INFO - 2023-06-03 08:41:47 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:41:47 --> Helper loaded: security_helper
INFO - 2023-06-03 08:41:47 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:41:47 --> Database Driver Class Initialized
INFO - 2023-06-03 08:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:41:47 --> Parser Class Initialized
INFO - 2023-06-03 08:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:41:47 --> Pagination Class Initialized
INFO - 2023-06-03 08:41:47 --> Form Validation Class Initialized
INFO - 2023-06-03 08:41:47 --> Controller Class Initialized
INFO - 2023-06-03 08:41:47 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:47 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:47 --> Model Class Initialized
INFO - 2023-06-03 08:41:47 --> Final output sent to browser
DEBUG - 2023-06-03 08:41:47 --> Total execution time: 0.0198
ERROR - 2023-06-03 08:41:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:41:53 --> Config Class Initialized
INFO - 2023-06-03 08:41:53 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:41:53 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:41:53 --> Utf8 Class Initialized
INFO - 2023-06-03 08:41:53 --> URI Class Initialized
INFO - 2023-06-03 08:41:53 --> Router Class Initialized
INFO - 2023-06-03 08:41:53 --> Output Class Initialized
INFO - 2023-06-03 08:41:54 --> Security Class Initialized
DEBUG - 2023-06-03 08:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:41:54 --> Input Class Initialized
INFO - 2023-06-03 08:41:54 --> Language Class Initialized
INFO - 2023-06-03 08:41:54 --> Loader Class Initialized
INFO - 2023-06-03 08:41:54 --> Helper loaded: url_helper
INFO - 2023-06-03 08:41:54 --> Helper loaded: file_helper
INFO - 2023-06-03 08:41:54 --> Helper loaded: html_helper
INFO - 2023-06-03 08:41:54 --> Helper loaded: text_helper
INFO - 2023-06-03 08:41:54 --> Helper loaded: form_helper
INFO - 2023-06-03 08:41:54 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:41:54 --> Helper loaded: security_helper
INFO - 2023-06-03 08:41:54 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:41:54 --> Database Driver Class Initialized
INFO - 2023-06-03 08:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:41:54 --> Parser Class Initialized
INFO - 2023-06-03 08:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:41:54 --> Pagination Class Initialized
INFO - 2023-06-03 08:41:54 --> Form Validation Class Initialized
INFO - 2023-06-03 08:41:54 --> Controller Class Initialized
INFO - 2023-06-03 08:41:54 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:54 --> Model Class Initialized
DEBUG - 2023-06-03 08:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:41:54 --> Model Class Initialized
INFO - 2023-06-03 08:41:54 --> Final output sent to browser
DEBUG - 2023-06-03 08:41:54 --> Total execution time: 0.0512
ERROR - 2023-06-03 08:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:42:03 --> Config Class Initialized
INFO - 2023-06-03 08:42:03 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:42:03 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:42:03 --> Utf8 Class Initialized
INFO - 2023-06-03 08:42:03 --> URI Class Initialized
INFO - 2023-06-03 08:42:03 --> Router Class Initialized
INFO - 2023-06-03 08:42:03 --> Output Class Initialized
INFO - 2023-06-03 08:42:03 --> Security Class Initialized
DEBUG - 2023-06-03 08:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:42:03 --> Input Class Initialized
INFO - 2023-06-03 08:42:03 --> Language Class Initialized
INFO - 2023-06-03 08:42:03 --> Loader Class Initialized
INFO - 2023-06-03 08:42:03 --> Helper loaded: url_helper
INFO - 2023-06-03 08:42:03 --> Helper loaded: file_helper
INFO - 2023-06-03 08:42:03 --> Helper loaded: html_helper
INFO - 2023-06-03 08:42:03 --> Helper loaded: text_helper
INFO - 2023-06-03 08:42:03 --> Helper loaded: form_helper
INFO - 2023-06-03 08:42:03 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:42:03 --> Helper loaded: security_helper
INFO - 2023-06-03 08:42:03 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:42:03 --> Database Driver Class Initialized
INFO - 2023-06-03 08:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:42:03 --> Parser Class Initialized
INFO - 2023-06-03 08:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:42:03 --> Pagination Class Initialized
INFO - 2023-06-03 08:42:03 --> Form Validation Class Initialized
INFO - 2023-06-03 08:42:03 --> Controller Class Initialized
INFO - 2023-06-03 08:42:03 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:03 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:03 --> Model Class Initialized
INFO - 2023-06-03 08:42:03 --> Email Class Initialized
DEBUG - 2023-06-03 08:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-03 08:42:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-06-03 08:42:03 --> Language file loaded: language/english/email_lang.php
INFO - 2023-06-03 08:42:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-06-03 08:42:03 --> Final output sent to browser
DEBUG - 2023-06-03 08:42:03 --> Total execution time: 0.5557
ERROR - 2023-06-03 08:42:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:42:05 --> Config Class Initialized
INFO - 2023-06-03 08:42:05 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:42:05 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:42:05 --> Utf8 Class Initialized
INFO - 2023-06-03 08:42:05 --> URI Class Initialized
INFO - 2023-06-03 08:42:05 --> Router Class Initialized
INFO - 2023-06-03 08:42:05 --> Output Class Initialized
INFO - 2023-06-03 08:42:05 --> Security Class Initialized
DEBUG - 2023-06-03 08:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:42:05 --> Input Class Initialized
INFO - 2023-06-03 08:42:05 --> Language Class Initialized
INFO - 2023-06-03 08:42:05 --> Loader Class Initialized
INFO - 2023-06-03 08:42:05 --> Helper loaded: url_helper
INFO - 2023-06-03 08:42:05 --> Helper loaded: file_helper
INFO - 2023-06-03 08:42:05 --> Helper loaded: html_helper
INFO - 2023-06-03 08:42:05 --> Helper loaded: text_helper
INFO - 2023-06-03 08:42:05 --> Helper loaded: form_helper
INFO - 2023-06-03 08:42:05 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:42:05 --> Helper loaded: security_helper
INFO - 2023-06-03 08:42:05 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:42:05 --> Database Driver Class Initialized
INFO - 2023-06-03 08:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:42:05 --> Parser Class Initialized
INFO - 2023-06-03 08:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:42:05 --> Pagination Class Initialized
INFO - 2023-06-03 08:42:05 --> Form Validation Class Initialized
INFO - 2023-06-03 08:42:05 --> Controller Class Initialized
INFO - 2023-06-03 08:42:05 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:05 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:05 --> Model Class Initialized
INFO - 2023-06-03 08:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-03 08:42:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:42:05 --> Model Class Initialized
INFO - 2023-06-03 08:42:05 --> Model Class Initialized
INFO - 2023-06-03 08:42:05 --> Model Class Initialized
INFO - 2023-06-03 08:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:42:05 --> Final output sent to browser
DEBUG - 2023-06-03 08:42:05 --> Total execution time: 0.0866
ERROR - 2023-06-03 08:42:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:42:20 --> Config Class Initialized
INFO - 2023-06-03 08:42:20 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:42:20 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:42:20 --> Utf8 Class Initialized
INFO - 2023-06-03 08:42:20 --> URI Class Initialized
INFO - 2023-06-03 08:42:20 --> Router Class Initialized
INFO - 2023-06-03 08:42:20 --> Output Class Initialized
INFO - 2023-06-03 08:42:20 --> Security Class Initialized
DEBUG - 2023-06-03 08:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:42:20 --> Input Class Initialized
INFO - 2023-06-03 08:42:20 --> Language Class Initialized
INFO - 2023-06-03 08:42:20 --> Loader Class Initialized
INFO - 2023-06-03 08:42:20 --> Helper loaded: url_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: file_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: html_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: text_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: form_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: security_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:42:20 --> Database Driver Class Initialized
INFO - 2023-06-03 08:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:42:20 --> Parser Class Initialized
INFO - 2023-06-03 08:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:42:20 --> Pagination Class Initialized
INFO - 2023-06-03 08:42:20 --> Form Validation Class Initialized
INFO - 2023-06-03 08:42:20 --> Controller Class Initialized
INFO - 2023-06-03 08:42:20 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:20 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:20 --> Model Class Initialized
INFO - 2023-06-03 08:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-03 08:42:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:42:20 --> Model Class Initialized
INFO - 2023-06-03 08:42:20 --> Model Class Initialized
INFO - 2023-06-03 08:42:20 --> Model Class Initialized
INFO - 2023-06-03 08:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:42:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:42:20 --> Final output sent to browser
DEBUG - 2023-06-03 08:42:20 --> Total execution time: 0.0892
ERROR - 2023-06-03 08:42:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:42:20 --> Config Class Initialized
INFO - 2023-06-03 08:42:20 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:42:20 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:42:20 --> Utf8 Class Initialized
INFO - 2023-06-03 08:42:20 --> URI Class Initialized
INFO - 2023-06-03 08:42:20 --> Router Class Initialized
INFO - 2023-06-03 08:42:20 --> Output Class Initialized
INFO - 2023-06-03 08:42:20 --> Security Class Initialized
DEBUG - 2023-06-03 08:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:42:20 --> Input Class Initialized
INFO - 2023-06-03 08:42:20 --> Language Class Initialized
INFO - 2023-06-03 08:42:20 --> Loader Class Initialized
INFO - 2023-06-03 08:42:20 --> Helper loaded: url_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: file_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: html_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: text_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: form_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: security_helper
INFO - 2023-06-03 08:42:20 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:42:20 --> Database Driver Class Initialized
INFO - 2023-06-03 08:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:42:20 --> Parser Class Initialized
INFO - 2023-06-03 08:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:42:20 --> Pagination Class Initialized
INFO - 2023-06-03 08:42:20 --> Form Validation Class Initialized
INFO - 2023-06-03 08:42:20 --> Controller Class Initialized
INFO - 2023-06-03 08:42:20 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:20 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:20 --> Model Class Initialized
INFO - 2023-06-03 08:42:20 --> Final output sent to browser
DEBUG - 2023-06-03 08:42:20 --> Total execution time: 0.0477
ERROR - 2023-06-03 08:42:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:42:26 --> Config Class Initialized
INFO - 2023-06-03 08:42:26 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:42:26 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:42:26 --> Utf8 Class Initialized
INFO - 2023-06-03 08:42:26 --> URI Class Initialized
DEBUG - 2023-06-03 08:42:26 --> No URI present. Default controller set.
INFO - 2023-06-03 08:42:26 --> Router Class Initialized
INFO - 2023-06-03 08:42:26 --> Output Class Initialized
INFO - 2023-06-03 08:42:26 --> Security Class Initialized
DEBUG - 2023-06-03 08:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:42:26 --> Input Class Initialized
INFO - 2023-06-03 08:42:26 --> Language Class Initialized
INFO - 2023-06-03 08:42:26 --> Loader Class Initialized
INFO - 2023-06-03 08:42:26 --> Helper loaded: url_helper
INFO - 2023-06-03 08:42:26 --> Helper loaded: file_helper
INFO - 2023-06-03 08:42:26 --> Helper loaded: html_helper
INFO - 2023-06-03 08:42:26 --> Helper loaded: text_helper
INFO - 2023-06-03 08:42:26 --> Helper loaded: form_helper
INFO - 2023-06-03 08:42:26 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:42:26 --> Helper loaded: security_helper
INFO - 2023-06-03 08:42:26 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:42:26 --> Database Driver Class Initialized
INFO - 2023-06-03 08:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:42:26 --> Parser Class Initialized
INFO - 2023-06-03 08:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:42:26 --> Pagination Class Initialized
INFO - 2023-06-03 08:42:26 --> Form Validation Class Initialized
INFO - 2023-06-03 08:42:26 --> Controller Class Initialized
INFO - 2023-06-03 08:42:26 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:26 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:26 --> Model Class Initialized
INFO - 2023-06-03 08:42:26 --> Model Class Initialized
INFO - 2023-06-03 08:42:26 --> Model Class Initialized
INFO - 2023-06-03 08:42:26 --> Model Class Initialized
DEBUG - 2023-06-03 08:42:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:26 --> Model Class Initialized
INFO - 2023-06-03 08:42:26 --> Model Class Initialized
INFO - 2023-06-03 08:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 08:42:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:42:26 --> Model Class Initialized
INFO - 2023-06-03 08:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:42:26 --> Final output sent to browser
DEBUG - 2023-06-03 08:42:26 --> Total execution time: 0.0788
ERROR - 2023-06-03 08:48:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:48:00 --> Config Class Initialized
INFO - 2023-06-03 08:48:00 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:48:00 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:48:00 --> Utf8 Class Initialized
INFO - 2023-06-03 08:48:00 --> URI Class Initialized
INFO - 2023-06-03 08:48:00 --> Router Class Initialized
INFO - 2023-06-03 08:48:00 --> Output Class Initialized
INFO - 2023-06-03 08:48:00 --> Security Class Initialized
DEBUG - 2023-06-03 08:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:48:00 --> Input Class Initialized
INFO - 2023-06-03 08:48:00 --> Language Class Initialized
INFO - 2023-06-03 08:48:00 --> Loader Class Initialized
INFO - 2023-06-03 08:48:00 --> Helper loaded: url_helper
INFO - 2023-06-03 08:48:00 --> Helper loaded: file_helper
INFO - 2023-06-03 08:48:00 --> Helper loaded: html_helper
INFO - 2023-06-03 08:48:00 --> Helper loaded: text_helper
INFO - 2023-06-03 08:48:00 --> Helper loaded: form_helper
INFO - 2023-06-03 08:48:00 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:48:00 --> Helper loaded: security_helper
INFO - 2023-06-03 08:48:00 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:48:00 --> Database Driver Class Initialized
INFO - 2023-06-03 08:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:48:00 --> Parser Class Initialized
INFO - 2023-06-03 08:48:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:48:00 --> Pagination Class Initialized
INFO - 2023-06-03 08:48:00 --> Form Validation Class Initialized
INFO - 2023-06-03 08:48:00 --> Controller Class Initialized
INFO - 2023-06-03 08:48:00 --> Model Class Initialized
DEBUG - 2023-06-03 08:48:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:48:00 --> Model Class Initialized
DEBUG - 2023-06-03 08:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:48:00 --> Model Class Initialized
INFO - 2023-06-03 08:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-03 08:48:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:48:00 --> Model Class Initialized
INFO - 2023-06-03 08:48:00 --> Model Class Initialized
INFO - 2023-06-03 08:48:00 --> Model Class Initialized
INFO - 2023-06-03 08:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:48:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:48:00 --> Final output sent to browser
DEBUG - 2023-06-03 08:48:00 --> Total execution time: 0.1030
ERROR - 2023-06-03 08:48:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:48:06 --> Config Class Initialized
INFO - 2023-06-03 08:48:06 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:48:06 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:48:06 --> Utf8 Class Initialized
INFO - 2023-06-03 08:48:06 --> URI Class Initialized
DEBUG - 2023-06-03 08:48:06 --> No URI present. Default controller set.
INFO - 2023-06-03 08:48:06 --> Router Class Initialized
INFO - 2023-06-03 08:48:06 --> Output Class Initialized
INFO - 2023-06-03 08:48:06 --> Security Class Initialized
DEBUG - 2023-06-03 08:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:48:06 --> Input Class Initialized
INFO - 2023-06-03 08:48:06 --> Language Class Initialized
INFO - 2023-06-03 08:48:06 --> Loader Class Initialized
INFO - 2023-06-03 08:48:06 --> Helper loaded: url_helper
INFO - 2023-06-03 08:48:06 --> Helper loaded: file_helper
INFO - 2023-06-03 08:48:06 --> Helper loaded: html_helper
INFO - 2023-06-03 08:48:06 --> Helper loaded: text_helper
INFO - 2023-06-03 08:48:06 --> Helper loaded: form_helper
INFO - 2023-06-03 08:48:06 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:48:06 --> Helper loaded: security_helper
INFO - 2023-06-03 08:48:06 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:48:06 --> Database Driver Class Initialized
INFO - 2023-06-03 08:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:48:06 --> Parser Class Initialized
INFO - 2023-06-03 08:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:48:06 --> Pagination Class Initialized
INFO - 2023-06-03 08:48:06 --> Form Validation Class Initialized
INFO - 2023-06-03 08:48:06 --> Controller Class Initialized
INFO - 2023-06-03 08:48:06 --> Model Class Initialized
DEBUG - 2023-06-03 08:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:48:06 --> Model Class Initialized
DEBUG - 2023-06-03 08:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:48:06 --> Model Class Initialized
INFO - 2023-06-03 08:48:06 --> Model Class Initialized
INFO - 2023-06-03 08:48:06 --> Model Class Initialized
INFO - 2023-06-03 08:48:06 --> Model Class Initialized
DEBUG - 2023-06-03 08:48:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:48:06 --> Model Class Initialized
INFO - 2023-06-03 08:48:06 --> Model Class Initialized
INFO - 2023-06-03 08:48:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 08:48:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:48:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:48:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:48:06 --> Model Class Initialized
INFO - 2023-06-03 08:48:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:48:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:48:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:48:06 --> Final output sent to browser
DEBUG - 2023-06-03 08:48:06 --> Total execution time: 0.0856
ERROR - 2023-06-03 08:56:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:17 --> Config Class Initialized
INFO - 2023-06-03 08:56:17 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:17 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:17 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:17 --> URI Class Initialized
DEBUG - 2023-06-03 08:56:17 --> No URI present. Default controller set.
INFO - 2023-06-03 08:56:17 --> Router Class Initialized
INFO - 2023-06-03 08:56:17 --> Output Class Initialized
INFO - 2023-06-03 08:56:17 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:17 --> Input Class Initialized
INFO - 2023-06-03 08:56:17 --> Language Class Initialized
INFO - 2023-06-03 08:56:17 --> Loader Class Initialized
INFO - 2023-06-03 08:56:17 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:17 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:17 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:17 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:17 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:17 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:17 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:17 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:17 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:17 --> Parser Class Initialized
INFO - 2023-06-03 08:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:17 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:17 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:17 --> Controller Class Initialized
INFO - 2023-06-03 08:56:17 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 08:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:18 --> Config Class Initialized
INFO - 2023-06-03 08:56:18 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:18 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:18 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:18 --> URI Class Initialized
INFO - 2023-06-03 08:56:18 --> Router Class Initialized
INFO - 2023-06-03 08:56:18 --> Output Class Initialized
INFO - 2023-06-03 08:56:18 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:18 --> Input Class Initialized
INFO - 2023-06-03 08:56:18 --> Language Class Initialized
INFO - 2023-06-03 08:56:18 --> Loader Class Initialized
INFO - 2023-06-03 08:56:18 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:18 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:18 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:18 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:18 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:18 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:18 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:18 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:18 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:18 --> Parser Class Initialized
INFO - 2023-06-03 08:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:18 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:18 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:18 --> Controller Class Initialized
INFO - 2023-06-03 08:56:18 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 08:56:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:56:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:56:18 --> Model Class Initialized
INFO - 2023-06-03 08:56:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:56:18 --> Final output sent to browser
DEBUG - 2023-06-03 08:56:18 --> Total execution time: 0.0310
ERROR - 2023-06-03 08:56:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:26 --> Config Class Initialized
INFO - 2023-06-03 08:56:26 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:26 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:26 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:26 --> URI Class Initialized
INFO - 2023-06-03 08:56:26 --> Router Class Initialized
INFO - 2023-06-03 08:56:26 --> Output Class Initialized
INFO - 2023-06-03 08:56:26 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:26 --> Input Class Initialized
INFO - 2023-06-03 08:56:26 --> Language Class Initialized
INFO - 2023-06-03 08:56:26 --> Loader Class Initialized
INFO - 2023-06-03 08:56:26 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:26 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:26 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:26 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:26 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:26 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:26 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:26 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:26 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:26 --> Parser Class Initialized
INFO - 2023-06-03 08:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:26 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:26 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:26 --> Controller Class Initialized
INFO - 2023-06-03 08:56:26 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:26 --> Model Class Initialized
INFO - 2023-06-03 08:56:26 --> Final output sent to browser
DEBUG - 2023-06-03 08:56:26 --> Total execution time: 0.0180
ERROR - 2023-06-03 08:56:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:27 --> Config Class Initialized
INFO - 2023-06-03 08:56:27 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:27 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:27 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:27 --> URI Class Initialized
INFO - 2023-06-03 08:56:27 --> Router Class Initialized
INFO - 2023-06-03 08:56:27 --> Output Class Initialized
INFO - 2023-06-03 08:56:27 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:27 --> Input Class Initialized
INFO - 2023-06-03 08:56:27 --> Language Class Initialized
INFO - 2023-06-03 08:56:27 --> Loader Class Initialized
INFO - 2023-06-03 08:56:27 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:27 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:27 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:27 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:27 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:27 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:27 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:27 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:27 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:27 --> Parser Class Initialized
INFO - 2023-06-03 08:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:27 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:27 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:27 --> Controller Class Initialized
INFO - 2023-06-03 08:56:27 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 08:56:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:56:27 --> Model Class Initialized
INFO - 2023-06-03 08:56:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:56:27 --> Final output sent to browser
DEBUG - 2023-06-03 08:56:27 --> Total execution time: 0.0317
ERROR - 2023-06-03 08:56:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:30 --> Config Class Initialized
INFO - 2023-06-03 08:56:30 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:30 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:30 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:30 --> URI Class Initialized
INFO - 2023-06-03 08:56:30 --> Router Class Initialized
INFO - 2023-06-03 08:56:30 --> Output Class Initialized
INFO - 2023-06-03 08:56:30 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:30 --> Input Class Initialized
INFO - 2023-06-03 08:56:30 --> Language Class Initialized
INFO - 2023-06-03 08:56:30 --> Loader Class Initialized
INFO - 2023-06-03 08:56:30 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:30 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:30 --> Parser Class Initialized
INFO - 2023-06-03 08:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:30 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:30 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:30 --> Controller Class Initialized
INFO - 2023-06-03 08:56:30 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:30 --> Model Class Initialized
INFO - 2023-06-03 08:56:30 --> Final output sent to browser
DEBUG - 2023-06-03 08:56:30 --> Total execution time: 0.0158
ERROR - 2023-06-03 08:56:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:30 --> Config Class Initialized
INFO - 2023-06-03 08:56:30 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:30 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:30 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:30 --> URI Class Initialized
INFO - 2023-06-03 08:56:30 --> Router Class Initialized
INFO - 2023-06-03 08:56:30 --> Output Class Initialized
INFO - 2023-06-03 08:56:30 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:30 --> Input Class Initialized
INFO - 2023-06-03 08:56:30 --> Language Class Initialized
INFO - 2023-06-03 08:56:30 --> Loader Class Initialized
INFO - 2023-06-03 08:56:30 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:30 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:30 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:30 --> Parser Class Initialized
INFO - 2023-06-03 08:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:30 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:30 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:30 --> Controller Class Initialized
INFO - 2023-06-03 08:56:30 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 08:56:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:56:30 --> Model Class Initialized
INFO - 2023-06-03 08:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:56:30 --> Final output sent to browser
DEBUG - 2023-06-03 08:56:30 --> Total execution time: 0.0265
ERROR - 2023-06-03 08:56:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:42 --> Config Class Initialized
INFO - 2023-06-03 08:56:42 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:42 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:42 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:42 --> URI Class Initialized
INFO - 2023-06-03 08:56:42 --> Router Class Initialized
INFO - 2023-06-03 08:56:42 --> Output Class Initialized
INFO - 2023-06-03 08:56:42 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:42 --> Input Class Initialized
INFO - 2023-06-03 08:56:42 --> Language Class Initialized
INFO - 2023-06-03 08:56:42 --> Loader Class Initialized
INFO - 2023-06-03 08:56:42 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:42 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:42 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:42 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:42 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:42 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:42 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:42 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:42 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:42 --> Parser Class Initialized
INFO - 2023-06-03 08:56:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:42 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:42 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:42 --> Controller Class Initialized
INFO - 2023-06-03 08:56:42 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:42 --> Model Class Initialized
INFO - 2023-06-03 08:56:42 --> Final output sent to browser
DEBUG - 2023-06-03 08:56:42 --> Total execution time: 0.0184
ERROR - 2023-06-03 08:56:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:43 --> Config Class Initialized
INFO - 2023-06-03 08:56:43 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:43 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:43 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:43 --> URI Class Initialized
INFO - 2023-06-03 08:56:43 --> Router Class Initialized
INFO - 2023-06-03 08:56:43 --> Output Class Initialized
INFO - 2023-06-03 08:56:43 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:43 --> Input Class Initialized
INFO - 2023-06-03 08:56:43 --> Language Class Initialized
INFO - 2023-06-03 08:56:43 --> Loader Class Initialized
INFO - 2023-06-03 08:56:43 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:43 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:43 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:43 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:43 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:43 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:43 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:43 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:43 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:43 --> Parser Class Initialized
INFO - 2023-06-03 08:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:43 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:43 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:43 --> Controller Class Initialized
INFO - 2023-06-03 08:56:43 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 08:56:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:56:43 --> Model Class Initialized
INFO - 2023-06-03 08:56:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:56:43 --> Final output sent to browser
DEBUG - 2023-06-03 08:56:43 --> Total execution time: 0.0336
ERROR - 2023-06-03 08:56:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:57 --> Config Class Initialized
INFO - 2023-06-03 08:56:57 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:57 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:57 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:57 --> URI Class Initialized
INFO - 2023-06-03 08:56:57 --> Router Class Initialized
INFO - 2023-06-03 08:56:57 --> Output Class Initialized
INFO - 2023-06-03 08:56:57 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:57 --> Input Class Initialized
INFO - 2023-06-03 08:56:57 --> Language Class Initialized
INFO - 2023-06-03 08:56:57 --> Loader Class Initialized
INFO - 2023-06-03 08:56:57 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:57 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:57 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:57 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:57 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:57 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:57 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:57 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:57 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:57 --> Parser Class Initialized
INFO - 2023-06-03 08:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:57 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:57 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:57 --> Controller Class Initialized
INFO - 2023-06-03 08:56:57 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:57 --> Model Class Initialized
INFO - 2023-06-03 08:56:57 --> Final output sent to browser
DEBUG - 2023-06-03 08:56:57 --> Total execution time: 0.0203
ERROR - 2023-06-03 08:56:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:56:58 --> Config Class Initialized
INFO - 2023-06-03 08:56:58 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:56:58 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:56:58 --> Utf8 Class Initialized
INFO - 2023-06-03 08:56:58 --> URI Class Initialized
DEBUG - 2023-06-03 08:56:58 --> No URI present. Default controller set.
INFO - 2023-06-03 08:56:58 --> Router Class Initialized
INFO - 2023-06-03 08:56:58 --> Output Class Initialized
INFO - 2023-06-03 08:56:58 --> Security Class Initialized
DEBUG - 2023-06-03 08:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:56:58 --> Input Class Initialized
INFO - 2023-06-03 08:56:58 --> Language Class Initialized
INFO - 2023-06-03 08:56:58 --> Loader Class Initialized
INFO - 2023-06-03 08:56:58 --> Helper loaded: url_helper
INFO - 2023-06-03 08:56:58 --> Helper loaded: file_helper
INFO - 2023-06-03 08:56:58 --> Helper loaded: html_helper
INFO - 2023-06-03 08:56:58 --> Helper loaded: text_helper
INFO - 2023-06-03 08:56:58 --> Helper loaded: form_helper
INFO - 2023-06-03 08:56:58 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:56:58 --> Helper loaded: security_helper
INFO - 2023-06-03 08:56:58 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:56:58 --> Database Driver Class Initialized
INFO - 2023-06-03 08:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:56:58 --> Parser Class Initialized
INFO - 2023-06-03 08:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:56:58 --> Pagination Class Initialized
INFO - 2023-06-03 08:56:58 --> Form Validation Class Initialized
INFO - 2023-06-03 08:56:58 --> Controller Class Initialized
INFO - 2023-06-03 08:56:58 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:58 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:58 --> Model Class Initialized
INFO - 2023-06-03 08:56:58 --> Model Class Initialized
INFO - 2023-06-03 08:56:58 --> Model Class Initialized
INFO - 2023-06-03 08:56:58 --> Model Class Initialized
DEBUG - 2023-06-03 08:56:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:58 --> Model Class Initialized
INFO - 2023-06-03 08:56:58 --> Model Class Initialized
INFO - 2023-06-03 08:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 08:56:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:56:58 --> Model Class Initialized
INFO - 2023-06-03 08:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:56:58 --> Final output sent to browser
DEBUG - 2023-06-03 08:56:58 --> Total execution time: 0.0681
ERROR - 2023-06-03 08:57:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:03 --> Config Class Initialized
INFO - 2023-06-03 08:57:03 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:03 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:03 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:03 --> URI Class Initialized
INFO - 2023-06-03 08:57:03 --> Router Class Initialized
INFO - 2023-06-03 08:57:03 --> Output Class Initialized
INFO - 2023-06-03 08:57:03 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:03 --> Input Class Initialized
INFO - 2023-06-03 08:57:03 --> Language Class Initialized
INFO - 2023-06-03 08:57:03 --> Loader Class Initialized
INFO - 2023-06-03 08:57:03 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:03 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:03 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:03 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:03 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:03 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:03 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:03 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:03 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:03 --> Parser Class Initialized
INFO - 2023-06-03 08:57:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:03 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:03 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:03 --> Controller Class Initialized
INFO - 2023-06-03 08:57:03 --> Model Class Initialized
INFO - 2023-06-03 08:57:03 --> Model Class Initialized
INFO - 2023-06-03 08:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-03 08:57:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:57:03 --> Model Class Initialized
INFO - 2023-06-03 08:57:03 --> Model Class Initialized
INFO - 2023-06-03 08:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:57:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:57:03 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:03 --> Total execution time: 0.0508
ERROR - 2023-06-03 08:57:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:04 --> Config Class Initialized
INFO - 2023-06-03 08:57:04 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:04 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:04 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:04 --> URI Class Initialized
INFO - 2023-06-03 08:57:04 --> Router Class Initialized
INFO - 2023-06-03 08:57:04 --> Output Class Initialized
INFO - 2023-06-03 08:57:04 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:04 --> Input Class Initialized
INFO - 2023-06-03 08:57:04 --> Language Class Initialized
INFO - 2023-06-03 08:57:04 --> Loader Class Initialized
INFO - 2023-06-03 08:57:04 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:04 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:04 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:04 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:04 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:04 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:04 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:04 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:04 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:04 --> Parser Class Initialized
INFO - 2023-06-03 08:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:04 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:04 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:04 --> Controller Class Initialized
INFO - 2023-06-03 08:57:04 --> Model Class Initialized
INFO - 2023-06-03 08:57:04 --> Model Class Initialized
INFO - 2023-06-03 08:57:04 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:04 --> Total execution time: 0.0182
ERROR - 2023-06-03 08:57:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:13 --> Config Class Initialized
INFO - 2023-06-03 08:57:13 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:13 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:13 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:13 --> URI Class Initialized
INFO - 2023-06-03 08:57:13 --> Router Class Initialized
INFO - 2023-06-03 08:57:13 --> Output Class Initialized
INFO - 2023-06-03 08:57:13 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:13 --> Input Class Initialized
INFO - 2023-06-03 08:57:13 --> Language Class Initialized
INFO - 2023-06-03 08:57:13 --> Loader Class Initialized
INFO - 2023-06-03 08:57:13 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:13 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:13 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:13 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:13 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:13 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:13 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:13 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:13 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:13 --> Parser Class Initialized
INFO - 2023-06-03 08:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:13 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:13 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:13 --> Controller Class Initialized
INFO - 2023-06-03 08:57:13 --> Model Class Initialized
INFO - 2023-06-03 08:57:13 --> Model Class Initialized
INFO - 2023-06-03 08:57:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-03 08:57:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:57:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:57:13 --> Model Class Initialized
INFO - 2023-06-03 08:57:13 --> Model Class Initialized
INFO - 2023-06-03 08:57:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:57:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:57:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:57:13 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:13 --> Total execution time: 0.0757
ERROR - 2023-06-03 08:57:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:14 --> Config Class Initialized
INFO - 2023-06-03 08:57:14 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:14 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:14 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:14 --> URI Class Initialized
INFO - 2023-06-03 08:57:14 --> Router Class Initialized
INFO - 2023-06-03 08:57:14 --> Output Class Initialized
INFO - 2023-06-03 08:57:14 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:14 --> Input Class Initialized
INFO - 2023-06-03 08:57:14 --> Language Class Initialized
INFO - 2023-06-03 08:57:14 --> Loader Class Initialized
INFO - 2023-06-03 08:57:14 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:14 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:14 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:14 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:14 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:14 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:14 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:14 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:14 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:14 --> Parser Class Initialized
INFO - 2023-06-03 08:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:14 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:14 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:14 --> Controller Class Initialized
INFO - 2023-06-03 08:57:14 --> Model Class Initialized
INFO - 2023-06-03 08:57:14 --> Model Class Initialized
INFO - 2023-06-03 08:57:14 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:14 --> Total execution time: 0.0260
ERROR - 2023-06-03 08:57:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:24 --> Config Class Initialized
INFO - 2023-06-03 08:57:24 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:24 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:24 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:24 --> URI Class Initialized
INFO - 2023-06-03 08:57:24 --> Router Class Initialized
INFO - 2023-06-03 08:57:24 --> Output Class Initialized
INFO - 2023-06-03 08:57:24 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:24 --> Input Class Initialized
INFO - 2023-06-03 08:57:24 --> Language Class Initialized
INFO - 2023-06-03 08:57:24 --> Loader Class Initialized
INFO - 2023-06-03 08:57:24 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:24 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:24 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:24 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:24 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:24 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:24 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:24 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:24 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:24 --> Parser Class Initialized
INFO - 2023-06-03 08:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:24 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:24 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:24 --> Controller Class Initialized
INFO - 2023-06-03 08:57:24 --> Model Class Initialized
DEBUG - 2023-06-03 08:57:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:24 --> Model Class Initialized
DEBUG - 2023-06-03 08:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:24 --> Model Class Initialized
INFO - 2023-06-03 08:57:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-03 08:57:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:57:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:57:24 --> Model Class Initialized
INFO - 2023-06-03 08:57:24 --> Model Class Initialized
INFO - 2023-06-03 08:57:24 --> Model Class Initialized
INFO - 2023-06-03 08:57:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:57:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:57:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:57:24 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:24 --> Total execution time: 0.0620
ERROR - 2023-06-03 08:57:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:25 --> Config Class Initialized
INFO - 2023-06-03 08:57:25 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:25 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:25 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:25 --> URI Class Initialized
INFO - 2023-06-03 08:57:25 --> Router Class Initialized
INFO - 2023-06-03 08:57:25 --> Output Class Initialized
INFO - 2023-06-03 08:57:25 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:25 --> Input Class Initialized
INFO - 2023-06-03 08:57:25 --> Language Class Initialized
INFO - 2023-06-03 08:57:25 --> Loader Class Initialized
INFO - 2023-06-03 08:57:25 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:25 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:25 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:25 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:25 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:25 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:25 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:25 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:25 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:25 --> Parser Class Initialized
INFO - 2023-06-03 08:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:25 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:25 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:25 --> Controller Class Initialized
INFO - 2023-06-03 08:57:25 --> Model Class Initialized
DEBUG - 2023-06-03 08:57:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:25 --> Model Class Initialized
DEBUG - 2023-06-03 08:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:25 --> Model Class Initialized
INFO - 2023-06-03 08:57:25 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:25 --> Total execution time: 0.0375
ERROR - 2023-06-03 08:57:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:43 --> Config Class Initialized
INFO - 2023-06-03 08:57:43 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:43 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:43 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:43 --> URI Class Initialized
INFO - 2023-06-03 08:57:43 --> Router Class Initialized
INFO - 2023-06-03 08:57:43 --> Output Class Initialized
INFO - 2023-06-03 08:57:43 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:43 --> Input Class Initialized
INFO - 2023-06-03 08:57:43 --> Language Class Initialized
INFO - 2023-06-03 08:57:43 --> Loader Class Initialized
INFO - 2023-06-03 08:57:43 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:43 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:43 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:43 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:43 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:43 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:43 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:43 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:43 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:43 --> Parser Class Initialized
INFO - 2023-06-03 08:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:43 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:43 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:43 --> Controller Class Initialized
INFO - 2023-06-03 08:57:43 --> Model Class Initialized
DEBUG - 2023-06-03 08:57:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:43 --> Model Class Initialized
DEBUG - 2023-06-03 08:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:43 --> Model Class Initialized
INFO - 2023-06-03 08:57:43 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:43 --> Total execution time: 0.0284
ERROR - 2023-06-03 08:57:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:47 --> Config Class Initialized
INFO - 2023-06-03 08:57:47 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:47 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:47 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:47 --> URI Class Initialized
INFO - 2023-06-03 08:57:47 --> Router Class Initialized
INFO - 2023-06-03 08:57:47 --> Output Class Initialized
INFO - 2023-06-03 08:57:47 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:47 --> Input Class Initialized
INFO - 2023-06-03 08:57:47 --> Language Class Initialized
INFO - 2023-06-03 08:57:47 --> Loader Class Initialized
INFO - 2023-06-03 08:57:47 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:47 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:47 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:47 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:47 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:47 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:47 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:47 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:47 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:47 --> Parser Class Initialized
INFO - 2023-06-03 08:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:47 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:47 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:47 --> Controller Class Initialized
INFO - 2023-06-03 08:57:47 --> Model Class Initialized
INFO - 2023-06-03 08:57:47 --> Model Class Initialized
INFO - 2023-06-03 08:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-03 08:57:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:57:47 --> Model Class Initialized
INFO - 2023-06-03 08:57:47 --> Model Class Initialized
INFO - 2023-06-03 08:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:57:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:57:47 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:47 --> Total execution time: 0.0585
ERROR - 2023-06-03 08:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:48 --> Config Class Initialized
INFO - 2023-06-03 08:57:48 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:48 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:48 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:48 --> URI Class Initialized
INFO - 2023-06-03 08:57:48 --> Router Class Initialized
INFO - 2023-06-03 08:57:48 --> Output Class Initialized
INFO - 2023-06-03 08:57:48 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:48 --> Input Class Initialized
INFO - 2023-06-03 08:57:48 --> Language Class Initialized
INFO - 2023-06-03 08:57:48 --> Loader Class Initialized
INFO - 2023-06-03 08:57:48 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:48 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:48 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:48 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:48 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:48 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:48 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:48 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:48 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:48 --> Parser Class Initialized
INFO - 2023-06-03 08:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:48 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:48 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:48 --> Controller Class Initialized
INFO - 2023-06-03 08:57:48 --> Model Class Initialized
INFO - 2023-06-03 08:57:48 --> Model Class Initialized
INFO - 2023-06-03 08:57:48 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:48 --> Total execution time: 0.0330
ERROR - 2023-06-03 08:57:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:50 --> Config Class Initialized
INFO - 2023-06-03 08:57:50 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:50 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:50 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:50 --> URI Class Initialized
INFO - 2023-06-03 08:57:50 --> Router Class Initialized
INFO - 2023-06-03 08:57:50 --> Output Class Initialized
INFO - 2023-06-03 08:57:50 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:50 --> Input Class Initialized
INFO - 2023-06-03 08:57:50 --> Language Class Initialized
INFO - 2023-06-03 08:57:50 --> Loader Class Initialized
INFO - 2023-06-03 08:57:50 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:50 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:50 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:50 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:50 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:50 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:50 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:50 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:50 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:50 --> Parser Class Initialized
INFO - 2023-06-03 08:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:50 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:50 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:50 --> Controller Class Initialized
INFO - 2023-06-03 08:57:50 --> Model Class Initialized
INFO - 2023-06-03 08:57:50 --> Model Class Initialized
INFO - 2023-06-03 08:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-03 08:57:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:57:50 --> Model Class Initialized
INFO - 2023-06-03 08:57:50 --> Model Class Initialized
INFO - 2023-06-03 08:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:57:50 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:50 --> Total execution time: 0.0501
ERROR - 2023-06-03 08:57:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:57:51 --> Config Class Initialized
INFO - 2023-06-03 08:57:51 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:57:51 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:57:51 --> Utf8 Class Initialized
INFO - 2023-06-03 08:57:51 --> URI Class Initialized
INFO - 2023-06-03 08:57:51 --> Router Class Initialized
INFO - 2023-06-03 08:57:51 --> Output Class Initialized
INFO - 2023-06-03 08:57:51 --> Security Class Initialized
DEBUG - 2023-06-03 08:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:57:51 --> Input Class Initialized
INFO - 2023-06-03 08:57:51 --> Language Class Initialized
INFO - 2023-06-03 08:57:51 --> Loader Class Initialized
INFO - 2023-06-03 08:57:51 --> Helper loaded: url_helper
INFO - 2023-06-03 08:57:51 --> Helper loaded: file_helper
INFO - 2023-06-03 08:57:51 --> Helper loaded: html_helper
INFO - 2023-06-03 08:57:51 --> Helper loaded: text_helper
INFO - 2023-06-03 08:57:51 --> Helper loaded: form_helper
INFO - 2023-06-03 08:57:51 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:57:51 --> Helper loaded: security_helper
INFO - 2023-06-03 08:57:51 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:57:51 --> Database Driver Class Initialized
INFO - 2023-06-03 08:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:57:51 --> Parser Class Initialized
INFO - 2023-06-03 08:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:57:51 --> Pagination Class Initialized
INFO - 2023-06-03 08:57:51 --> Form Validation Class Initialized
INFO - 2023-06-03 08:57:51 --> Controller Class Initialized
INFO - 2023-06-03 08:57:51 --> Model Class Initialized
INFO - 2023-06-03 08:57:51 --> Model Class Initialized
INFO - 2023-06-03 08:57:51 --> Final output sent to browser
DEBUG - 2023-06-03 08:57:51 --> Total execution time: 0.0165
ERROR - 2023-06-03 08:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:58:04 --> Config Class Initialized
INFO - 2023-06-03 08:58:04 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:58:04 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:58:04 --> Utf8 Class Initialized
INFO - 2023-06-03 08:58:04 --> URI Class Initialized
INFO - 2023-06-03 08:58:04 --> Router Class Initialized
INFO - 2023-06-03 08:58:04 --> Output Class Initialized
INFO - 2023-06-03 08:58:04 --> Security Class Initialized
DEBUG - 2023-06-03 08:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:58:04 --> Input Class Initialized
INFO - 2023-06-03 08:58:04 --> Language Class Initialized
INFO - 2023-06-03 08:58:04 --> Loader Class Initialized
INFO - 2023-06-03 08:58:04 --> Helper loaded: url_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: file_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: html_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: text_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: form_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: security_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:58:04 --> Database Driver Class Initialized
INFO - 2023-06-03 08:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:58:04 --> Parser Class Initialized
INFO - 2023-06-03 08:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:58:04 --> Pagination Class Initialized
INFO - 2023-06-03 08:58:04 --> Form Validation Class Initialized
INFO - 2023-06-03 08:58:04 --> Controller Class Initialized
INFO - 2023-06-03 08:58:04 --> Model Class Initialized
DEBUG - 2023-06-03 08:58:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:58:04 --> Model Class Initialized
DEBUG - 2023-06-03 08:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:58:04 --> Model Class Initialized
INFO - 2023-06-03 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-03 08:58:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:58:04 --> Model Class Initialized
INFO - 2023-06-03 08:58:04 --> Model Class Initialized
INFO - 2023-06-03 08:58:04 --> Model Class Initialized
INFO - 2023-06-03 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:58:04 --> Final output sent to browser
DEBUG - 2023-06-03 08:58:04 --> Total execution time: 0.0642
ERROR - 2023-06-03 08:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:58:04 --> Config Class Initialized
INFO - 2023-06-03 08:58:04 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:58:04 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:58:04 --> Utf8 Class Initialized
INFO - 2023-06-03 08:58:04 --> URI Class Initialized
INFO - 2023-06-03 08:58:04 --> Router Class Initialized
INFO - 2023-06-03 08:58:04 --> Output Class Initialized
INFO - 2023-06-03 08:58:04 --> Security Class Initialized
DEBUG - 2023-06-03 08:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:58:04 --> Input Class Initialized
INFO - 2023-06-03 08:58:04 --> Language Class Initialized
INFO - 2023-06-03 08:58:04 --> Loader Class Initialized
INFO - 2023-06-03 08:58:04 --> Helper loaded: url_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: file_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: html_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: text_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: form_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: security_helper
INFO - 2023-06-03 08:58:04 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:58:04 --> Database Driver Class Initialized
INFO - 2023-06-03 08:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:58:04 --> Parser Class Initialized
INFO - 2023-06-03 08:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:58:04 --> Pagination Class Initialized
INFO - 2023-06-03 08:58:04 --> Form Validation Class Initialized
INFO - 2023-06-03 08:58:04 --> Controller Class Initialized
INFO - 2023-06-03 08:58:04 --> Model Class Initialized
DEBUG - 2023-06-03 08:58:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:58:04 --> Model Class Initialized
DEBUG - 2023-06-03 08:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:58:04 --> Model Class Initialized
INFO - 2023-06-03 08:58:04 --> Final output sent to browser
DEBUG - 2023-06-03 08:58:04 --> Total execution time: 0.0295
ERROR - 2023-06-03 08:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 08:58:16 --> Config Class Initialized
INFO - 2023-06-03 08:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-03 08:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-03 08:58:16 --> Utf8 Class Initialized
INFO - 2023-06-03 08:58:16 --> URI Class Initialized
INFO - 2023-06-03 08:58:16 --> Router Class Initialized
INFO - 2023-06-03 08:58:16 --> Output Class Initialized
INFO - 2023-06-03 08:58:16 --> Security Class Initialized
DEBUG - 2023-06-03 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 08:58:16 --> Input Class Initialized
INFO - 2023-06-03 08:58:16 --> Language Class Initialized
INFO - 2023-06-03 08:58:16 --> Loader Class Initialized
INFO - 2023-06-03 08:58:16 --> Helper loaded: url_helper
INFO - 2023-06-03 08:58:16 --> Helper loaded: file_helper
INFO - 2023-06-03 08:58:16 --> Helper loaded: html_helper
INFO - 2023-06-03 08:58:16 --> Helper loaded: text_helper
INFO - 2023-06-03 08:58:16 --> Helper loaded: form_helper
INFO - 2023-06-03 08:58:16 --> Helper loaded: lang_helper
INFO - 2023-06-03 08:58:16 --> Helper loaded: security_helper
INFO - 2023-06-03 08:58:16 --> Helper loaded: cookie_helper
INFO - 2023-06-03 08:58:16 --> Database Driver Class Initialized
INFO - 2023-06-03 08:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 08:58:16 --> Parser Class Initialized
INFO - 2023-06-03 08:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 08:58:16 --> Pagination Class Initialized
INFO - 2023-06-03 08:58:16 --> Form Validation Class Initialized
INFO - 2023-06-03 08:58:16 --> Controller Class Initialized
INFO - 2023-06-03 08:58:16 --> Model Class Initialized
DEBUG - 2023-06-03 08:58:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 08:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:58:16 --> Model Class Initialized
DEBUG - 2023-06-03 08:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:58:16 --> Model Class Initialized
DEBUG - 2023-06-03 08:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-03 08:58:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 08:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 08:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 08:58:16 --> Model Class Initialized
INFO - 2023-06-03 08:58:16 --> Model Class Initialized
INFO - 2023-06-03 08:58:16 --> Model Class Initialized
INFO - 2023-06-03 08:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 08:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 08:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 08:58:16 --> Final output sent to browser
DEBUG - 2023-06-03 08:58:16 --> Total execution time: 0.0730
ERROR - 2023-06-03 11:46:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:46:30 --> Config Class Initialized
INFO - 2023-06-03 11:46:30 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:46:30 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:46:30 --> Utf8 Class Initialized
INFO - 2023-06-03 11:46:30 --> URI Class Initialized
DEBUG - 2023-06-03 11:46:30 --> No URI present. Default controller set.
INFO - 2023-06-03 11:46:30 --> Router Class Initialized
INFO - 2023-06-03 11:46:30 --> Output Class Initialized
INFO - 2023-06-03 11:46:30 --> Security Class Initialized
DEBUG - 2023-06-03 11:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:46:30 --> Input Class Initialized
INFO - 2023-06-03 11:46:30 --> Language Class Initialized
INFO - 2023-06-03 11:46:30 --> Loader Class Initialized
INFO - 2023-06-03 11:46:30 --> Helper loaded: url_helper
INFO - 2023-06-03 11:46:30 --> Helper loaded: file_helper
INFO - 2023-06-03 11:46:30 --> Helper loaded: html_helper
INFO - 2023-06-03 11:46:30 --> Helper loaded: text_helper
INFO - 2023-06-03 11:46:30 --> Helper loaded: form_helper
INFO - 2023-06-03 11:46:30 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:46:30 --> Helper loaded: security_helper
INFO - 2023-06-03 11:46:30 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:46:30 --> Database Driver Class Initialized
INFO - 2023-06-03 11:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:46:30 --> Parser Class Initialized
INFO - 2023-06-03 11:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:46:30 --> Pagination Class Initialized
INFO - 2023-06-03 11:46:30 --> Form Validation Class Initialized
INFO - 2023-06-03 11:46:30 --> Controller Class Initialized
INFO - 2023-06-03 11:46:30 --> Model Class Initialized
DEBUG - 2023-06-03 11:46:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 11:46:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:46:31 --> Config Class Initialized
INFO - 2023-06-03 11:46:31 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:46:31 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:46:31 --> Utf8 Class Initialized
INFO - 2023-06-03 11:46:31 --> URI Class Initialized
INFO - 2023-06-03 11:46:31 --> Router Class Initialized
INFO - 2023-06-03 11:46:31 --> Output Class Initialized
INFO - 2023-06-03 11:46:31 --> Security Class Initialized
DEBUG - 2023-06-03 11:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:46:31 --> Input Class Initialized
INFO - 2023-06-03 11:46:31 --> Language Class Initialized
INFO - 2023-06-03 11:46:31 --> Loader Class Initialized
INFO - 2023-06-03 11:46:31 --> Helper loaded: url_helper
INFO - 2023-06-03 11:46:31 --> Helper loaded: file_helper
INFO - 2023-06-03 11:46:31 --> Helper loaded: html_helper
INFO - 2023-06-03 11:46:31 --> Helper loaded: text_helper
INFO - 2023-06-03 11:46:31 --> Helper loaded: form_helper
INFO - 2023-06-03 11:46:31 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:46:31 --> Helper loaded: security_helper
INFO - 2023-06-03 11:46:31 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:46:31 --> Database Driver Class Initialized
INFO - 2023-06-03 11:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:46:31 --> Parser Class Initialized
INFO - 2023-06-03 11:46:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:46:31 --> Pagination Class Initialized
INFO - 2023-06-03 11:46:31 --> Form Validation Class Initialized
INFO - 2023-06-03 11:46:31 --> Controller Class Initialized
INFO - 2023-06-03 11:46:31 --> Model Class Initialized
DEBUG - 2023-06-03 11:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:46:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 11:46:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:46:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:46:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:46:31 --> Model Class Initialized
INFO - 2023-06-03 11:46:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:46:31 --> Final output sent to browser
DEBUG - 2023-06-03 11:46:31 --> Total execution time: 0.0337
ERROR - 2023-06-03 11:47:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:47:25 --> Config Class Initialized
INFO - 2023-06-03 11:47:25 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:47:25 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:47:25 --> Utf8 Class Initialized
INFO - 2023-06-03 11:47:25 --> URI Class Initialized
INFO - 2023-06-03 11:47:25 --> Router Class Initialized
INFO - 2023-06-03 11:47:25 --> Output Class Initialized
INFO - 2023-06-03 11:47:25 --> Security Class Initialized
DEBUG - 2023-06-03 11:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:47:25 --> Input Class Initialized
INFO - 2023-06-03 11:47:25 --> Language Class Initialized
INFO - 2023-06-03 11:47:25 --> Loader Class Initialized
INFO - 2023-06-03 11:47:25 --> Helper loaded: url_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: file_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: html_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: text_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: form_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: security_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:47:25 --> Database Driver Class Initialized
INFO - 2023-06-03 11:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:47:25 --> Parser Class Initialized
INFO - 2023-06-03 11:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:47:25 --> Pagination Class Initialized
INFO - 2023-06-03 11:47:25 --> Form Validation Class Initialized
INFO - 2023-06-03 11:47:25 --> Controller Class Initialized
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
DEBUG - 2023-06-03 11:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
INFO - 2023-06-03 11:47:25 --> Final output sent to browser
DEBUG - 2023-06-03 11:47:25 --> Total execution time: 0.0204
ERROR - 2023-06-03 11:47:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:47:25 --> Config Class Initialized
INFO - 2023-06-03 11:47:25 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:47:25 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:47:25 --> Utf8 Class Initialized
INFO - 2023-06-03 11:47:25 --> URI Class Initialized
DEBUG - 2023-06-03 11:47:25 --> No URI present. Default controller set.
INFO - 2023-06-03 11:47:25 --> Router Class Initialized
INFO - 2023-06-03 11:47:25 --> Output Class Initialized
INFO - 2023-06-03 11:47:25 --> Security Class Initialized
DEBUG - 2023-06-03 11:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:47:25 --> Input Class Initialized
INFO - 2023-06-03 11:47:25 --> Language Class Initialized
INFO - 2023-06-03 11:47:25 --> Loader Class Initialized
INFO - 2023-06-03 11:47:25 --> Helper loaded: url_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: file_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: html_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: text_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: form_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: security_helper
INFO - 2023-06-03 11:47:25 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:47:25 --> Database Driver Class Initialized
INFO - 2023-06-03 11:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:47:25 --> Parser Class Initialized
INFO - 2023-06-03 11:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:47:25 --> Pagination Class Initialized
INFO - 2023-06-03 11:47:25 --> Form Validation Class Initialized
INFO - 2023-06-03 11:47:25 --> Controller Class Initialized
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
DEBUG - 2023-06-03 11:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
DEBUG - 2023-06-03 11:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
DEBUG - 2023-06-03 11:47:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
INFO - 2023-06-03 11:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 11:47:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:47:25 --> Model Class Initialized
INFO - 2023-06-03 11:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:47:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:47:25 --> Final output sent to browser
DEBUG - 2023-06-03 11:47:25 --> Total execution time: 0.0711
ERROR - 2023-06-03 11:48:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:48:52 --> Config Class Initialized
INFO - 2023-06-03 11:48:52 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:48:52 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:48:52 --> Utf8 Class Initialized
INFO - 2023-06-03 11:48:52 --> URI Class Initialized
INFO - 2023-06-03 11:48:52 --> Router Class Initialized
INFO - 2023-06-03 11:48:52 --> Output Class Initialized
INFO - 2023-06-03 11:48:52 --> Security Class Initialized
DEBUG - 2023-06-03 11:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:48:52 --> Input Class Initialized
INFO - 2023-06-03 11:48:52 --> Language Class Initialized
INFO - 2023-06-03 11:48:52 --> Loader Class Initialized
INFO - 2023-06-03 11:48:52 --> Helper loaded: url_helper
INFO - 2023-06-03 11:48:52 --> Helper loaded: file_helper
INFO - 2023-06-03 11:48:52 --> Helper loaded: html_helper
INFO - 2023-06-03 11:48:52 --> Helper loaded: text_helper
INFO - 2023-06-03 11:48:52 --> Helper loaded: form_helper
INFO - 2023-06-03 11:48:52 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:48:52 --> Helper loaded: security_helper
INFO - 2023-06-03 11:48:52 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:48:52 --> Database Driver Class Initialized
INFO - 2023-06-03 11:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:48:52 --> Parser Class Initialized
INFO - 2023-06-03 11:48:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:48:52 --> Pagination Class Initialized
INFO - 2023-06-03 11:48:52 --> Form Validation Class Initialized
INFO - 2023-06-03 11:48:52 --> Controller Class Initialized
INFO - 2023-06-03 11:48:52 --> Model Class Initialized
DEBUG - 2023-06-03 11:48:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:48:52 --> Model Class Initialized
DEBUG - 2023-06-03 11:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:48:52 --> Model Class Initialized
INFO - 2023-06-03 11:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-03 11:48:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:48:52 --> Model Class Initialized
INFO - 2023-06-03 11:48:52 --> Model Class Initialized
INFO - 2023-06-03 11:48:52 --> Model Class Initialized
INFO - 2023-06-03 11:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:48:52 --> Final output sent to browser
DEBUG - 2023-06-03 11:48:52 --> Total execution time: 0.0692
ERROR - 2023-06-03 11:48:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:48:53 --> Config Class Initialized
INFO - 2023-06-03 11:48:53 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:48:53 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:48:53 --> Utf8 Class Initialized
INFO - 2023-06-03 11:48:53 --> URI Class Initialized
INFO - 2023-06-03 11:48:53 --> Router Class Initialized
INFO - 2023-06-03 11:48:53 --> Output Class Initialized
INFO - 2023-06-03 11:48:53 --> Security Class Initialized
DEBUG - 2023-06-03 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:48:53 --> Input Class Initialized
INFO - 2023-06-03 11:48:53 --> Language Class Initialized
INFO - 2023-06-03 11:48:53 --> Loader Class Initialized
INFO - 2023-06-03 11:48:53 --> Helper loaded: url_helper
INFO - 2023-06-03 11:48:53 --> Helper loaded: file_helper
INFO - 2023-06-03 11:48:53 --> Helper loaded: html_helper
INFO - 2023-06-03 11:48:53 --> Helper loaded: text_helper
INFO - 2023-06-03 11:48:53 --> Helper loaded: form_helper
INFO - 2023-06-03 11:48:53 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:48:53 --> Helper loaded: security_helper
INFO - 2023-06-03 11:48:53 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:48:53 --> Database Driver Class Initialized
INFO - 2023-06-03 11:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:48:53 --> Parser Class Initialized
INFO - 2023-06-03 11:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:48:53 --> Pagination Class Initialized
INFO - 2023-06-03 11:48:53 --> Form Validation Class Initialized
INFO - 2023-06-03 11:48:53 --> Controller Class Initialized
INFO - 2023-06-03 11:48:53 --> Model Class Initialized
DEBUG - 2023-06-03 11:48:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:48:53 --> Model Class Initialized
DEBUG - 2023-06-03 11:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:48:53 --> Model Class Initialized
INFO - 2023-06-03 11:48:53 --> Final output sent to browser
DEBUG - 2023-06-03 11:48:53 --> Total execution time: 0.0234
ERROR - 2023-06-03 11:49:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:49:44 --> Config Class Initialized
INFO - 2023-06-03 11:49:44 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:49:44 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:49:44 --> Utf8 Class Initialized
INFO - 2023-06-03 11:49:44 --> URI Class Initialized
DEBUG - 2023-06-03 11:49:44 --> No URI present. Default controller set.
INFO - 2023-06-03 11:49:44 --> Router Class Initialized
INFO - 2023-06-03 11:49:44 --> Output Class Initialized
INFO - 2023-06-03 11:49:44 --> Security Class Initialized
DEBUG - 2023-06-03 11:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:49:44 --> Input Class Initialized
INFO - 2023-06-03 11:49:44 --> Language Class Initialized
INFO - 2023-06-03 11:49:44 --> Loader Class Initialized
INFO - 2023-06-03 11:49:44 --> Helper loaded: url_helper
INFO - 2023-06-03 11:49:44 --> Helper loaded: file_helper
INFO - 2023-06-03 11:49:44 --> Helper loaded: html_helper
INFO - 2023-06-03 11:49:44 --> Helper loaded: text_helper
INFO - 2023-06-03 11:49:44 --> Helper loaded: form_helper
INFO - 2023-06-03 11:49:44 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:49:44 --> Helper loaded: security_helper
INFO - 2023-06-03 11:49:44 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:49:44 --> Database Driver Class Initialized
INFO - 2023-06-03 11:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:49:44 --> Parser Class Initialized
INFO - 2023-06-03 11:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:49:44 --> Pagination Class Initialized
INFO - 2023-06-03 11:49:44 --> Form Validation Class Initialized
INFO - 2023-06-03 11:49:44 --> Controller Class Initialized
INFO - 2023-06-03 11:49:44 --> Model Class Initialized
DEBUG - 2023-06-03 11:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:49:44 --> Model Class Initialized
DEBUG - 2023-06-03 11:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:49:44 --> Model Class Initialized
INFO - 2023-06-03 11:49:44 --> Model Class Initialized
INFO - 2023-06-03 11:49:44 --> Model Class Initialized
INFO - 2023-06-03 11:49:44 --> Model Class Initialized
DEBUG - 2023-06-03 11:49:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:49:44 --> Model Class Initialized
INFO - 2023-06-03 11:49:44 --> Model Class Initialized
INFO - 2023-06-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 11:49:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:49:44 --> Model Class Initialized
INFO - 2023-06-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:49:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:49:44 --> Final output sent to browser
DEBUG - 2023-06-03 11:49:44 --> Total execution time: 0.0700
ERROR - 2023-06-03 11:50:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:50:09 --> Config Class Initialized
INFO - 2023-06-03 11:50:09 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:50:09 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:50:09 --> Utf8 Class Initialized
INFO - 2023-06-03 11:50:09 --> URI Class Initialized
INFO - 2023-06-03 11:50:09 --> Router Class Initialized
INFO - 2023-06-03 11:50:09 --> Output Class Initialized
INFO - 2023-06-03 11:50:09 --> Security Class Initialized
DEBUG - 2023-06-03 11:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:50:09 --> Input Class Initialized
INFO - 2023-06-03 11:50:09 --> Language Class Initialized
INFO - 2023-06-03 11:50:09 --> Loader Class Initialized
INFO - 2023-06-03 11:50:09 --> Helper loaded: url_helper
INFO - 2023-06-03 11:50:09 --> Helper loaded: file_helper
INFO - 2023-06-03 11:50:09 --> Helper loaded: html_helper
INFO - 2023-06-03 11:50:09 --> Helper loaded: text_helper
INFO - 2023-06-03 11:50:09 --> Helper loaded: form_helper
INFO - 2023-06-03 11:50:09 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:50:09 --> Helper loaded: security_helper
INFO - 2023-06-03 11:50:09 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:50:09 --> Database Driver Class Initialized
INFO - 2023-06-03 11:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:50:09 --> Parser Class Initialized
INFO - 2023-06-03 11:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:50:09 --> Pagination Class Initialized
INFO - 2023-06-03 11:50:09 --> Form Validation Class Initialized
INFO - 2023-06-03 11:50:09 --> Controller Class Initialized
INFO - 2023-06-03 11:50:09 --> Model Class Initialized
DEBUG - 2023-06-03 11:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/change_password.php
DEBUG - 2023-06-03 11:50:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:50:09 --> Model Class Initialized
INFO - 2023-06-03 11:50:09 --> Model Class Initialized
INFO - 2023-06-03 11:50:09 --> Model Class Initialized
INFO - 2023-06-03 11:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:50:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:50:09 --> Final output sent to browser
DEBUG - 2023-06-03 11:50:09 --> Total execution time: 0.0736
ERROR - 2023-06-03 11:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:51:20 --> Config Class Initialized
INFO - 2023-06-03 11:51:20 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:51:20 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:51:20 --> Utf8 Class Initialized
INFO - 2023-06-03 11:51:20 --> URI Class Initialized
INFO - 2023-06-03 11:51:20 --> Router Class Initialized
INFO - 2023-06-03 11:51:20 --> Output Class Initialized
INFO - 2023-06-03 11:51:20 --> Security Class Initialized
DEBUG - 2023-06-03 11:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:51:20 --> Input Class Initialized
INFO - 2023-06-03 11:51:20 --> Language Class Initialized
INFO - 2023-06-03 11:51:20 --> Loader Class Initialized
INFO - 2023-06-03 11:51:20 --> Helper loaded: url_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: file_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: html_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: text_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: form_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: security_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:51:20 --> Database Driver Class Initialized
INFO - 2023-06-03 11:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:51:20 --> Parser Class Initialized
INFO - 2023-06-03 11:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:51:20 --> Pagination Class Initialized
INFO - 2023-06-03 11:51:20 --> Form Validation Class Initialized
INFO - 2023-06-03 11:51:20 --> Controller Class Initialized
INFO - 2023-06-03 11:51:20 --> Model Class Initialized
DEBUG - 2023-06-03 11:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:51:20 --> Model Class Initialized
INFO - 2023-06-03 11:51:20 --> Final output sent to browser
DEBUG - 2023-06-03 11:51:20 --> Total execution time: 0.0180
ERROR - 2023-06-03 11:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:51:20 --> Config Class Initialized
INFO - 2023-06-03 11:51:20 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:51:20 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:51:20 --> Utf8 Class Initialized
INFO - 2023-06-03 11:51:20 --> URI Class Initialized
INFO - 2023-06-03 11:51:20 --> Router Class Initialized
INFO - 2023-06-03 11:51:20 --> Output Class Initialized
INFO - 2023-06-03 11:51:20 --> Security Class Initialized
DEBUG - 2023-06-03 11:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:51:20 --> Input Class Initialized
INFO - 2023-06-03 11:51:20 --> Language Class Initialized
INFO - 2023-06-03 11:51:20 --> Loader Class Initialized
INFO - 2023-06-03 11:51:20 --> Helper loaded: url_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: file_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: html_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: text_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: form_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: security_helper
INFO - 2023-06-03 11:51:20 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:51:20 --> Database Driver Class Initialized
INFO - 2023-06-03 11:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:51:20 --> Parser Class Initialized
INFO - 2023-06-03 11:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:51:20 --> Pagination Class Initialized
INFO - 2023-06-03 11:51:20 --> Form Validation Class Initialized
INFO - 2023-06-03 11:51:20 --> Controller Class Initialized
INFO - 2023-06-03 11:51:20 --> Model Class Initialized
DEBUG - 2023-06-03 11:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/change_password.php
DEBUG - 2023-06-03 11:51:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:51:20 --> Model Class Initialized
INFO - 2023-06-03 11:51:20 --> Model Class Initialized
INFO - 2023-06-03 11:51:20 --> Model Class Initialized
INFO - 2023-06-03 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:51:20 --> Final output sent to browser
DEBUG - 2023-06-03 11:51:20 --> Total execution time: 0.0601
ERROR - 2023-06-03 11:51:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:51:43 --> Config Class Initialized
INFO - 2023-06-03 11:51:43 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:51:43 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:51:43 --> Utf8 Class Initialized
INFO - 2023-06-03 11:51:43 --> URI Class Initialized
DEBUG - 2023-06-03 11:51:43 --> No URI present. Default controller set.
INFO - 2023-06-03 11:51:43 --> Router Class Initialized
INFO - 2023-06-03 11:51:43 --> Output Class Initialized
INFO - 2023-06-03 11:51:43 --> Security Class Initialized
DEBUG - 2023-06-03 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:51:43 --> Input Class Initialized
INFO - 2023-06-03 11:51:43 --> Language Class Initialized
INFO - 2023-06-03 11:51:43 --> Loader Class Initialized
INFO - 2023-06-03 11:51:43 --> Helper loaded: url_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: file_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: html_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: text_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: form_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: security_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:51:43 --> Database Driver Class Initialized
INFO - 2023-06-03 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:51:43 --> Parser Class Initialized
INFO - 2023-06-03 11:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:51:43 --> Pagination Class Initialized
INFO - 2023-06-03 11:51:43 --> Form Validation Class Initialized
INFO - 2023-06-03 11:51:43 --> Controller Class Initialized
INFO - 2023-06-03 11:51:43 --> Model Class Initialized
DEBUG - 2023-06-03 11:51:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 11:51:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:51:43 --> Config Class Initialized
INFO - 2023-06-03 11:51:43 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:51:43 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:51:43 --> Utf8 Class Initialized
INFO - 2023-06-03 11:51:43 --> URI Class Initialized
INFO - 2023-06-03 11:51:43 --> Router Class Initialized
INFO - 2023-06-03 11:51:43 --> Output Class Initialized
INFO - 2023-06-03 11:51:43 --> Security Class Initialized
DEBUG - 2023-06-03 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:51:43 --> Input Class Initialized
INFO - 2023-06-03 11:51:43 --> Language Class Initialized
INFO - 2023-06-03 11:51:43 --> Loader Class Initialized
INFO - 2023-06-03 11:51:43 --> Helper loaded: url_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: file_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: html_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: text_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: form_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: security_helper
INFO - 2023-06-03 11:51:43 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:51:43 --> Database Driver Class Initialized
INFO - 2023-06-03 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:51:43 --> Parser Class Initialized
INFO - 2023-06-03 11:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:51:43 --> Pagination Class Initialized
INFO - 2023-06-03 11:51:43 --> Form Validation Class Initialized
INFO - 2023-06-03 11:51:43 --> Controller Class Initialized
INFO - 2023-06-03 11:51:43 --> Model Class Initialized
DEBUG - 2023-06-03 11:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:51:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 11:51:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:51:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:51:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:51:43 --> Model Class Initialized
INFO - 2023-06-03 11:51:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:51:43 --> Final output sent to browser
DEBUG - 2023-06-03 11:51:43 --> Total execution time: 0.0301
ERROR - 2023-06-03 11:52:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:52:41 --> Config Class Initialized
INFO - 2023-06-03 11:52:41 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:52:41 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:52:41 --> Utf8 Class Initialized
INFO - 2023-06-03 11:52:41 --> URI Class Initialized
INFO - 2023-06-03 11:52:41 --> Router Class Initialized
INFO - 2023-06-03 11:52:41 --> Output Class Initialized
INFO - 2023-06-03 11:52:41 --> Security Class Initialized
DEBUG - 2023-06-03 11:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:52:41 --> Input Class Initialized
INFO - 2023-06-03 11:52:41 --> Language Class Initialized
INFO - 2023-06-03 11:52:41 --> Loader Class Initialized
INFO - 2023-06-03 11:52:41 --> Helper loaded: url_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: file_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: html_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: text_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: form_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: security_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:52:41 --> Database Driver Class Initialized
INFO - 2023-06-03 11:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:52:41 --> Parser Class Initialized
INFO - 2023-06-03 11:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:52:41 --> Pagination Class Initialized
INFO - 2023-06-03 11:52:41 --> Form Validation Class Initialized
INFO - 2023-06-03 11:52:41 --> Controller Class Initialized
INFO - 2023-06-03 11:52:41 --> Model Class Initialized
DEBUG - 2023-06-03 11:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:41 --> Model Class Initialized
INFO - 2023-06-03 11:52:41 --> Final output sent to browser
DEBUG - 2023-06-03 11:52:41 --> Total execution time: 0.0199
ERROR - 2023-06-03 11:52:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:52:41 --> Config Class Initialized
INFO - 2023-06-03 11:52:41 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:52:41 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:52:41 --> Utf8 Class Initialized
INFO - 2023-06-03 11:52:41 --> URI Class Initialized
INFO - 2023-06-03 11:52:41 --> Router Class Initialized
INFO - 2023-06-03 11:52:41 --> Output Class Initialized
INFO - 2023-06-03 11:52:41 --> Security Class Initialized
DEBUG - 2023-06-03 11:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:52:41 --> Input Class Initialized
INFO - 2023-06-03 11:52:41 --> Language Class Initialized
INFO - 2023-06-03 11:52:41 --> Loader Class Initialized
INFO - 2023-06-03 11:52:41 --> Helper loaded: url_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: file_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: html_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: text_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: form_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: security_helper
INFO - 2023-06-03 11:52:41 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:52:41 --> Database Driver Class Initialized
INFO - 2023-06-03 11:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:52:41 --> Parser Class Initialized
INFO - 2023-06-03 11:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:52:41 --> Pagination Class Initialized
INFO - 2023-06-03 11:52:41 --> Form Validation Class Initialized
INFO - 2023-06-03 11:52:41 --> Controller Class Initialized
INFO - 2023-06-03 11:52:41 --> Model Class Initialized
DEBUG - 2023-06-03 11:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/change_password.php
DEBUG - 2023-06-03 11:52:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:52:41 --> Model Class Initialized
INFO - 2023-06-03 11:52:41 --> Model Class Initialized
INFO - 2023-06-03 11:52:41 --> Model Class Initialized
INFO - 2023-06-03 11:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:52:41 --> Final output sent to browser
DEBUG - 2023-06-03 11:52:41 --> Total execution time: 0.0642
ERROR - 2023-06-03 11:52:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:52:51 --> Config Class Initialized
INFO - 2023-06-03 11:52:51 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:52:51 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:52:51 --> Utf8 Class Initialized
INFO - 2023-06-03 11:52:51 --> URI Class Initialized
INFO - 2023-06-03 11:52:51 --> Router Class Initialized
INFO - 2023-06-03 11:52:51 --> Output Class Initialized
INFO - 2023-06-03 11:52:51 --> Security Class Initialized
DEBUG - 2023-06-03 11:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:52:51 --> Input Class Initialized
INFO - 2023-06-03 11:52:51 --> Language Class Initialized
INFO - 2023-06-03 11:52:51 --> Loader Class Initialized
INFO - 2023-06-03 11:52:51 --> Helper loaded: url_helper
INFO - 2023-06-03 11:52:51 --> Helper loaded: file_helper
INFO - 2023-06-03 11:52:51 --> Helper loaded: html_helper
INFO - 2023-06-03 11:52:51 --> Helper loaded: text_helper
INFO - 2023-06-03 11:52:51 --> Helper loaded: form_helper
INFO - 2023-06-03 11:52:51 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:52:51 --> Helper loaded: security_helper
INFO - 2023-06-03 11:52:51 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:52:51 --> Database Driver Class Initialized
INFO - 2023-06-03 11:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:52:51 --> Parser Class Initialized
INFO - 2023-06-03 11:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:52:51 --> Pagination Class Initialized
INFO - 2023-06-03 11:52:51 --> Form Validation Class Initialized
INFO - 2023-06-03 11:52:51 --> Controller Class Initialized
INFO - 2023-06-03 11:52:51 --> Model Class Initialized
DEBUG - 2023-06-03 11:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/change_password.php
DEBUG - 2023-06-03 11:52:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:52:51 --> Model Class Initialized
INFO - 2023-06-03 11:52:51 --> Model Class Initialized
INFO - 2023-06-03 11:52:51 --> Model Class Initialized
INFO - 2023-06-03 11:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:52:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:52:51 --> Final output sent to browser
DEBUG - 2023-06-03 11:52:51 --> Total execution time: 0.0690
ERROR - 2023-06-03 11:52:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:52:54 --> Config Class Initialized
INFO - 2023-06-03 11:52:54 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:52:54 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:52:54 --> Utf8 Class Initialized
INFO - 2023-06-03 11:52:54 --> URI Class Initialized
INFO - 2023-06-03 11:52:54 --> Router Class Initialized
INFO - 2023-06-03 11:52:54 --> Output Class Initialized
INFO - 2023-06-03 11:52:54 --> Security Class Initialized
DEBUG - 2023-06-03 11:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:52:54 --> Input Class Initialized
INFO - 2023-06-03 11:52:54 --> Language Class Initialized
INFO - 2023-06-03 11:52:54 --> Loader Class Initialized
INFO - 2023-06-03 11:52:54 --> Helper loaded: url_helper
INFO - 2023-06-03 11:52:54 --> Helper loaded: file_helper
INFO - 2023-06-03 11:52:54 --> Helper loaded: html_helper
INFO - 2023-06-03 11:52:54 --> Helper loaded: text_helper
INFO - 2023-06-03 11:52:54 --> Helper loaded: form_helper
INFO - 2023-06-03 11:52:54 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:52:54 --> Helper loaded: security_helper
INFO - 2023-06-03 11:52:54 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:52:54 --> Database Driver Class Initialized
INFO - 2023-06-03 11:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:52:54 --> Parser Class Initialized
INFO - 2023-06-03 11:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:52:54 --> Pagination Class Initialized
INFO - 2023-06-03 11:52:54 --> Form Validation Class Initialized
INFO - 2023-06-03 11:52:54 --> Controller Class Initialized
INFO - 2023-06-03 11:52:54 --> Model Class Initialized
DEBUG - 2023-06-03 11:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/change_password.php
DEBUG - 2023-06-03 11:52:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:52:54 --> Model Class Initialized
INFO - 2023-06-03 11:52:54 --> Model Class Initialized
INFO - 2023-06-03 11:52:54 --> Model Class Initialized
INFO - 2023-06-03 11:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:52:54 --> Final output sent to browser
DEBUG - 2023-06-03 11:52:54 --> Total execution time: 0.0702
ERROR - 2023-06-03 11:52:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:52:56 --> Config Class Initialized
INFO - 2023-06-03 11:52:56 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:52:56 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:52:56 --> Utf8 Class Initialized
INFO - 2023-06-03 11:52:56 --> URI Class Initialized
DEBUG - 2023-06-03 11:52:56 --> No URI present. Default controller set.
INFO - 2023-06-03 11:52:56 --> Router Class Initialized
INFO - 2023-06-03 11:52:56 --> Output Class Initialized
INFO - 2023-06-03 11:52:56 --> Security Class Initialized
DEBUG - 2023-06-03 11:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:52:56 --> Input Class Initialized
INFO - 2023-06-03 11:52:56 --> Language Class Initialized
INFO - 2023-06-03 11:52:56 --> Loader Class Initialized
INFO - 2023-06-03 11:52:56 --> Helper loaded: url_helper
INFO - 2023-06-03 11:52:56 --> Helper loaded: file_helper
INFO - 2023-06-03 11:52:56 --> Helper loaded: html_helper
INFO - 2023-06-03 11:52:56 --> Helper loaded: text_helper
INFO - 2023-06-03 11:52:56 --> Helper loaded: form_helper
INFO - 2023-06-03 11:52:56 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:52:56 --> Helper loaded: security_helper
INFO - 2023-06-03 11:52:56 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:52:56 --> Database Driver Class Initialized
INFO - 2023-06-03 11:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:52:56 --> Parser Class Initialized
INFO - 2023-06-03 11:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:52:56 --> Pagination Class Initialized
INFO - 2023-06-03 11:52:56 --> Form Validation Class Initialized
INFO - 2023-06-03 11:52:56 --> Controller Class Initialized
INFO - 2023-06-03 11:52:56 --> Model Class Initialized
DEBUG - 2023-06-03 11:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:56 --> Model Class Initialized
DEBUG - 2023-06-03 11:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:56 --> Model Class Initialized
INFO - 2023-06-03 11:52:56 --> Model Class Initialized
INFO - 2023-06-03 11:52:56 --> Model Class Initialized
INFO - 2023-06-03 11:52:56 --> Model Class Initialized
DEBUG - 2023-06-03 11:52:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:56 --> Model Class Initialized
INFO - 2023-06-03 11:52:56 --> Model Class Initialized
INFO - 2023-06-03 11:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 11:52:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:52:56 --> Model Class Initialized
INFO - 2023-06-03 11:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:52:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:52:56 --> Final output sent to browser
DEBUG - 2023-06-03 11:52:56 --> Total execution time: 0.0666
ERROR - 2023-06-03 11:53:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:53:04 --> Config Class Initialized
INFO - 2023-06-03 11:53:04 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:53:04 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:53:04 --> Utf8 Class Initialized
INFO - 2023-06-03 11:53:04 --> URI Class Initialized
INFO - 2023-06-03 11:53:04 --> Router Class Initialized
INFO - 2023-06-03 11:53:04 --> Output Class Initialized
INFO - 2023-06-03 11:53:04 --> Security Class Initialized
DEBUG - 2023-06-03 11:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:53:04 --> Input Class Initialized
INFO - 2023-06-03 11:53:04 --> Language Class Initialized
INFO - 2023-06-03 11:53:04 --> Loader Class Initialized
INFO - 2023-06-03 11:53:04 --> Helper loaded: url_helper
INFO - 2023-06-03 11:53:04 --> Helper loaded: file_helper
INFO - 2023-06-03 11:53:04 --> Helper loaded: html_helper
INFO - 2023-06-03 11:53:04 --> Helper loaded: text_helper
INFO - 2023-06-03 11:53:04 --> Helper loaded: form_helper
INFO - 2023-06-03 11:53:04 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:53:04 --> Helper loaded: security_helper
INFO - 2023-06-03 11:53:04 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:53:04 --> Database Driver Class Initialized
INFO - 2023-06-03 11:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:53:04 --> Parser Class Initialized
INFO - 2023-06-03 11:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:53:04 --> Pagination Class Initialized
INFO - 2023-06-03 11:53:04 --> Form Validation Class Initialized
INFO - 2023-06-03 11:53:04 --> Controller Class Initialized
INFO - 2023-06-03 11:53:04 --> Model Class Initialized
DEBUG - 2023-06-03 11:53:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:04 --> Model Class Initialized
DEBUG - 2023-06-03 11:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:04 --> Model Class Initialized
INFO - 2023-06-03 11:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-03 11:53:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:53:04 --> Model Class Initialized
INFO - 2023-06-03 11:53:04 --> Model Class Initialized
INFO - 2023-06-03 11:53:04 --> Model Class Initialized
INFO - 2023-06-03 11:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:53:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:53:04 --> Final output sent to browser
DEBUG - 2023-06-03 11:53:04 --> Total execution time: 0.0671
ERROR - 2023-06-03 11:53:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:53:05 --> Config Class Initialized
INFO - 2023-06-03 11:53:05 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:53:05 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:53:05 --> Utf8 Class Initialized
INFO - 2023-06-03 11:53:05 --> URI Class Initialized
INFO - 2023-06-03 11:53:05 --> Router Class Initialized
INFO - 2023-06-03 11:53:05 --> Output Class Initialized
INFO - 2023-06-03 11:53:05 --> Security Class Initialized
DEBUG - 2023-06-03 11:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:53:05 --> Input Class Initialized
INFO - 2023-06-03 11:53:05 --> Language Class Initialized
INFO - 2023-06-03 11:53:05 --> Loader Class Initialized
INFO - 2023-06-03 11:53:05 --> Helper loaded: url_helper
INFO - 2023-06-03 11:53:05 --> Helper loaded: file_helper
INFO - 2023-06-03 11:53:05 --> Helper loaded: html_helper
INFO - 2023-06-03 11:53:05 --> Helper loaded: text_helper
INFO - 2023-06-03 11:53:05 --> Helper loaded: form_helper
INFO - 2023-06-03 11:53:05 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:53:05 --> Helper loaded: security_helper
INFO - 2023-06-03 11:53:05 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:53:05 --> Database Driver Class Initialized
INFO - 2023-06-03 11:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:53:05 --> Parser Class Initialized
INFO - 2023-06-03 11:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:53:05 --> Pagination Class Initialized
INFO - 2023-06-03 11:53:05 --> Form Validation Class Initialized
INFO - 2023-06-03 11:53:05 --> Controller Class Initialized
INFO - 2023-06-03 11:53:05 --> Model Class Initialized
DEBUG - 2023-06-03 11:53:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:05 --> Model Class Initialized
DEBUG - 2023-06-03 11:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:05 --> Model Class Initialized
INFO - 2023-06-03 11:53:05 --> Final output sent to browser
DEBUG - 2023-06-03 11:53:05 --> Total execution time: 0.0199
ERROR - 2023-06-03 11:53:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:53:32 --> Config Class Initialized
INFO - 2023-06-03 11:53:32 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:53:32 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:53:32 --> Utf8 Class Initialized
INFO - 2023-06-03 11:53:32 --> URI Class Initialized
INFO - 2023-06-03 11:53:32 --> Router Class Initialized
INFO - 2023-06-03 11:53:32 --> Output Class Initialized
INFO - 2023-06-03 11:53:32 --> Security Class Initialized
DEBUG - 2023-06-03 11:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:53:32 --> Input Class Initialized
INFO - 2023-06-03 11:53:32 --> Language Class Initialized
INFO - 2023-06-03 11:53:32 --> Loader Class Initialized
INFO - 2023-06-03 11:53:32 --> Helper loaded: url_helper
INFO - 2023-06-03 11:53:32 --> Helper loaded: file_helper
INFO - 2023-06-03 11:53:32 --> Helper loaded: html_helper
INFO - 2023-06-03 11:53:32 --> Helper loaded: text_helper
INFO - 2023-06-03 11:53:32 --> Helper loaded: form_helper
INFO - 2023-06-03 11:53:32 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:53:32 --> Helper loaded: security_helper
INFO - 2023-06-03 11:53:32 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:53:32 --> Database Driver Class Initialized
INFO - 2023-06-03 11:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:53:32 --> Parser Class Initialized
INFO - 2023-06-03 11:53:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:53:32 --> Pagination Class Initialized
INFO - 2023-06-03 11:53:32 --> Form Validation Class Initialized
INFO - 2023-06-03 11:53:32 --> Controller Class Initialized
INFO - 2023-06-03 11:53:32 --> Model Class Initialized
DEBUG - 2023-06-03 11:53:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:32 --> Model Class Initialized
DEBUG - 2023-06-03 11:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:32 --> Model Class Initialized
INFO - 2023-06-03 11:53:32 --> Final output sent to browser
DEBUG - 2023-06-03 11:53:32 --> Total execution time: 0.0227
ERROR - 2023-06-03 11:53:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:53:53 --> Config Class Initialized
INFO - 2023-06-03 11:53:53 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:53:53 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:53:53 --> Utf8 Class Initialized
INFO - 2023-06-03 11:53:53 --> URI Class Initialized
DEBUG - 2023-06-03 11:53:53 --> No URI present. Default controller set.
INFO - 2023-06-03 11:53:53 --> Router Class Initialized
INFO - 2023-06-03 11:53:53 --> Output Class Initialized
INFO - 2023-06-03 11:53:53 --> Security Class Initialized
DEBUG - 2023-06-03 11:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:53:53 --> Input Class Initialized
INFO - 2023-06-03 11:53:53 --> Language Class Initialized
INFO - 2023-06-03 11:53:53 --> Loader Class Initialized
INFO - 2023-06-03 11:53:53 --> Helper loaded: url_helper
INFO - 2023-06-03 11:53:53 --> Helper loaded: file_helper
INFO - 2023-06-03 11:53:53 --> Helper loaded: html_helper
INFO - 2023-06-03 11:53:53 --> Helper loaded: text_helper
INFO - 2023-06-03 11:53:53 --> Helper loaded: form_helper
INFO - 2023-06-03 11:53:53 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:53:53 --> Helper loaded: security_helper
INFO - 2023-06-03 11:53:53 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:53:53 --> Database Driver Class Initialized
INFO - 2023-06-03 11:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:53:53 --> Parser Class Initialized
INFO - 2023-06-03 11:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:53:53 --> Pagination Class Initialized
INFO - 2023-06-03 11:53:53 --> Form Validation Class Initialized
INFO - 2023-06-03 11:53:53 --> Controller Class Initialized
INFO - 2023-06-03 11:53:53 --> Model Class Initialized
DEBUG - 2023-06-03 11:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:53 --> Model Class Initialized
DEBUG - 2023-06-03 11:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:53 --> Model Class Initialized
INFO - 2023-06-03 11:53:53 --> Model Class Initialized
INFO - 2023-06-03 11:53:53 --> Model Class Initialized
INFO - 2023-06-03 11:53:53 --> Model Class Initialized
DEBUG - 2023-06-03 11:53:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:53 --> Model Class Initialized
INFO - 2023-06-03 11:53:53 --> Model Class Initialized
INFO - 2023-06-03 11:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 11:53:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:53:53 --> Model Class Initialized
INFO - 2023-06-03 11:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:53:53 --> Final output sent to browser
DEBUG - 2023-06-03 11:53:53 --> Total execution time: 0.0712
ERROR - 2023-06-03 11:54:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:54:02 --> Config Class Initialized
INFO - 2023-06-03 11:54:02 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:54:02 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:54:02 --> Utf8 Class Initialized
INFO - 2023-06-03 11:54:02 --> URI Class Initialized
INFO - 2023-06-03 11:54:02 --> Router Class Initialized
INFO - 2023-06-03 11:54:02 --> Output Class Initialized
INFO - 2023-06-03 11:54:02 --> Security Class Initialized
DEBUG - 2023-06-03 11:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:54:02 --> Input Class Initialized
INFO - 2023-06-03 11:54:02 --> Language Class Initialized
INFO - 2023-06-03 11:54:02 --> Loader Class Initialized
INFO - 2023-06-03 11:54:02 --> Helper loaded: url_helper
INFO - 2023-06-03 11:54:02 --> Helper loaded: file_helper
INFO - 2023-06-03 11:54:02 --> Helper loaded: html_helper
INFO - 2023-06-03 11:54:02 --> Helper loaded: text_helper
INFO - 2023-06-03 11:54:02 --> Helper loaded: form_helper
INFO - 2023-06-03 11:54:02 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:54:02 --> Helper loaded: security_helper
INFO - 2023-06-03 11:54:02 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:54:02 --> Database Driver Class Initialized
INFO - 2023-06-03 11:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:54:02 --> Parser Class Initialized
INFO - 2023-06-03 11:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:54:02 --> Pagination Class Initialized
INFO - 2023-06-03 11:54:02 --> Form Validation Class Initialized
INFO - 2023-06-03 11:54:02 --> Controller Class Initialized
INFO - 2023-06-03 11:54:02 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:02 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:02 --> Model Class Initialized
INFO - 2023-06-03 11:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-03 11:54:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:54:02 --> Model Class Initialized
INFO - 2023-06-03 11:54:02 --> Model Class Initialized
INFO - 2023-06-03 11:54:02 --> Model Class Initialized
INFO - 2023-06-03 11:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:54:02 --> Final output sent to browser
DEBUG - 2023-06-03 11:54:02 --> Total execution time: 0.0645
ERROR - 2023-06-03 11:54:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:54:03 --> Config Class Initialized
INFO - 2023-06-03 11:54:03 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:54:03 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:54:03 --> Utf8 Class Initialized
INFO - 2023-06-03 11:54:03 --> URI Class Initialized
INFO - 2023-06-03 11:54:03 --> Router Class Initialized
INFO - 2023-06-03 11:54:03 --> Output Class Initialized
INFO - 2023-06-03 11:54:03 --> Security Class Initialized
DEBUG - 2023-06-03 11:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:54:03 --> Input Class Initialized
INFO - 2023-06-03 11:54:03 --> Language Class Initialized
INFO - 2023-06-03 11:54:03 --> Loader Class Initialized
INFO - 2023-06-03 11:54:03 --> Helper loaded: url_helper
INFO - 2023-06-03 11:54:03 --> Helper loaded: file_helper
INFO - 2023-06-03 11:54:03 --> Helper loaded: html_helper
INFO - 2023-06-03 11:54:03 --> Helper loaded: text_helper
INFO - 2023-06-03 11:54:03 --> Helper loaded: form_helper
INFO - 2023-06-03 11:54:03 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:54:03 --> Helper loaded: security_helper
INFO - 2023-06-03 11:54:03 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:54:03 --> Database Driver Class Initialized
INFO - 2023-06-03 11:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:54:03 --> Parser Class Initialized
INFO - 2023-06-03 11:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:54:03 --> Pagination Class Initialized
INFO - 2023-06-03 11:54:03 --> Form Validation Class Initialized
INFO - 2023-06-03 11:54:03 --> Controller Class Initialized
INFO - 2023-06-03 11:54:03 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:03 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:03 --> Model Class Initialized
INFO - 2023-06-03 11:54:03 --> Final output sent to browser
DEBUG - 2023-06-03 11:54:03 --> Total execution time: 0.0200
ERROR - 2023-06-03 11:54:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:54:17 --> Config Class Initialized
INFO - 2023-06-03 11:54:17 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:54:17 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:54:17 --> Utf8 Class Initialized
INFO - 2023-06-03 11:54:17 --> URI Class Initialized
DEBUG - 2023-06-03 11:54:17 --> No URI present. Default controller set.
INFO - 2023-06-03 11:54:17 --> Router Class Initialized
INFO - 2023-06-03 11:54:17 --> Output Class Initialized
INFO - 2023-06-03 11:54:17 --> Security Class Initialized
DEBUG - 2023-06-03 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:54:17 --> Input Class Initialized
INFO - 2023-06-03 11:54:17 --> Language Class Initialized
INFO - 2023-06-03 11:54:17 --> Loader Class Initialized
INFO - 2023-06-03 11:54:17 --> Helper loaded: url_helper
INFO - 2023-06-03 11:54:17 --> Helper loaded: file_helper
INFO - 2023-06-03 11:54:17 --> Helper loaded: html_helper
INFO - 2023-06-03 11:54:17 --> Helper loaded: text_helper
INFO - 2023-06-03 11:54:17 --> Helper loaded: form_helper
INFO - 2023-06-03 11:54:17 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:54:17 --> Helper loaded: security_helper
INFO - 2023-06-03 11:54:17 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:54:17 --> Database Driver Class Initialized
INFO - 2023-06-03 11:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:54:17 --> Parser Class Initialized
INFO - 2023-06-03 11:54:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:54:17 --> Pagination Class Initialized
INFO - 2023-06-03 11:54:17 --> Form Validation Class Initialized
INFO - 2023-06-03 11:54:17 --> Controller Class Initialized
INFO - 2023-06-03 11:54:17 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:17 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:17 --> Model Class Initialized
INFO - 2023-06-03 11:54:17 --> Model Class Initialized
INFO - 2023-06-03 11:54:17 --> Model Class Initialized
INFO - 2023-06-03 11:54:17 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:17 --> Model Class Initialized
INFO - 2023-06-03 11:54:17 --> Model Class Initialized
INFO - 2023-06-03 11:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 11:54:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:54:17 --> Model Class Initialized
INFO - 2023-06-03 11:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:54:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:54:17 --> Final output sent to browser
DEBUG - 2023-06-03 11:54:17 --> Total execution time: 0.0721
ERROR - 2023-06-03 11:54:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:54:19 --> Config Class Initialized
INFO - 2023-06-03 11:54:19 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:54:19 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:54:19 --> Utf8 Class Initialized
INFO - 2023-06-03 11:54:19 --> URI Class Initialized
INFO - 2023-06-03 11:54:19 --> Router Class Initialized
INFO - 2023-06-03 11:54:19 --> Output Class Initialized
INFO - 2023-06-03 11:54:19 --> Security Class Initialized
DEBUG - 2023-06-03 11:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:54:19 --> Input Class Initialized
INFO - 2023-06-03 11:54:19 --> Language Class Initialized
INFO - 2023-06-03 11:54:19 --> Loader Class Initialized
INFO - 2023-06-03 11:54:19 --> Helper loaded: url_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: file_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: html_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: text_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: form_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: security_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:54:19 --> Database Driver Class Initialized
INFO - 2023-06-03 11:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:54:19 --> Parser Class Initialized
INFO - 2023-06-03 11:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:54:19 --> Pagination Class Initialized
INFO - 2023-06-03 11:54:19 --> Form Validation Class Initialized
INFO - 2023-06-03 11:54:19 --> Controller Class Initialized
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 11:54:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:54:19 --> Final output sent to browser
DEBUG - 2023-06-03 11:54:19 --> Total execution time: 0.0339
ERROR - 2023-06-03 11:54:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:54:19 --> Config Class Initialized
INFO - 2023-06-03 11:54:19 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:54:19 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:54:19 --> Utf8 Class Initialized
INFO - 2023-06-03 11:54:19 --> URI Class Initialized
INFO - 2023-06-03 11:54:19 --> Router Class Initialized
INFO - 2023-06-03 11:54:19 --> Output Class Initialized
INFO - 2023-06-03 11:54:19 --> Security Class Initialized
DEBUG - 2023-06-03 11:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:54:19 --> Input Class Initialized
INFO - 2023-06-03 11:54:19 --> Language Class Initialized
INFO - 2023-06-03 11:54:19 --> Loader Class Initialized
INFO - 2023-06-03 11:54:19 --> Helper loaded: url_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: file_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: html_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: text_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: form_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: security_helper
INFO - 2023-06-03 11:54:19 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:54:19 --> Database Driver Class Initialized
INFO - 2023-06-03 11:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:54:19 --> Parser Class Initialized
INFO - 2023-06-03 11:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:54:19 --> Pagination Class Initialized
INFO - 2023-06-03 11:54:19 --> Form Validation Class Initialized
INFO - 2023-06-03 11:54:19 --> Controller Class Initialized
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 11:54:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:54:19 --> Model Class Initialized
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:54:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:54:19 --> Final output sent to browser
DEBUG - 2023-06-03 11:54:19 --> Total execution time: 0.0662
ERROR - 2023-06-03 11:54:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 11:54:32 --> Config Class Initialized
INFO - 2023-06-03 11:54:32 --> Hooks Class Initialized
DEBUG - 2023-06-03 11:54:32 --> UTF-8 Support Enabled
INFO - 2023-06-03 11:54:32 --> Utf8 Class Initialized
INFO - 2023-06-03 11:54:32 --> URI Class Initialized
DEBUG - 2023-06-03 11:54:32 --> No URI present. Default controller set.
INFO - 2023-06-03 11:54:32 --> Router Class Initialized
INFO - 2023-06-03 11:54:32 --> Output Class Initialized
INFO - 2023-06-03 11:54:32 --> Security Class Initialized
DEBUG - 2023-06-03 11:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 11:54:32 --> Input Class Initialized
INFO - 2023-06-03 11:54:32 --> Language Class Initialized
INFO - 2023-06-03 11:54:32 --> Loader Class Initialized
INFO - 2023-06-03 11:54:32 --> Helper loaded: url_helper
INFO - 2023-06-03 11:54:32 --> Helper loaded: file_helper
INFO - 2023-06-03 11:54:32 --> Helper loaded: html_helper
INFO - 2023-06-03 11:54:32 --> Helper loaded: text_helper
INFO - 2023-06-03 11:54:32 --> Helper loaded: form_helper
INFO - 2023-06-03 11:54:32 --> Helper loaded: lang_helper
INFO - 2023-06-03 11:54:32 --> Helper loaded: security_helper
INFO - 2023-06-03 11:54:32 --> Helper loaded: cookie_helper
INFO - 2023-06-03 11:54:32 --> Database Driver Class Initialized
INFO - 2023-06-03 11:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 11:54:32 --> Parser Class Initialized
INFO - 2023-06-03 11:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 11:54:32 --> Pagination Class Initialized
INFO - 2023-06-03 11:54:32 --> Form Validation Class Initialized
INFO - 2023-06-03 11:54:32 --> Controller Class Initialized
INFO - 2023-06-03 11:54:32 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:32 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:32 --> Model Class Initialized
INFO - 2023-06-03 11:54:32 --> Model Class Initialized
INFO - 2023-06-03 11:54:32 --> Model Class Initialized
INFO - 2023-06-03 11:54:32 --> Model Class Initialized
DEBUG - 2023-06-03 11:54:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-03 11:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:32 --> Model Class Initialized
INFO - 2023-06-03 11:54:32 --> Model Class Initialized
INFO - 2023-06-03 11:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-03 11:54:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 11:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 11:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 11:54:32 --> Model Class Initialized
INFO - 2023-06-03 11:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-03 11:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-03 11:54:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 11:54:32 --> Final output sent to browser
DEBUG - 2023-06-03 11:54:32 --> Total execution time: 0.0688
ERROR - 2023-06-03 14:35:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 14:35:11 --> Config Class Initialized
INFO - 2023-06-03 14:35:11 --> Hooks Class Initialized
DEBUG - 2023-06-03 14:35:11 --> UTF-8 Support Enabled
INFO - 2023-06-03 14:35:11 --> Utf8 Class Initialized
INFO - 2023-06-03 14:35:11 --> URI Class Initialized
DEBUG - 2023-06-03 14:35:11 --> No URI present. Default controller set.
INFO - 2023-06-03 14:35:11 --> Router Class Initialized
INFO - 2023-06-03 14:35:11 --> Output Class Initialized
INFO - 2023-06-03 14:35:11 --> Security Class Initialized
DEBUG - 2023-06-03 14:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 14:35:11 --> Input Class Initialized
INFO - 2023-06-03 14:35:11 --> Language Class Initialized
INFO - 2023-06-03 14:35:11 --> Loader Class Initialized
INFO - 2023-06-03 14:35:11 --> Helper loaded: url_helper
INFO - 2023-06-03 14:35:11 --> Helper loaded: file_helper
INFO - 2023-06-03 14:35:11 --> Helper loaded: html_helper
INFO - 2023-06-03 14:35:11 --> Helper loaded: text_helper
INFO - 2023-06-03 14:35:11 --> Helper loaded: form_helper
INFO - 2023-06-03 14:35:11 --> Helper loaded: lang_helper
INFO - 2023-06-03 14:35:11 --> Helper loaded: security_helper
INFO - 2023-06-03 14:35:11 --> Helper loaded: cookie_helper
INFO - 2023-06-03 14:35:11 --> Database Driver Class Initialized
INFO - 2023-06-03 14:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 14:35:11 --> Parser Class Initialized
INFO - 2023-06-03 14:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 14:35:11 --> Pagination Class Initialized
INFO - 2023-06-03 14:35:11 --> Form Validation Class Initialized
INFO - 2023-06-03 14:35:11 --> Controller Class Initialized
INFO - 2023-06-03 14:35:11 --> Model Class Initialized
DEBUG - 2023-06-03 14:35:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 14:35:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 14:35:12 --> Config Class Initialized
INFO - 2023-06-03 14:35:12 --> Hooks Class Initialized
DEBUG - 2023-06-03 14:35:12 --> UTF-8 Support Enabled
INFO - 2023-06-03 14:35:12 --> Utf8 Class Initialized
INFO - 2023-06-03 14:35:12 --> URI Class Initialized
INFO - 2023-06-03 14:35:12 --> Router Class Initialized
INFO - 2023-06-03 14:35:12 --> Output Class Initialized
INFO - 2023-06-03 14:35:12 --> Security Class Initialized
DEBUG - 2023-06-03 14:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 14:35:12 --> Input Class Initialized
INFO - 2023-06-03 14:35:12 --> Language Class Initialized
INFO - 2023-06-03 14:35:12 --> Loader Class Initialized
INFO - 2023-06-03 14:35:12 --> Helper loaded: url_helper
INFO - 2023-06-03 14:35:12 --> Helper loaded: file_helper
INFO - 2023-06-03 14:35:12 --> Helper loaded: html_helper
INFO - 2023-06-03 14:35:12 --> Helper loaded: text_helper
INFO - 2023-06-03 14:35:12 --> Helper loaded: form_helper
INFO - 2023-06-03 14:35:12 --> Helper loaded: lang_helper
INFO - 2023-06-03 14:35:12 --> Helper loaded: security_helper
INFO - 2023-06-03 14:35:12 --> Helper loaded: cookie_helper
INFO - 2023-06-03 14:35:12 --> Database Driver Class Initialized
INFO - 2023-06-03 14:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 14:35:12 --> Parser Class Initialized
INFO - 2023-06-03 14:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 14:35:12 --> Pagination Class Initialized
INFO - 2023-06-03 14:35:12 --> Form Validation Class Initialized
INFO - 2023-06-03 14:35:12 --> Controller Class Initialized
INFO - 2023-06-03 14:35:12 --> Model Class Initialized
DEBUG - 2023-06-03 14:35:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 14:35:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 14:35:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 14:35:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 14:35:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 14:35:12 --> Model Class Initialized
INFO - 2023-06-03 14:35:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 14:35:12 --> Final output sent to browser
DEBUG - 2023-06-03 14:35:12 --> Total execution time: 0.0363
ERROR - 2023-06-03 14:35:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 14:35:29 --> Config Class Initialized
INFO - 2023-06-03 14:35:29 --> Hooks Class Initialized
DEBUG - 2023-06-03 14:35:29 --> UTF-8 Support Enabled
INFO - 2023-06-03 14:35:29 --> Utf8 Class Initialized
INFO - 2023-06-03 14:35:29 --> URI Class Initialized
INFO - 2023-06-03 14:35:29 --> Router Class Initialized
INFO - 2023-06-03 14:35:29 --> Output Class Initialized
INFO - 2023-06-03 14:35:29 --> Security Class Initialized
DEBUG - 2023-06-03 14:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 14:35:29 --> Input Class Initialized
INFO - 2023-06-03 14:35:29 --> Language Class Initialized
INFO - 2023-06-03 14:35:29 --> Loader Class Initialized
INFO - 2023-06-03 14:35:29 --> Helper loaded: url_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: file_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: html_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: text_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: form_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: lang_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: security_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: cookie_helper
INFO - 2023-06-03 14:35:29 --> Database Driver Class Initialized
INFO - 2023-06-03 14:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 14:35:29 --> Parser Class Initialized
INFO - 2023-06-03 14:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 14:35:29 --> Pagination Class Initialized
INFO - 2023-06-03 14:35:29 --> Form Validation Class Initialized
INFO - 2023-06-03 14:35:29 --> Controller Class Initialized
INFO - 2023-06-03 14:35:29 --> Model Class Initialized
DEBUG - 2023-06-03 14:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 14:35:29 --> Model Class Initialized
INFO - 2023-06-03 14:35:29 --> Final output sent to browser
DEBUG - 2023-06-03 14:35:29 --> Total execution time: 0.0212
ERROR - 2023-06-03 14:35:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 14:35:29 --> Config Class Initialized
INFO - 2023-06-03 14:35:29 --> Hooks Class Initialized
DEBUG - 2023-06-03 14:35:29 --> UTF-8 Support Enabled
INFO - 2023-06-03 14:35:29 --> Utf8 Class Initialized
INFO - 2023-06-03 14:35:29 --> URI Class Initialized
INFO - 2023-06-03 14:35:29 --> Router Class Initialized
INFO - 2023-06-03 14:35:29 --> Output Class Initialized
INFO - 2023-06-03 14:35:29 --> Security Class Initialized
DEBUG - 2023-06-03 14:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 14:35:29 --> Input Class Initialized
INFO - 2023-06-03 14:35:29 --> Language Class Initialized
INFO - 2023-06-03 14:35:29 --> Loader Class Initialized
INFO - 2023-06-03 14:35:29 --> Helper loaded: url_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: file_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: html_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: text_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: form_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: lang_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: security_helper
INFO - 2023-06-03 14:35:29 --> Helper loaded: cookie_helper
INFO - 2023-06-03 14:35:29 --> Database Driver Class Initialized
INFO - 2023-06-03 14:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 14:35:29 --> Parser Class Initialized
INFO - 2023-06-03 14:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 14:35:29 --> Pagination Class Initialized
INFO - 2023-06-03 14:35:29 --> Form Validation Class Initialized
INFO - 2023-06-03 14:35:29 --> Controller Class Initialized
INFO - 2023-06-03 14:35:29 --> Model Class Initialized
DEBUG - 2023-06-03 14:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 14:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 14:35:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 14:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 14:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 14:35:29 --> Model Class Initialized
INFO - 2023-06-03 14:35:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 14:35:29 --> Final output sent to browser
DEBUG - 2023-06-03 14:35:29 --> Total execution time: 0.0390
ERROR - 2023-06-03 14:35:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 14:35:32 --> Config Class Initialized
INFO - 2023-06-03 14:35:32 --> Hooks Class Initialized
DEBUG - 2023-06-03 14:35:32 --> UTF-8 Support Enabled
INFO - 2023-06-03 14:35:32 --> Utf8 Class Initialized
INFO - 2023-06-03 14:35:32 --> URI Class Initialized
INFO - 2023-06-03 14:35:32 --> Router Class Initialized
INFO - 2023-06-03 14:35:32 --> Output Class Initialized
INFO - 2023-06-03 14:35:32 --> Security Class Initialized
DEBUG - 2023-06-03 14:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 14:35:32 --> Input Class Initialized
INFO - 2023-06-03 14:35:32 --> Language Class Initialized
INFO - 2023-06-03 14:35:32 --> Loader Class Initialized
INFO - 2023-06-03 14:35:32 --> Helper loaded: url_helper
INFO - 2023-06-03 14:35:32 --> Helper loaded: file_helper
INFO - 2023-06-03 14:35:32 --> Helper loaded: html_helper
INFO - 2023-06-03 14:35:32 --> Helper loaded: text_helper
INFO - 2023-06-03 14:35:32 --> Helper loaded: form_helper
INFO - 2023-06-03 14:35:32 --> Helper loaded: lang_helper
INFO - 2023-06-03 14:35:32 --> Helper loaded: security_helper
INFO - 2023-06-03 14:35:32 --> Helper loaded: cookie_helper
INFO - 2023-06-03 14:35:32 --> Database Driver Class Initialized
INFO - 2023-06-03 14:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 14:35:32 --> Parser Class Initialized
INFO - 2023-06-03 14:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 14:35:32 --> Pagination Class Initialized
INFO - 2023-06-03 14:35:32 --> Form Validation Class Initialized
INFO - 2023-06-03 14:35:32 --> Controller Class Initialized
INFO - 2023-06-03 14:35:32 --> Model Class Initialized
DEBUG - 2023-06-03 14:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 14:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 14:35:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 14:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 14:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 14:35:32 --> Model Class Initialized
INFO - 2023-06-03 14:35:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 14:35:32 --> Final output sent to browser
DEBUG - 2023-06-03 14:35:32 --> Total execution time: 0.0319
ERROR - 2023-06-03 14:36:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 14:36:40 --> Config Class Initialized
INFO - 2023-06-03 14:36:40 --> Hooks Class Initialized
DEBUG - 2023-06-03 14:36:40 --> UTF-8 Support Enabled
INFO - 2023-06-03 14:36:40 --> Utf8 Class Initialized
INFO - 2023-06-03 14:36:40 --> URI Class Initialized
DEBUG - 2023-06-03 14:36:40 --> No URI present. Default controller set.
INFO - 2023-06-03 14:36:40 --> Router Class Initialized
INFO - 2023-06-03 14:36:40 --> Output Class Initialized
INFO - 2023-06-03 14:36:40 --> Security Class Initialized
DEBUG - 2023-06-03 14:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 14:36:40 --> Input Class Initialized
INFO - 2023-06-03 14:36:40 --> Language Class Initialized
INFO - 2023-06-03 14:36:40 --> Loader Class Initialized
INFO - 2023-06-03 14:36:40 --> Helper loaded: url_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: file_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: html_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: text_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: form_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: lang_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: security_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: cookie_helper
INFO - 2023-06-03 14:36:40 --> Database Driver Class Initialized
INFO - 2023-06-03 14:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 14:36:40 --> Parser Class Initialized
INFO - 2023-06-03 14:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 14:36:40 --> Pagination Class Initialized
INFO - 2023-06-03 14:36:40 --> Form Validation Class Initialized
INFO - 2023-06-03 14:36:40 --> Controller Class Initialized
INFO - 2023-06-03 14:36:40 --> Model Class Initialized
DEBUG - 2023-06-03 14:36:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-03 14:36:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 14:36:40 --> Config Class Initialized
INFO - 2023-06-03 14:36:40 --> Hooks Class Initialized
DEBUG - 2023-06-03 14:36:40 --> UTF-8 Support Enabled
INFO - 2023-06-03 14:36:40 --> Utf8 Class Initialized
INFO - 2023-06-03 14:36:40 --> URI Class Initialized
INFO - 2023-06-03 14:36:40 --> Router Class Initialized
INFO - 2023-06-03 14:36:40 --> Output Class Initialized
INFO - 2023-06-03 14:36:40 --> Security Class Initialized
DEBUG - 2023-06-03 14:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 14:36:40 --> Input Class Initialized
INFO - 2023-06-03 14:36:40 --> Language Class Initialized
INFO - 2023-06-03 14:36:40 --> Loader Class Initialized
INFO - 2023-06-03 14:36:40 --> Helper loaded: url_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: file_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: html_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: text_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: form_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: lang_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: security_helper
INFO - 2023-06-03 14:36:40 --> Helper loaded: cookie_helper
INFO - 2023-06-03 14:36:40 --> Database Driver Class Initialized
INFO - 2023-06-03 14:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 14:36:40 --> Parser Class Initialized
INFO - 2023-06-03 14:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 14:36:40 --> Pagination Class Initialized
INFO - 2023-06-03 14:36:40 --> Form Validation Class Initialized
INFO - 2023-06-03 14:36:40 --> Controller Class Initialized
INFO - 2023-06-03 14:36:40 --> Model Class Initialized
DEBUG - 2023-06-03 14:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-03 14:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-03 14:36:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-03 14:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-03 14:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-03 14:36:40 --> Model Class Initialized
INFO - 2023-06-03 14:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-03 14:36:40 --> Final output sent to browser
DEBUG - 2023-06-03 14:36:40 --> Total execution time: 0.0292
ERROR - 2023-06-03 21:17:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-03 21:17:13 --> Config Class Initialized
INFO - 2023-06-03 21:17:13 --> Hooks Class Initialized
DEBUG - 2023-06-03 21:17:13 --> UTF-8 Support Enabled
INFO - 2023-06-03 21:17:13 --> Utf8 Class Initialized
INFO - 2023-06-03 21:17:13 --> URI Class Initialized
DEBUG - 2023-06-03 21:17:13 --> No URI present. Default controller set.
INFO - 2023-06-03 21:17:13 --> Router Class Initialized
INFO - 2023-06-03 21:17:13 --> Output Class Initialized
INFO - 2023-06-03 21:17:13 --> Security Class Initialized
DEBUG - 2023-06-03 21:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-03 21:17:13 --> Input Class Initialized
INFO - 2023-06-03 21:17:13 --> Language Class Initialized
INFO - 2023-06-03 21:17:13 --> Loader Class Initialized
INFO - 2023-06-03 21:17:13 --> Helper loaded: url_helper
INFO - 2023-06-03 21:17:13 --> Helper loaded: file_helper
INFO - 2023-06-03 21:17:13 --> Helper loaded: html_helper
INFO - 2023-06-03 21:17:13 --> Helper loaded: text_helper
INFO - 2023-06-03 21:17:13 --> Helper loaded: form_helper
INFO - 2023-06-03 21:17:13 --> Helper loaded: lang_helper
INFO - 2023-06-03 21:17:13 --> Helper loaded: security_helper
INFO - 2023-06-03 21:17:13 --> Helper loaded: cookie_helper
INFO - 2023-06-03 21:17:13 --> Database Driver Class Initialized
INFO - 2023-06-03 21:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-03 21:17:13 --> Parser Class Initialized
INFO - 2023-06-03 21:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-03 21:17:13 --> Pagination Class Initialized
INFO - 2023-06-03 21:17:13 --> Form Validation Class Initialized
INFO - 2023-06-03 21:17:13 --> Controller Class Initialized
INFO - 2023-06-03 21:17:13 --> Model Class Initialized
DEBUG - 2023-06-03 21:17:13 --> Session class already loaded. Second attempt ignored.
