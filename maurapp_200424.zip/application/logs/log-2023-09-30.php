<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-30 05:16:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:16:18 --> Config Class Initialized
INFO - 2023-09-30 05:16:18 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:16:18 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:16:18 --> Utf8 Class Initialized
INFO - 2023-09-30 05:16:18 --> URI Class Initialized
DEBUG - 2023-09-30 05:16:18 --> No URI present. Default controller set.
INFO - 2023-09-30 05:16:18 --> Router Class Initialized
INFO - 2023-09-30 05:16:18 --> Output Class Initialized
INFO - 2023-09-30 05:16:18 --> Security Class Initialized
DEBUG - 2023-09-30 05:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:16:18 --> Input Class Initialized
INFO - 2023-09-30 05:16:18 --> Language Class Initialized
INFO - 2023-09-30 05:16:18 --> Loader Class Initialized
INFO - 2023-09-30 05:16:18 --> Helper loaded: url_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: file_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: html_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: text_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: form_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: security_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:16:18 --> Database Driver Class Initialized
INFO - 2023-09-30 05:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:16:18 --> Parser Class Initialized
INFO - 2023-09-30 05:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:16:18 --> Pagination Class Initialized
INFO - 2023-09-30 05:16:18 --> Form Validation Class Initialized
INFO - 2023-09-30 05:16:18 --> Controller Class Initialized
INFO - 2023-09-30 05:16:18 --> Model Class Initialized
DEBUG - 2023-09-30 05:16:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-30 05:16:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:16:18 --> Config Class Initialized
INFO - 2023-09-30 05:16:18 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:16:18 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:16:18 --> Utf8 Class Initialized
INFO - 2023-09-30 05:16:18 --> URI Class Initialized
INFO - 2023-09-30 05:16:18 --> Router Class Initialized
INFO - 2023-09-30 05:16:18 --> Output Class Initialized
INFO - 2023-09-30 05:16:18 --> Security Class Initialized
DEBUG - 2023-09-30 05:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:16:18 --> Input Class Initialized
INFO - 2023-09-30 05:16:18 --> Language Class Initialized
INFO - 2023-09-30 05:16:18 --> Loader Class Initialized
INFO - 2023-09-30 05:16:18 --> Helper loaded: url_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: file_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: html_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: text_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: form_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: security_helper
INFO - 2023-09-30 05:16:18 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:16:18 --> Database Driver Class Initialized
INFO - 2023-09-30 05:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:16:18 --> Parser Class Initialized
INFO - 2023-09-30 05:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:16:18 --> Pagination Class Initialized
INFO - 2023-09-30 05:16:18 --> Form Validation Class Initialized
INFO - 2023-09-30 05:16:18 --> Controller Class Initialized
INFO - 2023-09-30 05:16:18 --> Model Class Initialized
DEBUG - 2023-09-30 05:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 05:16:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:16:18 --> Model Class Initialized
INFO - 2023-09-30 05:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:16:18 --> Final output sent to browser
DEBUG - 2023-09-30 05:16:18 --> Total execution time: 0.0342
ERROR - 2023-09-30 05:16:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:16:40 --> Config Class Initialized
INFO - 2023-09-30 05:16:40 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:16:40 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:16:40 --> Utf8 Class Initialized
INFO - 2023-09-30 05:16:40 --> URI Class Initialized
INFO - 2023-09-30 05:16:40 --> Router Class Initialized
INFO - 2023-09-30 05:16:40 --> Output Class Initialized
INFO - 2023-09-30 05:16:40 --> Security Class Initialized
DEBUG - 2023-09-30 05:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:16:40 --> Input Class Initialized
INFO - 2023-09-30 05:16:40 --> Language Class Initialized
INFO - 2023-09-30 05:16:40 --> Loader Class Initialized
INFO - 2023-09-30 05:16:40 --> Helper loaded: url_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: file_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: html_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: text_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: form_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: security_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:16:40 --> Database Driver Class Initialized
INFO - 2023-09-30 05:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:16:40 --> Parser Class Initialized
INFO - 2023-09-30 05:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:16:40 --> Pagination Class Initialized
INFO - 2023-09-30 05:16:40 --> Form Validation Class Initialized
INFO - 2023-09-30 05:16:40 --> Controller Class Initialized
INFO - 2023-09-30 05:16:40 --> Model Class Initialized
DEBUG - 2023-09-30 05:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:16:40 --> Model Class Initialized
INFO - 2023-09-30 05:16:40 --> Final output sent to browser
DEBUG - 2023-09-30 05:16:40 --> Total execution time: 0.0222
ERROR - 2023-09-30 05:16:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:16:40 --> Config Class Initialized
INFO - 2023-09-30 05:16:40 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:16:40 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:16:40 --> Utf8 Class Initialized
INFO - 2023-09-30 05:16:40 --> URI Class Initialized
INFO - 2023-09-30 05:16:40 --> Router Class Initialized
INFO - 2023-09-30 05:16:40 --> Output Class Initialized
INFO - 2023-09-30 05:16:40 --> Security Class Initialized
DEBUG - 2023-09-30 05:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:16:40 --> Input Class Initialized
INFO - 2023-09-30 05:16:40 --> Language Class Initialized
INFO - 2023-09-30 05:16:40 --> Loader Class Initialized
INFO - 2023-09-30 05:16:40 --> Helper loaded: url_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: file_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: html_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: text_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: form_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: security_helper
INFO - 2023-09-30 05:16:40 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:16:40 --> Database Driver Class Initialized
INFO - 2023-09-30 05:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:16:40 --> Parser Class Initialized
INFO - 2023-09-30 05:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:16:40 --> Pagination Class Initialized
INFO - 2023-09-30 05:16:40 --> Form Validation Class Initialized
INFO - 2023-09-30 05:16:40 --> Controller Class Initialized
INFO - 2023-09-30 05:16:40 --> Model Class Initialized
DEBUG - 2023-09-30 05:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 05:16:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:16:40 --> Model Class Initialized
INFO - 2023-09-30 05:16:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:16:40 --> Final output sent to browser
DEBUG - 2023-09-30 05:16:40 --> Total execution time: 0.0283
ERROR - 2023-09-30 05:16:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:16:48 --> Config Class Initialized
INFO - 2023-09-30 05:16:48 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:16:48 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:16:48 --> Utf8 Class Initialized
INFO - 2023-09-30 05:16:48 --> URI Class Initialized
INFO - 2023-09-30 05:16:48 --> Router Class Initialized
INFO - 2023-09-30 05:16:48 --> Output Class Initialized
INFO - 2023-09-30 05:16:48 --> Security Class Initialized
DEBUG - 2023-09-30 05:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:16:48 --> Input Class Initialized
INFO - 2023-09-30 05:16:48 --> Language Class Initialized
INFO - 2023-09-30 05:16:48 --> Loader Class Initialized
INFO - 2023-09-30 05:16:48 --> Helper loaded: url_helper
INFO - 2023-09-30 05:16:48 --> Helper loaded: file_helper
INFO - 2023-09-30 05:16:48 --> Helper loaded: html_helper
INFO - 2023-09-30 05:16:48 --> Helper loaded: text_helper
INFO - 2023-09-30 05:16:48 --> Helper loaded: form_helper
INFO - 2023-09-30 05:16:48 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:16:48 --> Helper loaded: security_helper
INFO - 2023-09-30 05:16:48 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:16:48 --> Database Driver Class Initialized
INFO - 2023-09-30 05:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:16:48 --> Parser Class Initialized
INFO - 2023-09-30 05:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:16:48 --> Pagination Class Initialized
INFO - 2023-09-30 05:16:48 --> Form Validation Class Initialized
INFO - 2023-09-30 05:16:48 --> Controller Class Initialized
INFO - 2023-09-30 05:16:48 --> Model Class Initialized
DEBUG - 2023-09-30 05:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 05:16:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:16:48 --> Model Class Initialized
INFO - 2023-09-30 05:16:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:16:48 --> Final output sent to browser
DEBUG - 2023-09-30 05:16:48 --> Total execution time: 0.0342
ERROR - 2023-09-30 05:21:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:21:54 --> Config Class Initialized
INFO - 2023-09-30 05:21:54 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:21:54 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:21:54 --> Utf8 Class Initialized
INFO - 2023-09-30 05:21:54 --> URI Class Initialized
DEBUG - 2023-09-30 05:21:54 --> No URI present. Default controller set.
INFO - 2023-09-30 05:21:54 --> Router Class Initialized
INFO - 2023-09-30 05:21:54 --> Output Class Initialized
INFO - 2023-09-30 05:21:54 --> Security Class Initialized
DEBUG - 2023-09-30 05:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:21:54 --> Input Class Initialized
INFO - 2023-09-30 05:21:54 --> Language Class Initialized
INFO - 2023-09-30 05:21:54 --> Loader Class Initialized
INFO - 2023-09-30 05:21:54 --> Helper loaded: url_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: file_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: html_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: text_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: form_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: security_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:21:54 --> Database Driver Class Initialized
INFO - 2023-09-30 05:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:21:54 --> Parser Class Initialized
INFO - 2023-09-30 05:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:21:54 --> Pagination Class Initialized
INFO - 2023-09-30 05:21:54 --> Form Validation Class Initialized
INFO - 2023-09-30 05:21:54 --> Controller Class Initialized
INFO - 2023-09-30 05:21:54 --> Model Class Initialized
DEBUG - 2023-09-30 05:21:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-30 05:21:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:21:54 --> Config Class Initialized
INFO - 2023-09-30 05:21:54 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:21:54 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:21:54 --> Utf8 Class Initialized
INFO - 2023-09-30 05:21:54 --> URI Class Initialized
INFO - 2023-09-30 05:21:54 --> Router Class Initialized
INFO - 2023-09-30 05:21:54 --> Output Class Initialized
INFO - 2023-09-30 05:21:54 --> Security Class Initialized
DEBUG - 2023-09-30 05:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:21:54 --> Input Class Initialized
INFO - 2023-09-30 05:21:54 --> Language Class Initialized
INFO - 2023-09-30 05:21:54 --> Loader Class Initialized
INFO - 2023-09-30 05:21:54 --> Helper loaded: url_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: file_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: html_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: text_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: form_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: security_helper
INFO - 2023-09-30 05:21:54 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:21:54 --> Database Driver Class Initialized
INFO - 2023-09-30 05:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:21:54 --> Parser Class Initialized
INFO - 2023-09-30 05:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:21:54 --> Pagination Class Initialized
INFO - 2023-09-30 05:21:54 --> Form Validation Class Initialized
INFO - 2023-09-30 05:21:54 --> Controller Class Initialized
INFO - 2023-09-30 05:21:54 --> Model Class Initialized
DEBUG - 2023-09-30 05:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 05:21:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:21:54 --> Model Class Initialized
INFO - 2023-09-30 05:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:21:54 --> Final output sent to browser
DEBUG - 2023-09-30 05:21:54 --> Total execution time: 0.0297
ERROR - 2023-09-30 05:22:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:22:12 --> Config Class Initialized
INFO - 2023-09-30 05:22:12 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:22:12 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:22:12 --> Utf8 Class Initialized
INFO - 2023-09-30 05:22:12 --> URI Class Initialized
INFO - 2023-09-30 05:22:12 --> Router Class Initialized
INFO - 2023-09-30 05:22:12 --> Output Class Initialized
INFO - 2023-09-30 05:22:12 --> Security Class Initialized
DEBUG - 2023-09-30 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:22:12 --> Input Class Initialized
INFO - 2023-09-30 05:22:12 --> Language Class Initialized
INFO - 2023-09-30 05:22:12 --> Loader Class Initialized
INFO - 2023-09-30 05:22:12 --> Helper loaded: url_helper
INFO - 2023-09-30 05:22:12 --> Helper loaded: file_helper
INFO - 2023-09-30 05:22:12 --> Helper loaded: html_helper
INFO - 2023-09-30 05:22:12 --> Helper loaded: text_helper
INFO - 2023-09-30 05:22:12 --> Helper loaded: form_helper
INFO - 2023-09-30 05:22:12 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:22:12 --> Helper loaded: security_helper
INFO - 2023-09-30 05:22:12 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:22:12 --> Database Driver Class Initialized
INFO - 2023-09-30 05:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:22:12 --> Parser Class Initialized
INFO - 2023-09-30 05:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:22:12 --> Pagination Class Initialized
INFO - 2023-09-30 05:22:12 --> Form Validation Class Initialized
INFO - 2023-09-30 05:22:12 --> Controller Class Initialized
INFO - 2023-09-30 05:22:12 --> Model Class Initialized
DEBUG - 2023-09-30 05:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:12 --> Model Class Initialized
INFO - 2023-09-30 05:22:12 --> Final output sent to browser
DEBUG - 2023-09-30 05:22:12 --> Total execution time: 0.0201
ERROR - 2023-09-30 05:22:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:22:13 --> Config Class Initialized
INFO - 2023-09-30 05:22:13 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:22:13 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:22:13 --> Utf8 Class Initialized
INFO - 2023-09-30 05:22:13 --> URI Class Initialized
INFO - 2023-09-30 05:22:13 --> Router Class Initialized
INFO - 2023-09-30 05:22:13 --> Output Class Initialized
INFO - 2023-09-30 05:22:13 --> Security Class Initialized
DEBUG - 2023-09-30 05:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:22:13 --> Input Class Initialized
INFO - 2023-09-30 05:22:13 --> Language Class Initialized
INFO - 2023-09-30 05:22:13 --> Loader Class Initialized
INFO - 2023-09-30 05:22:13 --> Helper loaded: url_helper
INFO - 2023-09-30 05:22:13 --> Helper loaded: file_helper
INFO - 2023-09-30 05:22:13 --> Helper loaded: html_helper
INFO - 2023-09-30 05:22:13 --> Helper loaded: text_helper
INFO - 2023-09-30 05:22:13 --> Helper loaded: form_helper
INFO - 2023-09-30 05:22:13 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:22:13 --> Helper loaded: security_helper
INFO - 2023-09-30 05:22:13 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:22:13 --> Database Driver Class Initialized
INFO - 2023-09-30 05:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:22:13 --> Parser Class Initialized
INFO - 2023-09-30 05:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:22:13 --> Pagination Class Initialized
INFO - 2023-09-30 05:22:13 --> Form Validation Class Initialized
INFO - 2023-09-30 05:22:13 --> Controller Class Initialized
INFO - 2023-09-30 05:22:13 --> Model Class Initialized
DEBUG - 2023-09-30 05:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 05:22:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:22:13 --> Model Class Initialized
INFO - 2023-09-30 05:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:22:13 --> Final output sent to browser
DEBUG - 2023-09-30 05:22:13 --> Total execution time: 0.0309
ERROR - 2023-09-30 05:22:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:22:37 --> Config Class Initialized
INFO - 2023-09-30 05:22:37 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:22:37 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:22:37 --> Utf8 Class Initialized
INFO - 2023-09-30 05:22:37 --> URI Class Initialized
INFO - 2023-09-30 05:22:37 --> Router Class Initialized
INFO - 2023-09-30 05:22:37 --> Output Class Initialized
INFO - 2023-09-30 05:22:37 --> Security Class Initialized
DEBUG - 2023-09-30 05:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:22:37 --> Input Class Initialized
INFO - 2023-09-30 05:22:37 --> Language Class Initialized
INFO - 2023-09-30 05:22:37 --> Loader Class Initialized
INFO - 2023-09-30 05:22:37 --> Helper loaded: url_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: file_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: html_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: text_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: form_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: security_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:22:37 --> Database Driver Class Initialized
INFO - 2023-09-30 05:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:22:37 --> Parser Class Initialized
INFO - 2023-09-30 05:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:22:37 --> Pagination Class Initialized
INFO - 2023-09-30 05:22:37 --> Form Validation Class Initialized
INFO - 2023-09-30 05:22:37 --> Controller Class Initialized
INFO - 2023-09-30 05:22:37 --> Model Class Initialized
DEBUG - 2023-09-30 05:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:37 --> Model Class Initialized
INFO - 2023-09-30 05:22:37 --> Final output sent to browser
DEBUG - 2023-09-30 05:22:37 --> Total execution time: 0.0196
ERROR - 2023-09-30 05:22:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:22:37 --> Config Class Initialized
INFO - 2023-09-30 05:22:37 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:22:37 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:22:37 --> Utf8 Class Initialized
INFO - 2023-09-30 05:22:37 --> URI Class Initialized
INFO - 2023-09-30 05:22:37 --> Router Class Initialized
INFO - 2023-09-30 05:22:37 --> Output Class Initialized
INFO - 2023-09-30 05:22:37 --> Security Class Initialized
DEBUG - 2023-09-30 05:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:22:37 --> Input Class Initialized
INFO - 2023-09-30 05:22:37 --> Language Class Initialized
INFO - 2023-09-30 05:22:37 --> Loader Class Initialized
INFO - 2023-09-30 05:22:37 --> Helper loaded: url_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: file_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: html_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: text_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: form_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: security_helper
INFO - 2023-09-30 05:22:37 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:22:37 --> Database Driver Class Initialized
INFO - 2023-09-30 05:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:22:37 --> Parser Class Initialized
INFO - 2023-09-30 05:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:22:37 --> Pagination Class Initialized
INFO - 2023-09-30 05:22:37 --> Form Validation Class Initialized
INFO - 2023-09-30 05:22:37 --> Controller Class Initialized
INFO - 2023-09-30 05:22:37 --> Model Class Initialized
DEBUG - 2023-09-30 05:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 05:22:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:22:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:22:37 --> Model Class Initialized
INFO - 2023-09-30 05:22:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:22:37 --> Final output sent to browser
DEBUG - 2023-09-30 05:22:37 --> Total execution time: 0.0311
ERROR - 2023-09-30 05:22:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:22:39 --> Config Class Initialized
INFO - 2023-09-30 05:22:39 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:22:39 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:22:39 --> Utf8 Class Initialized
INFO - 2023-09-30 05:22:39 --> URI Class Initialized
DEBUG - 2023-09-30 05:22:39 --> No URI present. Default controller set.
INFO - 2023-09-30 05:22:39 --> Router Class Initialized
INFO - 2023-09-30 05:22:39 --> Output Class Initialized
INFO - 2023-09-30 05:22:39 --> Security Class Initialized
DEBUG - 2023-09-30 05:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:22:39 --> Input Class Initialized
INFO - 2023-09-30 05:22:39 --> Language Class Initialized
INFO - 2023-09-30 05:22:39 --> Loader Class Initialized
INFO - 2023-09-30 05:22:39 --> Helper loaded: url_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: file_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: html_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: text_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: form_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: security_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:22:39 --> Database Driver Class Initialized
INFO - 2023-09-30 05:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:22:39 --> Parser Class Initialized
INFO - 2023-09-30 05:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:22:39 --> Pagination Class Initialized
INFO - 2023-09-30 05:22:39 --> Form Validation Class Initialized
INFO - 2023-09-30 05:22:39 --> Controller Class Initialized
INFO - 2023-09-30 05:22:39 --> Model Class Initialized
DEBUG - 2023-09-30 05:22:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-30 05:22:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:22:39 --> Config Class Initialized
INFO - 2023-09-30 05:22:39 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:22:39 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:22:39 --> Utf8 Class Initialized
INFO - 2023-09-30 05:22:39 --> URI Class Initialized
INFO - 2023-09-30 05:22:39 --> Router Class Initialized
INFO - 2023-09-30 05:22:39 --> Output Class Initialized
INFO - 2023-09-30 05:22:39 --> Security Class Initialized
DEBUG - 2023-09-30 05:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:22:39 --> Input Class Initialized
INFO - 2023-09-30 05:22:39 --> Language Class Initialized
INFO - 2023-09-30 05:22:39 --> Loader Class Initialized
INFO - 2023-09-30 05:22:39 --> Helper loaded: url_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: file_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: html_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: text_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: form_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: security_helper
INFO - 2023-09-30 05:22:39 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:22:39 --> Database Driver Class Initialized
INFO - 2023-09-30 05:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:22:39 --> Parser Class Initialized
INFO - 2023-09-30 05:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:22:39 --> Pagination Class Initialized
INFO - 2023-09-30 05:22:39 --> Form Validation Class Initialized
INFO - 2023-09-30 05:22:39 --> Controller Class Initialized
INFO - 2023-09-30 05:22:39 --> Model Class Initialized
DEBUG - 2023-09-30 05:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 05:22:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:22:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:22:39 --> Model Class Initialized
INFO - 2023-09-30 05:22:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:22:39 --> Final output sent to browser
DEBUG - 2023-09-30 05:22:39 --> Total execution time: 0.0279
ERROR - 2023-09-30 05:22:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:22:45 --> Config Class Initialized
INFO - 2023-09-30 05:22:45 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:22:45 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:22:45 --> Utf8 Class Initialized
INFO - 2023-09-30 05:22:45 --> URI Class Initialized
INFO - 2023-09-30 05:22:45 --> Router Class Initialized
INFO - 2023-09-30 05:22:45 --> Output Class Initialized
INFO - 2023-09-30 05:22:45 --> Security Class Initialized
DEBUG - 2023-09-30 05:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:22:45 --> Input Class Initialized
INFO - 2023-09-30 05:22:45 --> Language Class Initialized
INFO - 2023-09-30 05:22:45 --> Loader Class Initialized
INFO - 2023-09-30 05:22:45 --> Helper loaded: url_helper
INFO - 2023-09-30 05:22:45 --> Helper loaded: file_helper
INFO - 2023-09-30 05:22:45 --> Helper loaded: html_helper
INFO - 2023-09-30 05:22:45 --> Helper loaded: text_helper
INFO - 2023-09-30 05:22:45 --> Helper loaded: form_helper
INFO - 2023-09-30 05:22:45 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:22:45 --> Helper loaded: security_helper
INFO - 2023-09-30 05:22:45 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:22:45 --> Database Driver Class Initialized
INFO - 2023-09-30 05:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:22:45 --> Parser Class Initialized
INFO - 2023-09-30 05:22:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:22:45 --> Pagination Class Initialized
INFO - 2023-09-30 05:22:45 --> Form Validation Class Initialized
INFO - 2023-09-30 05:22:45 --> Controller Class Initialized
INFO - 2023-09-30 05:22:45 --> Model Class Initialized
DEBUG - 2023-09-30 05:22:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 05:22:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:22:45 --> Model Class Initialized
INFO - 2023-09-30 05:22:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:22:45 --> Final output sent to browser
DEBUG - 2023-09-30 05:22:45 --> Total execution time: 0.0295
ERROR - 2023-09-30 05:22:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:22:47 --> Config Class Initialized
INFO - 2023-09-30 05:22:47 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:22:47 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:22:47 --> Utf8 Class Initialized
INFO - 2023-09-30 05:22:47 --> URI Class Initialized
INFO - 2023-09-30 05:22:47 --> Router Class Initialized
INFO - 2023-09-30 05:22:47 --> Output Class Initialized
INFO - 2023-09-30 05:22:47 --> Security Class Initialized
DEBUG - 2023-09-30 05:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:22:47 --> Input Class Initialized
INFO - 2023-09-30 05:22:47 --> Language Class Initialized
INFO - 2023-09-30 05:22:47 --> Loader Class Initialized
INFO - 2023-09-30 05:22:47 --> Helper loaded: url_helper
INFO - 2023-09-30 05:22:47 --> Helper loaded: file_helper
INFO - 2023-09-30 05:22:47 --> Helper loaded: html_helper
INFO - 2023-09-30 05:22:47 --> Helper loaded: text_helper
INFO - 2023-09-30 05:22:47 --> Helper loaded: form_helper
INFO - 2023-09-30 05:22:47 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:22:47 --> Helper loaded: security_helper
INFO - 2023-09-30 05:22:47 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:22:47 --> Database Driver Class Initialized
INFO - 2023-09-30 05:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:22:47 --> Parser Class Initialized
INFO - 2023-09-30 05:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:22:47 --> Pagination Class Initialized
INFO - 2023-09-30 05:22:47 --> Form Validation Class Initialized
INFO - 2023-09-30 05:22:47 --> Controller Class Initialized
INFO - 2023-09-30 05:22:47 --> Model Class Initialized
DEBUG - 2023-09-30 05:22:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 05:22:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:22:47 --> Model Class Initialized
INFO - 2023-09-30 05:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:22:47 --> Final output sent to browser
DEBUG - 2023-09-30 05:22:47 --> Total execution time: 0.0282
ERROR - 2023-09-30 05:22:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:22:53 --> Config Class Initialized
INFO - 2023-09-30 05:22:53 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:22:53 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:22:53 --> Utf8 Class Initialized
INFO - 2023-09-30 05:22:53 --> URI Class Initialized
INFO - 2023-09-30 05:22:53 --> Router Class Initialized
INFO - 2023-09-30 05:22:53 --> Output Class Initialized
INFO - 2023-09-30 05:22:53 --> Security Class Initialized
DEBUG - 2023-09-30 05:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:22:53 --> Input Class Initialized
INFO - 2023-09-30 05:22:53 --> Language Class Initialized
INFO - 2023-09-30 05:22:53 --> Loader Class Initialized
INFO - 2023-09-30 05:22:53 --> Helper loaded: url_helper
INFO - 2023-09-30 05:22:53 --> Helper loaded: file_helper
INFO - 2023-09-30 05:22:53 --> Helper loaded: html_helper
INFO - 2023-09-30 05:22:53 --> Helper loaded: text_helper
INFO - 2023-09-30 05:22:53 --> Helper loaded: form_helper
INFO - 2023-09-30 05:22:53 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:22:53 --> Helper loaded: security_helper
INFO - 2023-09-30 05:22:53 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:22:53 --> Database Driver Class Initialized
INFO - 2023-09-30 05:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:22:53 --> Parser Class Initialized
INFO - 2023-09-30 05:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:22:53 --> Pagination Class Initialized
INFO - 2023-09-30 05:22:53 --> Form Validation Class Initialized
INFO - 2023-09-30 05:22:53 --> Controller Class Initialized
INFO - 2023-09-30 05:22:53 --> Model Class Initialized
DEBUG - 2023-09-30 05:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:22:53 --> Model Class Initialized
INFO - 2023-09-30 05:22:53 --> Final output sent to browser
DEBUG - 2023-09-30 05:22:53 --> Total execution time: 0.0162
ERROR - 2023-09-30 05:23:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:23:44 --> Config Class Initialized
INFO - 2023-09-30 05:23:44 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:23:44 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:23:44 --> Utf8 Class Initialized
INFO - 2023-09-30 05:23:44 --> URI Class Initialized
INFO - 2023-09-30 05:23:44 --> Router Class Initialized
INFO - 2023-09-30 05:23:44 --> Output Class Initialized
INFO - 2023-09-30 05:23:44 --> Security Class Initialized
DEBUG - 2023-09-30 05:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:23:44 --> Input Class Initialized
INFO - 2023-09-30 05:23:44 --> Language Class Initialized
INFO - 2023-09-30 05:23:44 --> Loader Class Initialized
INFO - 2023-09-30 05:23:44 --> Helper loaded: url_helper
INFO - 2023-09-30 05:23:44 --> Helper loaded: file_helper
INFO - 2023-09-30 05:23:44 --> Helper loaded: html_helper
INFO - 2023-09-30 05:23:44 --> Helper loaded: text_helper
INFO - 2023-09-30 05:23:44 --> Helper loaded: form_helper
INFO - 2023-09-30 05:23:44 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:23:44 --> Helper loaded: security_helper
INFO - 2023-09-30 05:23:44 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:23:44 --> Database Driver Class Initialized
INFO - 2023-09-30 05:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:23:44 --> Parser Class Initialized
INFO - 2023-09-30 05:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:23:44 --> Pagination Class Initialized
INFO - 2023-09-30 05:23:44 --> Form Validation Class Initialized
INFO - 2023-09-30 05:23:44 --> Controller Class Initialized
INFO - 2023-09-30 05:23:44 --> Model Class Initialized
DEBUG - 2023-09-30 05:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:23:44 --> Model Class Initialized
INFO - 2023-09-30 05:23:44 --> Final output sent to browser
DEBUG - 2023-09-30 05:23:44 --> Total execution time: 0.0189
ERROR - 2023-09-30 05:23:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:23:59 --> Config Class Initialized
INFO - 2023-09-30 05:23:59 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:23:59 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:23:59 --> Utf8 Class Initialized
INFO - 2023-09-30 05:23:59 --> URI Class Initialized
DEBUG - 2023-09-30 05:23:59 --> No URI present. Default controller set.
INFO - 2023-09-30 05:23:59 --> Router Class Initialized
INFO - 2023-09-30 05:23:59 --> Output Class Initialized
INFO - 2023-09-30 05:23:59 --> Security Class Initialized
DEBUG - 2023-09-30 05:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:23:59 --> Input Class Initialized
INFO - 2023-09-30 05:23:59 --> Language Class Initialized
INFO - 2023-09-30 05:23:59 --> Loader Class Initialized
INFO - 2023-09-30 05:23:59 --> Helper loaded: url_helper
INFO - 2023-09-30 05:23:59 --> Helper loaded: file_helper
INFO - 2023-09-30 05:23:59 --> Helper loaded: html_helper
INFO - 2023-09-30 05:23:59 --> Helper loaded: text_helper
INFO - 2023-09-30 05:23:59 --> Helper loaded: form_helper
INFO - 2023-09-30 05:23:59 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:23:59 --> Helper loaded: security_helper
INFO - 2023-09-30 05:23:59 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:23:59 --> Database Driver Class Initialized
INFO - 2023-09-30 05:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:23:59 --> Parser Class Initialized
INFO - 2023-09-30 05:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:23:59 --> Pagination Class Initialized
INFO - 2023-09-30 05:23:59 --> Form Validation Class Initialized
INFO - 2023-09-30 05:23:59 --> Controller Class Initialized
INFO - 2023-09-30 05:23:59 --> Model Class Initialized
DEBUG - 2023-09-30 05:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:23:59 --> Model Class Initialized
DEBUG - 2023-09-30 05:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:23:59 --> Model Class Initialized
INFO - 2023-09-30 05:23:59 --> Model Class Initialized
INFO - 2023-09-30 05:23:59 --> Model Class Initialized
INFO - 2023-09-30 05:23:59 --> Model Class Initialized
DEBUG - 2023-09-30 05:23:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:23:59 --> Model Class Initialized
INFO - 2023-09-30 05:23:59 --> Model Class Initialized
INFO - 2023-09-30 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-30 05:23:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:23:59 --> Model Class Initialized
INFO - 2023-09-30 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-30 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-30 05:23:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:23:59 --> Final output sent to browser
DEBUG - 2023-09-30 05:23:59 --> Total execution time: 0.2117
ERROR - 2023-09-30 05:25:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:25:09 --> Config Class Initialized
INFO - 2023-09-30 05:25:09 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:25:09 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:25:09 --> Utf8 Class Initialized
INFO - 2023-09-30 05:25:09 --> URI Class Initialized
INFO - 2023-09-30 05:25:09 --> Router Class Initialized
INFO - 2023-09-30 05:25:09 --> Output Class Initialized
INFO - 2023-09-30 05:25:09 --> Security Class Initialized
DEBUG - 2023-09-30 05:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:25:09 --> Input Class Initialized
INFO - 2023-09-30 05:25:09 --> Language Class Initialized
INFO - 2023-09-30 05:25:09 --> Loader Class Initialized
INFO - 2023-09-30 05:25:09 --> Helper loaded: url_helper
INFO - 2023-09-30 05:25:09 --> Helper loaded: file_helper
INFO - 2023-09-30 05:25:09 --> Helper loaded: html_helper
INFO - 2023-09-30 05:25:09 --> Helper loaded: text_helper
INFO - 2023-09-30 05:25:09 --> Helper loaded: form_helper
INFO - 2023-09-30 05:25:09 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:25:09 --> Helper loaded: security_helper
INFO - 2023-09-30 05:25:09 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:25:09 --> Database Driver Class Initialized
INFO - 2023-09-30 05:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:25:09 --> Parser Class Initialized
INFO - 2023-09-30 05:25:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:25:09 --> Pagination Class Initialized
INFO - 2023-09-30 05:25:09 --> Form Validation Class Initialized
INFO - 2023-09-30 05:25:09 --> Controller Class Initialized
DEBUG - 2023-09-30 05:25:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:25:09 --> Model Class Initialized
INFO - 2023-09-30 05:25:09 --> Final output sent to browser
DEBUG - 2023-09-30 05:25:09 --> Total execution time: 0.0148
ERROR - 2023-09-30 05:27:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:27:08 --> Config Class Initialized
INFO - 2023-09-30 05:27:08 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:27:08 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:27:08 --> Utf8 Class Initialized
INFO - 2023-09-30 05:27:08 --> URI Class Initialized
INFO - 2023-09-30 05:27:08 --> Router Class Initialized
INFO - 2023-09-30 05:27:08 --> Output Class Initialized
INFO - 2023-09-30 05:27:08 --> Security Class Initialized
DEBUG - 2023-09-30 05:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:27:08 --> Input Class Initialized
INFO - 2023-09-30 05:27:08 --> Language Class Initialized
INFO - 2023-09-30 05:27:08 --> Loader Class Initialized
INFO - 2023-09-30 05:27:08 --> Helper loaded: url_helper
INFO - 2023-09-30 05:27:08 --> Helper loaded: file_helper
INFO - 2023-09-30 05:27:08 --> Helper loaded: html_helper
INFO - 2023-09-30 05:27:08 --> Helper loaded: text_helper
INFO - 2023-09-30 05:27:08 --> Helper loaded: form_helper
INFO - 2023-09-30 05:27:08 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:27:08 --> Helper loaded: security_helper
INFO - 2023-09-30 05:27:08 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:27:08 --> Database Driver Class Initialized
INFO - 2023-09-30 05:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:27:08 --> Parser Class Initialized
INFO - 2023-09-30 05:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:27:08 --> Pagination Class Initialized
INFO - 2023-09-30 05:27:08 --> Form Validation Class Initialized
INFO - 2023-09-30 05:27:08 --> Controller Class Initialized
DEBUG - 2023-09-30 05:27:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:08 --> Model Class Initialized
DEBUG - 2023-09-30 05:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:08 --> Model Class Initialized
DEBUG - 2023-09-30 05:27:08 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:08 --> Model Class Initialized
INFO - 2023-09-30 05:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-09-30 05:27:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 05:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 05:27:08 --> Model Class Initialized
INFO - 2023-09-30 05:27:08 --> Model Class Initialized
INFO - 2023-09-30 05:27:08 --> Model Class Initialized
INFO - 2023-09-30 05:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-30 05:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-30 05:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 05:27:08 --> Final output sent to browser
DEBUG - 2023-09-30 05:27:08 --> Total execution time: 0.1677
ERROR - 2023-09-30 05:27:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:27:09 --> Config Class Initialized
INFO - 2023-09-30 05:27:09 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:27:09 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:27:09 --> Utf8 Class Initialized
INFO - 2023-09-30 05:27:09 --> URI Class Initialized
INFO - 2023-09-30 05:27:09 --> Router Class Initialized
INFO - 2023-09-30 05:27:09 --> Output Class Initialized
INFO - 2023-09-30 05:27:09 --> Security Class Initialized
DEBUG - 2023-09-30 05:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:27:09 --> Input Class Initialized
INFO - 2023-09-30 05:27:09 --> Language Class Initialized
INFO - 2023-09-30 05:27:09 --> Loader Class Initialized
INFO - 2023-09-30 05:27:09 --> Helper loaded: url_helper
INFO - 2023-09-30 05:27:09 --> Helper loaded: file_helper
INFO - 2023-09-30 05:27:09 --> Helper loaded: html_helper
INFO - 2023-09-30 05:27:09 --> Helper loaded: text_helper
INFO - 2023-09-30 05:27:09 --> Helper loaded: form_helper
INFO - 2023-09-30 05:27:09 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:27:09 --> Helper loaded: security_helper
INFO - 2023-09-30 05:27:09 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:27:09 --> Database Driver Class Initialized
INFO - 2023-09-30 05:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:27:09 --> Parser Class Initialized
INFO - 2023-09-30 05:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:27:09 --> Pagination Class Initialized
INFO - 2023-09-30 05:27:09 --> Form Validation Class Initialized
INFO - 2023-09-30 05:27:09 --> Controller Class Initialized
DEBUG - 2023-09-30 05:27:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:09 --> Model Class Initialized
DEBUG - 2023-09-30 05:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:09 --> Model Class Initialized
INFO - 2023-09-30 05:27:09 --> Final output sent to browser
DEBUG - 2023-09-30 05:27:09 --> Total execution time: 0.0343
ERROR - 2023-09-30 05:27:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:27:18 --> Config Class Initialized
INFO - 2023-09-30 05:27:18 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:27:18 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:27:18 --> Utf8 Class Initialized
INFO - 2023-09-30 05:27:18 --> URI Class Initialized
INFO - 2023-09-30 05:27:18 --> Router Class Initialized
INFO - 2023-09-30 05:27:18 --> Output Class Initialized
INFO - 2023-09-30 05:27:18 --> Security Class Initialized
DEBUG - 2023-09-30 05:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:27:18 --> Input Class Initialized
INFO - 2023-09-30 05:27:18 --> Language Class Initialized
INFO - 2023-09-30 05:27:18 --> Loader Class Initialized
INFO - 2023-09-30 05:27:18 --> Helper loaded: url_helper
INFO - 2023-09-30 05:27:18 --> Helper loaded: file_helper
INFO - 2023-09-30 05:27:18 --> Helper loaded: html_helper
INFO - 2023-09-30 05:27:18 --> Helper loaded: text_helper
INFO - 2023-09-30 05:27:18 --> Helper loaded: form_helper
INFO - 2023-09-30 05:27:18 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:27:18 --> Helper loaded: security_helper
INFO - 2023-09-30 05:27:18 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:27:18 --> Database Driver Class Initialized
INFO - 2023-09-30 05:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:27:18 --> Parser Class Initialized
INFO - 2023-09-30 05:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:27:18 --> Pagination Class Initialized
INFO - 2023-09-30 05:27:18 --> Form Validation Class Initialized
INFO - 2023-09-30 05:27:18 --> Controller Class Initialized
DEBUG - 2023-09-30 05:27:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:18 --> Model Class Initialized
DEBUG - 2023-09-30 05:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:18 --> Model Class Initialized
INFO - 2023-09-30 05:27:18 --> Final output sent to browser
DEBUG - 2023-09-30 05:27:18 --> Total execution time: 0.0338
ERROR - 2023-09-30 05:27:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:27:19 --> Config Class Initialized
INFO - 2023-09-30 05:27:19 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:27:19 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:27:19 --> Utf8 Class Initialized
INFO - 2023-09-30 05:27:19 --> URI Class Initialized
INFO - 2023-09-30 05:27:19 --> Router Class Initialized
INFO - 2023-09-30 05:27:19 --> Output Class Initialized
INFO - 2023-09-30 05:27:19 --> Security Class Initialized
DEBUG - 2023-09-30 05:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:27:19 --> Input Class Initialized
INFO - 2023-09-30 05:27:19 --> Language Class Initialized
INFO - 2023-09-30 05:27:19 --> Loader Class Initialized
INFO - 2023-09-30 05:27:19 --> Helper loaded: url_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: file_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: html_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: text_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: form_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: security_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:27:19 --> Database Driver Class Initialized
INFO - 2023-09-30 05:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:27:19 --> Parser Class Initialized
INFO - 2023-09-30 05:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:27:19 --> Pagination Class Initialized
INFO - 2023-09-30 05:27:19 --> Form Validation Class Initialized
INFO - 2023-09-30 05:27:19 --> Controller Class Initialized
DEBUG - 2023-09-30 05:27:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:19 --> Model Class Initialized
DEBUG - 2023-09-30 05:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:19 --> Model Class Initialized
INFO - 2023-09-30 05:27:19 --> Final output sent to browser
DEBUG - 2023-09-30 05:27:19 --> Total execution time: 0.0333
ERROR - 2023-09-30 05:27:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:27:19 --> Config Class Initialized
INFO - 2023-09-30 05:27:19 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:27:19 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:27:19 --> Utf8 Class Initialized
INFO - 2023-09-30 05:27:19 --> URI Class Initialized
INFO - 2023-09-30 05:27:19 --> Router Class Initialized
INFO - 2023-09-30 05:27:19 --> Output Class Initialized
INFO - 2023-09-30 05:27:19 --> Security Class Initialized
DEBUG - 2023-09-30 05:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:27:19 --> Input Class Initialized
INFO - 2023-09-30 05:27:19 --> Language Class Initialized
INFO - 2023-09-30 05:27:19 --> Loader Class Initialized
INFO - 2023-09-30 05:27:19 --> Helper loaded: url_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: file_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: html_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: text_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: form_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: security_helper
INFO - 2023-09-30 05:27:19 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:27:19 --> Database Driver Class Initialized
INFO - 2023-09-30 05:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:27:19 --> Parser Class Initialized
INFO - 2023-09-30 05:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:27:19 --> Pagination Class Initialized
INFO - 2023-09-30 05:27:19 --> Form Validation Class Initialized
INFO - 2023-09-30 05:27:19 --> Controller Class Initialized
DEBUG - 2023-09-30 05:27:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:19 --> Model Class Initialized
DEBUG - 2023-09-30 05:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:19 --> Model Class Initialized
INFO - 2023-09-30 05:27:19 --> Final output sent to browser
DEBUG - 2023-09-30 05:27:19 --> Total execution time: 0.0294
ERROR - 2023-09-30 05:27:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:27:20 --> Config Class Initialized
INFO - 2023-09-30 05:27:20 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:27:20 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:27:20 --> Utf8 Class Initialized
INFO - 2023-09-30 05:27:20 --> URI Class Initialized
INFO - 2023-09-30 05:27:20 --> Router Class Initialized
INFO - 2023-09-30 05:27:20 --> Output Class Initialized
INFO - 2023-09-30 05:27:20 --> Security Class Initialized
DEBUG - 2023-09-30 05:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:27:20 --> Input Class Initialized
INFO - 2023-09-30 05:27:20 --> Language Class Initialized
INFO - 2023-09-30 05:27:20 --> Loader Class Initialized
INFO - 2023-09-30 05:27:20 --> Helper loaded: url_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: file_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: html_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: text_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: form_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: security_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:27:20 --> Database Driver Class Initialized
INFO - 2023-09-30 05:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:27:20 --> Parser Class Initialized
INFO - 2023-09-30 05:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:27:20 --> Pagination Class Initialized
INFO - 2023-09-30 05:27:20 --> Form Validation Class Initialized
INFO - 2023-09-30 05:27:20 --> Controller Class Initialized
DEBUG - 2023-09-30 05:27:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:20 --> Model Class Initialized
DEBUG - 2023-09-30 05:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:20 --> Model Class Initialized
INFO - 2023-09-30 05:27:20 --> Final output sent to browser
DEBUG - 2023-09-30 05:27:20 --> Total execution time: 0.0171
ERROR - 2023-09-30 05:27:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:27:20 --> Config Class Initialized
INFO - 2023-09-30 05:27:20 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:27:20 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:27:20 --> Utf8 Class Initialized
INFO - 2023-09-30 05:27:20 --> URI Class Initialized
INFO - 2023-09-30 05:27:20 --> Router Class Initialized
INFO - 2023-09-30 05:27:20 --> Output Class Initialized
INFO - 2023-09-30 05:27:20 --> Security Class Initialized
DEBUG - 2023-09-30 05:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:27:20 --> Input Class Initialized
INFO - 2023-09-30 05:27:20 --> Language Class Initialized
INFO - 2023-09-30 05:27:20 --> Loader Class Initialized
INFO - 2023-09-30 05:27:20 --> Helper loaded: url_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: file_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: html_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: text_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: form_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: security_helper
INFO - 2023-09-30 05:27:20 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:27:20 --> Database Driver Class Initialized
INFO - 2023-09-30 05:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:27:20 --> Parser Class Initialized
INFO - 2023-09-30 05:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:27:20 --> Pagination Class Initialized
INFO - 2023-09-30 05:27:20 --> Form Validation Class Initialized
INFO - 2023-09-30 05:27:20 --> Controller Class Initialized
DEBUG - 2023-09-30 05:27:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:20 --> Model Class Initialized
DEBUG - 2023-09-30 05:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:20 --> Model Class Initialized
INFO - 2023-09-30 05:27:20 --> Final output sent to browser
DEBUG - 2023-09-30 05:27:20 --> Total execution time: 0.0219
ERROR - 2023-09-30 05:27:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 05:27:34 --> Config Class Initialized
INFO - 2023-09-30 05:27:34 --> Hooks Class Initialized
DEBUG - 2023-09-30 05:27:34 --> UTF-8 Support Enabled
INFO - 2023-09-30 05:27:34 --> Utf8 Class Initialized
INFO - 2023-09-30 05:27:34 --> URI Class Initialized
INFO - 2023-09-30 05:27:34 --> Router Class Initialized
INFO - 2023-09-30 05:27:34 --> Output Class Initialized
INFO - 2023-09-30 05:27:34 --> Security Class Initialized
DEBUG - 2023-09-30 05:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 05:27:34 --> Input Class Initialized
INFO - 2023-09-30 05:27:34 --> Language Class Initialized
INFO - 2023-09-30 05:27:34 --> Loader Class Initialized
INFO - 2023-09-30 05:27:34 --> Helper loaded: url_helper
INFO - 2023-09-30 05:27:34 --> Helper loaded: file_helper
INFO - 2023-09-30 05:27:34 --> Helper loaded: html_helper
INFO - 2023-09-30 05:27:34 --> Helper loaded: text_helper
INFO - 2023-09-30 05:27:34 --> Helper loaded: form_helper
INFO - 2023-09-30 05:27:34 --> Helper loaded: lang_helper
INFO - 2023-09-30 05:27:34 --> Helper loaded: security_helper
INFO - 2023-09-30 05:27:34 --> Helper loaded: cookie_helper
INFO - 2023-09-30 05:27:34 --> Database Driver Class Initialized
INFO - 2023-09-30 05:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 05:27:34 --> Parser Class Initialized
INFO - 2023-09-30 05:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 05:27:34 --> Pagination Class Initialized
INFO - 2023-09-30 05:27:34 --> Form Validation Class Initialized
INFO - 2023-09-30 05:27:34 --> Controller Class Initialized
DEBUG - 2023-09-30 05:27:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 05:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:34 --> Model Class Initialized
DEBUG - 2023-09-30 05:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 05:27:34 --> Model Class Initialized
INFO - 2023-09-30 05:27:34 --> Final output sent to browser
DEBUG - 2023-09-30 05:27:34 --> Total execution time: 0.0208
ERROR - 2023-09-30 08:06:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:06:59 --> Config Class Initialized
INFO - 2023-09-30 08:06:59 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:06:59 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:06:59 --> Utf8 Class Initialized
INFO - 2023-09-30 08:06:59 --> URI Class Initialized
DEBUG - 2023-09-30 08:06:59 --> No URI present. Default controller set.
INFO - 2023-09-30 08:06:59 --> Router Class Initialized
INFO - 2023-09-30 08:06:59 --> Output Class Initialized
INFO - 2023-09-30 08:06:59 --> Security Class Initialized
DEBUG - 2023-09-30 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:06:59 --> Input Class Initialized
INFO - 2023-09-30 08:06:59 --> Language Class Initialized
INFO - 2023-09-30 08:06:59 --> Loader Class Initialized
INFO - 2023-09-30 08:06:59 --> Helper loaded: url_helper
INFO - 2023-09-30 08:06:59 --> Helper loaded: file_helper
INFO - 2023-09-30 08:06:59 --> Helper loaded: html_helper
INFO - 2023-09-30 08:06:59 --> Helper loaded: text_helper
INFO - 2023-09-30 08:06:59 --> Helper loaded: form_helper
INFO - 2023-09-30 08:06:59 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:06:59 --> Helper loaded: security_helper
INFO - 2023-09-30 08:06:59 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:06:59 --> Database Driver Class Initialized
INFO - 2023-09-30 08:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:06:59 --> Parser Class Initialized
INFO - 2023-09-30 08:06:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:06:59 --> Pagination Class Initialized
INFO - 2023-09-30 08:06:59 --> Form Validation Class Initialized
INFO - 2023-09-30 08:06:59 --> Controller Class Initialized
INFO - 2023-09-30 08:06:59 --> Model Class Initialized
DEBUG - 2023-09-30 08:06:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-30 08:07:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:07:00 --> Config Class Initialized
INFO - 2023-09-30 08:07:00 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:07:00 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:07:00 --> Utf8 Class Initialized
INFO - 2023-09-30 08:07:00 --> URI Class Initialized
INFO - 2023-09-30 08:07:00 --> Router Class Initialized
INFO - 2023-09-30 08:07:00 --> Output Class Initialized
INFO - 2023-09-30 08:07:00 --> Security Class Initialized
DEBUG - 2023-09-30 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:07:00 --> Input Class Initialized
INFO - 2023-09-30 08:07:00 --> Language Class Initialized
INFO - 2023-09-30 08:07:00 --> Loader Class Initialized
INFO - 2023-09-30 08:07:00 --> Helper loaded: url_helper
INFO - 2023-09-30 08:07:00 --> Helper loaded: file_helper
INFO - 2023-09-30 08:07:00 --> Helper loaded: html_helper
INFO - 2023-09-30 08:07:00 --> Helper loaded: text_helper
INFO - 2023-09-30 08:07:00 --> Helper loaded: form_helper
INFO - 2023-09-30 08:07:00 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:07:00 --> Helper loaded: security_helper
INFO - 2023-09-30 08:07:00 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:07:00 --> Database Driver Class Initialized
INFO - 2023-09-30 08:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:07:00 --> Parser Class Initialized
INFO - 2023-09-30 08:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:07:00 --> Pagination Class Initialized
INFO - 2023-09-30 08:07:00 --> Form Validation Class Initialized
INFO - 2023-09-30 08:07:00 --> Controller Class Initialized
INFO - 2023-09-30 08:07:00 --> Model Class Initialized
DEBUG - 2023-09-30 08:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 08:07:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 08:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 08:07:00 --> Model Class Initialized
INFO - 2023-09-30 08:07:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 08:07:00 --> Final output sent to browser
DEBUG - 2023-09-30 08:07:00 --> Total execution time: 0.0332
ERROR - 2023-09-30 08:07:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:07:03 --> Config Class Initialized
INFO - 2023-09-30 08:07:03 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:07:03 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:07:03 --> Utf8 Class Initialized
INFO - 2023-09-30 08:07:03 --> URI Class Initialized
INFO - 2023-09-30 08:07:03 --> Router Class Initialized
INFO - 2023-09-30 08:07:03 --> Output Class Initialized
INFO - 2023-09-30 08:07:03 --> Security Class Initialized
DEBUG - 2023-09-30 08:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:07:03 --> Input Class Initialized
INFO - 2023-09-30 08:07:03 --> Language Class Initialized
INFO - 2023-09-30 08:07:03 --> Loader Class Initialized
INFO - 2023-09-30 08:07:03 --> Helper loaded: url_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: file_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: html_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: text_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: form_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: security_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:07:03 --> Database Driver Class Initialized
INFO - 2023-09-30 08:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:07:03 --> Parser Class Initialized
INFO - 2023-09-30 08:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:07:03 --> Pagination Class Initialized
INFO - 2023-09-30 08:07:03 --> Form Validation Class Initialized
INFO - 2023-09-30 08:07:03 --> Controller Class Initialized
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
DEBUG - 2023-09-30 08:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
INFO - 2023-09-30 08:07:03 --> Final output sent to browser
DEBUG - 2023-09-30 08:07:03 --> Total execution time: 0.0187
ERROR - 2023-09-30 08:07:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:07:03 --> Config Class Initialized
INFO - 2023-09-30 08:07:03 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:07:03 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:07:03 --> Utf8 Class Initialized
INFO - 2023-09-30 08:07:03 --> URI Class Initialized
DEBUG - 2023-09-30 08:07:03 --> No URI present. Default controller set.
INFO - 2023-09-30 08:07:03 --> Router Class Initialized
INFO - 2023-09-30 08:07:03 --> Output Class Initialized
INFO - 2023-09-30 08:07:03 --> Security Class Initialized
DEBUG - 2023-09-30 08:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:07:03 --> Input Class Initialized
INFO - 2023-09-30 08:07:03 --> Language Class Initialized
INFO - 2023-09-30 08:07:03 --> Loader Class Initialized
INFO - 2023-09-30 08:07:03 --> Helper loaded: url_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: file_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: html_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: text_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: form_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: security_helper
INFO - 2023-09-30 08:07:03 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:07:03 --> Database Driver Class Initialized
INFO - 2023-09-30 08:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:07:03 --> Parser Class Initialized
INFO - 2023-09-30 08:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:07:03 --> Pagination Class Initialized
INFO - 2023-09-30 08:07:03 --> Form Validation Class Initialized
INFO - 2023-09-30 08:07:03 --> Controller Class Initialized
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
DEBUG - 2023-09-30 08:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
DEBUG - 2023-09-30 08:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
DEBUG - 2023-09-30 08:07:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 08:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
INFO - 2023-09-30 08:07:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-30 08:07:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 08:07:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 08:07:03 --> Model Class Initialized
INFO - 2023-09-30 08:07:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-30 08:07:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-30 08:07:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 08:07:03 --> Final output sent to browser
DEBUG - 2023-09-30 08:07:03 --> Total execution time: 0.2204
ERROR - 2023-09-30 08:07:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:07:04 --> Config Class Initialized
INFO - 2023-09-30 08:07:04 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:07:04 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:07:04 --> Utf8 Class Initialized
INFO - 2023-09-30 08:07:04 --> URI Class Initialized
INFO - 2023-09-30 08:07:04 --> Router Class Initialized
INFO - 2023-09-30 08:07:04 --> Output Class Initialized
INFO - 2023-09-30 08:07:04 --> Security Class Initialized
DEBUG - 2023-09-30 08:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:07:04 --> Input Class Initialized
INFO - 2023-09-30 08:07:04 --> Language Class Initialized
INFO - 2023-09-30 08:07:04 --> Loader Class Initialized
INFO - 2023-09-30 08:07:04 --> Helper loaded: url_helper
INFO - 2023-09-30 08:07:04 --> Helper loaded: file_helper
INFO - 2023-09-30 08:07:04 --> Helper loaded: html_helper
INFO - 2023-09-30 08:07:04 --> Helper loaded: text_helper
INFO - 2023-09-30 08:07:04 --> Helper loaded: form_helper
INFO - 2023-09-30 08:07:04 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:07:04 --> Helper loaded: security_helper
INFO - 2023-09-30 08:07:04 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:07:04 --> Database Driver Class Initialized
INFO - 2023-09-30 08:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:07:04 --> Parser Class Initialized
INFO - 2023-09-30 08:07:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:07:04 --> Pagination Class Initialized
INFO - 2023-09-30 08:07:04 --> Form Validation Class Initialized
INFO - 2023-09-30 08:07:04 --> Controller Class Initialized
DEBUG - 2023-09-30 08:07:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 08:07:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:04 --> Model Class Initialized
INFO - 2023-09-30 08:07:04 --> Final output sent to browser
DEBUG - 2023-09-30 08:07:04 --> Total execution time: 0.0130
ERROR - 2023-09-30 08:07:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:07:46 --> Config Class Initialized
INFO - 2023-09-30 08:07:46 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:07:46 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:07:46 --> Utf8 Class Initialized
INFO - 2023-09-30 08:07:46 --> URI Class Initialized
INFO - 2023-09-30 08:07:46 --> Router Class Initialized
INFO - 2023-09-30 08:07:46 --> Output Class Initialized
INFO - 2023-09-30 08:07:46 --> Security Class Initialized
DEBUG - 2023-09-30 08:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:07:46 --> Input Class Initialized
INFO - 2023-09-30 08:07:46 --> Language Class Initialized
INFO - 2023-09-30 08:07:46 --> Loader Class Initialized
INFO - 2023-09-30 08:07:46 --> Helper loaded: url_helper
INFO - 2023-09-30 08:07:46 --> Helper loaded: file_helper
INFO - 2023-09-30 08:07:46 --> Helper loaded: html_helper
INFO - 2023-09-30 08:07:46 --> Helper loaded: text_helper
INFO - 2023-09-30 08:07:46 --> Helper loaded: form_helper
INFO - 2023-09-30 08:07:46 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:07:46 --> Helper loaded: security_helper
INFO - 2023-09-30 08:07:46 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:07:46 --> Database Driver Class Initialized
INFO - 2023-09-30 08:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:07:46 --> Parser Class Initialized
INFO - 2023-09-30 08:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:07:46 --> Pagination Class Initialized
INFO - 2023-09-30 08:07:46 --> Form Validation Class Initialized
INFO - 2023-09-30 08:07:46 --> Controller Class Initialized
DEBUG - 2023-09-30 08:07:46 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:46 --> Model Class Initialized
INFO - 2023-09-30 08:07:46 --> Model Class Initialized
INFO - 2023-09-30 08:07:46 --> Model Class Initialized
INFO - 2023-09-30 08:07:46 --> Model Class Initialized
INFO - 2023-09-30 08:07:46 --> Model Class Initialized
INFO - 2023-09-30 08:07:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_product_form.php
DEBUG - 2023-09-30 08:07:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:07:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 08:07:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 08:07:46 --> Model Class Initialized
INFO - 2023-09-30 08:07:46 --> Model Class Initialized
INFO - 2023-09-30 08:07:46 --> Model Class Initialized
INFO - 2023-09-30 08:07:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-30 08:07:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-30 08:07:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 08:07:46 --> Final output sent to browser
DEBUG - 2023-09-30 08:07:46 --> Total execution time: 0.1982
ERROR - 2023-09-30 08:11:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:11:58 --> Config Class Initialized
INFO - 2023-09-30 08:11:58 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:11:58 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:11:58 --> Utf8 Class Initialized
INFO - 2023-09-30 08:11:58 --> URI Class Initialized
INFO - 2023-09-30 08:11:58 --> Router Class Initialized
INFO - 2023-09-30 08:11:58 --> Output Class Initialized
INFO - 2023-09-30 08:11:58 --> Security Class Initialized
DEBUG - 2023-09-30 08:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:11:58 --> Input Class Initialized
INFO - 2023-09-30 08:11:58 --> Language Class Initialized
INFO - 2023-09-30 08:11:58 --> Loader Class Initialized
INFO - 2023-09-30 08:11:58 --> Helper loaded: url_helper
INFO - 2023-09-30 08:11:58 --> Helper loaded: file_helper
INFO - 2023-09-30 08:11:58 --> Helper loaded: html_helper
INFO - 2023-09-30 08:11:58 --> Helper loaded: text_helper
INFO - 2023-09-30 08:11:58 --> Helper loaded: form_helper
INFO - 2023-09-30 08:11:58 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:11:58 --> Helper loaded: security_helper
INFO - 2023-09-30 08:11:58 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:11:58 --> Database Driver Class Initialized
INFO - 2023-09-30 08:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:11:58 --> Parser Class Initialized
INFO - 2023-09-30 08:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:11:58 --> Pagination Class Initialized
INFO - 2023-09-30 08:11:58 --> Form Validation Class Initialized
INFO - 2023-09-30 08:11:58 --> Controller Class Initialized
DEBUG - 2023-09-30 08:11:58 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:11:58 --> Model Class Initialized
INFO - 2023-09-30 08:11:58 --> Model Class Initialized
INFO - 2023-09-30 08:11:58 --> Final output sent to browser
DEBUG - 2023-09-30 08:11:58 --> Total execution time: 0.0235
ERROR - 2023-09-30 08:12:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:12:29 --> Config Class Initialized
INFO - 2023-09-30 08:12:29 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:12:29 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:12:29 --> Utf8 Class Initialized
INFO - 2023-09-30 08:12:29 --> URI Class Initialized
INFO - 2023-09-30 08:12:29 --> Router Class Initialized
INFO - 2023-09-30 08:12:29 --> Output Class Initialized
INFO - 2023-09-30 08:12:29 --> Security Class Initialized
DEBUG - 2023-09-30 08:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:12:29 --> Input Class Initialized
INFO - 2023-09-30 08:12:29 --> Language Class Initialized
INFO - 2023-09-30 08:12:29 --> Loader Class Initialized
INFO - 2023-09-30 08:12:29 --> Helper loaded: url_helper
INFO - 2023-09-30 08:12:29 --> Helper loaded: file_helper
INFO - 2023-09-30 08:12:29 --> Helper loaded: html_helper
INFO - 2023-09-30 08:12:29 --> Helper loaded: text_helper
INFO - 2023-09-30 08:12:29 --> Helper loaded: form_helper
INFO - 2023-09-30 08:12:29 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:12:29 --> Helper loaded: security_helper
INFO - 2023-09-30 08:12:29 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:12:29 --> Database Driver Class Initialized
INFO - 2023-09-30 08:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:12:29 --> Parser Class Initialized
INFO - 2023-09-30 08:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:12:29 --> Pagination Class Initialized
INFO - 2023-09-30 08:12:29 --> Form Validation Class Initialized
INFO - 2023-09-30 08:12:29 --> Controller Class Initialized
DEBUG - 2023-09-30 08:12:29 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:12:29 --> Model Class Initialized
INFO - 2023-09-30 08:12:29 --> Model Class Initialized
INFO - 2023-09-30 08:12:29 --> Final output sent to browser
DEBUG - 2023-09-30 08:12:29 --> Total execution time: 0.0229
ERROR - 2023-09-30 08:12:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:12:39 --> Config Class Initialized
INFO - 2023-09-30 08:12:39 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:12:39 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:12:39 --> Utf8 Class Initialized
INFO - 2023-09-30 08:12:39 --> URI Class Initialized
DEBUG - 2023-09-30 08:12:39 --> No URI present. Default controller set.
INFO - 2023-09-30 08:12:39 --> Router Class Initialized
INFO - 2023-09-30 08:12:39 --> Output Class Initialized
INFO - 2023-09-30 08:12:39 --> Security Class Initialized
DEBUG - 2023-09-30 08:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:12:39 --> Input Class Initialized
INFO - 2023-09-30 08:12:39 --> Language Class Initialized
INFO - 2023-09-30 08:12:39 --> Loader Class Initialized
INFO - 2023-09-30 08:12:39 --> Helper loaded: url_helper
INFO - 2023-09-30 08:12:39 --> Helper loaded: file_helper
INFO - 2023-09-30 08:12:39 --> Helper loaded: html_helper
INFO - 2023-09-30 08:12:39 --> Helper loaded: text_helper
INFO - 2023-09-30 08:12:39 --> Helper loaded: form_helper
INFO - 2023-09-30 08:12:39 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:12:39 --> Helper loaded: security_helper
INFO - 2023-09-30 08:12:39 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:12:39 --> Database Driver Class Initialized
INFO - 2023-09-30 08:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:12:39 --> Parser Class Initialized
INFO - 2023-09-30 08:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:12:39 --> Pagination Class Initialized
INFO - 2023-09-30 08:12:39 --> Form Validation Class Initialized
INFO - 2023-09-30 08:12:39 --> Controller Class Initialized
INFO - 2023-09-30 08:12:39 --> Model Class Initialized
DEBUG - 2023-09-30 08:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:12:40 --> Model Class Initialized
DEBUG - 2023-09-30 08:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:12:40 --> Model Class Initialized
INFO - 2023-09-30 08:12:40 --> Model Class Initialized
INFO - 2023-09-30 08:12:40 --> Model Class Initialized
INFO - 2023-09-30 08:12:40 --> Model Class Initialized
DEBUG - 2023-09-30 08:12:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-30 08:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:12:40 --> Model Class Initialized
INFO - 2023-09-30 08:12:40 --> Model Class Initialized
INFO - 2023-09-30 08:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-30 08:12:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 08:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 08:12:40 --> Model Class Initialized
INFO - 2023-09-30 08:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-30 08:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-30 08:12:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 08:12:40 --> Final output sent to browser
DEBUG - 2023-09-30 08:12:40 --> Total execution time: 0.2322
ERROR - 2023-09-30 08:12:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:12:48 --> Config Class Initialized
INFO - 2023-09-30 08:12:48 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:12:48 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:12:48 --> Utf8 Class Initialized
INFO - 2023-09-30 08:12:48 --> URI Class Initialized
INFO - 2023-09-30 08:12:48 --> Router Class Initialized
INFO - 2023-09-30 08:12:48 --> Output Class Initialized
INFO - 2023-09-30 08:12:48 --> Security Class Initialized
DEBUG - 2023-09-30 08:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:12:48 --> Input Class Initialized
INFO - 2023-09-30 08:12:48 --> Language Class Initialized
INFO - 2023-09-30 08:12:48 --> Loader Class Initialized
INFO - 2023-09-30 08:12:48 --> Helper loaded: url_helper
INFO - 2023-09-30 08:12:48 --> Helper loaded: file_helper
INFO - 2023-09-30 08:12:48 --> Helper loaded: html_helper
INFO - 2023-09-30 08:12:48 --> Helper loaded: text_helper
INFO - 2023-09-30 08:12:48 --> Helper loaded: form_helper
INFO - 2023-09-30 08:12:48 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:12:48 --> Helper loaded: security_helper
INFO - 2023-09-30 08:12:48 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:12:48 --> Database Driver Class Initialized
INFO - 2023-09-30 08:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:12:48 --> Parser Class Initialized
INFO - 2023-09-30 08:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:12:48 --> Pagination Class Initialized
INFO - 2023-09-30 08:12:48 --> Form Validation Class Initialized
INFO - 2023-09-30 08:12:48 --> Controller Class Initialized
DEBUG - 2023-09-30 08:12:48 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:12:48 --> Model Class Initialized
INFO - 2023-09-30 08:12:48 --> Model Class Initialized
INFO - 2023-09-30 08:12:48 --> Model Class Initialized
INFO - 2023-09-30 08:12:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-09-30 08:12:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:12:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 08:12:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 08:12:48 --> Model Class Initialized
INFO - 2023-09-30 08:12:48 --> Model Class Initialized
INFO - 2023-09-30 08:12:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-30 08:12:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-30 08:12:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 08:12:48 --> Final output sent to browser
DEBUG - 2023-09-30 08:12:48 --> Total execution time: 0.1538
ERROR - 2023-09-30 08:12:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:12:51 --> Config Class Initialized
INFO - 2023-09-30 08:12:51 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:12:51 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:12:51 --> Utf8 Class Initialized
INFO - 2023-09-30 08:12:51 --> URI Class Initialized
INFO - 2023-09-30 08:12:51 --> Router Class Initialized
INFO - 2023-09-30 08:12:51 --> Output Class Initialized
INFO - 2023-09-30 08:12:51 --> Security Class Initialized
DEBUG - 2023-09-30 08:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:12:51 --> Input Class Initialized
INFO - 2023-09-30 08:12:51 --> Language Class Initialized
INFO - 2023-09-30 08:12:51 --> Loader Class Initialized
INFO - 2023-09-30 08:12:51 --> Helper loaded: url_helper
INFO - 2023-09-30 08:12:51 --> Helper loaded: file_helper
INFO - 2023-09-30 08:12:51 --> Helper loaded: html_helper
INFO - 2023-09-30 08:12:51 --> Helper loaded: text_helper
INFO - 2023-09-30 08:12:51 --> Helper loaded: form_helper
INFO - 2023-09-30 08:12:51 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:12:51 --> Helper loaded: security_helper
INFO - 2023-09-30 08:12:51 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:12:51 --> Database Driver Class Initialized
INFO - 2023-09-30 08:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:12:51 --> Parser Class Initialized
INFO - 2023-09-30 08:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:12:51 --> Pagination Class Initialized
INFO - 2023-09-30 08:12:51 --> Form Validation Class Initialized
INFO - 2023-09-30 08:12:51 --> Controller Class Initialized
DEBUG - 2023-09-30 08:12:51 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:12:51 --> Model Class Initialized
INFO - 2023-09-30 08:12:51 --> Model Class Initialized
INFO - 2023-09-30 08:12:51 --> Final output sent to browser
DEBUG - 2023-09-30 08:12:51 --> Total execution time: 0.0489
ERROR - 2023-09-30 08:13:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:13:12 --> Config Class Initialized
INFO - 2023-09-30 08:13:12 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:13:12 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:13:12 --> Utf8 Class Initialized
INFO - 2023-09-30 08:13:12 --> URI Class Initialized
INFO - 2023-09-30 08:13:12 --> Router Class Initialized
INFO - 2023-09-30 08:13:12 --> Output Class Initialized
INFO - 2023-09-30 08:13:12 --> Security Class Initialized
DEBUG - 2023-09-30 08:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:13:12 --> Input Class Initialized
INFO - 2023-09-30 08:13:12 --> Language Class Initialized
INFO - 2023-09-30 08:13:12 --> Loader Class Initialized
INFO - 2023-09-30 08:13:12 --> Helper loaded: url_helper
INFO - 2023-09-30 08:13:12 --> Helper loaded: file_helper
INFO - 2023-09-30 08:13:12 --> Helper loaded: html_helper
INFO - 2023-09-30 08:13:12 --> Helper loaded: text_helper
INFO - 2023-09-30 08:13:12 --> Helper loaded: form_helper
INFO - 2023-09-30 08:13:12 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:13:12 --> Helper loaded: security_helper
INFO - 2023-09-30 08:13:12 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:13:12 --> Database Driver Class Initialized
INFO - 2023-09-30 08:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:13:12 --> Parser Class Initialized
INFO - 2023-09-30 08:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:13:12 --> Pagination Class Initialized
INFO - 2023-09-30 08:13:12 --> Form Validation Class Initialized
INFO - 2023-09-30 08:13:12 --> Controller Class Initialized
DEBUG - 2023-09-30 08:13:12 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:13:12 --> Model Class Initialized
INFO - 2023-09-30 08:13:12 --> Model Class Initialized
INFO - 2023-09-30 08:13:12 --> Final output sent to browser
DEBUG - 2023-09-30 08:13:12 --> Total execution time: 0.1471
ERROR - 2023-09-30 08:13:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:13:28 --> Config Class Initialized
INFO - 2023-09-30 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:13:28 --> Utf8 Class Initialized
INFO - 2023-09-30 08:13:28 --> URI Class Initialized
INFO - 2023-09-30 08:13:28 --> Router Class Initialized
INFO - 2023-09-30 08:13:28 --> Output Class Initialized
INFO - 2023-09-30 08:13:28 --> Security Class Initialized
DEBUG - 2023-09-30 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:13:28 --> Input Class Initialized
INFO - 2023-09-30 08:13:28 --> Language Class Initialized
INFO - 2023-09-30 08:13:28 --> Loader Class Initialized
INFO - 2023-09-30 08:13:28 --> Helper loaded: url_helper
INFO - 2023-09-30 08:13:28 --> Helper loaded: file_helper
INFO - 2023-09-30 08:13:28 --> Helper loaded: html_helper
INFO - 2023-09-30 08:13:28 --> Helper loaded: text_helper
INFO - 2023-09-30 08:13:28 --> Helper loaded: form_helper
INFO - 2023-09-30 08:13:28 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:13:28 --> Helper loaded: security_helper
INFO - 2023-09-30 08:13:28 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:13:28 --> Database Driver Class Initialized
INFO - 2023-09-30 08:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:13:28 --> Parser Class Initialized
INFO - 2023-09-30 08:13:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:13:28 --> Pagination Class Initialized
INFO - 2023-09-30 08:13:28 --> Form Validation Class Initialized
INFO - 2023-09-30 08:13:28 --> Controller Class Initialized
DEBUG - 2023-09-30 08:13:28 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:13:28 --> Model Class Initialized
INFO - 2023-09-30 08:13:28 --> Model Class Initialized
INFO - 2023-09-30 08:13:28 --> Model Class Initialized
INFO - 2023-09-30 08:13:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-09-30 08:13:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:13:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 08:13:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 08:13:28 --> Model Class Initialized
INFO - 2023-09-30 08:13:28 --> Model Class Initialized
INFO - 2023-09-30 08:13:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-30 08:13:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-30 08:13:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 08:13:28 --> Final output sent to browser
DEBUG - 2023-09-30 08:13:28 --> Total execution time: 0.1735
ERROR - 2023-09-30 08:13:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:13:52 --> Config Class Initialized
INFO - 2023-09-30 08:13:52 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:13:52 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:13:52 --> Utf8 Class Initialized
INFO - 2023-09-30 08:13:52 --> URI Class Initialized
INFO - 2023-09-30 08:13:52 --> Router Class Initialized
INFO - 2023-09-30 08:13:52 --> Output Class Initialized
INFO - 2023-09-30 08:13:52 --> Security Class Initialized
DEBUG - 2023-09-30 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:13:52 --> Input Class Initialized
INFO - 2023-09-30 08:13:52 --> Language Class Initialized
INFO - 2023-09-30 08:13:52 --> Loader Class Initialized
INFO - 2023-09-30 08:13:52 --> Helper loaded: url_helper
INFO - 2023-09-30 08:13:52 --> Helper loaded: file_helper
INFO - 2023-09-30 08:13:52 --> Helper loaded: html_helper
INFO - 2023-09-30 08:13:52 --> Helper loaded: text_helper
INFO - 2023-09-30 08:13:52 --> Helper loaded: form_helper
INFO - 2023-09-30 08:13:52 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:13:52 --> Helper loaded: security_helper
INFO - 2023-09-30 08:13:52 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:13:52 --> Database Driver Class Initialized
INFO - 2023-09-30 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:13:52 --> Parser Class Initialized
INFO - 2023-09-30 08:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:13:52 --> Pagination Class Initialized
INFO - 2023-09-30 08:13:52 --> Form Validation Class Initialized
INFO - 2023-09-30 08:13:52 --> Controller Class Initialized
DEBUG - 2023-09-30 08:13:52 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:13:52 --> Model Class Initialized
INFO - 2023-09-30 08:13:52 --> Model Class Initialized
INFO - 2023-09-30 08:13:52 --> Final output sent to browser
DEBUG - 2023-09-30 08:13:52 --> Total execution time: 0.0501
ERROR - 2023-09-30 08:14:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:14:19 --> Config Class Initialized
INFO - 2023-09-30 08:14:19 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:14:19 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:14:19 --> Utf8 Class Initialized
INFO - 2023-09-30 08:14:19 --> URI Class Initialized
INFO - 2023-09-30 08:14:19 --> Router Class Initialized
INFO - 2023-09-30 08:14:19 --> Output Class Initialized
INFO - 2023-09-30 08:14:19 --> Security Class Initialized
DEBUG - 2023-09-30 08:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:14:19 --> Input Class Initialized
INFO - 2023-09-30 08:14:19 --> Language Class Initialized
INFO - 2023-09-30 08:14:19 --> Loader Class Initialized
INFO - 2023-09-30 08:14:19 --> Helper loaded: url_helper
INFO - 2023-09-30 08:14:19 --> Helper loaded: file_helper
INFO - 2023-09-30 08:14:19 --> Helper loaded: html_helper
INFO - 2023-09-30 08:14:19 --> Helper loaded: text_helper
INFO - 2023-09-30 08:14:19 --> Helper loaded: form_helper
INFO - 2023-09-30 08:14:19 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:14:19 --> Helper loaded: security_helper
INFO - 2023-09-30 08:14:19 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:14:19 --> Database Driver Class Initialized
INFO - 2023-09-30 08:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:14:19 --> Parser Class Initialized
INFO - 2023-09-30 08:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:14:19 --> Pagination Class Initialized
INFO - 2023-09-30 08:14:19 --> Form Validation Class Initialized
INFO - 2023-09-30 08:14:19 --> Controller Class Initialized
DEBUG - 2023-09-30 08:14:19 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:14:19 --> Model Class Initialized
INFO - 2023-09-30 08:14:19 --> Model Class Initialized
INFO - 2023-09-30 08:14:19 --> Final output sent to browser
DEBUG - 2023-09-30 08:14:19 --> Total execution time: 0.1372
ERROR - 2023-09-30 08:14:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:14:21 --> Config Class Initialized
INFO - 2023-09-30 08:14:21 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:14:21 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:14:21 --> Utf8 Class Initialized
INFO - 2023-09-30 08:14:21 --> URI Class Initialized
INFO - 2023-09-30 08:14:21 --> Router Class Initialized
INFO - 2023-09-30 08:14:21 --> Output Class Initialized
INFO - 2023-09-30 08:14:21 --> Security Class Initialized
DEBUG - 2023-09-30 08:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:14:21 --> Input Class Initialized
INFO - 2023-09-30 08:14:21 --> Language Class Initialized
INFO - 2023-09-30 08:14:21 --> Loader Class Initialized
INFO - 2023-09-30 08:14:21 --> Helper loaded: url_helper
INFO - 2023-09-30 08:14:21 --> Helper loaded: file_helper
INFO - 2023-09-30 08:14:21 --> Helper loaded: html_helper
INFO - 2023-09-30 08:14:21 --> Helper loaded: text_helper
INFO - 2023-09-30 08:14:21 --> Helper loaded: form_helper
INFO - 2023-09-30 08:14:21 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:14:21 --> Helper loaded: security_helper
INFO - 2023-09-30 08:14:21 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:14:21 --> Database Driver Class Initialized
INFO - 2023-09-30 08:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:14:21 --> Parser Class Initialized
INFO - 2023-09-30 08:14:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:14:21 --> Pagination Class Initialized
INFO - 2023-09-30 08:14:21 --> Form Validation Class Initialized
INFO - 2023-09-30 08:14:21 --> Controller Class Initialized
DEBUG - 2023-09-30 08:14:21 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:14:21 --> Model Class Initialized
INFO - 2023-09-30 08:14:21 --> Model Class Initialized
INFO - 2023-09-30 08:14:21 --> Final output sent to browser
DEBUG - 2023-09-30 08:14:21 --> Total execution time: 0.1520
ERROR - 2023-09-30 08:15:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 08:15:19 --> Config Class Initialized
INFO - 2023-09-30 08:15:19 --> Hooks Class Initialized
DEBUG - 2023-09-30 08:15:19 --> UTF-8 Support Enabled
INFO - 2023-09-30 08:15:19 --> Utf8 Class Initialized
INFO - 2023-09-30 08:15:19 --> URI Class Initialized
INFO - 2023-09-30 08:15:19 --> Router Class Initialized
INFO - 2023-09-30 08:15:19 --> Output Class Initialized
INFO - 2023-09-30 08:15:19 --> Security Class Initialized
DEBUG - 2023-09-30 08:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 08:15:19 --> Input Class Initialized
INFO - 2023-09-30 08:15:19 --> Language Class Initialized
INFO - 2023-09-30 08:15:19 --> Loader Class Initialized
INFO - 2023-09-30 08:15:19 --> Helper loaded: url_helper
INFO - 2023-09-30 08:15:19 --> Helper loaded: file_helper
INFO - 2023-09-30 08:15:19 --> Helper loaded: html_helper
INFO - 2023-09-30 08:15:19 --> Helper loaded: text_helper
INFO - 2023-09-30 08:15:19 --> Helper loaded: form_helper
INFO - 2023-09-30 08:15:19 --> Helper loaded: lang_helper
INFO - 2023-09-30 08:15:19 --> Helper loaded: security_helper
INFO - 2023-09-30 08:15:19 --> Helper loaded: cookie_helper
INFO - 2023-09-30 08:15:19 --> Database Driver Class Initialized
INFO - 2023-09-30 08:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 08:15:19 --> Parser Class Initialized
INFO - 2023-09-30 08:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 08:15:19 --> Pagination Class Initialized
INFO - 2023-09-30 08:15:19 --> Form Validation Class Initialized
INFO - 2023-09-30 08:15:19 --> Controller Class Initialized
DEBUG - 2023-09-30 08:15:19 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-09-30 08:15:19 --> Model Class Initialized
INFO - 2023-09-30 08:15:19 --> Model Class Initialized
ERROR - 2023-09-30 08:15:19 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: SELECT *
FROM `web_setting`
WHERE `product_id` = '19521476'
ERROR - 2023-09-30 08:15:19 --> Severity: error --> Exception: Call to a member function row() on bool /home/powera7m/app.maurnaturo.com/application/helpers/lang_helper.php 16
ERROR - 2023-09-30 11:16:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 11:16:25 --> Config Class Initialized
INFO - 2023-09-30 11:16:25 --> Hooks Class Initialized
DEBUG - 2023-09-30 11:16:25 --> UTF-8 Support Enabled
INFO - 2023-09-30 11:16:25 --> Utf8 Class Initialized
INFO - 2023-09-30 11:16:25 --> URI Class Initialized
DEBUG - 2023-09-30 11:16:25 --> No URI present. Default controller set.
INFO - 2023-09-30 11:16:25 --> Router Class Initialized
INFO - 2023-09-30 11:16:25 --> Output Class Initialized
INFO - 2023-09-30 11:16:25 --> Security Class Initialized
DEBUG - 2023-09-30 11:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 11:16:25 --> Input Class Initialized
INFO - 2023-09-30 11:16:25 --> Language Class Initialized
INFO - 2023-09-30 11:16:25 --> Loader Class Initialized
INFO - 2023-09-30 11:16:25 --> Helper loaded: url_helper
INFO - 2023-09-30 11:16:25 --> Helper loaded: file_helper
INFO - 2023-09-30 11:16:25 --> Helper loaded: html_helper
INFO - 2023-09-30 11:16:25 --> Helper loaded: text_helper
INFO - 2023-09-30 11:16:25 --> Helper loaded: form_helper
INFO - 2023-09-30 11:16:25 --> Helper loaded: lang_helper
INFO - 2023-09-30 11:16:25 --> Helper loaded: security_helper
INFO - 2023-09-30 11:16:25 --> Helper loaded: cookie_helper
INFO - 2023-09-30 11:16:25 --> Database Driver Class Initialized
INFO - 2023-09-30 11:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 11:16:25 --> Parser Class Initialized
INFO - 2023-09-30 11:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 11:16:25 --> Pagination Class Initialized
INFO - 2023-09-30 11:16:25 --> Form Validation Class Initialized
INFO - 2023-09-30 11:16:25 --> Controller Class Initialized
INFO - 2023-09-30 11:16:25 --> Model Class Initialized
DEBUG - 2023-09-30 11:16:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:11:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 13:11:32 --> Config Class Initialized
INFO - 2023-09-30 13:11:32 --> Hooks Class Initialized
DEBUG - 2023-09-30 13:11:32 --> UTF-8 Support Enabled
INFO - 2023-09-30 13:11:32 --> Utf8 Class Initialized
INFO - 2023-09-30 13:11:32 --> URI Class Initialized
DEBUG - 2023-09-30 13:11:32 --> No URI present. Default controller set.
INFO - 2023-09-30 13:11:32 --> Router Class Initialized
INFO - 2023-09-30 13:11:32 --> Output Class Initialized
INFO - 2023-09-30 13:11:32 --> Security Class Initialized
DEBUG - 2023-09-30 13:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 13:11:32 --> Input Class Initialized
INFO - 2023-09-30 13:11:32 --> Language Class Initialized
INFO - 2023-09-30 13:11:32 --> Loader Class Initialized
INFO - 2023-09-30 13:11:32 --> Helper loaded: url_helper
INFO - 2023-09-30 13:11:32 --> Helper loaded: file_helper
INFO - 2023-09-30 13:11:32 --> Helper loaded: html_helper
INFO - 2023-09-30 13:11:32 --> Helper loaded: text_helper
INFO - 2023-09-30 13:11:32 --> Helper loaded: form_helper
INFO - 2023-09-30 13:11:32 --> Helper loaded: lang_helper
INFO - 2023-09-30 13:11:32 --> Helper loaded: security_helper
INFO - 2023-09-30 13:11:32 --> Helper loaded: cookie_helper
INFO - 2023-09-30 13:11:32 --> Database Driver Class Initialized
INFO - 2023-09-30 13:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 13:11:32 --> Parser Class Initialized
INFO - 2023-09-30 13:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 13:11:32 --> Pagination Class Initialized
INFO - 2023-09-30 13:11:32 --> Form Validation Class Initialized
INFO - 2023-09-30 13:11:32 --> Controller Class Initialized
INFO - 2023-09-30 13:11:32 --> Model Class Initialized
DEBUG - 2023-09-30 13:11:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:11:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-30 13:11:33 --> Config Class Initialized
INFO - 2023-09-30 13:11:33 --> Hooks Class Initialized
DEBUG - 2023-09-30 13:11:33 --> UTF-8 Support Enabled
INFO - 2023-09-30 13:11:33 --> Utf8 Class Initialized
INFO - 2023-09-30 13:11:33 --> URI Class Initialized
INFO - 2023-09-30 13:11:33 --> Router Class Initialized
INFO - 2023-09-30 13:11:33 --> Output Class Initialized
INFO - 2023-09-30 13:11:33 --> Security Class Initialized
DEBUG - 2023-09-30 13:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 13:11:33 --> Input Class Initialized
INFO - 2023-09-30 13:11:33 --> Language Class Initialized
INFO - 2023-09-30 13:11:33 --> Loader Class Initialized
INFO - 2023-09-30 13:11:33 --> Helper loaded: url_helper
INFO - 2023-09-30 13:11:33 --> Helper loaded: file_helper
INFO - 2023-09-30 13:11:33 --> Helper loaded: html_helper
INFO - 2023-09-30 13:11:33 --> Helper loaded: text_helper
INFO - 2023-09-30 13:11:33 --> Helper loaded: form_helper
INFO - 2023-09-30 13:11:33 --> Helper loaded: lang_helper
INFO - 2023-09-30 13:11:33 --> Helper loaded: security_helper
INFO - 2023-09-30 13:11:33 --> Helper loaded: cookie_helper
INFO - 2023-09-30 13:11:33 --> Database Driver Class Initialized
INFO - 2023-09-30 13:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 13:11:33 --> Parser Class Initialized
INFO - 2023-09-30 13:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-30 13:11:33 --> Pagination Class Initialized
INFO - 2023-09-30 13:11:33 --> Form Validation Class Initialized
INFO - 2023-09-30 13:11:33 --> Controller Class Initialized
INFO - 2023-09-30 13:11:33 --> Model Class Initialized
DEBUG - 2023-09-30 13:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-30 13:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-30 13:11:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-30 13:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-30 13:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-30 13:11:33 --> Model Class Initialized
INFO - 2023-09-30 13:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-30 13:11:33 --> Final output sent to browser
DEBUG - 2023-09-30 13:11:33 --> Total execution time: 0.2575
