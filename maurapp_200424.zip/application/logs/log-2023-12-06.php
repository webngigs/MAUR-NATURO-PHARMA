<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-06 03:36:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 03:36:35 --> Config Class Initialized
INFO - 2023-12-06 03:36:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 03:36:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 03:36:35 --> Utf8 Class Initialized
INFO - 2023-12-06 03:36:35 --> URI Class Initialized
DEBUG - 2023-12-06 03:36:35 --> No URI present. Default controller set.
INFO - 2023-12-06 03:36:35 --> Router Class Initialized
INFO - 2023-12-06 03:36:35 --> Output Class Initialized
INFO - 2023-12-06 03:36:35 --> Security Class Initialized
DEBUG - 2023-12-06 03:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 03:36:35 --> Input Class Initialized
INFO - 2023-12-06 03:36:35 --> Language Class Initialized
INFO - 2023-12-06 03:36:35 --> Loader Class Initialized
INFO - 2023-12-06 03:36:35 --> Helper loaded: url_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: file_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: html_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: text_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: form_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: lang_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: security_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: cookie_helper
INFO - 2023-12-06 03:36:35 --> Database Driver Class Initialized
INFO - 2023-12-06 03:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 03:36:35 --> Parser Class Initialized
INFO - 2023-12-06 03:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 03:36:35 --> Pagination Class Initialized
INFO - 2023-12-06 03:36:35 --> Form Validation Class Initialized
INFO - 2023-12-06 03:36:35 --> Controller Class Initialized
INFO - 2023-12-06 03:36:35 --> Model Class Initialized
DEBUG - 2023-12-06 03:36:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-06 03:36:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 03:36:35 --> Config Class Initialized
INFO - 2023-12-06 03:36:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 03:36:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 03:36:35 --> Utf8 Class Initialized
INFO - 2023-12-06 03:36:35 --> URI Class Initialized
INFO - 2023-12-06 03:36:35 --> Router Class Initialized
INFO - 2023-12-06 03:36:35 --> Output Class Initialized
INFO - 2023-12-06 03:36:35 --> Security Class Initialized
DEBUG - 2023-12-06 03:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 03:36:35 --> Input Class Initialized
INFO - 2023-12-06 03:36:35 --> Language Class Initialized
INFO - 2023-12-06 03:36:35 --> Loader Class Initialized
INFO - 2023-12-06 03:36:35 --> Helper loaded: url_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: file_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: html_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: text_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: form_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: lang_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: security_helper
INFO - 2023-12-06 03:36:35 --> Helper loaded: cookie_helper
INFO - 2023-12-06 03:36:35 --> Database Driver Class Initialized
INFO - 2023-12-06 03:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 03:36:35 --> Parser Class Initialized
INFO - 2023-12-06 03:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 03:36:35 --> Pagination Class Initialized
INFO - 2023-12-06 03:36:35 --> Form Validation Class Initialized
INFO - 2023-12-06 03:36:35 --> Controller Class Initialized
INFO - 2023-12-06 03:36:35 --> Model Class Initialized
DEBUG - 2023-12-06 03:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-06 03:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-06 03:36:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-06 03:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-06 03:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-06 03:36:35 --> Model Class Initialized
INFO - 2023-12-06 03:36:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-06 03:36:35 --> Final output sent to browser
DEBUG - 2023-12-06 03:36:35 --> Total execution time: 0.0321
ERROR - 2023-12-06 04:15:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 04:15:02 --> Config Class Initialized
INFO - 2023-12-06 04:15:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 04:15:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 04:15:02 --> Utf8 Class Initialized
INFO - 2023-12-06 04:15:02 --> URI Class Initialized
INFO - 2023-12-06 04:15:02 --> Router Class Initialized
INFO - 2023-12-06 04:15:02 --> Output Class Initialized
INFO - 2023-12-06 04:15:02 --> Security Class Initialized
DEBUG - 2023-12-06 04:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 04:15:02 --> Input Class Initialized
INFO - 2023-12-06 04:15:02 --> Language Class Initialized
ERROR - 2023-12-06 04:15:02 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-06 13:23:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 13:23:17 --> Config Class Initialized
INFO - 2023-12-06 13:23:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:23:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:23:17 --> Utf8 Class Initialized
INFO - 2023-12-06 13:23:17 --> URI Class Initialized
DEBUG - 2023-12-06 13:23:17 --> No URI present. Default controller set.
INFO - 2023-12-06 13:23:17 --> Router Class Initialized
INFO - 2023-12-06 13:23:17 --> Output Class Initialized
INFO - 2023-12-06 13:23:17 --> Security Class Initialized
DEBUG - 2023-12-06 13:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:23:17 --> Input Class Initialized
INFO - 2023-12-06 13:23:17 --> Language Class Initialized
INFO - 2023-12-06 13:23:17 --> Loader Class Initialized
INFO - 2023-12-06 13:23:17 --> Helper loaded: url_helper
INFO - 2023-12-06 13:23:17 --> Helper loaded: file_helper
INFO - 2023-12-06 13:23:17 --> Helper loaded: html_helper
INFO - 2023-12-06 13:23:17 --> Helper loaded: text_helper
INFO - 2023-12-06 13:23:17 --> Helper loaded: form_helper
INFO - 2023-12-06 13:23:17 --> Helper loaded: lang_helper
INFO - 2023-12-06 13:23:17 --> Helper loaded: security_helper
INFO - 2023-12-06 13:23:17 --> Helper loaded: cookie_helper
INFO - 2023-12-06 13:23:17 --> Database Driver Class Initialized
INFO - 2023-12-06 13:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:23:17 --> Parser Class Initialized
INFO - 2023-12-06 13:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 13:23:17 --> Pagination Class Initialized
INFO - 2023-12-06 13:23:17 --> Form Validation Class Initialized
INFO - 2023-12-06 13:23:17 --> Controller Class Initialized
INFO - 2023-12-06 13:23:17 --> Model Class Initialized
DEBUG - 2023-12-06 13:23:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-06 15:15:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 15:15:49 --> Config Class Initialized
INFO - 2023-12-06 15:15:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:15:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:15:49 --> Utf8 Class Initialized
INFO - 2023-12-06 15:15:49 --> URI Class Initialized
DEBUG - 2023-12-06 15:15:49 --> No URI present. Default controller set.
INFO - 2023-12-06 15:15:49 --> Router Class Initialized
INFO - 2023-12-06 15:15:49 --> Output Class Initialized
INFO - 2023-12-06 15:15:49 --> Security Class Initialized
DEBUG - 2023-12-06 15:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:15:49 --> Input Class Initialized
INFO - 2023-12-06 15:15:49 --> Language Class Initialized
INFO - 2023-12-06 15:15:49 --> Loader Class Initialized
INFO - 2023-12-06 15:15:49 --> Helper loaded: url_helper
INFO - 2023-12-06 15:15:49 --> Helper loaded: file_helper
INFO - 2023-12-06 15:15:49 --> Helper loaded: html_helper
INFO - 2023-12-06 15:15:49 --> Helper loaded: text_helper
INFO - 2023-12-06 15:15:49 --> Helper loaded: form_helper
INFO - 2023-12-06 15:15:49 --> Helper loaded: lang_helper
INFO - 2023-12-06 15:15:49 --> Helper loaded: security_helper
INFO - 2023-12-06 15:15:49 --> Helper loaded: cookie_helper
INFO - 2023-12-06 15:15:49 --> Database Driver Class Initialized
INFO - 2023-12-06 15:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:15:49 --> Parser Class Initialized
INFO - 2023-12-06 15:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 15:15:49 --> Pagination Class Initialized
INFO - 2023-12-06 15:15:49 --> Form Validation Class Initialized
INFO - 2023-12-06 15:15:49 --> Controller Class Initialized
INFO - 2023-12-06 15:15:49 --> Model Class Initialized
DEBUG - 2023-12-06 15:15:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-06 15:15:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 15:15:51 --> Config Class Initialized
INFO - 2023-12-06 15:15:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:15:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:15:51 --> Utf8 Class Initialized
INFO - 2023-12-06 15:15:51 --> URI Class Initialized
DEBUG - 2023-12-06 15:15:51 --> No URI present. Default controller set.
INFO - 2023-12-06 15:15:51 --> Router Class Initialized
INFO - 2023-12-06 15:15:51 --> Output Class Initialized
INFO - 2023-12-06 15:15:51 --> Security Class Initialized
DEBUG - 2023-12-06 15:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:15:51 --> Input Class Initialized
INFO - 2023-12-06 15:15:51 --> Language Class Initialized
INFO - 2023-12-06 15:15:51 --> Loader Class Initialized
INFO - 2023-12-06 15:15:51 --> Helper loaded: url_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: file_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: html_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: text_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: form_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: lang_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: security_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: cookie_helper
INFO - 2023-12-06 15:15:51 --> Database Driver Class Initialized
INFO - 2023-12-06 15:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:15:51 --> Parser Class Initialized
INFO - 2023-12-06 15:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 15:15:51 --> Pagination Class Initialized
INFO - 2023-12-06 15:15:51 --> Form Validation Class Initialized
INFO - 2023-12-06 15:15:51 --> Controller Class Initialized
INFO - 2023-12-06 15:15:51 --> Model Class Initialized
DEBUG - 2023-12-06 15:15:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-06 15:15:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 15:15:51 --> Config Class Initialized
INFO - 2023-12-06 15:15:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:15:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:15:51 --> Utf8 Class Initialized
INFO - 2023-12-06 15:15:51 --> URI Class Initialized
DEBUG - 2023-12-06 15:15:51 --> No URI present. Default controller set.
INFO - 2023-12-06 15:15:51 --> Router Class Initialized
INFO - 2023-12-06 15:15:51 --> Output Class Initialized
INFO - 2023-12-06 15:15:51 --> Security Class Initialized
DEBUG - 2023-12-06 15:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:15:51 --> Input Class Initialized
INFO - 2023-12-06 15:15:51 --> Language Class Initialized
INFO - 2023-12-06 15:15:51 --> Loader Class Initialized
INFO - 2023-12-06 15:15:51 --> Helper loaded: url_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: file_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: html_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: text_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: form_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: lang_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: security_helper
INFO - 2023-12-06 15:15:51 --> Helper loaded: cookie_helper
INFO - 2023-12-06 15:15:51 --> Database Driver Class Initialized
INFO - 2023-12-06 15:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:15:51 --> Parser Class Initialized
INFO - 2023-12-06 15:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 15:15:51 --> Pagination Class Initialized
INFO - 2023-12-06 15:15:51 --> Form Validation Class Initialized
INFO - 2023-12-06 15:15:51 --> Controller Class Initialized
INFO - 2023-12-06 15:15:51 --> Model Class Initialized
DEBUG - 2023-12-06 15:15:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-06 15:15:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 15:15:52 --> Config Class Initialized
INFO - 2023-12-06 15:15:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:15:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:15:52 --> Utf8 Class Initialized
INFO - 2023-12-06 15:15:52 --> URI Class Initialized
DEBUG - 2023-12-06 15:15:52 --> No URI present. Default controller set.
INFO - 2023-12-06 15:15:52 --> Router Class Initialized
INFO - 2023-12-06 15:15:52 --> Output Class Initialized
INFO - 2023-12-06 15:15:52 --> Security Class Initialized
DEBUG - 2023-12-06 15:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:15:52 --> Input Class Initialized
INFO - 2023-12-06 15:15:52 --> Language Class Initialized
INFO - 2023-12-06 15:15:52 --> Loader Class Initialized
INFO - 2023-12-06 15:15:52 --> Helper loaded: url_helper
INFO - 2023-12-06 15:15:52 --> Helper loaded: file_helper
INFO - 2023-12-06 15:15:52 --> Helper loaded: html_helper
INFO - 2023-12-06 15:15:52 --> Helper loaded: text_helper
INFO - 2023-12-06 15:15:52 --> Helper loaded: form_helper
INFO - 2023-12-06 15:15:52 --> Helper loaded: lang_helper
INFO - 2023-12-06 15:15:52 --> Helper loaded: security_helper
INFO - 2023-12-06 15:15:52 --> Helper loaded: cookie_helper
INFO - 2023-12-06 15:15:52 --> Database Driver Class Initialized
INFO - 2023-12-06 15:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:15:52 --> Parser Class Initialized
INFO - 2023-12-06 15:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 15:15:52 --> Pagination Class Initialized
INFO - 2023-12-06 15:15:52 --> Form Validation Class Initialized
INFO - 2023-12-06 15:15:52 --> Controller Class Initialized
INFO - 2023-12-06 15:15:52 --> Model Class Initialized
DEBUG - 2023-12-06 15:15:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-06 15:23:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 15:23:31 --> Config Class Initialized
INFO - 2023-12-06 15:23:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:23:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:23:31 --> Utf8 Class Initialized
INFO - 2023-12-06 15:23:31 --> URI Class Initialized
DEBUG - 2023-12-06 15:23:31 --> No URI present. Default controller set.
INFO - 2023-12-06 15:23:31 --> Router Class Initialized
INFO - 2023-12-06 15:23:31 --> Output Class Initialized
INFO - 2023-12-06 15:23:31 --> Security Class Initialized
DEBUG - 2023-12-06 15:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:23:31 --> Input Class Initialized
INFO - 2023-12-06 15:23:31 --> Language Class Initialized
INFO - 2023-12-06 15:23:31 --> Loader Class Initialized
INFO - 2023-12-06 15:23:31 --> Helper loaded: url_helper
INFO - 2023-12-06 15:23:31 --> Helper loaded: file_helper
INFO - 2023-12-06 15:23:31 --> Helper loaded: html_helper
INFO - 2023-12-06 15:23:31 --> Helper loaded: text_helper
INFO - 2023-12-06 15:23:31 --> Helper loaded: form_helper
INFO - 2023-12-06 15:23:31 --> Helper loaded: lang_helper
INFO - 2023-12-06 15:23:31 --> Helper loaded: security_helper
INFO - 2023-12-06 15:23:31 --> Helper loaded: cookie_helper
INFO - 2023-12-06 15:23:31 --> Database Driver Class Initialized
INFO - 2023-12-06 15:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:23:31 --> Parser Class Initialized
INFO - 2023-12-06 15:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 15:23:31 --> Pagination Class Initialized
INFO - 2023-12-06 15:23:31 --> Form Validation Class Initialized
INFO - 2023-12-06 15:23:31 --> Controller Class Initialized
INFO - 2023-12-06 15:23:31 --> Model Class Initialized
DEBUG - 2023-12-06 15:23:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-06 16:05:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 16:05:30 --> Config Class Initialized
INFO - 2023-12-06 16:05:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:05:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:05:30 --> Utf8 Class Initialized
INFO - 2023-12-06 16:05:30 --> URI Class Initialized
DEBUG - 2023-12-06 16:05:30 --> No URI present. Default controller set.
INFO - 2023-12-06 16:05:30 --> Router Class Initialized
INFO - 2023-12-06 16:05:30 --> Output Class Initialized
INFO - 2023-12-06 16:05:30 --> Security Class Initialized
DEBUG - 2023-12-06 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:05:30 --> Input Class Initialized
INFO - 2023-12-06 16:05:30 --> Language Class Initialized
INFO - 2023-12-06 16:05:30 --> Loader Class Initialized
INFO - 2023-12-06 16:05:30 --> Helper loaded: url_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: file_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: html_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: text_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: form_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: lang_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: security_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:05:30 --> Database Driver Class Initialized
INFO - 2023-12-06 16:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:05:30 --> Parser Class Initialized
INFO - 2023-12-06 16:05:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 16:05:30 --> Pagination Class Initialized
INFO - 2023-12-06 16:05:30 --> Form Validation Class Initialized
INFO - 2023-12-06 16:05:30 --> Controller Class Initialized
INFO - 2023-12-06 16:05:30 --> Model Class Initialized
DEBUG - 2023-12-06 16:05:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-06 16:05:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 16:05:30 --> Config Class Initialized
INFO - 2023-12-06 16:05:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:05:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:05:30 --> Utf8 Class Initialized
INFO - 2023-12-06 16:05:30 --> URI Class Initialized
INFO - 2023-12-06 16:05:30 --> Router Class Initialized
INFO - 2023-12-06 16:05:30 --> Output Class Initialized
INFO - 2023-12-06 16:05:30 --> Security Class Initialized
DEBUG - 2023-12-06 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:05:30 --> Input Class Initialized
INFO - 2023-12-06 16:05:30 --> Language Class Initialized
INFO - 2023-12-06 16:05:30 --> Loader Class Initialized
INFO - 2023-12-06 16:05:30 --> Helper loaded: url_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: file_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: html_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: text_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: form_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: lang_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: security_helper
INFO - 2023-12-06 16:05:30 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:05:30 --> Database Driver Class Initialized
INFO - 2023-12-06 16:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:05:30 --> Parser Class Initialized
INFO - 2023-12-06 16:05:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 16:05:30 --> Pagination Class Initialized
INFO - 2023-12-06 16:05:30 --> Form Validation Class Initialized
INFO - 2023-12-06 16:05:30 --> Controller Class Initialized
INFO - 2023-12-06 16:05:30 --> Model Class Initialized
DEBUG - 2023-12-06 16:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-06 16:05:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-06 16:05:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-06 16:05:30 --> Model Class Initialized
INFO - 2023-12-06 16:05:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-06 16:05:30 --> Final output sent to browser
DEBUG - 2023-12-06 16:05:30 --> Total execution time: 0.0319
ERROR - 2023-12-06 16:05:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 16:05:34 --> Config Class Initialized
INFO - 2023-12-06 16:05:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:05:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:05:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:05:34 --> URI Class Initialized
INFO - 2023-12-06 16:05:34 --> Router Class Initialized
INFO - 2023-12-06 16:05:34 --> Output Class Initialized
INFO - 2023-12-06 16:05:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:05:34 --> Input Class Initialized
INFO - 2023-12-06 16:05:34 --> Language Class Initialized
INFO - 2023-12-06 16:05:34 --> Loader Class Initialized
INFO - 2023-12-06 16:05:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: html_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: text_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: lang_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: security_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:05:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:05:34 --> Parser Class Initialized
INFO - 2023-12-06 16:05:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 16:05:34 --> Pagination Class Initialized
INFO - 2023-12-06 16:05:34 --> Form Validation Class Initialized
INFO - 2023-12-06 16:05:34 --> Controller Class Initialized
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
DEBUG - 2023-12-06 16:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
INFO - 2023-12-06 16:05:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:05:34 --> Total execution time: 0.0192
ERROR - 2023-12-06 16:05:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 16:05:34 --> Config Class Initialized
INFO - 2023-12-06 16:05:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:05:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:05:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:05:34 --> URI Class Initialized
DEBUG - 2023-12-06 16:05:34 --> No URI present. Default controller set.
INFO - 2023-12-06 16:05:34 --> Router Class Initialized
INFO - 2023-12-06 16:05:34 --> Output Class Initialized
INFO - 2023-12-06 16:05:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:05:34 --> Input Class Initialized
INFO - 2023-12-06 16:05:34 --> Language Class Initialized
INFO - 2023-12-06 16:05:34 --> Loader Class Initialized
INFO - 2023-12-06 16:05:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: html_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: text_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: lang_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: security_helper
INFO - 2023-12-06 16:05:34 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:05:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:05:34 --> Parser Class Initialized
INFO - 2023-12-06 16:05:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 16:05:34 --> Pagination Class Initialized
INFO - 2023-12-06 16:05:34 --> Form Validation Class Initialized
INFO - 2023-12-06 16:05:34 --> Controller Class Initialized
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
DEBUG - 2023-12-06 16:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
DEBUG - 2023-12-06 16:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
DEBUG - 2023-12-06 16:05:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 16:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
INFO - 2023-12-06 16:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-06 16:05:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-06 16:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-06 16:05:34 --> Model Class Initialized
INFO - 2023-12-06 16:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-06 16:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-06 16:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-06 16:05:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:05:34 --> Total execution time: 0.2184
ERROR - 2023-12-06 16:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 16:05:44 --> Config Class Initialized
INFO - 2023-12-06 16:05:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:05:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:05:44 --> Utf8 Class Initialized
INFO - 2023-12-06 16:05:44 --> URI Class Initialized
DEBUG - 2023-12-06 16:05:44 --> No URI present. Default controller set.
INFO - 2023-12-06 16:05:44 --> Router Class Initialized
INFO - 2023-12-06 16:05:44 --> Output Class Initialized
INFO - 2023-12-06 16:05:44 --> Security Class Initialized
DEBUG - 2023-12-06 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:05:44 --> Input Class Initialized
INFO - 2023-12-06 16:05:44 --> Language Class Initialized
INFO - 2023-12-06 16:05:44 --> Loader Class Initialized
INFO - 2023-12-06 16:05:44 --> Helper loaded: url_helper
INFO - 2023-12-06 16:05:44 --> Helper loaded: file_helper
INFO - 2023-12-06 16:05:44 --> Helper loaded: html_helper
INFO - 2023-12-06 16:05:44 --> Helper loaded: text_helper
INFO - 2023-12-06 16:05:44 --> Helper loaded: form_helper
INFO - 2023-12-06 16:05:44 --> Helper loaded: lang_helper
INFO - 2023-12-06 16:05:44 --> Helper loaded: security_helper
INFO - 2023-12-06 16:05:44 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:05:44 --> Database Driver Class Initialized
INFO - 2023-12-06 16:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:05:44 --> Parser Class Initialized
INFO - 2023-12-06 16:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-06 16:05:44 --> Pagination Class Initialized
INFO - 2023-12-06 16:05:44 --> Form Validation Class Initialized
INFO - 2023-12-06 16:05:44 --> Controller Class Initialized
INFO - 2023-12-06 16:05:44 --> Model Class Initialized
DEBUG - 2023-12-06 16:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:44 --> Model Class Initialized
DEBUG - 2023-12-06 16:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:44 --> Model Class Initialized
INFO - 2023-12-06 16:05:44 --> Model Class Initialized
INFO - 2023-12-06 16:05:44 --> Model Class Initialized
INFO - 2023-12-06 16:05:44 --> Model Class Initialized
DEBUG - 2023-12-06 16:05:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 16:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:44 --> Model Class Initialized
INFO - 2023-12-06 16:05:44 --> Model Class Initialized
INFO - 2023-12-06 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-06 16:05:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-06 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-06 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-06 16:05:44 --> Model Class Initialized
INFO - 2023-12-06 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-06 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-06 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-06 16:05:44 --> Final output sent to browser
DEBUG - 2023-12-06 16:05:44 --> Total execution time: 0.2082
ERROR - 2023-12-06 18:13:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-06 18:13:39 --> Config Class Initialized
INFO - 2023-12-06 18:13:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 18:13:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 18:13:39 --> Utf8 Class Initialized
INFO - 2023-12-06 18:13:39 --> URI Class Initialized
INFO - 2023-12-06 18:13:39 --> Router Class Initialized
INFO - 2023-12-06 18:13:39 --> Output Class Initialized
INFO - 2023-12-06 18:13:39 --> Security Class Initialized
DEBUG - 2023-12-06 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 18:13:39 --> Input Class Initialized
INFO - 2023-12-06 18:13:39 --> Language Class Initialized
ERROR - 2023-12-06 18:13:39 --> 404 Page Not Found: Well-known/assetlinks.json
