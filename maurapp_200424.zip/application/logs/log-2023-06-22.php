<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-22 02:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:11:06 --> Config Class Initialized
INFO - 2023-06-22 02:11:06 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:11:06 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:11:06 --> Utf8 Class Initialized
INFO - 2023-06-22 02:11:06 --> URI Class Initialized
DEBUG - 2023-06-22 02:11:06 --> No URI present. Default controller set.
INFO - 2023-06-22 02:11:06 --> Router Class Initialized
INFO - 2023-06-22 02:11:06 --> Output Class Initialized
INFO - 2023-06-22 02:11:06 --> Security Class Initialized
DEBUG - 2023-06-22 02:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:11:06 --> Input Class Initialized
INFO - 2023-06-22 02:11:06 --> Language Class Initialized
INFO - 2023-06-22 02:11:06 --> Loader Class Initialized
INFO - 2023-06-22 02:11:06 --> Helper loaded: url_helper
INFO - 2023-06-22 02:11:06 --> Helper loaded: file_helper
INFO - 2023-06-22 02:11:06 --> Helper loaded: html_helper
INFO - 2023-06-22 02:11:06 --> Helper loaded: text_helper
INFO - 2023-06-22 02:11:06 --> Helper loaded: form_helper
INFO - 2023-06-22 02:11:06 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:11:06 --> Helper loaded: security_helper
INFO - 2023-06-22 02:11:06 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:11:06 --> Database Driver Class Initialized
INFO - 2023-06-22 02:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:11:06 --> Parser Class Initialized
INFO - 2023-06-22 02:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:11:06 --> Pagination Class Initialized
INFO - 2023-06-22 02:11:06 --> Form Validation Class Initialized
INFO - 2023-06-22 02:11:06 --> Controller Class Initialized
INFO - 2023-06-22 02:11:06 --> Model Class Initialized
DEBUG - 2023-06-22 02:11:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 02:11:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:11:07 --> Config Class Initialized
INFO - 2023-06-22 02:11:07 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:11:07 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:11:07 --> Utf8 Class Initialized
INFO - 2023-06-22 02:11:07 --> URI Class Initialized
INFO - 2023-06-22 02:11:07 --> Router Class Initialized
INFO - 2023-06-22 02:11:07 --> Output Class Initialized
INFO - 2023-06-22 02:11:07 --> Security Class Initialized
DEBUG - 2023-06-22 02:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:11:07 --> Input Class Initialized
INFO - 2023-06-22 02:11:07 --> Language Class Initialized
INFO - 2023-06-22 02:11:07 --> Loader Class Initialized
INFO - 2023-06-22 02:11:07 --> Helper loaded: url_helper
INFO - 2023-06-22 02:11:07 --> Helper loaded: file_helper
INFO - 2023-06-22 02:11:07 --> Helper loaded: html_helper
INFO - 2023-06-22 02:11:07 --> Helper loaded: text_helper
INFO - 2023-06-22 02:11:07 --> Helper loaded: form_helper
INFO - 2023-06-22 02:11:07 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:11:07 --> Helper loaded: security_helper
INFO - 2023-06-22 02:11:07 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:11:07 --> Database Driver Class Initialized
INFO - 2023-06-22 02:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:11:07 --> Parser Class Initialized
INFO - 2023-06-22 02:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:11:07 --> Pagination Class Initialized
INFO - 2023-06-22 02:11:07 --> Form Validation Class Initialized
INFO - 2023-06-22 02:11:07 --> Controller Class Initialized
INFO - 2023-06-22 02:11:07 --> Model Class Initialized
DEBUG - 2023-06-22 02:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 02:11:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:11:07 --> Model Class Initialized
INFO - 2023-06-22 02:11:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:11:07 --> Final output sent to browser
DEBUG - 2023-06-22 02:11:07 --> Total execution time: 0.0305
ERROR - 2023-06-22 02:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:11:38 --> Config Class Initialized
INFO - 2023-06-22 02:11:38 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:11:38 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:11:38 --> Utf8 Class Initialized
INFO - 2023-06-22 02:11:38 --> URI Class Initialized
INFO - 2023-06-22 02:11:38 --> Router Class Initialized
INFO - 2023-06-22 02:11:38 --> Output Class Initialized
INFO - 2023-06-22 02:11:38 --> Security Class Initialized
DEBUG - 2023-06-22 02:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:11:38 --> Input Class Initialized
INFO - 2023-06-22 02:11:38 --> Language Class Initialized
INFO - 2023-06-22 02:11:38 --> Loader Class Initialized
INFO - 2023-06-22 02:11:38 --> Helper loaded: url_helper
INFO - 2023-06-22 02:11:38 --> Helper loaded: file_helper
INFO - 2023-06-22 02:11:38 --> Helper loaded: html_helper
INFO - 2023-06-22 02:11:38 --> Helper loaded: text_helper
INFO - 2023-06-22 02:11:38 --> Helper loaded: form_helper
INFO - 2023-06-22 02:11:38 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:11:38 --> Helper loaded: security_helper
INFO - 2023-06-22 02:11:38 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:11:38 --> Database Driver Class Initialized
INFO - 2023-06-22 02:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:11:38 --> Parser Class Initialized
INFO - 2023-06-22 02:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:11:38 --> Pagination Class Initialized
INFO - 2023-06-22 02:11:38 --> Form Validation Class Initialized
INFO - 2023-06-22 02:11:38 --> Controller Class Initialized
INFO - 2023-06-22 02:11:38 --> Model Class Initialized
DEBUG - 2023-06-22 02:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:11:38 --> Model Class Initialized
INFO - 2023-06-22 02:11:38 --> Final output sent to browser
DEBUG - 2023-06-22 02:11:38 --> Total execution time: 0.0209
ERROR - 2023-06-22 02:11:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:11:39 --> Config Class Initialized
INFO - 2023-06-22 02:11:39 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:11:39 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:11:39 --> Utf8 Class Initialized
INFO - 2023-06-22 02:11:39 --> URI Class Initialized
DEBUG - 2023-06-22 02:11:39 --> No URI present. Default controller set.
INFO - 2023-06-22 02:11:39 --> Router Class Initialized
INFO - 2023-06-22 02:11:39 --> Output Class Initialized
INFO - 2023-06-22 02:11:39 --> Security Class Initialized
DEBUG - 2023-06-22 02:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:11:39 --> Input Class Initialized
INFO - 2023-06-22 02:11:39 --> Language Class Initialized
INFO - 2023-06-22 02:11:39 --> Loader Class Initialized
INFO - 2023-06-22 02:11:39 --> Helper loaded: url_helper
INFO - 2023-06-22 02:11:39 --> Helper loaded: file_helper
INFO - 2023-06-22 02:11:39 --> Helper loaded: html_helper
INFO - 2023-06-22 02:11:39 --> Helper loaded: text_helper
INFO - 2023-06-22 02:11:39 --> Helper loaded: form_helper
INFO - 2023-06-22 02:11:39 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:11:39 --> Helper loaded: security_helper
INFO - 2023-06-22 02:11:39 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:11:39 --> Database Driver Class Initialized
INFO - 2023-06-22 02:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:11:39 --> Parser Class Initialized
INFO - 2023-06-22 02:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:11:39 --> Pagination Class Initialized
INFO - 2023-06-22 02:11:39 --> Form Validation Class Initialized
INFO - 2023-06-22 02:11:39 --> Controller Class Initialized
INFO - 2023-06-22 02:11:39 --> Model Class Initialized
DEBUG - 2023-06-22 02:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:11:39 --> Model Class Initialized
DEBUG - 2023-06-22 02:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:11:39 --> Model Class Initialized
INFO - 2023-06-22 02:11:39 --> Model Class Initialized
INFO - 2023-06-22 02:11:39 --> Model Class Initialized
INFO - 2023-06-22 02:11:39 --> Model Class Initialized
DEBUG - 2023-06-22 02:11:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:11:39 --> Model Class Initialized
INFO - 2023-06-22 02:11:39 --> Model Class Initialized
INFO - 2023-06-22 02:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 02:11:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:11:39 --> Model Class Initialized
INFO - 2023-06-22 02:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:11:39 --> Final output sent to browser
DEBUG - 2023-06-22 02:11:39 --> Total execution time: 0.0679
ERROR - 2023-06-22 02:12:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:12:07 --> Config Class Initialized
INFO - 2023-06-22 02:12:07 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:12:07 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:12:07 --> Utf8 Class Initialized
INFO - 2023-06-22 02:12:07 --> URI Class Initialized
INFO - 2023-06-22 02:12:07 --> Router Class Initialized
INFO - 2023-06-22 02:12:07 --> Output Class Initialized
INFO - 2023-06-22 02:12:07 --> Security Class Initialized
DEBUG - 2023-06-22 02:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:12:07 --> Input Class Initialized
INFO - 2023-06-22 02:12:07 --> Language Class Initialized
INFO - 2023-06-22 02:12:07 --> Loader Class Initialized
INFO - 2023-06-22 02:12:07 --> Helper loaded: url_helper
INFO - 2023-06-22 02:12:07 --> Helper loaded: file_helper
INFO - 2023-06-22 02:12:07 --> Helper loaded: html_helper
INFO - 2023-06-22 02:12:07 --> Helper loaded: text_helper
INFO - 2023-06-22 02:12:07 --> Helper loaded: form_helper
INFO - 2023-06-22 02:12:07 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:12:07 --> Helper loaded: security_helper
INFO - 2023-06-22 02:12:07 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:12:07 --> Database Driver Class Initialized
INFO - 2023-06-22 02:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:12:07 --> Parser Class Initialized
INFO - 2023-06-22 02:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:12:07 --> Pagination Class Initialized
INFO - 2023-06-22 02:12:07 --> Form Validation Class Initialized
INFO - 2023-06-22 02:12:07 --> Controller Class Initialized
INFO - 2023-06-22 02:12:07 --> Model Class Initialized
DEBUG - 2023-06-22 02:12:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:12:07 --> Model Class Initialized
DEBUG - 2023-06-22 02:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:12:07 --> Model Class Initialized
INFO - 2023-06-22 02:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-22 02:12:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:12:07 --> Model Class Initialized
INFO - 2023-06-22 02:12:07 --> Model Class Initialized
INFO - 2023-06-22 02:12:07 --> Model Class Initialized
INFO - 2023-06-22 02:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:12:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:12:07 --> Final output sent to browser
DEBUG - 2023-06-22 02:12:07 --> Total execution time: 0.0603
ERROR - 2023-06-22 02:12:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:12:08 --> Config Class Initialized
INFO - 2023-06-22 02:12:08 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:12:08 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:12:08 --> Utf8 Class Initialized
INFO - 2023-06-22 02:12:08 --> URI Class Initialized
INFO - 2023-06-22 02:12:08 --> Router Class Initialized
INFO - 2023-06-22 02:12:08 --> Output Class Initialized
INFO - 2023-06-22 02:12:08 --> Security Class Initialized
DEBUG - 2023-06-22 02:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:12:08 --> Input Class Initialized
INFO - 2023-06-22 02:12:08 --> Language Class Initialized
INFO - 2023-06-22 02:12:08 --> Loader Class Initialized
INFO - 2023-06-22 02:12:08 --> Helper loaded: url_helper
INFO - 2023-06-22 02:12:08 --> Helper loaded: file_helper
INFO - 2023-06-22 02:12:08 --> Helper loaded: html_helper
INFO - 2023-06-22 02:12:08 --> Helper loaded: text_helper
INFO - 2023-06-22 02:12:08 --> Helper loaded: form_helper
INFO - 2023-06-22 02:12:08 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:12:08 --> Helper loaded: security_helper
INFO - 2023-06-22 02:12:08 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:12:08 --> Database Driver Class Initialized
INFO - 2023-06-22 02:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:12:08 --> Parser Class Initialized
INFO - 2023-06-22 02:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:12:08 --> Pagination Class Initialized
INFO - 2023-06-22 02:12:08 --> Form Validation Class Initialized
INFO - 2023-06-22 02:12:08 --> Controller Class Initialized
INFO - 2023-06-22 02:12:08 --> Model Class Initialized
DEBUG - 2023-06-22 02:12:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:12:08 --> Model Class Initialized
DEBUG - 2023-06-22 02:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:12:08 --> Model Class Initialized
INFO - 2023-06-22 02:12:08 --> Final output sent to browser
DEBUG - 2023-06-22 02:12:08 --> Total execution time: 0.0283
ERROR - 2023-06-22 02:12:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:12:56 --> Config Class Initialized
INFO - 2023-06-22 02:12:56 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:12:56 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:12:56 --> Utf8 Class Initialized
INFO - 2023-06-22 02:12:56 --> URI Class Initialized
INFO - 2023-06-22 02:12:56 --> Router Class Initialized
INFO - 2023-06-22 02:12:56 --> Output Class Initialized
INFO - 2023-06-22 02:12:56 --> Security Class Initialized
DEBUG - 2023-06-22 02:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:12:56 --> Input Class Initialized
INFO - 2023-06-22 02:12:56 --> Language Class Initialized
INFO - 2023-06-22 02:12:56 --> Loader Class Initialized
INFO - 2023-06-22 02:12:56 --> Helper loaded: url_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: file_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: html_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: text_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: form_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: security_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:12:56 --> Database Driver Class Initialized
INFO - 2023-06-22 02:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:12:56 --> Parser Class Initialized
INFO - 2023-06-22 02:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:12:56 --> Pagination Class Initialized
INFO - 2023-06-22 02:12:56 --> Form Validation Class Initialized
INFO - 2023-06-22 02:12:56 --> Controller Class Initialized
INFO - 2023-06-22 02:12:56 --> Model Class Initialized
INFO - 2023-06-22 02:12:56 --> Model Class Initialized
INFO - 2023-06-22 02:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-22 02:12:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:12:56 --> Model Class Initialized
INFO - 2023-06-22 02:12:56 --> Model Class Initialized
INFO - 2023-06-22 02:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:12:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:12:56 --> Final output sent to browser
DEBUG - 2023-06-22 02:12:56 --> Total execution time: 0.0527
ERROR - 2023-06-22 02:12:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:12:56 --> Config Class Initialized
INFO - 2023-06-22 02:12:56 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:12:56 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:12:56 --> Utf8 Class Initialized
INFO - 2023-06-22 02:12:56 --> URI Class Initialized
INFO - 2023-06-22 02:12:56 --> Router Class Initialized
INFO - 2023-06-22 02:12:56 --> Output Class Initialized
INFO - 2023-06-22 02:12:56 --> Security Class Initialized
DEBUG - 2023-06-22 02:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:12:56 --> Input Class Initialized
INFO - 2023-06-22 02:12:56 --> Language Class Initialized
INFO - 2023-06-22 02:12:56 --> Loader Class Initialized
INFO - 2023-06-22 02:12:56 --> Helper loaded: url_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: file_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: html_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: text_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: form_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: security_helper
INFO - 2023-06-22 02:12:56 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:12:56 --> Database Driver Class Initialized
INFO - 2023-06-22 02:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:12:56 --> Parser Class Initialized
INFO - 2023-06-22 02:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:12:56 --> Pagination Class Initialized
INFO - 2023-06-22 02:12:56 --> Form Validation Class Initialized
INFO - 2023-06-22 02:12:56 --> Controller Class Initialized
INFO - 2023-06-22 02:12:56 --> Model Class Initialized
INFO - 2023-06-22 02:12:56 --> Model Class Initialized
INFO - 2023-06-22 02:12:56 --> Final output sent to browser
DEBUG - 2023-06-22 02:12:56 --> Total execution time: 0.0171
ERROR - 2023-06-22 02:13:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:13:06 --> Config Class Initialized
INFO - 2023-06-22 02:13:06 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:13:06 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:13:06 --> Utf8 Class Initialized
INFO - 2023-06-22 02:13:06 --> URI Class Initialized
INFO - 2023-06-22 02:13:06 --> Router Class Initialized
INFO - 2023-06-22 02:13:06 --> Output Class Initialized
INFO - 2023-06-22 02:13:06 --> Security Class Initialized
DEBUG - 2023-06-22 02:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:13:06 --> Input Class Initialized
INFO - 2023-06-22 02:13:06 --> Language Class Initialized
INFO - 2023-06-22 02:13:06 --> Loader Class Initialized
INFO - 2023-06-22 02:13:06 --> Helper loaded: url_helper
INFO - 2023-06-22 02:13:06 --> Helper loaded: file_helper
INFO - 2023-06-22 02:13:06 --> Helper loaded: html_helper
INFO - 2023-06-22 02:13:06 --> Helper loaded: text_helper
INFO - 2023-06-22 02:13:06 --> Helper loaded: form_helper
INFO - 2023-06-22 02:13:06 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:13:06 --> Helper loaded: security_helper
INFO - 2023-06-22 02:13:06 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:13:06 --> Database Driver Class Initialized
INFO - 2023-06-22 02:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:13:06 --> Parser Class Initialized
INFO - 2023-06-22 02:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:13:06 --> Pagination Class Initialized
INFO - 2023-06-22 02:13:06 --> Form Validation Class Initialized
INFO - 2023-06-22 02:13:06 --> Controller Class Initialized
INFO - 2023-06-22 02:13:06 --> Model Class Initialized
INFO - 2023-06-22 02:13:06 --> Model Class Initialized
INFO - 2023-06-22 02:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-22 02:13:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:13:06 --> Model Class Initialized
INFO - 2023-06-22 02:13:06 --> Model Class Initialized
INFO - 2023-06-22 02:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:13:06 --> Final output sent to browser
DEBUG - 2023-06-22 02:13:06 --> Total execution time: 0.0958
ERROR - 2023-06-22 02:13:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:13:07 --> Config Class Initialized
INFO - 2023-06-22 02:13:07 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:13:07 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:13:07 --> Utf8 Class Initialized
INFO - 2023-06-22 02:13:07 --> URI Class Initialized
INFO - 2023-06-22 02:13:07 --> Router Class Initialized
INFO - 2023-06-22 02:13:07 --> Output Class Initialized
INFO - 2023-06-22 02:13:07 --> Security Class Initialized
DEBUG - 2023-06-22 02:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:13:07 --> Input Class Initialized
INFO - 2023-06-22 02:13:07 --> Language Class Initialized
INFO - 2023-06-22 02:13:07 --> Loader Class Initialized
INFO - 2023-06-22 02:13:07 --> Helper loaded: url_helper
INFO - 2023-06-22 02:13:07 --> Helper loaded: file_helper
INFO - 2023-06-22 02:13:07 --> Helper loaded: html_helper
INFO - 2023-06-22 02:13:07 --> Helper loaded: text_helper
INFO - 2023-06-22 02:13:07 --> Helper loaded: form_helper
INFO - 2023-06-22 02:13:07 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:13:07 --> Helper loaded: security_helper
INFO - 2023-06-22 02:13:07 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:13:07 --> Database Driver Class Initialized
INFO - 2023-06-22 02:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:13:07 --> Parser Class Initialized
INFO - 2023-06-22 02:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:13:07 --> Pagination Class Initialized
INFO - 2023-06-22 02:13:07 --> Form Validation Class Initialized
INFO - 2023-06-22 02:13:07 --> Controller Class Initialized
INFO - 2023-06-22 02:13:07 --> Model Class Initialized
INFO - 2023-06-22 02:13:07 --> Model Class Initialized
INFO - 2023-06-22 02:13:07 --> Final output sent to browser
DEBUG - 2023-06-22 02:13:07 --> Total execution time: 0.1364
ERROR - 2023-06-22 02:13:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:13:49 --> Config Class Initialized
INFO - 2023-06-22 02:13:49 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:13:49 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:13:49 --> Utf8 Class Initialized
INFO - 2023-06-22 02:13:49 --> URI Class Initialized
INFO - 2023-06-22 02:13:49 --> Router Class Initialized
INFO - 2023-06-22 02:13:49 --> Output Class Initialized
INFO - 2023-06-22 02:13:49 --> Security Class Initialized
DEBUG - 2023-06-22 02:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:13:49 --> Input Class Initialized
INFO - 2023-06-22 02:13:49 --> Language Class Initialized
INFO - 2023-06-22 02:13:49 --> Loader Class Initialized
INFO - 2023-06-22 02:13:49 --> Helper loaded: url_helper
INFO - 2023-06-22 02:13:49 --> Helper loaded: file_helper
INFO - 2023-06-22 02:13:49 --> Helper loaded: html_helper
INFO - 2023-06-22 02:13:49 --> Helper loaded: text_helper
INFO - 2023-06-22 02:13:49 --> Helper loaded: form_helper
INFO - 2023-06-22 02:13:49 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:13:49 --> Helper loaded: security_helper
INFO - 2023-06-22 02:13:49 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:13:49 --> Database Driver Class Initialized
INFO - 2023-06-22 02:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:13:49 --> Parser Class Initialized
INFO - 2023-06-22 02:13:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:13:49 --> Pagination Class Initialized
INFO - 2023-06-22 02:13:49 --> Form Validation Class Initialized
INFO - 2023-06-22 02:13:49 --> Controller Class Initialized
DEBUG - 2023-06-22 02:13:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:13:49 --> Model Class Initialized
DEBUG - 2023-06-22 02:13:49 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:13:49 --> Model Class Initialized
DEBUG - 2023-06-22 02:13:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:13:49 --> Model Class Initialized
DEBUG - 2023-06-22 02:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:13:49 --> Model Class Initialized
INFO - 2023-06-22 02:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-06-22 02:13:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:13:49 --> Model Class Initialized
INFO - 2023-06-22 02:13:49 --> Model Class Initialized
INFO - 2023-06-22 02:13:49 --> Model Class Initialized
INFO - 2023-06-22 02:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:13:49 --> Final output sent to browser
DEBUG - 2023-06-22 02:13:49 --> Total execution time: 0.0600
ERROR - 2023-06-22 02:13:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:13:50 --> Config Class Initialized
INFO - 2023-06-22 02:13:50 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:13:50 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:13:50 --> Utf8 Class Initialized
INFO - 2023-06-22 02:13:50 --> URI Class Initialized
INFO - 2023-06-22 02:13:50 --> Router Class Initialized
INFO - 2023-06-22 02:13:50 --> Output Class Initialized
INFO - 2023-06-22 02:13:50 --> Security Class Initialized
DEBUG - 2023-06-22 02:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:13:50 --> Input Class Initialized
INFO - 2023-06-22 02:13:50 --> Language Class Initialized
INFO - 2023-06-22 02:13:50 --> Loader Class Initialized
INFO - 2023-06-22 02:13:50 --> Helper loaded: url_helper
INFO - 2023-06-22 02:13:50 --> Helper loaded: file_helper
INFO - 2023-06-22 02:13:50 --> Helper loaded: html_helper
INFO - 2023-06-22 02:13:50 --> Helper loaded: text_helper
INFO - 2023-06-22 02:13:50 --> Helper loaded: form_helper
INFO - 2023-06-22 02:13:50 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:13:50 --> Helper loaded: security_helper
INFO - 2023-06-22 02:13:50 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:13:50 --> Database Driver Class Initialized
INFO - 2023-06-22 02:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:13:50 --> Parser Class Initialized
INFO - 2023-06-22 02:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:13:50 --> Pagination Class Initialized
INFO - 2023-06-22 02:13:50 --> Form Validation Class Initialized
INFO - 2023-06-22 02:13:50 --> Controller Class Initialized
DEBUG - 2023-06-22 02:13:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:13:50 --> Model Class Initialized
INFO - 2023-06-22 02:13:50 --> Final output sent to browser
DEBUG - 2023-06-22 02:13:50 --> Total execution time: 0.0158
ERROR - 2023-06-22 02:14:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:18 --> Config Class Initialized
INFO - 2023-06-22 02:14:18 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:18 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:18 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:18 --> URI Class Initialized
INFO - 2023-06-22 02:14:18 --> Router Class Initialized
INFO - 2023-06-22 02:14:18 --> Output Class Initialized
INFO - 2023-06-22 02:14:18 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:18 --> Input Class Initialized
INFO - 2023-06-22 02:14:18 --> Language Class Initialized
INFO - 2023-06-22 02:14:18 --> Loader Class Initialized
INFO - 2023-06-22 02:14:18 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:18 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:18 --> Parser Class Initialized
INFO - 2023-06-22 02:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:18 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:18 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:18 --> Controller Class Initialized
INFO - 2023-06-22 02:14:18 --> Model Class Initialized
INFO - 2023-06-22 02:14:18 --> Model Class Initialized
INFO - 2023-06-22 02:14:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-22 02:14:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:18 --> Model Class Initialized
INFO - 2023-06-22 02:14:18 --> Model Class Initialized
INFO - 2023-06-22 02:14:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:18 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:18 --> Total execution time: 0.0549
ERROR - 2023-06-22 02:14:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:18 --> Config Class Initialized
INFO - 2023-06-22 02:14:18 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:18 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:18 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:18 --> URI Class Initialized
INFO - 2023-06-22 02:14:18 --> Router Class Initialized
INFO - 2023-06-22 02:14:18 --> Output Class Initialized
INFO - 2023-06-22 02:14:18 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:18 --> Input Class Initialized
INFO - 2023-06-22 02:14:18 --> Language Class Initialized
INFO - 2023-06-22 02:14:18 --> Loader Class Initialized
INFO - 2023-06-22 02:14:18 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:18 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:18 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:18 --> Parser Class Initialized
INFO - 2023-06-22 02:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:18 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:18 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:18 --> Controller Class Initialized
INFO - 2023-06-22 02:14:18 --> Model Class Initialized
INFO - 2023-06-22 02:14:18 --> Model Class Initialized
INFO - 2023-06-22 02:14:18 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:18 --> Total execution time: 0.0179
ERROR - 2023-06-22 02:14:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:25 --> Config Class Initialized
INFO - 2023-06-22 02:14:25 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:25 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:25 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:25 --> URI Class Initialized
INFO - 2023-06-22 02:14:25 --> Router Class Initialized
INFO - 2023-06-22 02:14:25 --> Output Class Initialized
INFO - 2023-06-22 02:14:25 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:25 --> Input Class Initialized
INFO - 2023-06-22 02:14:25 --> Language Class Initialized
INFO - 2023-06-22 02:14:25 --> Loader Class Initialized
INFO - 2023-06-22 02:14:25 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:25 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:25 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:25 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:25 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:25 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:25 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:25 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:25 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:25 --> Parser Class Initialized
INFO - 2023-06-22 02:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:25 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:25 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:25 --> Controller Class Initialized
DEBUG - 2023-06-22 02:14:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:25 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:25 --> Lgift class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:25 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:25 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:25 --> Model Class Initialized
INFO - 2023-06-22 02:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/gift.php
DEBUG - 2023-06-22 02:14:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:25 --> Model Class Initialized
INFO - 2023-06-22 02:14:25 --> Model Class Initialized
INFO - 2023-06-22 02:14:25 --> Model Class Initialized
INFO - 2023-06-22 02:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:25 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:25 --> Total execution time: 0.0540
ERROR - 2023-06-22 02:14:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:26 --> Config Class Initialized
INFO - 2023-06-22 02:14:26 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:26 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:26 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:26 --> URI Class Initialized
INFO - 2023-06-22 02:14:26 --> Router Class Initialized
INFO - 2023-06-22 02:14:26 --> Output Class Initialized
INFO - 2023-06-22 02:14:26 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:26 --> Input Class Initialized
INFO - 2023-06-22 02:14:26 --> Language Class Initialized
INFO - 2023-06-22 02:14:26 --> Loader Class Initialized
INFO - 2023-06-22 02:14:26 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:26 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:26 --> Parser Class Initialized
INFO - 2023-06-22 02:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:26 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:26 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:26 --> Controller Class Initialized
DEBUG - 2023-06-22 02:14:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:26 --> Model Class Initialized
INFO - 2023-06-22 02:14:26 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:26 --> Total execution time: 0.0182
ERROR - 2023-06-22 02:14:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:26 --> Config Class Initialized
INFO - 2023-06-22 02:14:26 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:26 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:26 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:26 --> URI Class Initialized
INFO - 2023-06-22 02:14:26 --> Router Class Initialized
INFO - 2023-06-22 02:14:26 --> Output Class Initialized
INFO - 2023-06-22 02:14:26 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:26 --> Input Class Initialized
INFO - 2023-06-22 02:14:26 --> Language Class Initialized
INFO - 2023-06-22 02:14:26 --> Loader Class Initialized
INFO - 2023-06-22 02:14:26 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:26 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:26 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:26 --> Parser Class Initialized
INFO - 2023-06-22 02:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:26 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:26 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:26 --> Controller Class Initialized
INFO - 2023-06-22 02:14:26 --> Model Class Initialized
INFO - 2023-06-22 02:14:26 --> Model Class Initialized
INFO - 2023-06-22 02:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-22 02:14:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:26 --> Model Class Initialized
INFO - 2023-06-22 02:14:26 --> Model Class Initialized
INFO - 2023-06-22 02:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:26 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:26 --> Total execution time: 0.0572
ERROR - 2023-06-22 02:14:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:27 --> Config Class Initialized
INFO - 2023-06-22 02:14:27 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:27 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:27 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:27 --> URI Class Initialized
INFO - 2023-06-22 02:14:27 --> Router Class Initialized
INFO - 2023-06-22 02:14:27 --> Output Class Initialized
INFO - 2023-06-22 02:14:27 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:27 --> Input Class Initialized
INFO - 2023-06-22 02:14:27 --> Language Class Initialized
INFO - 2023-06-22 02:14:27 --> Loader Class Initialized
INFO - 2023-06-22 02:14:27 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:27 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:27 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:27 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:27 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:27 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:27 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:27 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:27 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:27 --> Parser Class Initialized
INFO - 2023-06-22 02:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:27 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:27 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:27 --> Controller Class Initialized
INFO - 2023-06-22 02:14:27 --> Model Class Initialized
INFO - 2023-06-22 02:14:27 --> Model Class Initialized
INFO - 2023-06-22 02:14:27 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:27 --> Total execution time: 0.0279
ERROR - 2023-06-22 02:14:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:35 --> Config Class Initialized
INFO - 2023-06-22 02:14:35 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:35 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:35 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:35 --> URI Class Initialized
DEBUG - 2023-06-22 02:14:35 --> No URI present. Default controller set.
INFO - 2023-06-22 02:14:35 --> Router Class Initialized
INFO - 2023-06-22 02:14:35 --> Output Class Initialized
INFO - 2023-06-22 02:14:35 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:35 --> Input Class Initialized
INFO - 2023-06-22 02:14:35 --> Language Class Initialized
INFO - 2023-06-22 02:14:35 --> Loader Class Initialized
INFO - 2023-06-22 02:14:35 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:35 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:35 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:35 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:35 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:35 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:35 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:35 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:35 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:35 --> Parser Class Initialized
INFO - 2023-06-22 02:14:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:35 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:35 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:35 --> Controller Class Initialized
INFO - 2023-06-22 02:14:35 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:35 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:35 --> Model Class Initialized
INFO - 2023-06-22 02:14:35 --> Model Class Initialized
INFO - 2023-06-22 02:14:35 --> Model Class Initialized
INFO - 2023-06-22 02:14:35 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:35 --> Model Class Initialized
INFO - 2023-06-22 02:14:35 --> Model Class Initialized
INFO - 2023-06-22 02:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 02:14:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:35 --> Model Class Initialized
INFO - 2023-06-22 02:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:35 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:35 --> Total execution time: 0.0621
ERROR - 2023-06-22 02:14:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:56 --> Config Class Initialized
INFO - 2023-06-22 02:14:56 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:56 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:56 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:56 --> URI Class Initialized
INFO - 2023-06-22 02:14:56 --> Router Class Initialized
INFO - 2023-06-22 02:14:56 --> Output Class Initialized
INFO - 2023-06-22 02:14:56 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:56 --> Input Class Initialized
INFO - 2023-06-22 02:14:56 --> Language Class Initialized
INFO - 2023-06-22 02:14:56 --> Loader Class Initialized
INFO - 2023-06-22 02:14:56 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:56 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:56 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:56 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:56 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:56 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:56 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:56 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:56 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:56 --> Parser Class Initialized
INFO - 2023-06-22 02:14:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:56 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:56 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:56 --> Controller Class Initialized
INFO - 2023-06-22 02:14:56 --> Model Class Initialized
INFO - 2023-06-22 02:14:56 --> Model Class Initialized
INFO - 2023-06-22 02:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-22 02:14:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:56 --> Model Class Initialized
INFO - 2023-06-22 02:14:56 --> Model Class Initialized
INFO - 2023-06-22 02:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:56 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:56 --> Total execution time: 0.0548
ERROR - 2023-06-22 02:14:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:57 --> Config Class Initialized
INFO - 2023-06-22 02:14:57 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:57 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:57 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:57 --> URI Class Initialized
INFO - 2023-06-22 02:14:57 --> Router Class Initialized
INFO - 2023-06-22 02:14:57 --> Output Class Initialized
INFO - 2023-06-22 02:14:57 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:57 --> Input Class Initialized
INFO - 2023-06-22 02:14:57 --> Language Class Initialized
INFO - 2023-06-22 02:14:57 --> Loader Class Initialized
INFO - 2023-06-22 02:14:57 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:57 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:57 --> Parser Class Initialized
INFO - 2023-06-22 02:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:57 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:57 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:57 --> Controller Class Initialized
INFO - 2023-06-22 02:14:57 --> Model Class Initialized
INFO - 2023-06-22 02:14:57 --> Model Class Initialized
INFO - 2023-06-22 02:14:57 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:57 --> Total execution time: 0.0524
ERROR - 2023-06-22 02:14:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:57 --> Config Class Initialized
INFO - 2023-06-22 02:14:57 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:57 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:57 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:57 --> URI Class Initialized
INFO - 2023-06-22 02:14:57 --> Router Class Initialized
INFO - 2023-06-22 02:14:57 --> Output Class Initialized
INFO - 2023-06-22 02:14:57 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:57 --> Input Class Initialized
INFO - 2023-06-22 02:14:57 --> Language Class Initialized
INFO - 2023-06-22 02:14:57 --> Loader Class Initialized
INFO - 2023-06-22 02:14:57 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:57 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:57 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:57 --> Parser Class Initialized
INFO - 2023-06-22 02:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:57 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:57 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:57 --> Controller Class Initialized
INFO - 2023-06-22 02:14:57 --> Model Class Initialized
INFO - 2023-06-22 02:14:57 --> Model Class Initialized
INFO - 2023-06-22 02:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-22 02:14:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:57 --> Model Class Initialized
INFO - 2023-06-22 02:14:57 --> Model Class Initialized
INFO - 2023-06-22 02:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:57 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:57 --> Total execution time: 0.1361
ERROR - 2023-06-22 02:14:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:58 --> Config Class Initialized
INFO - 2023-06-22 02:14:58 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:58 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:58 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:58 --> URI Class Initialized
INFO - 2023-06-22 02:14:58 --> Router Class Initialized
INFO - 2023-06-22 02:14:58 --> Output Class Initialized
INFO - 2023-06-22 02:14:58 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:58 --> Input Class Initialized
INFO - 2023-06-22 02:14:58 --> Language Class Initialized
INFO - 2023-06-22 02:14:58 --> Loader Class Initialized
INFO - 2023-06-22 02:14:58 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:58 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:58 --> Parser Class Initialized
INFO - 2023-06-22 02:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:58 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:58 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:58 --> Controller Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:58 --> Total execution time: 0.0685
ERROR - 2023-06-22 02:14:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:58 --> Config Class Initialized
INFO - 2023-06-22 02:14:58 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:58 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:58 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:58 --> URI Class Initialized
INFO - 2023-06-22 02:14:58 --> Router Class Initialized
INFO - 2023-06-22 02:14:58 --> Output Class Initialized
INFO - 2023-06-22 02:14:58 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:58 --> Input Class Initialized
INFO - 2023-06-22 02:14:58 --> Language Class Initialized
INFO - 2023-06-22 02:14:58 --> Loader Class Initialized
INFO - 2023-06-22 02:14:58 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:58 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:58 --> Parser Class Initialized
INFO - 2023-06-22 02:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:58 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:58 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:58 --> Controller Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:14:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-22 02:14:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:58 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:58 --> Total execution time: 0.0567
ERROR - 2023-06-22 02:14:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:58 --> Config Class Initialized
INFO - 2023-06-22 02:14:58 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:58 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:58 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:58 --> URI Class Initialized
DEBUG - 2023-06-22 02:14:58 --> No URI present. Default controller set.
INFO - 2023-06-22 02:14:58 --> Router Class Initialized
INFO - 2023-06-22 02:14:58 --> Output Class Initialized
INFO - 2023-06-22 02:14:58 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:58 --> Input Class Initialized
INFO - 2023-06-22 02:14:58 --> Language Class Initialized
INFO - 2023-06-22 02:14:58 --> Loader Class Initialized
INFO - 2023-06-22 02:14:58 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:58 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:58 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:58 --> Parser Class Initialized
INFO - 2023-06-22 02:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:58 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:58 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:58 --> Controller Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:14:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:58 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 02:14:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:59 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:59 --> Total execution time: 0.0671
ERROR - 2023-06-22 02:14:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:59 --> Config Class Initialized
INFO - 2023-06-22 02:14:59 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:59 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:59 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:59 --> URI Class Initialized
INFO - 2023-06-22 02:14:59 --> Router Class Initialized
INFO - 2023-06-22 02:14:59 --> Output Class Initialized
INFO - 2023-06-22 02:14:59 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:59 --> Input Class Initialized
INFO - 2023-06-22 02:14:59 --> Language Class Initialized
INFO - 2023-06-22 02:14:59 --> Loader Class Initialized
INFO - 2023-06-22 02:14:59 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:59 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:59 --> Parser Class Initialized
INFO - 2023-06-22 02:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:59 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:59 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:59 --> Controller Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:59 --> Total execution time: 0.0241
ERROR - 2023-06-22 02:14:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:59 --> Config Class Initialized
INFO - 2023-06-22 02:14:59 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:59 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:59 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:59 --> URI Class Initialized
DEBUG - 2023-06-22 02:14:59 --> No URI present. Default controller set.
INFO - 2023-06-22 02:14:59 --> Router Class Initialized
INFO - 2023-06-22 02:14:59 --> Output Class Initialized
INFO - 2023-06-22 02:14:59 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:59 --> Input Class Initialized
INFO - 2023-06-22 02:14:59 --> Language Class Initialized
INFO - 2023-06-22 02:14:59 --> Loader Class Initialized
INFO - 2023-06-22 02:14:59 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:59 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:59 --> Parser Class Initialized
INFO - 2023-06-22 02:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:59 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:59 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:59 --> Controller Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 02:14:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:59 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:59 --> Total execution time: 0.0597
ERROR - 2023-06-22 02:14:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:59 --> Config Class Initialized
INFO - 2023-06-22 02:14:59 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:59 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:59 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:59 --> URI Class Initialized
INFO - 2023-06-22 02:14:59 --> Router Class Initialized
INFO - 2023-06-22 02:14:59 --> Output Class Initialized
INFO - 2023-06-22 02:14:59 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:59 --> Input Class Initialized
INFO - 2023-06-22 02:14:59 --> Language Class Initialized
INFO - 2023-06-22 02:14:59 --> Loader Class Initialized
INFO - 2023-06-22 02:14:59 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:59 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:59 --> Parser Class Initialized
INFO - 2023-06-22 02:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:59 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:59 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:59 --> Controller Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 02:14:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:59 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:59 --> Total execution time: 0.0252
ERROR - 2023-06-22 02:14:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 02:14:59 --> Config Class Initialized
INFO - 2023-06-22 02:14:59 --> Hooks Class Initialized
DEBUG - 2023-06-22 02:14:59 --> UTF-8 Support Enabled
INFO - 2023-06-22 02:14:59 --> Utf8 Class Initialized
INFO - 2023-06-22 02:14:59 --> URI Class Initialized
INFO - 2023-06-22 02:14:59 --> Router Class Initialized
INFO - 2023-06-22 02:14:59 --> Output Class Initialized
INFO - 2023-06-22 02:14:59 --> Security Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 02:14:59 --> Input Class Initialized
INFO - 2023-06-22 02:14:59 --> Language Class Initialized
INFO - 2023-06-22 02:14:59 --> Loader Class Initialized
INFO - 2023-06-22 02:14:59 --> Helper loaded: url_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: file_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: html_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: text_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: form_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: lang_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: security_helper
INFO - 2023-06-22 02:14:59 --> Helper loaded: cookie_helper
INFO - 2023-06-22 02:14:59 --> Database Driver Class Initialized
INFO - 2023-06-22 02:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 02:14:59 --> Parser Class Initialized
INFO - 2023-06-22 02:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 02:14:59 --> Pagination Class Initialized
INFO - 2023-06-22 02:14:59 --> Form Validation Class Initialized
INFO - 2023-06-22 02:14:59 --> Controller Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
DEBUG - 2023-06-22 02:14:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 02:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 02:14:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 02:14:59 --> Model Class Initialized
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 02:14:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 02:14:59 --> Final output sent to browser
DEBUG - 2023-06-22 02:14:59 --> Total execution time: 0.0596
ERROR - 2023-06-22 03:25:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:25:25 --> Config Class Initialized
INFO - 2023-06-22 03:25:25 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:25:25 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:25:25 --> Utf8 Class Initialized
INFO - 2023-06-22 03:25:25 --> URI Class Initialized
DEBUG - 2023-06-22 03:25:25 --> No URI present. Default controller set.
INFO - 2023-06-22 03:25:25 --> Router Class Initialized
INFO - 2023-06-22 03:25:25 --> Output Class Initialized
INFO - 2023-06-22 03:25:25 --> Security Class Initialized
DEBUG - 2023-06-22 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:25:25 --> Input Class Initialized
INFO - 2023-06-22 03:25:25 --> Language Class Initialized
INFO - 2023-06-22 03:25:25 --> Loader Class Initialized
INFO - 2023-06-22 03:25:25 --> Helper loaded: url_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: file_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: html_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: text_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: form_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: security_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:25:25 --> Database Driver Class Initialized
INFO - 2023-06-22 03:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:25:25 --> Parser Class Initialized
INFO - 2023-06-22 03:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:25:25 --> Pagination Class Initialized
INFO - 2023-06-22 03:25:25 --> Form Validation Class Initialized
INFO - 2023-06-22 03:25:25 --> Controller Class Initialized
INFO - 2023-06-22 03:25:25 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 03:25:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:25:25 --> Config Class Initialized
INFO - 2023-06-22 03:25:25 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:25:25 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:25:25 --> Utf8 Class Initialized
INFO - 2023-06-22 03:25:25 --> URI Class Initialized
INFO - 2023-06-22 03:25:25 --> Router Class Initialized
INFO - 2023-06-22 03:25:25 --> Output Class Initialized
INFO - 2023-06-22 03:25:25 --> Security Class Initialized
DEBUG - 2023-06-22 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:25:25 --> Input Class Initialized
INFO - 2023-06-22 03:25:25 --> Language Class Initialized
INFO - 2023-06-22 03:25:25 --> Loader Class Initialized
INFO - 2023-06-22 03:25:25 --> Helper loaded: url_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: file_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: html_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: text_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: form_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: security_helper
INFO - 2023-06-22 03:25:25 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:25:25 --> Database Driver Class Initialized
INFO - 2023-06-22 03:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:25:25 --> Parser Class Initialized
INFO - 2023-06-22 03:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:25:25 --> Pagination Class Initialized
INFO - 2023-06-22 03:25:25 --> Form Validation Class Initialized
INFO - 2023-06-22 03:25:25 --> Controller Class Initialized
INFO - 2023-06-22 03:25:25 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 03:25:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 03:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 03:25:25 --> Model Class Initialized
INFO - 2023-06-22 03:25:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 03:25:25 --> Final output sent to browser
DEBUG - 2023-06-22 03:25:25 --> Total execution time: 0.0304
ERROR - 2023-06-22 03:25:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:25:30 --> Config Class Initialized
INFO - 2023-06-22 03:25:30 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:25:30 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:25:30 --> Utf8 Class Initialized
INFO - 2023-06-22 03:25:30 --> URI Class Initialized
INFO - 2023-06-22 03:25:30 --> Router Class Initialized
INFO - 2023-06-22 03:25:30 --> Output Class Initialized
INFO - 2023-06-22 03:25:30 --> Security Class Initialized
DEBUG - 2023-06-22 03:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:25:30 --> Input Class Initialized
INFO - 2023-06-22 03:25:30 --> Language Class Initialized
INFO - 2023-06-22 03:25:30 --> Loader Class Initialized
INFO - 2023-06-22 03:25:30 --> Helper loaded: url_helper
INFO - 2023-06-22 03:25:30 --> Helper loaded: file_helper
INFO - 2023-06-22 03:25:30 --> Helper loaded: html_helper
INFO - 2023-06-22 03:25:30 --> Helper loaded: text_helper
INFO - 2023-06-22 03:25:30 --> Helper loaded: form_helper
INFO - 2023-06-22 03:25:30 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:25:30 --> Helper loaded: security_helper
INFO - 2023-06-22 03:25:30 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:25:30 --> Database Driver Class Initialized
INFO - 2023-06-22 03:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:25:30 --> Parser Class Initialized
INFO - 2023-06-22 03:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:25:30 --> Pagination Class Initialized
INFO - 2023-06-22 03:25:30 --> Form Validation Class Initialized
INFO - 2023-06-22 03:25:30 --> Controller Class Initialized
INFO - 2023-06-22 03:25:30 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:30 --> Model Class Initialized
INFO - 2023-06-22 03:25:30 --> Final output sent to browser
DEBUG - 2023-06-22 03:25:30 --> Total execution time: 0.0217
ERROR - 2023-06-22 03:25:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:25:30 --> Config Class Initialized
INFO - 2023-06-22 03:25:30 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:25:30 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:25:30 --> Utf8 Class Initialized
INFO - 2023-06-22 03:25:31 --> URI Class Initialized
DEBUG - 2023-06-22 03:25:31 --> No URI present. Default controller set.
INFO - 2023-06-22 03:25:31 --> Router Class Initialized
INFO - 2023-06-22 03:25:31 --> Output Class Initialized
INFO - 2023-06-22 03:25:31 --> Security Class Initialized
DEBUG - 2023-06-22 03:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:25:31 --> Input Class Initialized
INFO - 2023-06-22 03:25:31 --> Language Class Initialized
INFO - 2023-06-22 03:25:31 --> Loader Class Initialized
INFO - 2023-06-22 03:25:31 --> Helper loaded: url_helper
INFO - 2023-06-22 03:25:31 --> Helper loaded: file_helper
INFO - 2023-06-22 03:25:31 --> Helper loaded: html_helper
INFO - 2023-06-22 03:25:31 --> Helper loaded: text_helper
INFO - 2023-06-22 03:25:31 --> Helper loaded: form_helper
INFO - 2023-06-22 03:25:31 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:25:31 --> Helper loaded: security_helper
INFO - 2023-06-22 03:25:31 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:25:31 --> Database Driver Class Initialized
INFO - 2023-06-22 03:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:25:31 --> Parser Class Initialized
INFO - 2023-06-22 03:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:25:31 --> Pagination Class Initialized
INFO - 2023-06-22 03:25:31 --> Form Validation Class Initialized
INFO - 2023-06-22 03:25:31 --> Controller Class Initialized
INFO - 2023-06-22 03:25:31 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:31 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:31 --> Model Class Initialized
INFO - 2023-06-22 03:25:31 --> Model Class Initialized
INFO - 2023-06-22 03:25:31 --> Model Class Initialized
INFO - 2023-06-22 03:25:31 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 03:25:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:31 --> Model Class Initialized
INFO - 2023-06-22 03:25:31 --> Model Class Initialized
INFO - 2023-06-22 03:25:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 03:25:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 03:25:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 03:25:31 --> Model Class Initialized
INFO - 2023-06-22 03:25:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 03:25:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 03:25:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 03:25:31 --> Final output sent to browser
DEBUG - 2023-06-22 03:25:31 --> Total execution time: 0.1596
ERROR - 2023-06-22 03:25:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:25:32 --> Config Class Initialized
INFO - 2023-06-22 03:25:32 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:25:32 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:25:32 --> Utf8 Class Initialized
INFO - 2023-06-22 03:25:32 --> URI Class Initialized
INFO - 2023-06-22 03:25:32 --> Router Class Initialized
INFO - 2023-06-22 03:25:32 --> Output Class Initialized
INFO - 2023-06-22 03:25:32 --> Security Class Initialized
DEBUG - 2023-06-22 03:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:25:32 --> Input Class Initialized
INFO - 2023-06-22 03:25:32 --> Language Class Initialized
INFO - 2023-06-22 03:25:32 --> Loader Class Initialized
INFO - 2023-06-22 03:25:32 --> Helper loaded: url_helper
INFO - 2023-06-22 03:25:32 --> Helper loaded: file_helper
INFO - 2023-06-22 03:25:32 --> Helper loaded: html_helper
INFO - 2023-06-22 03:25:32 --> Helper loaded: text_helper
INFO - 2023-06-22 03:25:32 --> Helper loaded: form_helper
INFO - 2023-06-22 03:25:32 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:25:32 --> Helper loaded: security_helper
INFO - 2023-06-22 03:25:32 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:25:32 --> Database Driver Class Initialized
INFO - 2023-06-22 03:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:25:32 --> Parser Class Initialized
INFO - 2023-06-22 03:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:25:32 --> Pagination Class Initialized
INFO - 2023-06-22 03:25:32 --> Form Validation Class Initialized
INFO - 2023-06-22 03:25:32 --> Controller Class Initialized
DEBUG - 2023-06-22 03:25:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 03:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:32 --> Model Class Initialized
INFO - 2023-06-22 03:25:32 --> Final output sent to browser
DEBUG - 2023-06-22 03:25:32 --> Total execution time: 0.0138
ERROR - 2023-06-22 03:25:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:25:48 --> Config Class Initialized
INFO - 2023-06-22 03:25:48 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:25:48 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:25:48 --> Utf8 Class Initialized
INFO - 2023-06-22 03:25:48 --> URI Class Initialized
DEBUG - 2023-06-22 03:25:48 --> No URI present. Default controller set.
INFO - 2023-06-22 03:25:48 --> Router Class Initialized
INFO - 2023-06-22 03:25:48 --> Output Class Initialized
INFO - 2023-06-22 03:25:48 --> Security Class Initialized
DEBUG - 2023-06-22 03:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:25:48 --> Input Class Initialized
INFO - 2023-06-22 03:25:48 --> Language Class Initialized
INFO - 2023-06-22 03:25:48 --> Loader Class Initialized
INFO - 2023-06-22 03:25:48 --> Helper loaded: url_helper
INFO - 2023-06-22 03:25:48 --> Helper loaded: file_helper
INFO - 2023-06-22 03:25:48 --> Helper loaded: html_helper
INFO - 2023-06-22 03:25:48 --> Helper loaded: text_helper
INFO - 2023-06-22 03:25:48 --> Helper loaded: form_helper
INFO - 2023-06-22 03:25:48 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:25:48 --> Helper loaded: security_helper
INFO - 2023-06-22 03:25:48 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:25:48 --> Database Driver Class Initialized
INFO - 2023-06-22 03:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:25:48 --> Parser Class Initialized
INFO - 2023-06-22 03:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:25:48 --> Pagination Class Initialized
INFO - 2023-06-22 03:25:48 --> Form Validation Class Initialized
INFO - 2023-06-22 03:25:48 --> Controller Class Initialized
INFO - 2023-06-22 03:25:48 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 03:25:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:25:49 --> Config Class Initialized
INFO - 2023-06-22 03:25:49 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:25:49 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:25:49 --> Utf8 Class Initialized
INFO - 2023-06-22 03:25:49 --> URI Class Initialized
INFO - 2023-06-22 03:25:49 --> Router Class Initialized
INFO - 2023-06-22 03:25:49 --> Output Class Initialized
INFO - 2023-06-22 03:25:49 --> Security Class Initialized
DEBUG - 2023-06-22 03:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:25:49 --> Input Class Initialized
INFO - 2023-06-22 03:25:49 --> Language Class Initialized
INFO - 2023-06-22 03:25:49 --> Loader Class Initialized
INFO - 2023-06-22 03:25:49 --> Helper loaded: url_helper
INFO - 2023-06-22 03:25:49 --> Helper loaded: file_helper
INFO - 2023-06-22 03:25:49 --> Helper loaded: html_helper
INFO - 2023-06-22 03:25:49 --> Helper loaded: text_helper
INFO - 2023-06-22 03:25:49 --> Helper loaded: form_helper
INFO - 2023-06-22 03:25:49 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:25:49 --> Helper loaded: security_helper
INFO - 2023-06-22 03:25:49 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:25:49 --> Database Driver Class Initialized
INFO - 2023-06-22 03:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:25:49 --> Parser Class Initialized
INFO - 2023-06-22 03:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:25:49 --> Pagination Class Initialized
INFO - 2023-06-22 03:25:49 --> Form Validation Class Initialized
INFO - 2023-06-22 03:25:49 --> Controller Class Initialized
INFO - 2023-06-22 03:25:49 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 03:25:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 03:25:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 03:25:49 --> Model Class Initialized
INFO - 2023-06-22 03:25:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 03:25:49 --> Final output sent to browser
DEBUG - 2023-06-22 03:25:49 --> Total execution time: 0.0269
ERROR - 2023-06-22 03:25:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:25:55 --> Config Class Initialized
INFO - 2023-06-22 03:25:55 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:25:55 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:25:55 --> Utf8 Class Initialized
INFO - 2023-06-22 03:25:55 --> URI Class Initialized
INFO - 2023-06-22 03:25:55 --> Router Class Initialized
INFO - 2023-06-22 03:25:55 --> Output Class Initialized
INFO - 2023-06-22 03:25:55 --> Security Class Initialized
DEBUG - 2023-06-22 03:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:25:55 --> Input Class Initialized
INFO - 2023-06-22 03:25:55 --> Language Class Initialized
INFO - 2023-06-22 03:25:55 --> Loader Class Initialized
INFO - 2023-06-22 03:25:55 --> Helper loaded: url_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: file_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: html_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: text_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: form_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: security_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:25:55 --> Database Driver Class Initialized
INFO - 2023-06-22 03:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:25:55 --> Parser Class Initialized
INFO - 2023-06-22 03:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:25:55 --> Pagination Class Initialized
INFO - 2023-06-22 03:25:55 --> Form Validation Class Initialized
INFO - 2023-06-22 03:25:55 --> Controller Class Initialized
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
INFO - 2023-06-22 03:25:55 --> Final output sent to browser
DEBUG - 2023-06-22 03:25:55 --> Total execution time: 0.0179
ERROR - 2023-06-22 03:25:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:25:55 --> Config Class Initialized
INFO - 2023-06-22 03:25:55 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:25:55 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:25:55 --> Utf8 Class Initialized
INFO - 2023-06-22 03:25:55 --> URI Class Initialized
DEBUG - 2023-06-22 03:25:55 --> No URI present. Default controller set.
INFO - 2023-06-22 03:25:55 --> Router Class Initialized
INFO - 2023-06-22 03:25:55 --> Output Class Initialized
INFO - 2023-06-22 03:25:55 --> Security Class Initialized
DEBUG - 2023-06-22 03:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:25:55 --> Input Class Initialized
INFO - 2023-06-22 03:25:55 --> Language Class Initialized
INFO - 2023-06-22 03:25:55 --> Loader Class Initialized
INFO - 2023-06-22 03:25:55 --> Helper loaded: url_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: file_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: html_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: text_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: form_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: security_helper
INFO - 2023-06-22 03:25:55 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:25:55 --> Database Driver Class Initialized
INFO - 2023-06-22 03:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:25:55 --> Parser Class Initialized
INFO - 2023-06-22 03:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:25:55 --> Pagination Class Initialized
INFO - 2023-06-22 03:25:55 --> Form Validation Class Initialized
INFO - 2023-06-22 03:25:55 --> Controller Class Initialized
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
DEBUG - 2023-06-22 03:25:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 03:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
INFO - 2023-06-22 03:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 03:25:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 03:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 03:25:55 --> Model Class Initialized
INFO - 2023-06-22 03:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 03:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 03:25:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 03:25:55 --> Final output sent to browser
DEBUG - 2023-06-22 03:25:55 --> Total execution time: 0.0733
ERROR - 2023-06-22 03:26:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:26:03 --> Config Class Initialized
INFO - 2023-06-22 03:26:03 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:26:03 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:26:03 --> Utf8 Class Initialized
INFO - 2023-06-22 03:26:03 --> URI Class Initialized
INFO - 2023-06-22 03:26:03 --> Router Class Initialized
INFO - 2023-06-22 03:26:03 --> Output Class Initialized
INFO - 2023-06-22 03:26:03 --> Security Class Initialized
DEBUG - 2023-06-22 03:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:26:03 --> Input Class Initialized
INFO - 2023-06-22 03:26:03 --> Language Class Initialized
INFO - 2023-06-22 03:26:03 --> Loader Class Initialized
INFO - 2023-06-22 03:26:03 --> Helper loaded: url_helper
INFO - 2023-06-22 03:26:03 --> Helper loaded: file_helper
INFO - 2023-06-22 03:26:03 --> Helper loaded: html_helper
INFO - 2023-06-22 03:26:03 --> Helper loaded: text_helper
INFO - 2023-06-22 03:26:03 --> Helper loaded: form_helper
INFO - 2023-06-22 03:26:03 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:26:03 --> Helper loaded: security_helper
INFO - 2023-06-22 03:26:03 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:26:03 --> Database Driver Class Initialized
INFO - 2023-06-22 03:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:26:03 --> Parser Class Initialized
INFO - 2023-06-22 03:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:26:03 --> Pagination Class Initialized
INFO - 2023-06-22 03:26:03 --> Form Validation Class Initialized
INFO - 2023-06-22 03:26:03 --> Controller Class Initialized
INFO - 2023-06-22 03:26:03 --> Model Class Initialized
DEBUG - 2023-06-22 03:26:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 03:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:26:03 --> Model Class Initialized
DEBUG - 2023-06-22 03:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:26:03 --> Model Class Initialized
INFO - 2023-06-22 03:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-22 03:26:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 03:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 03:26:03 --> Model Class Initialized
INFO - 2023-06-22 03:26:03 --> Model Class Initialized
INFO - 2023-06-22 03:26:03 --> Model Class Initialized
INFO - 2023-06-22 03:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 03:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 03:26:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 03:26:03 --> Final output sent to browser
DEBUG - 2023-06-22 03:26:03 --> Total execution time: 0.0648
ERROR - 2023-06-22 03:26:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:26:04 --> Config Class Initialized
INFO - 2023-06-22 03:26:04 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:26:04 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:26:04 --> Utf8 Class Initialized
INFO - 2023-06-22 03:26:04 --> URI Class Initialized
INFO - 2023-06-22 03:26:04 --> Router Class Initialized
INFO - 2023-06-22 03:26:04 --> Output Class Initialized
INFO - 2023-06-22 03:26:04 --> Security Class Initialized
DEBUG - 2023-06-22 03:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:26:04 --> Input Class Initialized
INFO - 2023-06-22 03:26:04 --> Language Class Initialized
INFO - 2023-06-22 03:26:04 --> Loader Class Initialized
INFO - 2023-06-22 03:26:04 --> Helper loaded: url_helper
INFO - 2023-06-22 03:26:04 --> Helper loaded: file_helper
INFO - 2023-06-22 03:26:04 --> Helper loaded: html_helper
INFO - 2023-06-22 03:26:04 --> Helper loaded: text_helper
INFO - 2023-06-22 03:26:04 --> Helper loaded: form_helper
INFO - 2023-06-22 03:26:04 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:26:04 --> Helper loaded: security_helper
INFO - 2023-06-22 03:26:04 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:26:04 --> Database Driver Class Initialized
INFO - 2023-06-22 03:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:26:04 --> Parser Class Initialized
INFO - 2023-06-22 03:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:26:04 --> Pagination Class Initialized
INFO - 2023-06-22 03:26:04 --> Form Validation Class Initialized
INFO - 2023-06-22 03:26:04 --> Controller Class Initialized
INFO - 2023-06-22 03:26:04 --> Model Class Initialized
DEBUG - 2023-06-22 03:26:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 03:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:26:04 --> Model Class Initialized
DEBUG - 2023-06-22 03:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:26:04 --> Model Class Initialized
INFO - 2023-06-22 03:26:04 --> Final output sent to browser
DEBUG - 2023-06-22 03:26:04 --> Total execution time: 0.0431
ERROR - 2023-06-22 03:29:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:29:32 --> Config Class Initialized
INFO - 2023-06-22 03:29:32 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:29:32 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:29:32 --> Utf8 Class Initialized
INFO - 2023-06-22 03:29:32 --> URI Class Initialized
INFO - 2023-06-22 03:29:32 --> Router Class Initialized
INFO - 2023-06-22 03:29:32 --> Output Class Initialized
INFO - 2023-06-22 03:29:32 --> Security Class Initialized
DEBUG - 2023-06-22 03:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:29:32 --> Input Class Initialized
INFO - 2023-06-22 03:29:32 --> Language Class Initialized
INFO - 2023-06-22 03:29:32 --> Loader Class Initialized
INFO - 2023-06-22 03:29:32 --> Helper loaded: url_helper
INFO - 2023-06-22 03:29:32 --> Helper loaded: file_helper
INFO - 2023-06-22 03:29:32 --> Helper loaded: html_helper
INFO - 2023-06-22 03:29:32 --> Helper loaded: text_helper
INFO - 2023-06-22 03:29:32 --> Helper loaded: form_helper
INFO - 2023-06-22 03:29:32 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:29:32 --> Helper loaded: security_helper
INFO - 2023-06-22 03:29:32 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:29:32 --> Database Driver Class Initialized
INFO - 2023-06-22 03:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:29:32 --> Parser Class Initialized
INFO - 2023-06-22 03:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:29:32 --> Pagination Class Initialized
INFO - 2023-06-22 03:29:32 --> Form Validation Class Initialized
INFO - 2023-06-22 03:29:32 --> Controller Class Initialized
INFO - 2023-06-22 03:29:32 --> Model Class Initialized
ERROR - 2023-06-22 03:31:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:31:53 --> Config Class Initialized
INFO - 2023-06-22 03:31:53 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:31:53 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:31:53 --> Utf8 Class Initialized
INFO - 2023-06-22 03:31:53 --> URI Class Initialized
INFO - 2023-06-22 03:31:53 --> Router Class Initialized
INFO - 2023-06-22 03:31:53 --> Output Class Initialized
INFO - 2023-06-22 03:31:53 --> Security Class Initialized
DEBUG - 2023-06-22 03:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:31:53 --> Input Class Initialized
INFO - 2023-06-22 03:31:53 --> Language Class Initialized
INFO - 2023-06-22 03:31:53 --> Loader Class Initialized
INFO - 2023-06-22 03:31:53 --> Helper loaded: url_helper
INFO - 2023-06-22 03:31:53 --> Helper loaded: file_helper
INFO - 2023-06-22 03:31:53 --> Helper loaded: html_helper
INFO - 2023-06-22 03:31:53 --> Helper loaded: text_helper
INFO - 2023-06-22 03:31:53 --> Helper loaded: form_helper
INFO - 2023-06-22 03:31:53 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:31:53 --> Helper loaded: security_helper
INFO - 2023-06-22 03:31:53 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:31:53 --> Database Driver Class Initialized
INFO - 2023-06-22 03:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:31:53 --> Parser Class Initialized
INFO - 2023-06-22 03:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:31:53 --> Pagination Class Initialized
INFO - 2023-06-22 03:31:53 --> Form Validation Class Initialized
INFO - 2023-06-22 03:31:53 --> Controller Class Initialized
INFO - 2023-06-22 03:31:53 --> Model Class Initialized
ERROR - 2023-06-22 03:34:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:34:12 --> Config Class Initialized
INFO - 2023-06-22 03:34:12 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:34:12 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:34:12 --> Utf8 Class Initialized
INFO - 2023-06-22 03:34:12 --> URI Class Initialized
INFO - 2023-06-22 03:34:12 --> Router Class Initialized
INFO - 2023-06-22 03:34:12 --> Output Class Initialized
INFO - 2023-06-22 03:34:12 --> Security Class Initialized
DEBUG - 2023-06-22 03:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:34:12 --> Input Class Initialized
INFO - 2023-06-22 03:34:12 --> Language Class Initialized
INFO - 2023-06-22 03:34:12 --> Loader Class Initialized
INFO - 2023-06-22 03:34:12 --> Helper loaded: url_helper
INFO - 2023-06-22 03:34:12 --> Helper loaded: file_helper
INFO - 2023-06-22 03:34:12 --> Helper loaded: html_helper
INFO - 2023-06-22 03:34:12 --> Helper loaded: text_helper
INFO - 2023-06-22 03:34:12 --> Helper loaded: form_helper
INFO - 2023-06-22 03:34:12 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:34:12 --> Helper loaded: security_helper
INFO - 2023-06-22 03:34:12 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:34:12 --> Database Driver Class Initialized
INFO - 2023-06-22 03:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:34:12 --> Parser Class Initialized
INFO - 2023-06-22 03:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:34:12 --> Pagination Class Initialized
INFO - 2023-06-22 03:34:12 --> Form Validation Class Initialized
INFO - 2023-06-22 03:34:12 --> Controller Class Initialized
INFO - 2023-06-22 03:34:12 --> Model Class Initialized
ERROR - 2023-06-22 03:40:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:40:49 --> Config Class Initialized
INFO - 2023-06-22 03:40:49 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:40:49 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:40:49 --> Utf8 Class Initialized
INFO - 2023-06-22 03:40:49 --> URI Class Initialized
INFO - 2023-06-22 03:40:49 --> Router Class Initialized
INFO - 2023-06-22 03:40:49 --> Output Class Initialized
INFO - 2023-06-22 03:40:49 --> Security Class Initialized
DEBUG - 2023-06-22 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:40:49 --> Input Class Initialized
INFO - 2023-06-22 03:40:49 --> Language Class Initialized
INFO - 2023-06-22 03:40:49 --> Loader Class Initialized
INFO - 2023-06-22 03:40:49 --> Helper loaded: url_helper
INFO - 2023-06-22 03:40:49 --> Helper loaded: file_helper
INFO - 2023-06-22 03:40:49 --> Helper loaded: html_helper
INFO - 2023-06-22 03:40:49 --> Helper loaded: text_helper
INFO - 2023-06-22 03:40:49 --> Helper loaded: form_helper
INFO - 2023-06-22 03:40:49 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:40:49 --> Helper loaded: security_helper
INFO - 2023-06-22 03:40:49 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:40:49 --> Database Driver Class Initialized
INFO - 2023-06-22 03:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:40:49 --> Parser Class Initialized
INFO - 2023-06-22 03:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:40:49 --> Pagination Class Initialized
INFO - 2023-06-22 03:40:49 --> Form Validation Class Initialized
INFO - 2023-06-22 03:40:49 --> Controller Class Initialized
DEBUG - 2023-06-22 03:40:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 03:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 03:40:49 --> Model Class Initialized
ERROR - 2023-06-22 03:41:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:41:23 --> Config Class Initialized
INFO - 2023-06-22 03:41:23 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:41:23 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:41:23 --> Utf8 Class Initialized
INFO - 2023-06-22 03:41:23 --> URI Class Initialized
INFO - 2023-06-22 03:41:23 --> Router Class Initialized
INFO - 2023-06-22 03:41:23 --> Output Class Initialized
INFO - 2023-06-22 03:41:23 --> Security Class Initialized
DEBUG - 2023-06-22 03:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:41:23 --> Input Class Initialized
INFO - 2023-06-22 03:41:23 --> Language Class Initialized
INFO - 2023-06-22 03:41:23 --> Loader Class Initialized
INFO - 2023-06-22 03:41:23 --> Helper loaded: url_helper
INFO - 2023-06-22 03:41:23 --> Helper loaded: file_helper
INFO - 2023-06-22 03:41:23 --> Helper loaded: html_helper
INFO - 2023-06-22 03:41:23 --> Helper loaded: text_helper
INFO - 2023-06-22 03:41:23 --> Helper loaded: form_helper
INFO - 2023-06-22 03:41:23 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:41:23 --> Helper loaded: security_helper
INFO - 2023-06-22 03:41:23 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:41:23 --> Database Driver Class Initialized
INFO - 2023-06-22 03:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:41:23 --> Parser Class Initialized
INFO - 2023-06-22 03:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:41:23 --> Pagination Class Initialized
INFO - 2023-06-22 03:41:23 --> Form Validation Class Initialized
INFO - 2023-06-22 03:41:23 --> Controller Class Initialized
ERROR - 2023-06-22 03:41:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 03:41:42 --> Config Class Initialized
INFO - 2023-06-22 03:41:42 --> Hooks Class Initialized
DEBUG - 2023-06-22 03:41:42 --> UTF-8 Support Enabled
INFO - 2023-06-22 03:41:42 --> Utf8 Class Initialized
INFO - 2023-06-22 03:41:42 --> URI Class Initialized
INFO - 2023-06-22 03:41:42 --> Router Class Initialized
INFO - 2023-06-22 03:41:42 --> Output Class Initialized
INFO - 2023-06-22 03:41:42 --> Security Class Initialized
DEBUG - 2023-06-22 03:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 03:41:42 --> Input Class Initialized
INFO - 2023-06-22 03:41:42 --> Language Class Initialized
INFO - 2023-06-22 03:41:42 --> Loader Class Initialized
INFO - 2023-06-22 03:41:42 --> Helper loaded: url_helper
INFO - 2023-06-22 03:41:42 --> Helper loaded: file_helper
INFO - 2023-06-22 03:41:42 --> Helper loaded: html_helper
INFO - 2023-06-22 03:41:42 --> Helper loaded: text_helper
INFO - 2023-06-22 03:41:42 --> Helper loaded: form_helper
INFO - 2023-06-22 03:41:42 --> Helper loaded: lang_helper
INFO - 2023-06-22 03:41:42 --> Helper loaded: security_helper
INFO - 2023-06-22 03:41:42 --> Helper loaded: cookie_helper
INFO - 2023-06-22 03:41:42 --> Database Driver Class Initialized
INFO - 2023-06-22 03:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 03:41:42 --> Parser Class Initialized
INFO - 2023-06-22 03:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 03:41:42 --> Pagination Class Initialized
INFO - 2023-06-22 03:41:42 --> Form Validation Class Initialized
INFO - 2023-06-22 03:41:42 --> Controller Class Initialized
INFO - 2023-06-22 03:41:42 --> Model Class Initialized
ERROR - 2023-06-22 06:20:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:20:06 --> Config Class Initialized
INFO - 2023-06-22 06:20:06 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:20:06 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:20:06 --> Utf8 Class Initialized
INFO - 2023-06-22 06:20:06 --> URI Class Initialized
DEBUG - 2023-06-22 06:20:06 --> No URI present. Default controller set.
INFO - 2023-06-22 06:20:06 --> Router Class Initialized
INFO - 2023-06-22 06:20:06 --> Output Class Initialized
INFO - 2023-06-22 06:20:06 --> Security Class Initialized
DEBUG - 2023-06-22 06:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:20:06 --> Input Class Initialized
INFO - 2023-06-22 06:20:06 --> Language Class Initialized
INFO - 2023-06-22 06:20:06 --> Loader Class Initialized
INFO - 2023-06-22 06:20:06 --> Helper loaded: url_helper
INFO - 2023-06-22 06:20:06 --> Helper loaded: file_helper
INFO - 2023-06-22 06:20:06 --> Helper loaded: html_helper
INFO - 2023-06-22 06:20:06 --> Helper loaded: text_helper
INFO - 2023-06-22 06:20:06 --> Helper loaded: form_helper
INFO - 2023-06-22 06:20:06 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:20:06 --> Helper loaded: security_helper
INFO - 2023-06-22 06:20:06 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:20:06 --> Database Driver Class Initialized
INFO - 2023-06-22 06:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:20:06 --> Parser Class Initialized
INFO - 2023-06-22 06:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:20:06 --> Pagination Class Initialized
INFO - 2023-06-22 06:20:06 --> Form Validation Class Initialized
INFO - 2023-06-22 06:20:06 --> Controller Class Initialized
INFO - 2023-06-22 06:20:06 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 06:20:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:20:07 --> Config Class Initialized
INFO - 2023-06-22 06:20:07 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:20:07 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:20:07 --> Utf8 Class Initialized
INFO - 2023-06-22 06:20:07 --> URI Class Initialized
INFO - 2023-06-22 06:20:07 --> Router Class Initialized
INFO - 2023-06-22 06:20:07 --> Output Class Initialized
INFO - 2023-06-22 06:20:07 --> Security Class Initialized
DEBUG - 2023-06-22 06:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:20:07 --> Input Class Initialized
INFO - 2023-06-22 06:20:07 --> Language Class Initialized
INFO - 2023-06-22 06:20:07 --> Loader Class Initialized
INFO - 2023-06-22 06:20:07 --> Helper loaded: url_helper
INFO - 2023-06-22 06:20:07 --> Helper loaded: file_helper
INFO - 2023-06-22 06:20:07 --> Helper loaded: html_helper
INFO - 2023-06-22 06:20:07 --> Helper loaded: text_helper
INFO - 2023-06-22 06:20:07 --> Helper loaded: form_helper
INFO - 2023-06-22 06:20:07 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:20:07 --> Helper loaded: security_helper
INFO - 2023-06-22 06:20:07 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:20:07 --> Database Driver Class Initialized
INFO - 2023-06-22 06:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:20:07 --> Parser Class Initialized
INFO - 2023-06-22 06:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:20:07 --> Pagination Class Initialized
INFO - 2023-06-22 06:20:07 --> Form Validation Class Initialized
INFO - 2023-06-22 06:20:07 --> Controller Class Initialized
INFO - 2023-06-22 06:20:07 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 06:20:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:20:07 --> Model Class Initialized
INFO - 2023-06-22 06:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:20:07 --> Final output sent to browser
DEBUG - 2023-06-22 06:20:07 --> Total execution time: 0.0315
ERROR - 2023-06-22 06:20:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:20:23 --> Config Class Initialized
INFO - 2023-06-22 06:20:23 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:20:23 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:20:23 --> Utf8 Class Initialized
INFO - 2023-06-22 06:20:23 --> URI Class Initialized
DEBUG - 2023-06-22 06:20:23 --> No URI present. Default controller set.
INFO - 2023-06-22 06:20:23 --> Router Class Initialized
INFO - 2023-06-22 06:20:23 --> Output Class Initialized
INFO - 2023-06-22 06:20:23 --> Security Class Initialized
DEBUG - 2023-06-22 06:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:20:23 --> Input Class Initialized
INFO - 2023-06-22 06:20:23 --> Language Class Initialized
INFO - 2023-06-22 06:20:23 --> Loader Class Initialized
INFO - 2023-06-22 06:20:23 --> Helper loaded: url_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: file_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: html_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: text_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: form_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: security_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:20:23 --> Database Driver Class Initialized
INFO - 2023-06-22 06:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:20:23 --> Parser Class Initialized
INFO - 2023-06-22 06:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:20:23 --> Pagination Class Initialized
INFO - 2023-06-22 06:20:23 --> Form Validation Class Initialized
INFO - 2023-06-22 06:20:23 --> Controller Class Initialized
INFO - 2023-06-22 06:20:23 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 06:20:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:20:23 --> Config Class Initialized
INFO - 2023-06-22 06:20:23 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:20:23 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:20:23 --> Utf8 Class Initialized
INFO - 2023-06-22 06:20:23 --> URI Class Initialized
INFO - 2023-06-22 06:20:23 --> Router Class Initialized
INFO - 2023-06-22 06:20:23 --> Output Class Initialized
INFO - 2023-06-22 06:20:23 --> Security Class Initialized
DEBUG - 2023-06-22 06:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:20:23 --> Input Class Initialized
INFO - 2023-06-22 06:20:23 --> Language Class Initialized
INFO - 2023-06-22 06:20:23 --> Loader Class Initialized
INFO - 2023-06-22 06:20:23 --> Helper loaded: url_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: file_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: html_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: text_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: form_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: security_helper
INFO - 2023-06-22 06:20:23 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:20:23 --> Database Driver Class Initialized
INFO - 2023-06-22 06:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:20:23 --> Parser Class Initialized
INFO - 2023-06-22 06:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:20:23 --> Pagination Class Initialized
INFO - 2023-06-22 06:20:23 --> Form Validation Class Initialized
INFO - 2023-06-22 06:20:23 --> Controller Class Initialized
INFO - 2023-06-22 06:20:23 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 06:20:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:20:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:20:23 --> Model Class Initialized
INFO - 2023-06-22 06:20:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:20:23 --> Final output sent to browser
DEBUG - 2023-06-22 06:20:23 --> Total execution time: 0.0301
ERROR - 2023-06-22 06:20:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:20:31 --> Config Class Initialized
INFO - 2023-06-22 06:20:31 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:20:31 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:20:31 --> Utf8 Class Initialized
INFO - 2023-06-22 06:20:31 --> URI Class Initialized
INFO - 2023-06-22 06:20:31 --> Router Class Initialized
INFO - 2023-06-22 06:20:31 --> Output Class Initialized
INFO - 2023-06-22 06:20:31 --> Security Class Initialized
DEBUG - 2023-06-22 06:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:20:31 --> Input Class Initialized
INFO - 2023-06-22 06:20:31 --> Language Class Initialized
INFO - 2023-06-22 06:20:31 --> Loader Class Initialized
INFO - 2023-06-22 06:20:31 --> Helper loaded: url_helper
INFO - 2023-06-22 06:20:31 --> Helper loaded: file_helper
INFO - 2023-06-22 06:20:31 --> Helper loaded: html_helper
INFO - 2023-06-22 06:20:31 --> Helper loaded: text_helper
INFO - 2023-06-22 06:20:31 --> Helper loaded: form_helper
INFO - 2023-06-22 06:20:31 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:20:31 --> Helper loaded: security_helper
INFO - 2023-06-22 06:20:31 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:20:31 --> Database Driver Class Initialized
INFO - 2023-06-22 06:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:20:31 --> Parser Class Initialized
INFO - 2023-06-22 06:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:20:31 --> Pagination Class Initialized
INFO - 2023-06-22 06:20:31 --> Form Validation Class Initialized
INFO - 2023-06-22 06:20:31 --> Controller Class Initialized
INFO - 2023-06-22 06:20:31 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:31 --> Model Class Initialized
INFO - 2023-06-22 06:20:31 --> Final output sent to browser
DEBUG - 2023-06-22 06:20:31 --> Total execution time: 0.0197
ERROR - 2023-06-22 06:20:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:20:32 --> Config Class Initialized
INFO - 2023-06-22 06:20:32 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:20:32 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:20:32 --> Utf8 Class Initialized
INFO - 2023-06-22 06:20:32 --> URI Class Initialized
DEBUG - 2023-06-22 06:20:32 --> No URI present. Default controller set.
INFO - 2023-06-22 06:20:32 --> Router Class Initialized
INFO - 2023-06-22 06:20:32 --> Output Class Initialized
INFO - 2023-06-22 06:20:32 --> Security Class Initialized
DEBUG - 2023-06-22 06:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:20:32 --> Input Class Initialized
INFO - 2023-06-22 06:20:32 --> Language Class Initialized
INFO - 2023-06-22 06:20:32 --> Loader Class Initialized
INFO - 2023-06-22 06:20:32 --> Helper loaded: url_helper
INFO - 2023-06-22 06:20:32 --> Helper loaded: file_helper
INFO - 2023-06-22 06:20:32 --> Helper loaded: html_helper
INFO - 2023-06-22 06:20:32 --> Helper loaded: text_helper
INFO - 2023-06-22 06:20:32 --> Helper loaded: form_helper
INFO - 2023-06-22 06:20:32 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:20:32 --> Helper loaded: security_helper
INFO - 2023-06-22 06:20:32 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:20:32 --> Database Driver Class Initialized
INFO - 2023-06-22 06:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:20:32 --> Parser Class Initialized
INFO - 2023-06-22 06:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:20:32 --> Pagination Class Initialized
INFO - 2023-06-22 06:20:32 --> Form Validation Class Initialized
INFO - 2023-06-22 06:20:32 --> Controller Class Initialized
INFO - 2023-06-22 06:20:32 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:32 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:32 --> Model Class Initialized
INFO - 2023-06-22 06:20:32 --> Model Class Initialized
INFO - 2023-06-22 06:20:32 --> Model Class Initialized
INFO - 2023-06-22 06:20:32 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:32 --> Model Class Initialized
INFO - 2023-06-22 06:20:32 --> Model Class Initialized
INFO - 2023-06-22 06:20:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 06:20:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:20:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:20:32 --> Model Class Initialized
INFO - 2023-06-22 06:20:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 06:20:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 06:20:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:20:32 --> Final output sent to browser
DEBUG - 2023-06-22 06:20:32 --> Total execution time: 0.0705
ERROR - 2023-06-22 06:20:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:20:42 --> Config Class Initialized
INFO - 2023-06-22 06:20:42 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:20:42 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:20:42 --> Utf8 Class Initialized
INFO - 2023-06-22 06:20:42 --> URI Class Initialized
INFO - 2023-06-22 06:20:42 --> Router Class Initialized
INFO - 2023-06-22 06:20:42 --> Output Class Initialized
INFO - 2023-06-22 06:20:42 --> Security Class Initialized
DEBUG - 2023-06-22 06:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:20:42 --> Input Class Initialized
INFO - 2023-06-22 06:20:42 --> Language Class Initialized
INFO - 2023-06-22 06:20:42 --> Loader Class Initialized
INFO - 2023-06-22 06:20:42 --> Helper loaded: url_helper
INFO - 2023-06-22 06:20:42 --> Helper loaded: file_helper
INFO - 2023-06-22 06:20:42 --> Helper loaded: html_helper
INFO - 2023-06-22 06:20:42 --> Helper loaded: text_helper
INFO - 2023-06-22 06:20:42 --> Helper loaded: form_helper
INFO - 2023-06-22 06:20:42 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:20:42 --> Helper loaded: security_helper
INFO - 2023-06-22 06:20:42 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:20:42 --> Database Driver Class Initialized
INFO - 2023-06-22 06:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:20:42 --> Parser Class Initialized
INFO - 2023-06-22 06:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:20:42 --> Pagination Class Initialized
INFO - 2023-06-22 06:20:42 --> Form Validation Class Initialized
INFO - 2023-06-22 06:20:42 --> Controller Class Initialized
INFO - 2023-06-22 06:20:42 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:20:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:42 --> Model Class Initialized
DEBUG - 2023-06-22 06:20:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-06-22 06:20:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:20:42 --> Model Class Initialized
INFO - 2023-06-22 06:20:42 --> Model Class Initialized
INFO - 2023-06-22 06:20:42 --> Model Class Initialized
INFO - 2023-06-22 06:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 06:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 06:20:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:20:42 --> Final output sent to browser
DEBUG - 2023-06-22 06:20:42 --> Total execution time: 0.0633
ERROR - 2023-06-22 06:21:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:21:01 --> Config Class Initialized
INFO - 2023-06-22 06:21:01 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:21:01 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:21:01 --> Utf8 Class Initialized
INFO - 2023-06-22 06:21:01 --> URI Class Initialized
INFO - 2023-06-22 06:21:01 --> Router Class Initialized
INFO - 2023-06-22 06:21:01 --> Output Class Initialized
INFO - 2023-06-22 06:21:01 --> Security Class Initialized
DEBUG - 2023-06-22 06:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:21:01 --> Input Class Initialized
INFO - 2023-06-22 06:21:01 --> Language Class Initialized
INFO - 2023-06-22 06:21:01 --> Loader Class Initialized
INFO - 2023-06-22 06:21:01 --> Helper loaded: url_helper
INFO - 2023-06-22 06:21:01 --> Helper loaded: file_helper
INFO - 2023-06-22 06:21:01 --> Helper loaded: html_helper
INFO - 2023-06-22 06:21:01 --> Helper loaded: text_helper
INFO - 2023-06-22 06:21:01 --> Helper loaded: form_helper
INFO - 2023-06-22 06:21:01 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:21:01 --> Helper loaded: security_helper
INFO - 2023-06-22 06:21:01 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:21:01 --> Database Driver Class Initialized
INFO - 2023-06-22 06:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:21:01 --> Parser Class Initialized
INFO - 2023-06-22 06:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:21:01 --> Pagination Class Initialized
INFO - 2023-06-22 06:21:01 --> Form Validation Class Initialized
INFO - 2023-06-22 06:21:01 --> Controller Class Initialized
INFO - 2023-06-22 06:21:01 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:01 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:01 --> Model Class Initialized
INFO - 2023-06-22 06:21:01 --> Final output sent to browser
DEBUG - 2023-06-22 06:21:01 --> Total execution time: 0.0200
ERROR - 2023-06-22 06:21:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:21:02 --> Config Class Initialized
INFO - 2023-06-22 06:21:02 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:21:02 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:21:02 --> Utf8 Class Initialized
INFO - 2023-06-22 06:21:02 --> URI Class Initialized
INFO - 2023-06-22 06:21:02 --> Router Class Initialized
INFO - 2023-06-22 06:21:02 --> Output Class Initialized
INFO - 2023-06-22 06:21:02 --> Security Class Initialized
DEBUG - 2023-06-22 06:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:21:02 --> Input Class Initialized
INFO - 2023-06-22 06:21:02 --> Language Class Initialized
INFO - 2023-06-22 06:21:02 --> Loader Class Initialized
INFO - 2023-06-22 06:21:02 --> Helper loaded: url_helper
INFO - 2023-06-22 06:21:02 --> Helper loaded: file_helper
INFO - 2023-06-22 06:21:02 --> Helper loaded: html_helper
INFO - 2023-06-22 06:21:02 --> Helper loaded: text_helper
INFO - 2023-06-22 06:21:02 --> Helper loaded: form_helper
INFO - 2023-06-22 06:21:02 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:21:02 --> Helper loaded: security_helper
INFO - 2023-06-22 06:21:02 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:21:02 --> Database Driver Class Initialized
INFO - 2023-06-22 06:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:21:02 --> Parser Class Initialized
INFO - 2023-06-22 06:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:21:02 --> Pagination Class Initialized
INFO - 2023-06-22 06:21:02 --> Form Validation Class Initialized
INFO - 2023-06-22 06:21:02 --> Controller Class Initialized
INFO - 2023-06-22 06:21:02 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:02 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:02 --> Model Class Initialized
INFO - 2023-06-22 06:21:02 --> Final output sent to browser
DEBUG - 2023-06-22 06:21:02 --> Total execution time: 0.0175
ERROR - 2023-06-22 06:21:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:21:04 --> Config Class Initialized
INFO - 2023-06-22 06:21:04 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:21:04 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:21:04 --> Utf8 Class Initialized
INFO - 2023-06-22 06:21:04 --> URI Class Initialized
INFO - 2023-06-22 06:21:04 --> Router Class Initialized
INFO - 2023-06-22 06:21:04 --> Output Class Initialized
INFO - 2023-06-22 06:21:04 --> Security Class Initialized
DEBUG - 2023-06-22 06:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:21:04 --> Input Class Initialized
INFO - 2023-06-22 06:21:04 --> Language Class Initialized
INFO - 2023-06-22 06:21:04 --> Loader Class Initialized
INFO - 2023-06-22 06:21:04 --> Helper loaded: url_helper
INFO - 2023-06-22 06:21:04 --> Helper loaded: file_helper
INFO - 2023-06-22 06:21:04 --> Helper loaded: html_helper
INFO - 2023-06-22 06:21:04 --> Helper loaded: text_helper
INFO - 2023-06-22 06:21:04 --> Helper loaded: form_helper
INFO - 2023-06-22 06:21:04 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:21:04 --> Helper loaded: security_helper
INFO - 2023-06-22 06:21:04 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:21:04 --> Database Driver Class Initialized
INFO - 2023-06-22 06:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:21:04 --> Parser Class Initialized
INFO - 2023-06-22 06:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:21:04 --> Pagination Class Initialized
INFO - 2023-06-22 06:21:04 --> Form Validation Class Initialized
INFO - 2023-06-22 06:21:04 --> Controller Class Initialized
INFO - 2023-06-22 06:21:04 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:04 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:04 --> Model Class Initialized
INFO - 2023-06-22 06:21:04 --> Final output sent to browser
DEBUG - 2023-06-22 06:21:04 --> Total execution time: 0.0168
ERROR - 2023-06-22 06:21:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:21:06 --> Config Class Initialized
INFO - 2023-06-22 06:21:06 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:21:06 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:21:06 --> Utf8 Class Initialized
INFO - 2023-06-22 06:21:06 --> URI Class Initialized
INFO - 2023-06-22 06:21:06 --> Router Class Initialized
INFO - 2023-06-22 06:21:06 --> Output Class Initialized
INFO - 2023-06-22 06:21:06 --> Security Class Initialized
DEBUG - 2023-06-22 06:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:21:06 --> Input Class Initialized
INFO - 2023-06-22 06:21:06 --> Language Class Initialized
INFO - 2023-06-22 06:21:06 --> Loader Class Initialized
INFO - 2023-06-22 06:21:06 --> Helper loaded: url_helper
INFO - 2023-06-22 06:21:06 --> Helper loaded: file_helper
INFO - 2023-06-22 06:21:06 --> Helper loaded: html_helper
INFO - 2023-06-22 06:21:06 --> Helper loaded: text_helper
INFO - 2023-06-22 06:21:06 --> Helper loaded: form_helper
INFO - 2023-06-22 06:21:06 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:21:06 --> Helper loaded: security_helper
INFO - 2023-06-22 06:21:06 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:21:06 --> Database Driver Class Initialized
INFO - 2023-06-22 06:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:21:06 --> Parser Class Initialized
INFO - 2023-06-22 06:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:21:06 --> Pagination Class Initialized
INFO - 2023-06-22 06:21:06 --> Form Validation Class Initialized
INFO - 2023-06-22 06:21:06 --> Controller Class Initialized
INFO - 2023-06-22 06:21:06 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:06 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:06 --> Model Class Initialized
INFO - 2023-06-22 06:21:06 --> Final output sent to browser
DEBUG - 2023-06-22 06:21:06 --> Total execution time: 0.0209
ERROR - 2023-06-22 06:21:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:21:24 --> Config Class Initialized
INFO - 2023-06-22 06:21:24 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:21:24 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:21:24 --> Utf8 Class Initialized
INFO - 2023-06-22 06:21:24 --> URI Class Initialized
INFO - 2023-06-22 06:21:24 --> Router Class Initialized
INFO - 2023-06-22 06:21:24 --> Output Class Initialized
INFO - 2023-06-22 06:21:24 --> Security Class Initialized
DEBUG - 2023-06-22 06:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:21:24 --> Input Class Initialized
INFO - 2023-06-22 06:21:24 --> Language Class Initialized
INFO - 2023-06-22 06:21:24 --> Loader Class Initialized
INFO - 2023-06-22 06:21:24 --> Helper loaded: url_helper
INFO - 2023-06-22 06:21:24 --> Helper loaded: file_helper
INFO - 2023-06-22 06:21:24 --> Helper loaded: html_helper
INFO - 2023-06-22 06:21:24 --> Helper loaded: text_helper
INFO - 2023-06-22 06:21:24 --> Helper loaded: form_helper
INFO - 2023-06-22 06:21:24 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:21:24 --> Helper loaded: security_helper
INFO - 2023-06-22 06:21:24 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:21:24 --> Database Driver Class Initialized
INFO - 2023-06-22 06:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:21:24 --> Parser Class Initialized
INFO - 2023-06-22 06:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:21:24 --> Pagination Class Initialized
INFO - 2023-06-22 06:21:24 --> Form Validation Class Initialized
INFO - 2023-06-22 06:21:24 --> Controller Class Initialized
INFO - 2023-06-22 06:21:24 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:24 --> Model Class Initialized
INFO - 2023-06-22 06:21:24 --> Model Class Initialized
INFO - 2023-06-22 06:21:24 --> Final output sent to browser
DEBUG - 2023-06-22 06:21:24 --> Total execution time: 0.0224
ERROR - 2023-06-22 06:21:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:21:43 --> Config Class Initialized
INFO - 2023-06-22 06:21:43 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:21:43 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:21:43 --> Utf8 Class Initialized
INFO - 2023-06-22 06:21:43 --> URI Class Initialized
DEBUG - 2023-06-22 06:21:43 --> No URI present. Default controller set.
INFO - 2023-06-22 06:21:43 --> Router Class Initialized
INFO - 2023-06-22 06:21:43 --> Output Class Initialized
INFO - 2023-06-22 06:21:43 --> Security Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:21:43 --> Input Class Initialized
INFO - 2023-06-22 06:21:43 --> Language Class Initialized
INFO - 2023-06-22 06:21:43 --> Loader Class Initialized
INFO - 2023-06-22 06:21:43 --> Helper loaded: url_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: file_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: html_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: text_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: form_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: security_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:21:43 --> Database Driver Class Initialized
INFO - 2023-06-22 06:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:21:43 --> Parser Class Initialized
INFO - 2023-06-22 06:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:21:43 --> Pagination Class Initialized
INFO - 2023-06-22 06:21:43 --> Form Validation Class Initialized
INFO - 2023-06-22 06:21:43 --> Controller Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 06:21:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:21:43 --> Final output sent to browser
DEBUG - 2023-06-22 06:21:43 --> Total execution time: 0.0670
ERROR - 2023-06-22 06:21:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:21:43 --> Config Class Initialized
INFO - 2023-06-22 06:21:43 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:21:43 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:21:43 --> Utf8 Class Initialized
INFO - 2023-06-22 06:21:43 --> URI Class Initialized
INFO - 2023-06-22 06:21:43 --> Router Class Initialized
INFO - 2023-06-22 06:21:43 --> Output Class Initialized
INFO - 2023-06-22 06:21:43 --> Security Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:21:43 --> Input Class Initialized
INFO - 2023-06-22 06:21:43 --> Language Class Initialized
INFO - 2023-06-22 06:21:43 --> Loader Class Initialized
INFO - 2023-06-22 06:21:43 --> Helper loaded: url_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: file_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: html_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: text_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: form_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: security_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:21:43 --> Database Driver Class Initialized
INFO - 2023-06-22 06:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:21:43 --> Parser Class Initialized
INFO - 2023-06-22 06:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:21:43 --> Pagination Class Initialized
INFO - 2023-06-22 06:21:43 --> Form Validation Class Initialized
INFO - 2023-06-22 06:21:43 --> Controller Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 06:21:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:21:43 --> Final output sent to browser
DEBUG - 2023-06-22 06:21:43 --> Total execution time: 0.0273
ERROR - 2023-06-22 06:21:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:21:43 --> Config Class Initialized
INFO - 2023-06-22 06:21:43 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:21:43 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:21:43 --> Utf8 Class Initialized
INFO - 2023-06-22 06:21:43 --> URI Class Initialized
INFO - 2023-06-22 06:21:43 --> Router Class Initialized
INFO - 2023-06-22 06:21:43 --> Output Class Initialized
INFO - 2023-06-22 06:21:43 --> Security Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:21:43 --> Input Class Initialized
INFO - 2023-06-22 06:21:43 --> Language Class Initialized
INFO - 2023-06-22 06:21:43 --> Loader Class Initialized
INFO - 2023-06-22 06:21:43 --> Helper loaded: url_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: file_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: html_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: text_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: form_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: security_helper
INFO - 2023-06-22 06:21:43 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:21:43 --> Database Driver Class Initialized
INFO - 2023-06-22 06:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:21:43 --> Parser Class Initialized
INFO - 2023-06-22 06:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:21:43 --> Pagination Class Initialized
INFO - 2023-06-22 06:21:43 --> Form Validation Class Initialized
INFO - 2023-06-22 06:21:43 --> Controller Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
DEBUG - 2023-06-22 06:21:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 06:21:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:21:43 --> Model Class Initialized
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 06:21:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:21:43 --> Final output sent to browser
DEBUG - 2023-06-22 06:21:43 --> Total execution time: 0.0607
ERROR - 2023-06-22 06:45:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:45:59 --> Config Class Initialized
INFO - 2023-06-22 06:45:59 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:45:59 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:45:59 --> Utf8 Class Initialized
INFO - 2023-06-22 06:45:59 --> URI Class Initialized
DEBUG - 2023-06-22 06:45:59 --> No URI present. Default controller set.
INFO - 2023-06-22 06:45:59 --> Router Class Initialized
INFO - 2023-06-22 06:45:59 --> Output Class Initialized
INFO - 2023-06-22 06:45:59 --> Security Class Initialized
DEBUG - 2023-06-22 06:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:45:59 --> Input Class Initialized
INFO - 2023-06-22 06:45:59 --> Language Class Initialized
INFO - 2023-06-22 06:45:59 --> Loader Class Initialized
INFO - 2023-06-22 06:45:59 --> Helper loaded: url_helper
INFO - 2023-06-22 06:45:59 --> Helper loaded: file_helper
INFO - 2023-06-22 06:45:59 --> Helper loaded: html_helper
INFO - 2023-06-22 06:45:59 --> Helper loaded: text_helper
INFO - 2023-06-22 06:45:59 --> Helper loaded: form_helper
INFO - 2023-06-22 06:45:59 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:45:59 --> Helper loaded: security_helper
INFO - 2023-06-22 06:45:59 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:45:59 --> Database Driver Class Initialized
INFO - 2023-06-22 06:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:45:59 --> Parser Class Initialized
INFO - 2023-06-22 06:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:45:59 --> Pagination Class Initialized
INFO - 2023-06-22 06:45:59 --> Form Validation Class Initialized
INFO - 2023-06-22 06:45:59 --> Controller Class Initialized
INFO - 2023-06-22 06:45:59 --> Model Class Initialized
DEBUG - 2023-06-22 06:45:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 06:56:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:56:53 --> Config Class Initialized
INFO - 2023-06-22 06:56:53 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:56:53 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:56:53 --> Utf8 Class Initialized
INFO - 2023-06-22 06:56:53 --> URI Class Initialized
DEBUG - 2023-06-22 06:56:53 --> No URI present. Default controller set.
INFO - 2023-06-22 06:56:53 --> Router Class Initialized
INFO - 2023-06-22 06:56:53 --> Output Class Initialized
INFO - 2023-06-22 06:56:53 --> Security Class Initialized
DEBUG - 2023-06-22 06:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:56:53 --> Input Class Initialized
INFO - 2023-06-22 06:56:53 --> Language Class Initialized
INFO - 2023-06-22 06:56:53 --> Loader Class Initialized
INFO - 2023-06-22 06:56:53 --> Helper loaded: url_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: file_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: html_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: text_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: form_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: security_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:56:53 --> Database Driver Class Initialized
INFO - 2023-06-22 06:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:56:53 --> Parser Class Initialized
INFO - 2023-06-22 06:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:56:53 --> Pagination Class Initialized
INFO - 2023-06-22 06:56:53 --> Form Validation Class Initialized
INFO - 2023-06-22 06:56:53 --> Controller Class Initialized
INFO - 2023-06-22 06:56:53 --> Model Class Initialized
DEBUG - 2023-06-22 06:56:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 06:56:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:56:53 --> Config Class Initialized
INFO - 2023-06-22 06:56:53 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:56:53 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:56:53 --> Utf8 Class Initialized
INFO - 2023-06-22 06:56:53 --> URI Class Initialized
INFO - 2023-06-22 06:56:53 --> Router Class Initialized
INFO - 2023-06-22 06:56:53 --> Output Class Initialized
INFO - 2023-06-22 06:56:53 --> Security Class Initialized
DEBUG - 2023-06-22 06:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:56:53 --> Input Class Initialized
INFO - 2023-06-22 06:56:53 --> Language Class Initialized
INFO - 2023-06-22 06:56:53 --> Loader Class Initialized
INFO - 2023-06-22 06:56:53 --> Helper loaded: url_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: file_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: html_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: text_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: form_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: security_helper
INFO - 2023-06-22 06:56:53 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:56:53 --> Database Driver Class Initialized
INFO - 2023-06-22 06:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:56:53 --> Parser Class Initialized
INFO - 2023-06-22 06:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:56:53 --> Pagination Class Initialized
INFO - 2023-06-22 06:56:53 --> Form Validation Class Initialized
INFO - 2023-06-22 06:56:53 --> Controller Class Initialized
INFO - 2023-06-22 06:56:53 --> Model Class Initialized
DEBUG - 2023-06-22 06:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 06:56:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:56:53 --> Model Class Initialized
INFO - 2023-06-22 06:56:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:56:53 --> Final output sent to browser
DEBUG - 2023-06-22 06:56:53 --> Total execution time: 0.0303
ERROR - 2023-06-22 06:57:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:57:06 --> Config Class Initialized
INFO - 2023-06-22 06:57:06 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:57:06 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:57:06 --> Utf8 Class Initialized
INFO - 2023-06-22 06:57:06 --> URI Class Initialized
DEBUG - 2023-06-22 06:57:06 --> No URI present. Default controller set.
INFO - 2023-06-22 06:57:06 --> Router Class Initialized
INFO - 2023-06-22 06:57:06 --> Output Class Initialized
INFO - 2023-06-22 06:57:06 --> Security Class Initialized
DEBUG - 2023-06-22 06:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:57:06 --> Input Class Initialized
INFO - 2023-06-22 06:57:06 --> Language Class Initialized
INFO - 2023-06-22 06:57:06 --> Loader Class Initialized
INFO - 2023-06-22 06:57:06 --> Helper loaded: url_helper
INFO - 2023-06-22 06:57:06 --> Helper loaded: file_helper
INFO - 2023-06-22 06:57:06 --> Helper loaded: html_helper
INFO - 2023-06-22 06:57:06 --> Helper loaded: text_helper
INFO - 2023-06-22 06:57:06 --> Helper loaded: form_helper
INFO - 2023-06-22 06:57:06 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:57:06 --> Helper loaded: security_helper
INFO - 2023-06-22 06:57:06 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:57:06 --> Database Driver Class Initialized
INFO - 2023-06-22 06:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:57:06 --> Parser Class Initialized
INFO - 2023-06-22 06:57:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:57:06 --> Pagination Class Initialized
INFO - 2023-06-22 06:57:06 --> Form Validation Class Initialized
INFO - 2023-06-22 06:57:06 --> Controller Class Initialized
INFO - 2023-06-22 06:57:06 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 06:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:57:07 --> Config Class Initialized
INFO - 2023-06-22 06:57:07 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:57:07 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:57:07 --> Utf8 Class Initialized
INFO - 2023-06-22 06:57:07 --> URI Class Initialized
INFO - 2023-06-22 06:57:07 --> Router Class Initialized
INFO - 2023-06-22 06:57:07 --> Output Class Initialized
INFO - 2023-06-22 06:57:07 --> Security Class Initialized
DEBUG - 2023-06-22 06:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:57:07 --> Input Class Initialized
INFO - 2023-06-22 06:57:07 --> Language Class Initialized
INFO - 2023-06-22 06:57:07 --> Loader Class Initialized
INFO - 2023-06-22 06:57:07 --> Helper loaded: url_helper
INFO - 2023-06-22 06:57:07 --> Helper loaded: file_helper
INFO - 2023-06-22 06:57:07 --> Helper loaded: html_helper
INFO - 2023-06-22 06:57:07 --> Helper loaded: text_helper
INFO - 2023-06-22 06:57:07 --> Helper loaded: form_helper
INFO - 2023-06-22 06:57:07 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:57:07 --> Helper loaded: security_helper
INFO - 2023-06-22 06:57:07 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:57:07 --> Database Driver Class Initialized
INFO - 2023-06-22 06:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:57:07 --> Parser Class Initialized
INFO - 2023-06-22 06:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:57:07 --> Pagination Class Initialized
INFO - 2023-06-22 06:57:07 --> Form Validation Class Initialized
INFO - 2023-06-22 06:57:07 --> Controller Class Initialized
INFO - 2023-06-22 06:57:07 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 06:57:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:57:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:57:07 --> Model Class Initialized
INFO - 2023-06-22 06:57:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:57:07 --> Final output sent to browser
DEBUG - 2023-06-22 06:57:07 --> Total execution time: 0.0272
ERROR - 2023-06-22 06:57:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:57:14 --> Config Class Initialized
INFO - 2023-06-22 06:57:14 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:57:14 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:57:14 --> Utf8 Class Initialized
INFO - 2023-06-22 06:57:14 --> URI Class Initialized
INFO - 2023-06-22 06:57:14 --> Router Class Initialized
INFO - 2023-06-22 06:57:14 --> Output Class Initialized
INFO - 2023-06-22 06:57:14 --> Security Class Initialized
DEBUG - 2023-06-22 06:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:57:14 --> Input Class Initialized
INFO - 2023-06-22 06:57:14 --> Language Class Initialized
INFO - 2023-06-22 06:57:14 --> Loader Class Initialized
INFO - 2023-06-22 06:57:14 --> Helper loaded: url_helper
INFO - 2023-06-22 06:57:14 --> Helper loaded: file_helper
INFO - 2023-06-22 06:57:14 --> Helper loaded: html_helper
INFO - 2023-06-22 06:57:14 --> Helper loaded: text_helper
INFO - 2023-06-22 06:57:14 --> Helper loaded: form_helper
INFO - 2023-06-22 06:57:14 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:57:14 --> Helper loaded: security_helper
INFO - 2023-06-22 06:57:14 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:57:14 --> Database Driver Class Initialized
INFO - 2023-06-22 06:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:57:14 --> Parser Class Initialized
INFO - 2023-06-22 06:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:57:14 --> Pagination Class Initialized
INFO - 2023-06-22 06:57:14 --> Form Validation Class Initialized
INFO - 2023-06-22 06:57:14 --> Controller Class Initialized
INFO - 2023-06-22 06:57:14 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:14 --> Model Class Initialized
INFO - 2023-06-22 06:57:14 --> Final output sent to browser
DEBUG - 2023-06-22 06:57:14 --> Total execution time: 0.0174
ERROR - 2023-06-22 06:57:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:57:15 --> Config Class Initialized
INFO - 2023-06-22 06:57:15 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:57:15 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:57:15 --> Utf8 Class Initialized
INFO - 2023-06-22 06:57:15 --> URI Class Initialized
DEBUG - 2023-06-22 06:57:15 --> No URI present. Default controller set.
INFO - 2023-06-22 06:57:15 --> Router Class Initialized
INFO - 2023-06-22 06:57:15 --> Output Class Initialized
INFO - 2023-06-22 06:57:15 --> Security Class Initialized
DEBUG - 2023-06-22 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:57:15 --> Input Class Initialized
INFO - 2023-06-22 06:57:15 --> Language Class Initialized
INFO - 2023-06-22 06:57:15 --> Loader Class Initialized
INFO - 2023-06-22 06:57:15 --> Helper loaded: url_helper
INFO - 2023-06-22 06:57:15 --> Helper loaded: file_helper
INFO - 2023-06-22 06:57:15 --> Helper loaded: html_helper
INFO - 2023-06-22 06:57:15 --> Helper loaded: text_helper
INFO - 2023-06-22 06:57:15 --> Helper loaded: form_helper
INFO - 2023-06-22 06:57:15 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:57:15 --> Helper loaded: security_helper
INFO - 2023-06-22 06:57:15 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:57:15 --> Database Driver Class Initialized
INFO - 2023-06-22 06:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:57:15 --> Parser Class Initialized
INFO - 2023-06-22 06:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:57:15 --> Pagination Class Initialized
INFO - 2023-06-22 06:57:15 --> Form Validation Class Initialized
INFO - 2023-06-22 06:57:15 --> Controller Class Initialized
INFO - 2023-06-22 06:57:15 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:15 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:15 --> Model Class Initialized
INFO - 2023-06-22 06:57:15 --> Model Class Initialized
INFO - 2023-06-22 06:57:15 --> Model Class Initialized
INFO - 2023-06-22 06:57:15 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:15 --> Model Class Initialized
INFO - 2023-06-22 06:57:15 --> Model Class Initialized
INFO - 2023-06-22 06:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 06:57:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:57:15 --> Model Class Initialized
INFO - 2023-06-22 06:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 06:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 06:57:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:57:15 --> Final output sent to browser
DEBUG - 2023-06-22 06:57:15 --> Total execution time: 0.0753
ERROR - 2023-06-22 06:57:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:57:38 --> Config Class Initialized
INFO - 2023-06-22 06:57:38 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:57:38 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:57:38 --> Utf8 Class Initialized
INFO - 2023-06-22 06:57:38 --> URI Class Initialized
INFO - 2023-06-22 06:57:38 --> Router Class Initialized
INFO - 2023-06-22 06:57:38 --> Output Class Initialized
INFO - 2023-06-22 06:57:38 --> Security Class Initialized
DEBUG - 2023-06-22 06:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:57:38 --> Input Class Initialized
INFO - 2023-06-22 06:57:38 --> Language Class Initialized
INFO - 2023-06-22 06:57:38 --> Loader Class Initialized
INFO - 2023-06-22 06:57:38 --> Helper loaded: url_helper
INFO - 2023-06-22 06:57:38 --> Helper loaded: file_helper
INFO - 2023-06-22 06:57:38 --> Helper loaded: html_helper
INFO - 2023-06-22 06:57:38 --> Helper loaded: text_helper
INFO - 2023-06-22 06:57:38 --> Helper loaded: form_helper
INFO - 2023-06-22 06:57:38 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:57:38 --> Helper loaded: security_helper
INFO - 2023-06-22 06:57:38 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:57:38 --> Database Driver Class Initialized
INFO - 2023-06-22 06:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:57:38 --> Parser Class Initialized
INFO - 2023-06-22 06:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:57:38 --> Pagination Class Initialized
INFO - 2023-06-22 06:57:38 --> Form Validation Class Initialized
INFO - 2023-06-22 06:57:38 --> Controller Class Initialized
INFO - 2023-06-22 06:57:38 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:38 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:38 --> Model Class Initialized
INFO - 2023-06-22 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-22 06:57:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:57:38 --> Model Class Initialized
INFO - 2023-06-22 06:57:38 --> Model Class Initialized
INFO - 2023-06-22 06:57:38 --> Model Class Initialized
INFO - 2023-06-22 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 06:57:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:57:38 --> Final output sent to browser
DEBUG - 2023-06-22 06:57:38 --> Total execution time: 0.0711
ERROR - 2023-06-22 06:57:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:57:39 --> Config Class Initialized
INFO - 2023-06-22 06:57:39 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:57:39 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:57:39 --> Utf8 Class Initialized
INFO - 2023-06-22 06:57:39 --> URI Class Initialized
INFO - 2023-06-22 06:57:39 --> Router Class Initialized
INFO - 2023-06-22 06:57:39 --> Output Class Initialized
INFO - 2023-06-22 06:57:39 --> Security Class Initialized
DEBUG - 2023-06-22 06:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:57:39 --> Input Class Initialized
INFO - 2023-06-22 06:57:39 --> Language Class Initialized
INFO - 2023-06-22 06:57:39 --> Loader Class Initialized
INFO - 2023-06-22 06:57:39 --> Helper loaded: url_helper
INFO - 2023-06-22 06:57:39 --> Helper loaded: file_helper
INFO - 2023-06-22 06:57:39 --> Helper loaded: html_helper
INFO - 2023-06-22 06:57:39 --> Helper loaded: text_helper
INFO - 2023-06-22 06:57:39 --> Helper loaded: form_helper
INFO - 2023-06-22 06:57:39 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:57:39 --> Helper loaded: security_helper
INFO - 2023-06-22 06:57:39 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:57:39 --> Database Driver Class Initialized
INFO - 2023-06-22 06:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:57:39 --> Parser Class Initialized
INFO - 2023-06-22 06:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:57:39 --> Pagination Class Initialized
INFO - 2023-06-22 06:57:39 --> Form Validation Class Initialized
INFO - 2023-06-22 06:57:39 --> Controller Class Initialized
INFO - 2023-06-22 06:57:39 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:39 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:39 --> Model Class Initialized
INFO - 2023-06-22 06:57:39 --> Final output sent to browser
DEBUG - 2023-06-22 06:57:39 --> Total execution time: 0.0506
ERROR - 2023-06-22 06:57:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:57:49 --> Config Class Initialized
INFO - 2023-06-22 06:57:49 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:57:49 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:57:49 --> Utf8 Class Initialized
INFO - 2023-06-22 06:57:49 --> URI Class Initialized
INFO - 2023-06-22 06:57:49 --> Router Class Initialized
INFO - 2023-06-22 06:57:49 --> Output Class Initialized
INFO - 2023-06-22 06:57:49 --> Security Class Initialized
DEBUG - 2023-06-22 06:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:57:49 --> Input Class Initialized
INFO - 2023-06-22 06:57:49 --> Language Class Initialized
INFO - 2023-06-22 06:57:49 --> Loader Class Initialized
INFO - 2023-06-22 06:57:49 --> Helper loaded: url_helper
INFO - 2023-06-22 06:57:49 --> Helper loaded: file_helper
INFO - 2023-06-22 06:57:49 --> Helper loaded: html_helper
INFO - 2023-06-22 06:57:49 --> Helper loaded: text_helper
INFO - 2023-06-22 06:57:49 --> Helper loaded: form_helper
INFO - 2023-06-22 06:57:49 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:57:49 --> Helper loaded: security_helper
INFO - 2023-06-22 06:57:49 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:57:49 --> Database Driver Class Initialized
INFO - 2023-06-22 06:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:57:49 --> Parser Class Initialized
INFO - 2023-06-22 06:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:57:49 --> Pagination Class Initialized
INFO - 2023-06-22 06:57:49 --> Form Validation Class Initialized
INFO - 2023-06-22 06:57:49 --> Controller Class Initialized
INFO - 2023-06-22 06:57:49 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:49 --> Model Class Initialized
INFO - 2023-06-22 06:57:49 --> Final output sent to browser
DEBUG - 2023-06-22 06:57:49 --> Total execution time: 0.0155
ERROR - 2023-06-22 06:57:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:57:50 --> Config Class Initialized
INFO - 2023-06-22 06:57:50 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:57:50 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:57:50 --> Utf8 Class Initialized
INFO - 2023-06-22 06:57:50 --> URI Class Initialized
DEBUG - 2023-06-22 06:57:50 --> No URI present. Default controller set.
INFO - 2023-06-22 06:57:50 --> Router Class Initialized
INFO - 2023-06-22 06:57:50 --> Output Class Initialized
INFO - 2023-06-22 06:57:50 --> Security Class Initialized
DEBUG - 2023-06-22 06:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:57:50 --> Input Class Initialized
INFO - 2023-06-22 06:57:50 --> Language Class Initialized
INFO - 2023-06-22 06:57:50 --> Loader Class Initialized
INFO - 2023-06-22 06:57:50 --> Helper loaded: url_helper
INFO - 2023-06-22 06:57:50 --> Helper loaded: file_helper
INFO - 2023-06-22 06:57:50 --> Helper loaded: html_helper
INFO - 2023-06-22 06:57:50 --> Helper loaded: text_helper
INFO - 2023-06-22 06:57:50 --> Helper loaded: form_helper
INFO - 2023-06-22 06:57:50 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:57:50 --> Helper loaded: security_helper
INFO - 2023-06-22 06:57:50 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:57:50 --> Database Driver Class Initialized
INFO - 2023-06-22 06:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:57:50 --> Parser Class Initialized
INFO - 2023-06-22 06:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:57:50 --> Pagination Class Initialized
INFO - 2023-06-22 06:57:50 --> Form Validation Class Initialized
INFO - 2023-06-22 06:57:50 --> Controller Class Initialized
INFO - 2023-06-22 06:57:50 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:50 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:50 --> Model Class Initialized
INFO - 2023-06-22 06:57:50 --> Model Class Initialized
INFO - 2023-06-22 06:57:50 --> Model Class Initialized
INFO - 2023-06-22 06:57:50 --> Model Class Initialized
DEBUG - 2023-06-22 06:57:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:50 --> Model Class Initialized
INFO - 2023-06-22 06:57:50 --> Model Class Initialized
INFO - 2023-06-22 06:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 06:57:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:57:50 --> Model Class Initialized
INFO - 2023-06-22 06:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 06:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 06:57:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:57:50 --> Final output sent to browser
DEBUG - 2023-06-22 06:57:50 --> Total execution time: 0.1564
ERROR - 2023-06-22 06:57:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:57:51 --> Config Class Initialized
INFO - 2023-06-22 06:57:51 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:57:51 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:57:51 --> Utf8 Class Initialized
INFO - 2023-06-22 06:57:51 --> URI Class Initialized
INFO - 2023-06-22 06:57:51 --> Router Class Initialized
INFO - 2023-06-22 06:57:51 --> Output Class Initialized
INFO - 2023-06-22 06:57:51 --> Security Class Initialized
DEBUG - 2023-06-22 06:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:57:51 --> Input Class Initialized
INFO - 2023-06-22 06:57:51 --> Language Class Initialized
INFO - 2023-06-22 06:57:51 --> Loader Class Initialized
INFO - 2023-06-22 06:57:51 --> Helper loaded: url_helper
INFO - 2023-06-22 06:57:51 --> Helper loaded: file_helper
INFO - 2023-06-22 06:57:51 --> Helper loaded: html_helper
INFO - 2023-06-22 06:57:51 --> Helper loaded: text_helper
INFO - 2023-06-22 06:57:51 --> Helper loaded: form_helper
INFO - 2023-06-22 06:57:51 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:57:51 --> Helper loaded: security_helper
INFO - 2023-06-22 06:57:51 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:57:51 --> Database Driver Class Initialized
INFO - 2023-06-22 06:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:57:51 --> Parser Class Initialized
INFO - 2023-06-22 06:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:57:51 --> Pagination Class Initialized
INFO - 2023-06-22 06:57:51 --> Form Validation Class Initialized
INFO - 2023-06-22 06:57:51 --> Controller Class Initialized
DEBUG - 2023-06-22 06:57:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:57:51 --> Model Class Initialized
INFO - 2023-06-22 06:57:51 --> Final output sent to browser
DEBUG - 2023-06-22 06:57:51 --> Total execution time: 0.0153
ERROR - 2023-06-22 06:58:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:58:04 --> Config Class Initialized
INFO - 2023-06-22 06:58:04 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:58:04 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:58:04 --> Utf8 Class Initialized
INFO - 2023-06-22 06:58:04 --> URI Class Initialized
INFO - 2023-06-22 06:58:04 --> Router Class Initialized
INFO - 2023-06-22 06:58:04 --> Output Class Initialized
INFO - 2023-06-22 06:58:04 --> Security Class Initialized
DEBUG - 2023-06-22 06:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:58:04 --> Input Class Initialized
INFO - 2023-06-22 06:58:04 --> Language Class Initialized
INFO - 2023-06-22 06:58:04 --> Loader Class Initialized
INFO - 2023-06-22 06:58:04 --> Helper loaded: url_helper
INFO - 2023-06-22 06:58:04 --> Helper loaded: file_helper
INFO - 2023-06-22 06:58:04 --> Helper loaded: html_helper
INFO - 2023-06-22 06:58:04 --> Helper loaded: text_helper
INFO - 2023-06-22 06:58:04 --> Helper loaded: form_helper
INFO - 2023-06-22 06:58:04 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:58:04 --> Helper loaded: security_helper
INFO - 2023-06-22 06:58:04 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:58:04 --> Database Driver Class Initialized
INFO - 2023-06-22 06:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:58:04 --> Parser Class Initialized
INFO - 2023-06-22 06:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:58:04 --> Pagination Class Initialized
INFO - 2023-06-22 06:58:04 --> Form Validation Class Initialized
INFO - 2023-06-22 06:58:04 --> Controller Class Initialized
INFO - 2023-06-22 06:58:04 --> Model Class Initialized
DEBUG - 2023-06-22 06:58:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:58:04 --> Model Class Initialized
DEBUG - 2023-06-22 06:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:58:04 --> Model Class Initialized
INFO - 2023-06-22 06:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-22 06:58:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:58:04 --> Model Class Initialized
INFO - 2023-06-22 06:58:04 --> Model Class Initialized
INFO - 2023-06-22 06:58:04 --> Model Class Initialized
INFO - 2023-06-22 06:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 06:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 06:58:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:58:04 --> Final output sent to browser
DEBUG - 2023-06-22 06:58:04 --> Total execution time: 0.1256
ERROR - 2023-06-22 06:58:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:58:05 --> Config Class Initialized
INFO - 2023-06-22 06:58:05 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:58:05 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:58:05 --> Utf8 Class Initialized
INFO - 2023-06-22 06:58:05 --> URI Class Initialized
INFO - 2023-06-22 06:58:05 --> Router Class Initialized
INFO - 2023-06-22 06:58:05 --> Output Class Initialized
INFO - 2023-06-22 06:58:05 --> Security Class Initialized
DEBUG - 2023-06-22 06:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:58:05 --> Input Class Initialized
INFO - 2023-06-22 06:58:05 --> Language Class Initialized
INFO - 2023-06-22 06:58:05 --> Loader Class Initialized
INFO - 2023-06-22 06:58:05 --> Helper loaded: url_helper
INFO - 2023-06-22 06:58:05 --> Helper loaded: file_helper
INFO - 2023-06-22 06:58:05 --> Helper loaded: html_helper
INFO - 2023-06-22 06:58:05 --> Helper loaded: text_helper
INFO - 2023-06-22 06:58:05 --> Helper loaded: form_helper
INFO - 2023-06-22 06:58:05 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:58:05 --> Helper loaded: security_helper
INFO - 2023-06-22 06:58:05 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:58:05 --> Database Driver Class Initialized
INFO - 2023-06-22 06:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:58:05 --> Parser Class Initialized
INFO - 2023-06-22 06:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:58:05 --> Pagination Class Initialized
INFO - 2023-06-22 06:58:05 --> Form Validation Class Initialized
INFO - 2023-06-22 06:58:05 --> Controller Class Initialized
INFO - 2023-06-22 06:58:05 --> Model Class Initialized
DEBUG - 2023-06-22 06:58:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:58:05 --> Model Class Initialized
DEBUG - 2023-06-22 06:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:58:05 --> Model Class Initialized
INFO - 2023-06-22 06:58:05 --> Final output sent to browser
DEBUG - 2023-06-22 06:58:05 --> Total execution time: 0.0568
ERROR - 2023-06-22 06:58:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 06:58:10 --> Config Class Initialized
INFO - 2023-06-22 06:58:10 --> Hooks Class Initialized
DEBUG - 2023-06-22 06:58:10 --> UTF-8 Support Enabled
INFO - 2023-06-22 06:58:10 --> Utf8 Class Initialized
INFO - 2023-06-22 06:58:10 --> URI Class Initialized
DEBUG - 2023-06-22 06:58:10 --> No URI present. Default controller set.
INFO - 2023-06-22 06:58:10 --> Router Class Initialized
INFO - 2023-06-22 06:58:10 --> Output Class Initialized
INFO - 2023-06-22 06:58:10 --> Security Class Initialized
DEBUG - 2023-06-22 06:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 06:58:10 --> Input Class Initialized
INFO - 2023-06-22 06:58:10 --> Language Class Initialized
INFO - 2023-06-22 06:58:10 --> Loader Class Initialized
INFO - 2023-06-22 06:58:10 --> Helper loaded: url_helper
INFO - 2023-06-22 06:58:10 --> Helper loaded: file_helper
INFO - 2023-06-22 06:58:10 --> Helper loaded: html_helper
INFO - 2023-06-22 06:58:10 --> Helper loaded: text_helper
INFO - 2023-06-22 06:58:10 --> Helper loaded: form_helper
INFO - 2023-06-22 06:58:10 --> Helper loaded: lang_helper
INFO - 2023-06-22 06:58:10 --> Helper loaded: security_helper
INFO - 2023-06-22 06:58:10 --> Helper loaded: cookie_helper
INFO - 2023-06-22 06:58:10 --> Database Driver Class Initialized
INFO - 2023-06-22 06:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 06:58:10 --> Parser Class Initialized
INFO - 2023-06-22 06:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 06:58:10 --> Pagination Class Initialized
INFO - 2023-06-22 06:58:10 --> Form Validation Class Initialized
INFO - 2023-06-22 06:58:10 --> Controller Class Initialized
INFO - 2023-06-22 06:58:10 --> Model Class Initialized
DEBUG - 2023-06-22 06:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:58:10 --> Model Class Initialized
DEBUG - 2023-06-22 06:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:58:10 --> Model Class Initialized
INFO - 2023-06-22 06:58:10 --> Model Class Initialized
INFO - 2023-06-22 06:58:10 --> Model Class Initialized
INFO - 2023-06-22 06:58:10 --> Model Class Initialized
DEBUG - 2023-06-22 06:58:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 06:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:58:10 --> Model Class Initialized
INFO - 2023-06-22 06:58:10 --> Model Class Initialized
INFO - 2023-06-22 06:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 06:58:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 06:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 06:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 06:58:10 --> Model Class Initialized
INFO - 2023-06-22 06:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 06:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 06:58:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 06:58:10 --> Final output sent to browser
DEBUG - 2023-06-22 06:58:10 --> Total execution time: 0.1569
ERROR - 2023-06-22 07:04:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:04:22 --> Config Class Initialized
INFO - 2023-06-22 07:04:22 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:04:22 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:04:22 --> Utf8 Class Initialized
INFO - 2023-06-22 07:04:22 --> URI Class Initialized
DEBUG - 2023-06-22 07:04:22 --> No URI present. Default controller set.
INFO - 2023-06-22 07:04:22 --> Router Class Initialized
INFO - 2023-06-22 07:04:22 --> Output Class Initialized
INFO - 2023-06-22 07:04:22 --> Security Class Initialized
DEBUG - 2023-06-22 07:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:04:22 --> Input Class Initialized
INFO - 2023-06-22 07:04:22 --> Language Class Initialized
INFO - 2023-06-22 07:04:22 --> Loader Class Initialized
INFO - 2023-06-22 07:04:22 --> Helper loaded: url_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: file_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: html_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: text_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: form_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: security_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:04:22 --> Database Driver Class Initialized
INFO - 2023-06-22 07:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:04:22 --> Parser Class Initialized
INFO - 2023-06-22 07:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:04:22 --> Pagination Class Initialized
INFO - 2023-06-22 07:04:22 --> Form Validation Class Initialized
INFO - 2023-06-22 07:04:22 --> Controller Class Initialized
INFO - 2023-06-22 07:04:22 --> Model Class Initialized
DEBUG - 2023-06-22 07:04:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 07:04:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:04:22 --> Config Class Initialized
INFO - 2023-06-22 07:04:22 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:04:22 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:04:22 --> Utf8 Class Initialized
INFO - 2023-06-22 07:04:22 --> URI Class Initialized
INFO - 2023-06-22 07:04:22 --> Router Class Initialized
INFO - 2023-06-22 07:04:22 --> Output Class Initialized
INFO - 2023-06-22 07:04:22 --> Security Class Initialized
DEBUG - 2023-06-22 07:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:04:22 --> Input Class Initialized
INFO - 2023-06-22 07:04:22 --> Language Class Initialized
INFO - 2023-06-22 07:04:22 --> Loader Class Initialized
INFO - 2023-06-22 07:04:22 --> Helper loaded: url_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: file_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: html_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: text_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: form_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: security_helper
INFO - 2023-06-22 07:04:22 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:04:22 --> Database Driver Class Initialized
INFO - 2023-06-22 07:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:04:22 --> Parser Class Initialized
INFO - 2023-06-22 07:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:04:22 --> Pagination Class Initialized
INFO - 2023-06-22 07:04:22 --> Form Validation Class Initialized
INFO - 2023-06-22 07:04:22 --> Controller Class Initialized
INFO - 2023-06-22 07:04:22 --> Model Class Initialized
DEBUG - 2023-06-22 07:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 07:04:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:04:22 --> Model Class Initialized
INFO - 2023-06-22 07:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:04:22 --> Final output sent to browser
DEBUG - 2023-06-22 07:04:22 --> Total execution time: 0.0287
ERROR - 2023-06-22 07:09:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:09:48 --> Config Class Initialized
INFO - 2023-06-22 07:09:48 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:09:48 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:09:48 --> Utf8 Class Initialized
INFO - 2023-06-22 07:09:48 --> URI Class Initialized
DEBUG - 2023-06-22 07:09:48 --> No URI present. Default controller set.
INFO - 2023-06-22 07:09:48 --> Router Class Initialized
INFO - 2023-06-22 07:09:48 --> Output Class Initialized
INFO - 2023-06-22 07:09:48 --> Security Class Initialized
DEBUG - 2023-06-22 07:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:09:48 --> Input Class Initialized
INFO - 2023-06-22 07:09:48 --> Language Class Initialized
INFO - 2023-06-22 07:09:48 --> Loader Class Initialized
INFO - 2023-06-22 07:09:48 --> Helper loaded: url_helper
INFO - 2023-06-22 07:09:48 --> Helper loaded: file_helper
INFO - 2023-06-22 07:09:48 --> Helper loaded: html_helper
INFO - 2023-06-22 07:09:48 --> Helper loaded: text_helper
INFO - 2023-06-22 07:09:48 --> Helper loaded: form_helper
INFO - 2023-06-22 07:09:48 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:09:48 --> Helper loaded: security_helper
INFO - 2023-06-22 07:09:48 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:09:48 --> Database Driver Class Initialized
INFO - 2023-06-22 07:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:09:48 --> Parser Class Initialized
INFO - 2023-06-22 07:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:09:48 --> Pagination Class Initialized
INFO - 2023-06-22 07:09:48 --> Form Validation Class Initialized
INFO - 2023-06-22 07:09:48 --> Controller Class Initialized
INFO - 2023-06-22 07:09:48 --> Model Class Initialized
DEBUG - 2023-06-22 07:09:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 07:11:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:11:17 --> Config Class Initialized
INFO - 2023-06-22 07:11:17 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:11:17 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:11:17 --> Utf8 Class Initialized
INFO - 2023-06-22 07:11:17 --> URI Class Initialized
DEBUG - 2023-06-22 07:11:17 --> No URI present. Default controller set.
INFO - 2023-06-22 07:11:17 --> Router Class Initialized
INFO - 2023-06-22 07:11:17 --> Output Class Initialized
INFO - 2023-06-22 07:11:17 --> Security Class Initialized
DEBUG - 2023-06-22 07:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:11:17 --> Input Class Initialized
INFO - 2023-06-22 07:11:17 --> Language Class Initialized
INFO - 2023-06-22 07:11:17 --> Loader Class Initialized
INFO - 2023-06-22 07:11:17 --> Helper loaded: url_helper
INFO - 2023-06-22 07:11:17 --> Helper loaded: file_helper
INFO - 2023-06-22 07:11:17 --> Helper loaded: html_helper
INFO - 2023-06-22 07:11:17 --> Helper loaded: text_helper
INFO - 2023-06-22 07:11:17 --> Helper loaded: form_helper
INFO - 2023-06-22 07:11:17 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:11:17 --> Helper loaded: security_helper
INFO - 2023-06-22 07:11:17 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:11:17 --> Database Driver Class Initialized
INFO - 2023-06-22 07:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:11:17 --> Parser Class Initialized
INFO - 2023-06-22 07:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:11:17 --> Pagination Class Initialized
INFO - 2023-06-22 07:11:17 --> Form Validation Class Initialized
INFO - 2023-06-22 07:11:17 --> Controller Class Initialized
INFO - 2023-06-22 07:11:17 --> Model Class Initialized
DEBUG - 2023-06-22 07:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:11:17 --> Model Class Initialized
DEBUG - 2023-06-22 07:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:11:17 --> Model Class Initialized
INFO - 2023-06-22 07:11:17 --> Model Class Initialized
INFO - 2023-06-22 07:11:17 --> Model Class Initialized
INFO - 2023-06-22 07:11:17 --> Model Class Initialized
DEBUG - 2023-06-22 07:11:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:11:17 --> Model Class Initialized
INFO - 2023-06-22 07:11:17 --> Model Class Initialized
INFO - 2023-06-22 07:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 07:11:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:11:17 --> Model Class Initialized
INFO - 2023-06-22 07:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:11:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:11:17 --> Final output sent to browser
DEBUG - 2023-06-22 07:11:17 --> Total execution time: 0.1708
ERROR - 2023-06-22 07:11:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:11:41 --> Config Class Initialized
INFO - 2023-06-22 07:11:41 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:11:41 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:11:41 --> Utf8 Class Initialized
INFO - 2023-06-22 07:11:41 --> URI Class Initialized
INFO - 2023-06-22 07:11:41 --> Router Class Initialized
INFO - 2023-06-22 07:11:41 --> Output Class Initialized
INFO - 2023-06-22 07:11:41 --> Security Class Initialized
DEBUG - 2023-06-22 07:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:11:41 --> Input Class Initialized
INFO - 2023-06-22 07:11:41 --> Language Class Initialized
INFO - 2023-06-22 07:11:41 --> Loader Class Initialized
INFO - 2023-06-22 07:11:41 --> Helper loaded: url_helper
INFO - 2023-06-22 07:11:41 --> Helper loaded: file_helper
INFO - 2023-06-22 07:11:41 --> Helper loaded: html_helper
INFO - 2023-06-22 07:11:41 --> Helper loaded: text_helper
INFO - 2023-06-22 07:11:41 --> Helper loaded: form_helper
INFO - 2023-06-22 07:11:41 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:11:41 --> Helper loaded: security_helper
INFO - 2023-06-22 07:11:41 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:11:41 --> Database Driver Class Initialized
INFO - 2023-06-22 07:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:11:41 --> Parser Class Initialized
INFO - 2023-06-22 07:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:11:41 --> Pagination Class Initialized
INFO - 2023-06-22 07:11:41 --> Form Validation Class Initialized
INFO - 2023-06-22 07:11:41 --> Controller Class Initialized
INFO - 2023-06-22 07:11:41 --> Model Class Initialized
DEBUG - 2023-06-22 07:11:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:11:41 --> Model Class Initialized
INFO - 2023-06-22 07:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:11:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:11:41 --> Model Class Initialized
INFO - 2023-06-22 07:11:41 --> Model Class Initialized
INFO - 2023-06-22 07:11:41 --> Model Class Initialized
INFO - 2023-06-22 07:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:11:42 --> Final output sent to browser
DEBUG - 2023-06-22 07:11:42 --> Total execution time: 0.1239
ERROR - 2023-06-22 07:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:11:42 --> Config Class Initialized
INFO - 2023-06-22 07:11:42 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:11:42 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:11:42 --> Utf8 Class Initialized
INFO - 2023-06-22 07:11:42 --> URI Class Initialized
INFO - 2023-06-22 07:11:42 --> Router Class Initialized
INFO - 2023-06-22 07:11:42 --> Output Class Initialized
INFO - 2023-06-22 07:11:42 --> Security Class Initialized
DEBUG - 2023-06-22 07:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:11:42 --> Input Class Initialized
INFO - 2023-06-22 07:11:42 --> Language Class Initialized
INFO - 2023-06-22 07:11:42 --> Loader Class Initialized
INFO - 2023-06-22 07:11:42 --> Helper loaded: url_helper
INFO - 2023-06-22 07:11:42 --> Helper loaded: file_helper
INFO - 2023-06-22 07:11:42 --> Helper loaded: html_helper
INFO - 2023-06-22 07:11:42 --> Helper loaded: text_helper
INFO - 2023-06-22 07:11:42 --> Helper loaded: form_helper
INFO - 2023-06-22 07:11:42 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:11:42 --> Helper loaded: security_helper
INFO - 2023-06-22 07:11:42 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:11:42 --> Database Driver Class Initialized
INFO - 2023-06-22 07:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:11:42 --> Parser Class Initialized
INFO - 2023-06-22 07:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:11:42 --> Pagination Class Initialized
INFO - 2023-06-22 07:11:42 --> Form Validation Class Initialized
INFO - 2023-06-22 07:11:42 --> Controller Class Initialized
INFO - 2023-06-22 07:11:42 --> Model Class Initialized
DEBUG - 2023-06-22 07:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:11:42 --> Model Class Initialized
INFO - 2023-06-22 07:11:42 --> Final output sent to browser
DEBUG - 2023-06-22 07:11:42 --> Total execution time: 0.0280
ERROR - 2023-06-22 07:12:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:12:14 --> Config Class Initialized
INFO - 2023-06-22 07:12:14 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:12:14 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:12:14 --> Utf8 Class Initialized
INFO - 2023-06-22 07:12:14 --> URI Class Initialized
INFO - 2023-06-22 07:12:14 --> Router Class Initialized
INFO - 2023-06-22 07:12:14 --> Output Class Initialized
INFO - 2023-06-22 07:12:14 --> Security Class Initialized
DEBUG - 2023-06-22 07:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:12:14 --> Input Class Initialized
INFO - 2023-06-22 07:12:14 --> Language Class Initialized
INFO - 2023-06-22 07:12:14 --> Loader Class Initialized
INFO - 2023-06-22 07:12:14 --> Helper loaded: url_helper
INFO - 2023-06-22 07:12:14 --> Helper loaded: file_helper
INFO - 2023-06-22 07:12:14 --> Helper loaded: html_helper
INFO - 2023-06-22 07:12:14 --> Helper loaded: text_helper
INFO - 2023-06-22 07:12:14 --> Helper loaded: form_helper
INFO - 2023-06-22 07:12:14 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:12:14 --> Helper loaded: security_helper
INFO - 2023-06-22 07:12:14 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:12:14 --> Database Driver Class Initialized
INFO - 2023-06-22 07:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:12:14 --> Parser Class Initialized
INFO - 2023-06-22 07:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:12:14 --> Pagination Class Initialized
INFO - 2023-06-22 07:12:14 --> Form Validation Class Initialized
INFO - 2023-06-22 07:12:14 --> Controller Class Initialized
INFO - 2023-06-22 07:12:14 --> Model Class Initialized
DEBUG - 2023-06-22 07:12:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:12:14 --> Model Class Initialized
DEBUG - 2023-06-22 07:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:12:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:12:14 --> Model Class Initialized
INFO - 2023-06-22 07:12:14 --> Model Class Initialized
INFO - 2023-06-22 07:12:14 --> Model Class Initialized
INFO - 2023-06-22 07:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:12:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:12:14 --> Final output sent to browser
DEBUG - 2023-06-22 07:12:14 --> Total execution time: 0.1316
ERROR - 2023-06-22 07:12:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:12:20 --> Config Class Initialized
INFO - 2023-06-22 07:12:20 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:12:20 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:12:20 --> Utf8 Class Initialized
INFO - 2023-06-22 07:12:20 --> URI Class Initialized
INFO - 2023-06-22 07:12:20 --> Router Class Initialized
INFO - 2023-06-22 07:12:20 --> Output Class Initialized
INFO - 2023-06-22 07:12:20 --> Security Class Initialized
DEBUG - 2023-06-22 07:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:12:20 --> Input Class Initialized
INFO - 2023-06-22 07:12:20 --> Language Class Initialized
INFO - 2023-06-22 07:12:20 --> Loader Class Initialized
INFO - 2023-06-22 07:12:20 --> Helper loaded: url_helper
INFO - 2023-06-22 07:12:20 --> Helper loaded: file_helper
INFO - 2023-06-22 07:12:20 --> Helper loaded: html_helper
INFO - 2023-06-22 07:12:20 --> Helper loaded: text_helper
INFO - 2023-06-22 07:12:20 --> Helper loaded: form_helper
INFO - 2023-06-22 07:12:20 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:12:20 --> Helper loaded: security_helper
INFO - 2023-06-22 07:12:20 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:12:20 --> Database Driver Class Initialized
INFO - 2023-06-22 07:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:12:20 --> Parser Class Initialized
INFO - 2023-06-22 07:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:12:20 --> Pagination Class Initialized
INFO - 2023-06-22 07:12:20 --> Form Validation Class Initialized
INFO - 2023-06-22 07:12:20 --> Controller Class Initialized
INFO - 2023-06-22 07:12:20 --> Model Class Initialized
DEBUG - 2023-06-22 07:12:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:12:20 --> Model Class Initialized
INFO - 2023-06-22 07:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:12:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:12:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:12:20 --> Model Class Initialized
INFO - 2023-06-22 07:12:20 --> Model Class Initialized
INFO - 2023-06-22 07:12:20 --> Model Class Initialized
INFO - 2023-06-22 07:12:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:12:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:12:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:12:21 --> Final output sent to browser
DEBUG - 2023-06-22 07:12:21 --> Total execution time: 0.1246
ERROR - 2023-06-22 07:12:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:12:21 --> Config Class Initialized
INFO - 2023-06-22 07:12:21 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:12:21 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:12:21 --> Utf8 Class Initialized
INFO - 2023-06-22 07:12:21 --> URI Class Initialized
INFO - 2023-06-22 07:12:21 --> Router Class Initialized
INFO - 2023-06-22 07:12:21 --> Output Class Initialized
INFO - 2023-06-22 07:12:21 --> Security Class Initialized
DEBUG - 2023-06-22 07:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:12:21 --> Input Class Initialized
INFO - 2023-06-22 07:12:21 --> Language Class Initialized
INFO - 2023-06-22 07:12:21 --> Loader Class Initialized
INFO - 2023-06-22 07:12:21 --> Helper loaded: url_helper
INFO - 2023-06-22 07:12:21 --> Helper loaded: file_helper
INFO - 2023-06-22 07:12:21 --> Helper loaded: html_helper
INFO - 2023-06-22 07:12:21 --> Helper loaded: text_helper
INFO - 2023-06-22 07:12:21 --> Helper loaded: form_helper
INFO - 2023-06-22 07:12:21 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:12:21 --> Helper loaded: security_helper
INFO - 2023-06-22 07:12:21 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:12:21 --> Database Driver Class Initialized
INFO - 2023-06-22 07:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:12:21 --> Parser Class Initialized
INFO - 2023-06-22 07:12:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:12:21 --> Pagination Class Initialized
INFO - 2023-06-22 07:12:21 --> Form Validation Class Initialized
INFO - 2023-06-22 07:12:21 --> Controller Class Initialized
INFO - 2023-06-22 07:12:21 --> Model Class Initialized
DEBUG - 2023-06-22 07:12:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:12:21 --> Model Class Initialized
INFO - 2023-06-22 07:12:21 --> Final output sent to browser
DEBUG - 2023-06-22 07:12:21 --> Total execution time: 0.0278
ERROR - 2023-06-22 07:13:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:13:18 --> Config Class Initialized
INFO - 2023-06-22 07:13:18 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:13:18 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:13:18 --> Utf8 Class Initialized
INFO - 2023-06-22 07:13:18 --> URI Class Initialized
INFO - 2023-06-22 07:13:18 --> Router Class Initialized
INFO - 2023-06-22 07:13:18 --> Output Class Initialized
INFO - 2023-06-22 07:13:18 --> Security Class Initialized
DEBUG - 2023-06-22 07:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:13:18 --> Input Class Initialized
INFO - 2023-06-22 07:13:18 --> Language Class Initialized
INFO - 2023-06-22 07:13:18 --> Loader Class Initialized
INFO - 2023-06-22 07:13:18 --> Helper loaded: url_helper
INFO - 2023-06-22 07:13:18 --> Helper loaded: file_helper
INFO - 2023-06-22 07:13:18 --> Helper loaded: html_helper
INFO - 2023-06-22 07:13:18 --> Helper loaded: text_helper
INFO - 2023-06-22 07:13:18 --> Helper loaded: form_helper
INFO - 2023-06-22 07:13:18 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:13:18 --> Helper loaded: security_helper
INFO - 2023-06-22 07:13:18 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:13:18 --> Database Driver Class Initialized
INFO - 2023-06-22 07:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:13:18 --> Parser Class Initialized
INFO - 2023-06-22 07:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:13:18 --> Pagination Class Initialized
INFO - 2023-06-22 07:13:18 --> Form Validation Class Initialized
INFO - 2023-06-22 07:13:18 --> Controller Class Initialized
INFO - 2023-06-22 07:13:18 --> Model Class Initialized
DEBUG - 2023-06-22 07:13:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:18 --> Model Class Initialized
DEBUG - 2023-06-22 07:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:13:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:13:18 --> Model Class Initialized
INFO - 2023-06-22 07:13:18 --> Model Class Initialized
INFO - 2023-06-22 07:13:18 --> Model Class Initialized
INFO - 2023-06-22 07:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:13:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:13:18 --> Final output sent to browser
DEBUG - 2023-06-22 07:13:18 --> Total execution time: 0.1226
ERROR - 2023-06-22 07:13:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:13:25 --> Config Class Initialized
INFO - 2023-06-22 07:13:25 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:13:25 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:13:25 --> Utf8 Class Initialized
INFO - 2023-06-22 07:13:25 --> URI Class Initialized
INFO - 2023-06-22 07:13:25 --> Router Class Initialized
INFO - 2023-06-22 07:13:25 --> Output Class Initialized
INFO - 2023-06-22 07:13:25 --> Security Class Initialized
DEBUG - 2023-06-22 07:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:13:25 --> Input Class Initialized
INFO - 2023-06-22 07:13:25 --> Language Class Initialized
INFO - 2023-06-22 07:13:25 --> Loader Class Initialized
INFO - 2023-06-22 07:13:25 --> Helper loaded: url_helper
INFO - 2023-06-22 07:13:25 --> Helper loaded: file_helper
INFO - 2023-06-22 07:13:25 --> Helper loaded: html_helper
INFO - 2023-06-22 07:13:25 --> Helper loaded: text_helper
INFO - 2023-06-22 07:13:25 --> Helper loaded: form_helper
INFO - 2023-06-22 07:13:25 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:13:25 --> Helper loaded: security_helper
INFO - 2023-06-22 07:13:25 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:13:25 --> Database Driver Class Initialized
INFO - 2023-06-22 07:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:13:25 --> Parser Class Initialized
INFO - 2023-06-22 07:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:13:25 --> Pagination Class Initialized
INFO - 2023-06-22 07:13:25 --> Form Validation Class Initialized
INFO - 2023-06-22 07:13:25 --> Controller Class Initialized
INFO - 2023-06-22 07:13:25 --> Model Class Initialized
DEBUG - 2023-06-22 07:13:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:25 --> Model Class Initialized
INFO - 2023-06-22 07:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:13:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:13:25 --> Model Class Initialized
INFO - 2023-06-22 07:13:25 --> Model Class Initialized
INFO - 2023-06-22 07:13:25 --> Model Class Initialized
INFO - 2023-06-22 07:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:13:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:13:25 --> Final output sent to browser
DEBUG - 2023-06-22 07:13:25 --> Total execution time: 0.1156
ERROR - 2023-06-22 07:13:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:13:26 --> Config Class Initialized
INFO - 2023-06-22 07:13:26 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:13:26 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:13:26 --> Utf8 Class Initialized
INFO - 2023-06-22 07:13:26 --> URI Class Initialized
INFO - 2023-06-22 07:13:26 --> Router Class Initialized
INFO - 2023-06-22 07:13:26 --> Output Class Initialized
INFO - 2023-06-22 07:13:26 --> Security Class Initialized
DEBUG - 2023-06-22 07:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:13:26 --> Input Class Initialized
INFO - 2023-06-22 07:13:26 --> Language Class Initialized
INFO - 2023-06-22 07:13:26 --> Loader Class Initialized
INFO - 2023-06-22 07:13:26 --> Helper loaded: url_helper
INFO - 2023-06-22 07:13:26 --> Helper loaded: file_helper
INFO - 2023-06-22 07:13:26 --> Helper loaded: html_helper
INFO - 2023-06-22 07:13:26 --> Helper loaded: text_helper
INFO - 2023-06-22 07:13:26 --> Helper loaded: form_helper
INFO - 2023-06-22 07:13:26 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:13:26 --> Helper loaded: security_helper
INFO - 2023-06-22 07:13:26 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:13:26 --> Database Driver Class Initialized
INFO - 2023-06-22 07:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:13:26 --> Parser Class Initialized
INFO - 2023-06-22 07:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:13:26 --> Pagination Class Initialized
INFO - 2023-06-22 07:13:26 --> Form Validation Class Initialized
INFO - 2023-06-22 07:13:26 --> Controller Class Initialized
INFO - 2023-06-22 07:13:26 --> Model Class Initialized
DEBUG - 2023-06-22 07:13:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:26 --> Model Class Initialized
INFO - 2023-06-22 07:13:26 --> Final output sent to browser
DEBUG - 2023-06-22 07:13:26 --> Total execution time: 0.0345
ERROR - 2023-06-22 07:13:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:13:30 --> Config Class Initialized
INFO - 2023-06-22 07:13:30 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:13:30 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:13:30 --> Utf8 Class Initialized
INFO - 2023-06-22 07:13:30 --> URI Class Initialized
INFO - 2023-06-22 07:13:30 --> Router Class Initialized
INFO - 2023-06-22 07:13:30 --> Output Class Initialized
INFO - 2023-06-22 07:13:30 --> Security Class Initialized
DEBUG - 2023-06-22 07:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:13:30 --> Input Class Initialized
INFO - 2023-06-22 07:13:30 --> Language Class Initialized
INFO - 2023-06-22 07:13:30 --> Loader Class Initialized
INFO - 2023-06-22 07:13:30 --> Helper loaded: url_helper
INFO - 2023-06-22 07:13:30 --> Helper loaded: file_helper
INFO - 2023-06-22 07:13:30 --> Helper loaded: html_helper
INFO - 2023-06-22 07:13:30 --> Helper loaded: text_helper
INFO - 2023-06-22 07:13:30 --> Helper loaded: form_helper
INFO - 2023-06-22 07:13:30 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:13:30 --> Helper loaded: security_helper
INFO - 2023-06-22 07:13:30 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:13:30 --> Database Driver Class Initialized
INFO - 2023-06-22 07:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:13:30 --> Parser Class Initialized
INFO - 2023-06-22 07:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:13:30 --> Pagination Class Initialized
INFO - 2023-06-22 07:13:30 --> Form Validation Class Initialized
INFO - 2023-06-22 07:13:30 --> Controller Class Initialized
DEBUG - 2023-06-22 07:13:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:30 --> Model Class Initialized
DEBUG - 2023-06-22 07:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:30 --> Model Class Initialized
DEBUG - 2023-06-22 07:13:30 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:30 --> Model Class Initialized
INFO - 2023-06-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-22 07:13:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:13:30 --> Model Class Initialized
INFO - 2023-06-22 07:13:30 --> Model Class Initialized
INFO - 2023-06-22 07:13:30 --> Model Class Initialized
INFO - 2023-06-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:13:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:13:30 --> Final output sent to browser
DEBUG - 2023-06-22 07:13:30 --> Total execution time: 0.1163
ERROR - 2023-06-22 07:13:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:13:31 --> Config Class Initialized
INFO - 2023-06-22 07:13:31 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:13:31 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:13:31 --> Utf8 Class Initialized
INFO - 2023-06-22 07:13:31 --> URI Class Initialized
INFO - 2023-06-22 07:13:31 --> Router Class Initialized
INFO - 2023-06-22 07:13:31 --> Output Class Initialized
INFO - 2023-06-22 07:13:31 --> Security Class Initialized
DEBUG - 2023-06-22 07:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:13:31 --> Input Class Initialized
INFO - 2023-06-22 07:13:31 --> Language Class Initialized
INFO - 2023-06-22 07:13:31 --> Loader Class Initialized
INFO - 2023-06-22 07:13:31 --> Helper loaded: url_helper
INFO - 2023-06-22 07:13:31 --> Helper loaded: file_helper
INFO - 2023-06-22 07:13:31 --> Helper loaded: html_helper
INFO - 2023-06-22 07:13:31 --> Helper loaded: text_helper
INFO - 2023-06-22 07:13:31 --> Helper loaded: form_helper
INFO - 2023-06-22 07:13:31 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:13:31 --> Helper loaded: security_helper
INFO - 2023-06-22 07:13:31 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:13:31 --> Database Driver Class Initialized
INFO - 2023-06-22 07:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:13:31 --> Parser Class Initialized
INFO - 2023-06-22 07:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:13:31 --> Pagination Class Initialized
INFO - 2023-06-22 07:13:31 --> Form Validation Class Initialized
INFO - 2023-06-22 07:13:31 --> Controller Class Initialized
DEBUG - 2023-06-22 07:13:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:31 --> Model Class Initialized
DEBUG - 2023-06-22 07:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:31 --> Model Class Initialized
INFO - 2023-06-22 07:13:31 --> Final output sent to browser
DEBUG - 2023-06-22 07:13:31 --> Total execution time: 0.0294
ERROR - 2023-06-22 07:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:13:34 --> Config Class Initialized
INFO - 2023-06-22 07:13:34 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:13:34 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:13:34 --> Utf8 Class Initialized
INFO - 2023-06-22 07:13:34 --> URI Class Initialized
INFO - 2023-06-22 07:13:34 --> Router Class Initialized
INFO - 2023-06-22 07:13:34 --> Output Class Initialized
INFO - 2023-06-22 07:13:34 --> Security Class Initialized
DEBUG - 2023-06-22 07:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:13:34 --> Input Class Initialized
INFO - 2023-06-22 07:13:34 --> Language Class Initialized
INFO - 2023-06-22 07:13:34 --> Loader Class Initialized
INFO - 2023-06-22 07:13:34 --> Helper loaded: url_helper
INFO - 2023-06-22 07:13:34 --> Helper loaded: file_helper
INFO - 2023-06-22 07:13:34 --> Helper loaded: html_helper
INFO - 2023-06-22 07:13:34 --> Helper loaded: text_helper
INFO - 2023-06-22 07:13:34 --> Helper loaded: form_helper
INFO - 2023-06-22 07:13:34 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:13:34 --> Helper loaded: security_helper
INFO - 2023-06-22 07:13:34 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:13:34 --> Database Driver Class Initialized
INFO - 2023-06-22 07:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:13:34 --> Parser Class Initialized
INFO - 2023-06-22 07:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:13:34 --> Pagination Class Initialized
INFO - 2023-06-22 07:13:34 --> Form Validation Class Initialized
INFO - 2023-06-22 07:13:34 --> Controller Class Initialized
DEBUG - 2023-06-22 07:13:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:34 --> Model Class Initialized
DEBUG - 2023-06-22 07:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:13:34 --> Model Class Initialized
INFO - 2023-06-22 07:13:35 --> Final output sent to browser
DEBUG - 2023-06-22 07:13:35 --> Total execution time: 0.1043
ERROR - 2023-06-22 07:14:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:14:42 --> Config Class Initialized
INFO - 2023-06-22 07:14:42 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:14:42 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:14:42 --> Utf8 Class Initialized
INFO - 2023-06-22 07:14:42 --> URI Class Initialized
INFO - 2023-06-22 07:14:42 --> Router Class Initialized
INFO - 2023-06-22 07:14:42 --> Output Class Initialized
INFO - 2023-06-22 07:14:42 --> Security Class Initialized
DEBUG - 2023-06-22 07:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:14:42 --> Input Class Initialized
INFO - 2023-06-22 07:14:42 --> Language Class Initialized
INFO - 2023-06-22 07:14:42 --> Loader Class Initialized
INFO - 2023-06-22 07:14:42 --> Helper loaded: url_helper
INFO - 2023-06-22 07:14:42 --> Helper loaded: file_helper
INFO - 2023-06-22 07:14:42 --> Helper loaded: html_helper
INFO - 2023-06-22 07:14:42 --> Helper loaded: text_helper
INFO - 2023-06-22 07:14:42 --> Helper loaded: form_helper
INFO - 2023-06-22 07:14:42 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:14:42 --> Helper loaded: security_helper
INFO - 2023-06-22 07:14:42 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:14:42 --> Database Driver Class Initialized
INFO - 2023-06-22 07:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:14:42 --> Parser Class Initialized
INFO - 2023-06-22 07:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:14:42 --> Pagination Class Initialized
INFO - 2023-06-22 07:14:42 --> Form Validation Class Initialized
INFO - 2023-06-22 07:14:42 --> Controller Class Initialized
INFO - 2023-06-22 07:14:42 --> Model Class Initialized
DEBUG - 2023-06-22 07:14:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:14:42 --> Model Class Initialized
INFO - 2023-06-22 07:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:14:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:14:42 --> Model Class Initialized
INFO - 2023-06-22 07:14:42 --> Model Class Initialized
INFO - 2023-06-22 07:14:42 --> Model Class Initialized
INFO - 2023-06-22 07:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:14:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:14:42 --> Final output sent to browser
DEBUG - 2023-06-22 07:14:42 --> Total execution time: 0.2932
ERROR - 2023-06-22 07:14:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:14:43 --> Config Class Initialized
INFO - 2023-06-22 07:14:43 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:14:43 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:14:43 --> Utf8 Class Initialized
INFO - 2023-06-22 07:14:43 --> URI Class Initialized
INFO - 2023-06-22 07:14:43 --> Router Class Initialized
INFO - 2023-06-22 07:14:43 --> Output Class Initialized
INFO - 2023-06-22 07:14:43 --> Security Class Initialized
DEBUG - 2023-06-22 07:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:14:43 --> Input Class Initialized
INFO - 2023-06-22 07:14:43 --> Language Class Initialized
INFO - 2023-06-22 07:14:43 --> Loader Class Initialized
INFO - 2023-06-22 07:14:43 --> Helper loaded: url_helper
INFO - 2023-06-22 07:14:43 --> Helper loaded: file_helper
INFO - 2023-06-22 07:14:43 --> Helper loaded: html_helper
INFO - 2023-06-22 07:14:43 --> Helper loaded: text_helper
INFO - 2023-06-22 07:14:43 --> Helper loaded: form_helper
INFO - 2023-06-22 07:14:43 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:14:43 --> Helper loaded: security_helper
INFO - 2023-06-22 07:14:43 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:14:43 --> Database Driver Class Initialized
INFO - 2023-06-22 07:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:14:43 --> Parser Class Initialized
INFO - 2023-06-22 07:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:14:43 --> Pagination Class Initialized
INFO - 2023-06-22 07:14:43 --> Form Validation Class Initialized
INFO - 2023-06-22 07:14:43 --> Controller Class Initialized
INFO - 2023-06-22 07:14:43 --> Model Class Initialized
DEBUG - 2023-06-22 07:14:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:14:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:14:43 --> Model Class Initialized
INFO - 2023-06-22 07:14:43 --> Final output sent to browser
DEBUG - 2023-06-22 07:14:43 --> Total execution time: 0.0305
ERROR - 2023-06-22 07:15:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:15:05 --> Config Class Initialized
INFO - 2023-06-22 07:15:05 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:15:05 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:15:05 --> Utf8 Class Initialized
INFO - 2023-06-22 07:15:05 --> URI Class Initialized
INFO - 2023-06-22 07:15:05 --> Router Class Initialized
INFO - 2023-06-22 07:15:05 --> Output Class Initialized
INFO - 2023-06-22 07:15:05 --> Security Class Initialized
DEBUG - 2023-06-22 07:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:15:05 --> Input Class Initialized
INFO - 2023-06-22 07:15:05 --> Language Class Initialized
INFO - 2023-06-22 07:15:05 --> Loader Class Initialized
INFO - 2023-06-22 07:15:05 --> Helper loaded: url_helper
INFO - 2023-06-22 07:15:05 --> Helper loaded: file_helper
INFO - 2023-06-22 07:15:05 --> Helper loaded: html_helper
INFO - 2023-06-22 07:15:05 --> Helper loaded: text_helper
INFO - 2023-06-22 07:15:05 --> Helper loaded: form_helper
INFO - 2023-06-22 07:15:05 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:15:05 --> Helper loaded: security_helper
INFO - 2023-06-22 07:15:05 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:15:05 --> Database Driver Class Initialized
INFO - 2023-06-22 07:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:15:05 --> Parser Class Initialized
INFO - 2023-06-22 07:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:15:05 --> Pagination Class Initialized
INFO - 2023-06-22 07:15:05 --> Form Validation Class Initialized
INFO - 2023-06-22 07:15:05 --> Controller Class Initialized
INFO - 2023-06-22 07:15:05 --> Model Class Initialized
DEBUG - 2023-06-22 07:15:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:15:05 --> Model Class Initialized
DEBUG - 2023-06-22 07:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:15:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:15:05 --> Model Class Initialized
INFO - 2023-06-22 07:15:05 --> Model Class Initialized
INFO - 2023-06-22 07:15:05 --> Model Class Initialized
INFO - 2023-06-22 07:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:15:05 --> Final output sent to browser
DEBUG - 2023-06-22 07:15:05 --> Total execution time: 0.1207
ERROR - 2023-06-22 07:15:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:15:19 --> Config Class Initialized
INFO - 2023-06-22 07:15:19 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:15:19 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:15:19 --> Utf8 Class Initialized
INFO - 2023-06-22 07:15:19 --> URI Class Initialized
INFO - 2023-06-22 07:15:19 --> Router Class Initialized
INFO - 2023-06-22 07:15:19 --> Output Class Initialized
INFO - 2023-06-22 07:15:19 --> Security Class Initialized
DEBUG - 2023-06-22 07:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:15:19 --> Input Class Initialized
INFO - 2023-06-22 07:15:19 --> Language Class Initialized
INFO - 2023-06-22 07:15:19 --> Loader Class Initialized
INFO - 2023-06-22 07:15:19 --> Helper loaded: url_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: file_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: html_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: text_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: form_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: security_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:15:19 --> Database Driver Class Initialized
INFO - 2023-06-22 07:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:15:19 --> Parser Class Initialized
INFO - 2023-06-22 07:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:15:19 --> Pagination Class Initialized
INFO - 2023-06-22 07:15:19 --> Form Validation Class Initialized
INFO - 2023-06-22 07:15:19 --> Controller Class Initialized
INFO - 2023-06-22 07:15:19 --> Model Class Initialized
DEBUG - 2023-06-22 07:15:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:15:19 --> Model Class Initialized
INFO - 2023-06-22 07:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:15:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:15:19 --> Model Class Initialized
INFO - 2023-06-22 07:15:19 --> Model Class Initialized
INFO - 2023-06-22 07:15:19 --> Model Class Initialized
INFO - 2023-06-22 07:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:15:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:15:19 --> Final output sent to browser
DEBUG - 2023-06-22 07:15:19 --> Total execution time: 0.1279
ERROR - 2023-06-22 07:15:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:15:19 --> Config Class Initialized
INFO - 2023-06-22 07:15:19 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:15:19 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:15:19 --> Utf8 Class Initialized
INFO - 2023-06-22 07:15:19 --> URI Class Initialized
INFO - 2023-06-22 07:15:19 --> Router Class Initialized
INFO - 2023-06-22 07:15:19 --> Output Class Initialized
INFO - 2023-06-22 07:15:19 --> Security Class Initialized
DEBUG - 2023-06-22 07:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:15:19 --> Input Class Initialized
INFO - 2023-06-22 07:15:19 --> Language Class Initialized
INFO - 2023-06-22 07:15:19 --> Loader Class Initialized
INFO - 2023-06-22 07:15:19 --> Helper loaded: url_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: file_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: html_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: text_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: form_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: security_helper
INFO - 2023-06-22 07:15:19 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:15:19 --> Database Driver Class Initialized
INFO - 2023-06-22 07:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:15:19 --> Parser Class Initialized
INFO - 2023-06-22 07:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:15:19 --> Pagination Class Initialized
INFO - 2023-06-22 07:15:19 --> Form Validation Class Initialized
INFO - 2023-06-22 07:15:19 --> Controller Class Initialized
INFO - 2023-06-22 07:15:19 --> Model Class Initialized
DEBUG - 2023-06-22 07:15:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:15:19 --> Model Class Initialized
INFO - 2023-06-22 07:15:19 --> Final output sent to browser
DEBUG - 2023-06-22 07:15:19 --> Total execution time: 0.0274
ERROR - 2023-06-22 07:15:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:15:33 --> Config Class Initialized
INFO - 2023-06-22 07:15:33 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:15:33 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:15:33 --> Utf8 Class Initialized
INFO - 2023-06-22 07:15:33 --> URI Class Initialized
INFO - 2023-06-22 07:15:33 --> Router Class Initialized
INFO - 2023-06-22 07:15:33 --> Output Class Initialized
INFO - 2023-06-22 07:15:33 --> Security Class Initialized
DEBUG - 2023-06-22 07:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:15:33 --> Input Class Initialized
INFO - 2023-06-22 07:15:33 --> Language Class Initialized
INFO - 2023-06-22 07:15:33 --> Loader Class Initialized
INFO - 2023-06-22 07:15:33 --> Helper loaded: url_helper
INFO - 2023-06-22 07:15:33 --> Helper loaded: file_helper
INFO - 2023-06-22 07:15:33 --> Helper loaded: html_helper
INFO - 2023-06-22 07:15:33 --> Helper loaded: text_helper
INFO - 2023-06-22 07:15:33 --> Helper loaded: form_helper
INFO - 2023-06-22 07:15:33 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:15:33 --> Helper loaded: security_helper
INFO - 2023-06-22 07:15:33 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:15:33 --> Database Driver Class Initialized
INFO - 2023-06-22 07:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:15:33 --> Parser Class Initialized
INFO - 2023-06-22 07:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:15:33 --> Pagination Class Initialized
INFO - 2023-06-22 07:15:33 --> Form Validation Class Initialized
INFO - 2023-06-22 07:15:33 --> Controller Class Initialized
INFO - 2023-06-22 07:15:33 --> Model Class Initialized
DEBUG - 2023-06-22 07:15:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:15:33 --> Model Class Initialized
INFO - 2023-06-22 07:15:33 --> Final output sent to browser
DEBUG - 2023-06-22 07:15:33 --> Total execution time: 0.0483
ERROR - 2023-06-22 07:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:03 --> Config Class Initialized
INFO - 2023-06-22 07:17:03 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:03 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:03 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:03 --> URI Class Initialized
INFO - 2023-06-22 07:17:03 --> Router Class Initialized
INFO - 2023-06-22 07:17:03 --> Output Class Initialized
INFO - 2023-06-22 07:17:03 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:03 --> Input Class Initialized
INFO - 2023-06-22 07:17:03 --> Language Class Initialized
INFO - 2023-06-22 07:17:03 --> Loader Class Initialized
INFO - 2023-06-22 07:17:03 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:03 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:03 --> Parser Class Initialized
INFO - 2023-06-22 07:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:03 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:03 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:03 --> Controller Class Initialized
INFO - 2023-06-22 07:17:03 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:03 --> Model Class Initialized
ERROR - 2023-06-22 07:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:03 --> Config Class Initialized
INFO - 2023-06-22 07:17:03 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:03 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:03 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:03 --> URI Class Initialized
INFO - 2023-06-22 07:17:03 --> Router Class Initialized
INFO - 2023-06-22 07:17:03 --> Output Class Initialized
INFO - 2023-06-22 07:17:03 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:03 --> Input Class Initialized
INFO - 2023-06-22 07:17:03 --> Language Class Initialized
INFO - 2023-06-22 07:17:03 --> Loader Class Initialized
INFO - 2023-06-22 07:17:03 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:03 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:03 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:03 --> Parser Class Initialized
INFO - 2023-06-22 07:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:03 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:03 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:03 --> Controller Class Initialized
INFO - 2023-06-22 07:17:03 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:03 --> Model Class Initialized
INFO - 2023-06-22 07:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:17:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:17:03 --> Model Class Initialized
INFO - 2023-06-22 07:17:03 --> Model Class Initialized
INFO - 2023-06-22 07:17:03 --> Model Class Initialized
INFO - 2023-06-22 07:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:17:03 --> Final output sent to browser
DEBUG - 2023-06-22 07:17:03 --> Total execution time: 0.1341
ERROR - 2023-06-22 07:17:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:04 --> Config Class Initialized
INFO - 2023-06-22 07:17:04 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:04 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:04 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:04 --> URI Class Initialized
INFO - 2023-06-22 07:17:04 --> Router Class Initialized
INFO - 2023-06-22 07:17:04 --> Output Class Initialized
INFO - 2023-06-22 07:17:04 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:04 --> Input Class Initialized
INFO - 2023-06-22 07:17:04 --> Language Class Initialized
INFO - 2023-06-22 07:17:04 --> Loader Class Initialized
INFO - 2023-06-22 07:17:04 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:04 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:04 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:04 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:04 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:04 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:04 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:04 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:04 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:04 --> Parser Class Initialized
INFO - 2023-06-22 07:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:04 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:04 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:04 --> Controller Class Initialized
INFO - 2023-06-22 07:17:04 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:04 --> Model Class Initialized
INFO - 2023-06-22 07:17:04 --> Final output sent to browser
DEBUG - 2023-06-22 07:17:04 --> Total execution time: 0.0276
ERROR - 2023-06-22 07:17:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:12 --> Config Class Initialized
INFO - 2023-06-22 07:17:12 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:12 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:12 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:12 --> URI Class Initialized
INFO - 2023-06-22 07:17:12 --> Router Class Initialized
INFO - 2023-06-22 07:17:12 --> Output Class Initialized
INFO - 2023-06-22 07:17:12 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:12 --> Input Class Initialized
INFO - 2023-06-22 07:17:12 --> Language Class Initialized
INFO - 2023-06-22 07:17:12 --> Loader Class Initialized
INFO - 2023-06-22 07:17:12 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:12 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:12 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:12 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:12 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:12 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:12 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:12 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:12 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:12 --> Parser Class Initialized
INFO - 2023-06-22 07:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:12 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:12 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:12 --> Controller Class Initialized
INFO - 2023-06-22 07:17:12 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:12 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:17:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:17:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:17:12 --> Model Class Initialized
INFO - 2023-06-22 07:17:12 --> Model Class Initialized
INFO - 2023-06-22 07:17:12 --> Model Class Initialized
INFO - 2023-06-22 07:17:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:17:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:17:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:17:12 --> Final output sent to browser
DEBUG - 2023-06-22 07:17:12 --> Total execution time: 0.1278
ERROR - 2023-06-22 07:17:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:16 --> Config Class Initialized
INFO - 2023-06-22 07:17:16 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:16 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:16 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:16 --> URI Class Initialized
INFO - 2023-06-22 07:17:16 --> Router Class Initialized
INFO - 2023-06-22 07:17:16 --> Output Class Initialized
INFO - 2023-06-22 07:17:16 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:16 --> Input Class Initialized
INFO - 2023-06-22 07:17:16 --> Language Class Initialized
INFO - 2023-06-22 07:17:16 --> Loader Class Initialized
INFO - 2023-06-22 07:17:16 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:16 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:16 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:16 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:16 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:16 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:16 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:16 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:16 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:16 --> Parser Class Initialized
INFO - 2023-06-22 07:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:16 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:16 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:16 --> Controller Class Initialized
INFO - 2023-06-22 07:17:16 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:16 --> Model Class Initialized
INFO - 2023-06-22 07:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:17:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:17:16 --> Model Class Initialized
INFO - 2023-06-22 07:17:16 --> Model Class Initialized
INFO - 2023-06-22 07:17:16 --> Model Class Initialized
INFO - 2023-06-22 07:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:17:16 --> Final output sent to browser
DEBUG - 2023-06-22 07:17:16 --> Total execution time: 0.1256
ERROR - 2023-06-22 07:17:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:17 --> Config Class Initialized
INFO - 2023-06-22 07:17:17 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:17 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:17 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:17 --> URI Class Initialized
INFO - 2023-06-22 07:17:17 --> Router Class Initialized
INFO - 2023-06-22 07:17:17 --> Output Class Initialized
INFO - 2023-06-22 07:17:17 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:17 --> Input Class Initialized
INFO - 2023-06-22 07:17:17 --> Language Class Initialized
INFO - 2023-06-22 07:17:17 --> Loader Class Initialized
INFO - 2023-06-22 07:17:17 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:17 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:17 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:17 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:17 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:17 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:17 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:17 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:17 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:17 --> Parser Class Initialized
INFO - 2023-06-22 07:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:17 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:17 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:17 --> Controller Class Initialized
INFO - 2023-06-22 07:17:17 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:17 --> Model Class Initialized
INFO - 2023-06-22 07:17:17 --> Final output sent to browser
DEBUG - 2023-06-22 07:17:17 --> Total execution time: 0.0279
ERROR - 2023-06-22 07:17:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:21 --> Config Class Initialized
INFO - 2023-06-22 07:17:21 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:21 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:21 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:21 --> URI Class Initialized
INFO - 2023-06-22 07:17:21 --> Router Class Initialized
INFO - 2023-06-22 07:17:21 --> Output Class Initialized
INFO - 2023-06-22 07:17:21 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:21 --> Input Class Initialized
INFO - 2023-06-22 07:17:21 --> Language Class Initialized
INFO - 2023-06-22 07:17:21 --> Loader Class Initialized
INFO - 2023-06-22 07:17:21 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:21 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:21 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:21 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:21 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:21 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:21 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:21 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:21 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:21 --> Parser Class Initialized
INFO - 2023-06-22 07:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:21 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:21 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:21 --> Controller Class Initialized
INFO - 2023-06-22 07:17:21 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:21 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:17:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:17:21 --> Model Class Initialized
INFO - 2023-06-22 07:17:21 --> Model Class Initialized
INFO - 2023-06-22 07:17:21 --> Model Class Initialized
INFO - 2023-06-22 07:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:17:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:17:21 --> Final output sent to browser
DEBUG - 2023-06-22 07:17:21 --> Total execution time: 0.1122
ERROR - 2023-06-22 07:17:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:47 --> Config Class Initialized
INFO - 2023-06-22 07:17:47 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:47 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:47 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:47 --> URI Class Initialized
INFO - 2023-06-22 07:17:47 --> Router Class Initialized
INFO - 2023-06-22 07:17:47 --> Output Class Initialized
INFO - 2023-06-22 07:17:47 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:47 --> Input Class Initialized
INFO - 2023-06-22 07:17:47 --> Language Class Initialized
INFO - 2023-06-22 07:17:47 --> Loader Class Initialized
INFO - 2023-06-22 07:17:47 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:47 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:47 --> Parser Class Initialized
INFO - 2023-06-22 07:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:47 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:47 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:47 --> Controller Class Initialized
INFO - 2023-06-22 07:17:47 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:47 --> Model Class Initialized
INFO - 2023-06-22 07:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:17:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:17:47 --> Model Class Initialized
INFO - 2023-06-22 07:17:47 --> Model Class Initialized
INFO - 2023-06-22 07:17:47 --> Model Class Initialized
INFO - 2023-06-22 07:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:17:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:17:47 --> Final output sent to browser
DEBUG - 2023-06-22 07:17:47 --> Total execution time: 0.1238
ERROR - 2023-06-22 07:17:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:47 --> Config Class Initialized
INFO - 2023-06-22 07:17:47 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:47 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:47 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:47 --> URI Class Initialized
INFO - 2023-06-22 07:17:47 --> Router Class Initialized
INFO - 2023-06-22 07:17:47 --> Output Class Initialized
INFO - 2023-06-22 07:17:47 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:47 --> Input Class Initialized
INFO - 2023-06-22 07:17:47 --> Language Class Initialized
INFO - 2023-06-22 07:17:47 --> Loader Class Initialized
INFO - 2023-06-22 07:17:47 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:47 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:47 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:47 --> Parser Class Initialized
INFO - 2023-06-22 07:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:47 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:47 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:47 --> Controller Class Initialized
INFO - 2023-06-22 07:17:47 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:47 --> Model Class Initialized
INFO - 2023-06-22 07:17:47 --> Final output sent to browser
DEBUG - 2023-06-22 07:17:47 --> Total execution time: 0.0278
ERROR - 2023-06-22 07:17:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:17:59 --> Config Class Initialized
INFO - 2023-06-22 07:17:59 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:17:59 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:17:59 --> Utf8 Class Initialized
INFO - 2023-06-22 07:17:59 --> URI Class Initialized
INFO - 2023-06-22 07:17:59 --> Router Class Initialized
INFO - 2023-06-22 07:17:59 --> Output Class Initialized
INFO - 2023-06-22 07:17:59 --> Security Class Initialized
DEBUG - 2023-06-22 07:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:17:59 --> Input Class Initialized
INFO - 2023-06-22 07:17:59 --> Language Class Initialized
INFO - 2023-06-22 07:17:59 --> Loader Class Initialized
INFO - 2023-06-22 07:17:59 --> Helper loaded: url_helper
INFO - 2023-06-22 07:17:59 --> Helper loaded: file_helper
INFO - 2023-06-22 07:17:59 --> Helper loaded: html_helper
INFO - 2023-06-22 07:17:59 --> Helper loaded: text_helper
INFO - 2023-06-22 07:17:59 --> Helper loaded: form_helper
INFO - 2023-06-22 07:17:59 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:17:59 --> Helper loaded: security_helper
INFO - 2023-06-22 07:17:59 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:17:59 --> Database Driver Class Initialized
INFO - 2023-06-22 07:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:17:59 --> Parser Class Initialized
INFO - 2023-06-22 07:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:17:59 --> Pagination Class Initialized
INFO - 2023-06-22 07:17:59 --> Form Validation Class Initialized
INFO - 2023-06-22 07:17:59 --> Controller Class Initialized
INFO - 2023-06-22 07:17:59 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:59 --> Model Class Initialized
DEBUG - 2023-06-22 07:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:17:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:17:59 --> Model Class Initialized
INFO - 2023-06-22 07:17:59 --> Model Class Initialized
INFO - 2023-06-22 07:17:59 --> Model Class Initialized
INFO - 2023-06-22 07:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:17:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:17:59 --> Final output sent to browser
DEBUG - 2023-06-22 07:17:59 --> Total execution time: 0.1359
ERROR - 2023-06-22 07:18:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:18:04 --> Config Class Initialized
INFO - 2023-06-22 07:18:04 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:18:04 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:18:04 --> Utf8 Class Initialized
INFO - 2023-06-22 07:18:04 --> URI Class Initialized
INFO - 2023-06-22 07:18:04 --> Router Class Initialized
INFO - 2023-06-22 07:18:04 --> Output Class Initialized
INFO - 2023-06-22 07:18:04 --> Security Class Initialized
DEBUG - 2023-06-22 07:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:18:04 --> Input Class Initialized
INFO - 2023-06-22 07:18:04 --> Language Class Initialized
INFO - 2023-06-22 07:18:04 --> Loader Class Initialized
INFO - 2023-06-22 07:18:04 --> Helper loaded: url_helper
INFO - 2023-06-22 07:18:04 --> Helper loaded: file_helper
INFO - 2023-06-22 07:18:04 --> Helper loaded: html_helper
INFO - 2023-06-22 07:18:04 --> Helper loaded: text_helper
INFO - 2023-06-22 07:18:04 --> Helper loaded: form_helper
INFO - 2023-06-22 07:18:04 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:18:04 --> Helper loaded: security_helper
INFO - 2023-06-22 07:18:04 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:18:04 --> Database Driver Class Initialized
INFO - 2023-06-22 07:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:18:04 --> Parser Class Initialized
INFO - 2023-06-22 07:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:18:04 --> Pagination Class Initialized
INFO - 2023-06-22 07:18:04 --> Form Validation Class Initialized
INFO - 2023-06-22 07:18:04 --> Controller Class Initialized
INFO - 2023-06-22 07:18:04 --> Model Class Initialized
DEBUG - 2023-06-22 07:18:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:18:04 --> Model Class Initialized
INFO - 2023-06-22 07:18:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:18:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:18:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:18:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:18:04 --> Model Class Initialized
INFO - 2023-06-22 07:18:04 --> Model Class Initialized
INFO - 2023-06-22 07:18:04 --> Model Class Initialized
INFO - 2023-06-22 07:18:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:18:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:18:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:18:04 --> Final output sent to browser
DEBUG - 2023-06-22 07:18:04 --> Total execution time: 0.1292
ERROR - 2023-06-22 07:18:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:18:05 --> Config Class Initialized
INFO - 2023-06-22 07:18:05 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:18:05 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:18:05 --> Utf8 Class Initialized
INFO - 2023-06-22 07:18:05 --> URI Class Initialized
INFO - 2023-06-22 07:18:05 --> Router Class Initialized
INFO - 2023-06-22 07:18:05 --> Output Class Initialized
INFO - 2023-06-22 07:18:05 --> Security Class Initialized
DEBUG - 2023-06-22 07:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:18:05 --> Input Class Initialized
INFO - 2023-06-22 07:18:05 --> Language Class Initialized
INFO - 2023-06-22 07:18:05 --> Loader Class Initialized
INFO - 2023-06-22 07:18:05 --> Helper loaded: url_helper
INFO - 2023-06-22 07:18:05 --> Helper loaded: file_helper
INFO - 2023-06-22 07:18:05 --> Helper loaded: html_helper
INFO - 2023-06-22 07:18:05 --> Helper loaded: text_helper
INFO - 2023-06-22 07:18:05 --> Helper loaded: form_helper
INFO - 2023-06-22 07:18:05 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:18:05 --> Helper loaded: security_helper
INFO - 2023-06-22 07:18:05 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:18:05 --> Database Driver Class Initialized
INFO - 2023-06-22 07:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:18:05 --> Parser Class Initialized
INFO - 2023-06-22 07:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:18:05 --> Pagination Class Initialized
INFO - 2023-06-22 07:18:05 --> Form Validation Class Initialized
INFO - 2023-06-22 07:18:05 --> Controller Class Initialized
INFO - 2023-06-22 07:18:05 --> Model Class Initialized
DEBUG - 2023-06-22 07:18:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:18:05 --> Model Class Initialized
INFO - 2023-06-22 07:18:05 --> Final output sent to browser
DEBUG - 2023-06-22 07:18:05 --> Total execution time: 0.0284
ERROR - 2023-06-22 07:18:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:18:12 --> Config Class Initialized
INFO - 2023-06-22 07:18:12 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:18:12 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:18:12 --> Utf8 Class Initialized
INFO - 2023-06-22 07:18:12 --> URI Class Initialized
INFO - 2023-06-22 07:18:12 --> Router Class Initialized
INFO - 2023-06-22 07:18:12 --> Output Class Initialized
INFO - 2023-06-22 07:18:12 --> Security Class Initialized
DEBUG - 2023-06-22 07:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:18:12 --> Input Class Initialized
INFO - 2023-06-22 07:18:12 --> Language Class Initialized
INFO - 2023-06-22 07:18:12 --> Loader Class Initialized
INFO - 2023-06-22 07:18:12 --> Helper loaded: url_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: file_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: html_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: text_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: form_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: security_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:18:12 --> Database Driver Class Initialized
INFO - 2023-06-22 07:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:18:12 --> Parser Class Initialized
INFO - 2023-06-22 07:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:18:12 --> Pagination Class Initialized
INFO - 2023-06-22 07:18:12 --> Form Validation Class Initialized
INFO - 2023-06-22 07:18:12 --> Controller Class Initialized
INFO - 2023-06-22 07:18:12 --> Model Class Initialized
DEBUG - 2023-06-22 07:18:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:18:12 --> Model Class Initialized
ERROR - 2023-06-22 07:18:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:18:12 --> Config Class Initialized
INFO - 2023-06-22 07:18:12 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:18:12 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:18:12 --> Utf8 Class Initialized
INFO - 2023-06-22 07:18:12 --> URI Class Initialized
INFO - 2023-06-22 07:18:12 --> Router Class Initialized
INFO - 2023-06-22 07:18:12 --> Output Class Initialized
INFO - 2023-06-22 07:18:12 --> Security Class Initialized
DEBUG - 2023-06-22 07:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:18:12 --> Input Class Initialized
INFO - 2023-06-22 07:18:12 --> Language Class Initialized
INFO - 2023-06-22 07:18:12 --> Loader Class Initialized
INFO - 2023-06-22 07:18:12 --> Helper loaded: url_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: file_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: html_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: text_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: form_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: security_helper
INFO - 2023-06-22 07:18:12 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:18:12 --> Database Driver Class Initialized
INFO - 2023-06-22 07:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:18:12 --> Parser Class Initialized
INFO - 2023-06-22 07:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:18:12 --> Pagination Class Initialized
INFO - 2023-06-22 07:18:12 --> Form Validation Class Initialized
INFO - 2023-06-22 07:18:12 --> Controller Class Initialized
INFO - 2023-06-22 07:18:12 --> Model Class Initialized
DEBUG - 2023-06-22 07:18:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:18:12 --> Model Class Initialized
INFO - 2023-06-22 07:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:18:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:18:12 --> Model Class Initialized
INFO - 2023-06-22 07:18:12 --> Model Class Initialized
INFO - 2023-06-22 07:18:12 --> Model Class Initialized
INFO - 2023-06-22 07:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:18:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:18:12 --> Final output sent to browser
DEBUG - 2023-06-22 07:18:12 --> Total execution time: 0.1245
ERROR - 2023-06-22 07:18:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:18:13 --> Config Class Initialized
INFO - 2023-06-22 07:18:13 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:18:13 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:18:13 --> Utf8 Class Initialized
INFO - 2023-06-22 07:18:13 --> URI Class Initialized
INFO - 2023-06-22 07:18:13 --> Router Class Initialized
INFO - 2023-06-22 07:18:13 --> Output Class Initialized
INFO - 2023-06-22 07:18:13 --> Security Class Initialized
DEBUG - 2023-06-22 07:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:18:13 --> Input Class Initialized
INFO - 2023-06-22 07:18:13 --> Language Class Initialized
INFO - 2023-06-22 07:18:13 --> Loader Class Initialized
INFO - 2023-06-22 07:18:13 --> Helper loaded: url_helper
INFO - 2023-06-22 07:18:13 --> Helper loaded: file_helper
INFO - 2023-06-22 07:18:13 --> Helper loaded: html_helper
INFO - 2023-06-22 07:18:13 --> Helper loaded: text_helper
INFO - 2023-06-22 07:18:13 --> Helper loaded: form_helper
INFO - 2023-06-22 07:18:13 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:18:13 --> Helper loaded: security_helper
INFO - 2023-06-22 07:18:13 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:18:13 --> Database Driver Class Initialized
INFO - 2023-06-22 07:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:18:13 --> Parser Class Initialized
INFO - 2023-06-22 07:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:18:13 --> Pagination Class Initialized
INFO - 2023-06-22 07:18:13 --> Form Validation Class Initialized
INFO - 2023-06-22 07:18:13 --> Controller Class Initialized
INFO - 2023-06-22 07:18:13 --> Model Class Initialized
DEBUG - 2023-06-22 07:18:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:18:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:18:13 --> Model Class Initialized
INFO - 2023-06-22 07:18:13 --> Final output sent to browser
DEBUG - 2023-06-22 07:18:13 --> Total execution time: 0.0272
ERROR - 2023-06-22 07:20:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:20:10 --> Config Class Initialized
INFO - 2023-06-22 07:20:10 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:20:10 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:20:10 --> Utf8 Class Initialized
INFO - 2023-06-22 07:20:10 --> URI Class Initialized
INFO - 2023-06-22 07:20:10 --> Router Class Initialized
INFO - 2023-06-22 07:20:10 --> Output Class Initialized
INFO - 2023-06-22 07:20:10 --> Security Class Initialized
DEBUG - 2023-06-22 07:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:20:10 --> Input Class Initialized
INFO - 2023-06-22 07:20:10 --> Language Class Initialized
INFO - 2023-06-22 07:20:10 --> Loader Class Initialized
INFO - 2023-06-22 07:20:10 --> Helper loaded: url_helper
INFO - 2023-06-22 07:20:10 --> Helper loaded: file_helper
INFO - 2023-06-22 07:20:10 --> Helper loaded: html_helper
INFO - 2023-06-22 07:20:10 --> Helper loaded: text_helper
INFO - 2023-06-22 07:20:10 --> Helper loaded: form_helper
INFO - 2023-06-22 07:20:10 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:20:10 --> Helper loaded: security_helper
INFO - 2023-06-22 07:20:10 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:20:10 --> Database Driver Class Initialized
INFO - 2023-06-22 07:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:20:10 --> Parser Class Initialized
INFO - 2023-06-22 07:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:20:10 --> Pagination Class Initialized
INFO - 2023-06-22 07:20:10 --> Form Validation Class Initialized
INFO - 2023-06-22 07:20:10 --> Controller Class Initialized
INFO - 2023-06-22 07:20:10 --> Model Class Initialized
DEBUG - 2023-06-22 07:20:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:20:10 --> Model Class Initialized
DEBUG - 2023-06-22 07:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:20:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:20:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:20:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:20:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:20:11 --> Model Class Initialized
INFO - 2023-06-22 07:20:11 --> Model Class Initialized
INFO - 2023-06-22 07:20:11 --> Model Class Initialized
INFO - 2023-06-22 07:20:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:20:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:20:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:20:11 --> Final output sent to browser
DEBUG - 2023-06-22 07:20:11 --> Total execution time: 0.1212
ERROR - 2023-06-22 07:20:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:20:14 --> Config Class Initialized
INFO - 2023-06-22 07:20:14 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:20:14 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:20:14 --> Utf8 Class Initialized
INFO - 2023-06-22 07:20:14 --> URI Class Initialized
INFO - 2023-06-22 07:20:14 --> Router Class Initialized
INFO - 2023-06-22 07:20:14 --> Output Class Initialized
INFO - 2023-06-22 07:20:14 --> Security Class Initialized
DEBUG - 2023-06-22 07:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:20:14 --> Input Class Initialized
INFO - 2023-06-22 07:20:14 --> Language Class Initialized
INFO - 2023-06-22 07:20:14 --> Loader Class Initialized
INFO - 2023-06-22 07:20:14 --> Helper loaded: url_helper
INFO - 2023-06-22 07:20:14 --> Helper loaded: file_helper
INFO - 2023-06-22 07:20:14 --> Helper loaded: html_helper
INFO - 2023-06-22 07:20:14 --> Helper loaded: text_helper
INFO - 2023-06-22 07:20:14 --> Helper loaded: form_helper
INFO - 2023-06-22 07:20:14 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:20:14 --> Helper loaded: security_helper
INFO - 2023-06-22 07:20:14 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:20:14 --> Database Driver Class Initialized
INFO - 2023-06-22 07:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:20:14 --> Parser Class Initialized
INFO - 2023-06-22 07:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:20:14 --> Pagination Class Initialized
INFO - 2023-06-22 07:20:14 --> Form Validation Class Initialized
INFO - 2023-06-22 07:20:14 --> Controller Class Initialized
INFO - 2023-06-22 07:20:14 --> Model Class Initialized
DEBUG - 2023-06-22 07:20:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:20:14 --> Model Class Initialized
INFO - 2023-06-22 07:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:20:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:20:14 --> Model Class Initialized
INFO - 2023-06-22 07:20:14 --> Model Class Initialized
INFO - 2023-06-22 07:20:14 --> Model Class Initialized
INFO - 2023-06-22 07:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:20:14 --> Final output sent to browser
DEBUG - 2023-06-22 07:20:14 --> Total execution time: 0.1247
ERROR - 2023-06-22 07:20:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:20:15 --> Config Class Initialized
INFO - 2023-06-22 07:20:15 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:20:15 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:20:15 --> Utf8 Class Initialized
INFO - 2023-06-22 07:20:15 --> URI Class Initialized
INFO - 2023-06-22 07:20:15 --> Router Class Initialized
INFO - 2023-06-22 07:20:15 --> Output Class Initialized
INFO - 2023-06-22 07:20:15 --> Security Class Initialized
DEBUG - 2023-06-22 07:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:20:15 --> Input Class Initialized
INFO - 2023-06-22 07:20:15 --> Language Class Initialized
INFO - 2023-06-22 07:20:15 --> Loader Class Initialized
INFO - 2023-06-22 07:20:15 --> Helper loaded: url_helper
INFO - 2023-06-22 07:20:15 --> Helper loaded: file_helper
INFO - 2023-06-22 07:20:15 --> Helper loaded: html_helper
INFO - 2023-06-22 07:20:15 --> Helper loaded: text_helper
INFO - 2023-06-22 07:20:15 --> Helper loaded: form_helper
INFO - 2023-06-22 07:20:15 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:20:15 --> Helper loaded: security_helper
INFO - 2023-06-22 07:20:15 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:20:15 --> Database Driver Class Initialized
INFO - 2023-06-22 07:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:20:15 --> Parser Class Initialized
INFO - 2023-06-22 07:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:20:15 --> Pagination Class Initialized
INFO - 2023-06-22 07:20:15 --> Form Validation Class Initialized
INFO - 2023-06-22 07:20:15 --> Controller Class Initialized
INFO - 2023-06-22 07:20:15 --> Model Class Initialized
DEBUG - 2023-06-22 07:20:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:20:15 --> Model Class Initialized
INFO - 2023-06-22 07:20:15 --> Final output sent to browser
DEBUG - 2023-06-22 07:20:15 --> Total execution time: 0.0310
ERROR - 2023-06-22 07:20:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:20:43 --> Config Class Initialized
INFO - 2023-06-22 07:20:43 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:20:43 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:20:43 --> Utf8 Class Initialized
INFO - 2023-06-22 07:20:43 --> URI Class Initialized
INFO - 2023-06-22 07:20:43 --> Router Class Initialized
INFO - 2023-06-22 07:20:43 --> Output Class Initialized
INFO - 2023-06-22 07:20:43 --> Security Class Initialized
DEBUG - 2023-06-22 07:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:20:43 --> Input Class Initialized
INFO - 2023-06-22 07:20:43 --> Language Class Initialized
INFO - 2023-06-22 07:20:43 --> Loader Class Initialized
INFO - 2023-06-22 07:20:43 --> Helper loaded: url_helper
INFO - 2023-06-22 07:20:43 --> Helper loaded: file_helper
INFO - 2023-06-22 07:20:43 --> Helper loaded: html_helper
INFO - 2023-06-22 07:20:43 --> Helper loaded: text_helper
INFO - 2023-06-22 07:20:43 --> Helper loaded: form_helper
INFO - 2023-06-22 07:20:43 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:20:43 --> Helper loaded: security_helper
INFO - 2023-06-22 07:20:43 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:20:43 --> Database Driver Class Initialized
INFO - 2023-06-22 07:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:20:43 --> Parser Class Initialized
INFO - 2023-06-22 07:20:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:20:43 --> Pagination Class Initialized
INFO - 2023-06-22 07:20:43 --> Form Validation Class Initialized
INFO - 2023-06-22 07:20:43 --> Controller Class Initialized
INFO - 2023-06-22 07:20:43 --> Model Class Initialized
DEBUG - 2023-06-22 07:20:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:20:43 --> Model Class Initialized
INFO - 2023-06-22 07:20:43 --> Final output sent to browser
DEBUG - 2023-06-22 07:20:43 --> Total execution time: 0.0424
ERROR - 2023-06-22 07:23:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:23:40 --> Config Class Initialized
INFO - 2023-06-22 07:23:40 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:23:40 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:23:40 --> Utf8 Class Initialized
INFO - 2023-06-22 07:23:40 --> URI Class Initialized
INFO - 2023-06-22 07:23:40 --> Router Class Initialized
INFO - 2023-06-22 07:23:40 --> Output Class Initialized
INFO - 2023-06-22 07:23:40 --> Security Class Initialized
DEBUG - 2023-06-22 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:23:40 --> Input Class Initialized
INFO - 2023-06-22 07:23:40 --> Language Class Initialized
INFO - 2023-06-22 07:23:40 --> Loader Class Initialized
INFO - 2023-06-22 07:23:40 --> Helper loaded: url_helper
INFO - 2023-06-22 07:23:40 --> Helper loaded: file_helper
INFO - 2023-06-22 07:23:40 --> Helper loaded: html_helper
INFO - 2023-06-22 07:23:40 --> Helper loaded: text_helper
INFO - 2023-06-22 07:23:40 --> Helper loaded: form_helper
INFO - 2023-06-22 07:23:40 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:23:40 --> Helper loaded: security_helper
INFO - 2023-06-22 07:23:40 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:23:40 --> Database Driver Class Initialized
INFO - 2023-06-22 07:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:23:40 --> Parser Class Initialized
INFO - 2023-06-22 07:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:23:40 --> Pagination Class Initialized
INFO - 2023-06-22 07:23:40 --> Form Validation Class Initialized
INFO - 2023-06-22 07:23:40 --> Controller Class Initialized
INFO - 2023-06-22 07:23:40 --> Model Class Initialized
DEBUG - 2023-06-22 07:23:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:23:40 --> Model Class Initialized
DEBUG - 2023-06-22 07:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-06-22 07:23:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:23:40 --> Model Class Initialized
INFO - 2023-06-22 07:23:40 --> Model Class Initialized
INFO - 2023-06-22 07:23:40 --> Model Class Initialized
INFO - 2023-06-22 07:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:23:40 --> Final output sent to browser
DEBUG - 2023-06-22 07:23:40 --> Total execution time: 0.1389
ERROR - 2023-06-22 07:25:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:12 --> Config Class Initialized
INFO - 2023-06-22 07:25:12 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:12 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:12 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:12 --> URI Class Initialized
INFO - 2023-06-22 07:25:12 --> Router Class Initialized
INFO - 2023-06-22 07:25:12 --> Output Class Initialized
INFO - 2023-06-22 07:25:12 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:12 --> Input Class Initialized
INFO - 2023-06-22 07:25:12 --> Language Class Initialized
INFO - 2023-06-22 07:25:12 --> Loader Class Initialized
INFO - 2023-06-22 07:25:12 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:12 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:12 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:12 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:12 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:12 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:12 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:12 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:12 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:12 --> Parser Class Initialized
INFO - 2023-06-22 07:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:12 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:12 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:12 --> Controller Class Initialized
INFO - 2023-06-22 07:25:12 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:12 --> Model Class Initialized
INFO - 2023-06-22 07:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-06-22 07:25:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:25:12 --> Model Class Initialized
INFO - 2023-06-22 07:25:12 --> Model Class Initialized
INFO - 2023-06-22 07:25:12 --> Model Class Initialized
INFO - 2023-06-22 07:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:25:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:25:12 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:12 --> Total execution time: 0.1197
ERROR - 2023-06-22 07:25:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:13 --> Config Class Initialized
INFO - 2023-06-22 07:25:13 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:13 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:13 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:13 --> URI Class Initialized
INFO - 2023-06-22 07:25:13 --> Router Class Initialized
INFO - 2023-06-22 07:25:13 --> Output Class Initialized
INFO - 2023-06-22 07:25:13 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:13 --> Input Class Initialized
INFO - 2023-06-22 07:25:13 --> Language Class Initialized
INFO - 2023-06-22 07:25:13 --> Loader Class Initialized
INFO - 2023-06-22 07:25:13 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:13 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:13 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:13 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:13 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:13 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:13 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:13 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:13 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:13 --> Parser Class Initialized
INFO - 2023-06-22 07:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:13 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:13 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:13 --> Controller Class Initialized
INFO - 2023-06-22 07:25:13 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:13 --> Model Class Initialized
INFO - 2023-06-22 07:25:13 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:13 --> Total execution time: 0.0185
ERROR - 2023-06-22 07:25:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:16 --> Config Class Initialized
INFO - 2023-06-22 07:25:16 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:16 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:16 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:16 --> URI Class Initialized
INFO - 2023-06-22 07:25:16 --> Router Class Initialized
INFO - 2023-06-22 07:25:16 --> Output Class Initialized
INFO - 2023-06-22 07:25:16 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:16 --> Input Class Initialized
INFO - 2023-06-22 07:25:16 --> Language Class Initialized
INFO - 2023-06-22 07:25:16 --> Loader Class Initialized
INFO - 2023-06-22 07:25:16 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:16 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:16 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:16 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:16 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:16 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:16 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:16 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:16 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:16 --> Parser Class Initialized
INFO - 2023-06-22 07:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:16 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:16 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:16 --> Controller Class Initialized
INFO - 2023-06-22 07:25:16 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:16 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:25:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:25:16 --> Model Class Initialized
INFO - 2023-06-22 07:25:16 --> Model Class Initialized
INFO - 2023-06-22 07:25:16 --> Model Class Initialized
INFO - 2023-06-22 07:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:25:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:25:16 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:16 --> Total execution time: 0.1150
ERROR - 2023-06-22 07:25:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:22 --> Config Class Initialized
INFO - 2023-06-22 07:25:22 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:22 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:22 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:22 --> URI Class Initialized
INFO - 2023-06-22 07:25:22 --> Router Class Initialized
INFO - 2023-06-22 07:25:22 --> Output Class Initialized
INFO - 2023-06-22 07:25:22 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:22 --> Input Class Initialized
INFO - 2023-06-22 07:25:22 --> Language Class Initialized
INFO - 2023-06-22 07:25:23 --> Loader Class Initialized
INFO - 2023-06-22 07:25:23 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:23 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:23 --> Parser Class Initialized
INFO - 2023-06-22 07:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:23 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:23 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:23 --> Controller Class Initialized
INFO - 2023-06-22 07:25:23 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:23 --> Model Class Initialized
INFO - 2023-06-22 07:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-06-22 07:25:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:25:23 --> Model Class Initialized
INFO - 2023-06-22 07:25:23 --> Model Class Initialized
INFO - 2023-06-22 07:25:23 --> Model Class Initialized
INFO - 2023-06-22 07:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:25:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:25:23 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:23 --> Total execution time: 0.1428
ERROR - 2023-06-22 07:25:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:23 --> Config Class Initialized
INFO - 2023-06-22 07:25:23 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:23 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:23 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:23 --> URI Class Initialized
INFO - 2023-06-22 07:25:23 --> Router Class Initialized
INFO - 2023-06-22 07:25:23 --> Output Class Initialized
INFO - 2023-06-22 07:25:23 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:23 --> Input Class Initialized
INFO - 2023-06-22 07:25:23 --> Language Class Initialized
INFO - 2023-06-22 07:25:23 --> Loader Class Initialized
INFO - 2023-06-22 07:25:23 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:23 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:23 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:23 --> Parser Class Initialized
INFO - 2023-06-22 07:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:23 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:23 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:23 --> Controller Class Initialized
INFO - 2023-06-22 07:25:23 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:23 --> Model Class Initialized
INFO - 2023-06-22 07:25:23 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:23 --> Total execution time: 0.0189
ERROR - 2023-06-22 07:25:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:27 --> Config Class Initialized
INFO - 2023-06-22 07:25:27 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:27 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:27 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:27 --> URI Class Initialized
INFO - 2023-06-22 07:25:27 --> Router Class Initialized
INFO - 2023-06-22 07:25:27 --> Output Class Initialized
INFO - 2023-06-22 07:25:27 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:27 --> Input Class Initialized
INFO - 2023-06-22 07:25:27 --> Language Class Initialized
INFO - 2023-06-22 07:25:27 --> Loader Class Initialized
INFO - 2023-06-22 07:25:27 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:27 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:27 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:27 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:27 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:27 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:27 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:27 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:27 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:27 --> Parser Class Initialized
INFO - 2023-06-22 07:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:27 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:27 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:27 --> Controller Class Initialized
INFO - 2023-06-22 07:25:27 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:27 --> Model Class Initialized
ERROR - 2023-06-22 07:25:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:28 --> Config Class Initialized
INFO - 2023-06-22 07:25:28 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:28 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:28 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:28 --> URI Class Initialized
INFO - 2023-06-22 07:25:28 --> Router Class Initialized
INFO - 2023-06-22 07:25:28 --> Output Class Initialized
INFO - 2023-06-22 07:25:28 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:28 --> Input Class Initialized
INFO - 2023-06-22 07:25:28 --> Language Class Initialized
INFO - 2023-06-22 07:25:28 --> Loader Class Initialized
INFO - 2023-06-22 07:25:28 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:28 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:28 --> Parser Class Initialized
INFO - 2023-06-22 07:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:28 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:28 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:28 --> Controller Class Initialized
INFO - 2023-06-22 07:25:28 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:28 --> Model Class Initialized
INFO - 2023-06-22 07:25:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-06-22 07:25:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:25:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:25:28 --> Model Class Initialized
INFO - 2023-06-22 07:25:28 --> Model Class Initialized
INFO - 2023-06-22 07:25:28 --> Model Class Initialized
INFO - 2023-06-22 07:25:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:25:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:25:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:25:28 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:28 --> Total execution time: 0.1248
ERROR - 2023-06-22 07:25:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:28 --> Config Class Initialized
INFO - 2023-06-22 07:25:28 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:28 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:28 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:28 --> URI Class Initialized
INFO - 2023-06-22 07:25:28 --> Router Class Initialized
INFO - 2023-06-22 07:25:28 --> Output Class Initialized
INFO - 2023-06-22 07:25:28 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:28 --> Input Class Initialized
INFO - 2023-06-22 07:25:28 --> Language Class Initialized
INFO - 2023-06-22 07:25:28 --> Loader Class Initialized
INFO - 2023-06-22 07:25:28 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:28 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:28 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:28 --> Parser Class Initialized
INFO - 2023-06-22 07:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:28 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:28 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:28 --> Controller Class Initialized
INFO - 2023-06-22 07:25:28 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:28 --> Model Class Initialized
INFO - 2023-06-22 07:25:28 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:28 --> Total execution time: 0.0149
ERROR - 2023-06-22 07:25:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:33 --> Config Class Initialized
INFO - 2023-06-22 07:25:33 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:33 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:33 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:33 --> URI Class Initialized
INFO - 2023-06-22 07:25:33 --> Router Class Initialized
INFO - 2023-06-22 07:25:33 --> Output Class Initialized
INFO - 2023-06-22 07:25:33 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:33 --> Input Class Initialized
INFO - 2023-06-22 07:25:33 --> Language Class Initialized
INFO - 2023-06-22 07:25:33 --> Loader Class Initialized
INFO - 2023-06-22 07:25:33 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:33 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:33 --> Parser Class Initialized
INFO - 2023-06-22 07:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:33 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:33 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:33 --> Controller Class Initialized
INFO - 2023-06-22 07:25:33 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:33 --> Model Class Initialized
INFO - 2023-06-22 07:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:25:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:25:33 --> Model Class Initialized
INFO - 2023-06-22 07:25:33 --> Model Class Initialized
INFO - 2023-06-22 07:25:33 --> Model Class Initialized
INFO - 2023-06-22 07:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:25:33 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:33 --> Total execution time: 0.1156
ERROR - 2023-06-22 07:25:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:33 --> Config Class Initialized
INFO - 2023-06-22 07:25:33 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:33 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:33 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:33 --> URI Class Initialized
INFO - 2023-06-22 07:25:33 --> Router Class Initialized
INFO - 2023-06-22 07:25:33 --> Output Class Initialized
INFO - 2023-06-22 07:25:33 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:33 --> Input Class Initialized
INFO - 2023-06-22 07:25:33 --> Language Class Initialized
INFO - 2023-06-22 07:25:33 --> Loader Class Initialized
INFO - 2023-06-22 07:25:33 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:33 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:33 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:33 --> Parser Class Initialized
INFO - 2023-06-22 07:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:33 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:33 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:33 --> Controller Class Initialized
INFO - 2023-06-22 07:25:33 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:33 --> Model Class Initialized
INFO - 2023-06-22 07:25:33 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:33 --> Total execution time: 0.0303
ERROR - 2023-06-22 07:25:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:43 --> Config Class Initialized
INFO - 2023-06-22 07:25:43 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:43 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:43 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:43 --> URI Class Initialized
INFO - 2023-06-22 07:25:43 --> Router Class Initialized
INFO - 2023-06-22 07:25:43 --> Output Class Initialized
INFO - 2023-06-22 07:25:43 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:43 --> Input Class Initialized
INFO - 2023-06-22 07:25:43 --> Language Class Initialized
INFO - 2023-06-22 07:25:43 --> Loader Class Initialized
INFO - 2023-06-22 07:25:43 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:43 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:43 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:43 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:43 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:43 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:43 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:43 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:43 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:43 --> Parser Class Initialized
INFO - 2023-06-22 07:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:43 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:43 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:43 --> Controller Class Initialized
INFO - 2023-06-22 07:25:43 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:43 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:25:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:25:43 --> Model Class Initialized
INFO - 2023-06-22 07:25:43 --> Model Class Initialized
INFO - 2023-06-22 07:25:43 --> Model Class Initialized
INFO - 2023-06-22 07:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:25:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:25:43 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:43 --> Total execution time: 0.1144
ERROR - 2023-06-22 07:25:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:46 --> Config Class Initialized
INFO - 2023-06-22 07:25:46 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:46 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:46 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:46 --> URI Class Initialized
INFO - 2023-06-22 07:25:46 --> Router Class Initialized
INFO - 2023-06-22 07:25:46 --> Output Class Initialized
INFO - 2023-06-22 07:25:46 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:46 --> Input Class Initialized
INFO - 2023-06-22 07:25:46 --> Language Class Initialized
INFO - 2023-06-22 07:25:46 --> Loader Class Initialized
INFO - 2023-06-22 07:25:46 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:46 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:46 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:46 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:46 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:46 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:46 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:46 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:46 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:46 --> Parser Class Initialized
INFO - 2023-06-22 07:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:46 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:46 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:46 --> Controller Class Initialized
INFO - 2023-06-22 07:25:46 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:46 --> Model Class Initialized
INFO - 2023-06-22 07:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:25:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:25:46 --> Model Class Initialized
INFO - 2023-06-22 07:25:46 --> Model Class Initialized
INFO - 2023-06-22 07:25:46 --> Model Class Initialized
INFO - 2023-06-22 07:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:25:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:25:46 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:46 --> Total execution time: 0.1141
ERROR - 2023-06-22 07:25:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:47 --> Config Class Initialized
INFO - 2023-06-22 07:25:47 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:47 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:47 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:47 --> URI Class Initialized
INFO - 2023-06-22 07:25:47 --> Router Class Initialized
INFO - 2023-06-22 07:25:47 --> Output Class Initialized
INFO - 2023-06-22 07:25:47 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:47 --> Input Class Initialized
INFO - 2023-06-22 07:25:47 --> Language Class Initialized
INFO - 2023-06-22 07:25:47 --> Loader Class Initialized
INFO - 2023-06-22 07:25:47 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:47 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:47 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:47 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:47 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:47 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:47 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:47 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:47 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:47 --> Parser Class Initialized
INFO - 2023-06-22 07:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:47 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:47 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:47 --> Controller Class Initialized
INFO - 2023-06-22 07:25:47 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:47 --> Model Class Initialized
INFO - 2023-06-22 07:25:47 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:47 --> Total execution time: 0.0316
ERROR - 2023-06-22 07:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:51 --> Config Class Initialized
INFO - 2023-06-22 07:25:51 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:51 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:51 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:51 --> URI Class Initialized
INFO - 2023-06-22 07:25:51 --> Router Class Initialized
INFO - 2023-06-22 07:25:51 --> Output Class Initialized
INFO - 2023-06-22 07:25:51 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:51 --> Input Class Initialized
INFO - 2023-06-22 07:25:51 --> Language Class Initialized
INFO - 2023-06-22 07:25:51 --> Loader Class Initialized
INFO - 2023-06-22 07:25:51 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:51 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:51 --> Parser Class Initialized
INFO - 2023-06-22 07:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:51 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:51 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:51 --> Controller Class Initialized
INFO - 2023-06-22 07:25:51 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:51 --> Model Class Initialized
ERROR - 2023-06-22 07:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:51 --> Config Class Initialized
INFO - 2023-06-22 07:25:51 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:51 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:51 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:51 --> URI Class Initialized
INFO - 2023-06-22 07:25:51 --> Router Class Initialized
INFO - 2023-06-22 07:25:51 --> Output Class Initialized
INFO - 2023-06-22 07:25:51 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:51 --> Input Class Initialized
INFO - 2023-06-22 07:25:51 --> Language Class Initialized
INFO - 2023-06-22 07:25:51 --> Loader Class Initialized
INFO - 2023-06-22 07:25:51 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:51 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:51 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:51 --> Parser Class Initialized
INFO - 2023-06-22 07:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:51 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:51 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:51 --> Controller Class Initialized
INFO - 2023-06-22 07:25:51 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:51 --> Model Class Initialized
INFO - 2023-06-22 07:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:25:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:25:51 --> Model Class Initialized
INFO - 2023-06-22 07:25:51 --> Model Class Initialized
INFO - 2023-06-22 07:25:51 --> Model Class Initialized
INFO - 2023-06-22 07:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:25:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:25:51 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:51 --> Total execution time: 0.1310
ERROR - 2023-06-22 07:25:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:25:52 --> Config Class Initialized
INFO - 2023-06-22 07:25:52 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:25:52 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:25:52 --> Utf8 Class Initialized
INFO - 2023-06-22 07:25:52 --> URI Class Initialized
INFO - 2023-06-22 07:25:52 --> Router Class Initialized
INFO - 2023-06-22 07:25:52 --> Output Class Initialized
INFO - 2023-06-22 07:25:52 --> Security Class Initialized
DEBUG - 2023-06-22 07:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:25:52 --> Input Class Initialized
INFO - 2023-06-22 07:25:52 --> Language Class Initialized
INFO - 2023-06-22 07:25:52 --> Loader Class Initialized
INFO - 2023-06-22 07:25:52 --> Helper loaded: url_helper
INFO - 2023-06-22 07:25:52 --> Helper loaded: file_helper
INFO - 2023-06-22 07:25:52 --> Helper loaded: html_helper
INFO - 2023-06-22 07:25:52 --> Helper loaded: text_helper
INFO - 2023-06-22 07:25:52 --> Helper loaded: form_helper
INFO - 2023-06-22 07:25:52 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:25:52 --> Helper loaded: security_helper
INFO - 2023-06-22 07:25:52 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:25:52 --> Database Driver Class Initialized
INFO - 2023-06-22 07:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:25:52 --> Parser Class Initialized
INFO - 2023-06-22 07:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:25:52 --> Pagination Class Initialized
INFO - 2023-06-22 07:25:52 --> Form Validation Class Initialized
INFO - 2023-06-22 07:25:52 --> Controller Class Initialized
INFO - 2023-06-22 07:25:52 --> Model Class Initialized
DEBUG - 2023-06-22 07:25:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:25:52 --> Model Class Initialized
INFO - 2023-06-22 07:25:52 --> Final output sent to browser
DEBUG - 2023-06-22 07:25:52 --> Total execution time: 0.0331
ERROR - 2023-06-22 07:26:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:01 --> Config Class Initialized
INFO - 2023-06-22 07:26:01 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:01 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:01 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:01 --> URI Class Initialized
INFO - 2023-06-22 07:26:01 --> Router Class Initialized
INFO - 2023-06-22 07:26:01 --> Output Class Initialized
INFO - 2023-06-22 07:26:01 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:01 --> Input Class Initialized
INFO - 2023-06-22 07:26:01 --> Language Class Initialized
INFO - 2023-06-22 07:26:01 --> Loader Class Initialized
INFO - 2023-06-22 07:26:01 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:01 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:01 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:01 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:01 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:01 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:01 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:01 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:01 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:01 --> Parser Class Initialized
INFO - 2023-06-22 07:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:01 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:01 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:01 --> Controller Class Initialized
INFO - 2023-06-22 07:26:01 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:01 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-22 07:26:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:01 --> Model Class Initialized
INFO - 2023-06-22 07:26:01 --> Model Class Initialized
INFO - 2023-06-22 07:26:01 --> Model Class Initialized
INFO - 2023-06-22 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:01 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:01 --> Total execution time: 0.1275
ERROR - 2023-06-22 07:26:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:04 --> Config Class Initialized
INFO - 2023-06-22 07:26:04 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:04 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:04 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:04 --> URI Class Initialized
INFO - 2023-06-22 07:26:04 --> Router Class Initialized
INFO - 2023-06-22 07:26:04 --> Output Class Initialized
INFO - 2023-06-22 07:26:04 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:04 --> Input Class Initialized
INFO - 2023-06-22 07:26:04 --> Language Class Initialized
INFO - 2023-06-22 07:26:04 --> Loader Class Initialized
INFO - 2023-06-22 07:26:04 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:04 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:04 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:04 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:04 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:04 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:04 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:04 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:04 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:04 --> Parser Class Initialized
INFO - 2023-06-22 07:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:04 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:04 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:04 --> Controller Class Initialized
INFO - 2023-06-22 07:26:04 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:04 --> Model Class Initialized
INFO - 2023-06-22 07:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:26:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:04 --> Model Class Initialized
INFO - 2023-06-22 07:26:04 --> Model Class Initialized
INFO - 2023-06-22 07:26:04 --> Model Class Initialized
INFO - 2023-06-22 07:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:04 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:04 --> Total execution time: 0.1322
ERROR - 2023-06-22 07:26:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:05 --> Config Class Initialized
INFO - 2023-06-22 07:26:05 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:05 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:05 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:05 --> URI Class Initialized
INFO - 2023-06-22 07:26:05 --> Router Class Initialized
INFO - 2023-06-22 07:26:05 --> Output Class Initialized
INFO - 2023-06-22 07:26:05 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:05 --> Input Class Initialized
INFO - 2023-06-22 07:26:05 --> Language Class Initialized
INFO - 2023-06-22 07:26:05 --> Loader Class Initialized
INFO - 2023-06-22 07:26:05 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:05 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:05 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:05 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:05 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:05 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:05 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:05 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:05 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:05 --> Parser Class Initialized
INFO - 2023-06-22 07:26:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:05 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:05 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:05 --> Controller Class Initialized
INFO - 2023-06-22 07:26:05 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:05 --> Model Class Initialized
INFO - 2023-06-22 07:26:05 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:05 --> Total execution time: 0.0302
ERROR - 2023-06-22 07:26:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:09 --> Config Class Initialized
INFO - 2023-06-22 07:26:09 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:09 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:09 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:09 --> URI Class Initialized
INFO - 2023-06-22 07:26:09 --> Router Class Initialized
INFO - 2023-06-22 07:26:09 --> Output Class Initialized
INFO - 2023-06-22 07:26:09 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:09 --> Input Class Initialized
INFO - 2023-06-22 07:26:09 --> Language Class Initialized
INFO - 2023-06-22 07:26:09 --> Loader Class Initialized
INFO - 2023-06-22 07:26:09 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:09 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:09 --> Parser Class Initialized
INFO - 2023-06-22 07:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:09 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:09 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:09 --> Controller Class Initialized
INFO - 2023-06-22 07:26:09 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:09 --> Model Class Initialized
ERROR - 2023-06-22 07:26:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:09 --> Config Class Initialized
INFO - 2023-06-22 07:26:09 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:09 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:09 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:09 --> URI Class Initialized
INFO - 2023-06-22 07:26:09 --> Router Class Initialized
INFO - 2023-06-22 07:26:09 --> Output Class Initialized
INFO - 2023-06-22 07:26:09 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:09 --> Input Class Initialized
INFO - 2023-06-22 07:26:09 --> Language Class Initialized
INFO - 2023-06-22 07:26:09 --> Loader Class Initialized
INFO - 2023-06-22 07:26:09 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:09 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:09 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:09 --> Parser Class Initialized
INFO - 2023-06-22 07:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:09 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:09 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:09 --> Controller Class Initialized
INFO - 2023-06-22 07:26:09 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:09 --> Model Class Initialized
INFO - 2023-06-22 07:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:26:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:09 --> Model Class Initialized
INFO - 2023-06-22 07:26:09 --> Model Class Initialized
INFO - 2023-06-22 07:26:09 --> Model Class Initialized
INFO - 2023-06-22 07:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:09 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:09 --> Total execution time: 0.1388
ERROR - 2023-06-22 07:26:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:10 --> Config Class Initialized
INFO - 2023-06-22 07:26:10 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:10 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:10 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:10 --> URI Class Initialized
INFO - 2023-06-22 07:26:10 --> Router Class Initialized
INFO - 2023-06-22 07:26:10 --> Output Class Initialized
INFO - 2023-06-22 07:26:10 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:10 --> Input Class Initialized
INFO - 2023-06-22 07:26:10 --> Language Class Initialized
INFO - 2023-06-22 07:26:10 --> Loader Class Initialized
INFO - 2023-06-22 07:26:10 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:10 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:10 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:10 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:10 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:10 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:10 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:10 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:10 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:10 --> Parser Class Initialized
INFO - 2023-06-22 07:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:10 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:10 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:10 --> Controller Class Initialized
INFO - 2023-06-22 07:26:10 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:10 --> Model Class Initialized
INFO - 2023-06-22 07:26:10 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:10 --> Total execution time: 0.0292
ERROR - 2023-06-22 07:26:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:17 --> Config Class Initialized
INFO - 2023-06-22 07:26:17 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:17 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:17 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:17 --> URI Class Initialized
INFO - 2023-06-22 07:26:17 --> Router Class Initialized
INFO - 2023-06-22 07:26:17 --> Output Class Initialized
INFO - 2023-06-22 07:26:17 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:17 --> Input Class Initialized
INFO - 2023-06-22 07:26:17 --> Language Class Initialized
INFO - 2023-06-22 07:26:17 --> Loader Class Initialized
INFO - 2023-06-22 07:26:17 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:17 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:17 --> Parser Class Initialized
INFO - 2023-06-22 07:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:17 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:17 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:17 --> Controller Class Initialized
INFO - 2023-06-22 07:26:17 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:17 --> Model Class Initialized
ERROR - 2023-06-22 07:26:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:17 --> Config Class Initialized
INFO - 2023-06-22 07:26:17 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:17 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:17 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:17 --> URI Class Initialized
INFO - 2023-06-22 07:26:17 --> Router Class Initialized
INFO - 2023-06-22 07:26:17 --> Output Class Initialized
INFO - 2023-06-22 07:26:17 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:17 --> Input Class Initialized
INFO - 2023-06-22 07:26:17 --> Language Class Initialized
INFO - 2023-06-22 07:26:17 --> Loader Class Initialized
INFO - 2023-06-22 07:26:17 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:17 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:17 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:17 --> Parser Class Initialized
INFO - 2023-06-22 07:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:17 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:17 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:17 --> Controller Class Initialized
INFO - 2023-06-22 07:26:17 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:17 --> Model Class Initialized
INFO - 2023-06-22 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:26:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:17 --> Model Class Initialized
INFO - 2023-06-22 07:26:17 --> Model Class Initialized
INFO - 2023-06-22 07:26:17 --> Model Class Initialized
INFO - 2023-06-22 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:17 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:17 --> Total execution time: 0.1255
ERROR - 2023-06-22 07:26:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:18 --> Config Class Initialized
INFO - 2023-06-22 07:26:18 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:18 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:18 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:18 --> URI Class Initialized
INFO - 2023-06-22 07:26:18 --> Router Class Initialized
INFO - 2023-06-22 07:26:18 --> Output Class Initialized
INFO - 2023-06-22 07:26:18 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:18 --> Input Class Initialized
INFO - 2023-06-22 07:26:18 --> Language Class Initialized
INFO - 2023-06-22 07:26:18 --> Loader Class Initialized
INFO - 2023-06-22 07:26:18 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:18 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:18 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:18 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:18 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:18 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:18 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:18 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:18 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:18 --> Parser Class Initialized
INFO - 2023-06-22 07:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:18 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:18 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:18 --> Controller Class Initialized
INFO - 2023-06-22 07:26:18 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:18 --> Model Class Initialized
INFO - 2023-06-22 07:26:18 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:18 --> Total execution time: 0.0288
ERROR - 2023-06-22 07:26:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:25 --> Config Class Initialized
INFO - 2023-06-22 07:26:25 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:25 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:25 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:25 --> URI Class Initialized
INFO - 2023-06-22 07:26:25 --> Router Class Initialized
INFO - 2023-06-22 07:26:25 --> Output Class Initialized
INFO - 2023-06-22 07:26:25 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:25 --> Input Class Initialized
INFO - 2023-06-22 07:26:25 --> Language Class Initialized
INFO - 2023-06-22 07:26:25 --> Loader Class Initialized
INFO - 2023-06-22 07:26:25 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:25 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:25 --> Parser Class Initialized
INFO - 2023-06-22 07:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:25 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:25 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:25 --> Controller Class Initialized
INFO - 2023-06-22 07:26:25 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:25 --> Model Class Initialized
ERROR - 2023-06-22 07:26:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:25 --> Config Class Initialized
INFO - 2023-06-22 07:26:25 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:25 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:25 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:25 --> URI Class Initialized
INFO - 2023-06-22 07:26:25 --> Router Class Initialized
INFO - 2023-06-22 07:26:25 --> Output Class Initialized
INFO - 2023-06-22 07:26:25 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:25 --> Input Class Initialized
INFO - 2023-06-22 07:26:25 --> Language Class Initialized
INFO - 2023-06-22 07:26:25 --> Loader Class Initialized
INFO - 2023-06-22 07:26:25 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:25 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:25 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:25 --> Parser Class Initialized
INFO - 2023-06-22 07:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:25 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:25 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:25 --> Controller Class Initialized
INFO - 2023-06-22 07:26:25 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:25 --> Model Class Initialized
INFO - 2023-06-22 07:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:26:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:25 --> Model Class Initialized
INFO - 2023-06-22 07:26:25 --> Model Class Initialized
INFO - 2023-06-22 07:26:25 --> Model Class Initialized
INFO - 2023-06-22 07:26:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:26 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:26 --> Total execution time: 0.1457
ERROR - 2023-06-22 07:26:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:26 --> Config Class Initialized
INFO - 2023-06-22 07:26:26 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:26 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:26 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:26 --> URI Class Initialized
INFO - 2023-06-22 07:26:26 --> Router Class Initialized
INFO - 2023-06-22 07:26:26 --> Output Class Initialized
INFO - 2023-06-22 07:26:26 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:26 --> Input Class Initialized
INFO - 2023-06-22 07:26:26 --> Language Class Initialized
INFO - 2023-06-22 07:26:26 --> Loader Class Initialized
INFO - 2023-06-22 07:26:26 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:26 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:26 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:26 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:26 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:26 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:26 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:26 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:26 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:26 --> Parser Class Initialized
INFO - 2023-06-22 07:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:26 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:26 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:26 --> Controller Class Initialized
INFO - 2023-06-22 07:26:26 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:26 --> Model Class Initialized
INFO - 2023-06-22 07:26:26 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:26 --> Total execution time: 0.0327
ERROR - 2023-06-22 07:26:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:31 --> Config Class Initialized
INFO - 2023-06-22 07:26:31 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:31 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:31 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:31 --> URI Class Initialized
INFO - 2023-06-22 07:26:31 --> Router Class Initialized
INFO - 2023-06-22 07:26:31 --> Output Class Initialized
INFO - 2023-06-22 07:26:31 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:31 --> Input Class Initialized
INFO - 2023-06-22 07:26:31 --> Language Class Initialized
INFO - 2023-06-22 07:26:31 --> Loader Class Initialized
INFO - 2023-06-22 07:26:31 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:31 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:31 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:31 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:31 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:31 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:31 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:31 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:31 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:31 --> Parser Class Initialized
INFO - 2023-06-22 07:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:31 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:31 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:31 --> Controller Class Initialized
INFO - 2023-06-22 07:26:31 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:31 --> Model Class Initialized
ERROR - 2023-06-22 07:26:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:32 --> Config Class Initialized
INFO - 2023-06-22 07:26:32 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:32 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:32 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:32 --> URI Class Initialized
INFO - 2023-06-22 07:26:32 --> Router Class Initialized
INFO - 2023-06-22 07:26:32 --> Output Class Initialized
INFO - 2023-06-22 07:26:32 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:32 --> Input Class Initialized
INFO - 2023-06-22 07:26:32 --> Language Class Initialized
INFO - 2023-06-22 07:26:32 --> Loader Class Initialized
INFO - 2023-06-22 07:26:32 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:32 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:32 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:32 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:32 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:32 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:32 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:32 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:32 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:32 --> Parser Class Initialized
INFO - 2023-06-22 07:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:32 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:32 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:32 --> Controller Class Initialized
INFO - 2023-06-22 07:26:32 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:32 --> Model Class Initialized
INFO - 2023-06-22 07:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:26:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:32 --> Model Class Initialized
INFO - 2023-06-22 07:26:32 --> Model Class Initialized
INFO - 2023-06-22 07:26:32 --> Model Class Initialized
INFO - 2023-06-22 07:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:32 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:32 --> Total execution time: 0.1227
ERROR - 2023-06-22 07:26:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:33 --> Config Class Initialized
INFO - 2023-06-22 07:26:33 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:33 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:33 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:33 --> URI Class Initialized
INFO - 2023-06-22 07:26:33 --> Router Class Initialized
INFO - 2023-06-22 07:26:33 --> Output Class Initialized
INFO - 2023-06-22 07:26:33 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:33 --> Input Class Initialized
INFO - 2023-06-22 07:26:33 --> Language Class Initialized
INFO - 2023-06-22 07:26:33 --> Loader Class Initialized
INFO - 2023-06-22 07:26:33 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:33 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:33 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:33 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:33 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:33 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:33 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:33 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:33 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:33 --> Parser Class Initialized
INFO - 2023-06-22 07:26:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:33 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:33 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:33 --> Controller Class Initialized
INFO - 2023-06-22 07:26:33 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:33 --> Model Class Initialized
INFO - 2023-06-22 07:26:33 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:33 --> Total execution time: 0.0268
ERROR - 2023-06-22 07:26:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:37 --> Config Class Initialized
INFO - 2023-06-22 07:26:37 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:37 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:37 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:37 --> URI Class Initialized
INFO - 2023-06-22 07:26:37 --> Router Class Initialized
INFO - 2023-06-22 07:26:37 --> Output Class Initialized
INFO - 2023-06-22 07:26:37 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:37 --> Input Class Initialized
INFO - 2023-06-22 07:26:37 --> Language Class Initialized
INFO - 2023-06-22 07:26:37 --> Loader Class Initialized
INFO - 2023-06-22 07:26:37 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:37 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:37 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:37 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:37 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:37 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:37 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:37 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:37 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:37 --> Parser Class Initialized
INFO - 2023-06-22 07:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:37 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:37 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:37 --> Controller Class Initialized
INFO - 2023-06-22 07:26:37 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:37 --> Model Class Initialized
ERROR - 2023-06-22 07:26:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:38 --> Config Class Initialized
INFO - 2023-06-22 07:26:38 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:38 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:38 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:38 --> URI Class Initialized
INFO - 2023-06-22 07:26:38 --> Router Class Initialized
INFO - 2023-06-22 07:26:38 --> Output Class Initialized
INFO - 2023-06-22 07:26:38 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:38 --> Input Class Initialized
INFO - 2023-06-22 07:26:38 --> Language Class Initialized
INFO - 2023-06-22 07:26:38 --> Loader Class Initialized
INFO - 2023-06-22 07:26:38 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:38 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:38 --> Parser Class Initialized
INFO - 2023-06-22 07:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:38 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:38 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:38 --> Controller Class Initialized
INFO - 2023-06-22 07:26:38 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:38 --> Model Class Initialized
INFO - 2023-06-22 07:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:26:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:38 --> Model Class Initialized
INFO - 2023-06-22 07:26:38 --> Model Class Initialized
INFO - 2023-06-22 07:26:38 --> Model Class Initialized
INFO - 2023-06-22 07:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:38 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:38 --> Total execution time: 0.1362
ERROR - 2023-06-22 07:26:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:38 --> Config Class Initialized
INFO - 2023-06-22 07:26:38 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:38 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:38 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:38 --> URI Class Initialized
INFO - 2023-06-22 07:26:38 --> Router Class Initialized
INFO - 2023-06-22 07:26:38 --> Output Class Initialized
INFO - 2023-06-22 07:26:38 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:38 --> Input Class Initialized
INFO - 2023-06-22 07:26:38 --> Language Class Initialized
INFO - 2023-06-22 07:26:38 --> Loader Class Initialized
INFO - 2023-06-22 07:26:38 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:38 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:38 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:38 --> Parser Class Initialized
INFO - 2023-06-22 07:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:38 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:38 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:38 --> Controller Class Initialized
INFO - 2023-06-22 07:26:38 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:38 --> Model Class Initialized
INFO - 2023-06-22 07:26:38 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:38 --> Total execution time: 0.0284
ERROR - 2023-06-22 07:26:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:44 --> Config Class Initialized
INFO - 2023-06-22 07:26:44 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:44 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:44 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:44 --> URI Class Initialized
INFO - 2023-06-22 07:26:44 --> Router Class Initialized
INFO - 2023-06-22 07:26:44 --> Output Class Initialized
INFO - 2023-06-22 07:26:44 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:44 --> Input Class Initialized
INFO - 2023-06-22 07:26:44 --> Language Class Initialized
INFO - 2023-06-22 07:26:44 --> Loader Class Initialized
INFO - 2023-06-22 07:26:44 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:44 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:44 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:44 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:44 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:44 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:44 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:44 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:44 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:44 --> Parser Class Initialized
INFO - 2023-06-22 07:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:44 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:44 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:44 --> Controller Class Initialized
INFO - 2023-06-22 07:26:44 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:44 --> Model Class Initialized
ERROR - 2023-06-22 07:26:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:45 --> Config Class Initialized
INFO - 2023-06-22 07:26:45 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:45 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:45 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:45 --> URI Class Initialized
INFO - 2023-06-22 07:26:45 --> Router Class Initialized
INFO - 2023-06-22 07:26:45 --> Output Class Initialized
INFO - 2023-06-22 07:26:45 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:45 --> Input Class Initialized
INFO - 2023-06-22 07:26:45 --> Language Class Initialized
INFO - 2023-06-22 07:26:45 --> Loader Class Initialized
INFO - 2023-06-22 07:26:45 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:45 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:45 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:45 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:45 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:45 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:45 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:45 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:45 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:45 --> Parser Class Initialized
INFO - 2023-06-22 07:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:45 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:45 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:45 --> Controller Class Initialized
INFO - 2023-06-22 07:26:45 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:45 --> Model Class Initialized
INFO - 2023-06-22 07:26:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:26:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:45 --> Model Class Initialized
INFO - 2023-06-22 07:26:45 --> Model Class Initialized
INFO - 2023-06-22 07:26:45 --> Model Class Initialized
INFO - 2023-06-22 07:26:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:45 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:45 --> Total execution time: 0.1304
ERROR - 2023-06-22 07:26:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:46 --> Config Class Initialized
INFO - 2023-06-22 07:26:46 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:46 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:46 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:46 --> URI Class Initialized
INFO - 2023-06-22 07:26:46 --> Router Class Initialized
INFO - 2023-06-22 07:26:46 --> Output Class Initialized
INFO - 2023-06-22 07:26:46 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:46 --> Input Class Initialized
INFO - 2023-06-22 07:26:46 --> Language Class Initialized
INFO - 2023-06-22 07:26:46 --> Loader Class Initialized
INFO - 2023-06-22 07:26:46 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:46 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:46 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:46 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:46 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:46 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:46 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:46 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:46 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:46 --> Parser Class Initialized
INFO - 2023-06-22 07:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:46 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:46 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:46 --> Controller Class Initialized
INFO - 2023-06-22 07:26:46 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:46 --> Model Class Initialized
INFO - 2023-06-22 07:26:46 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:46 --> Total execution time: 0.0271
ERROR - 2023-06-22 07:26:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:50 --> Config Class Initialized
INFO - 2023-06-22 07:26:50 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:50 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:50 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:50 --> URI Class Initialized
INFO - 2023-06-22 07:26:50 --> Router Class Initialized
INFO - 2023-06-22 07:26:50 --> Output Class Initialized
INFO - 2023-06-22 07:26:50 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:50 --> Input Class Initialized
INFO - 2023-06-22 07:26:50 --> Language Class Initialized
INFO - 2023-06-22 07:26:50 --> Loader Class Initialized
INFO - 2023-06-22 07:26:50 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:50 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:50 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:50 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:50 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:50 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:50 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:50 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:50 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:50 --> Parser Class Initialized
INFO - 2023-06-22 07:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:50 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:50 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:50 --> Controller Class Initialized
INFO - 2023-06-22 07:26:50 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:50 --> Model Class Initialized
ERROR - 2023-06-22 07:26:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:51 --> Config Class Initialized
INFO - 2023-06-22 07:26:51 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:51 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:51 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:51 --> URI Class Initialized
INFO - 2023-06-22 07:26:51 --> Router Class Initialized
INFO - 2023-06-22 07:26:51 --> Output Class Initialized
INFO - 2023-06-22 07:26:51 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:51 --> Input Class Initialized
INFO - 2023-06-22 07:26:51 --> Language Class Initialized
INFO - 2023-06-22 07:26:51 --> Loader Class Initialized
INFO - 2023-06-22 07:26:51 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:51 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:51 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:51 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:51 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:51 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:51 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:51 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:51 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:51 --> Parser Class Initialized
INFO - 2023-06-22 07:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:51 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:51 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:51 --> Controller Class Initialized
INFO - 2023-06-22 07:26:51 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:51 --> Model Class Initialized
INFO - 2023-06-22 07:26:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:26:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:51 --> Model Class Initialized
INFO - 2023-06-22 07:26:51 --> Model Class Initialized
INFO - 2023-06-22 07:26:51 --> Model Class Initialized
INFO - 2023-06-22 07:26:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:51 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:51 --> Total execution time: 0.1361
ERROR - 2023-06-22 07:26:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:52 --> Config Class Initialized
INFO - 2023-06-22 07:26:52 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:52 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:52 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:52 --> URI Class Initialized
INFO - 2023-06-22 07:26:52 --> Router Class Initialized
INFO - 2023-06-22 07:26:52 --> Output Class Initialized
INFO - 2023-06-22 07:26:52 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:52 --> Input Class Initialized
INFO - 2023-06-22 07:26:52 --> Language Class Initialized
INFO - 2023-06-22 07:26:52 --> Loader Class Initialized
INFO - 2023-06-22 07:26:52 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:52 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:52 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:52 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:52 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:52 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:52 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:52 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:52 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:52 --> Parser Class Initialized
INFO - 2023-06-22 07:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:52 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:52 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:52 --> Controller Class Initialized
INFO - 2023-06-22 07:26:52 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:52 --> Model Class Initialized
INFO - 2023-06-22 07:26:52 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:52 --> Total execution time: 0.0339
ERROR - 2023-06-22 07:26:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:57 --> Config Class Initialized
INFO - 2023-06-22 07:26:57 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:57 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:57 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:57 --> URI Class Initialized
INFO - 2023-06-22 07:26:57 --> Router Class Initialized
INFO - 2023-06-22 07:26:57 --> Output Class Initialized
INFO - 2023-06-22 07:26:57 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:57 --> Input Class Initialized
INFO - 2023-06-22 07:26:57 --> Language Class Initialized
INFO - 2023-06-22 07:26:57 --> Loader Class Initialized
INFO - 2023-06-22 07:26:57 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:57 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:57 --> Parser Class Initialized
INFO - 2023-06-22 07:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:57 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:57 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:57 --> Controller Class Initialized
INFO - 2023-06-22 07:26:57 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:57 --> Model Class Initialized
ERROR - 2023-06-22 07:26:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:57 --> Config Class Initialized
INFO - 2023-06-22 07:26:57 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:57 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:57 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:57 --> URI Class Initialized
INFO - 2023-06-22 07:26:57 --> Router Class Initialized
INFO - 2023-06-22 07:26:57 --> Output Class Initialized
INFO - 2023-06-22 07:26:57 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:57 --> Input Class Initialized
INFO - 2023-06-22 07:26:57 --> Language Class Initialized
INFO - 2023-06-22 07:26:57 --> Loader Class Initialized
INFO - 2023-06-22 07:26:57 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:57 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:57 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:57 --> Parser Class Initialized
INFO - 2023-06-22 07:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:57 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:57 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:57 --> Controller Class Initialized
INFO - 2023-06-22 07:26:57 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:57 --> Model Class Initialized
INFO - 2023-06-22 07:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:26:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:26:57 --> Model Class Initialized
INFO - 2023-06-22 07:26:57 --> Model Class Initialized
INFO - 2023-06-22 07:26:57 --> Model Class Initialized
INFO - 2023-06-22 07:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:26:57 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:57 --> Total execution time: 0.1285
ERROR - 2023-06-22 07:26:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:26:58 --> Config Class Initialized
INFO - 2023-06-22 07:26:58 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:26:58 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:26:58 --> Utf8 Class Initialized
INFO - 2023-06-22 07:26:58 --> URI Class Initialized
INFO - 2023-06-22 07:26:58 --> Router Class Initialized
INFO - 2023-06-22 07:26:58 --> Output Class Initialized
INFO - 2023-06-22 07:26:58 --> Security Class Initialized
DEBUG - 2023-06-22 07:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:26:58 --> Input Class Initialized
INFO - 2023-06-22 07:26:58 --> Language Class Initialized
INFO - 2023-06-22 07:26:58 --> Loader Class Initialized
INFO - 2023-06-22 07:26:58 --> Helper loaded: url_helper
INFO - 2023-06-22 07:26:58 --> Helper loaded: file_helper
INFO - 2023-06-22 07:26:58 --> Helper loaded: html_helper
INFO - 2023-06-22 07:26:58 --> Helper loaded: text_helper
INFO - 2023-06-22 07:26:58 --> Helper loaded: form_helper
INFO - 2023-06-22 07:26:58 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:26:58 --> Helper loaded: security_helper
INFO - 2023-06-22 07:26:58 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:26:58 --> Database Driver Class Initialized
INFO - 2023-06-22 07:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:26:58 --> Parser Class Initialized
INFO - 2023-06-22 07:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:26:58 --> Pagination Class Initialized
INFO - 2023-06-22 07:26:58 --> Form Validation Class Initialized
INFO - 2023-06-22 07:26:58 --> Controller Class Initialized
INFO - 2023-06-22 07:26:58 --> Model Class Initialized
DEBUG - 2023-06-22 07:26:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:26:58 --> Model Class Initialized
INFO - 2023-06-22 07:26:58 --> Final output sent to browser
DEBUG - 2023-06-22 07:26:58 --> Total execution time: 0.0291
ERROR - 2023-06-22 07:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:03 --> Config Class Initialized
INFO - 2023-06-22 07:27:03 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:03 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:03 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:03 --> URI Class Initialized
INFO - 2023-06-22 07:27:03 --> Router Class Initialized
INFO - 2023-06-22 07:27:03 --> Output Class Initialized
INFO - 2023-06-22 07:27:03 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:03 --> Input Class Initialized
INFO - 2023-06-22 07:27:03 --> Language Class Initialized
INFO - 2023-06-22 07:27:03 --> Loader Class Initialized
INFO - 2023-06-22 07:27:03 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:03 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:03 --> Parser Class Initialized
INFO - 2023-06-22 07:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:03 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:03 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:03 --> Controller Class Initialized
INFO - 2023-06-22 07:27:03 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:03 --> Model Class Initialized
ERROR - 2023-06-22 07:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:03 --> Config Class Initialized
INFO - 2023-06-22 07:27:03 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:03 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:03 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:03 --> URI Class Initialized
INFO - 2023-06-22 07:27:03 --> Router Class Initialized
INFO - 2023-06-22 07:27:03 --> Output Class Initialized
INFO - 2023-06-22 07:27:03 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:03 --> Input Class Initialized
INFO - 2023-06-22 07:27:03 --> Language Class Initialized
INFO - 2023-06-22 07:27:03 --> Loader Class Initialized
INFO - 2023-06-22 07:27:03 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:03 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:03 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:03 --> Parser Class Initialized
INFO - 2023-06-22 07:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:03 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:03 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:03 --> Controller Class Initialized
INFO - 2023-06-22 07:27:03 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:03 --> Model Class Initialized
INFO - 2023-06-22 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:03 --> Model Class Initialized
INFO - 2023-06-22 07:27:03 --> Model Class Initialized
INFO - 2023-06-22 07:27:03 --> Model Class Initialized
INFO - 2023-06-22 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:03 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:03 --> Total execution time: 0.1593
ERROR - 2023-06-22 07:27:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:04 --> Config Class Initialized
INFO - 2023-06-22 07:27:04 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:04 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:04 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:04 --> URI Class Initialized
INFO - 2023-06-22 07:27:04 --> Router Class Initialized
INFO - 2023-06-22 07:27:04 --> Output Class Initialized
INFO - 2023-06-22 07:27:04 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:04 --> Input Class Initialized
INFO - 2023-06-22 07:27:04 --> Language Class Initialized
INFO - 2023-06-22 07:27:04 --> Loader Class Initialized
INFO - 2023-06-22 07:27:04 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:04 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:04 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:04 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:04 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:04 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:04 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:04 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:04 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:04 --> Parser Class Initialized
INFO - 2023-06-22 07:27:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:04 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:04 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:04 --> Controller Class Initialized
INFO - 2023-06-22 07:27:04 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:04 --> Model Class Initialized
INFO - 2023-06-22 07:27:04 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:04 --> Total execution time: 0.0316
ERROR - 2023-06-22 07:27:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:08 --> Config Class Initialized
INFO - 2023-06-22 07:27:08 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:08 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:08 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:08 --> URI Class Initialized
INFO - 2023-06-22 07:27:08 --> Router Class Initialized
INFO - 2023-06-22 07:27:08 --> Output Class Initialized
INFO - 2023-06-22 07:27:08 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:08 --> Input Class Initialized
INFO - 2023-06-22 07:27:08 --> Language Class Initialized
INFO - 2023-06-22 07:27:08 --> Loader Class Initialized
INFO - 2023-06-22 07:27:08 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:08 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:08 --> Parser Class Initialized
INFO - 2023-06-22 07:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:08 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:08 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:08 --> Controller Class Initialized
INFO - 2023-06-22 07:27:08 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:08 --> Model Class Initialized
ERROR - 2023-06-22 07:27:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:08 --> Config Class Initialized
INFO - 2023-06-22 07:27:08 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:08 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:08 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:08 --> URI Class Initialized
INFO - 2023-06-22 07:27:08 --> Router Class Initialized
INFO - 2023-06-22 07:27:08 --> Output Class Initialized
INFO - 2023-06-22 07:27:08 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:08 --> Input Class Initialized
INFO - 2023-06-22 07:27:08 --> Language Class Initialized
INFO - 2023-06-22 07:27:08 --> Loader Class Initialized
INFO - 2023-06-22 07:27:08 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:08 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:08 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:08 --> Parser Class Initialized
INFO - 2023-06-22 07:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:08 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:08 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:08 --> Controller Class Initialized
INFO - 2023-06-22 07:27:08 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:08 --> Model Class Initialized
INFO - 2023-06-22 07:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:08 --> Model Class Initialized
INFO - 2023-06-22 07:27:08 --> Model Class Initialized
INFO - 2023-06-22 07:27:08 --> Model Class Initialized
INFO - 2023-06-22 07:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:08 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:08 --> Total execution time: 0.1248
ERROR - 2023-06-22 07:27:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:09 --> Config Class Initialized
INFO - 2023-06-22 07:27:09 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:09 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:09 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:09 --> URI Class Initialized
INFO - 2023-06-22 07:27:09 --> Router Class Initialized
INFO - 2023-06-22 07:27:09 --> Output Class Initialized
INFO - 2023-06-22 07:27:09 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:09 --> Input Class Initialized
INFO - 2023-06-22 07:27:09 --> Language Class Initialized
INFO - 2023-06-22 07:27:09 --> Loader Class Initialized
INFO - 2023-06-22 07:27:09 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:09 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:09 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:09 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:09 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:09 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:09 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:09 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:09 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:09 --> Parser Class Initialized
INFO - 2023-06-22 07:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:09 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:09 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:09 --> Controller Class Initialized
INFO - 2023-06-22 07:27:09 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:09 --> Model Class Initialized
INFO - 2023-06-22 07:27:09 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:09 --> Total execution time: 0.0299
ERROR - 2023-06-22 07:27:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:13 --> Config Class Initialized
INFO - 2023-06-22 07:27:13 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:13 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:13 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:13 --> URI Class Initialized
INFO - 2023-06-22 07:27:13 --> Router Class Initialized
INFO - 2023-06-22 07:27:13 --> Output Class Initialized
INFO - 2023-06-22 07:27:13 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:13 --> Input Class Initialized
INFO - 2023-06-22 07:27:13 --> Language Class Initialized
INFO - 2023-06-22 07:27:13 --> Loader Class Initialized
INFO - 2023-06-22 07:27:13 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:13 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:13 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:13 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:13 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:13 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:13 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:13 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:13 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:13 --> Parser Class Initialized
INFO - 2023-06-22 07:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:13 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:13 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:13 --> Controller Class Initialized
INFO - 2023-06-22 07:27:13 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:13 --> Model Class Initialized
ERROR - 2023-06-22 07:27:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:14 --> Config Class Initialized
INFO - 2023-06-22 07:27:14 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:14 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:14 --> URI Class Initialized
INFO - 2023-06-22 07:27:14 --> Router Class Initialized
INFO - 2023-06-22 07:27:14 --> Output Class Initialized
INFO - 2023-06-22 07:27:14 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:14 --> Input Class Initialized
INFO - 2023-06-22 07:27:14 --> Language Class Initialized
INFO - 2023-06-22 07:27:14 --> Loader Class Initialized
INFO - 2023-06-22 07:27:14 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:14 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:14 --> Parser Class Initialized
INFO - 2023-06-22 07:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:14 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:14 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:14 --> Controller Class Initialized
INFO - 2023-06-22 07:27:14 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:14 --> Model Class Initialized
INFO - 2023-06-22 07:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:14 --> Model Class Initialized
INFO - 2023-06-22 07:27:14 --> Model Class Initialized
INFO - 2023-06-22 07:27:14 --> Model Class Initialized
INFO - 2023-06-22 07:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:14 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:14 --> Total execution time: 0.1278
ERROR - 2023-06-22 07:27:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:14 --> Config Class Initialized
INFO - 2023-06-22 07:27:14 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:14 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:14 --> URI Class Initialized
INFO - 2023-06-22 07:27:14 --> Router Class Initialized
INFO - 2023-06-22 07:27:14 --> Output Class Initialized
INFO - 2023-06-22 07:27:14 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:14 --> Input Class Initialized
INFO - 2023-06-22 07:27:14 --> Language Class Initialized
INFO - 2023-06-22 07:27:14 --> Loader Class Initialized
INFO - 2023-06-22 07:27:14 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:14 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:14 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:14 --> Parser Class Initialized
INFO - 2023-06-22 07:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:14 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:14 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:14 --> Controller Class Initialized
INFO - 2023-06-22 07:27:14 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:14 --> Model Class Initialized
INFO - 2023-06-22 07:27:14 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:14 --> Total execution time: 0.0263
ERROR - 2023-06-22 07:27:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:18 --> Config Class Initialized
INFO - 2023-06-22 07:27:18 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:18 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:18 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:18 --> URI Class Initialized
INFO - 2023-06-22 07:27:18 --> Router Class Initialized
INFO - 2023-06-22 07:27:18 --> Output Class Initialized
INFO - 2023-06-22 07:27:18 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:18 --> Input Class Initialized
INFO - 2023-06-22 07:27:18 --> Language Class Initialized
INFO - 2023-06-22 07:27:18 --> Loader Class Initialized
INFO - 2023-06-22 07:27:18 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:18 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:18 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:18 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:18 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:18 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:18 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:18 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:18 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:18 --> Parser Class Initialized
INFO - 2023-06-22 07:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:18 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:18 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:18 --> Controller Class Initialized
INFO - 2023-06-22 07:27:18 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:18 --> Model Class Initialized
ERROR - 2023-06-22 07:27:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:19 --> Config Class Initialized
INFO - 2023-06-22 07:27:19 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:19 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:19 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:19 --> URI Class Initialized
INFO - 2023-06-22 07:27:19 --> Router Class Initialized
INFO - 2023-06-22 07:27:19 --> Output Class Initialized
INFO - 2023-06-22 07:27:19 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:19 --> Input Class Initialized
INFO - 2023-06-22 07:27:19 --> Language Class Initialized
INFO - 2023-06-22 07:27:19 --> Loader Class Initialized
INFO - 2023-06-22 07:27:19 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:19 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:19 --> Parser Class Initialized
INFO - 2023-06-22 07:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:19 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:19 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:19 --> Controller Class Initialized
INFO - 2023-06-22 07:27:19 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:19 --> Model Class Initialized
INFO - 2023-06-22 07:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:19 --> Model Class Initialized
INFO - 2023-06-22 07:27:19 --> Model Class Initialized
INFO - 2023-06-22 07:27:19 --> Model Class Initialized
INFO - 2023-06-22 07:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:19 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:19 --> Total execution time: 0.1325
ERROR - 2023-06-22 07:27:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:19 --> Config Class Initialized
INFO - 2023-06-22 07:27:19 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:19 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:19 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:19 --> URI Class Initialized
INFO - 2023-06-22 07:27:19 --> Router Class Initialized
INFO - 2023-06-22 07:27:19 --> Output Class Initialized
INFO - 2023-06-22 07:27:19 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:19 --> Input Class Initialized
INFO - 2023-06-22 07:27:19 --> Language Class Initialized
INFO - 2023-06-22 07:27:19 --> Loader Class Initialized
INFO - 2023-06-22 07:27:19 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:19 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:19 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:19 --> Parser Class Initialized
INFO - 2023-06-22 07:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:19 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:19 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:19 --> Controller Class Initialized
INFO - 2023-06-22 07:27:19 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:19 --> Model Class Initialized
INFO - 2023-06-22 07:27:19 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:19 --> Total execution time: 0.0243
ERROR - 2023-06-22 07:27:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:25 --> Config Class Initialized
INFO - 2023-06-22 07:27:25 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:25 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:25 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:25 --> URI Class Initialized
INFO - 2023-06-22 07:27:25 --> Router Class Initialized
INFO - 2023-06-22 07:27:25 --> Output Class Initialized
INFO - 2023-06-22 07:27:25 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:25 --> Input Class Initialized
INFO - 2023-06-22 07:27:25 --> Language Class Initialized
INFO - 2023-06-22 07:27:25 --> Loader Class Initialized
INFO - 2023-06-22 07:27:25 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:25 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:25 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:25 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:25 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:25 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:25 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:25 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:25 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:25 --> Parser Class Initialized
INFO - 2023-06-22 07:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:25 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:25 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:25 --> Controller Class Initialized
INFO - 2023-06-22 07:27:25 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:25 --> Model Class Initialized
ERROR - 2023-06-22 07:27:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:26 --> Config Class Initialized
INFO - 2023-06-22 07:27:26 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:26 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:26 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:26 --> URI Class Initialized
INFO - 2023-06-22 07:27:26 --> Router Class Initialized
INFO - 2023-06-22 07:27:26 --> Output Class Initialized
INFO - 2023-06-22 07:27:26 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:26 --> Input Class Initialized
INFO - 2023-06-22 07:27:26 --> Language Class Initialized
INFO - 2023-06-22 07:27:26 --> Loader Class Initialized
INFO - 2023-06-22 07:27:26 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:26 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:26 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:26 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:26 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:26 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:26 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:26 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:26 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:26 --> Parser Class Initialized
INFO - 2023-06-22 07:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:26 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:26 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:26 --> Controller Class Initialized
INFO - 2023-06-22 07:27:26 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:26 --> Model Class Initialized
INFO - 2023-06-22 07:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:26 --> Model Class Initialized
INFO - 2023-06-22 07:27:26 --> Model Class Initialized
INFO - 2023-06-22 07:27:26 --> Model Class Initialized
INFO - 2023-06-22 07:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:26 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:26 --> Total execution time: 0.1170
ERROR - 2023-06-22 07:27:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:27 --> Config Class Initialized
INFO - 2023-06-22 07:27:27 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:27 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:27 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:27 --> URI Class Initialized
INFO - 2023-06-22 07:27:27 --> Router Class Initialized
INFO - 2023-06-22 07:27:27 --> Output Class Initialized
INFO - 2023-06-22 07:27:27 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:27 --> Input Class Initialized
INFO - 2023-06-22 07:27:27 --> Language Class Initialized
INFO - 2023-06-22 07:27:27 --> Loader Class Initialized
INFO - 2023-06-22 07:27:27 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:27 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:27 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:27 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:27 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:27 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:27 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:27 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:27 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:27 --> Parser Class Initialized
INFO - 2023-06-22 07:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:27 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:27 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:27 --> Controller Class Initialized
INFO - 2023-06-22 07:27:27 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:27 --> Model Class Initialized
INFO - 2023-06-22 07:27:27 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:27 --> Total execution time: 0.0241
ERROR - 2023-06-22 07:27:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:31 --> Config Class Initialized
INFO - 2023-06-22 07:27:31 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:31 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:31 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:31 --> URI Class Initialized
INFO - 2023-06-22 07:27:31 --> Router Class Initialized
INFO - 2023-06-22 07:27:31 --> Output Class Initialized
INFO - 2023-06-22 07:27:31 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:31 --> Input Class Initialized
INFO - 2023-06-22 07:27:31 --> Language Class Initialized
INFO - 2023-06-22 07:27:31 --> Loader Class Initialized
INFO - 2023-06-22 07:27:31 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:31 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:31 --> Parser Class Initialized
INFO - 2023-06-22 07:27:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:31 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:31 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:31 --> Controller Class Initialized
INFO - 2023-06-22 07:27:31 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:31 --> Model Class Initialized
ERROR - 2023-06-22 07:27:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:31 --> Config Class Initialized
INFO - 2023-06-22 07:27:31 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:31 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:31 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:31 --> URI Class Initialized
INFO - 2023-06-22 07:27:31 --> Router Class Initialized
INFO - 2023-06-22 07:27:31 --> Output Class Initialized
INFO - 2023-06-22 07:27:31 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:31 --> Input Class Initialized
INFO - 2023-06-22 07:27:31 --> Language Class Initialized
INFO - 2023-06-22 07:27:31 --> Loader Class Initialized
INFO - 2023-06-22 07:27:31 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:31 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:31 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:31 --> Parser Class Initialized
INFO - 2023-06-22 07:27:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:31 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:31 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:31 --> Controller Class Initialized
INFO - 2023-06-22 07:27:31 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:31 --> Model Class Initialized
INFO - 2023-06-22 07:27:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:31 --> Model Class Initialized
INFO - 2023-06-22 07:27:31 --> Model Class Initialized
INFO - 2023-06-22 07:27:31 --> Model Class Initialized
INFO - 2023-06-22 07:27:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:31 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:31 --> Total execution time: 0.1240
ERROR - 2023-06-22 07:27:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:32 --> Config Class Initialized
INFO - 2023-06-22 07:27:32 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:32 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:32 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:32 --> URI Class Initialized
INFO - 2023-06-22 07:27:32 --> Router Class Initialized
INFO - 2023-06-22 07:27:32 --> Output Class Initialized
INFO - 2023-06-22 07:27:32 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:32 --> Input Class Initialized
INFO - 2023-06-22 07:27:32 --> Language Class Initialized
INFO - 2023-06-22 07:27:32 --> Loader Class Initialized
INFO - 2023-06-22 07:27:32 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:32 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:32 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:32 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:32 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:32 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:32 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:32 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:32 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:32 --> Parser Class Initialized
INFO - 2023-06-22 07:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:32 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:32 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:32 --> Controller Class Initialized
INFO - 2023-06-22 07:27:32 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:32 --> Model Class Initialized
INFO - 2023-06-22 07:27:32 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:32 --> Total execution time: 0.0231
ERROR - 2023-06-22 07:27:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:36 --> Config Class Initialized
INFO - 2023-06-22 07:27:36 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:36 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:36 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:36 --> URI Class Initialized
INFO - 2023-06-22 07:27:36 --> Router Class Initialized
INFO - 2023-06-22 07:27:36 --> Output Class Initialized
INFO - 2023-06-22 07:27:36 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:36 --> Input Class Initialized
INFO - 2023-06-22 07:27:36 --> Language Class Initialized
INFO - 2023-06-22 07:27:36 --> Loader Class Initialized
INFO - 2023-06-22 07:27:36 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:36 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:36 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:36 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:36 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:36 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:36 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:36 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:36 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:36 --> Parser Class Initialized
INFO - 2023-06-22 07:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:36 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:36 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:36 --> Controller Class Initialized
INFO - 2023-06-22 07:27:36 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:36 --> Model Class Initialized
ERROR - 2023-06-22 07:27:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:37 --> Config Class Initialized
INFO - 2023-06-22 07:27:37 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:37 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:37 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:37 --> URI Class Initialized
INFO - 2023-06-22 07:27:37 --> Router Class Initialized
INFO - 2023-06-22 07:27:37 --> Output Class Initialized
INFO - 2023-06-22 07:27:37 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:37 --> Input Class Initialized
INFO - 2023-06-22 07:27:37 --> Language Class Initialized
INFO - 2023-06-22 07:27:37 --> Loader Class Initialized
INFO - 2023-06-22 07:27:37 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:37 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:37 --> Parser Class Initialized
INFO - 2023-06-22 07:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:37 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:37 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:37 --> Controller Class Initialized
INFO - 2023-06-22 07:27:37 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:37 --> Model Class Initialized
INFO - 2023-06-22 07:27:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:37 --> Model Class Initialized
INFO - 2023-06-22 07:27:37 --> Model Class Initialized
INFO - 2023-06-22 07:27:37 --> Model Class Initialized
INFO - 2023-06-22 07:27:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:37 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:37 --> Total execution time: 0.1200
ERROR - 2023-06-22 07:27:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:37 --> Config Class Initialized
INFO - 2023-06-22 07:27:37 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:37 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:37 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:37 --> URI Class Initialized
INFO - 2023-06-22 07:27:37 --> Router Class Initialized
INFO - 2023-06-22 07:27:37 --> Output Class Initialized
INFO - 2023-06-22 07:27:37 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:37 --> Input Class Initialized
INFO - 2023-06-22 07:27:37 --> Language Class Initialized
INFO - 2023-06-22 07:27:37 --> Loader Class Initialized
INFO - 2023-06-22 07:27:37 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:37 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:37 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:37 --> Parser Class Initialized
INFO - 2023-06-22 07:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:37 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:37 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:37 --> Controller Class Initialized
INFO - 2023-06-22 07:27:37 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:37 --> Model Class Initialized
INFO - 2023-06-22 07:27:37 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:37 --> Total execution time: 0.0223
ERROR - 2023-06-22 07:27:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:42 --> Config Class Initialized
INFO - 2023-06-22 07:27:42 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:42 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:42 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:42 --> URI Class Initialized
INFO - 2023-06-22 07:27:42 --> Router Class Initialized
INFO - 2023-06-22 07:27:42 --> Output Class Initialized
INFO - 2023-06-22 07:27:42 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:42 --> Input Class Initialized
INFO - 2023-06-22 07:27:42 --> Language Class Initialized
INFO - 2023-06-22 07:27:42 --> Loader Class Initialized
INFO - 2023-06-22 07:27:42 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:42 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:42 --> Parser Class Initialized
INFO - 2023-06-22 07:27:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:42 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:42 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:42 --> Controller Class Initialized
INFO - 2023-06-22 07:27:42 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:42 --> Model Class Initialized
ERROR - 2023-06-22 07:27:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:42 --> Config Class Initialized
INFO - 2023-06-22 07:27:42 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:42 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:42 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:42 --> URI Class Initialized
INFO - 2023-06-22 07:27:42 --> Router Class Initialized
INFO - 2023-06-22 07:27:42 --> Output Class Initialized
INFO - 2023-06-22 07:27:42 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:42 --> Input Class Initialized
INFO - 2023-06-22 07:27:42 --> Language Class Initialized
INFO - 2023-06-22 07:27:42 --> Loader Class Initialized
INFO - 2023-06-22 07:27:42 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:42 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:42 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:42 --> Parser Class Initialized
INFO - 2023-06-22 07:27:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:42 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:42 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:42 --> Controller Class Initialized
INFO - 2023-06-22 07:27:42 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:42 --> Model Class Initialized
INFO - 2023-06-22 07:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:42 --> Model Class Initialized
INFO - 2023-06-22 07:27:42 --> Model Class Initialized
INFO - 2023-06-22 07:27:42 --> Model Class Initialized
INFO - 2023-06-22 07:27:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:43 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:43 --> Total execution time: 0.1147
ERROR - 2023-06-22 07:27:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:43 --> Config Class Initialized
INFO - 2023-06-22 07:27:43 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:43 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:43 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:43 --> URI Class Initialized
INFO - 2023-06-22 07:27:43 --> Router Class Initialized
INFO - 2023-06-22 07:27:43 --> Output Class Initialized
INFO - 2023-06-22 07:27:43 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:43 --> Input Class Initialized
INFO - 2023-06-22 07:27:43 --> Language Class Initialized
INFO - 2023-06-22 07:27:43 --> Loader Class Initialized
INFO - 2023-06-22 07:27:43 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:43 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:43 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:43 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:43 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:43 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:43 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:43 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:43 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:43 --> Parser Class Initialized
INFO - 2023-06-22 07:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:43 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:43 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:43 --> Controller Class Initialized
INFO - 2023-06-22 07:27:43 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:43 --> Model Class Initialized
INFO - 2023-06-22 07:27:43 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:43 --> Total execution time: 0.0209
ERROR - 2023-06-22 07:27:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:47 --> Config Class Initialized
INFO - 2023-06-22 07:27:47 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:47 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:47 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:47 --> URI Class Initialized
INFO - 2023-06-22 07:27:47 --> Router Class Initialized
INFO - 2023-06-22 07:27:47 --> Output Class Initialized
INFO - 2023-06-22 07:27:47 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:47 --> Input Class Initialized
INFO - 2023-06-22 07:27:47 --> Language Class Initialized
INFO - 2023-06-22 07:27:47 --> Loader Class Initialized
INFO - 2023-06-22 07:27:47 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:47 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:47 --> Parser Class Initialized
INFO - 2023-06-22 07:27:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:47 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:47 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:47 --> Controller Class Initialized
INFO - 2023-06-22 07:27:47 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:47 --> Model Class Initialized
ERROR - 2023-06-22 07:27:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:47 --> Config Class Initialized
INFO - 2023-06-22 07:27:47 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:47 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:47 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:47 --> URI Class Initialized
INFO - 2023-06-22 07:27:47 --> Router Class Initialized
INFO - 2023-06-22 07:27:47 --> Output Class Initialized
INFO - 2023-06-22 07:27:47 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:47 --> Input Class Initialized
INFO - 2023-06-22 07:27:47 --> Language Class Initialized
INFO - 2023-06-22 07:27:47 --> Loader Class Initialized
INFO - 2023-06-22 07:27:47 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:47 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:48 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:48 --> Parser Class Initialized
INFO - 2023-06-22 07:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:48 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:48 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:48 --> Controller Class Initialized
INFO - 2023-06-22 07:27:48 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:48 --> Model Class Initialized
INFO - 2023-06-22 07:27:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:48 --> Model Class Initialized
INFO - 2023-06-22 07:27:48 --> Model Class Initialized
INFO - 2023-06-22 07:27:48 --> Model Class Initialized
INFO - 2023-06-22 07:27:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:48 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:48 --> Total execution time: 0.1202
ERROR - 2023-06-22 07:27:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:48 --> Config Class Initialized
INFO - 2023-06-22 07:27:48 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:48 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:48 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:48 --> URI Class Initialized
INFO - 2023-06-22 07:27:48 --> Router Class Initialized
INFO - 2023-06-22 07:27:48 --> Output Class Initialized
INFO - 2023-06-22 07:27:48 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:48 --> Input Class Initialized
INFO - 2023-06-22 07:27:48 --> Language Class Initialized
INFO - 2023-06-22 07:27:48 --> Loader Class Initialized
INFO - 2023-06-22 07:27:48 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:48 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:48 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:48 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:48 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:48 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:48 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:48 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:48 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:48 --> Parser Class Initialized
INFO - 2023-06-22 07:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:48 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:48 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:48 --> Controller Class Initialized
INFO - 2023-06-22 07:27:48 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:48 --> Model Class Initialized
INFO - 2023-06-22 07:27:48 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:48 --> Total execution time: 0.0196
ERROR - 2023-06-22 07:27:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:52 --> Config Class Initialized
INFO - 2023-06-22 07:27:52 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:52 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:52 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:52 --> URI Class Initialized
INFO - 2023-06-22 07:27:52 --> Router Class Initialized
INFO - 2023-06-22 07:27:52 --> Output Class Initialized
INFO - 2023-06-22 07:27:52 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:52 --> Input Class Initialized
INFO - 2023-06-22 07:27:52 --> Language Class Initialized
INFO - 2023-06-22 07:27:52 --> Loader Class Initialized
INFO - 2023-06-22 07:27:52 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:52 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:52 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:52 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:52 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:52 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:52 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:52 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:52 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:52 --> Parser Class Initialized
INFO - 2023-06-22 07:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:52 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:52 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:52 --> Controller Class Initialized
INFO - 2023-06-22 07:27:52 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:52 --> Model Class Initialized
ERROR - 2023-06-22 07:27:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:53 --> Config Class Initialized
INFO - 2023-06-22 07:27:53 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:53 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:53 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:53 --> URI Class Initialized
INFO - 2023-06-22 07:27:53 --> Router Class Initialized
INFO - 2023-06-22 07:27:53 --> Output Class Initialized
INFO - 2023-06-22 07:27:53 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:53 --> Input Class Initialized
INFO - 2023-06-22 07:27:53 --> Language Class Initialized
INFO - 2023-06-22 07:27:53 --> Loader Class Initialized
INFO - 2023-06-22 07:27:53 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:53 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:53 --> Parser Class Initialized
INFO - 2023-06-22 07:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:53 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:53 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:53 --> Controller Class Initialized
INFO - 2023-06-22 07:27:53 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:53 --> Model Class Initialized
INFO - 2023-06-22 07:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:53 --> Model Class Initialized
INFO - 2023-06-22 07:27:53 --> Model Class Initialized
INFO - 2023-06-22 07:27:53 --> Model Class Initialized
INFO - 2023-06-22 07:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:53 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:53 --> Total execution time: 0.1250
ERROR - 2023-06-22 07:27:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:53 --> Config Class Initialized
INFO - 2023-06-22 07:27:53 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:53 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:53 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:53 --> URI Class Initialized
INFO - 2023-06-22 07:27:53 --> Router Class Initialized
INFO - 2023-06-22 07:27:53 --> Output Class Initialized
INFO - 2023-06-22 07:27:53 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:53 --> Input Class Initialized
INFO - 2023-06-22 07:27:53 --> Language Class Initialized
INFO - 2023-06-22 07:27:53 --> Loader Class Initialized
INFO - 2023-06-22 07:27:53 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:53 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:53 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:53 --> Parser Class Initialized
INFO - 2023-06-22 07:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:53 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:53 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:53 --> Controller Class Initialized
INFO - 2023-06-22 07:27:53 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:53 --> Model Class Initialized
INFO - 2023-06-22 07:27:53 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:53 --> Total execution time: 0.0179
ERROR - 2023-06-22 07:27:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:58 --> Config Class Initialized
INFO - 2023-06-22 07:27:58 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:58 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:58 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:58 --> URI Class Initialized
INFO - 2023-06-22 07:27:58 --> Router Class Initialized
INFO - 2023-06-22 07:27:58 --> Output Class Initialized
INFO - 2023-06-22 07:27:58 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:58 --> Input Class Initialized
INFO - 2023-06-22 07:27:58 --> Language Class Initialized
INFO - 2023-06-22 07:27:58 --> Loader Class Initialized
INFO - 2023-06-22 07:27:58 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:58 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:58 --> Parser Class Initialized
INFO - 2023-06-22 07:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:58 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:58 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:58 --> Controller Class Initialized
INFO - 2023-06-22 07:27:58 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:58 --> Model Class Initialized
ERROR - 2023-06-22 07:27:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:58 --> Config Class Initialized
INFO - 2023-06-22 07:27:58 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:58 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:58 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:58 --> URI Class Initialized
INFO - 2023-06-22 07:27:58 --> Router Class Initialized
INFO - 2023-06-22 07:27:58 --> Output Class Initialized
INFO - 2023-06-22 07:27:58 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:58 --> Input Class Initialized
INFO - 2023-06-22 07:27:58 --> Language Class Initialized
INFO - 2023-06-22 07:27:58 --> Loader Class Initialized
INFO - 2023-06-22 07:27:58 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:58 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:58 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:58 --> Parser Class Initialized
INFO - 2023-06-22 07:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:58 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:58 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:58 --> Controller Class Initialized
INFO - 2023-06-22 07:27:58 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:58 --> Model Class Initialized
INFO - 2023-06-22 07:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:27:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:27:58 --> Model Class Initialized
INFO - 2023-06-22 07:27:58 --> Model Class Initialized
INFO - 2023-06-22 07:27:58 --> Model Class Initialized
INFO - 2023-06-22 07:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:27:58 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:58 --> Total execution time: 0.1486
ERROR - 2023-06-22 07:27:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:27:59 --> Config Class Initialized
INFO - 2023-06-22 07:27:59 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:27:59 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:27:59 --> Utf8 Class Initialized
INFO - 2023-06-22 07:27:59 --> URI Class Initialized
INFO - 2023-06-22 07:27:59 --> Router Class Initialized
INFO - 2023-06-22 07:27:59 --> Output Class Initialized
INFO - 2023-06-22 07:27:59 --> Security Class Initialized
DEBUG - 2023-06-22 07:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:27:59 --> Input Class Initialized
INFO - 2023-06-22 07:27:59 --> Language Class Initialized
INFO - 2023-06-22 07:27:59 --> Loader Class Initialized
INFO - 2023-06-22 07:27:59 --> Helper loaded: url_helper
INFO - 2023-06-22 07:27:59 --> Helper loaded: file_helper
INFO - 2023-06-22 07:27:59 --> Helper loaded: html_helper
INFO - 2023-06-22 07:27:59 --> Helper loaded: text_helper
INFO - 2023-06-22 07:27:59 --> Helper loaded: form_helper
INFO - 2023-06-22 07:27:59 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:27:59 --> Helper loaded: security_helper
INFO - 2023-06-22 07:27:59 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:27:59 --> Database Driver Class Initialized
INFO - 2023-06-22 07:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:27:59 --> Parser Class Initialized
INFO - 2023-06-22 07:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:27:59 --> Pagination Class Initialized
INFO - 2023-06-22 07:27:59 --> Form Validation Class Initialized
INFO - 2023-06-22 07:27:59 --> Controller Class Initialized
INFO - 2023-06-22 07:27:59 --> Model Class Initialized
DEBUG - 2023-06-22 07:27:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:27:59 --> Model Class Initialized
INFO - 2023-06-22 07:27:59 --> Final output sent to browser
DEBUG - 2023-06-22 07:27:59 --> Total execution time: 0.0216
ERROR - 2023-06-22 07:28:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:05 --> Config Class Initialized
INFO - 2023-06-22 07:28:05 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:05 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:05 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:05 --> URI Class Initialized
INFO - 2023-06-22 07:28:05 --> Router Class Initialized
INFO - 2023-06-22 07:28:05 --> Output Class Initialized
INFO - 2023-06-22 07:28:05 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:05 --> Input Class Initialized
INFO - 2023-06-22 07:28:05 --> Language Class Initialized
INFO - 2023-06-22 07:28:05 --> Loader Class Initialized
INFO - 2023-06-22 07:28:05 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:05 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:05 --> Parser Class Initialized
INFO - 2023-06-22 07:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:05 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:05 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:05 --> Controller Class Initialized
INFO - 2023-06-22 07:28:05 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:05 --> Model Class Initialized
INFO - 2023-06-22 07:28:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-06-22 07:28:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:28:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:28:05 --> Model Class Initialized
INFO - 2023-06-22 07:28:05 --> Model Class Initialized
INFO - 2023-06-22 07:28:05 --> Model Class Initialized
INFO - 2023-06-22 07:28:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:28:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:28:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:28:05 --> Final output sent to browser
DEBUG - 2023-06-22 07:28:05 --> Total execution time: 0.1206
ERROR - 2023-06-22 07:28:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:05 --> Config Class Initialized
INFO - 2023-06-22 07:28:05 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:05 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:05 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:05 --> URI Class Initialized
INFO - 2023-06-22 07:28:05 --> Router Class Initialized
INFO - 2023-06-22 07:28:05 --> Output Class Initialized
INFO - 2023-06-22 07:28:05 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:05 --> Input Class Initialized
INFO - 2023-06-22 07:28:05 --> Language Class Initialized
INFO - 2023-06-22 07:28:05 --> Loader Class Initialized
INFO - 2023-06-22 07:28:05 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:05 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:05 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:05 --> Parser Class Initialized
INFO - 2023-06-22 07:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:05 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:05 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:05 --> Controller Class Initialized
INFO - 2023-06-22 07:28:05 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:05 --> Model Class Initialized
INFO - 2023-06-22 07:28:05 --> Final output sent to browser
DEBUG - 2023-06-22 07:28:05 --> Total execution time: 0.0272
ERROR - 2023-06-22 07:28:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:14 --> Config Class Initialized
INFO - 2023-06-22 07:28:14 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:14 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:14 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:14 --> URI Class Initialized
INFO - 2023-06-22 07:28:14 --> Router Class Initialized
INFO - 2023-06-22 07:28:14 --> Output Class Initialized
INFO - 2023-06-22 07:28:14 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:14 --> Input Class Initialized
INFO - 2023-06-22 07:28:14 --> Language Class Initialized
INFO - 2023-06-22 07:28:14 --> Loader Class Initialized
INFO - 2023-06-22 07:28:14 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:14 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:14 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:14 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:14 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:14 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:14 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:14 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:14 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:14 --> Parser Class Initialized
INFO - 2023-06-22 07:28:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:14 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:14 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:14 --> Controller Class Initialized
INFO - 2023-06-22 07:28:14 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:28:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:14 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-06-22 07:28:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:28:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:28:14 --> Model Class Initialized
INFO - 2023-06-22 07:28:14 --> Model Class Initialized
INFO - 2023-06-22 07:28:14 --> Model Class Initialized
INFO - 2023-06-22 07:28:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:28:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:28:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:28:14 --> Final output sent to browser
DEBUG - 2023-06-22 07:28:14 --> Total execution time: 0.1203
ERROR - 2023-06-22 07:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:23 --> Config Class Initialized
INFO - 2023-06-22 07:28:23 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:23 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:23 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:23 --> URI Class Initialized
DEBUG - 2023-06-22 07:28:23 --> No URI present. Default controller set.
INFO - 2023-06-22 07:28:23 --> Router Class Initialized
INFO - 2023-06-22 07:28:23 --> Output Class Initialized
INFO - 2023-06-22 07:28:23 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:23 --> Input Class Initialized
INFO - 2023-06-22 07:28:23 --> Language Class Initialized
INFO - 2023-06-22 07:28:23 --> Loader Class Initialized
INFO - 2023-06-22 07:28:23 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:23 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:23 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:23 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:23 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:23 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:23 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:23 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:23 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:23 --> Parser Class Initialized
INFO - 2023-06-22 07:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:23 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:23 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:23 --> Controller Class Initialized
INFO - 2023-06-22 07:28:23 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:23 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:23 --> Model Class Initialized
INFO - 2023-06-22 07:28:23 --> Model Class Initialized
INFO - 2023-06-22 07:28:23 --> Model Class Initialized
INFO - 2023-06-22 07:28:23 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:23 --> Model Class Initialized
INFO - 2023-06-22 07:28:23 --> Model Class Initialized
INFO - 2023-06-22 07:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 07:28:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:28:23 --> Model Class Initialized
INFO - 2023-06-22 07:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:28:23 --> Final output sent to browser
DEBUG - 2023-06-22 07:28:23 --> Total execution time: 0.0726
ERROR - 2023-06-22 07:28:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:30 --> Config Class Initialized
INFO - 2023-06-22 07:28:30 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:30 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:30 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:30 --> URI Class Initialized
INFO - 2023-06-22 07:28:30 --> Router Class Initialized
INFO - 2023-06-22 07:28:30 --> Output Class Initialized
INFO - 2023-06-22 07:28:30 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:30 --> Input Class Initialized
INFO - 2023-06-22 07:28:30 --> Language Class Initialized
INFO - 2023-06-22 07:28:30 --> Loader Class Initialized
INFO - 2023-06-22 07:28:30 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:30 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:30 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:30 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:30 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:30 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:30 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:30 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:30 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:30 --> Parser Class Initialized
INFO - 2023-06-22 07:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:30 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:30 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:30 --> Controller Class Initialized
INFO - 2023-06-22 07:28:30 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:30 --> Model Class Initialized
INFO - 2023-06-22 07:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-22 07:28:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:28:30 --> Model Class Initialized
INFO - 2023-06-22 07:28:30 --> Model Class Initialized
INFO - 2023-06-22 07:28:30 --> Model Class Initialized
INFO - 2023-06-22 07:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:28:30 --> Final output sent to browser
DEBUG - 2023-06-22 07:28:30 --> Total execution time: 0.0642
ERROR - 2023-06-22 07:28:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:31 --> Config Class Initialized
INFO - 2023-06-22 07:28:31 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:31 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:31 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:31 --> URI Class Initialized
INFO - 2023-06-22 07:28:31 --> Router Class Initialized
INFO - 2023-06-22 07:28:31 --> Output Class Initialized
INFO - 2023-06-22 07:28:31 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:31 --> Input Class Initialized
INFO - 2023-06-22 07:28:31 --> Language Class Initialized
INFO - 2023-06-22 07:28:31 --> Loader Class Initialized
INFO - 2023-06-22 07:28:31 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:31 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:31 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:31 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:31 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:31 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:31 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:31 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:31 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:31 --> Parser Class Initialized
INFO - 2023-06-22 07:28:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:31 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:31 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:31 --> Controller Class Initialized
INFO - 2023-06-22 07:28:31 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:31 --> Model Class Initialized
INFO - 2023-06-22 07:28:31 --> Final output sent to browser
DEBUG - 2023-06-22 07:28:31 --> Total execution time: 0.0156
ERROR - 2023-06-22 07:28:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:33 --> Config Class Initialized
INFO - 2023-06-22 07:28:33 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:33 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:33 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:33 --> URI Class Initialized
INFO - 2023-06-22 07:28:33 --> Router Class Initialized
INFO - 2023-06-22 07:28:33 --> Output Class Initialized
INFO - 2023-06-22 07:28:33 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:33 --> Input Class Initialized
INFO - 2023-06-22 07:28:33 --> Language Class Initialized
INFO - 2023-06-22 07:28:33 --> Loader Class Initialized
INFO - 2023-06-22 07:28:33 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:33 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:33 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:33 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:33 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:33 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:33 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:33 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:33 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:33 --> Parser Class Initialized
INFO - 2023-06-22 07:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:33 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:33 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:33 --> Controller Class Initialized
INFO - 2023-06-22 07:28:33 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:33 --> Model Class Initialized
INFO - 2023-06-22 07:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-06-22 07:28:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:28:33 --> Model Class Initialized
INFO - 2023-06-22 07:28:33 --> Model Class Initialized
INFO - 2023-06-22 07:28:33 --> Model Class Initialized
INFO - 2023-06-22 07:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:28:33 --> Final output sent to browser
DEBUG - 2023-06-22 07:28:33 --> Total execution time: 0.0620
ERROR - 2023-06-22 07:28:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:34 --> Config Class Initialized
INFO - 2023-06-22 07:28:34 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:34 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:34 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:34 --> URI Class Initialized
INFO - 2023-06-22 07:28:34 --> Router Class Initialized
INFO - 2023-06-22 07:28:34 --> Output Class Initialized
INFO - 2023-06-22 07:28:34 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:34 --> Input Class Initialized
INFO - 2023-06-22 07:28:34 --> Language Class Initialized
INFO - 2023-06-22 07:28:34 --> Loader Class Initialized
INFO - 2023-06-22 07:28:34 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:34 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:34 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:34 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:34 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:34 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:34 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:34 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:34 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:34 --> Parser Class Initialized
INFO - 2023-06-22 07:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:34 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:34 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:34 --> Controller Class Initialized
INFO - 2023-06-22 07:28:34 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:34 --> Model Class Initialized
INFO - 2023-06-22 07:28:34 --> Final output sent to browser
DEBUG - 2023-06-22 07:28:34 --> Total execution time: 0.0159
ERROR - 2023-06-22 07:28:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:37 --> Config Class Initialized
INFO - 2023-06-22 07:28:37 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:37 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:37 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:37 --> URI Class Initialized
INFO - 2023-06-22 07:28:37 --> Router Class Initialized
INFO - 2023-06-22 07:28:37 --> Output Class Initialized
INFO - 2023-06-22 07:28:37 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:37 --> Input Class Initialized
INFO - 2023-06-22 07:28:37 --> Language Class Initialized
INFO - 2023-06-22 07:28:37 --> Loader Class Initialized
INFO - 2023-06-22 07:28:37 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:37 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:37 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:37 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:37 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:37 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:37 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:37 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:37 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:37 --> Parser Class Initialized
INFO - 2023-06-22 07:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:37 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:37 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:37 --> Controller Class Initialized
INFO - 2023-06-22 07:28:37 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 07:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:37 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-06-22 07:28:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 07:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 07:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 07:28:37 --> Model Class Initialized
INFO - 2023-06-22 07:28:37 --> Model Class Initialized
INFO - 2023-06-22 07:28:37 --> Model Class Initialized
INFO - 2023-06-22 07:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 07:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 07:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 07:28:37 --> Final output sent to browser
DEBUG - 2023-06-22 07:28:37 --> Total execution time: 0.0739
ERROR - 2023-06-22 07:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 07:28:38 --> Config Class Initialized
INFO - 2023-06-22 07:28:38 --> Hooks Class Initialized
DEBUG - 2023-06-22 07:28:38 --> UTF-8 Support Enabled
INFO - 2023-06-22 07:28:38 --> Utf8 Class Initialized
INFO - 2023-06-22 07:28:38 --> URI Class Initialized
DEBUG - 2023-06-22 07:28:38 --> No URI present. Default controller set.
INFO - 2023-06-22 07:28:38 --> Router Class Initialized
INFO - 2023-06-22 07:28:38 --> Output Class Initialized
INFO - 2023-06-22 07:28:38 --> Security Class Initialized
DEBUG - 2023-06-22 07:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 07:28:38 --> Input Class Initialized
INFO - 2023-06-22 07:28:38 --> Language Class Initialized
INFO - 2023-06-22 07:28:38 --> Loader Class Initialized
INFO - 2023-06-22 07:28:38 --> Helper loaded: url_helper
INFO - 2023-06-22 07:28:38 --> Helper loaded: file_helper
INFO - 2023-06-22 07:28:38 --> Helper loaded: html_helper
INFO - 2023-06-22 07:28:38 --> Helper loaded: text_helper
INFO - 2023-06-22 07:28:38 --> Helper loaded: form_helper
INFO - 2023-06-22 07:28:38 --> Helper loaded: lang_helper
INFO - 2023-06-22 07:28:38 --> Helper loaded: security_helper
INFO - 2023-06-22 07:28:38 --> Helper loaded: cookie_helper
INFO - 2023-06-22 07:28:38 --> Database Driver Class Initialized
INFO - 2023-06-22 07:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 07:28:38 --> Parser Class Initialized
INFO - 2023-06-22 07:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 07:28:38 --> Pagination Class Initialized
INFO - 2023-06-22 07:28:38 --> Form Validation Class Initialized
INFO - 2023-06-22 07:28:38 --> Controller Class Initialized
INFO - 2023-06-22 07:28:38 --> Model Class Initialized
DEBUG - 2023-06-22 07:28:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 10:19:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 10:19:22 --> Config Class Initialized
INFO - 2023-06-22 10:19:22 --> Hooks Class Initialized
DEBUG - 2023-06-22 10:19:22 --> UTF-8 Support Enabled
INFO - 2023-06-22 10:19:22 --> Utf8 Class Initialized
INFO - 2023-06-22 10:19:22 --> URI Class Initialized
DEBUG - 2023-06-22 10:19:22 --> No URI present. Default controller set.
INFO - 2023-06-22 10:19:22 --> Router Class Initialized
INFO - 2023-06-22 10:19:22 --> Output Class Initialized
INFO - 2023-06-22 10:19:22 --> Security Class Initialized
DEBUG - 2023-06-22 10:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 10:19:22 --> Input Class Initialized
INFO - 2023-06-22 10:19:22 --> Language Class Initialized
INFO - 2023-06-22 10:19:22 --> Loader Class Initialized
INFO - 2023-06-22 10:19:22 --> Helper loaded: url_helper
INFO - 2023-06-22 10:19:22 --> Helper loaded: file_helper
INFO - 2023-06-22 10:19:22 --> Helper loaded: html_helper
INFO - 2023-06-22 10:19:22 --> Helper loaded: text_helper
INFO - 2023-06-22 10:19:22 --> Helper loaded: form_helper
INFO - 2023-06-22 10:19:22 --> Helper loaded: lang_helper
INFO - 2023-06-22 10:19:22 --> Helper loaded: security_helper
INFO - 2023-06-22 10:19:22 --> Helper loaded: cookie_helper
INFO - 2023-06-22 10:19:22 --> Database Driver Class Initialized
INFO - 2023-06-22 10:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 10:19:22 --> Parser Class Initialized
INFO - 2023-06-22 10:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 10:19:22 --> Pagination Class Initialized
INFO - 2023-06-22 10:19:22 --> Form Validation Class Initialized
INFO - 2023-06-22 10:19:22 --> Controller Class Initialized
INFO - 2023-06-22 10:19:22 --> Model Class Initialized
DEBUG - 2023-06-22 10:19:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 11:22:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 11:22:48 --> Config Class Initialized
INFO - 2023-06-22 11:22:48 --> Hooks Class Initialized
DEBUG - 2023-06-22 11:22:48 --> UTF-8 Support Enabled
INFO - 2023-06-22 11:22:48 --> Utf8 Class Initialized
INFO - 2023-06-22 11:22:48 --> URI Class Initialized
DEBUG - 2023-06-22 11:22:48 --> No URI present. Default controller set.
INFO - 2023-06-22 11:22:48 --> Router Class Initialized
INFO - 2023-06-22 11:22:48 --> Output Class Initialized
INFO - 2023-06-22 11:22:48 --> Security Class Initialized
DEBUG - 2023-06-22 11:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 11:22:48 --> Input Class Initialized
INFO - 2023-06-22 11:22:48 --> Language Class Initialized
INFO - 2023-06-22 11:22:48 --> Loader Class Initialized
INFO - 2023-06-22 11:22:48 --> Helper loaded: url_helper
INFO - 2023-06-22 11:22:48 --> Helper loaded: file_helper
INFO - 2023-06-22 11:22:48 --> Helper loaded: html_helper
INFO - 2023-06-22 11:22:48 --> Helper loaded: text_helper
INFO - 2023-06-22 11:22:48 --> Helper loaded: form_helper
INFO - 2023-06-22 11:22:48 --> Helper loaded: lang_helper
INFO - 2023-06-22 11:22:48 --> Helper loaded: security_helper
INFO - 2023-06-22 11:22:48 --> Helper loaded: cookie_helper
INFO - 2023-06-22 11:22:48 --> Database Driver Class Initialized
INFO - 2023-06-22 11:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 11:22:48 --> Parser Class Initialized
INFO - 2023-06-22 11:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 11:22:48 --> Pagination Class Initialized
INFO - 2023-06-22 11:22:48 --> Form Validation Class Initialized
INFO - 2023-06-22 11:22:48 --> Controller Class Initialized
INFO - 2023-06-22 11:22:48 --> Model Class Initialized
DEBUG - 2023-06-22 11:22:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 11:22:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 11:22:49 --> Config Class Initialized
INFO - 2023-06-22 11:22:49 --> Hooks Class Initialized
DEBUG - 2023-06-22 11:22:49 --> UTF-8 Support Enabled
INFO - 2023-06-22 11:22:49 --> Utf8 Class Initialized
INFO - 2023-06-22 11:22:49 --> URI Class Initialized
INFO - 2023-06-22 11:22:49 --> Router Class Initialized
INFO - 2023-06-22 11:22:49 --> Output Class Initialized
INFO - 2023-06-22 11:22:49 --> Security Class Initialized
DEBUG - 2023-06-22 11:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 11:22:49 --> Input Class Initialized
INFO - 2023-06-22 11:22:49 --> Language Class Initialized
INFO - 2023-06-22 11:22:49 --> Loader Class Initialized
INFO - 2023-06-22 11:22:49 --> Helper loaded: url_helper
INFO - 2023-06-22 11:22:49 --> Helper loaded: file_helper
INFO - 2023-06-22 11:22:49 --> Helper loaded: html_helper
INFO - 2023-06-22 11:22:49 --> Helper loaded: text_helper
INFO - 2023-06-22 11:22:49 --> Helper loaded: form_helper
INFO - 2023-06-22 11:22:49 --> Helper loaded: lang_helper
INFO - 2023-06-22 11:22:49 --> Helper loaded: security_helper
INFO - 2023-06-22 11:22:49 --> Helper loaded: cookie_helper
INFO - 2023-06-22 11:22:49 --> Database Driver Class Initialized
INFO - 2023-06-22 11:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 11:22:49 --> Parser Class Initialized
INFO - 2023-06-22 11:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 11:22:49 --> Pagination Class Initialized
INFO - 2023-06-22 11:22:49 --> Form Validation Class Initialized
INFO - 2023-06-22 11:22:49 --> Controller Class Initialized
INFO - 2023-06-22 11:22:49 --> Model Class Initialized
DEBUG - 2023-06-22 11:22:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 11:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 11:22:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 11:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 11:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 11:22:49 --> Model Class Initialized
INFO - 2023-06-22 11:22:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 11:22:49 --> Final output sent to browser
DEBUG - 2023-06-22 11:22:49 --> Total execution time: 0.0391
ERROR - 2023-06-22 12:43:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 12:43:29 --> Config Class Initialized
INFO - 2023-06-22 12:43:29 --> Hooks Class Initialized
DEBUG - 2023-06-22 12:43:29 --> UTF-8 Support Enabled
INFO - 2023-06-22 12:43:29 --> Utf8 Class Initialized
INFO - 2023-06-22 12:43:29 --> URI Class Initialized
DEBUG - 2023-06-22 12:43:29 --> No URI present. Default controller set.
INFO - 2023-06-22 12:43:29 --> Router Class Initialized
INFO - 2023-06-22 12:43:29 --> Output Class Initialized
INFO - 2023-06-22 12:43:29 --> Security Class Initialized
DEBUG - 2023-06-22 12:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 12:43:29 --> Input Class Initialized
INFO - 2023-06-22 12:43:29 --> Language Class Initialized
INFO - 2023-06-22 12:43:29 --> Loader Class Initialized
INFO - 2023-06-22 12:43:29 --> Helper loaded: url_helper
INFO - 2023-06-22 12:43:29 --> Helper loaded: file_helper
INFO - 2023-06-22 12:43:29 --> Helper loaded: html_helper
INFO - 2023-06-22 12:43:29 --> Helper loaded: text_helper
INFO - 2023-06-22 12:43:29 --> Helper loaded: form_helper
INFO - 2023-06-22 12:43:29 --> Helper loaded: lang_helper
INFO - 2023-06-22 12:43:29 --> Helper loaded: security_helper
INFO - 2023-06-22 12:43:29 --> Helper loaded: cookie_helper
INFO - 2023-06-22 12:43:29 --> Database Driver Class Initialized
INFO - 2023-06-22 12:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 12:43:29 --> Parser Class Initialized
INFO - 2023-06-22 12:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 12:43:29 --> Pagination Class Initialized
INFO - 2023-06-22 12:43:29 --> Form Validation Class Initialized
INFO - 2023-06-22 12:43:29 --> Controller Class Initialized
INFO - 2023-06-22 12:43:29 --> Model Class Initialized
DEBUG - 2023-06-22 12:43:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-22 12:43:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 12:43:32 --> Config Class Initialized
INFO - 2023-06-22 12:43:32 --> Hooks Class Initialized
DEBUG - 2023-06-22 12:43:32 --> UTF-8 Support Enabled
INFO - 2023-06-22 12:43:32 --> Utf8 Class Initialized
INFO - 2023-06-22 12:43:32 --> URI Class Initialized
INFO - 2023-06-22 12:43:32 --> Router Class Initialized
INFO - 2023-06-22 12:43:32 --> Output Class Initialized
INFO - 2023-06-22 12:43:32 --> Security Class Initialized
DEBUG - 2023-06-22 12:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 12:43:32 --> Input Class Initialized
INFO - 2023-06-22 12:43:32 --> Language Class Initialized
INFO - 2023-06-22 12:43:32 --> Loader Class Initialized
INFO - 2023-06-22 12:43:32 --> Helper loaded: url_helper
INFO - 2023-06-22 12:43:32 --> Helper loaded: file_helper
INFO - 2023-06-22 12:43:33 --> Helper loaded: html_helper
INFO - 2023-06-22 12:43:33 --> Helper loaded: text_helper
INFO - 2023-06-22 12:43:33 --> Helper loaded: form_helper
INFO - 2023-06-22 12:43:33 --> Helper loaded: lang_helper
INFO - 2023-06-22 12:43:33 --> Helper loaded: security_helper
INFO - 2023-06-22 12:43:33 --> Helper loaded: cookie_helper
INFO - 2023-06-22 12:43:33 --> Database Driver Class Initialized
INFO - 2023-06-22 12:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 12:43:33 --> Parser Class Initialized
INFO - 2023-06-22 12:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 12:43:33 --> Pagination Class Initialized
INFO - 2023-06-22 12:43:33 --> Form Validation Class Initialized
INFO - 2023-06-22 12:43:33 --> Controller Class Initialized
INFO - 2023-06-22 12:43:33 --> Model Class Initialized
DEBUG - 2023-06-22 12:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:43:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 12:43:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:43:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 12:43:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 12:43:33 --> Model Class Initialized
INFO - 2023-06-22 12:43:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 12:43:33 --> Final output sent to browser
DEBUG - 2023-06-22 12:43:33 --> Total execution time: 0.0323
ERROR - 2023-06-22 12:43:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 12:43:45 --> Config Class Initialized
INFO - 2023-06-22 12:43:45 --> Hooks Class Initialized
DEBUG - 2023-06-22 12:43:45 --> UTF-8 Support Enabled
INFO - 2023-06-22 12:43:45 --> Utf8 Class Initialized
INFO - 2023-06-22 12:43:45 --> URI Class Initialized
INFO - 2023-06-22 12:43:45 --> Router Class Initialized
INFO - 2023-06-22 12:43:45 --> Output Class Initialized
INFO - 2023-06-22 12:43:45 --> Security Class Initialized
DEBUG - 2023-06-22 12:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 12:43:45 --> Input Class Initialized
INFO - 2023-06-22 12:43:45 --> Language Class Initialized
INFO - 2023-06-22 12:43:45 --> Loader Class Initialized
INFO - 2023-06-22 12:43:45 --> Helper loaded: url_helper
INFO - 2023-06-22 12:43:45 --> Helper loaded: file_helper
INFO - 2023-06-22 12:43:45 --> Helper loaded: html_helper
INFO - 2023-06-22 12:43:45 --> Helper loaded: text_helper
INFO - 2023-06-22 12:43:45 --> Helper loaded: form_helper
INFO - 2023-06-22 12:43:45 --> Helper loaded: lang_helper
INFO - 2023-06-22 12:43:45 --> Helper loaded: security_helper
INFO - 2023-06-22 12:43:45 --> Helper loaded: cookie_helper
INFO - 2023-06-22 12:43:45 --> Database Driver Class Initialized
INFO - 2023-06-22 12:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 12:43:45 --> Parser Class Initialized
INFO - 2023-06-22 12:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 12:43:45 --> Pagination Class Initialized
INFO - 2023-06-22 12:43:45 --> Form Validation Class Initialized
INFO - 2023-06-22 12:43:45 --> Controller Class Initialized
INFO - 2023-06-22 12:43:45 --> Model Class Initialized
DEBUG - 2023-06-22 12:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:43:45 --> Model Class Initialized
INFO - 2023-06-22 12:43:45 --> Final output sent to browser
DEBUG - 2023-06-22 12:43:45 --> Total execution time: 0.0216
ERROR - 2023-06-22 12:43:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 12:43:46 --> Config Class Initialized
INFO - 2023-06-22 12:43:46 --> Hooks Class Initialized
DEBUG - 2023-06-22 12:43:46 --> UTF-8 Support Enabled
INFO - 2023-06-22 12:43:46 --> Utf8 Class Initialized
INFO - 2023-06-22 12:43:46 --> URI Class Initialized
DEBUG - 2023-06-22 12:43:46 --> No URI present. Default controller set.
INFO - 2023-06-22 12:43:46 --> Router Class Initialized
INFO - 2023-06-22 12:43:46 --> Output Class Initialized
INFO - 2023-06-22 12:43:46 --> Security Class Initialized
DEBUG - 2023-06-22 12:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 12:43:46 --> Input Class Initialized
INFO - 2023-06-22 12:43:46 --> Language Class Initialized
INFO - 2023-06-22 12:43:46 --> Loader Class Initialized
INFO - 2023-06-22 12:43:46 --> Helper loaded: url_helper
INFO - 2023-06-22 12:43:46 --> Helper loaded: file_helper
INFO - 2023-06-22 12:43:46 --> Helper loaded: html_helper
INFO - 2023-06-22 12:43:46 --> Helper loaded: text_helper
INFO - 2023-06-22 12:43:46 --> Helper loaded: form_helper
INFO - 2023-06-22 12:43:46 --> Helper loaded: lang_helper
INFO - 2023-06-22 12:43:46 --> Helper loaded: security_helper
INFO - 2023-06-22 12:43:46 --> Helper loaded: cookie_helper
INFO - 2023-06-22 12:43:46 --> Database Driver Class Initialized
INFO - 2023-06-22 12:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 12:43:46 --> Parser Class Initialized
INFO - 2023-06-22 12:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 12:43:46 --> Pagination Class Initialized
INFO - 2023-06-22 12:43:46 --> Form Validation Class Initialized
INFO - 2023-06-22 12:43:46 --> Controller Class Initialized
INFO - 2023-06-22 12:43:46 --> Model Class Initialized
DEBUG - 2023-06-22 12:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:43:46 --> Model Class Initialized
DEBUG - 2023-06-22 12:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:43:46 --> Model Class Initialized
INFO - 2023-06-22 12:43:46 --> Model Class Initialized
INFO - 2023-06-22 12:43:46 --> Model Class Initialized
INFO - 2023-06-22 12:43:46 --> Model Class Initialized
DEBUG - 2023-06-22 12:43:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 12:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:43:46 --> Model Class Initialized
INFO - 2023-06-22 12:43:46 --> Model Class Initialized
INFO - 2023-06-22 12:43:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 12:43:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:43:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 12:43:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 12:43:46 --> Model Class Initialized
INFO - 2023-06-22 12:43:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 12:43:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 12:43:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 12:43:46 --> Final output sent to browser
DEBUG - 2023-06-22 12:43:46 --> Total execution time: 0.0918
ERROR - 2023-06-22 12:44:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 12:44:10 --> Config Class Initialized
INFO - 2023-06-22 12:44:10 --> Hooks Class Initialized
DEBUG - 2023-06-22 12:44:10 --> UTF-8 Support Enabled
INFO - 2023-06-22 12:44:10 --> Utf8 Class Initialized
INFO - 2023-06-22 12:44:10 --> URI Class Initialized
DEBUG - 2023-06-22 12:44:10 --> No URI present. Default controller set.
INFO - 2023-06-22 12:44:10 --> Router Class Initialized
INFO - 2023-06-22 12:44:10 --> Output Class Initialized
INFO - 2023-06-22 12:44:10 --> Security Class Initialized
DEBUG - 2023-06-22 12:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 12:44:10 --> Input Class Initialized
INFO - 2023-06-22 12:44:10 --> Language Class Initialized
INFO - 2023-06-22 12:44:10 --> Loader Class Initialized
INFO - 2023-06-22 12:44:10 --> Helper loaded: url_helper
INFO - 2023-06-22 12:44:10 --> Helper loaded: file_helper
INFO - 2023-06-22 12:44:10 --> Helper loaded: html_helper
INFO - 2023-06-22 12:44:10 --> Helper loaded: text_helper
INFO - 2023-06-22 12:44:10 --> Helper loaded: form_helper
INFO - 2023-06-22 12:44:10 --> Helper loaded: lang_helper
INFO - 2023-06-22 12:44:10 --> Helper loaded: security_helper
INFO - 2023-06-22 12:44:10 --> Helper loaded: cookie_helper
INFO - 2023-06-22 12:44:10 --> Database Driver Class Initialized
INFO - 2023-06-22 12:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 12:44:10 --> Parser Class Initialized
INFO - 2023-06-22 12:44:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 12:44:10 --> Pagination Class Initialized
INFO - 2023-06-22 12:44:10 --> Form Validation Class Initialized
INFO - 2023-06-22 12:44:10 --> Controller Class Initialized
INFO - 2023-06-22 12:44:10 --> Model Class Initialized
DEBUG - 2023-06-22 12:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:10 --> Model Class Initialized
DEBUG - 2023-06-22 12:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:10 --> Model Class Initialized
INFO - 2023-06-22 12:44:10 --> Model Class Initialized
INFO - 2023-06-22 12:44:10 --> Model Class Initialized
INFO - 2023-06-22 12:44:10 --> Model Class Initialized
DEBUG - 2023-06-22 12:44:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 12:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:10 --> Model Class Initialized
INFO - 2023-06-22 12:44:10 --> Model Class Initialized
INFO - 2023-06-22 12:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 12:44:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 12:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 12:44:10 --> Model Class Initialized
INFO - 2023-06-22 12:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 12:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 12:44:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 12:44:10 --> Final output sent to browser
DEBUG - 2023-06-22 12:44:10 --> Total execution time: 0.0816
ERROR - 2023-06-22 12:44:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 12:44:14 --> Config Class Initialized
INFO - 2023-06-22 12:44:14 --> Hooks Class Initialized
DEBUG - 2023-06-22 12:44:14 --> UTF-8 Support Enabled
INFO - 2023-06-22 12:44:14 --> Utf8 Class Initialized
INFO - 2023-06-22 12:44:14 --> URI Class Initialized
INFO - 2023-06-22 12:44:14 --> Router Class Initialized
INFO - 2023-06-22 12:44:14 --> Output Class Initialized
INFO - 2023-06-22 12:44:14 --> Security Class Initialized
DEBUG - 2023-06-22 12:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 12:44:14 --> Input Class Initialized
INFO - 2023-06-22 12:44:14 --> Language Class Initialized
INFO - 2023-06-22 12:44:14 --> Loader Class Initialized
INFO - 2023-06-22 12:44:14 --> Helper loaded: url_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: file_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: html_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: text_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: form_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: lang_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: security_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: cookie_helper
INFO - 2023-06-22 12:44:14 --> Database Driver Class Initialized
INFO - 2023-06-22 12:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 12:44:14 --> Parser Class Initialized
INFO - 2023-06-22 12:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 12:44:14 --> Pagination Class Initialized
INFO - 2023-06-22 12:44:14 --> Form Validation Class Initialized
INFO - 2023-06-22 12:44:14 --> Controller Class Initialized
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
DEBUG - 2023-06-22 12:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-22 12:44:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 12:44:14 --> Final output sent to browser
DEBUG - 2023-06-22 12:44:14 --> Total execution time: 0.0285
ERROR - 2023-06-22 12:44:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-22 12:44:14 --> Config Class Initialized
INFO - 2023-06-22 12:44:14 --> Hooks Class Initialized
DEBUG - 2023-06-22 12:44:14 --> UTF-8 Support Enabled
INFO - 2023-06-22 12:44:14 --> Utf8 Class Initialized
INFO - 2023-06-22 12:44:14 --> URI Class Initialized
INFO - 2023-06-22 12:44:14 --> Router Class Initialized
INFO - 2023-06-22 12:44:14 --> Output Class Initialized
INFO - 2023-06-22 12:44:14 --> Security Class Initialized
DEBUG - 2023-06-22 12:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-22 12:44:14 --> Input Class Initialized
INFO - 2023-06-22 12:44:14 --> Language Class Initialized
INFO - 2023-06-22 12:44:14 --> Loader Class Initialized
INFO - 2023-06-22 12:44:14 --> Helper loaded: url_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: file_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: html_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: text_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: form_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: lang_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: security_helper
INFO - 2023-06-22 12:44:14 --> Helper loaded: cookie_helper
INFO - 2023-06-22 12:44:14 --> Database Driver Class Initialized
INFO - 2023-06-22 12:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-22 12:44:14 --> Parser Class Initialized
INFO - 2023-06-22 12:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-22 12:44:14 --> Pagination Class Initialized
INFO - 2023-06-22 12:44:14 --> Form Validation Class Initialized
INFO - 2023-06-22 12:44:14 --> Controller Class Initialized
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
DEBUG - 2023-06-22 12:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
DEBUG - 2023-06-22 12:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
DEBUG - 2023-06-22 12:44:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-22 12:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-22 12:44:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-22 12:44:14 --> Model Class Initialized
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-22 12:44:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-22 12:44:14 --> Final output sent to browser
DEBUG - 2023-06-22 12:44:14 --> Total execution time: 0.0798
